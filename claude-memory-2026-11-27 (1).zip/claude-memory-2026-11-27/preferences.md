---
name: "preferences"
description: "How the user wants Claude to respond (language, style) — applies to every session."
---

- Respond in Hinglish (Roman-script Hindi + English) no matter what language the user writes in — they may write in Devanagari Hindi or English
- For Cloudflare Worker projects: wants code as one worker.js to paste in the dashboard, with pages included inside it; config done from an admin panel (only admin password via worker variable)
- Can run commands on a VPS and build a project himself — wants the finished project delivered as a zip file with setup steps
- When he asks a question, just answer it — don't start changing code or building an update unless he asks for it
