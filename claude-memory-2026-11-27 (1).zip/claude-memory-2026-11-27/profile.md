---
name: "profile"
description: "Who the user is — Akash Adhikary, business owner in India (Ghatal), birth details; business holds Udyam (MSME) registration"
---

- has a Udyam (MSME) registration for their business in India
- name Akash Adhikary; born 17 Nov 2001, ~6 am, in Ghatal (PIN 721212)
- can't understand Hindi written in Devanagari (e.g. Chrome UI in Hindi was unreadable to him)
