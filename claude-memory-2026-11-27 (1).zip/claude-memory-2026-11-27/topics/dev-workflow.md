---
name: "dev-workflow"
description: "How the user builds software projects with Claude models — build with Sonnet 4.6 first, then bug-hunt with Opus 5.5 before final upload"
---

- builds any system with Sonnet 4.6 first, then uses Opus 5.5 to find bugs, then does the final upload; wants to keep using Sonnet 4.6 (via API) after it leaves the Claude app
