---
name: "health"
description: "Health notes"
---

- gets recurring genital herpes outbreaks (one last year, another in Nov 2026); keeps acyclovir 400 mg, doctor advised one every 8 hours during an outbreak
