---
name: "animation-reels"
description: "User's animated reel making (emotional/relatable story reels on existing audio) — read when they ask for a reel, animation video or lyric/caption video"
---

- wants to make mostly emotional story-type animation reels set to an existing audio, that people relate to their own life and share
- on-screen lyrics/captions should be Hindi written in English (Roman) letters
- wants premium-level animation like the YouTube channel "RG Bucket List"; did not like the first flat 2D style (previously asked for 3D-style characters)
- found the code-built 3D-character version very poor; then asked for 2D, hand-sketch type designs are fine
- expects the song to be looked up first (name, lyrics, meaning) and the story built from its meaning
- liked the hand-sketch 2D reel ("badiya hai"); wants later reels in the same sketch type but a different style each time; asked for the next reel to be 1 minute long
- wants clips to change in sync with the beat so it is fun to watch
- did not like the black-and-white chalkboard look ("achcha ni lag ra"); asked for it redone in the cream-paper coloured sketch style of the reel he liked
