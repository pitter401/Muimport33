---
name: "money-transfer-cashout"
description: "User's planned money transfer business in India — taking money from people online and handing out cash; exploring licence route"
---

- wants to start a money transfer business in India: take money from people online and give them cash; asked what licence it needs (Oct 2026)
