---
name: "telegram-channel-funnel"
description: "Live Meta ad funnel for a Telegram channel at join.nikhilagency.online (landing → join-request link → Meta Subscribe), campaign tracking"
---

- Running a Meta funnel ad for one of their Telegram channels: landing page ("You're invited to join this Telegram channel") → Join button → bot generates an invite link → user sends join request → Meta should receive a Subscribe/subscriber event on the join request
- Wants Pixel ID, CAPI token, bot token/username etc. all changeable via Cloudflare Worker variables
- Has already added a bot to the channel as admin with permissions; has pixel ID, CAPI token and bot token ready
- Asked Claude to build the full system and walk them through setup; says they don't have much technical idea
- Funnel is live on join.nikhilagency.online (Cloudflare Worker + D1, admin page at /admin); Meta ads already running with UTM parameters on the ad URLs; wants per-campaign join-request tracking and an AUTO_APPROVE true/false variable for instant vs manual approval
- Wanted an advanced admin dashboard (LP views, join clicks, verified joins, left, active members, from-ad vs direct, daily budget, spend, cost per join and real cost per active member after leaves); Meta ad account ID 2330744311032018 and an ads_read system-user token are set in Worker variables
- User's own final worker.js (2026-09-26) is the baseline for all future changes — it adds tracking for the promoted platform's subscription purchases and ROI against ad spend; any future update must be made on top of that version (user will share the current file when changing it)
- Wants to start their own ad agency that runs Meta ads for paying clients' Telegram channels from the agency's ad accounts, with agency-provided landing pages and a per-client dashboard (spend, remaining budget, joins, left, cost per member)
- The "xmx" Meta campaigns and the "xmx180" custom audience (Subscribe event, 180 days) belong to this other business, not to P2P INR — don't mix them into P2P INR ad setups
