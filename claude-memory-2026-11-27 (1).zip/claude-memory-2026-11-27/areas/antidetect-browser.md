---
name: "antidetect-browser"
description: "User's own antidetect browser product (Camoufox Windows EXE, user + admin builds, VPS backend on mytw.cc, NOWPayments) — grew out of fb automation"
---

- building own antidetect browser on Camoufox (ok with Firefox engine), wants it the strongest in the market and priced so normal antidetect buyers can afford it
- separate admin EXE (imports his own profiles exported from [[fb-account-automation]] VPS; free for admin; download disabled from admin panel after he takes it) and public user EXE with no admin features
- backend runs on his VPS (not Cloudflare Worker), on his domain mytw.cc (bought on Spaceship, moving its DNS off Cloudflare to Spaceship, pointed at the VPS); must not touch his bizsite/adflow setups; NOWPayments via iframe; admin panel sets monthly profile limits and pricing; Firefox only at first (later open to Chrome engine, see below)
- per-profile distinct noise (canvas etc.), real host GPU shown, 1920x1080, proxy travels with exported profile; export = shift (FB moves to PC; the Gmail must stay logged in on BOTH — on the PC copy and in a mail profile on the VPS); Android skipped for now
- plans a website for the antidetect browser later as a startup, and to sell automation + warmup setup to users for a fee
- rejected the first mytw.cc site as basic/cheap — wants a premium, not-AI-looking UI (as if made by a very experienced dev team) for the website, admin panel and apps; thinks the website should be built in React
- website direction: likes AdsPower's site/Google sitelinks layout but wants richer animations; colour system from reels he liked — Midnight Black #08080C / Pure White / Lime Green #C8F432 in a 60/30/10 split; brand name set from the admin panel
- wants the Windows app code-signed before public release (no "unknown app" warning)
- decided to drop the Android APK entirely — the antidetect is offered only as a PC (Windows) app
- wants site presets for users (like his own Facebook preset), and every site setup he makes from the Telegram bot (any-site voice setup) also kept as a preset
- wants it as close to 100% undetectable as possible — the canvas-noise "tampering" detection must be fixed; fine if each profile costs more and open to buying fingerprints/noise; profiles made/warmed on the Linux VPS are acceptable since they move to a real PC
- (Nov 2026) now wants the market's most powerful antidetect for his own personal work, keeping the current flow exactly the same; open to a Chrome/Chromium engine and willing to buy VPS/cloud hosting on name.com and $2–3 dedicated IPs (~50 profiles/month); will explain his profile-deletion plan later
- says cost is no problem — wants a 100% undetectable setup since real devices aren't practical; exploring renting Windows machines with real GPUs (monthly, or hourly while working with profiles exported in/out)
- his main work is USA — needs US warm-up in profiles, and warmed profiles must never be deleted; mainly for his own work, may also sell ~5 profiles/day
- plans to collect real Windows PC fingerprint data (one per profile) by running a Windows-only Meta ad (~$5/day for a week) to a page offering ~$1 per submission, paid one week later
- fingerprint-collection plan details: ad targeted to Windows desktop only, ~$5/day, page clearly tells the visitor what data is collected and they choose whether to take the payment; payout one week after the ad runs; each collected PC's data used for a separate profile; wants Facebook traffic ads (~$1/click in US) as the data source; not every clicker will submit and he accepts that
- asked to save this plan; next steps agreed in discussion: collection page + bot first, Chrome engine afterwards; survey domain to be connected later
- dropped the rented-GPU-machine idea for now — going with collected real-PC fingerprints + own Chrome engine; collection rewards paid via PayPal to everyone in every country (wants profiles of any country)
- selling plan: standard profiles using the GoLogin/Multilogin-style method at normal price, and profiles with a 100% unique real-PC fingerprint sold separately at their own (per-profile) pricing
- engine decision: use a ready-made patched Chromium (Option A) for now while the system is built; end goal is still his own Chromium engine (strongest, aiming 100% undetectable); for the build server he wants a less-popular, USA-based provider rented hourly/for a few days
- (later) skipped renting a build server for now (too costly, had doubts); testing CloakBrowser as the Chrome engine — fine if it is one Chrome version behind; plan is to build the whole rest of the system first and make his own engine only once everything works
- for the own-engine build server, leaning to Hostinger KVM 8 on a 1-month plan (~₹5,000, 30-day refund), to be taken only when the engine work starts
