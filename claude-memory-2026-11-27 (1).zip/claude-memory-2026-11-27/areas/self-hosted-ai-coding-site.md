---
name: "self-hosted-ai-coding-site"
description: "User's planned personal Claude-like AI coding website on a non-Claude model (own PC GPU or rented GPU) with admin restriction toggle"
---

- wants to build a Claude-like website with coding ability as close as possible to Claude's top coding model, without using the Claude API
- wants it uncensored / no limitations for advanced development, with an admin option to choose uncensored vs controlled/restricted
- for personal use only; not selling it for now
- PC has a graphics card they can use; also asked about the rented-GPU route and was walking through setup assuming a rented GPU
