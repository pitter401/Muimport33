---
name: "client-business-sites"
description: "User's multi-site system for their US client businesses — one template, admin panel creates a subdomain site per client on their Cloudflare domain"
---

- building a system on their Cloudflare domain (said by voice roughly as "mixa co bm .online"; exact spelling not confirmed) where an admin panel creates a subdomain website per client business (e.g. sandeepan.<domain>) from one shared template, filled with the business's registered name, address, email, phone
- the client sites are used for the businesses' Facebook verification; the businesses are their own clients
- the system runs on nikhilagency.online (client sites as <slug>.nikhilagency.online); decided owner emails must be on the main domain (firstname@nikhilagency.online, forwarded to their inbox), not on the client subdomain, for Meta business email verification
- only the user edits details from the admin panel — clients get no edit access; wants any US business category supported (salon, car rental, etc.), with category chosen or auto-detected from the business name
