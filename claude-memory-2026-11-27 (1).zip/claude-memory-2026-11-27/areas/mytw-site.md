---
name: "mytw-site"
description: "User's website moved from twcard.store to mytw.cc on their VPS/Cloudflare; backup domains mytw.casa, mytw.lol with switchable primary"
---

- changed their website's domain from twcard.store to mytw.cc; both domains on Cloudflare, site set up on their VPS
- adding two backup domains, mytw.casa and mytw.lol; wants to switch which of the three is primary at will, with visitors (from Meta ads) on any domain redirected to the primary
- latest WORKING base worker.js = attachment c1159dd2-worker_10.js — NO $5 fee system, gas + TG notification working; any future changes MUST be built on this file only, NOT on the broken version Claude made
