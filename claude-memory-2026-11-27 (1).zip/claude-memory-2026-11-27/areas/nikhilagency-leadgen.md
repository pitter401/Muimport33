---
name: "nikhilagency-leadgen"
description: "Multi-agent lead-gen / ad-tracking web system on nikhilagency.online — read when the user brings up agents, subdomains, Meta ads tracking, Telegram lead routing, or Cloudflare deploy for this project."
---

- Building a multi-agent lead generation + Meta ad-tracking system for a generic SaaS/software platform; main domain nikhilagency.online, configured on Cloudflare
- Each agent gets a dynamic subdomain (e.g. akash.nikhilagency.online, rohit.nikhilagency.online); one centralized Meta Ad Account + single Meta Pixel / Conversions API across all subdomains
- Landing flow: name + phone → pre-qualification prompt → "Yes, I am Ready" fires a Pixel custom event and redirects to that agent's unique external sign-up/referral link
- Leads routed via a Telegram bot; each agent has a separate Telegram group so one agent's leads never reach another agent
- All config (per-agent Telegram/group IDs, Meta Pixel, Conversions API token, bot token etc.) must come from environment variables
- Chose to deploy the backend on Cloudflare Workers (no VPS/Nginx)
- UI and page text will be customized by the user later
- Communicates in Hinglish (Hindi-English mix)

FINAL WRITE
