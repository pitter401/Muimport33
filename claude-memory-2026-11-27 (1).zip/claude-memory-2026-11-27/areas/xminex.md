---
name: "xminex"
description: "User's XMineX project — Phase 2 website launch via their Telegram channel, with pre-launch hype and a free-claim Telegram bot"
---

- preparing XMineX Phase 2 website launch, to be launched in their Telegram channel ~30 days out (planned as of late Oct 2026); wants pre-launch hype via a Telegram claim bot giving free access to the first 5000 users, promoted with Telegram ads and user sharing
- XMineX website is a mining investment platform with a $50 minimum investment; user says returns are paid from real mining
- Phase 1 ran Apr–Oct 2025 (then closed), ~₹14 lakh business with zero investment; plans ~₹10 lakh of Facebook ads for Phase 2. Phase 2 (mining project being built separately) planned to start around end Dec 2026 / 1 Jan 2027
