---
name: "binance-p2p-merchant"
description: "User's plan to become a Binance P2P merchant run as a legit registered business, ~₹1 Cr/month volume target"
---

- Wants to become a P2P merchant on Binance, set up as a legit business (not informal), targeting ~₹1 Cr/month transaction volume
