---
name: "bizsite"
description: "User's BizSite SaaS (facezio.com clone) on ti9.uk — business websites from Udyam certificate (India) / CNPJ (Brazil), NowPayments USDT, on adsy.com's VPS"
---

- building a facezio.com-style SaaS that generates business websites from company registration; main domain ti9.uk with free subdomains, main domain + extra subdomain domains changeable from admin panel
- India sites in English (user uploads Udyam certificate, cheapest Claude model reads it — no portal scraping); Brazil sites in Portuguese via CNPJ
- website phone/email/WhatsApp asked from the user at site creation, not copied from Udyam
- subscriptions paid via NowPayments; IPN webhook URL shown in admin panel to paste into NowPayments
- runs on same Contabo VPS as adsy.com, in a separate folder, port 3005 (3000–3003 already used)
- deploying in /root/bizsite on the VPS (which also runs adflow and udyam-bot); setting up fully via server IP first, domain not yet purchased — plans to buy it on Spaceship and point it via Cloudflare nameservers
- wants both the main platform site and every customer site to look premium; each customer site should get a business email (e.g. support@coffee.<domain>) whose incoming mails show in that customer's Leads; referred to the domain as ti9.me in later messages
- wants each BizSite update zip named by version (v2, v3, v4, v5…); admin-only "change business" on a site via new Udyam (keep or change subdomain/email); full REST API + docs with bulk India/Brazil import, API free for admin
- mail service (receive-only) for users: name@ti9.uk and name@brand.ti9.uk (no website needed), only on mail domains the admin turns ON (more domains addable later), mailbox limits by plan, admin unlimited
