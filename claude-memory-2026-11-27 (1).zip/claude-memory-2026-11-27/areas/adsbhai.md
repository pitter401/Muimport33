---
name: "adsbhai"
description: "AdsBhai (adsbhai.com) — ads + funnel setup service the user runs Meta ads for"
---

- running Meta ads (CTA Learn More) for AdsBhai, the adsbhai.com ads + funnel setup service, using a reel video
- current pricing: ad account $25 (previously $23; free replacement anytime); premium ad account $45; landing page + full funnel setup $50/month
- funnel service does NOT include an admin app / agent app for clients — never advertise that
- policies: top-up fee 3%; account delivered within 1 hour of payment, funnel in 1–2 days; no refund (replacement only); no discounts; any niche allowed; payment via USDT or UPI; funnel-only sold if client has own ad account
- prefers crypto (USDT) payments; UPI is handled manually by the manager; ad accounts are shared into the client's Business Manager (needs their BM ID)
- considering applying for Udyam for AdsBhai so he can create/verify a Meta Business Manager for it and get its Facebook page verified
- planning (not building yet) an AI chat agent in the AdsBhai bot to handle sales chats human-like in the customer's language, learning from past chats, so most manager work is done by AI; starting with AI reply suggestions for his agents, plus an admin test/debug lab to check how right the AI answers
- his agents are freshers who don't yet know how to talk to customers
- AI features, once built, stay OFF by default until fully debugged and loaded with knowledge
- business model: earns from the top-up fee, which is why replacement is free/unlimited (wants clients' ad spend to keep running)
- full-access ad account option: client tops up himself (no fee), 3 accounts total (1 + 2 replacements); priced $45 normal, $60 Premium full access (previously $50)
- also sells aged (old) Facebook accounts, currently $10 per account
- /products page links are given to Telegram/WhatsApp customers, so it uses Telegram prices
- any niche incl. gambling is accepted; customer-facing replies must never add ban/disable/guarantee disclaimers (strict rule)
- now has a WhatsApp community (with invite link); planning to use it as a fallback for customers who don't have/open Telegram, plus a link in the welcome message — no separate WhatsApp ads
- WhatsApp community already has 1,400+ members; WhatsApp is kept completely free — no Subscribe/Meta events for WhatsApp joins
- has a US WhatsApp number for an agent chat option, wants it OFF by default
- sells ad accounts at $20–23 but most sellers he messaged charge $40–60; planning a price test via a separate /premium funnel link (own Telegram and website prices, same pixel) while still running ads on the current pricing; wants the premium tier positioned as a "Premium / stronger profiles" category; total ad budget for agency ad accounts about $40/day
- Premium tier decided: $45 on Telegram / $40 on website, 3% top-up fee; really offers aged strong-history profiles, higher-spend accounts, 30-min priority delivery, unlimited replacements, dedicated agent; Premium chats go to the manager only by default (agents enabled later one by one), possibly with a separate Premium commission
- launching ads at $45/day total: $40/day agency (2 normal + 2 premium ads) plus a separate $5/day campaign for joins to the AdsBhai private Telegram channel
- AdsBhai Facebook Page is owned by his personal Facebook account; the ad account is on a different account, and his Business Manager only has access to the Page
- competitors often post fake "scam/fake" comments on his ads; wants an AI comment agent that hides competitor comments and instantly replies to genuine ones
- main AdsBhai contact number is the US WhatsApp +1 (646) 270-7080 (wa.me/16462707080); his other number is currently not active and redirects customers there
