---
name: "bm-access-rental"
description: "Service renting access to the user's verified Meta Business Managers for a monthly fee — landing page, USDT BEP20 QR/address payment, admin approval, CAPI"
---

- Has 5–6 verified Meta Business Managers (BM5, BM10, BM25 etc.) and is starting a service giving people access to them to run ads, charging a monthly amount; will run Meta ads for it
- Funnel on Cloudflare Worker (not VPS): customer picks a BM, gives the Facebook account email the BM invite goes to plus WhatsApp, pays USDT BEP20 by QR (wants users pushed to QR, with QR download) or by address, uploads a payment screenshot, then user approves manually and only then the event goes to Meta via Pixel/CAPI
- Monthly prices via QR: BM5 $15, BM10 $25, BM25 $40, BM50 $70; paying to the address costs $5 more on every plan
- Live at domain mexacobm.online (landing page + /admin); Meta ads run on this service via the "bm selling" pixel/dataset under their "Soyeta Agency" business manager
- Plans to give users ad accounts from his verified BM via partner access so they can only run ads while he keeps the rest of the control
- (2026-10-10) ads are bringing lots of leads but zero conversions; weighing a cheaper BM10 price (~$10–15, a few dollars more for Trust Wallet payment), a flow that stays fully inside the website, and adding screenshots of the verified BMs as proof
