---
name: "meta-business-manager"
description: "User's own Meta Business Managers — India-verified \"Shri Ram Mobile and Electronic\" with USD ad account NGTS, plus a US-verified BM (WhatsApp API)"
---

- owns a Meta Business Manager named "Shri Ram Mobile and Electronic"; it is India-verified (Indian registered business)
- has a USD-currency ad account "NGTS" inside that BM and runs their own ads from it without issues
- also has a US-verified Business Manager with a 2000 messaging limit; wants to set up WhatsApp API inside it
- (2026-10-08) a Facebook account of theirs got disabled; a Business Manager was tied to that account (BM had a separate email set on it) and they want to recover that BM; that BM is the verified portfolio "MO HAIR SALON INC", which they say is their own business (they are the owner); they were its only full-access admin and are pursuing a Meta Business Support admin dispute to get a new profile added as admin
- runs several FB accounts/BMs (sells verified, in-review and unverified ad accounts); switches between FB accounts on a phone hotspot, toggling airplane mode to change IP
- going with Proxy-Seller India ISP static proxies (~$3/IP), one IP per FB profile, for new accounts and for the AdsBhai BM API; existing 2 accounts stay on the phone method
