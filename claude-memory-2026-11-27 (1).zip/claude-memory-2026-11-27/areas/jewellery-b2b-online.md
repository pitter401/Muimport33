---
name: "jewellery-b2b-online"
description: "User's plan to take the family imitation-jewellery factory's bulk wholesale to shops online (B2B portal) — with [[father]]"
---

- goal: sell the same bulk wholesale maal that [[father]] sells offline to shops, but online to shops (B2B)
- main problems offline: local wholesalers haggle rates down and resell at 2-3x; goods go on udhaar/credit, payments come late and some never come
- offline sales ~₹20-30L/month with only ~₹1-1.5L left as margin
- wants a normal e-commerce order flow (no manual shop approval); prices visible only after account login
- likes the brand name "Tamra Jewels" and found the domain available
- offline they sell at ~₹20-25/piece, shops buy in 500-1000 piece quantities; plans to sell online at ~₹35/piece for more profit
