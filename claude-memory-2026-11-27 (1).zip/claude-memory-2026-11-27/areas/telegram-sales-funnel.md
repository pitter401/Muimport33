---
name: "telegram-sales-funnel"
description: "User's Cloudflare-Worker-only lead-gen + sales funnel for their digital product/service (Meta ad → MCQ landing → Telegram bot → direct chat → CAPI Purchase)"
---

- building a lead generation + sales system to sell their own digital product/service via Meta ads
- wants it entirely on Cloudflare Workers (no VPS for this): landing page + admin panel + Telegram bot in one worker
- flow: Meta ad → landing with admin-set product + MCQ qualifying questions → Telegram bot deep link; bot gives leads a unique link to message the user directly (user handles chats personally, not via bot); user marks sales with /sold to fire Meta CAPI Purchase
- the whole selling system is in USD; all customer-facing text (landing, bot messages) and admin panel must be in English
- ad plan: optimize for Lead first (no Purchase data yet), switch to Purchase optimization once enough purchase events accumulate
