---
name: "wellayurveda-client"
description: "Client project — user is checking/updating a client's website code (Wellayurveda repo, backend on Render) with Claude; repo sits in old developer's GitHub (netcradus)"
---

- has a client whose code they want to pull to their own PC, have Claude check fully, and update
- client's backend is deployed on Render
- the GitHub account "netcradus" that holds the repo (netcradus/Wellayurveda) belongs to the client's old developer, not the client
