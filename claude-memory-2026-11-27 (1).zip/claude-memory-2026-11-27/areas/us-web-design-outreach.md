---
name: "us-web-design-outreach"
description: "User's outreach building websites for New York / US small businesses that have no website; works only with registered businesses"
---

- building websites for New York (US) businesses that don't have a website and reaching out to them; only wants to work with registered businesses
