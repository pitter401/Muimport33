---
name: "domain-checker-bot"
description: "User's Telegram \"Domain checker\" bot on Cloudflare Workers that checks and monitors their domains for safety flags — read when they mention the domain checker, monitoring domains, or safe-browsing/phishing flags"
---

- Runs a Telegram "Domain checker" bot on Cloudflare Workers that checks a domain across Google Safe Browsing, HashDit (Trust Wallet engine), security DNS resolvers, and phishing blocklists — built to use no API keys
- Bot's /monitor command re-checks domains every 30 min and alerts on new flags; deployed at domainreport.jaredmack60.workers.dev
- Only wants checks that reflect a real domain block/ban/down — not content filters or soft "caution" signals
