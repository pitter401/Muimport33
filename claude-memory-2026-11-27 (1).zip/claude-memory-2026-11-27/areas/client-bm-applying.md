---
name: "client-bm-applying"
description: "User's service applying for/creating Meta Business Managers on behalf of their clients; concern about many BMs from one IP"
---

- applies for Meta Business Managers for their clients as part of their work; facing issues because doing many from one IP causes problems, looking for an API-based way
- volume is 100-150 client BM applications per day — manually not manageable
- client BM verification takes them 12-20 days (they pick "My business isn't listed" + document upload), while other agencies get same-day verification; delays are costing them clients
