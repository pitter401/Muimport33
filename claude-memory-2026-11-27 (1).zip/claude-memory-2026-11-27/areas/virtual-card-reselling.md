---
name: "virtual-card-reselling"
description: "User's planned Telegram bot business reselling virtual cards for USDT BEP20, cards sourced via a friend's offshore card provider"
---

- planning to sell virtual cards through a Telegram bot, taking payment in USDT BEP20
- cards to come from a friend who is a reseller of a card-issuing provider; that provider is offshore and does not require KYC
- says the provider issues the cards in the end user's name
- planned flow: cards added via admin panel; bot shows a payment QR ("scanner"); user submits the tx hash; balance then added to the card manually
- main target audience is Trust Wallet users (people who already hold USDT BEP20 in Trust Wallet); wants ad copy to lead with "you have crypto, spend it", not with Netflix
- plans to run Meta ads for the bot at about $20/day, using two ad creatives
