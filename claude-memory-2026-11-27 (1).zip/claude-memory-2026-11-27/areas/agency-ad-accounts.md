---
name: "agency-ad-accounts"
description: "User's planned \"agency\" website (agency. subdomain of their Cloudflare domain) selling Meta agency ad accounts + topup with a fee, plus optional ad-setup service — read when they bring up the agency site, ad-account selling, or topup fees"
---

- Planning an "agency" ad-account website on an agency. subdomain of their Cloudflare domain: customer buys a Meta agency ad account (~$15), then tops it up (min ~$50) with a ~5–6% topup fee added, pays in USDT (BEP20); optional paid ad-setup service (landing page included) handled via their Telegram
- Wants it built as a separate project from the BM rental ([[bm-access-rental]]); details (prices, fee %, separate worker vs same) still being decided
- (2026-10-11) says the work to pursue is the ad agency business only, not BM rental ([[bm-access-rental]]); wants to take customer payments for it through a legit payment gateway or PhonePe/BharatPe, and is working out how to handle tax on it
- company name: Adsbhai Agency (adsbhai.com); account price now "starts at $20" (not $15/$17); top-up fee 3%
- differentiators to stress in ads: dedicated support, 3% top-up fee, replacement if account gets banned, no spending limit, 1-on-1 call available
- standing rule for Adsbhai ad reels: every reel must stay under 30 seconds; does not give account access before payment
- ad video workflow: Claude writes the script (ElevenLabs-ready, with reaction tags; male/female for conversation ads), he makes the voice in ElevenLabs and sends the audio, Claude builds the video on that audio
- runs ~20–30 BMs with ~100–150 ad accounts, spread across separate Facebook accounts each kept on its own IP (to avoid bans); clients run ads from their own BM; wants to manage/share accounts from the AdsBhai admin panel without logging into each FB account
- switches IP for each FB account login via Indian proxy + phone airplane-mode toggle; names ad accounts "AdsBhai Ad Account 1, 2, 3…"; never gives clients full access (so they can't add own card/top-up); clients without a BM get a Facebook invite into his BM for that one ad account; isn't always at a PC, so the manager runs account ops (main admin oversees sales/top-up earnings)
- sells all three kinds of ad accounts: from verified, in-review and unverified BMs (picks which type when sharing)
