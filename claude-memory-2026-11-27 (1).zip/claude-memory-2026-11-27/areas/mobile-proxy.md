---
name: "mobile-proxy"
description: "User's phone-based mobile proxy setup on iProxy.online, and their idea of a self-hosted iProxy-like system on their VPS"
---

- runs a mobile proxy from their phone using iProxy.online; finds it costly and the app keeps stopping in the background
- considering building their own iProxy-like full setup on their existing VPS, including a link that toggles airplane mode on the phone to rotate IP
