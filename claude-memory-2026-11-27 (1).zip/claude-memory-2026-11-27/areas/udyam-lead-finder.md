---
name: "udyam-lead-finder"
description: "User's Udyam Lead Finder Telegram bot on Contabo VPS — India Udyam MSME leads plus Brazil CNPJ leads, sold in-bot via NOWPayments"
---

- building a Telegram bot on Cloudflare Workers that takes Udyam numbers, pulls details from udyamregistration.gov.in, and finds/verifies the business's existing website — he upgrades those sites and sells them to the business owners
- wants the bot premium/multi-user in English so others can buy leads: balance top-up via NOWPayments USDT BEP20 inside the bot chat (no mini app), min deposit, price per lead and min quantity set via worker variables; uses 2Captcha for the captcha and Claude API for search
- moved the bot to his Contabo VPS (Puppeteer browser, separate folder alongside his existing site) since Udyam blocks automated requests; going with his iProxy mobile proxy (own Indian IP) for Udyam access
- leads get saved to the bot's database when stock is generated; buyers (max 5 per purchase) receive each lead as its own message — Udyam PDF + all details + website link together — not as a CSV
- wants website-finding to stay on Claude models (not third-party search APIs), just cheaper; keeps Claude search on so Gmail/Outlook-email businesses aren't missed
- extending the same bot to Brazil: CNPJ leads (all ATIVA companies), buyers choose India/Brazil; Brazil runs from the VPS IP without proxy. Also wants an admin toggle so India leads can be saved without a website
- Brazil leads go out details-only (no PDF) — he prints the Receita comprovante himself when needed; website-required toggle for both countries, default off, $5/lead each
