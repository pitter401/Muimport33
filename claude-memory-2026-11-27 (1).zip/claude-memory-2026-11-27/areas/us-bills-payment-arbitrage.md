---
name: "us-bills-payment-arbitrage"
description: "User's US business paying rent/utilities/tuition/school fees for customers via an agency's 30% off, reselling at 10% off (20% margin); FB ad funnel, $1000 budget"
---

- Runs a business across all US states paying customers' rent, utility bills, tuition and school fees on their behalf
- Gets 30% off these bills through a US agency's points/rewards system, passes 10% off to customers, keeps ~20% margin
- Now sets customer discount at 20% (one admin setting drives landing pages and invoices); wants no agency-discount setting anywhere — profit = customer payments received minus costs he records himself (agency payments, ads, other) via "Add a cost", paying the agency whenever he chooses; wants dashboard profit viewable for today/yesterday/7 days/all time
- Also offers discounted flights as an upsell to the same customers
- Customers must share their account login for the bill payment to be made
- Initial ad budget for this business is $1000, wants lowest-cost way to grow it
- Planned funnel: Facebook traffic campaign → landing page lead form (name/email/phone) → custom audience + lookalike retargeting; cannot message leads directly, so landing page submit redirects to WhatsApp/Telegram instead
- Wants the lead capture/admin system built into the landing page itself (not a separate bot) so leads can later be exported for Meta, and plans to use Cloudflare for the website
- Decided to build and run all 5 landing page design variants (not pick one) so he can A/B test them with Facebook ads and switch the live one from an admin panel based on performance
- Brand name for this business is USABooker; domain is usabooker.us (using the root domain directly, no subdomain)
- Has a private Telegram channel with ~1,400 subscribers where he posts proof (e.g. payment proofs) for this business
- Has a US bank account and wants to invoice customers from the admin panel so they pay into it
- Uses Resend for emails (invoices, auto email retargeting 3-4 times to leads who didn't order); wants SMS retargeting to US numbers later, said not to build it yet; added his Resend domain
- Wants to accept crypto (coins + wallet addresses added from admin) alongside bank transfer, with an extra ~5% discount for crypto payers on top of the normal discount; customer picks a coin and clicks "generate address" to see the address
FINAL WRITE
- Plans a referral offer: customers who invite others via their refer link get an extra 5% discount; reasons that repeat clients need no further acquisition spend
FINAL WRITE
- Business model: they pay the customer's bill first, and collect the customer's payment afterwards
- Ad plan: start with a Traffic campaign testing landing pages V1/V2/V3 (~$20/day each), then run a Leads campaign on the winner
- Unpaid-invoice policy: due date 4 days after invoice, final notice on day 5; says he will do a chargeback through his agency if the customer doesn't pay
FINAL WRITE
- Wants to ask customers for a photo ID as proof/trust before paying their bill first (pay-after model), via a WhatsApp Business quick reply
- Says on a $1000 bill, after giving the customer the discount and paying the agency, about $400 remains for him (~40% margin); notes many bills will be smaller (e.g. $300)
FINAL WRITE
- Wants a monthly "new month" email on the 1st or 2nd to all paid customers plus leads from the last 90 days (customers and non-converting leads alike), design previewed before sending
- Has an iPhone and can buy a US number; currently has no team to handle replies; plans to run WhatsApp click-to-message ads for a few days to test, after the Traffic campaign spent $150+ with almost no leads
FINAL WRITE
- USABooker's WhatsApp Business number (+1 450 232 9499) was banned in Oct 2026 ("can't use WhatsApp", in-app review unavailable); says he only replied to clients who messaged first from his Meta ads, no bulk messaging; appealed via WhatsApp's contact form
- Having trouble collecting payments from US clients; wants to register USABooker as a US business cheaply (not via Doola etc., too expensive), set up a US bank, and do Meta business verification under the USABooker name
- This US bill payment work was his peak in 2024; plans to (re)start it in 2027
