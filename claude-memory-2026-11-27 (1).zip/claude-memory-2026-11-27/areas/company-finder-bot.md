---
name: company-finder-bot
description: User's Telegram "Company finder" bot on Cloudflare Workers that pulls company details (India default: CIN, GSTIN; multi-country) by category — read when they mention it
aliases: [company finder bot, Company finder, CIN GST bot]
---

- runs a Telegram "Company finder" bot built entirely on a Cloudflare Worker: pick category + quantity, get company CIN, GSTIN, address, website in copy-friendly text; already-fetched companies must never repeat (KV per-category list)
- asked to remember: data that has already come must never come again
- only companies with website + CIN + GSTIN; wants full details incl. authorized/paid-up capital, company type, Udyam if possible
- OK paying ₹5–10 per company; search via cheap Claude model (Haiku 5.5, auto-fallback to Haiku 4.5), API key as env variable
- wants it to work for all countries (country chosen in settings, default India) with full details for every country, not just India; plus an "Any" category option
