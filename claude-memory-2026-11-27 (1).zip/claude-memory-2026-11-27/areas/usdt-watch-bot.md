---
name: "usdt-watch-bot"
description: "User's Telegram bot that monitors USDT BEP20 wallet addresses and notifies on incoming payments, fed by addresses from their other bot; set up on Cloudflare"
---

- Wants a Telegram bot that monitors USDT BEP20 addresses they give it (possibly 200+): whenever USDT BEP20 is received, it notifies how much came in and the total USDT balance of that address; BNB balance doesn't matter
- Has a second bot on which the wallet addresses actually arrive; wants every address that comes there to be added automatically to the monitor bot — on first add it should report the current USDT BEP20 balance, then keep monitoring
- Setting it up inside Cloudflare (asked for the full setup there: tokens, variables)
- For this project has only Cloudflare — no VPS, no domain, no wrangler; everything must live in a single worker.js set up from the Cloudflare dashboard
- The second bot is their own, it sends the addresses to them, and they have only its token (no code); its webhook URL is empty
- Wants NodeReal as the BSC RPC provider (free plan, "1 crore" quota)
- Needs setup explained very step-by-step: full list of variables, what goes in each and where to find it
- Bot must report only the USDT BEP20 balance — never other tokens on the address (asked to remember this)
- Also has 2–3 existing addresses of their own that should be monitored too
- Telegram notifications sometimes don't work for them, so wants an instant alert outside Telegram too (WhatsApp message or a phone call) with the address and balance whenever balance shows up
- For the extra alert: CallMeBot (WhatsApp) did not work for them; prefers a free option, so going with the ntfy app; WhatsApp Business Cloud API via their verified BM postponed for later
