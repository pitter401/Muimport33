---
name: "dev-portfolio-business"
description: "User's planned developer website business — premium animated portfolio site, builds exchanges/MLM/websites for foreign clients, $200–300 minimum"
---

- planning a business building websites for clients (any type — exchanges, MLM platforms, etc.), selling in countries where there's demand; developer-style site, not "agency"
- minimum charge $200–300 per website; wants a niche where $20–50 ad spend gets one client; business details to be worked out later
- wants a premium animated portfolio website (reference: dark "designer portfolio" style video) — "more premium than the reference"
- also builds any type of custom websites/apps; custom app pricing starts from $500
- wants the reference used only as inspiration, not copied; the "click a door → go inside and see that service's site" interaction is what he liked
- has no real past projects to show yet — site should include concept/ready designs that clients pick from, or choose a custom build
- wants the portfolio in 3D style but must not look AI-made (worried clients won't hire if it looks AI-built)
