---
name: "p2p-inr"
description: "User's platform P2P INR (buy USDT, scan-and-pay any UPI QR with USDT), its social ad, and the creator/influencer partnership funnel (Meta ad → landing → Telegram bot → admin approval → per-creator group) — read when the user mentions P2P INR, scan & pay, USDT, \"my platform\", the HeyGen/ElevenLabs ad, or the influencer/creator bot."
---

- Runs P2P INR, their own platform where users buy USDT and pay any UPI QR directly with USDT through a scan-and-pay flow
- The scan & pay system UI was built with Claude in a separate session (not found among non-project chats)
- Making a 9:16 social ad for it: Hinglish ElevenLabs voiceover (~23.5 sec) + HeyGen avatar video with app screenshots attached

Creator / influencer partnership funnel
- Building a creator lead-gen flow for P2P INR: Meta ad → landing page on their Cloudflare domain (Meta Pixel + Conversions API, Cloudflare Worker + D1) → Telegram bot hosted on their VPS asks name / platform / audience / content type / rate → admin approves → only then the applicant gets the group link; every influencer gets their own separate Telegram group
- Chose "pool" mode (pre-created blank groups that the bot renames) instead of auto-creating groups; group name format: "<applicant name> P2pinr Creator Leads"
- Decided the creator partnership is revenue-share ONLY (creators get a % of the company's profit from users they bring) — no upfront payment offered
- Plans to pre-create 30–40 groups per account across multiple Telegram accounts so 100–200 pool groups are ready
- Wants every setting (Meta API token, pixel ID, etc.) controlled through environment variables
- Has a VPS, and a domain already added on Cloudflare
- Their existing business site already runs on that same VPS (they don't know what stack it's built in) — anything new deployed there must not disturb it
- Funnel is live: landing page at creators.nikhilagency.online (Cloudflare Worker "p2pinr-creators" + D1; needed its own specific route because the old nikhilagency worker holds a wildcard route on that domain), Telegram bot @P2pinrLeadsbot running under pm2 on their VPS, admin/approver Telegram account @p2pinradmin; pool groups to be bulk-created from spare Telegram accounts

Merchant funnel (live)
- Second "merchant" funnel on the same bot/Worker/pool setup to recruit existing P2P merchants from other platforms — merchant landing at creators.nikhilagency.online/merchants, admin /funnel switch in the bot; the live creator campaign must not be disturbed
- Merchant pitch: on P2P INR a merchant buys USDT at ~₹100.60 and sells at ~₹101.40 (₹0.80 margin) vs buy ~₹104 / sell ~₹104.20 (₹0.20) on other P2P platforms
- Does not want to name competitor platforms directly in marketing ("poke nahi karna") — uses altered spellings like "Biaanance", "Byybit", "OKKX", "KuuCoin" instead

Revenue model & user acquisition
- Platform earns ~1.5–2% margin on volume (built into the rate, not shown to users separately), plus a small-order fee on selling / scan & pay (reduced to $0.05, previously $0.10) and a $0.5 withdrawal fee
- Running a Meta user-signup campaign for P2P INR (Hinglish UGC scan & pay video), starting at ~$33/day ($1,000) for the first month (earlier plan was $25/day then $50/day); from month 2 plans to put company profit (after recovering ad spend) back into ads — the $1,000 plus ~30% more — so marketing keeps growing; optimizing for CompleteRegistration sent via browser + CAPI
- Platform sends Meta a Purchase event only for each user's first trade (not every trade); also now sends an event when a user starts an order but doesn't pay
- P2P INR admin panel can export data on which users bought or sold on the platform
