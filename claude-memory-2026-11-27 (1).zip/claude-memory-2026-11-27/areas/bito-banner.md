---
name: "bito-banner"
description: "User's other existing site \"Bito Banner\" with a base of signed-up crypto-aware users — read when they mention it or want to reuse its audience for ads"
---

- has another existing site of theirs, "Bito Banner", where users have signed up; those users know crypto
- considering using that signup audience as a lookalike seed for the [[airdrop-token]] Facebook ads
