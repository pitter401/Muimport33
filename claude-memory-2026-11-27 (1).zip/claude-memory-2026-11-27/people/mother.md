---
name: "mother"
description: "User's mother (mummy), Mamani Adhikary"
---

- user's mother is Mamani Adhikary
