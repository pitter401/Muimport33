---
name: "father"
description: "User's father (papa) — runs a family business making artificial jewellery"
---

- papa runs a business making artificial jewellery (user calls it "humara papa ka business")
- family owns the factory making copper-based gold-colour imitation jewellery; papa sells the maal wholesale in the local market
