---
name: "preferences"
description: "How the user wants Claude to work on their projects (previews, setup)"
---

- Finds local dev setup (installing PHP/Node, terminal commands) too complicated; wants Claude to run the code in its own workspace and send live screenshots instead, like it did for the P2P Miner project
- Wants actual rendered screenshots of pages, not just artifact links
- Always send design previews/screenshots in mobile view only — their users come from mobile
- When redesigning pages, never remove anything the current site shows — redesign the UI but keep every existing field/section; some scrolling is acceptable
- Design quality bar: the site should look like 10-15 lakh was spent on it (premium, high-end feel); redesigned cards should stay within the current card's size
- When a feature/section is no longer used, delete its code outright (frontend, backend, admin) instead of hiding it — the codebase shouldn't keep unused stuff; they'll ask to rebuild it if needed later
- Xminex full frontend redesign (2026-10-21) follows the "Machine Room" direction (3D matte-black mining machines with green light bar, calm exchange-app-style layout), replacing the earlier "mining rig console" theme; machines must be animated whenever a bot is mining
- Never use colour emoji (Android-style 🚀 🧾 💡 ⚠️ etc.) anywhere in the website UI — use proper icons instead
- Reply in Hinglish written in Roman (Latin) script — can't follow replies written in Devanagari Hindi
- Keep ONE delete script, TO-DELETE.bat at the Xminex project root (C:\Users\Akash\Documents\Xmx\xminex v9 latest): with every update, append any file/folder that is no longer needed to it (dated heading), so a single run deletes everything — no separate lists like _TO_DELETE.txt or DELETE-LATER
