---
name: "agency-ad-accounts"
description: "Project-scoped notes on the user's USA Meta agency ad account selling — read with the account-level agency-ad-accounts file when they discuss its ads or terms"
---

- sells USA Meta agency ad accounts; does not give account access before payment (wants no "access first, pay later" claims in ads)
- USA agency account price changed to $20 (previously $15)
- wants to make UGC-style ad videos in-house with AI (model photo + script, cloned voice) to save on paying for UGC content
