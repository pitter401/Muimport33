---
name: "ugc-ai-videos"
description: "User's plan to make their own UGC-style ad videos with AI (model photo + script, voice cloning) instead of paying for UGC content"
---

- wants a proper reusable setup to make UGC-style ad videos himself — give a model's photo + script and get a realistic video like his existing UGC ads — to save money on UGC content
