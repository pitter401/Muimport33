---
name: "preferences"
description: "How the user wants Claude to work on ad creatives / reels in this project — read before making any video, animation or creative"
---

- Every new ad creative / reel (any topic, animation or any other format) must look and be edited in a different style from the previous videos — never the same look, animation style or editing repeated
- Nothing should repeat from the previous video — including characters: every video gets different characters (e.g. not the same Vijay/Sameer Indian characters again); this also applies inside any setup prompt Claude writes
- Every ad script must be strong and well-crafted
- Make only ONE version of each video — no duplicate versions with different music. If told to use the Love Story track, use it; if told to add background music on Claude's own judgement, pick it
- When sending a script in Hindi (Devanagari), always also send a Hinglish (Roman-script) version alongside it — they can't read Hindi script well
- Background music and sound effects must be newly made / different in every video — never reuse the same SFX; and the background music must be clearly audible (not buried under the voice)
- Dislikes Claude's code-synthesized background music ("tui tui", cheap, doesn't fit the ad) — background music must sound like a real produced track that matches the ad's mood
- Also dislikes beepy "tui tui" UI sound effects — SFX must not be tonal blips
- For every script — AdsBhai's own ads or any client's ad — use the agents: an expert scripter agent (creative marketing, 20+ years) writes the script options (latest: 3), all are sent to him, and an expert agent picks one and explains why; never send scripts written/picked by me alone. Each script comes in 2 versions: Roman Hinglish and the ElevenLabs emotion-tag version. Hook always inside the first 3 seconds
