---
name: "3d-movie-system"
description: "User's planned professional 3D movie-making setup (horror/suspense full movies) with assets in their \"3d model\" PC folder — read when making 3D movies, teasers or reels"
---

- Building a professional 3D movie system to make full movies (suspense, horror) and cartoons; keeps all downloaded assets in the "3d model" folder on their PC
- Plans to make a ~10-minute horror movie next, reviewing script together with Claude
- Finished reels go in "3d model\Reels\<series>\Part N.mp4" on their PC
