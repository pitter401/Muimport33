---
name: "client-video-ads"
description: "User's client ad videos (Alpha Trader, NSE DMax Team, Dragon Tiger client) — stock-footage and premium style; read when he brings a client video/ad request"
---

- may make stock-footage style promo videos (like trading/Telegram-channel promo reels) for his clients; wanted free stock footage sources + tools set up for this
- client "Alpha Trader" (Trading Alpha) — wants Telegram channel joins; landing page alphatrader.adsbhai.com; ads to be made in user's premium style using the client's own screenshots/videos, male voice, max 35 s, urgency-style script like the client's reference video
- client "NSE DMax Team" — colour prediction (Wingo) VIP Telegram channel + panel; landing page dmax.adsbhai.com; wants ads in the landing page's theme, premium quality
- for client ad scripts: wants Hindi/Hinglish ElevenLabs script with emotion tags plus a normal Roman Hinglish version the client can read; hook within first 1–3 s
- new client (Nov 2026) — "Dragon Tiger Baazigar" Telegram channel (similar to NSE DMax); landing page baazigar.adsbhai.com; sessions run 3–4 times a day, not only at night; wants 2 video versions — one with Alpha Trader's music, one with a dark premium track Claude picks
- 18+ / responsible-play disclaimer is NOT spoken in the script — it gets added as on-screen text at the end of the video
- scripts must be punchy direct ad lines, not story/narrative style
