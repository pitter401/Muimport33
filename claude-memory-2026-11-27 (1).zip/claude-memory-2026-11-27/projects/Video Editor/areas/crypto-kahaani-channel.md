---
name: "crypto-kahaani-channel"
description: "User's own new Instagram/YouTube channel \"Crypto Kahaani\" (@cryptokahaani) — choose-your-ending crypto thriller reels to build a crypto audience; read when making its series or channel assets"
---

- the 7 MINUTE series videos will be posted by his nephew (bhanja) on the nephew's channel; he is making a separate channel of his own
- his own channel: choose-your-ending reels on a crypto topic, to build a crypto-related audience and later move that audience to his own channel
- going with channel name Crypto Kahaani (@cryptokahaani, Instagram page under that username)
- wants to make series for many channels in one chat — he names the channel and Claude should remember everything and keep making the next series
- Related: [[interactive-story-reels]]
- will post the Crypto Kahaani videos on YouTube, Facebook and Instagram (all three)
- wants the channel tag added inside every video, because many fake channels will appear
- wants a reel cover pic sent with every video, and the cover added for 0.5 s at the very end of each video (YouTube Shorts cover can't be set manually, it's taken from the video)
