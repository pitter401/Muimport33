---
name: retargeting-ads-bhai
description: "Retargeting Ads Bhai" — user's weekly AdsBhai retargeting reel-script system (Agency / Premium / Funnel ad sets); read when he says "Retargeting Ads Bhai — is hafte ke scripts"
aliases: [Retargeting Ads Bhai, AdsBhai retargeting, RT scripts, AGENCY RT, PREMIUM RT, FUNNEL RT]
---

- asked to remember this method under the name "Retargeting Ads Bhai"; no scripts until he says "Retargeting Ads Bhai — is hafte ke scripts" — then he gives audio and scripts are built to fit that audio
- business: AdsBhai (adsbhai.com) — Meta agency ad accounts + landing page/funnel setup; customer chats with our agent on Telegram; payment USDT or UPI
- retargeting = ads shown only to people who viewed our page but didn't message; they already know what we sell — don't explain who we are; bring them back: reminder + clear one doubt + this week's offer + "Telegram par message karo"

## Three ad sets — separate script for each, every time
- 1) AGENCY (normal ad account) — offer: "Is hafte $20 per account (normal $23) — Sunday tak"; points (only these true ones): agency ad account, live in 1 hour, free replacement if issue, USDT/UPI, one agent on Telegram does the whole setup; why free replacement: we earn from top-up fee, so we want your ads to keep running
- 2) PREMIUM AGENCY (strong profile accounts, $45) — offer: "Price same, pehla top-up 0% fee (max $200) — Sunday tak"; never show price lower; points: aged profiles with strong history, handle higher daily spend, 30 minute delivery, unlimited free replacements, dedicated agent; tone premium, for serious buyers ($100+/day spenders)
- 3) FUNNEL (landing page + funnel setup, $50/month) — offer: "Pehla mahina $40 (normal $50) — Sunday tak"; points: landing page + qualifying form, every lead to your sales team on Telegram, admin app + agent app, Meta Conversions API tracking — setup in 2–3 days

## Script structure (reel up to 30 s, fit to his audio length/beat; shorter audio = shorter reel)
- Hook (0–3 s): remind them / catch their doubt ("Abhi bhi soch rahe ho?", "Account band hone ka darr?")
- Body: clear only 1 doubt + 2–3 points
- Offer line: this week's offer + "Sunday tak"
- CTA: "adsbhai.com se order karo" (decided — retargeting too; ad button goes to the website, not straight to Telegram)
- retargeting ads are 9:16 only (Instagram/Facebook); wants them in the SaaS-promo visual style with Hindi voice
- voiceover language: Hindi + English mixed (the way younger people talk) — but never say "bro"; script must name AdsBhai
- only wants the voiceover script when asked for "script" — no primary text/headline extras unless asked
- per scene: on-screen text (short, big font), visual idea, which part of the audio it lands on
- also give: Primary text (FB/IG caption, 3–5 lines), Headline (max 40 chars), 1 alternative hook

## Weekly angle — different every week, never repeat; remember last week's angle
- angle pool: reminder / doubt-buster (ban fear → free replacement) / speed (1 hour / 30 min live) / process demo (form → Telegram → account live) / comparison (normal vs premium, or building landing page yourself vs us) / "kitna simple hai" / customer's question → answer

## Rules (strict)
- only truth: never "ban nahi hoga", "100% guarantee", fake reviews, fake numbers, fake customer names
- never write our BM's name or account type
- yes to any niche — but never name a niche with an "ye allowed hai" claim
- language: Roman Hinglish, simple, Telegram-chat style; max 2 emojis
- offer deadline always "Sunday tak" — no fake countdown

## Output format when asked
- "AGENCY RT", "PREMIUM RT", "FUNNEL RT" — each separately: Script (scene-by-scene with audio timing) + Primary text + Headline + Alt hook; last line: what this week's angle was (so next week differs)

## Angle log
- (none yet)
- the offer must be in the hook itself (first 2–3 s) — viewers swipe before a late offer; Agency RT hook phrasing: "AdsBhai ka verified agency ad account — is hafte ke liye sirf $20" (he changed "shared" to "verified agency")
- scripts must carry ElevenLabs audio tags ([excited], [short pause] etc.)
- decides on Premium RT and Funnel RT only after he likes the Agency RT reel
- generic rule: every video gets its own different style — Premium RT and Funnel RT reels stay SaaS style but each with its own distinct styling, not a copy of the Agency RT look
