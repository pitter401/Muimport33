---
name: "interactive-story-reels"
description: "User's planned \"choose your ending\" suspense story reel series (4-5 parts, audience picks next part via comments) — read when making story reels for it"
---

- Planning a 4-5 part "choose your ending" suspense story reel series in the viral Claude-made animation style; each part ends with a question whose winning answer is predictable (the one audience will argue about), next part built on it
- Wants very high suspense; switched topic from murder to hacking thriller
- Comment prompt should ask viewers to write the actual choice phrase, not "A or B"
- Sends ElevenLabs audio after receiving the script
- Whole series keeps one single video style across all parts (it's one series); wants suspense background music, will supply the track himself
- can't adjust ElevenLabs speed himself — Claude should speed up/tighten the audio itself so each part fits the time
- sends next part's audio and wants the following part's script along with each video
- The 5 final "7 MINUTE" videos will be posted by his nephew (bhanja) on the nephew's channel
- Plans his own separate choose-your-ending channel aimed at a crypto audience, to build that audience and later move it to his own channels
- Will make series for many channels in one chat — he names the channel and Claude should remember everything about it and keep making its next series
