---
name: adsbhai-client-pro
description: "AdsBhai Client Pro" — log of AdsBhai client delivery videos (Sunny Chauhan …); read when he asks how many clients or for the weekly YouTube compilation
aliases: [AdsBhai Client Pro, client pro, client delivery videos]
---

- asked to remember: save every AdsBhai client delivery video/image under "AdsBhai Client Pro" with the client's name; tell him the client count when asked
- plan: when 5–10 clients are logged, combine their data into one premium YouTube video; post weekly
- client name stays visible in these videos; payment details etc. must be blurred
- in captions/posts, tag @adsbhaibot (not @Adsbhaisupport / @Adsbhai)
- captions always in English
- use the full screenshots in these videos and images — never crop them (only blur payment details etc.)
- client numbering starts at #142 (not 01)
- client name and the ad account name (e.g. "adsbhai x Sunny") must stay visible so clients see it's theirs
- delivery videos: premium SaaS type but different styling each time, not a copy of the brand promo
- client #142: Sunny Chauhan — 22 Nov 2026, sold aged Facebook profile + Premium agency ad account together for $50, delivered same day
- Log also kept in project doc claude/AdsBhai_Client_Pro.md
