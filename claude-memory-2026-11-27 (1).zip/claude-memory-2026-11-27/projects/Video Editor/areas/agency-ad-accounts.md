---
name: "agency-ad-accounts"
description: "Project-scoped notes on the user's AdsBhai Agency (USA Meta agency ad accounts) ad videos — read with the account-level agency-ad-accounts file when making its ads"
---

- company name: Adsbhai Agency (adsbhai.com)
- USA agency ad account price: starts at $20 (not $17)
- selling points: dedicated support, top-up fee only 3%, replacement if account gets banned, no spending limit, 1-on-1 call available
- runs AdsBhai ads as 4 ads: normal, "why buy from us", male–female conversation, retargeting
- strict rule: all AdsBhai reels must be under 30 seconds
- workflow: Claude writes the scripts (ElevenLabs-ready, with reaction tags), user makes the voice in ElevenLabs and sends audio, Claude builds the video on that audio
