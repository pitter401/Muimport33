---
name: "meta-business-manager"
description: "Project copy — user's Meta BM / Page access structure for running BM ads (account-level /areas/meta-business-manager.md has the BM list); read when checkpoints, page unpublish, or ad-account roles come up"
---

- The Facebook Page used for their BM10 ads is owned by a friend; the friend added it to the BM and never gave the user direct Page control — the user is only a BM Admin (BM has 4–5 owners/admins). [[bm-access-rental]]
- When the user's own FB account (the one they publish ads from) hits a checkpoint, that Page gets unpublished and the friend has to log in and republish it before ads run again.
- Runs that FB account inside a GoLogin browser profile; a checkpoint happened after they changed the profile's fingerprint and refreshed.
- Had the friend change their role (user no longer BM Admin / no Page full control) so their own checkpoints stop unpublishing the Page — done 10 Oct 2026.
- Manages multiple Facebook accounts in GoLogin; the ads FB account is registered in a different country than India while the BM is US-based; wants a 5G/mobile proxy with no data cap for it.
