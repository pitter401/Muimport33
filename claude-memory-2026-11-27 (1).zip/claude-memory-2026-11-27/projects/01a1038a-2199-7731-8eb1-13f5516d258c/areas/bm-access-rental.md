---
name: "bm-access-rental"
description: "Project copy — user's mexacobm.online BM access service; current product/flow decisions (see account-level /areas/bm-access-rental.md for history)"
---

- (2026-10-10) Decided and deployed: single product BM10 (10 ad accounts + 2,000 WhatsApp API messages) at $17 one-time, checkout fully on the website (QR / Trust Wallet $17, direct address + surcharge), with an "access in 1 hour or refund" guarantee; dropped the WhatsApp-lead-first flow because it brought leads but no conversions
- (2026-10-10) Price is now $18 (not $17). Plans a separate /upi landing link for retargeting ads only: same landing with a "pay with UPI as well" highlight, pay page with just two methods — UPI at $20 (₹ amount, opens UPI app with amount filled) and USDT direct address at $18 flat; no QR / Trust Wallet on that link. Will ask later about retarget campaign setup and when to switch to Purchase optimization
- (2026-10-11) Plans to also run WhatsApp message ads for BM10 as a separate variant at mexacobm.online/whatsapp (retarget at /whatsapp/upi), with its own /whatsapp/admin where he creates pay links for WhatsApp converts and marks paid — same system as his agency site; website checkout flow on mexacobm.online stays as is
