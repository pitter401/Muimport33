---
name: "agency-ad-accounts"
description: "User's agency ad-account site (Meta agency ad accounts + USDT topup) — now launching Meta ads for it alongside BM3; same lead → WhatsApp → admin pay-link → Purchase CAPI funnel"
---

- Launching Meta ads for the agency ad-account site now, in parallel with the BM3 campaign; same funnel as BM3 (lead form → WhatsApp/Telegram → admin pay link → Purchase fired manually from admin)
- Has one 9:16 reel creative for the agency ad
- Total service list is 4: Agency ad account ($15), BM3 ($30), ad-account top-up at 4% fee, and landing page + campaign setup
- Has shifted all customer contact for these funnels to WhatsApp Business (greeting/away messages set there)
