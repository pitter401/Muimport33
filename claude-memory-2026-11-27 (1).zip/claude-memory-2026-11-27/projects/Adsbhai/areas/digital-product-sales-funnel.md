---
name: "digital-product-sales-funnel"
description: "AdFlow / AdsBhai agency sales system — team roles (who is manager / agents) and how the owner counts his income"
---

- user (Akash) is himself the manager in the AdFlow app; the manager's earnings count as his own income
- agents on the team: Suvo, Babai, Vaskar
- agent incentives are his separate account, not to be taken off net profit
- wants admin-login actions (sales, top-ups, replacements) recorded the same way as the manager login
- before any adflow update is delivered: test thoroughly that one sale = one record and one Meta event, never 2–3
