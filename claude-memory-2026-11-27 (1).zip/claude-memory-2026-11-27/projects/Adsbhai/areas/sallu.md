---
name: "sallu"
description: "Sallu / Money Hub client funnel (sallu.adsbhai.com) — copy of client's digital-home.icu/sallu page, WhatsApp + Telegram join, admin rules"
---

- client funnel for client "sallu" on sallu.adsbhai.com (pointed to the VPS); part of [[adsbhai]] client funnel builds
- landing page must be an exact copy of the client's page digital-home.icu/sallu — same design, placement, theme, colours, no-scroll single screen, same photos downloaded (swipeable screenshots) — only a premium touch added
- admin panel has a WhatsApp community/group link alongside the Telegram function; both ON → both buttons, one ON → one button; Meta Subscribe on join
- admin panel for sallu should open without a password
- AdsBhai popup always ON by default, only for visitors from Facebook/Instagram ads, with no admin option for it
- wants the pre-deploy check commands (e.g. which ports are free) sent before deploying
- client runs ads from many ad accounts (8, 10, 15, 20) and wants multiple Meta pixels on the one landing page, with a toggle between all-pixels and pixel-per-ad tracking
- client wants the admin at a secret link (KeishadkK39rndj30ksn38J) instead of /admin
