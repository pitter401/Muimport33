---
name: "dmax"
description: "NSE DMax Team / Wingo GodFather client funnel (dmax.adsbhai.com) — live build, deploy details, live WinGo results API, where source is kept"
---

- second AdsBhai client: NSE DMax Team / Wingo GodFather (khelv.com colour prediction), goal Telegram join requests; live at dmax.adsbhai.com
- deployed on Contabo VPS: /var/www/dmax, PM2 "dmax", port 3003, SSL via certbot; DNS A record "dmax" added on Spaceship → 13.140.208.222; zips uploaded to /root, installed with: cd /root && rm -rf /root/dmax && unzip -o dmax-vN.zip && bash /root/dmax/install.sh
- installed v3 on the VPS (21 Nov 2026) and fixed the results API URL by hand in admin; dmax-v4.zip (correct default URL + URL auto-fix) is the latest build, not yet installed — saved as the current setup to reuse
- wanted the signals box to show live WinGo 1-min history with the FULL period number, updating every minute like the gaming site; working API: https://draw.ar-lottery01.com/WinGo/WinGo_1M/GetHistoryIssuePage.json (the slash after WinGo_1M is required — missing slash gave 404)
- approved design: Design B "Vibrant Green" (green + orange on dark navy), accuracy always 97%, English text, strong urgency, client logo (khelv.com / NSE DMAX TEAM) in nav + hero; AdsBhai popup at top under the nav
- "seats per day" (60) is display-only urgency — no limit on invite links/joins
- still to do on his side: fill Meta Pixel ID + CAPI token + test event code in admin and test Subscribe with a different Telegram account
- full source kept in project doc dmax/dmax-v4-source.txt (built on Alpha Trader v4 base; logo image files not in the text dump — original logo upload is the round khelv.com image)
