---
name: "baazigar"
description: "Dragon Tiger Baazigar client funnel (baazigar.adsbhai.com) — live v1 build, deploy details, session settings, where source is kept"
---

- fourth AdsBhai client: "Dragon Tiger Baazigar" Telegram channel (Dragon Tiger card game, ~14.6K subscribers); goal Telegram join requests; part of [[adsbhai-project]] client builds
- chose design Option A "Royal Red Arena" (black/red/gold, big logo with animation around it)
- live at baazigar.adsbhai.com — DNS A record "baazigar" on Spaceship → 13.140.208.222; installed v1 on 26 Nov 2026: /var/www/baazigar, PM2 "baazigar", port 3006, SSL via certbot; zips go to /root, install: cd /root && rm -rf /root/baazigar && unzip -o baazigar-vN.zip && bash /root/baazigar/install.sh
- client runs 3–4 sessions a day from morning to night; for now he set one long session window in admin instead of an update (multi-session times would need a v2)
- source: built on alphatrader v10 + popup update; full v1 source saved in project doc baazigar/baazigar-v1-source.txt (logo images not in text; also on VPS /var/www/baazigar and in baazigar-v1.zip)
