---
name: "alphatrader"
description: "Alpha Trader / Trader Alpha client funnel (alphatrader.adsbhai.com) — live v6 build, admin features, deploy steps, source location, client's Meta ad setup"
---

- first AdsBhai client funnel; client's Telegram channel is "Trader Alpha" (logo: wolves, "Where traders become alphas"), private channel, ~76K+ subscribers; channel ID -1002113846851
- live at https://alphatrader.adsbhai.com — current version v4 (versioned zips alphatrader-v1..v4); user deploys by uploading zip to /root and running: cd /root && rm -rf /root/alphatrader && unzip -o alphatrader-vN.zip && bash /root/alphatrader/install.sh (keeps backend/.env password and backend/data settings)
- VPS: /var/www/alphatrader, PM2 name "alphatrader", port 3002 (127.0.0.1), Nginx site "alphatrader", SSL via certbot (Let's Encrypt), DNS A record on Spaceship → 13.140.208.222
- stack: React (Vite) frontend with 2 entries — index.html (landing, Black & Gold design from approved PDF, Cormorant Garamond + Manrope self-hosted) and safe.html (educational binary-trading safe site + Privacy/Terms/Disclaimer/Contact) — plus Node/Express backend (backend/server.js); settings in backend/data/config.json, join data in backend/data/joins.jsonl
- admin panel (/admin) tabs: Telegram (bot token, channel ID, notification chat ID, notify on link/join, Test Bot, Set Webhook, Send Test Message), Meta CAPI (pixel, token, test code, test event), Site Control (site ON/OFF, Safe Page Mode, AdsBhai popup ON/OFF + ad-traffic-only + timing, viewer range, channel name, member count), Data (stats, Meta Audience CSV + full CSV export), Blocker, Safe Page, Logs, Danger (type DELETE)
- tracking: dynamic per-visitor join-request invite links (7-day expiry); ViewContent on page load; Subscribe CAPI only on actual Telegram chat_join_request (with IP/UA/fbc/fbp/external_id/fn/ln), deduped; webhook protected by secret token
- all pages noindex; AdsBhai popup 3s delay / 5s show, ad traffic only, dofollow link with utm_source; hero shows Trader Alpha logo
- full source saved in the claude.ai Project doc "alphatrader/alphatrader-vN-source.txt" (all files, split at "===== FILE: path =====" markers; logo/favicon binaries only on VPS /var/www/alphatrader/frontend/src/assets/) and on the VPS; user also keeps the zips
- v6 deployed 22 Nov 2026 (stealth 404 APIs for blocked visitors, Test ViewContent/Subscribe buttons)
- user is setting up the client's Meta ads (client budget $150 total): Subscribers custom audience excluded; only one creative, so testing Broad vs Interest campaigns
