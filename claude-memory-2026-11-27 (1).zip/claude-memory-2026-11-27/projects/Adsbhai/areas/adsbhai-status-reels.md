---
name: "adsbhai-status-reels"
description: "How to make the owner's AdsBhai personal-sales status reel videos (WhatsApp/Instagram status) — read when he asks for \"AdsBhai ki aaj/kal ki sales ki video/reel\""
---

- asked to remember: when he says he wants an AdsBhai personal sales reel/status video, make it in the daily-reel style (approved 4 styles: A Ambient, B Cinema, C Story, D Widescreen — full 16:9 video, never cropped to 9:16)
- each new video should use a different style from the last one (rotate styles)
- before making it, ask him: today's or yesterday's sales data — he will type the numbers or send a screenshot of the admin Home (e.g. Yesterday); also ask for the background video (he sends a 16:9 video with song, ~43s)
- name shown = "AdsBhai Admin"; badge/logo = his real AdsBhai logo (purple)
- wants a loading animation with sound effects at the start so the flow feels right
- loved the first one (27 Nov 2026, Style C, 1080x1920, under 60s for WhatsApp status)
- feedback: the long intro (~8–9s of welcome/data animations with sound effects) felt too long — better to start the background video + its song right away (blurred reflection behind) while the welcome/data shows on top, then data moves away and the video flow continues
- plans an automatic version in v168: admin uploads a stock of videos, system renders one status video daily after 1 AM when server load is low, uses yesterday's sales data from the DB, makes light + dark versions, shows videos left in stock
- intro text (greeting/data) must never sit on top of the sharp video — blur the whole screen during the intro, then text fades and blur clears together to reveal the video
