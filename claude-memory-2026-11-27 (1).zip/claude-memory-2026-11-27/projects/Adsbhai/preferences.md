---
name: "preferences"
description: "How the user wants VPS deploy/update commands and client delivery posts delivered in this project"
---

- VPS commands: give the whole thing as one combined block to paste at once, not separate commands to run one by one
- Client delivery posts: use the same format as earlier channel posts ("✅ Delivered — Client #N", client name "got:", 🔷 bullets, then the call to action) and write separate versions for the Telegram channel, WhatsApp and Story
- Client posts are numbered in sequence: Client #147 was the last before 24 Nov 2026; Zennnnn (Premium, $55 + $200 top-ups) is Client #148; Premium account $193.31 daily limit (24 Nov 2026) is Client #149. Each new client post takes the next number (+1)
- Channel posts (Telegram / WhatsApp / Story) are written in English
- Client proof images (for channel posts / story): always make both 9:16 and 16:9, in 4K (2160×3840 and 3840×2160), AdsBhai dark-purple look
- Proof images: use the screenshots he sends uncropped (Meta screenshots + client chat screenshots); never crop them
- Proof images: do NOT blur business names, addresses etc. (ours or the client's) — blur only IDs (BM / portfolio ID, ad account ID, Tax ID, card number, wallet address, profile photos); keep the partner-assigned text visible
- Proof images: phone numbers are only half blurred (e.g. 282928282 → only half the digits blurred), never fully
- Proof images: highlight the key facts (daily limit, verified date, partner assigned, payment) in a premium way — glass-style zoom lens on the spot, not phone-marker style; must look real, not fake
- Proof images must look sharp/4K (zoomed parts AI-upscaled)
- WhatsApp versions of posts must carry our WhatsApp number (+1 646 270 7080, wa.me/16462707080) as the contact, not the Telegram bot
- Posts always name the client the way they appear in the chat ("Zennnnn got:", "Apex got:"), never "Our new client got:". Client #149 = Apex
- Any emojis inside images/graphics Claude makes (OG images etc.) must be iPhone/Apple style, never Android style
- adflow server updates are installed by uploading the zip in the adflow admin app (More → System → update the server from a zip), not with VPS commands — don't give VPS update commands for adflow
- Never leave background processes (e.g. test mock servers) running after testing — stop them before delivering; he worries it eats his credits
- Before answering setup / how-to questions, check the old chats first for what he already did or sent (e.g. Meta token permissions already set) — don't repeat steps he has already done
- adflow updates: test properly before delivering (use an experienced logic/QA agent); one sale must create exactly one record and one Meta event, never duplicates
- adflow updates: always deliver the FULL system zip (he saves the code for the future), but leave out the reel seed video (adflow/seed/) — no small patch-only zips
