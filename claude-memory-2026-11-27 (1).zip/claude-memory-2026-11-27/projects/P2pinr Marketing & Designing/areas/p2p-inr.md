---
name: "p2p-inr"
description: "P2PINR (p2pinr.in) organic social marketing — Telegram official channel, Instagram, Facebook posts and creatives"
---

- Runs marketing/creatives for their exchange website p2pinr.in in this project — organic posts for Telegram, Instagram and Facebook, not Meta ads
- P2PINR's Telegram is an official channel: all post copy and creatives must be in English (no Hindi/Hinglish)
- Creatives must follow the website's own branding (logo, colors, style from p2pinr.in)
