---
name: "preferences"
description: "How the user wants Claude to work in the P2PINR marketing project — creative delivery format"
---

- Send creatives as image files directly in chat so they can download them straight away
