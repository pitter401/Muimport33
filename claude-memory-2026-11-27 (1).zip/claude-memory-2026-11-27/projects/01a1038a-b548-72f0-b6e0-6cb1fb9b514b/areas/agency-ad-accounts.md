---
name: "agency-ad-accounts"
description: "User's agency.mexacobm.online business selling USA-verified Meta agency ad accounts (not BMs); current Meta campaign direction"
---

- sells USA-verified Meta Agency Ad Accounts via agency.mexacobm.online — NOT Business Managers (BMs); user corrects this when copy says "BM"
- decided to move the whole funnel to WhatsApp-first: ads (reel video, click-to-WhatsApp) → client messages on WhatsApp → access → pay link; the website lead/order form is removed and landing-page CTAs open WhatsApp (replaces the earlier Leads-objective + order-form approach)
- pay page methods now: USDT Direct Address + INR via their own fixed-amount payment links (has ~20-25 such links); dropped Trust Wallet, USDT QR and UPI; INR rate and fee are set by them
- going with a cloud calling number (Exotel/MyOperator-type) for agents' calls instead of personal numbers
- made a dedicated WhatsApp number for the agency + BM ads; reply-only — will not message users first (on the WhatsApp Business app, see below)
- has no PC — edits and deploys the Cloudflare Worker directly from the phone browser (Cloudflare dashboard editor), so wants exact line numbers to change rather than files to replace
- all their Meta ad accounts are on the Asia/Kolkata (IST) timezone — date ranges in reporting should follow IST
- does not want purchase/cost numbers taken from Meta (Purchase event attribution isn't reliable); the orders they mark Paid in their own admin/DB are the source of truth for paid count and real cost per paid
- for ads profit/ROI only Agency Ad Account sales count; client top-ups are pass-through ad money, not their profit (ad setup / landing page service is their earning)
- does not want "access first, pay later" mentioned in ad copy or the WhatsApp welcome message — says it attracts scammers; that offer is decided per client in chat
- hired 2-3 agents who call the WhatsApp leads; going with a lead/follow-up system inside their own admin panel, agents get their own login (Leads + Pay Link only); only WhatsApp number is the +44 one and doesn't want to buy a new number; tried moving it to the WhatsApp Cloud API but dropped that — staying on the WhatsApp Business app, linking agents' phones/laptops to it as linked devices, and adding leads to the panel by hand
- pricing: agency ad account $15; minimum top-up $30 with 4% top-up fee (down to 3% for clients with daily volume above ~$100-200); UPI/INR payments carry an extra 3% payment fee, USDT doesn't
