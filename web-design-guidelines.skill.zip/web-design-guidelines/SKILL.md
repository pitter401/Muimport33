---
name: "web-design-guidelines"
description: "Review UI code for Web Interface Guidelines compliance. Use when asked to \"review my UI\", \"check accessibility\", \"audit design\", \"review UX\", or \"check my site against best practices\"."
---

# Web Interface Guidelines

Review files for compliance with Web Interface Guidelines (by Vercel).

## Report only — never fix

This skill only finds and suggests. Do not edit, fix, refactor or delete anything, not even small or "obvious" fixes, and do not start an update. The user reads the list and decides which items to get done; work on them only after the user names them. Each finding: what is wrong, where (`file:line`), and the suggested fix in one line.

## How It Works

1. Fetch the latest guidelines from the source URL below
2. Read the specified files (or ask the user for files/pattern)
3. Check against all rules in the fetched guidelines
4. Output findings in the terse `file:line` format

## Guidelines Source

Fetch fresh guidelines before each review:

```
https://raw.githubusercontent.com/vercel-labs/web-interface-guidelines/main/command.md
```

Use WebFetch to retrieve the latest rules (if the web is blocked, `git clone https://github.com/vercel-labs/web-interface-guidelines` and read `command.md`). The fetched content contains all the rules and output format instructions.

## Usage

When a user provides a file or pattern argument:
1. Fetch guidelines from the source URL above
2. Read the specified files
3. Apply all rules from the fetched guidelines
4. Output findings using the format specified in the guidelines
5. End by asking which items the user wants fixed — then stop

If no files are specified, ask the user which files to review.