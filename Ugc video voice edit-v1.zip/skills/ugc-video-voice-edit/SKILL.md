---
name: "ugc-video-voice-edit"
description: "Edit a UGC/ad video: change on-screen text (e.g. price), cut claims, and replace spoken words with a voice clone of the same speaker, auto-scored for naturalness."
---

# UGC video + voice edit

Reply to the user in Hinglish (Roman script).

## 1. Set up the voice studio (fresh container every chat)
- Read project docs `claude/voice-studio/setup_voice_studio.sh` and `claude/voice-studio/voicefix.py` (Projects tool, project_read), write them into the working dir, and run `bash setup_voice_studio.sh <dir>` (~5 min). Put `voicefix.py` next to a `models/` folder (symlink the installed models dir).
- Everything comes from GitHub releases + PyPI (Hugging Face is blocked): ZipVoice zero-shot voice clone + vocos vocoder + lexicon-en-us (sherpa-onnx tts-models), Whisper-small (sherpa-onnx asr-models), Resemblyzer (voice similarity), speechmos DNSMOS (naturalness score). No GPU needed.

## 2. On-screen text changes (e.g. $15 -> $20)
- Extract frames (ffmpeg), find every scene where the text appears (contact sheets with frame numbers).
- Per frame: track the label with cv2.matchTemplate (multi-scale; use the stable part of the label, or the price token itself for fade-in animations), inpaint the old glyphs (cv2.inpaint on a dilated glyph mask), draw new text with a matching font from @fontsource npm packages (`npm pack @fontsource/<font>`; e.g. Inter 900, Barlow Condensed 700), colour = measured (text median - background median) so fades/flashes follow automatically.
- Handle: box-edge clipping (clip at the rightmost visible original glyph column), fade-in frames before tracking locks (inpaint the area), flash transitions (hold last transform a few frames). Check EVERY frame of each scene incl. entry/exit and flash frames before delivering.

## 3. Cutting segments
- Find cut points from frame-difference spikes (hard cuts) and white-flash peaks; cut video with trim/concat and audio with atrim + 30 ms fades. Transcribe after cutting to confirm the removed lines are gone.

## 4. Replacing spoken words (voice clone)
- Transcribe with Whisper small (en task gives English; Hinglish is translated) and binary-search short windows + 20 ms RMS envelopes to find exact word times. Prefer to replace a whole phrase between two pauses (e.g. 'only fifteen dollar' -> 'only twenty dollar') so there is no splice inside speech.
- Prompt ZipVoice with 2-3 s of the same speaker saying English words just before the phrase + exact transcript (Hindi words are not in the lexicon, keep prompt text English).
- Generate a grid (2 prompts x text variants x speed 0.95/1.05 x steps 16/32), EQ-match to her real speech, loudness-match, add room tone, place with 15 ms crossfades. Score each in context: ASR must contain the new words, Resemblyzer similarity >= original, DNSMOS SIG/OVRL >= original, duration close to the slot. Pick the best; never time-stretch/pitch-shift more than ~5% (that is what sounds robotic).
- Be honest: these scores are a proxy, not real listening; tell the user the exact timestamps to listen to.

## 5. Consent
Only clone the voice of a presenter who agreed to it (the user's own hired presenter / own content).