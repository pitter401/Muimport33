// PM2 process file: website + background worker + watchdog
module.exports = {
  apps: [
    { name: 'adflow-web', script: 'npm', args: 'start', env: { NODE_ENV: 'production' }, max_memory_restart: '700M' },
    { name: 'adflow-worker', script: 'npm', args: 'run worker', env: { NODE_ENV: 'production' }, max_memory_restart: '300M' },
    // restarts the website when it stops answering (see worker/watchdog.mjs)
    { name: 'adflow-watchdog', script: 'worker/watchdog.mjs', interpreter: 'node', cwd: __dirname, env: { NODE_ENV: 'production' }, max_memory_restart: '120M' },
  ],
};
