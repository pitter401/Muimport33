package com.adflow.admin;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.os.Build;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * v137: the admin's own notification sound on the phone, so it is there BEFORE the first alert.
 *  - bundled in the APK at build time (assets/own_sound.* + own_sound_ver.txt, scripts/build-apk.sh)
 *  - saved by the app itself when it is open (same-origin fetch in the WebView → saveSound(), no Cloudflare problem)
 *  - downloaded on "sync sound" push, after an app update / phone restart, or right before an alert (browser User-Agent)
 *  - the last good file is kept until a new one is saved (never left without a sound)
 * And the ring report (what played and why) for Admin → Phone notifications.
 */
public class SoundSync {
    static final String PREFS = "af_sound";
    static final String UA = "Mozilla/5.0 (Linux; Android " + Build.VERSION.RELEASE + "; " + Build.MODEL + ") AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36";

    static SharedPreferences p(Context c) { return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }
    static String clean(String v) { return v == null ? "" : v.replaceAll("[^A-Za-z0-9]", ""); }
    static File fileFor(Context c, String ver) { return new File(c.getFilesDir(), "notif_" + clean(ver) + ".snd"); }

    /** Server base + API path + the current sound (from the app or the last push). */
    static void remember(Context c, String base, String api, String ver, String url) {
        SharedPreferences.Editor e = p(c).edit();
        if (base != null && !base.isEmpty()) e.putString("base", base.replaceAll("/+$", ""));
        if (api != null && !api.isEmpty()) e.putString("api", api);
        if (ver != null) e.putString("ver", ver);
        if (url != null) e.putString("url", url);
        e.apply();
    }

    /** The file that holds the last good sound (any version), or null. */
    static File lastGood(Context c) {
        String n = p(c).getString("good", "");
        if (!n.isEmpty()) { File f = new File(c.getFilesDir(), n); if (f.exists() && f.length() > 0) return f; }
        File[] all = c.getFilesDir().listFiles();
        File best = null;
        if (all != null) for (File f : all) if (f.getName().startsWith("notif_") && f.getName().endsWith(".snd") && f.length() > 0 && (best == null || f.lastModified() > best.lastModified())) best = f;
        return best;
    }
    /** A new version is saved → it becomes the "last good" file and the older ones go. */
    static void keep(Context c, File f) {
        p(c).edit().putString("good", f.getName()).apply();
        File[] all = c.getFilesDir().listFiles();
        if (all != null) for (File o : all) if (o.getName().startsWith("notif_") && !o.equals(f) && !o.getName().startsWith("notif_bundled")) o.delete();
    }
    /** The cached file failed to play → it goes, so it is downloaded again (the bundled copy stays). */
    static void drop(Context c, File f) {
        if (f == null || f.getName().startsWith("notif_bundled")) return;
        f.delete();
        if (f.getName().equals(p(c).getString("good", ""))) p(c).edit().remove("good").apply();
    }

    /* ---------- bundled in the APK ---------- */
    static String bundledVer(Context c) {
        try (InputStream in = c.getAssets().open("own_sound_ver.txt")) {
            byte[] b = new byte[64]; int n = in.read(b); return n > 0 ? new String(b, 0, n, "UTF-8").trim() : "";
        } catch (Exception e) { return ""; }
    }
    static File bundled(Context c) {
        File out = new File(c.getFilesDir(), "notif_bundled_" + clean(bundledVer(c)) + ".snd");
        if (out.exists() && out.length() > 0) return out;
        try {
            String[] names = c.getAssets().list("");
            if (names == null) return null;
            for (String n : names) {
                if (!n.startsWith("own_sound.")) continue;
                try (InputStream in = c.getAssets().open(n); OutputStream o = new FileOutputStream(out)) { copy(in, o, 3_000_000); }
                return out.length() > 0 ? out : null;
            }
        } catch (Exception ignored) { }
        return null;
    }

    /* ---------- download (browser User-Agent: Cloudflare lets it through) ---------- */
    /** Downloads version `ver`; returns the file or null. err[0] gets the reason (HTTP status / not audio / exception). */
    static File download(Context c, String ver, String url, int timeoutMs, String[] err) {
        if (url == null || url.isEmpty() || ver == null || ver.isEmpty()) { if (err != null) err[0] = "no sound url"; return null; }
        File f = fileFor(c, ver);
        if (f.exists() && f.length() > 0) return f;
        HttpURLConnection con = null;
        try {
            String u = url;
            for (int hop = 0; hop < 4; hop++) {
                con = (HttpURLConnection) new URL(u).openConnection();
                con.setInstanceFollowRedirects(true);
                con.setConnectTimeout(Math.min(4000, timeoutMs)); con.setReadTimeout(timeoutMs);
                con.setRequestProperty("User-Agent", UA);
                con.setRequestProperty("Accept", "audio/*,*/*;q=0.5");
                String ck = cookie(c, u);
                if (ck != null) con.setRequestProperty("Cookie", ck);
                int code = con.getResponseCode();
                if (code >= 300 && code < 400 && con.getHeaderField("Location") != null) { u = new URL(new URL(u), con.getHeaderField("Location")).toString(); con.disconnect(); continue; }
                if (code != 200) { if (err != null) err[0] = "HTTP " + code + (con.getHeaderField("cf-mitigated") != null ? " (Cloudflare challenge)" : ""); return null; }
                String ct = String.valueOf(con.getContentType()).toLowerCase();
                if (!ct.startsWith("audio/") && !ct.startsWith("application/octet-stream")) { if (err != null) err[0] = "not audio: " + ct; return null; }
                File tmp = new File(c.getFilesDir(), "notif_tmp.part");
                try (InputStream in = con.getInputStream(); OutputStream o = new FileOutputStream(tmp)) {
                    if (copy(in, o, 3_000_000) < 0) { tmp.delete(); if (err != null) err[0] = "too big"; return null; }
                }
                if (tmp.length() < 100 || !tmp.renameTo(f)) { tmp.delete(); if (err != null) err[0] = "empty file"; return null; }
                keep(c, f);
                return f;
            }
            if (err != null) err[0] = "too many redirects";
            return null;
        } catch (Exception e) { if (err != null) err[0] = e.getClass().getSimpleName() + ": " + e.getMessage(); return null; }
        finally { if (con != null) try { con.disconnect(); } catch (Exception ignored) { } }
    }
    /** Bytes from the app (same-origin fetch in the WebView) → saved as that version. */
    static boolean save(Context c, String ver, byte[] data) {
        if (ver == null || ver.isEmpty() || data == null || data.length < 100 || data.length > 3_000_000) return false;
        File f = fileFor(c, ver);
        try (OutputStream o = new FileOutputStream(f)) { o.write(data); } catch (Exception e) { f.delete(); return false; }
        keep(c, f);
        p(c).edit().putString("ver", ver).apply();
        return true;
    }

    /**
     * The file to play for version `ver` (own sound selected). Order: the bundled copy when it is this version → the cached
     * download → a download right now (≈6 s) → the last good file (an older own sound) → the bundled copy. null = nothing.
     */
    static File resolve(Context c, String ver, String url, String[] err, boolean[] downloaded) {
        String bv = bundledVer(c);
        if (!bv.isEmpty() && bv.equals(ver)) { File b = bundled(c); if (b != null) return b; }
        File f = fileFor(c, ver);
        if (f.exists() && f.length() > 0) { downloaded[0] = true; return f; }
        f = download(c, ver, url, 6000, err);
        if (f != null) { downloaded[0] = true; return f; }
        File g = lastGood(c);
        if (g != null) return g;
        return bundled(c);
    }

    static long copy(InputStream in, OutputStream o, long max) throws java.io.IOException {
        byte[] buf = new byte[8192]; int n; long total = 0;
        while ((n = in.read(buf)) > 0) { o.write(buf, 0, n); total += n; if (total > max) return -1; }
        return total;
    }

    /* ---------- ring report ---------- */
    static String cookie(Context c, String url) {
        try { return android.webkit.CookieManager.getInstance().getCookie(url); } catch (Throwable t) { return null; }
    }
    static JSONObject baseReport(Context c, java.util.Map<String, String> d) {
        JSONObject r = new JSONObject();
        try {
            AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
            int rm = am == null ? -1 : am.getRingerMode();
            r.put("alarm_flag", "1".equals(d.get("alarm")));
            r.put("ringer_mode", rm == AudioManager.RINGER_MODE_NORMAL ? "normal" : rm == AudioManager.RINGER_MODE_VIBRATE ? "vibrate" : rm == AudioManager.RINGER_MODE_SILENT ? "silent" : "unknown");
            r.put("alarm_volume", am == null ? -1 : am.getStreamVolume(AudioManager.STREAM_ALARM));
            r.put("alarm_volume_max", am == null ? -1 : am.getStreamMaxVolume(AudioManager.STREAM_ALARM));
            r.put("own_sound", d.get("snd") != null && !d.get("snd").isEmpty());
            r.put("snd_ver", d.get("snd") == null ? "" : d.get("snd"));
            r.put("test", "1".equals(d.get("test")));
            r.put("device", (Build.MANUFACTURER + " " + Build.MODEL).trim());
            r.put("android", Build.VERSION.RELEASE);
            try { r.put("app_version", c.getPackageManager().getPackageInfo(c.getPackageName(), 0).versionName); } catch (Exception ignored) { }
        } catch (Exception ignored) { }
        return r;
    }
    /** POST {base}{api}push_report (the app's login token, else the cookie). Background, never throws.
     *  v139: a report that can't be sent now is kept and sent later (PushReg queue). */
    static void report(Context c, JSONObject r) {
        final Context app = c.getApplicationContext();
        new Thread(() -> { try { PushReg.sendOrQueue(app, "push_report", r); } catch (Throwable ignored) { } }).start();
    }
}
