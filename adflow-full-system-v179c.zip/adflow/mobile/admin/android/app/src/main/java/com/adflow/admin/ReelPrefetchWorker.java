package com.adflow.admin;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import androidx.annotation.NonNull;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

/**
 * v168: Daily reel — background downloader (runs also when the app is closed). COMPLETELY SILENT: plain WorkManager work
 * (no foreground service, no expedited work, no notification of any kind).
 *  - When: every 3 h (flex 1 h → every 2–3 h), at app start, after an app update / phone restart, and on the silent FCM data
 *    message {type:'reel_ready'} (AlertMessagingService). Unique work names → never duplicated; one run at a time (lock),
 *    a kick during a run makes that run look again at the end.
 *  - Network required. On a metered network a file is still downloaded when it is ≤ 60 MB (owner: it must be ready);
 *    a bigger one waits for an unmetered network (its own unique job).
 *  - GET <site><api>reel/prefetch (admin app: reel/view/prefetch) with the app's login token (saved by the app) and the
 *    WebView's login cookie (CookieManager) → today's + tomorrow's (IST) {id, url, size, sha256}; each goes to
 *    filesDir/reels/<id>.mp4 (ReelFetch: Range resume, chunk retries, sha256, atomic rename); files not in the list go.
 *  - Each finished file is reported once: POST reel/cached {reel_id, sha256, via:'native', app_build} (Admin → report).
 *  - Requests carry x-af-bg: 1 so the server does not count them as the person being online.
 */
public class ReelPrefetchWorker extends Worker {
    static final String PERIODIC = "af_reel_periodic", NOW = "af_reel_now", WIFI = "af_reel_unmetered";
    static final long METERED_MAX = 60L * 1024 * 1024;
    static final ReentrantLock LOCK = new ReentrantLock();

    public ReelPrefetchWorker(@NonNull Context c, @NonNull WorkerParameters p) { super(c, p); }

    static SharedPreferences p(Context c) { return c.getSharedPreferences("af_reel", Context.MODE_PRIVATE); }
    static File dir(Context c) { File d = new File(c.getFilesDir(), "reels"); d.mkdirs(); return d; }

    /** The periodic job (KEEP: scheduling again changes nothing). Safe to call often. */
    static void schedule(Context c) {
        try {
            Constraints net = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
            PeriodicWorkRequest r = new PeriodicWorkRequest.Builder(ReelPrefetchWorker.class, 3, TimeUnit.HOURS, 1, TimeUnit.HOURS)
                .setConstraints(net).setBackoffCriteria(androidx.work.BackoffPolicy.EXPONENTIAL, 2, TimeUnit.MINUTES).build();
            WorkManager.getInstance(c.getApplicationContext()).enqueueUniquePeriodicWork(PERIODIC, ExistingPeriodicWorkPolicy.KEEP, r);
        } catch (Throwable ignored) { }
    }
    /** One run now (as soon as there is a network). A run already waiting/running is kept; it looks again at its end. */
    static void kick(Context c, String why) {
        try {
            p(c).edit().putLong("kick_at", System.currentTimeMillis()).putString("kick_why", why).apply();
            Constraints net = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
            OneTimeWorkRequest r = new OneTimeWorkRequest.Builder(ReelPrefetchWorker.class).setConstraints(net)
                .setBackoffCriteria(androidx.work.BackoffPolicy.EXPONENTIAL, 1, TimeUnit.MINUTES).build();
            WorkManager.getInstance(c.getApplicationContext()).enqueueUniqueWork(NOW, ExistingWorkPolicy.KEEP, r);
        } catch (Throwable ignored) { }
    }
    static void kickUnmetered(Context c) {
        try {
            Constraints net = new Constraints.Builder().setRequiredNetworkType(NetworkType.UNMETERED).build();
            OneTimeWorkRequest r = new OneTimeWorkRequest.Builder(ReelPrefetchWorker.class).setConstraints(net).build();
            WorkManager.getInstance(c.getApplicationContext()).enqueueUniqueWork(WIFI, ExistingWorkPolicy.KEEP, r);
        } catch (Throwable ignored) { }
    }

    /** Where the server is: SoundSync prefs (base = origin, api = "/api/agent/" or "/api/admin/"), saved by the app. */
    static String reelApi(Context c) {
        String base = SoundSync.p(c).getString("base", ""), api = SoundSync.p(c).getString("api", "");
        if (base.isEmpty() || api.isEmpty()) return null;
        if (!api.endsWith("/")) api += "/";
        return base + api + (api.contains("/admin/") ? "reel/view/" : "reel/");
    }
    static String origin(Context c) { return SoundSync.p(c).getString("base", ""); }

    static HttpURLConnection open(Context c, String url) throws java.io.IOException {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        con.setConnectTimeout(15000); con.setReadTimeout(30000);
        con.setUseCaches(false);
        con.setRequestProperty("User-Agent", SoundSync.UA);
        con.setRequestProperty("x-af-bg", "1");
        con.setRequestProperty("Accept-Encoding", "identity");
        String auth = PushReg.p(c).getString("auth", "");
        if (!auth.isEmpty()) con.setRequestProperty("Authorization", "Bearer " + auth);
        String ck = SoundSync.cookie(c, url); // the WebView's login cookie (HttpOnly cookies included)
        if (ck != null && !ck.isEmpty()) con.setRequestProperty("Cookie", ck);
        return con;
    }

    @NonNull
    @Override
    public Result doWork() {
        final Context c = getApplicationContext();
        if (!LOCK.tryLock()) { p(c).edit().putLong("kick_at", System.currentTimeMillis()).apply(); return Result.success(); } // the running one looks again
        try {
            boolean retry = false;
            for (int loop = 0; loop < 3; loop++) {
                long started = System.currentTimeMillis();
                retry = runOnce(c);
                if (isStopped() || p(c).getLong("kick_at", 0) < started) break; // nobody asked again during this run
            }
            return retry && getRunAttemptCount() < 8 ? Result.retry() : Result.success();
        } catch (Throwable t) {
            p(c).edit().putString("last_err", t.getClass().getSimpleName() + ": " + t.getMessage()).apply();
            return Result.success();
        } finally { LOCK.unlock(); }
    }

    /** One pass. true = something failed that is worth a WorkManager retry. */
    boolean runOnce(Context c) throws InterruptedException {
        SharedPreferences sp = p(c);
        sp.edit().putLong("run_at", System.currentTimeMillis()).apply();
        String api = reelApi(c);
        if (api == null) { sp.edit().putString("last_err", "no server saved yet (open the app once)").apply(); return false; }
        File dir = dir(c);
        List<ReelFetch.Item> items = new ArrayList<>();
        boolean listed = false;
        String err = null;
        try {
            HttpURLConnection con = open(c, api + "prefetch");
            int code = con.getResponseCode();
            if (code == 401 || code == 403) { sp.edit().putString("last_err", "HTTP " + code + " (not logged in)").putLong("list_err_at", System.currentTimeMillis()).apply(); con.disconnect(); return false; }
            if (code != 200) throw new java.io.IOException("prefetch HTTP " + code);
            String body;
            try (InputStream in = con.getInputStream()) { body = readAll(in, 1 << 20); }
            con.disconnect();
            JSONArray fs = new JSONObject(body).optJSONArray("files");
            items = parse(fs, origin(c), api);
            listed = true;
            sp.edit().putLong("list_ok_at", System.currentTimeMillis()).putString("list", fs == null ? "[]" : fs.toString()).remove("queued").apply();
        } catch (Exception e) {
            err = "prefetch: " + e.getClass().getSimpleName() + ": " + e.getMessage();
            // offline / server down: use the list the app handed over (ReelCache.queue) or the last good list — never delete then
            try { items = parse(new JSONArray(sp.getString("queued", sp.getString("list", "[]"))), origin(c), api); } catch (Exception ignored) { }
        }
        if (listed) {
            Set<String> keep = new HashSet<>();
            for (ReelFetch.Item it : items) keep.add(it.id);
            ReelFetch.prune(dir, keep);
        }
        boolean metered = isMetered(c), retry = !listed, waitWifi = false;
        JSONObject failed = new JSONObject();
        for (ReelFetch.Item it : items) {
            if (isStopped()) return true;
            if (metered && it.size > METERED_MAX && !ReelFetch.has(dir, it.id, it.sha256)) { waitWifi = true; continue; }
            int r = ReelFetch.fetch(dir, it, url -> open(c, url), new ReelFetch.Ctl() {
                public boolean stopped() { return isStopped(); }
                public void sleep(long ms) throws InterruptedException { Thread.sleep(ms); }
            }, dir.getUsableSpace());
            if (r == ReelFetch.OK) report(c, dir, it);
            else {
                try { failed.put(it.id, r == ReelFetch.GONE ? "gone" : r == ReelFetch.NOSPACE ? "no_space" : r == ReelFetch.STOPPED ? "stopped" : "failed"); } catch (Exception ignored) { }
                if (r == ReelFetch.FAIL || r == ReelFetch.STOPPED) retry = true;
            }
        }
        if (waitWifi) kickUnmetered(c);
        SharedPreferences.Editor e = sp.edit().putString("failed", failed.toString()).putLong("done_at", System.currentTimeMillis());
        if (err != null) e.putString("last_err", err); else e.remove("last_err");
        e.apply();
        return retry;
    }

    /** POST reel/cached once per finished file (for the admin's "Ready on phone"). */
    static void report(Context c, File dir, ReelFetch.Item it) {
        String[] m = ReelFetch.meta(dir, it.id);
        if (m == null || "1".equals(m[2])) return;
        String api = reelApi(c);
        if (api == null) return;
        HttpURLConnection con = null;
        try {
            con = open(c, api + "cached");
            con.setRequestMethod("POST"); con.setDoOutput(true);
            con.setRequestProperty("Content-Type", "application/json");
            JSONObject b = new JSONObject();
            b.put("reel_id", Long.parseLong(it.id)); b.put("sha256", m[0]); b.put("via", "native"); b.put("app_build", PushReg.code(c));
            try (OutputStream o = con.getOutputStream()) { o.write(b.toString().getBytes("UTF-8")); }
            if (con.getResponseCode() == 200) ReelFetch.markReported(dir, it.id);
        } catch (Exception ignored) { }
        finally { if (con != null) try { con.disconnect(); } catch (Exception ignored) { } }
    }

    /** {id, url|file, size, sha256}[] → items; url made absolute against the site. */
    static List<ReelFetch.Item> parse(JSONArray fs, String origin, String api) {
        List<ReelFetch.Item> out = new ArrayList<>();
        if (fs == null) return out;
        for (int i = 0; i < fs.length(); i++) {
            JSONObject f = fs.optJSONObject(i);
            if (f == null) continue;
            String id = String.valueOf(f.optLong("id", -1)), sha = f.optString("sha256", ""), url = f.optString("url", "");
            long size = f.optLong("size", 0);
            if (url.isEmpty() && !f.optString("file", "").isEmpty()) { try { url = api + "media/" + java.net.URLEncoder.encode(f.optString("file"), "UTF-8"); } catch (Exception ignored) { } }
            else if (url.startsWith("/")) url = origin + url;
            if (!ReelFetch.validId(id) || size <= 0 || sha.isEmpty() || !(url.startsWith("https://") || url.startsWith("http://"))) continue;
            // only our own server (never a URL pointing somewhere else)
            if (!origin.isEmpty() && !url.startsWith(origin + "/")) continue;
            out.add(new ReelFetch.Item(id, url, size, sha));
        }
        return out;
    }

    static boolean isMetered(Context c) {
        try { ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE); return cm == null || cm.isActiveNetworkMetered(); }
        catch (Throwable t) { return true; }
    }
    static String readAll(InputStream in, int max) throws java.io.IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) { b.write(buf, 0, n); if (b.size() > max) throw new java.io.IOException("too large"); }
        return b.toString("UTF-8");
    }
}
