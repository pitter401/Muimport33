package com.adflow.admin;

import android.net.Uri;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import com.getcapacitor.Bridge;
import com.getcapacitor.BridgeWebViewClient;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * v168: serves the natively downloaded Daily reel to the page at https://<site>/__reelcache/<id>.mp4 — the SAME origin as the
 * remote-loaded app page, so <video> may play it (a file:// URL is blocked from an https page, and Capacitor's own
 * /_capacitor_file_ path ignores the start of a Range request, which breaks seeking). Proper HTTP Range: 206 with the
 * requested bytes, Content-Range and Content-Length. Anything else goes to Capacitor's client unchanged.
 */
public class ReelWebViewClient extends BridgeWebViewClient {
    static final String PREFIX = "/__reelcache/";
    static final Pattern PATH = Pattern.compile("^/__reelcache/([0-9]{1,12})\\.mp4$");
    static final Pattern RANGE = Pattern.compile("^bytes=(\\d*)-(\\d*)$");
    private final Bridge bridge;

    public ReelWebViewClient(Bridge bridge) { super(bridge); this.bridge = bridge; }

    @Override
    public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
        try {
            Uri u = request.getUrl();
            String path = u.getPath();
            if (path != null && path.startsWith(PREFIX) && sameHost(u)) return serve(view.getContext().getApplicationContext().getFilesDir(), path, header(request.getRequestHeaders(), "Range"));
        } catch (Throwable ignored) { }
        return super.shouldInterceptRequest(view, request);
    }

    private boolean sameHost(Uri u) {
        try {
            String s = bridge.getServerUrl();
            String host = s != null ? Uri.parse(s).getHost() : Uri.parse(SoundSync.p(bridge.getContext()).getString("base", "")).getHost();
            return host != null && host.equalsIgnoreCase(u.getHost());
        } catch (Throwable t) { return false; }
    }

    static String header(Map<String, String> h, String name) {
        if (h == null) return null;
        for (Map.Entry<String, String> e : h.entrySet()) if (e.getKey() != null && e.getKey().equalsIgnoreCase(name)) return e.getValue();
        return null;
    }

    static WebResourceResponse serve(File filesDir, String path, String range) throws IOException {
        Matcher m = PATH.matcher(path);
        File dir = new File(filesDir, "reels");
        if (!m.matches() || !ReelFetch.has(dir, m.group(1), "")) return status(404, "Not Found");
        File f = ReelFetch.mp4(dir, m.group(1));
        long size = f.length();
        Map<String, String> h = new HashMap<>();
        h.put("Accept-Ranges", "bytes");
        h.put("Cache-Control", "no-store");
        h.put("X-Content-Type-Options", "nosniff");
        long a = 0, b = size - 1;
        boolean partial = false;
        if (range != null) {
            Matcher r = RANGE.matcher(range.trim());
            if (r.matches() && (!r.group(1).isEmpty() || !r.group(2).isEmpty())) {
                if (r.group(1).isEmpty()) { a = Math.max(0, size - Long.parseLong(r.group(2))); }
                else { a = Long.parseLong(r.group(1)); if (!r.group(2).isEmpty()) b = Math.min(size - 1, Long.parseLong(r.group(2))); }
                if (a >= size || a > b) { h.put("Content-Range", "bytes */" + size); return new WebResourceResponse("video/mp4", null, 416, "Range Not Satisfiable", h, new ByteArrayInputStream(new byte[0])); }
                partial = true;
            }
        }
        long len = b - a + 1;
        h.put("Content-Length", String.valueOf(len));
        if (partial) h.put("Content-Range", "bytes " + a + "-" + b + "/" + size);
        return new WebResourceResponse("video/mp4", null, partial ? 206 : 200, partial ? "Partial Content" : "OK", h, slice(f, a, len));
    }

    static WebResourceResponse status(int code, String why) {
        Map<String, String> h = new HashMap<>();
        h.put("Cache-Control", "no-store");
        return new WebResourceResponse("text/plain", "utf-8", code, why, h, new ByteArrayInputStream(new byte[0]));
    }

    /** The bytes [a, a+len) of the file as a stream. */
    static InputStream slice(File f, long a, long len) throws IOException {
        final FileInputStream in = new FileInputStream(f);
        long s = 0;
        while (s < a) { long k = in.skip(a - s); if (k <= 0) break; s += k; }
        return new InputStream() {
            long left = len;
            @Override public int read() throws IOException { if (left <= 0) return -1; int x = in.read(); if (x >= 0) left--; return x; }
            @Override public int read(byte[] buf, int off, int n) throws IOException {
                if (left <= 0) return -1;
                int k = in.read(buf, off, (int) Math.min(n, left));
                if (k > 0) left -= k;
                return k;
            }
            @Override public int available() { return (int) Math.min(Integer.MAX_VALUE, left); }
            @Override public void close() throws IOException { in.close(); }
        };
    }
}
