package com.adflow.admin;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.app.Person;
import org.json.JSONArray;
import org.json.JSONObject;
import com.capacitorjs.plugins.pushnotifications.PushNotificationsPlugin;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * v103: our own push receiver (replaces the plugin's). The server sends data-only messages ("af"=1) so this code runs even
 * when the app is closed: it shows the notification itself, and for a NEW LEAD ("alarm"=1) it also plays the alert sound on
 * the ALARM volume when the phone is on silent / vibrate (like an alarm clock) — if the agent left that switch on.
 * v137: the sound plays from RingService (foreground, wake lock, alarm audio focus); own sound chosen = never the built-in
 * sound (quiet channel, nothing plays if the file can't be had); every alert sends a ring report to the server.
 */
public class AlertMessagingService extends FirebaseMessagingService {
    static final String CHANNEL = "alerts";
    static final String PREFS = "adflow";
    static final String KEY = "alarm_silent";

    @Override
    public void onNewToken(@NonNull String token) {
        super.onNewToken(token);
        PushNotificationsPlugin.onNewToken(token);
        PushReg.post(this, token, "new_token"); // v139: straight to the server (the plugin event alone did not reach it)
    }

    @Override
    public void onMessageReceived(@NonNull RemoteMessage m) {
        // v139: nothing here may stop the notification — every step has its own try/catch, the notification is shown FIRST,
        // the sound / ring report after it; the "sync sound" push is handled on its own and never reaches show().
        try { super.onMessageReceived(m); } catch (Throwable ignored) { }
        Map<String, String> d;
        try { d = m.getData(); } catch (Throwable t) { d = new java.util.HashMap<>(); }
        // v168: silent "Daily reel ready" data message → background download. NOTHING is shown (no notification, no sound).
        if ("reel_ready".equals(d.get("type")) && m.getNotification() == null) { try { ReelPrefetchWorker.kick(this, "fcm"); } catch (Throwable ignored) { } return; }
        boolean ours = false;
        try { ours = m.getNotification() == null && "1".equals(d.get("af")); } catch (Throwable ignored) { }
        if (ours) {
            // v134: "clear" = this chat was read (in any app) → its notification goes away, nothing is shown
            if (d.get("clear") != null) { try { clearChat(this, d.get("clear")); } catch (Throwable ignored) { } relay(m); return; }
            String ver = d.get("snd"), url = d.get("snd_url");
            boolean ownChosen = ver != null && !ver.isEmpty(); // the admin chose "Our own sound": NEVER the built-in sound
            try { if (ownChosen) SoundSync.remember(this, null, null, ver, url); } catch (Throwable ignored) { }
            // v137: "sync sound" push (the admin changed the sound) → download it now, show nothing
            if ("1".equals(d.get("snd_sync"))) {
                try {
                    JSONObject r = SoundSync.baseReport(this, d);
                    r.put("kind", "sync"); r.put("played", "none");
                    if (ownChosen) { String[] e = new String[1]; java.io.File f = SoundSync.download(this, ver, url, 8000, e); r.put("own_downloaded", f != null); if (e[0] != null) r.put("own_sound_error", e[0]); }
                    SoundSync.report(this, r);
                } catch (Throwable ignored) { }
                return;
            }
            try { show(m, d, ownChosen); }
            catch (Throwable e) {
                // the styled notification failed → a plain one, so the alert is never lost
                try { plain(d); } catch (Throwable ignored) { }
                try { JSONObject r = SoundSync.baseReport(this, d); r.put("kind", "show_error"); r.put("played", "none"); r.put("error", "show: " + e.getClass().getSimpleName() + ": " + e.getMessage()); SoundSync.report(this, r); } catch (Throwable ignored) { }
            }
            try { ring(d, ver, url, ownChosen); } catch (Throwable ignored) { }
        }
        relay(m);
    }
    /** app open → the JS side gets it too (never throws). */
    private void relay(RemoteMessage m) { try { PushNotificationsPlugin.sendRemoteMessage(m); } catch (Throwable ignored) { } }
    /** v139: the simplest possible notification (default channel settings) when show() failed. */
    private void plain(Map<String, String> d) {
        ensureChannel(this);
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 1, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder b = new NotificationCompat.Builder(this, CHANNEL).setSmallIcon(R.drawable.ic_stat_alert)
            .setContentTitle(d.get("title") == null ? "New message" : d.get("title")).setContentText(d.get("body") == null ? "" : d.get("body"))
            .setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH).setContentIntent(pi);
        NotificationManagerCompat.from(this).notify((int) (System.currentTimeMillis() % 100000), b.build());
    }

    /** v137: what to play for this alert, played from the foreground RingService (Vivo & co. silence background players), and the ring report. */
    private void ring(Map<String, String> d, String ver, String url, boolean ownChosen) {
        JSONObject rep = SoundSync.baseReport(this, d);
        try {
            boolean normal = ringerNormal(this);
            boolean alarmCase = "1".equals(d.get("alarm")) && alarmOn(this) && !normal;
            boolean ownNormal = ownChosen && normal; // the quiet channel has no sound: we play the own sound ourselves
            rep.put("kind", "alert");
            if (!alarmCase && !ownNormal) {
                rep.put("played", normal ? "channel" : "none");
                if (!normal) rep.put("error", !"1".equals(d.get("alarm")) ? "not a new-lead alert: no ring on " + rep.optString("ringer_mode") : "ring-on-silent switched off on this phone");
                SoundSync.report(this, rep);
                return;
            }
            java.io.File own = null;
            String[] err = new String[1]; boolean[] dl = new boolean[1];
            if (ownChosen) own = SoundSync.resolve(this, ver, url, err, dl);
            rep.put("own_downloaded", dl[0]);
            rep.put("own_file", own == null ? "" : own.getName());
            if (err[0] != null) rep.put("own_sound_error", err[0]);
            if (ownChosen && own == null) { rep.put("played", "none"); rep.put("error", "own sound chosen but not on the phone (" + err[0] + ")"); SoundSync.report(this, rep); return; }
            try { RingService.start(this, own, ownChosen, alarmCase, rep); }
            catch (Exception e) {
                rep.put("service_error", e.getClass().getSimpleName() + ": " + e.getMessage());
                rep.put("via", "direct");
                boolean ok = own != null ? playFile(this, own, alarmCase, 9000) : playAlarm(this, 9000);
                if (!ok && own != null) SoundSync.drop(this, own);
                rep.put("played", ok ? (own != null ? "own" : "builtin") : "none");
                SoundSync.report(this, rep);
            }
        } catch (Exception e) {
            try { rep.put("played", "none"); rep.put("error", e.getClass().getSimpleName() + ": " + e.getMessage()); } catch (Exception ignored) { }
            SoundSync.report(this, rep);
        }
    }

    static boolean alarmOn(Context c) { return c.getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY, true); }
    static void setAlarmOn(Context c, boolean on) { c.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY, on).apply(); }
    static boolean ringerNormal(Context c) {
        AudioManager am = (AudioManager) c.getSystemService(AUDIO_SERVICE);
        return am == null || am.getRingerMode() == AudioManager.RINGER_MODE_NORMAL;
    }

    /** v134: channel without its own sound — used when the admin uploaded our own notification sound (we play it ourselves). */
    static final String QUIET = "alerts_own";
    static void ensureQuietChannel(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(NOTIFICATION_SERVICE);
        if (nm == null || nm.getNotificationChannel(QUIET) != null) return;
        NotificationChannel ch = new NotificationChannel(QUIET, "Lead alerts (own sound)", NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("New leads and messages with the sound chosen by the admin");
        ch.enableVibration(true);
        ch.setVibrationPattern(new long[] { 0, 400, 200, 400, 200, 600 });
        ch.enableLights(true);
        ch.setLightColor(0xFF7C5CFF);
        ch.setLockscreenVisibility(NotificationCompat.VISIBILITY_PUBLIC);
        ch.setSound(null, null);
        nm.createNotificationChannel(ch);
    }
    /** Plays the admin's sound on the notification volume (ringer on) or the alarm volume (new lead on silent). */
    static boolean playFile(Context c, java.io.File f, boolean alarm, long waitMs) {
        final CountDownLatch done = new CountDownLatch(1);
        final boolean[] bad = { false };
        try {
            MediaPlayer mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder().setUsage(alarm ? AudioAttributes.USAGE_ALARM : AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            mp.setDataSource(f.getAbsolutePath());
            mp.setOnCompletionListener(p -> { p.release(); done.countDown(); });
            mp.setOnErrorListener((p, w, x) -> { bad[0] = true; p.release(); done.countDown(); return true; });
            mp.prepare();
            mp.start();
            if (waitMs > 0) done.await(waitMs, TimeUnit.MILLISECONDS);
            return !bad[0];
        } catch (Exception e) { return false; }
    }

    static void ensureChannel(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(NOTIFICATION_SERVICE);
        if (nm == null || nm.getNotificationChannel(CHANNEL) != null) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Lead alerts", NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("New leads and messages (loud)");
        ch.enableVibration(true);
        ch.setVibrationPattern(new long[] { 0, 400, 200, 400, 200, 600 });
        ch.enableLights(true);
        ch.setLightColor(0xFF7C5CFF);
        ch.setLockscreenVisibility(NotificationCompat.VISIBILITY_PUBLIC);
        ch.setSound(Uri.parse("android.resource://" + c.getPackageName() + "/" + R.raw.alert),
            new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
        nm.createNotificationChannel(ch);
    }

    static final String GROUP = "af_chats";
    static final String NPREFS = "af_notif";
    static final int SUMMARY_ID = 7;
    static int chatId(String lead) { return ("lead:" + lead).hashCode(); }

    /** v134: like WhatsApp — ONE notification per chat (its last messages, newest at the bottom), all chats grouped under the app. */
    private void show(RemoteMessage m, Map<String, String> d, boolean ownSound) {
        ensureChannel(this);
        if (ownSound) ensureQuietChannel(this);
        String lead = d.get("lead_id");
        String title = d.get("title") == null ? "" : d.get("title");
        String body = d.get("body") == null ? "" : d.get("body");
        // v134: server names the chat ("Name · WhatsApp") and the line ("New WhatsApp lead", or the message) → one clear notification per chat
        String chat = d.get("chat");
        if (lead != null && chat != null && !chat.isEmpty()) { title = chat; String ln = d.get("line"); if (ln != null && !ln.isEmpty()) body = ln; }
        Intent open = new Intent(this, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        String id = m.getMessageId() == null ? String.valueOf(System.currentTimeMillis()) : m.getMessageId();
        open.putExtra("google.message_id", id); // the push plugin turns this tap into "pushNotificationActionPerformed"
        for (Map.Entry<String, String> e : d.entrySet()) if (!e.getKey().equals("title") && !e.getKey().equals("body")) open.putExtra(e.getKey(), e.getValue());
        int nid = lead != null ? chatId(lead) : (int) (System.currentTimeMillis() & 0x7fffffff);
        PendingIntent pi = PendingIntent.getActivity(this, nid, open, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        NotificationCompat.Builder b = new NotificationCompat.Builder(this, ownSound ? QUIET : CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_alert)
            .setContentTitle(title)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setColor(0xFF7C5CFF)
            .setAutoCancel(true)
            .setGroup(GROUP)
            .setContentIntent(pi);
        if (lead != null) {
            SharedPreferences p = getSharedPreferences(NPREFS, MODE_PRIVATE);
            JSONArray old = new JSONArray();
            try { old = new JSONArray(p.getString("l_" + lead, "[]")); } catch (Exception ignored) { }
            JSONArray arr = new JSONArray();
            int from = Math.max(0, old.length() - 6); // keep the last 7 lines
            for (int i = from; i < old.length(); i++) { try { arr.put(old.getJSONObject(i)); } catch (Exception ignored) { } }
            String who = title.contains(" · ") ? title.substring(0, title.lastIndexOf(" · ")) : title;
            try { arr.put(new JSONObject().put("t", body).put("w", System.currentTimeMillis()).put("n", who)); } catch (Exception ignored) { }
            int total = p.getInt("c_" + lead, 0) + 1;
            p.edit().putString("l_" + lead, arr.toString()).putInt("c_" + lead, total).putString("n_" + lead, title).apply();
            Person me = new Person.Builder().setName("You").build();
            NotificationCompat.MessagingStyle st = new NotificationCompat.MessagingStyle(me).setConversationTitle(title).setGroupConversation(true);
            for (int i = 0; i < arr.length(); i++) {
                try {
                    JSONObject x = arr.getJSONObject(i);
                    st.addMessage(x.optString("t"), x.optLong("w"), new Person.Builder().setName(x.optString("n", title)).build());
                } catch (Exception ignored) { }
            }
            b.setStyle(st).setNumber(total);
            if (total > 1) b.setContentText(total + " new messages");
        } else {
            b.setStyle(new NotificationCompat.BigTextStyle().bigText(body));
        }
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm == null) return;
        nm.notify(nid, b.build());
        summary(this);
    }

    /** The group header ("3 chats") that holds the per-chat notifications together. */
    static void summary(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(NOTIFICATION_SERVICE);
        if (nm == null) return;
        SharedPreferences p = c.getSharedPreferences(NPREFS, MODE_PRIVATE);
        NotificationCompat.InboxStyle in = new NotificationCompat.InboxStyle();
        int chats = 0, msgs = 0;
        for (Map.Entry<String, ?> e : p.getAll().entrySet()) {
            if (!e.getKey().startsWith("c_")) continue;
            String lead = e.getKey().substring(2);
            int n = p.getInt(e.getKey(), 0);
            if (n <= 0) continue;
            chats++; msgs += n;
            in.addLine(p.getString("n_" + lead, "Chat") + "  (" + n + ")");
        }
        if (chats == 0) { nm.cancel(SUMMARY_ID); return; }
        Intent open = new Intent(c, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, SUMMARY_ID, open, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        String line = msgs + " new message" + (msgs == 1 ? "" : "s") + " from " + chats + " chat" + (chats == 1 ? "" : "s");
        in.setSummaryText(line);
        NotificationCompat.Builder s = new NotificationCompat.Builder(c, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_alert)
            .setContentTitle(line)
            .setStyle(in)
            .setGroup(GROUP)
            .setGroupSummary(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setAutoCancel(true)
            .setColor(0xFF7C5CFF)
            .setContentIntent(pi);
        nm.notify(SUMMARY_ID, s.build());
    }

    /** A chat was read (opened in the app, or read in the other app) → its notification and its saved lines go. */
    static void clearChat(Context c, String lead) {
        if (lead == null || lead.isEmpty()) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(chatId(lead));
        c.getSharedPreferences(NPREFS, MODE_PRIVATE).edit().remove("l_" + lead).remove("c_" + lead).remove("n_" + lead).apply();
        summary(c);
    }
    /** Tapped "clear all" / opened the app on the chat list → nothing is kept. */
    static void clearAll(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(NOTIFICATION_SERVICE);
        SharedPreferences p = c.getSharedPreferences(NPREFS, MODE_PRIVATE);
        if (nm != null) for (String k : p.getAll().keySet()) if (k.startsWith("c_")) nm.cancel(chatId(k.substring(2)));
        p.edit().clear().apply();
        if (nm != null) nm.cancel(SUMMARY_ID);
    }

    /** The alert sound on the ALARM stream: it plays on silent / vibrate (alarm volume), like an alarm clock. */
    static boolean playAlarm(Context c, long waitMs) {
        final CountDownLatch done = new CountDownLatch(1);
        final boolean[] bad = { false };
        try {
            MediaPlayer mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            mp.setDataSource(c, Uri.parse("android.resource://" + c.getPackageName() + "/" + R.raw.alert));
            mp.setOnCompletionListener(p -> { p.release(); done.countDown(); });
            mp.setOnErrorListener((p, w, x) -> { bad[0] = true; p.release(); done.countDown(); return true; });
            mp.prepare();
            mp.start();
            if (waitMs > 0) done.await(waitMs, TimeUnit.MILLISECONDS); // keep the service alive until the sound ends
            return !bad[0];
        } catch (Exception e) { return false; }
    }
}
