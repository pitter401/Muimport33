package com.adflow.agent;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** v137: after an app update (MY_PACKAGE_REPLACED) or a phone restart → fetch the current own sound in the background,
 *  so the first alert already has it (URL / version saved from the app or the last push). */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        final PendingResult pr = goAsync();
        final Context app = c.getApplicationContext();
        new Thread(() -> {
            try {
                String ver = SoundSync.p(app).getString("ver", ""), url = SoundSync.p(app).getString("url", "");
                if (!ver.isEmpty() && !url.isEmpty()) SoundSync.download(app, ver, url, 8000, new String[1]);
                SoundSync.bundled(app); // copy the bundled sound out of the APK once
                ReelPrefetchWorker.schedule(app); // v168: the Daily reel downloader runs after an update / restart even before the app is opened
                ReelPrefetchWorker.kick(app, "boot");
            } catch (Exception ignored) { }
            finally { pr.finish(); }
        }).start();
    }
}
