package com.adflow.agent;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * v168: Daily reel — the download core of the background downloader (plain Java, no Android classes, so it is unit-tested
 * on the JVM). Files live in <filesDir>/reels:
 *   <id>.mp4        the complete, sha256-verified video (only ever created by an atomic rename)
 *   <id>.ok         "sha256\nsize\nreported" — written (tmp + rename) after the rename; has() needs both
 *   <id>.part       the download in progress (its length = how far we got → HTTP Range resume)
 *   <id>.part.want  "sha256\nsize" the part belongs to (a new version of the reel throws the old part away)
 * Nothing here shows anything to the user.
 */
final class ReelFetch {
    static final int CHUNK = 4 * 1024 * 1024;  // one Range request
    static final int TRIES = 6;                // per chunk, before this run gives up (WorkManager retries the run later)
    static final Pattern ID = Pattern.compile("^[0-9]{1,12}$");

    interface Net { HttpURLConnection open(String url) throws IOException; }   // opens + sets auth / UA headers
    interface Ctl { boolean stopped(); void sleep(long ms) throws InterruptedException; }

    static final class Item {
        final String id, url, sha256; final long size;
        Item(String id, String url, long size, String sha256) { this.id = id; this.url = url; this.size = size; this.sha256 = sha256 == null ? "" : sha256.toLowerCase(); }
    }

    static final int OK = 0, GONE = 1, FAIL = 2, STOPPED = 3, NOSPACE = 4;

    static boolean validId(String id) { return id != null && ID.matcher(id).matches(); }
    static File mp4(File dir, String id) { return new File(dir, id + ".mp4"); }
    static File okf(File dir, String id) { return new File(dir, id + ".ok"); }
    static File part(File dir, String id) { return new File(dir, id + ".part"); }
    static File want(File dir, String id) { return new File(dir, id + ".part.want"); }

    /** [sha256, size, reported] of a finished file, or null. */
    static String[] meta(File dir, String id) {
        if (!validId(id)) return null;
        String s = read(okf(dir, id));
        if (s == null) return null;
        String[] a = s.split("\n");
        return a.length >= 2 ? new String[] { a[0].trim(), a[1].trim(), a.length > 2 ? a[2].trim() : "" } : null;
    }

    /** Complete and verified here? sha may be empty (= any version). */
    static boolean has(File dir, String id, String sha) {
        String[] m = meta(dir, id);
        if (m == null) return false;
        File f = mp4(dir, id);
        long size;
        try { size = Long.parseLong(m[1]); } catch (Exception e) { return false; }
        if (!f.isFile() || f.length() != size) return false;
        return sha == null || sha.isEmpty() || m[0].equalsIgnoreCase(sha);
    }

    /** Download one file until complete + verified (resume with Range, chunk retries with backoff, sha256, atomic rename). */
    static int fetch(File dir, Item it, Net net, Ctl ctl, long usableBytes) throws InterruptedException {
        if (!validId(it.id) || it.size <= 0) return FAIL;
        if (has(dir, it.id, it.sha256)) return OK;
        dir.mkdirs();
        File p = part(dir, it.id), w = want(dir, it.id), done = mp4(dir, it.id);
        // a finished file without its .ok (stopped between the rename and the .ok) → check it instead of downloading again
        if (done.isFile() && done.length() == it.size && !it.sha256.isEmpty() && it.sha256.equalsIgnoreCase(sha256(done))) { writeOk(dir, it, ""); return OK; }
        String wantTxt = it.sha256 + "\n" + it.size;
        if (!wantTxt.equals(read(w))) { p.delete(); write(w, wantTxt); }
        if (p.length() > it.size) p.delete();
        if (usableBytes >= 0 && usableBytes < (it.size - p.length()) + 16L * 1024 * 1024) return NOSPACE;
        for (int round = 0; round < 2; round++) {
            int r = fetchBytes(p, it, net, ctl);
            if (r != OK) return r;
            if (p.length() != it.size) { p.delete(); continue; }
            if (!it.sha256.isEmpty() && !it.sha256.equalsIgnoreCase(sha256(p))) { p.delete(); continue; } // damaged → start over (once)
            // atomic: the .mp4 only ever appears complete; .ok last
            okf(dir, it.id).delete();
            if (!p.renameTo(done)) { done.delete(); if (!p.renameTo(done)) return FAIL; }
            w.delete();
            writeOk(dir, it, "");
            return OK;
        }
        return FAIL;
    }

    /** Fills the .part from its current length to size, CHUNK bytes per request. */
    static int fetchBytes(File p, Item it, Net net, Ctl ctl) throws InterruptedException {
        long wait = 2000;
        int tries = 0;
        byte[] buf = new byte[64 * 1024];
        while (p.length() < it.size) {
            if (ctl.stopped()) return STOPPED;
            long off = p.length(), end = Math.min(it.size, off + CHUNK) - 1;
            HttpURLConnection con = null;
            boolean progressed = false;
            try {
                con = net.open(it.url);
                con.setRequestProperty("Range", "bytes=" + off + "-" + end);
                int code = con.getResponseCode();
                if (code == 404 || code == 401 || code == 403 || code == 410) return GONE;
                long start;
                if (code == 206) {
                    start = rangeStart(con.getHeaderField("Content-Range"));
                    if (start != off) throw new IOException("bad Content-Range " + con.getHeaderField("Content-Range"));
                } else if (code == 200) {
                    start = 0; // server ignored Range → the whole file from byte 0
                    if (off > 0) { try (RandomAccessFile raf = new RandomAccessFile(p, "rw")) { raf.setLength(0); } off = 0; }
                } else throw new IOException("HTTP " + code);
                long max = code == 206 ? end - off + 1 : it.size;
                try (InputStream in = con.getInputStream(); FileOutputStream out = new FileOutputStream(p, true)) {
                    long got = 0;
                    int n;
                    while (got < max && (n = in.read(buf, 0, (int) Math.min(buf.length, max - got))) > 0) {
                        out.write(buf, 0, n);
                        got += n;
                        progressed = true;
                        if (ctl.stopped()) { out.getFD().sync(); return STOPPED; }
                    }
                    out.getFD().sync();
                    if (got < max) throw new IOException("short read " + got + "/" + max);
                }
                wait = 2000; tries = 0;
            } catch (IOException e) {
                if (progressed) { wait = 2000; tries = 0; continue; } // got some bytes: resume at once from the new length
                if (++tries >= TRIES) return FAIL;
                ctl.sleep(wait);
                wait = Math.min(60000, wait * 2);
            } finally { if (con != null) try { con.disconnect(); } catch (Exception ignored) { } }
        }
        return OK;
    }

    static long rangeStart(String cr) {
        if (cr == null) return -1;
        Matcher m = Pattern.compile("bytes\\s+(\\d+)-(\\d+)/(\\d+|\\*)").matcher(cr.trim());
        return m.find() ? Long.parseLong(m.group(1)) : -1;
    }

    /** Everything that is not in the list goes (finished files, parts, leftovers). */
    static int prune(File dir, Set<String> keep) {
        File[] fs = dir.listFiles();
        if (fs == null) return 0;
        int n = 0;
        for (File f : fs) {
            String name = f.getName(), id = name.contains(".") ? name.substring(0, name.indexOf('.')) : name;
            if (!keep.contains(id)) { if (f.delete()) n++; }
        }
        return n;
    }

    static void writeOk(File dir, Item it, String reported) { write(okf(dir, it.id), it.sha256 + "\n" + it.size + "\n" + reported); }
    static void markReported(File dir, String id) {
        String[] m = meta(dir, id);
        if (m != null) write(okf(dir, id), m[0] + "\n" + m[1] + "\n1");
    }

    static String sha256(File f) {
        try (InputStream in = new FileInputStream(f)) {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] b = new byte[256 * 1024];
            int n;
            while ((n = in.read(b)) > 0) md.update(b, 0, n);
            StringBuilder sb = new StringBuilder();
            for (byte x : md.digest()) sb.append(String.format("%02x", x));
            return sb.toString();
        } catch (Exception e) { return ""; }
    }
    static String read(File f) {
        if (!f.isFile()) return null;
        try (InputStream in = new FileInputStream(f)) {
            byte[] b = new byte[(int) Math.min(4096, f.length())];
            int n = in.read(b);
            return n <= 0 ? "" : new String(b, 0, n, StandardCharsets.UTF_8);
        } catch (Exception e) { return null; }
    }
    /** Write via tmp + rename (never a half-written small file). */
    static void write(File f, String s) {
        File t = new File(f.getPath() + ".tmp");
        try (FileOutputStream o = new FileOutputStream(t)) { o.write(s.getBytes(StandardCharsets.UTF_8)); o.getFD().sync(); }
        catch (Exception e) { t.delete(); return; }
        if (!t.renameTo(f)) { f.delete(); t.renameTo(f); }
    }
}
