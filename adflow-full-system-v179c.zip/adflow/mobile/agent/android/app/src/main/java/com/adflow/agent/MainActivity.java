package com.adflow.agent;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(AppUpdaterPlugin.class);
        registerPlugin(ReelCachePlugin.class); // v168: Daily reel — native background download (has / url / queue / status)
        super.onCreate(savedInstanceState);
        BarStyle.install(this, bridge != null ? bridge.getWebView() : null); // v142: solid status / nav bars, content kept out from under them
        // v167: the Daily reel autoplays WITH sound (no tap first) — the WebView must not demand a user gesture for media
        if (bridge != null && bridge.getWebView() != null) bridge.getWebView().getSettings().setMediaPlaybackRequiresUserGesture(false);
        // v168: the natively downloaded reel is served at https://<site>/__reelcache/<id>.mp4 (same origin, Range for seeking)
        if (bridge != null) bridge.setWebViewClient(new ReelWebViewClient(bridge));
        ReelPrefetchWorker.schedule(this);          // every 2–3 h, also when the app is closed (silent, no notification)
        ReelPrefetchWorker.kick(this, "start");     // and once now
        PushReg.registerNow(this, "start", true); // v139: register this phone on every start (needs the server saved by the app once)
    }
    @Override
    public void onResume() {
        super.onResume();
        PushReg.registerNow(this, "resume", false); // throttled (30 min)
    }
}
