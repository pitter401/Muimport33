package com.adflow.agent;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

/**
 * v142: status bar + navigation bar for Android 15 edge-to-edge (targetSdk 35) and older phones alike.
 *  - The WebView is kept out from under the status bar, the nav bar and the keyboard (margins from the window insets),
 *    so page content never scrolls behind the clock / battery icons.
 *  - The strips behind the bars are painted solid in the page's colour (top = status bar, bottom = nav bar).
 *  - The icon colour follows the page: dark icons on a light page, light icons on a dark page.
 * The web page calls AppUpdater.setBars({ dark, color, navColor, navDark }) on start and whenever the theme / page changes;
 * the last values are saved so the next start draws the right colours from the first frame.
 */
public final class BarStyle {
    private BarStyle() { }
    private static final String PREF = "adflow_bars";

    /** Paints the area behind the status bar in one colour and the rest (nav bar area) in another. */
    static final class BarBg extends Drawable {
        int top = 0, topColor = Color.BLACK, bottomColor = Color.BLACK;
        private final Paint paint = new Paint();
        @Override public void draw(Canvas c) {
            Rect b = getBounds();
            paint.setColor(bottomColor); c.drawRect(b, paint);
            if (top > 0) { paint.setColor(topColor); c.drawRect(b.left, b.top, b.right, b.top + top, paint); }
        }
        @Override public void setAlpha(int a) { }
        @Override public void setColorFilter(ColorFilter f) { }
        @Override public int getOpacity() { return PixelFormat.OPAQUE; }
    }

    private static BarBg bg(Activity a) {
        View decor = a.getWindow().getDecorView();
        Drawable d = decor.getBackground();
        if (d instanceof BarBg) return (BarBg) d;
        BarBg n = new BarBg();
        decor.setBackground(n);
        return n;
    }

    /** MainActivity.onCreate (after super): edge-to-edge on every Android version + our own insets. */
    public static void install(Activity a, View webView) {
        Window w = a.getWindow();
        WindowCompat.setDecorFitsSystemWindows(w, false);
        w.setStatusBarColor(Color.TRANSPARENT);
        w.setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 29) { w.setNavigationBarContrastEnforced(false); w.setStatusBarContrastEnforced(false); }
        final BarBg bg = bg(a);
        // first frame: the last colours the page set, else the theme's defaults (values/ + values-night/ styles.xml)
        SharedPreferences sp = a.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        boolean night = (a.getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES;
        String k = night ? "d_" : "l_";
        int defTop = a.getResources().getColor(R.color.bar_top, a.getTheme());
        int defBottom = a.getResources().getColor(R.color.bar_bottom, a.getTheme());
        boolean defLight = a.getResources().getBoolean(R.bool.bar_light);
        apply(a, sp.getBoolean(k + "dark", defLight), sp.getInt(k + "color", defTop), sp.getBoolean(k + "navDark", defLight), sp.getInt(k + "navColor", defBottom), false);
        if (webView == null) return;
        ViewCompat.setOnApplyWindowInsetsListener(webView, (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            Insets ime = insets.getInsets(WindowInsetsCompat.Type.ime());
            ViewGroup.MarginLayoutParams mlp = (ViewGroup.MarginLayoutParams) v.getLayoutParams();
            mlp.topMargin = bars.top;
            mlp.leftMargin = bars.left;
            mlp.rightMargin = bars.right;
            mlp.bottomMargin = Math.max(bars.bottom, ime.bottom); // keyboard open → the page shrinks (like adjustResize)
            v.setLayoutParams(mlp);
            bg.top = bars.top;
            bg.invalidateSelf();
            // the page gets no insets → env(safe-area-inset-*) is 0 there, so nothing is padded twice
            return WindowInsetsCompat.CONSUMED;
        });
        ViewCompat.requestApplyInsets(webView);
    }

    /** dark = dark icons (light page). Must run on the UI thread. */
    public static void apply(Activity a, boolean darkIcons, int color, boolean navDarkIcons, int navColor, boolean save) {
        Window w = a.getWindow();
        BarBg bg = bg(a);
        bg.topColor = color | 0xFF000000;
        bg.bottomColor = navColor | 0xFF000000;
        bg.invalidateSelf();
        WindowInsetsControllerCompat c = WindowCompat.getInsetsController(w, w.getDecorView());
        c.setAppearanceLightStatusBars(darkIcons);
        c.setAppearanceLightNavigationBars(navDarkIcons);
        // Android 6–7 cannot draw dark nav icons: a black nav bar keeps the white ones readable there
        if (Build.VERSION.SDK_INT < 26) w.setNavigationBarColor(navDarkIcons ? 0xFF000000 : Color.TRANSPARENT);
        if (save) {
            boolean night = (a.getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES;
            String k = night ? "d_" : "l_";
            a.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putBoolean(k + "dark", darkIcons).putInt(k + "color", color).putBoolean(k + "navDark", navDarkIcons).putInt(k + "navColor", navColor).apply();
        }
    }

    /** '#rrggbb' / '#rgb' / 'rgb(r,g,b)' → colour, or the fallback. */
    public static int parse(String s, int fallback) {
        if (s == null) return fallback;
        s = s.trim();
        try {
            if (s.startsWith("rgb")) {
                String[] p = s.substring(s.indexOf('(') + 1, s.indexOf(')')).split("[,\\s/]+");
                return Color.rgb(Integer.parseInt(p[0].trim()), Integer.parseInt(p[1].trim()), Integer.parseInt(p[2].trim()));
            }
            if (s.length() == 4 && s.charAt(0) == '#') s = "#" + s.charAt(1) + s.charAt(1) + s.charAt(2) + s.charAt(2) + s.charAt(3) + s.charAt(3);
            return Color.parseColor(s);
        } catch (Exception e) { return fallback; }
    }
}
