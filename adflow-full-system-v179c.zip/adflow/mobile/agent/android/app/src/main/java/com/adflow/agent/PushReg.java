package com.adflow.agent;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import com.google.firebase.messaging.FirebaseMessaging;
import org.json.JSONObject;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * v139: push registration that does NOT depend on the Capacitor "registration" event (it stopped reaching the server).
 *  - the token comes straight from FirebaseMessaging.getToken()
 *  - posted to {base}{api}push_register from Java (login cookie of the WebView), with platform android4 + app version
 *  - runs on every app start / resume (throttled), on a new token (AlertMessagingService.onNewToken) and from the app (JS)
 *  - the result (time / error) is kept, so "check this phone" and Admin → Phone notifications can show it
 * Server base + API path are the ones the app saved for the ring reports (SoundSync prefs).
 */
public class PushReg {
    static final String PLATFORM = "android4"; // this app has AlertMessagingService (data-only messages, own sound, ring reports)
    static SharedPreferences p(Context c) { return c.getSharedPreferences("af_push", Context.MODE_PRIVATE); }

    static String version(Context c) {
        try { return c.getPackageManager().getPackageInfo(c.getPackageName(), 0).versionName; } catch (Exception e) { return ""; }
    }
    static long code(Context c) {
        try { android.content.pm.PackageInfo i = c.getPackageManager().getPackageInfo(c.getPackageName(), 0); return Build.VERSION.SDK_INT >= 28 ? i.getLongVersionCode() : i.versionCode; } catch (Exception e) { return 0; }
    }

    /** Get the token and register it (background). force = even if it was registered in the last 30 minutes. */
    static void registerNow(Context c, String why, boolean force) {
        final Context app = c.getApplicationContext();
        long last = p(app).getLong("ok_at", 0);
        if (!force && System.currentTimeMillis() - last < 30 * 60_000L) return; // registered in the last 30 min
        try {
            FirebaseMessaging.getInstance().getToken().addOnCompleteListener(t -> {
                if (!t.isSuccessful() || t.getResult() == null) { fail(app, "getToken: " + (t.getException() == null ? "no token" : t.getException().getMessage())); return; }
                post(app, t.getResult(), why);
            });
        } catch (Throwable e) { fail(app, "getToken: " + e.getClass().getSimpleName() + ": " + e.getMessage()); }
    }

    static void fail(Context c, String err) {
        p(c).edit().putString("err", err).putLong("err_at", System.currentTimeMillis()).apply();
        debug(c, "native_" + (err.startsWith("getToken") ? "token" : "register"), err);
    }

    /** POST push_register with this token (background thread). */
    static void post(Context c, String token, String why) {
        final Context app = c.getApplicationContext();
        p(app).edit().putString("token", token).apply();
        new Thread(() -> {
            JSONObject b = new JSONObject();
            try {
                b.put("token", token); b.put("platform", PLATFORM); b.put("native", 1); b.put("why", why);
                b.put("app_version", version(app)); b.put("app_code", code(app)); b.put("device", (Build.MANUFACTURER + " " + Build.MODEL).trim()); b.put("android", Build.VERSION.RELEASE);
            } catch (Exception ignored) { }
            String err = send(app, "push_register", b);
            if (err == null) { p(app).edit().putLong("ok_at", System.currentTimeMillis()).remove("err").apply(); flush(app); }
            else p(app).edit().putString("err", "push_register: " + err).putLong("err_at", System.currentTimeMillis()).apply();
        }).start();
    }

    /** The app's own report of a failed step (push_debug), so the admin sees why a phone is not registered. */
    static void debug(Context c, String stage, String error) {
        final Context app = c.getApplicationContext();
        new Thread(() -> {
            JSONObject b = new JSONObject();
            try { b.put("stage", stage); b.put("error", error); b.put("platform", PLATFORM); b.put("version", version(app)); b.put("device", (Build.MANUFACTURER + " " + Build.MODEL).trim()); } catch (Exception ignored) { }
            send(app, "push_debug", b);
        }).start();
    }

    /** v139: the app saves where the server is and its login token (pushConfig, on every start). */
    static void config(Context c, String base, String api, String auth, String role) {
        SoundSync.remember(c, base, api, null, null);
        SharedPreferences.Editor e = p(c).edit();
        if (auth != null && !auth.isEmpty()) e.putString("auth", auth);
        if (role != null && !role.isEmpty()) e.putString("role", role);
        e.apply();
    }
    /** v139: POST now; if it fails (offline, no server saved yet…) keep it and send it later (max 20 kept). Call from a background thread. */
    static synchronized void sendOrQueue(Context c, String path, JSONObject body) {
        String err = send(c, path, body);
        if (err == null) { flush(c); return; }
        try {
            org.json.JSONArray q = new org.json.JSONArray(p(c).getString("queue", "[]"));
            JSONObject it = new JSONObject(); it.put("path", path); it.put("body", body); it.put("err", err);
            q.put(it);
            while (q.length() > 20) q.remove(0);
            p(c).edit().putString("queue", q.toString()).putString("queue_err", err).apply();
        } catch (Exception ignored) { }
    }
    /** v139: send what was kept (oldest first); stops at the first failure. */
    static synchronized void flush(Context c) {
        try {
            org.json.JSONArray q = new org.json.JSONArray(p(c).getString("queue", "[]"));
            if (q.length() == 0) return;
            org.json.JSONArray left = new org.json.JSONArray();
            boolean stop = false;
            for (int i = 0; i < q.length(); i++) {
                JSONObject it = q.getJSONObject(i);
                if (!stop) { JSONObject b = it.getJSONObject("body"); b.put("queued", 1); if (send(c, it.getString("path"), b) == null) continue; stop = true; }
                left.put(it);
            }
            p(c).edit().putString("queue", left.toString()).apply();
        } catch (Exception ignored) { }
    }
    static int queued(Context c) { try { return new org.json.JSONArray(p(c).getString("queue", "[]")).length(); } catch (Exception e) { return 0; } }

    /** POST {base}{api}<path> with the app's login token / the WebView's login cookie. null = ok, else the error. */
    static String send(Context c, String path, JSONObject body) {
        HttpURLConnection con = null;
        try {
            String base = SoundSync.p(c).getString("base", ""), api = SoundSync.p(c).getString("api", "");
            if (base.isEmpty() || api.isEmpty()) return "no server saved yet (open the app once)";
            String url = base + api + path;
            con = (HttpURLConnection) new URL(url).openConnection();
            con.setConnectTimeout(8000); con.setReadTimeout(8000);
            con.setRequestMethod("POST"); con.setDoOutput(true);
            con.setRequestProperty("Content-Type", "application/json");
            con.setRequestProperty("User-Agent", SoundSync.UA);
            // v139: the app's own login token (saved by the app on every start) first; the WebView cookie as the fallback
            String auth = p(c).getString("auth", "");
            if (!auth.isEmpty()) con.setRequestProperty("Authorization", "Bearer " + auth);
            String ck = SoundSync.cookie(c, url);
            if (ck != null) con.setRequestProperty("Cookie", ck);
            try (OutputStream o = con.getOutputStream()) { o.write(body.toString().getBytes("UTF-8")); }
            int code = con.getResponseCode();
            return code == 200 ? null : "HTTP " + code + (code == 401 ? " (not logged in)" : "");
        } catch (Exception e) { return e.getClass().getSimpleName() + ": " + e.getMessage(); }
        finally { if (con != null) try { con.disconnect(); } catch (Exception ignored) { } }
    }
}
