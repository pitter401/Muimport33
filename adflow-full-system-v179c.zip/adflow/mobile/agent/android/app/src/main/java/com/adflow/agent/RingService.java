package com.adflow.agent;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import androidx.core.app.NotificationCompat;
import org.json.JSONObject;
import java.io.File;

/**
 * v137: plays the alert from a short FOREGROUND service (type mediaPlayback). Vivo / Oppo / Xiaomi silence a plain
 * MediaPlayer started from a background push; a foreground service with a wake lock and alarm audio focus is allowed to sound.
 * Extras: "file" (own sound path) or none = the built-in alert; "alarm" = alarm stream (silent / vibrate) or notification stream;
 * "report" = the ring report JSON to finish and send. If MediaPlayer fails it tries a Ringtone with the same attributes.
 * With an own sound chosen ("own"=true) the built-in sound is NEVER played.
 */
public class RingService extends Service {
    static final String CH = "af_ring";
    static final int NID = 4711;
    private PowerManager.WakeLock wl;
    private MediaPlayer mp;
    private Ringtone rt;
    private AudioManager am;
    private AudioFocusRequest afr;
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean finished = false;
    private JSONObject rep;
    private File file;

    @Override public IBinder onBind(Intent i) { return null; }

    static void start(Context c, File own, boolean ownChosen, boolean alarm, JSONObject report) {
        Intent i = new Intent(c, RingService.class);
        if (own != null) i.putExtra("file", own.getAbsolutePath());
        i.putExtra("own", ownChosen);
        i.putExtra("alarm", alarm);
        i.putExtra("report", report.toString());
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try { startForeground(); }
        catch (Throwable e) {
            // v139: Android 14/15 may refuse a media foreground service from the background → play directly, still report
            final Intent in = intent; final String why = e.getClass().getSimpleName() + ": " + e.getMessage();
            final android.content.Context app = getApplicationContext();
            new Thread(() -> {
                JSONObject r;
                try { r = new JSONObject(in == null || in.getStringExtra("report") == null ? "{}" : in.getStringExtra("report")); } catch (Exception x) { r = new JSONObject(); }
                try {
                    String path = in == null ? null : in.getStringExtra("file");
                    boolean alarm = in == null || in.getBooleanExtra("alarm", true), own = in != null && in.getBooleanExtra("own", false);
                    boolean ok = path != null ? AlertMessagingService.playFile(app, new File(path), alarm, 9000) : !own && AlertMessagingService.playAlarm(app, 9000);
                    r.put("via", "direct"); r.put("service_error", why); r.put("played", ok ? (path != null ? "own" : "builtin") : "none");
                } catch (Exception ignored) { }
                SoundSync.report(app, r);
            }).start();
            stopSelf(); return START_NOT_STICKY;
        }
        if (intent == null) { stop(); return START_NOT_STICKY; }
        try { rep = new JSONObject(intent.getStringExtra("report") == null ? "{}" : intent.getStringExtra("report")); } catch (Exception e) { rep = new JSONObject(); }
        put("via", "service");
        String path = intent.getStringExtra("file");
        file = path == null ? null : new File(path);
        boolean own = intent.getBooleanExtra("own", false), alarm = intent.getBooleanExtra("alarm", true);
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, getPackageName() + ":ring");
            wl.acquire(10_000);
        } catch (Exception ignored) { }
        AudioAttributes aa = new AudioAttributes.Builder().setUsage(alarm ? AudioAttributes.USAGE_ALARM : AudioAttributes.USAGE_NOTIFICATION_RINGTONE).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
        focus(aa);
        Uri uri = file != null ? Uri.fromFile(file) : own ? null : Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.alert);
        if (uri == null) { put("played", "none"); put("error", "own sound chosen but no file on the phone"); finish(); return START_NOT_STICKY; }
        String err = playMedia(uri, aa);
        if (err == null) { put("played", file != null ? "own" : "builtin"); put("player", "mediaplayer"); }
        else if (playRingtone(uri, aa)) { put("played", file != null ? "own" : "builtin"); put("player", "ringtone"); put("error", "mediaplayer: " + err); }
        else {
            if (file != null) SoundSync.drop(this, file); // a broken cached file is downloaded again next time
            put("played", "none"); put("error", "mediaplayer: " + err + "; ringtone failed");
            finish();
        }
        h.postDelayed(this::finish, 9500); // never longer than ~10 s
        return START_NOT_STICKY;
    }

    private void startForeground() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26 && nm != null && nm.getNotificationChannel(CH) == null) {
            NotificationChannel ch = new NotificationChannel(CH, "Alert sound", NotificationManager.IMPORTANCE_MIN);
            ch.setSound(null, null); ch.enableVibration(false); ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
        Notification n = new NotificationCompat.Builder(this, CH).setSmallIcon(R.drawable.ic_stat_alert).setContentTitle("New alert").setPriority(NotificationCompat.PRIORITY_MIN).setSilent(true).setOngoing(true).build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        else startForeground(NID, n);
    }
    private void focus(AudioAttributes aa) {
        try {
            am = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (am == null) return;
            if (Build.VERSION.SDK_INT >= 26) { afr = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT).setAudioAttributes(aa).build(); put("focus", am.requestAudioFocus(afr)); }
            else put("focus", am.requestAudioFocus(null, AudioManager.STREAM_ALARM, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT));
        } catch (Exception ignored) { }
    }
    /** null = playing; else the error. */
    private String playMedia(Uri uri, AudioAttributes aa) {
        try {
            mp = new MediaPlayer();
            mp.setAudioAttributes(aa);
            mp.setDataSource(this, uri);
            mp.setOnCompletionListener(p -> finish());
            mp.setOnErrorListener((p, w, x) -> { put("error", "mediaplayer onError " + w + "/" + x); if (rt == null && !playRingtone(uri, aa)) { put("played", "none"); finish(); } return true; });
            mp.prepare();
            mp.start();
            return null;
        } catch (Exception e) {
            try { if (mp != null) mp.release(); } catch (Exception ignored) { }
            mp = null;
            return e.getClass().getSimpleName() + ": " + e.getMessage();
        }
    }
    private boolean playRingtone(Uri uri, AudioAttributes aa) {
        try {
            rt = RingtoneManager.getRingtone(this, uri);
            if (rt == null) return false;
            if (Build.VERSION.SDK_INT >= 21) rt.setAudioAttributes(aa);
            rt.play();
            h.postDelayed(() -> { if (rt != null && !rt.isPlaying()) finish(); }, 4000);
            return true;
        } catch (Exception e) { rt = null; return false; }
    }
    private void put(String k, Object v) { try { if (rep != null) rep.put(k, v); } catch (Exception ignored) { } }

    private synchronized void finish() {
        if (finished) return;
        finished = true;
        try { if (mp != null) mp.release(); } catch (Exception ignored) { }
        try { if (rt != null) rt.stop(); } catch (Exception ignored) { }
        try { if (am != null) { if (Build.VERSION.SDK_INT >= 26 && afr != null) am.abandonAudioFocusRequest(afr); else am.abandonAudioFocus(null); } } catch (Exception ignored) { }
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Exception ignored) { }
        if (rep != null) SoundSync.report(this, rep);
        stop();
    }
    private void stop() {
        try { if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE); else stopForeground(true); } catch (Exception ignored) { }
        stopSelf();
    }
}
