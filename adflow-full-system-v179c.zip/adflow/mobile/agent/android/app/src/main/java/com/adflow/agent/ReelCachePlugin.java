package com.adflow.agent;

import android.net.Uri;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.File;

/**
 * v168: the page's view of the native Daily-reel downloader (ReelPrefetchWorker). No UI, nothing shown to the user.
 *   has({id, sha256|sha}) → {ok, value}  complete + verified here (sha256 must match when given)
 *   url({id})          → {url}      https://<site>/__reelcache/<id>.mp4 — served by ReelWebViewClient (same origin, Range)
 *   queue({list?})     → {ok}       download now (list = [{id, url, size, sha256}] used when the server can't be reached)
 *   status()           → debugging: files here, last run, last list, errors
 */
@CapacitorPlugin(name = "ReelCache")
public class ReelCachePlugin extends Plugin {

    private File dir() { return ReelPrefetchWorker.dir(getContext()); }

    @PluginMethod
    public void has(PluginCall call) {
        String id = call.getData().has("id") ? call.getData().opt("id").toString() : "";
        String sha = call.getString("sha256", call.getString("sha", "")); // both spellings (native-reel.ts: sha256, cache.ts: sha)
        boolean ok = ReelFetch.validId(id) && ReelFetch.has(dir(), id, sha);
        JSObject r = new JSObject();
        r.put("ok", ok);
        r.put("value", ok); // cache.ts reads .value
        call.resolve(r);
    }

    @PluginMethod
    public void url(PluginCall call) {
        String id = call.getData().has("id") ? call.getData().opt("id").toString() : "";
        JSObject r = new JSObject();
        if (!ReelFetch.validId(id) || !ReelFetch.has(dir(), id, "")) { r.put("url", null); call.resolve(r); return; }
        String[] m = ReelFetch.meta(dir(), id);
        r.put("url", origin() + ReelWebViewClient.PREFIX + id + ".mp4?v=" + (m == null ? "" : m[0].substring(0, Math.min(12, m[0].length()))));
        call.resolve(r);
    }

    @PluginMethod
    public void queue(PluginCall call) {
        JSArray list = call.getArray("list");
        if (list != null && list.length() > 0) ReelPrefetchWorker.p(getContext()).edit().putString("queued", list.toString()).apply();
        ReelPrefetchWorker.schedule(getContext());
        ReelPrefetchWorker.kick(getContext(), "page");
        JSObject r = new JSObject();
        r.put("ok", true);
        call.resolve(r);
    }

    @PluginMethod
    public void status(PluginCall call) {
        android.content.SharedPreferences sp = ReelPrefetchWorker.p(getContext());
        JSObject r = new JSObject();
        JSArray files = new JSArray();
        File[] fs = dir().listFiles();
        if (fs != null) for (File f : fs) {
            JSObject o = new JSObject();
            o.put("name", f.getName()); o.put("size", f.length());
            files.put(o);
        }
        r.put("files", files);
        r.put("run_at", sp.getLong("run_at", 0));
        r.put("done_at", sp.getLong("done_at", 0));
        r.put("list_ok_at", sp.getLong("list_ok_at", 0));
        r.put("kick_at", sp.getLong("kick_at", 0));
        r.put("kick_why", sp.getString("kick_why", ""));
        r.put("last_err", sp.getString("last_err", ""));
        r.put("failed", sp.getString("failed", "{}"));
        r.put("metered", ReelPrefetchWorker.isMetered(getContext()));
        r.put("api", ReelPrefetchWorker.reelApi(getContext()));
        call.resolve(r);
    }

    private String origin() {
        try {
            String s = getBridge().getServerUrl();
            if (s != null) { Uri u = Uri.parse(s); return u.getScheme() + "://" + u.getEncodedAuthority(); }
        } catch (Throwable ignored) { }
        return ReelPrefetchWorker.origin(getContext());
    }
}
