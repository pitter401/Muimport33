package com.adflow.agent;

import android.content.Intent;
import android.net.Uri;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/**
 * Small native helpers for the "get alerts when the app is closed" screen.
 * v96: no in-app APK installer, no battery-exemption request and no opening of other apps' security screens any more —
 * Google Play Protect treats that mix in a sideloaded app as harmful. Updates are downloaded in the phone's browser,
 * and the user changes battery / autostart in the normal settings screens we open here.
 */
@CapacitorPlugin(name = "AppUpdater")
public class AppUpdaterPlugin extends Plugin {

    @PluginMethod
    public void notifStatus(PluginCall call) {
        android.content.Context ctx = getContext();
        JSObject r = new JSObject();
        boolean battery = true;
        try {
            android.os.PowerManager pm = (android.os.PowerManager) ctx.getSystemService(android.content.Context.POWER_SERVICE);
            if (android.os.Build.VERSION.SDK_INT >= 23 && pm != null) battery = pm.isIgnoringBatteryOptimizations(ctx.getPackageName());
        } catch (Exception ignored) { }
        boolean notif = true;
        try { notif = androidx.core.app.NotificationManagerCompat.from(ctx).areNotificationsEnabled(); } catch (Exception ignored) { }
        r.put("battery_ok", battery);
        r.put("notif_on", notif);
        r.put("maker", android.os.Build.MANUFACTURER == null ? "" : android.os.Build.MANUFACTURER.toLowerCase());
        r.put("autostart", false);
        call.resolve(r);
    }

    /** Android's battery optimisation list (no special permission needed) → the user sets this app to "Don't optimise". */
    @PluginMethod
    public void requestBattery(PluginCall call) {
        try {
            // v135: one-tap "Allow" dialog for this app; the full list only if the phone has no such dialog
            Intent i = new Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, android.net.Uri.parse("package:" + getContext().getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try { getContext().startActivity(i); }
            catch (Exception e1) {
                Intent l = new Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
                l.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(l);
            }
        } catch (Exception e) { openDetails(); }
        call.resolve();
    }

    /** Autostart / background: the phone maker's option is in this app's own settings page. */
    @PluginMethod
    public void openAutostart(PluginCall call) {
        openDetails();
        JSObject r = new JSObject();
        r.put("opened", true);
        call.resolve(r);
    }

    /** This app's settings page (Notifications, Battery). */
    @PluginMethod
    public void openAppSettings(PluginCall call) { openDetails(); call.resolve(); }

    private void openDetails() {
        try {
            Intent i = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            i.setData(Uri.parse("package:" + getContext().getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
        } catch (Exception ignored) { }
    }

    /** v103: "new lead sound even on silent" switch (the alarm volume is used, like an alarm clock). */
    @PluginMethod
    public void alarmStatus(PluginCall call) {
        JSObject r = new JSObject();
        r.put("on", AlertMessagingService.alarmOn(getContext()));
        try {
            android.media.AudioManager am = (android.media.AudioManager) getContext().getSystemService(android.content.Context.AUDIO_SERVICE);
            r.put("volume", am.getStreamVolume(android.media.AudioManager.STREAM_ALARM));
            r.put("max", am.getStreamMaxVolume(android.media.AudioManager.STREAM_ALARM));
            r.put("ringer", am.getRingerMode() == android.media.AudioManager.RINGER_MODE_NORMAL ? "normal" : am.getRingerMode() == android.media.AudioManager.RINGER_MODE_VIBRATE ? "vibrate" : "silent");
        } catch (Exception ignored) { }
        call.resolve(r);
    }

    @PluginMethod
    public void setAlarm(PluginCall call) {
        AlertMessagingService.setAlarmOn(getContext(), Boolean.TRUE.equals(call.getBoolean("on", true)));
        call.resolve();
    }

    /** Plays the alert once on the alarm volume (to check it is loud enough). */
    /** v134: the chat was opened → its notification goes (WhatsApp-like). */
    @PluginMethod
    public void clearChat(PluginCall call) {
        AlertMessagingService.clearChat(getContext(), call.getString("lead", ""));
        call.resolve();
    }
    @PluginMethod
    public void clearAllChats(PluginCall call) {
        AlertMessagingService.clearAll(getContext());
        call.resolve();
    }

    @PluginMethod
    public void testAlarm(PluginCall call) {
        final android.content.Context c = getContext().getApplicationContext();
        new Thread(() -> AlertMessagingService.playAlarm(c, 0)).start();
        call.resolve();
    }

    /** v139: the FCM token straight from Firebase (no Capacitor event needed). */
    @PluginMethod
    public void fcmToken(PluginCall call) {
        try {
            com.google.firebase.messaging.FirebaseMessaging.getInstance().getToken().addOnCompleteListener(t -> {
                if (!t.isSuccessful() || t.getResult() == null) { call.reject("getToken failed: " + (t.getException() == null ? "no token" : t.getException().getMessage())); return; }
                JSObject r = new JSObject();
                r.put("token", t.getResult());
                call.resolve(r);
            });
        } catch (Throwable e) { call.reject("getToken failed: " + e.getMessage()); }
    }
    /** v139: what this app is for the server: android4 = our own push receiver (data-only alerts, own sound, ring reports). */
    @PluginMethod
    public void pushPlatform(PluginCall call) {
        JSObject r = new JSObject();
        r.put("platform", PushReg.PLATFORM);
        r.put("version", PushReg.version(getContext()));
        r.put("code", PushReg.code(getContext()));
        r.put("device", (android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL).trim());
        call.resolve(r);
    }
    /** v139: the native registration state (for "check this phone"). */
    @PluginMethod
    public void pushStatus(PluginCall call) {
        android.content.SharedPreferences sp = PushReg.p(getContext());
        JSObject r = new JSObject();
        r.put("platform", PushReg.PLATFORM);
        r.put("ok_at", sp.getLong("ok_at", 0));
        r.put("err", sp.getString("err", ""));
        r.put("err_at", sp.getLong("err_at", 0));
        String tk = sp.getString("token", "");
        r.put("token_end", tk.length() > 8 ? tk.substring(tk.length() - 8) : tk);
        r.put("snd_ver", SoundSync.p(getContext()).getString("ver", ""));
        java.io.File g = SoundSync.lastGood(getContext());
        r.put("snd_file", g == null ? "" : g.getName());
        r.put("server", SoundSync.p(getContext()).getString("base", ""));
        r.put("auth", !sp.getString("auth", "").isEmpty());
        r.put("queued", PushReg.queued(getContext()));
        r.put("queue_err", sp.getString("queue_err", ""));
        call.resolve(r);
    }
    /** v139: the app saves the server + its login token on every start (native registration + ring reports use them). */
    @PluginMethod
    public void pushConfig(PluginCall call) {
        PushReg.config(getContext(), call.getString("base", ""), call.getString("api", ""), call.getString("auth", ""), call.getString("role", ""));
        new Thread(() -> PushReg.flush(getContext().getApplicationContext())).start();
        PushReg.registerNow(getContext(), "config", false);
        JSObject r = new JSObject();
        r.put("queued", PushReg.queued(getContext()));
        call.resolve(r);
    }
    /** v139: "Re-register this phone" — new token request + POST from Java right now. */
    @PluginMethod
    public void reRegister(PluginCall call) { PushReg.registerNow(getContext(), "button", true); call.resolve(); }
    /** v139: "Test ring on this phone" — the same path as a real new-lead alert (RingService, own sound if chosen, alarm volume on silent). */
    @PluginMethod
    public void testRing(PluginCall call) {
        final android.content.Context c = getContext().getApplicationContext();
        new Thread(() -> {
            java.util.Map<String, String> d = new java.util.HashMap<>();
            String ver = SoundSync.p(c).getString("ver", ""), url = SoundSync.p(c).getString("url", "");
            d.put("alarm", "1"); d.put("test", "1"); if (!ver.isEmpty()) d.put("snd", ver);
            org.json.JSONObject rep = SoundSync.baseReport(c, d);
            try {
                rep.put("kind", "test_phone");
                java.io.File own = null; String[] err = new String[1]; boolean[] dl = new boolean[1];
                if (!ver.isEmpty()) own = SoundSync.resolve(c, ver, url, err, dl);
                if (err[0] != null) rep.put("own_sound_error", err[0]);
                if (!ver.isEmpty() && own == null) { rep.put("played", "none"); rep.put("error", "own sound chosen but not on the phone"); SoundSync.report(c, rep); return; }
                RingService.start(c, own, !ver.isEmpty(), !AlertMessagingService.ringerNormal(c), rep);
            } catch (Exception e) { AlertMessagingService.playAlarm(c, 0); }
        }).start();
        call.resolve();
    }

    /** v137: the app tells the native side where the server is (ring reports) and which own sound is current. */
    @PluginMethod
    public void soundConfig(PluginCall call) {
        SoundSync.remember(getContext(), call.getString("base", ""), call.getString("api", ""), call.getString("snd", null), call.getString("snd_url", null));
        PushReg.registerNow(getContext(), "config", false); // v139: the server is known now → register this phone (if not done in the last 30 min)
        JSObject r = new JSObject();
        String v = call.getString("snd", "");
        java.io.File f = v == null || v.isEmpty() ? null : SoundSync.fileFor(getContext(), v);
        String bv = SoundSync.bundledVer(getContext());
        r.put("have", f != null && f.exists() && f.length() > 0 || (!bv.isEmpty() && bv.equals(v)));
        r.put("bundled", bv);
        call.resolve(r);
    }
    /** v137: the own sound fetched by the app (same origin, so no Cloudflare block) → saved for alerts while the app is closed. */
    @PluginMethod
    public void saveSound(PluginCall call) {
        boolean ok = false;
        try { ok = SoundSync.save(getContext(), call.getString("ver", ""), android.util.Base64.decode(call.getString("data", ""), android.util.Base64.DEFAULT)); } catch (Exception ignored) { }
        JSObject r = new JSObject();
        r.put("ok", ok);
        call.resolve(r);
    }

    /** v142: status bar + nav bar colour from the page: { dark: true = dark icons (light page), color: '#rrggbb', navColor?, navDark? }.
     *  Resolves { ok, insets: true } → the page knows the app keeps it out from under the bars (no web strip needed). */
    @PluginMethod
    public void setBars(PluginCall call) {
        final boolean dark = Boolean.TRUE.equals(call.getBoolean("dark", false));
        final int color = BarStyle.parse(call.getString("color", null), dark ? 0xFFF1F3F6 : 0xFF0E1621);
        final boolean navDark = Boolean.TRUE.equals(call.getBoolean("navDark", dark));
        final int navColor = BarStyle.parse(call.getString("navColor", null), color);
        final android.app.Activity act = getActivity();
        if (act == null) { call.reject("no activity"); return; }
        act.runOnUiThread(() -> {
            try {
                BarStyle.apply(act, dark, color, navDark, navColor, true);
                JSObject r = new JSObject();
                r.put("ok", true);
                r.put("insets", true);
                call.resolve(r);
            } catch (Exception e) { call.reject(String.valueOf(e.getMessage())); }
        });
    }
}
