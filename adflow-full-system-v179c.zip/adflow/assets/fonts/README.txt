Inter (SIL Open Font License 1.1, rsms.me/inter) — used to draw the ad-account proof images on the server.
