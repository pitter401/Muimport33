#!/usr/bin/env bash
# One-time VPS setup (Ubuntu 22.04 / 24.04). Run from the project folder:
#   sudo bash scripts/setup-vps.sh yourdomain.com you@email.com
set -euo pipefail
DOMAIN="${1:-}"; EMAIL="${2:-}"
[ -z "$DOMAIN" ] && { echo "Usage: sudo bash scripts/setup-vps.sh yourdomain.com you@email.com"; exit 1; }
APPDIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$APPDIR"
echo "==> Project: $APPDIR   Domain: $DOMAIN"

echo "==> System packages"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y curl ca-certificates gnupg build-essential python3 nginx sqlite3 unzip ffmpeg
if ! command -v node >/dev/null || [ "$(node -p 'process.versions.node.split(".")[0]')" -lt 20 ]; then
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
  apt-get install -y nodejs
fi
npm i -g pm2@5

echo "==> .env"
[ -f .env ] || cp .env.example .env
grep -q '^APP_SECRET=.\+' .env || sed -i "s|^APP_SECRET=.*|APP_SECRET=$(openssl rand -hex 32)|" .env
IS_IP=0; [[ "$DOMAIN" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] && IS_IP=1
if [ "$IS_IP" = 1 ]; then
  sed -i "s|^PUBLIC_URL=.*|PUBLIC_URL=http://$DOMAIN|" .env
  grep -q '^INSECURE_COOKIES=' .env || echo "INSECURE_COOKIES=1" >> .env
else
  sed -i "s|^PUBLIC_URL=.*|PUBLIC_URL=https://$DOMAIN|" .env
  sed -i '/^INSECURE_COOKIES=/d' .env
fi
if grep -q '^ADMIN_PASSWORD=change-me-now' .env; then
  PW=$(openssl rand -base64 12 | tr -d '/+=' | cut -c1-12)
  sed -i "s|^ADMIN_PASSWORD=.*|ADMIN_PASSWORD=$PW|" .env
  echo "    Admin password generated: $PW   (saved in .env — change it inside the Admin app later)"
fi
mkdir -p data /var/www/adflow-downloads

echo "==> Install & build"
npm ci
npm run build

echo "==> Start with PM2"
pm2 delete adflow-web adflow-worker >/dev/null 2>&1 || true
pm2 start ecosystem.config.cjs --update-env
pm2 save
pm2 startup systemd -u root --hp /root >/dev/null 2>&1 || true

echo "==> Nginx"
sed -e "s|DOMAIN|$DOMAIN|g" -e "s|APPDIR|$APPDIR|g" deploy/nginx.conf > /etc/nginx/sites-available/adflow
ln -sf /etc/nginx/sites-available/adflow /etc/nginx/sites-enabled/adflow
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx

echo "==> HTTPS certificate"
if [ "$IS_IP" = 1 ]; then echo "    IP mode — HTTPS skipped (domain lene ke baad script dobara chalao)"
else
apt-get install -y certbot python3-certbot-nginx
if [ -n "$EMAIL" ]; then certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos -m "$EMAIL" --redirect || echo "!! certbot failed — check that $DOMAIN points to this server, then run: certbot --nginx -d $DOMAIN"
else certbot --nginx -d "$DOMAIN" --redirect || true; fi
fi

echo "==> Daily database backup (03:30)"
( crontab -l 2>/dev/null | grep -v 'adflow-backup' || true ; echo "30 3 * * * cd $APPDIR && bash scripts/backup.sh >> data/backup.log 2>&1 # adflow-backup" ) | crontab - || true

echo
echo "✅ Done!"
P=https; [ "$IS_IP" = 1 ] && P=http
echo "   Website:   $P://$DOMAIN"
echo "   Admin app: $P://$DOMAIN/admin   (username: admin, password in .env)"
echo "   Agent app: $P://$DOMAIN/agent"
echo "   Logs:      pm2 logs"
