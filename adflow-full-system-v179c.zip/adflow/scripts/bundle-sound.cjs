#!/usr/bin/env node
// v137: put the admin's own notification sound INTO the APK, so every phone has it right after the update (no app open,
// no download). Usage: node scripts/bundle-sound.cjs <DB_PATH> <android/app/src/main/assets dir>
// Writes own_sound.<ext> + own_sound_ver.txt (version = the notif_sound_ver setting). No own sound → both are removed.
const fs = require('fs'), path = require('path');
const [dbPath, out] = process.argv.slice(2);
if (!dbPath || !out) { console.error('usage: bundle-sound.cjs <DB_PATH> <assets dir>'); process.exit(2); }
fs.mkdirSync(out, { recursive: true });
for (const f of fs.readdirSync(out)) if (f.startsWith('own_sound')) fs.unlinkSync(path.join(out, f));
let st = {};
try {
  const Database = require(path.join(__dirname, '..', 'node_modules', 'better-sqlite3'));
  const db = new Database(dbPath, { readonly: true, fileMustExist: true });
  for (const r of db.prepare("SELECT k, v FROM settings WHERE k IN ('notif_sound','notif_sound_file','notif_sound_ver')").all()) st[r.k] = r.v;
  db.close();
} catch (e) { console.log('   (sound: could not read the database: ' + e.message + ' — nothing bundled)'); process.exit(0); }
const src = st.notif_sound_file ? path.join(path.dirname(dbPath), 'brand', st.notif_sound_file) : '';
if (st.notif_sound !== 'own' || !src || !fs.existsSync(src)) { console.log('   sound: built-in (no own sound bundled)'); process.exit(0); }
const ext = path.extname(src).slice(1).toLowerCase() || 'snd';
fs.copyFileSync(src, path.join(out, 'own_sound.' + ext));
fs.writeFileSync(path.join(out, 'own_sound_ver.txt'), String(st.notif_sound_ver || '1'));
console.log(`   sound: own sound bundled (own_sound.${ext}, version ${st.notif_sound_ver || '1'})`);
