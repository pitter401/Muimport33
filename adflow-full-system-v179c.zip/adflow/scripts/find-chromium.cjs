// v168: finds a headless Chromium for the status-video renderer (used by src/server/reelrender.ts and scripts/update.sh).
// Order (owner's VPS also runs other Playwright / Camoufox projects; nothing here deletes or upgrades their browsers):
//   0. REEL_CHROMIUM_PATH (explicit)
//   1. our own playwright-core's browser (the revision in node_modules/playwright-core/browsers.json), headless shell first
//   2. any other Chromium in the Playwright cache (~/.cache/ms-playwright or PLAYWRIGHT_BROWSERS_PATH), newest first
//   3. a system browser: /usr/bin/chromium, /usr/bin/chromium-browser, google-chrome
// CLI: node scripts/find-chromium.cjs → prints "<source>\t<path>" and exits 0, or exits 1 when none is found.
const fs = require('fs');
const os = require('os');
const path = require('path');

const isFile = p => { try { return fs.statSync(p).isFile(); } catch { return false; } };
const SHELL = ['chrome-headless-shell-linux64/chrome-headless-shell', 'chrome-linux/headless_shell'];
const FULL = ['chrome-linux64/chrome', 'chrome-linux/chrome'];

function ourRevisions(appDir) {
  try {
    const j = JSON.parse(fs.readFileSync(path.join(appDir, 'node_modules', 'playwright-core', 'browsers.json'), 'utf8'));
    const r = n => (j.browsers.find(b => b.name === n) || {}).revision;
    return { shell: r('chromium-headless-shell'), full: r('chromium') };
  } catch { return {}; }
}

function findChromium(appDir = process.cwd()) {
  const env = process.env.REEL_CHROMIUM_PATH;
  if (env) return isFile(env) ? { source: 'REEL_CHROMIUM_PATH', path: env } : null;
  const roots = [...new Set([process.env.PLAYWRIGHT_BROWSERS_PATH, path.join(os.homedir(), '.cache', 'ms-playwright'), '/root/.cache/ms-playwright'].filter(x => x && x !== '0'))];
  const rev = ourRevisions(appDir);
  // 1. our own revision
  for (const r of roots) {
    if (rev.shell) for (const c of SHELL) { const p = path.join(r, `chromium_headless_shell-${rev.shell}`, c); if (isFile(p)) return { source: `playwright-core (own, headless shell ${rev.shell})`, path: p }; }
    if (rev.full) for (const c of FULL) { const p = path.join(r, `chromium-${rev.full}`, c); if (isFile(p)) return { source: `playwright-core (own, chromium ${rev.full})`, path: p }; }
  }
  // 2. any other Playwright Chromium (another project's), newest first
  const ver = n => Number((/-(\d+)$/.exec(n) || [])[1] || 0);
  for (const r of roots) {
    let names = [];
    try { names = fs.readdirSync(r); } catch { continue; }
    const pick = (re, cands, label) => {
      for (const n of names.filter(x => re.test(x)).sort((a, b) => ver(b) - ver(a))) for (const c of cands) { const p = path.join(r, n, c); if (isFile(p)) return { source: `${label} ${n} (shared Playwright cache)`, path: p }; }
      return null;
    };
    const f = pick(/^chromium_headless_shell-\d+$/, SHELL, 'headless shell') || pick(/^chromium-\d+$/, FULL, 'chromium');
    if (f) return f;
  }
  // 3. system browsers
  for (const p of ['/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/google-chrome-stable', '/usr/bin/google-chrome', '/opt/google/chrome/chrome']) if (isFile(p)) return { source: 'system', path: p };
  return null;
}

module.exports = { findChromium };
if (require.main === module) {
  const f = findChromium(path.resolve(__dirname, '..'));
  if (f) { console.log(`${f.source}\t${f.path}`); process.exit(0); }
  process.exit(1);
}
