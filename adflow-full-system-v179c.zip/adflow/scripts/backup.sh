#!/usr/bin/env bash
# Safe SQLite backup, keeps the last 14 days
set -euo pipefail
cd "$(dirname "$0")/.."
DB="${DB_PATH:-data/adflow.db}"
mkdir -p backups
[ -f "$DB" ] && sqlite3 "$DB" ".backup 'backups/adflow-$(date +%F).db'"
find backups -name 'adflow-*.db' -mtime +14 -delete
echo "$(date) backup ok"
