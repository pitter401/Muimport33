#!/usr/bin/env bash
# Builds the two Android apps (Agent + Admin) on the VPS.
#   1. (for notifications) put your Firebase file at:  mobile/google-services.json
#   2. sudo bash scripts/build-apk.sh
# Result: https://yourdomain/downloads/agent.apk and https://yourdomain/downloads/admin.apk
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
set -a; source .env; set +a
: "${PUBLIC_URL:?Set PUBLIC_URL in .env first}"
SDK="${ANDROID_HOME:-/opt/android-sdk}"

echo "==> Java 21"
if ! java -version 2>&1 | grep -q 'version "21'; then apt-get update -y && apt-get install -y openjdk-21-jdk-headless unzip; fi
export JAVA_HOME="$(dirname "$(dirname "$(readlink -f "$(command -v java)")")")"

echo "==> Android SDK ($SDK)"
if [ ! -x "$SDK/cmdline-tools/latest/bin/sdkmanager" ]; then
  mkdir -p "$SDK/cmdline-tools" && cd /tmp
  curl -fsSL -o cmdtools.zip https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
  rm -rf cmdline-tools && unzip -q cmdtools.zip && rm -rf "$SDK/cmdline-tools/latest" && mv cmdline-tools "$SDK/cmdline-tools/latest"
  cd "$ROOT"
fi
export ANDROID_HOME="$SDK" ANDROID_SDK_ROOT="$SDK"
yes | "$SDK/cmdline-tools/latest/bin/sdkmanager" --licenses >/dev/null || true
"$SDK/cmdline-tools/latest/bin/sdkmanager" "platform-tools" "platforms;android-35" "build-tools;35.0.0" >/dev/null

echo "==> Signing key (keep mobile/release.keystore safe — app updates need the same key)"
KS="$ROOT/mobile/release.keystore"
if [ ! -f "$KS" ]; then
  KSPASS=$(openssl rand -hex 12)
  keytool -genkeypair -v -keystore "$KS" -alias adflow -keyalg RSA -keysize 2048 -validity 10000 -storepass "$KSPASS" -keypass "$KSPASS" -dname "CN=AdFlow, O=AdFlow, C=IN" >/dev/null
  echo "$KSPASS" > "$ROOT/mobile/release.keystore.pass"
fi
KSPASS=$(cat "$ROOT/mobile/release.keystore.pass")

DL=/var/www/adflow-downloads
mkdir -p "$DL"

# Every build gets a higher version number → the apps show "Update" (Admin + Agent app read /api/app-version)
LAST=$(node -e 'try{console.log(JSON.parse(require("fs").readFileSync(process.argv[1],"utf8")).code||0)}catch{console.log(0)}' "$DL/version.json")
GRADLE=$(grep -oP 'versionCode \K[0-9]+' "$ROOT/mobile/agent/android/app/build.gradle" | head -1)
CODE=$(( LAST + 1 > GRADLE ? LAST + 1 : GRADLE ))
VNAME="1.$(( CODE - 1 ))"
echo "==> Version $VNAME (code $CODE)"
for APP in agent admin; do
  sed -i -E "s/versionCode [0-9]+/versionCode $CODE/; s/versionName \"[^\"]*\"/versionName \"$VNAME\"/" "$ROOT/mobile/$APP/android/app/build.gradle"
done
for APP in agent admin; do
  echo "==> Building $APP app"
  cd "$ROOT/mobile/$APP"
  NAME_VAR="APP_NAME_${APP^^}"; NAME="${!NAME_VAR:-}"
  node -e '
    const fs=require("fs"); const [url, name]=process.argv.slice(1);
    const c=JSON.parse(fs.readFileSync("capacitor.config.json","utf8"));
    const path=c.server.url.replace(/^https?:\/\/[^/]+/,"");
    c.server.url=url.replace(/\/$/,"")+path; c.server.allowNavigation=[new URL(url).host];
    if(name) c.appName=name;
    fs.writeFileSync("capacitor.config.json", JSON.stringify(c,null,2));
    const sx="android/app/src/main/res/values/strings.xml";
    if(name&&fs.existsSync(sx)){let s=fs.readFileSync(sx,"utf8");s=s.replace(/<string name="app_name">[^<]*</,`<string name="app_name">${name}<`).replace(/<string name="title_activity_main">[^<]*</,`<string name="title_activity_main">${name}<`);fs.writeFileSync(sx,s);}
  ' "$PUBLIC_URL" "$NAME"
  # launcher icon: the site logo + "ADMIN" / "AGENT" (made by the server: /brand/app-icon.png)
  RES=android/app/src/main/res; TMPI=$(mktemp -d); OKI=1
  for D in mdpi:48 hdpi:72 xhdpi:96 xxhdpi:144 xxxhdpi:192; do
    DN=${D%%:*}; PX=${D##*:}
    for P in "ic_launcher:square" "ic_launcher_round:round" "ic_launcher_background:full" "ic_launcher_foreground:clear"; do
      curl -fsS -o "$TMPI/$DN-${P%%:*}.png" "$PUBLIC_URL/brand/app-icon.png?app=$APP&size=$PX&shape=${P##*:}&v=$(date +%s)" || OKI=0
    done
  done
  if [ "$OKI" = 1 ]; then
    for D in mdpi hdpi xhdpi xxhdpi xxxhdpi; do for N in ic_launcher ic_launcher_round ic_launcher_background ic_launcher_foreground; do cp "$TMPI/$D-$N.png" "$RES/mipmap-$D/$N.png"; done; done
    echo "   icon: logo ($APP)"
  else echo "   (could not get the icon from $PUBLIC_URL/brand/app-icon.png — keeping the old icon)"; fi
  # v153: the small notification icon (phone top bar) = white shape of the logo (Android shows only the shape)
  for D in mdpi:24 hdpi:36 xhdpi:48 xxhdpi:72 xxxhdpi:96; do
    DN=${D%%:*}; PX=${D##*:}; mkdir -p "$RES/drawable-$DN"
    curl -fsS -o "$TMPI/stat-$DN.png" "$PUBLIC_URL/brand/stat-icon.png?size=$PX&v=$(date +%s)" && cp "$TMPI/stat-$DN.png" "$RES/drawable-$DN/ic_stat_alert.png" || echo "   (no notification icon for $DN — the bell stays)"
  done
  rm -rf "$TMPI"
  [ -f "$ROOT/mobile/google-services.json" ] && cp "$ROOT/mobile/google-services.json" android/app/google-services.json || echo "   (no mobile/google-services.json — app works, but phone push notifications stay off)"
  # v137: the admin's own notification sound goes into the APK (phones have it right after the update)
  node "$ROOT/scripts/bundle-sound.cjs" "${DB_PATH:-$ROOT/data/adflow.db}" "android/app/src/main/assets" || true
  npm ci --no-audit --no-fund >/dev/null
  npx cap sync android
  cd android
  chmod +x gradlew
  ./gradlew --no-daemon assembleRelease \
    -Pandroid.injected.signing.store.file="$KS" -Pandroid.injected.signing.store.password="$KSPASS" \
    -Pandroid.injected.signing.key.alias=adflow -Pandroid.injected.signing.key.password="$KSPASS"
  cp app/build/outputs/apk/release/app-release.apk "$DL/$APP.apk"
  echo "   ✅ $DL/$APP.apk"
done
# v167: "v167" = the first build with the Daily reel WebView setting; apps older than it must update (Admin → System → Force update)
V167=$(node -e 'try{const v=JSON.parse(require("fs").readFileSync(process.argv[1],"utf8"));console.log(v.v167||"")}catch{console.log("")}' "$DL/version.json")
[ -z "$V167" ] && V167=$CODE
# v168: "v168" = the first build with the background Daily-reel downloader (ReelPrefetchWorker); it becomes the force-update minimum
V168=$(node -e 'try{const v=JSON.parse(require("fs").readFileSync(process.argv[1],"utf8"));console.log(v.v168||"")}catch{console.log("")}' "$DL/version.json")
[ -z "$V168" ] && V168=$CODE
echo "{\"code\":$CODE,\"name\":\"$VNAME\",\"at\":$(date +%s)000,\"v167\":$V167,\"v168\":$V168}" > "$DL/version.json"
chmod -R a+rX "$DL"
echo
echo "✅ APKs ready (version $VNAME) — open apps will show an Update bar:"
echo "   Agent app: $PUBLIC_URL/downloads/agent.apk"
echo "   Admin app: $PUBLIC_URL/downloads/admin.apk"
