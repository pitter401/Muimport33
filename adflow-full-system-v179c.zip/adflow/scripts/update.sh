#!/usr/bin/env bash
# After uploading a new version of the files: bash scripts/update.sh
set -euo pipefail
cd "$(dirname "$0")/.."
# ffmpeg: AI voice notes (room sound + Telegram voice format). Installed once; the update goes on even if this fails.
if ! command -v ffmpeg >/dev/null 2>&1; then
  echo "==> Installing ffmpeg (once, for AI voice notes)"
  if [ "$(id -u)" = 0 ]; then SUDO=""; else SUDO="sudo -n"; fi
  ( export DEBIAN_FRONTEND=noninteractive; timeout 300 $SUDO apt-get install -y -q ffmpeg || { timeout 180 $SUDO apt-get update -q && timeout 300 $SUDO apt-get install -y -q ffmpeg; } ) || echo "⚠️ ffmpeg could not be installed — voice notes go out without room sound. Run: apt-get install -y ffmpeg"
fi
npm ci
# v173: build into .next-new while the live site keeps serving from .next, then swap → no 502 while it builds.
# A build stopped by a signal (exit >= 128, e.g. "Terminated") is tried once more before the update fails.
rm -rf .next-new
# the build cache of the live version → a warm build (faster, less memory)
if [ -d .next/cache ]; then mkdir -p .next-new && cp -a .next/cache .next-new/ 2>/dev/null || true; fi
code=0
NEXT_DIST_DIR=.next-new npm run build || code=$?
if [ "$code" -ne 0 ]; then
  if [ "$code" -ge 128 ] || grep -qiE 'Terminated|SIGTERM|SIGKILL|Killed|signal' "${JOBLOG:-/dev/null}" 2>/dev/null; then
    echo "==> The build was stopped (exit $code). Trying once more…"
    rm -rf .next-new
    NEXT_DIST_DIR=.next-new npm run build
  else exit "$code"; fi
fi
rm -rf .next-old
if [ -d .next ]; then mv .next .next-old; fi
mv .next-new .next
pm2 reload ecosystem.config.cjs --update-env
pm2 save
rm -rf .next-old
# v168: headless Chromium for the automatic status videos. Uses one that is already there (our playwright-core's own, another
# project's Playwright Chromium, or a system Chromium — see scripts/find-chromium.cjs); installs Playwright's small "headless
# shell" (~110 MB) only when there is none. Never removes or upgrades other projects' browsers (--no-remove) and never touches
# global npm. Runs AFTER the new version is built and live (v168 senior review), so a slow download never delays the update.
# NEVER fails the update: without a renderer, Admin → Status video says "Renderer not installed" with a Retry button.
(
  set +e
  export PLAYWRIGHT_SKIP_BROWSER_GC=1 # belt and braces with --no-remove: never delete any other project's browsers
  if PW_FOUND=$(node scripts/find-chromium.cjs 2>/dev/null); then
    echo "==> Status-video renderer: using ${PW_FOUND%%$'\t'*} (${PW_FOUND#*$'\t'})"
  else
    echo "==> Installing the status-video renderer (headless Chromium, once)"
    if [ "$(id -u)" = 0 ]; then timeout 600 npx --no-install playwright-core install-deps chromium-headless-shell >/tmp/adflow-pw-deps.log 2>&1 && echo "    system libraries ok" || echo "    system libraries: skipped (see /tmp/adflow-pw-deps.log)"; fi
    if timeout 900 npx --no-install playwright-core install --no-remove --only-shell chromium >/tmp/adflow-pw.log 2>&1 && PW_FOUND=$(node scripts/find-chromium.cjs 2>/dev/null); then echo "    renderer ready: ${PW_FOUND#*$'\t'}"
    else echo "⚠️ The status-video renderer could not be installed (see /tmp/adflow-pw.log). The update goes on; use Admin → Status video → Retry install."; fi
  fi
) || true
echo "✅ Updated"
