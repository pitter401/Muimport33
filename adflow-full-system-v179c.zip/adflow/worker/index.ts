import { ensureWebhookUpdates } from '@/server/telegram';
/**
 * Background jobs (runs as its own process next to the website — see ecosystem.config.cjs)
 *  - Follow-ups: 12h → 16h → 24h reminders to agents, 48h → Dead
 *  - Retries Meta Conversions API events that failed (same event_id, so never duplicated)
 */
import fs from 'fs';
import path from 'path';
import { all, run } from '@/server/db';
import { getSettings, setSetting, pixelFor } from '@/server/settings';
import { runFollowups, sendDueWelcomes, pickAgent, ownerFor, addMsg, agentById, notifyAgent, linkChatToForm } from '@/server/crm';
import { ensureAutoSpend } from '@/server/profit';
import { aiAutoTick } from '@/server/ai';
import { autoContactTick, outboxTick, phoneJobTick, folderTick, muteTick, contactsTick, readTick, seenTick, unarchiveTick, approvePendingJoins } from '@/server/userbot';
import { attachWebLead } from '@/server/shop';
import { runReassign } from '@/server/crm';
import { deliver } from '@/server/capi';
import { metaTick } from '@/server/meta';
import { watchdogNotify } from '@/server/watchdog';
import { subscribeDue, channelChat } from '@/server/channel';

// Load .env (Next.js does this for the website; the worker runs on its own)
try {
  for (const line of fs.readFileSync(path.join(process.cwd(), '.env'), 'utf8').split('\n')) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
} catch { /* no .env */ }

const log = (...a: unknown[]) => console.log(new Date().toISOString(), '[worker]', ...a);

async function followups() {
  try { const n = await runFollowups(true); if (n) log(`follow-ups updated: ${n}`); } catch (e) { log('follow-up error', e); }
  try { const { runBotFollowups } = await import('@/server/crm'); const n = await runBotFollowups(); if (n) log(`bot reminders sent: ${n}`); } catch (e) { log('bot reminder error', e); }
}

async function retryCapi() {
  try {
    const s = getSettings();
    if (!s.pixel_id || !s.capi_token) return;
    const t = Date.now();
    // failed events (max 4 tries, Meta accepts events up to 7 days old) + events stuck in "pending" after a crash
    const rows = all<{ event_id: string; payload: string; line: string | null }>(
      "SELECT event_id, payload, line FROM capi_log WHERE payload IS NOT NULL AND created_at > ? AND ((status='error' AND tries < 4) OR (status='pending' AND created_at < ?)) ORDER BY created_at LIMIT 50",
      t - 6 * 86400000, t - 5 * 60000);
    for (const r of rows) {
      const ev = JSON.parse(r.payload);
      const res = await deliver(pixelFor(s, r.line), r.event_id, ev);
      log(`capi retry ${r.event_id}: ${res.status}`);
    }
    // events that were "skipped" because CAPI was not configured yet are not sent later on purpose (would be stale)
  } catch (e) { log('capi retry error', e); }
}

function cleanup() {
  try { run('DELETE FROM relay WHERE rowid IN (SELECT rowid FROM relay ORDER BY rowid DESC LIMIT -1 OFFSET 200000)'); } catch { /* ignore */ }
}

let busyContact = false;
async function autoContact() {
  if (busyContact) return; busyContact = true;
  try {
    const r = await autoContactTick({
      pickAgent: (sv, ln, l) => (l ? ownerFor(l) : pickAgent(sv, ln)), addMsg, linkExisting: linkChatToForm,
      notify: (leadId, agentId, title, body) => notifyAgent(agentById(agentId), `${title}\n${body}`, leadId, { title, body }),
    });
    if (r) log('auto first message', r);
  } catch (e) { log('auto message error', e); } finally { busyContact = false; }
}
let busyOut = false;
async function outbox() {
  if (busyOut) return; busyOut = true;
  try { await outboxTick(); } catch (e) { log('outbox error', e); } finally { busyOut = false; }
}
let busyWelcome = false;
async function welcomes() {
  if (busyWelcome) return; busyWelcome = true;
  try { await sendDueWelcomes(); } catch (e) { log('welcome error', e); } finally { busyWelcome = false; }
}

let busyPhone = false;
async function phoneJobs() {
  if (busyPhone) return; busyPhone = true;
  try { const r = await phoneJobTick(attachWebLead); if (r) log('telegram delivery message', r); } catch (e) { log('phone job error', e); } finally { busyPhone = false; }
}

let busyFolders = false;
async function folders() {
  if (busyFolders) return; busyFolders = true;
  try { const r = await folderTick(); if (r) log('chat folders', r); } catch (e) { log('folders error', e); } finally { busyFolders = false; }
}

let busyMute = false;
async function mutes() {
  if (busyMute) return; busyMute = true;
  try { const r = await muteTick(); if (r) log('mute', r); } catch (e) { log('mute error', e); } finally { busyMute = false; }
}

async function aiAuto() {
  try { const n = await aiAutoTick(); if (n) log('ai replies', n); } catch (e) { log('ai error', e); }
}
let busyRead = false;
async function reads() {
  if (busyRead) return; busyRead = true;
  try { await readTick(); } catch (e) { log('read ticks error', e); } finally { busyRead = false; }
}
let busySeen = false;
async function seen() {
  if (busySeen) return; busySeen = true;
  try { await seenTick(); } catch (e) { log('last seen error', e); } finally { busySeen = false; }
}
let busyContacts = false;
async function contacts() {
  if (busyContacts) return; busyContacts = true;
  try { const r = await contactsTick(); if (r) log('contacts', r); } catch (e) { log('contacts error', e); } finally { busyContacts = false; }
}
async function reassign() {
  try { const n = await runReassign(); if (n) log(`leads moved to next agent: ${n}`); } catch (e) { log('reassign error', e); }
}

async function meta() {
  try { const n = await metaTick(); if (n) log(`meta BMs synced: ${n}`); } catch (e) { log('meta error', e); }
}

function adSpend() { try { ensureAutoSpend(getSettings()); } catch (e) { log('ad spend error', e); } }

log('started');
setInterval(adSpend, 600_000);
// v167: Daily reel — the shipped seed video once, and a finished day's video files deleted (00:00 IST) — at start and every 10 min
const reelTickRun = async () => { try { const { reelTick } = await import('@/server/reel'); const r = reelTick(); if (r.purged) log(`daily reel: ${r.purged} old video file(s) deleted`); } catch (e) { log('daily reel error', e); } };
setTimeout(reelTickRun, 8_000);
setInterval(reelTickRun, 600_000);
// v168: status videos — heartbeat, the night job (01:00–07:00 IST, only when the server is quiet; checks every 10 min), clean-up,
// and the render queue (one at a time, low priority). Renders run only here, never in the web app.
let busySvid = false;
const svidRun = async () => { if (busySvid) return; busySvid = true; try { const { svidTick } = await import('@/server/statusvid'); const r = await svidTick(); const n = r.night as { did?: string } | undefined; if (n && n.did && !['window', 'done', 'off', 'busy'].includes(n.did)) log('status video:', n.did); } catch (e) { log('status video error', e); } finally { busySvid = false; } };
setTimeout(svidRun, 20_000);
setInterval(svidRun, 15_000);
setTimeout(adSpend, 10_000);
setTimeout(async () => { try { if (await ensureWebhookUpdates(getSettings())) log('webhook: now also gets deleted chat + channel member updates'); } catch (e) { log('webhook check', e); } }, 5_000);
setInterval(meta, 60_000);
// v152: Ad accounts by profile — one job at a time behind the iProxy IP change (setup, sync, share, top-up, take back, website orders)
let busyMq = false;
setInterval(async () => { if (busyMq) return; busyMq = true; try { const { queueTick } = await import('@/server/metaq'); const n = await queueTick(); if (n) log(`meta queue: ${n} job(s)`); } catch (e) { log('meta queue error', e); } finally { busyMq = false; } }, 5_000);
// v160: client queue messages (top-up countdown) + posts waiting for the chat screenshot — also while a long queue job runs
let busyQm = false;
setInterval(async () => { if (busyQm) return; busyQm = true; try { const T = await import('@/server/topupq'); await T.tickQueued(); const S = await import('@/server/shotpost'); await S.shotTick(); } catch (e) { log('queue messages error', e); } finally { busyQm = false; } }, 20_000);
// v150: Admin → Comments — Facebook Page + ads + Instagram ad comments (every 2 min by default, through the admin's proxy)
let busyCm = false;
setInterval(async () => { if (busyCm) return; busyCm = true; try { const { cmSync, cmTokenReminder } = await import('@/server/comments'); cmTokenReminder(); const r = await cmSync(); if (r && (r.new || r.deleted)) log(`comments: ${r.new} new, ${r.deleted} auto-deleted`); const { madsSync } = await import('@/server/metaads'); const m = await madsSync(); if (m) log(`meta ads: ${m.rows} rows, ${m.days} days, $${m.spend}`); } catch (e) { log('comments error', e); } finally { busyCm = false; } }, 30_000);
setTimeout(meta, 15_000);
setInterval(contacts, 30_000);
setInterval(reads, 30_000);
setInterval(seen, 45_000);
let busyUnarch = false;
setInterval(async () => { if (busyUnarch) return; busyUnarch = true; try { const r = await unarchiveTick(); if (r && ('moved' in r) && (r.moved || r.privacyOff)) log('archived lead chats', r); } catch (e) { log('unarchive error', e); } finally { busyUnarch = false; } }, 60_000); // customers' "last seen" for the chat header
setInterval(aiAuto, 5_000);
setInterval(reassign, 60_000);
setInterval(mutes, 20_000);
setInterval(folders, 120_000);
setTimeout(folders, 20_000);
setInterval(phoneJobs, 15_000);
setInterval(outbox, 2_000);
setInterval(welcomes, 4_000);
// v143: automatic follow-ups wait in the per-channel send queue → asked again every 5 s (they go at the safe sending speed)
let busyDrain = false;
setInterval(async () => { if (busyDrain) return; busyDrain = true; try { const { drainFollowups } = await import('@/server/crm'); const n = await drainFollowups(); if (n) log(`follow-ups sent from the queue: ${n}`); } catch (e) { log('send queue error', e); } finally { busyDrain = false; } }, 5_000);
// v141: new chats held for their welcome (text + voice) past the safety time-out → shown to the agent + the held alert (own timer,
// so a slow voice note in welcomes() never blocks it)
let busyHold = false;
setInterval(async () => { if (busyHold) return; busyHold = true; try { const { releaseDueHolds } = await import('@/server/crm'); await releaseDueHolds(); } catch (e) { log('hold release error', e); } finally { busyHold = false; } }, 5_000);
setInterval(autoContact, 30_000);
void followups();
setInterval(followups, 60_000);
// v113: Subscribe only for people still in the channel after the stay time
let busySub = false;
// v131: WhatsApp community sign-ups still chatting after the stay time → Subscribe (WhatsApp pixel)
let busyWaSub = false;
setInterval(async () => { if (busyWaSub) return; busyWaSub = true; try { const { waSubscribeDue } = await import('@/server/crm'); const n = await waSubscribeDue(getSettings()); if (n) log(`whatsapp: ${n} Subscribe sent`); } catch (e) { log('whatsapp subscribe error', e); } finally { busyWaSub = false; } }, 60_000);
let busyWaSync = false; // v137 (WATI Pro): chat status + contact attributes for changes made anywhere (max ~20 calls / run)
setInterval(async () => { if (busyWaSync) return; busyWaSync = true; try { const { waSyncSweep } = await import('@/server/wasync'); const n = await waSyncSweep(getSettings()); if (n) log(`whatsapp: ${n} WATI sync call(s)`); } catch (e) { log('whatsapp sync error', e); } finally { busyWaSync = false; } }, 60_000);
setInterval(async () => { if (busySub) return; busySub = true; try { const n = await subscribeDue(getSettings()); if (n) log(`channel: ${n} Subscribe sent (stayed)`); } catch (e) { log('channel subscribe error', e); } finally { busySub = false; } }, 60_000);
setInterval(() => { watchdogNotify().catch(e => log('watchdog notify error', e)); }, 30_000);
setInterval(retryCapi, 120_000);
setInterval(cleanup, 6 * 3600_000);

// v116: auto join ON → approve everyone still waiting (right after the update, every 30 min as a safety net, and when the admin taps the button)
let busyApprove = false, lastApprove = 0;
setInterval(async () => {
  const s = getSettings();
  const asked = s.chan_approve_req === '1';
  if (busyApprove || (!asked && (s.chan_auto_approve !== '1' || Date.now() - lastApprove < 30 * 60_000))) return;
  busyApprove = true; lastApprove = Date.now();
  try {
    if (asked) setSetting('chan_approve_req', '0');
    const r = await approvePendingJoins(channelChat(s));
    const at = new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' });
    if (r.ok && (r.count || asked)) { setSetting('chan_approve_status', `${at}: ${r.count ? r.count + ' waiting request(s) approved' : 'nobody was waiting'}`); log('channel: approved waiting', r.count); }
    if (!r.ok) { setSetting('chan_approve_status', `${at}: not done, ${r.error}`); if (asked) log('channel approve-all', r.error); }
  } catch (e) { log('channel approve-all error', e); } finally { busyApprove = false; }
}, 60_000);

// v116: people who pressed Start in the bot while it didn't answer → answer them now (once; new ones are answered at once)
setTimeout(async () => { try { const { answerMissedStarts } = await import('@/server/crm'); const n = await answerMissedStarts(500); if (n) log(`bot: answered ${n} people who pressed Start earlier`); } catch (e) { log('bot missed starts', e); } }, 30_000);

// v118: support-chat clients who pressed Start before and got nothing → "welcome back" + link to their chat (once)
setTimeout(async () => { try { const { welcomeBackOnce } = await import('@/server/crm'); const r = await welcomeBackOnce(); if (r.tried) log(`bot: welcome back sent to ${r.sent} of ${r.tried} support-chat clients (others never opened the bot)`); } catch (e) { log('bot welcome back', e); } }, 45_000);
