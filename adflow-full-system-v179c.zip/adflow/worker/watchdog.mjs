/**
 * Watchdog (its own PM2 process: adflow-watchdog). Plain Node, no imports from the app, so it keeps working when the website is stuck.
 *  - Every minute asks the website  http://127.0.0.1:PORT/api/health  (15 s timeout; the route also touches the database).
 *  - 2 failed checks in a row → saves a report (what the process was doing) and restarts adflow-web.
 *  - Never during an update / Android build / a manual "next build", and not in the first 3 minutes after the website (re)started.
 *  - At most 3 restarts per hour, then it only writes reports (so a broken build can't loop forever).
 * Reports: data/watchdog/*.txt, events: data/watchdog/events.jsonl (the worker sends the admin a notification for each event;
 * Admin → System shows them).
 */
import fs from 'fs';
import path from 'path';
import { execFile } from 'child_process';

const APP = process.cwd();
const PORT = Number(process.env.PORT || readEnv('PORT')) || 3000;
const WEB = process.env.WATCHDOG_APP || 'adflow-web';
const EVERY = Math.max(15, Number(process.env.WATCHDOG_EVERY_SEC) || 60) * 1000;
const FAILS = Math.max(1, Number(process.env.WATCHDOG_FAILS) || 2);
const GRACE = (Number(process.env.WATCHDOG_GRACE_SEC) || 180) * 1000; // after a (re)start
const dbPath = process.env.DB_PATH || readEnv('DB_PATH') || path.join(APP, 'data', 'adflow.db');
const DATA = path.dirname(dbPath);
const DIR = path.join(DATA, 'watchdog');
const JOBS = path.join(DATA, 'jobs');
fs.mkdirSync(DIR, { recursive: true });

function readEnv(k) {
  try { const m = fs.readFileSync(path.join(APP, '.env'), 'utf8').match(new RegExp(`^\\s*${k}\\s*=\\s*(.*)$`, 'm')); return m ? m[1].trim().replace(/^["']|["']$/g, '') : ''; } catch { return ''; }
}
const log = (...a) => console.log(new Date().toISOString(), '[watchdog]', ...a);
const sh = (cmd, args, ms = 15000) => new Promise(res => execFile(cmd, args, { timeout: ms, maxBuffer: 4 << 20 }, (e, out, err) => res(String(out || '') + (e && !out ? String(err || e.message || '') : ''))));
/** stdout only ('' when the command fails or finds nothing — e.g. pgrep with no match) */
const out = (cmd, args, ms = 15000) => new Promise(res => execFile(cmd, args, { timeout: ms, maxBuffer: 4 << 20 }, (e, o) => res(String(o || ''))));
const PM2 = ['pm2', '/usr/bin/pm2', '/usr/local/bin/pm2', path.join(APP, 'node_modules/.bin/pm2')].find(p => p === 'pm2' || fs.existsSync(p));

async function check() {
  try {
    const r = await fetch(`http://127.0.0.1:${PORT}/api/health`, { signal: AbortSignal.timeout(15000), cache: 'no-store' });
    if (r.ok) return { ok: true };
    return { ok: false, why: `HTTP ${r.status}` };
  } catch (e) { return { ok: false, why: e?.name === 'TimeoutError' ? 'no answer in 15 s' : String(e?.cause?.code || e?.message || e).slice(0, 80) }; }
}

/** An update / Android build is running (launched from Admin → System), or someone runs "next build" by hand. */
async function busy() {
  try {
    for (const f of fs.readdirSync(JOBS).filter(f => f.endsWith('.json'))) {
      const id = f.slice(0, -5);
      if (fs.existsSync(path.join(JOBS, id + '.exit'))) continue;
      const started = JSON.parse(fs.readFileSync(path.join(JOBS, f), 'utf8')).started || 0;
      // v173: a job whose shell is gone is not running (no 2-hour wait)
      let alive = true;
      try { const pid = Number(fs.readFileSync(path.join(JOBS, id + '.pid'), 'utf8').trim()); if (pid > 1) { try { process.kill(pid, 0); } catch (e) { alive = e?.code !== 'ESRCH'; } } } catch { /* older job: no pid file */ }
      if (alive && Date.now() - started < 2 * 3600_000) return `job ${id} running`;
    }
  } catch { /* no jobs dir */ }
  const ps = await out('pgrep', ['-af', 'next build|npm ci|npm install']);
  if (ps.trim()) return 'a build / install is running';
  return '';
}

async function webInfo() {
  try {
    const list = JSON.parse(await out(PM2, ['jlist']));
    const p = list.find(x => x.name === WEB);
    if (!p) return null;
    return { pid: p.pid, status: p.pm2_env?.status, uptime: p.pm2_env?.pm_uptime ? Date.now() - p.pm2_env.pm_uptime : 0, restarts: p.pm2_env?.restart_time, cpu: p.monit?.cpu, mem: p.monit?.memory, out: p.pm2_env?.pm_out_log_path, err: p.pm2_env?.pm_err_log_path };
  } catch { return null; }
}

const tail = (f, n = 40) => { try { const st = fs.statSync(f), fd = fs.openSync(f, 'r'), len = Math.min(st.size, 64_000), b = Buffer.alloc(len); fs.readSync(fd, b, 0, len, st.size - len); fs.closeSync(fd); return b.toString('utf8').split('\n').slice(-n).map(l => l.slice(0, 400)).join('\n'); } catch { return '(no log)'; } };

async function report(why, info) {
  const ts = new Date().toISOString().replace(/[:.]/g, '-');
  const procs = await sh('ps', ['-eo', 'pid,ppid,pcpu,pmem,etime,stat,wchan:22,args', '--sort=-pcpu']);
  const mine = procs.split('\n').filter((l, i) => i === 0 || /next|npm|node|tsx/.test(l)).slice(0, 25).map(l => l.slice(0, 220)).join('\n');
  const conns = await sh('ss', ['-tn', 'state', 'established', `( sport = :${PORT} )`]);
  const lines = [
    `Watchdog report ${new Date().toString()}`, `Reason: ${why}`,
    `adflow-web: ${info ? JSON.stringify({ pid: info.pid, status: info.status, uptime_min: Math.round(info.uptime / 60000), restarts: info.restarts, cpu: info.cpu, mem_mb: Math.round((info.mem || 0) / 1048576) }) : 'not found in pm2'}`,
    `Open connections to :${PORT}: ${Math.max(0, conns.trim().split('\n').length - 1)}`,
    '', '--- processes ---', mine,
    '', '--- load / memory ---', await sh('uptime', []), await sh('free', ['-m']),
    '', '--- adflow-web error log (last 40) ---', info?.err ? tail(info.err) : '',
    '', '--- adflow-web out log (last 40) ---', info?.out ? tail(info.out) : '',
  ];
  const file = path.join(DIR, `report-${ts}.txt`);
  fs.writeFileSync(file, lines.join('\n'));
  // keep the last 30 reports
  try { for (const f of fs.readdirSync(DIR).filter(f => f.startsWith('report-')).sort().reverse().slice(30)) fs.unlinkSync(path.join(DIR, f)); } catch { /* fine */ }
  return path.basename(file);
}

function event(e) {
  fs.appendFileSync(path.join(DIR, 'events.jsonl'), JSON.stringify({ at: Date.now(), ...e }) + '\n');
  log(e.kind, e.why || '', e.report || '');
}

let fails = 0, lastWhy = '';
const restarts = [];
async function tick() {
  const info = await webInfo();
  if (info && info.status === 'online' && info.uptime < GRACE) { fails = 0; return; } // just (re)started — give it time
  if (info && ['stopped', 'stopping', 'launching'].includes(info.status)) { fails = 0; return; } // stopped on purpose / PM2 is starting it
  const b = await busy();
  if (b) { fails = 0; return; }
  const r = await check();
  if (r.ok) { fails = 0; return; }
  fails++; lastWhy = r.why;
  log(`check failed (${fails}/${FAILS}): ${r.why}`);
  if (fails < FAILS) return;
  fails = 0;
  const rep = await report(`website did not answer ${FAILS}× in a row (${lastWhy})`, info);
  const now = Date.now();
  while (restarts.length && now - restarts[0] > 3600_000) restarts.shift();
  if (restarts.length >= 3) { event({ kind: 'gave_up', why: `${lastWhy} — already restarted 3× this hour, not restarting again`, report: rep }); return; }
  restarts.push(now);
  await sh(PM2, ['restart', WEB], 60000);
  // did it come back?
  let back = false;
  for (let i = 0; i < 12 && !back; i++) { await new Promise(x => setTimeout(x, 5000)); back = (await check()).ok; }
  event({ kind: back ? 'restarted' : 'restart_failed', why: lastWhy, report: rep });
}

log(`started — checking http://127.0.0.1:${PORT}/api/health every ${EVERY / 1000}s, restart after ${FAILS} fails`);
let running = false;
setInterval(() => { if (running) return; running = true; tick().catch(e => log('error', e?.message || e)).finally(() => { running = false; }); }, EVERY);
