import type { Config } from 'tailwindcss';

const v = (name: string) => `rgb(var(--${name}) / <alpha-value>)`;

export default {
  // v160: no sticky hover colour after a tap on phones
  future: { hoverOnlyWhenSupported: true },
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        // Landing theme tokens (values come from src/components/site/themes.ts)
        void: v('bg'),
        plum: { DEFAULT: v('s1'), 2: v('s2'), 3: v('s3') },
        edge: 'var(--edge)',
        violet: { DEFAULT: v('p'), deep: v('pd'), soft: v('ps') },
        lilac: v('pt'),
        orchid: v('a'),
        mint: v('ok'),
        ov: v('ov'),
        onp: v('onp'),
        fg: { DEFAULT: v('fg'), 2: v('fg2'), 3: v('fg3') },
        // Agent & admin apps (Telegram-style dark palette)
        tg: {
          // v131: colours are CSS variables (globals.css) so a chat can switch to the WhatsApp light look (.wa-light)
          bg: 'rgb(var(--tg-bg) / <alpha-value>)', panel: 'rgb(var(--tg-panel) / <alpha-value>)', hover: 'rgb(var(--tg-hover) / <alpha-value>)', active: 'rgb(var(--tg-active) / <alpha-value>)', line: 'rgb(var(--tg-line) / <alpha-value>)', in: 'rgb(var(--tg-in) / <alpha-value>)', out: 'rgb(var(--tg-out) / <alpha-value>)', acc: 'rgb(var(--tg-acc) / <alpha-value>)', link: 'rgb(var(--tg-link) / <alpha-value>)', text: 'rgb(var(--tg-text) / <alpha-value>)', sub: 'rgb(var(--tg-sub) / <alpha-value>)', green: 'rgb(var(--tg-green) / <alpha-value>)', input: 'rgb(var(--tg-input) / <alpha-value>)', red: 'rgb(var(--tg-red) / <alpha-value>)', chip: 'rgb(var(--tg-chip) / <alpha-value>)', orange: 'rgb(var(--tg-orange) / <alpha-value>)', strong: 'rgb(var(--tg-strong) / <alpha-value>)', outtx: 'rgb(var(--tg-outtx) / <alpha-value>)', outsub: 'rgb(var(--tg-outsub) / <alpha-value>)', menu: 'rgb(var(--tg-menu) / <alpha-value>)',
          // v136: semantic tokens
          ...Object.fromEntries(['ok', 'bad', 'warn', 'gold', 'premium', 'funnel', 'wa', 'tgblue', 'toast', 'card1', 'medal1', 'medal2', 'medal3',
            // v167: premium design system tokens (globals.css → "v167")
            'sep', 'faint', 'track', 'panel2', 'oksoft', 'badsoft', 'warnsoft', 'accsoft', 'premsoft', 'funsoft', 'badge'].map(k => [k, `rgb(var(--tg-${k}) / <alpha-value>)`])),
        },
      },
      fontFamily: {
        sans: ['var(--font-geist-sans)', 'system-ui', 'sans-serif'],
        mono: ['var(--font-geist-mono)', 'ui-monospace', 'monospace'],
        display: ['var(--font-display)', 'var(--font-geist-sans)', 'sans-serif'],
      },
      maxWidth: { page: '1200px' },
      keyframes: {
        aurora: { '0%,100%': { transform: 'translate(0,0) scale(1)' }, '33%': { transform: 'translate(6%,-8%) scale(1.15)' }, '66%': { transform: 'translate(-6%,6%) scale(.92)' } },
        spin: { to: { transform: 'rotate(360deg)' } },
        marquee: { to: { transform: 'translateX(-50%)' } },
        shine: { '0%': { backgroundPosition: '200% 0' }, '100%': { backgroundPosition: '-200% 0' } },
      },
      animation: {
        aurora: 'aurora 18s ease-in-out infinite',
        'aurora-slow': 'aurora 26s ease-in-out infinite reverse',
        beam: 'spin 5s linear infinite',
        marquee: 'marquee 38s linear infinite',
        shine: 'shine 6s linear infinite',
      },
    },
  },
  plugins: [],
} satisfies Config;
