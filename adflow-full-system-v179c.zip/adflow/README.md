# AdFlow — Setup Guide

Ek hi system mein:
- **4 alag landing pages** (har ek ka layout, style aur animation alag):
  - **Purple** (`/p/purple`) — glass cards, aurora glow, live Telegram chat demo
  - **Green** (`/p/green`) — Spotify style: album-cover service tiles, "tracklist" process, scrolling shelf
  - **Blue** (`/p/blue`) — light SaaS style: live ads dashboard window, stepper, plan comparison table
  - **Gold** (`/p/gold`) — luxury: 3D gold card (mouse ke saath ghoomta hai), menu-style price list, timeline
- **Admin app** — dashboard, saari chats, leads, team/leaderboard, ad spend + ROI, payouts, Meta events, export, aur poori settings
- **Agent app** — Telegram jaisa chat app (photo, video, file, voice note, quick replies, Mark Sold, Topup, wallet)
- **Telegram** — leads aapki personal Telegram ID se chat karte hain (Telegram Business), agents apne app se reply karte hain
- **Meta Conversions API** — sirf server-side, koi duplicate event nahi

Tech: Next.js 15 (App Router) + React 19 + TypeScript + Tailwind 3. Database SQLite (ek file, alag DB server nahi chahiye). Background jobs alag process mein (`worker/`).

---

## 1. VPS setup (ek baar, ~10 min)

**VPS:** Ubuntu 22.04 ya 24.04, kam se kam 2 GB RAM (APK build ke liye 4 GB better).
**Domain:** apne domain ka A record VPS ke IP pe point karo (Cloudflare use kar rahe ho toh SSL mode **Full** rakho).

```bash
# zip VPS pe upload karo, phir:
apt-get update && apt-get install -y unzip
unzip adflow.zip -d /root/adflow
cd /root/adflow
sudo bash scripts/setup-vps.sh yourdomain.com you@email.com
```

Script yeh sab khud karti hai: Node 22, build, PM2 (website + worker), nginx, HTTPS certificate, daily database backup.
End mein **admin password** print hoga (`.env` file mein bhi saved hai).

Kaam check karo:
- `https://yourdomain.com` → landing page
- `https://yourdomain.com/admin` → admin login (username `admin`)
- `pm2 logs` → live logs

## 2. Admin app mein settings (sab yahin se)

Admin app → **Settings**:

1. **Brand & landing page** — brand name, theme choose karo (Preview button se har theme dekh lo)
2. **Prices & delivery** — ad account price ($15), funnel price ($50/month), delivery time ("1 hour"), payment methods, topup fee % (client se har topup pe liya jaane wala fee, jaise 3%)
3. **Landing text** — headline, cards, FAQ, sab kuch editable
4. **Telegram** — @BotFather se bot token paste karo → Save (webhook apne-aap lag jaata hai)
5. **Meta** — Pixel ID + Conversions API token (+ testing ke liye Test event code)
6. **Phone notifications** — Firebase key (neeche step 5)

Har theme ka apna link bhi hai — alag ad sets mein test kar sakte ho:
`/p/purple`  `/p/green`  `/p/blue`  `/p/gold`  (main link `/` pe jo theme select hai wo dikhta hai)

## 3. Telegram — ek hi ID se saari chats

1. **@BotFather** → apna bot → *Bot Settings* → **Business Mode → ON**
2. Phone pe: **Telegram → Settings → Telegram Business → Chatbots** → apna bot add karo → reply karne ki permission do
3. Usi screen pe access mein **apne contacts exclude** kar do — taaki personal chats agents tak na jaayein
4. Zaroori: **Telegram Premium** aur aapki ID ka **public username**

Admin app → Settings → Telegram mein "connected to …" dikhna chahiye.

**Flow:** Lead form bharta hai → Telegram aapki ID ke saath khulta hai, message pehle se typed (code ke saath) → lead Send dabata hai → chat round-robin se ek agent ko jaati hai → agent app se reply karta hai, lead ko aapki ID se dikhta hai. Aap phone se reply karo toh wo bhi panel mein dikhega.

> Telegram call kisi bhi app ya bot se possible nahi hai (Telegram allow nahi karta). Agent app mein har chat pe 📞 button hai jisse phone call ya WhatsApp hota hai.

### Auto first message (jo form bhar ke message nahi karte)
Kuch logon ki Telegram ID anjaan logon ko pehla message nahi bhej paati. Unke liye aapki chat ID (jaise @adsbhaisupport) khud pehla message bhejti hai — unke **phone number** se.
1. Browser mein **my.telegram.org** kholo → chat ID ke number se login → **API development tools** → app banao (koi bhi naam) → `api_id` aur `api_hash` copy karo.
2. Admin app → Settings → **Auto first message** → api_id, api_hash, chat ID ka number daalo → **Send code** → Telegram pe aaya code daalo → **Log in** (2-step password ho toh wo bhi).
3. Switch **ON/OFF** yahin se. Wait time (default 5 min), ek ghante mein max messages (default 20) aur message ka text bhi yahin badlo → Save.
Reply aate hi chat round-robin se agent ke paas jaati hai, aur Meta **Lead** event tabhi jaata hai. Reply se pehle agent text bhej sakta hai (chat ID se jaata hai); photo/file reply ke baad.
> Login code kabhi kisi chat mein mat bhejna — Telegram login block kar deta hai.

### Logo, top bar, welcome
- **Logo:** Settings → Brand → Upload logo (square PNG). Chaaron landing pages, footer aur browser tab mein dikhega.
- **Top bar** ("1000+ members… See proof"): Settings → Landing text: top of page → Top bar. Link khaali ho toh channel link use hota hai.
- **Welcome message** ab ~35 second baad jaata hai (Settings → Telegram). Channel link set ho toh "Meanwhile, join our channel" line apne-aap judti hai. Agent pehle reply kar de toh welcome nahi jaata.

### Follow-ups aur "Remind me"
- Ghadi **agent ke aakhri bina-jawab wale message** se chalti hai: Follow-up 1 → 12 ghante baad, Follow-up 2 → FU1 bhejne ke 24 ghante baad, Follow-up 3 → FU2 ke 24 ghante baad.
- **Dead** tabhi hota hai jab FU3 bhej diya gaya aur uske 24 ghante baad bhi jawab nahi aaya. Client ka koi bhi message sab reset kar deta hai aur Dead chat wapas khul jaati hai.
- Raat 10 se subah 9 tak naye follow-up alert nahi aate (subah 9 baje aa jaate hain).
- Chat mein **⏰ Remind me**: "kal lunga" wale client ke liye agent time set kare — us time notification aata hai, aur tab tak follow-up/Dead ruka rehta hai.
- Saare time Settings → Agent app mein badal sakte ho.

## 4. Agents

Admin app → **Team → Agents → Add agent**: naam, username, password, commission per sale.
Agent ko username + password aur APK link do. Agent app ke menu se wo **Telegram alerts** bhi connect kar sakta hai — wahan lead ke message pe reply karke bhi answer kar sakta hai.

## 5. Android apps (APK)

**Notifications ke liye (recommended):**
1. https://console.firebase.google.com → naya project
2. Project mein **2 Android apps** add karo: package `com.adflow.agent` aur `com.adflow.admin`
3. **google-services.json** download karo → VPS pe `mobile/google-services.json` pe rakho
4. Project settings → **Service accounts → Generate new private key** → us JSON file ka poora content Admin app → Settings → Phone notifications mein paste karo

**APK build:**
```bash
cd /root/adflow
sudo bash scripts/build-apk.sh
```
(Pehli baar Android SDK download hota hai, 10–15 min lagta hai.)

Download links:
- `https://yourdomain.com/downloads/agent.apk`
- `https://yourdomain.com/downloads/admin.apk`

Phone pe link kholo → install (Chrome "unknown apps" permission maangega). Apps live website load karte hain, isliye **settings ya design badalne pe APK dobara banana nahi padta**.
`mobile/release.keystore` aur `mobile/release.keystore.pass` sambhal ke rakho — app update ke liye same key chahiye.

## 6. Meta events — kab kya jaata hai

| Event | Kab | Duplicate? |
|---|---|---|
| ViewContent | Landing page khulne pe | Har visitor ka sirf ek baar |
| Lead | **Jab user Telegram pe message bhejta hai** (form submit pe nahi) | Har lead ka sirf ek baar |
| Purchase | **Jab agent "Mark sold" karta hai** | Har event ki unique ID — kabhi do baar nahi |
| InitiateCheckout | Landing order form submit (name + number) | Har lead ka ek baar |
| Contact | "Chat with agent" button form submit | Har lead ka ek baar |
| Lead (website) | Website order form submit (payment se pehle) | Har website customer ka sirf ek baar |
| Purchase (website) | **Jab manager order deliver karta hai** | Har order ka sirf ek baar |

Har event mein form ke time saved browser data (IP, user agent, fbc, fbp) aur hashed email/phone/name jaata hai. Fail hua event worker 4 baar tak khud retry karta hai (same ID se). Admin app → **Meta events** mein sab dikhta hai.

## 6b. Website orders (master switch)

Admin → Settings → **Website orders**. Switch OFF = sab pehle jaisa (sirf Telegram).
Switch ON = landing pe 2 cards: Telegram $20 / Website $17, plus `/order` aur `/account` pages.

**Manager:** Admin → Team → Agents → Edit → Role = **Manager**. Manager ko normal leads nahi milti; use milta hai:
website orders, website top-ups, INR confirm, funnel leads, aur agents ke "Send to manager" requests (agent app → **Tasks** tab).

**NOWPayments (crypto):**
1. nowpayments.io → account → payout wallet add karo.
2. Settings → Payments → API keys → key banao → Admin mein paste.
3. Settings → Payments → Instant payment notifications → IPN secret banao → Admin mein paste.
   Callback URL: `https://adsbhai.com/api/np/ipn`
4. Coins (USDT BEP20, TRX, BTC, ETH) NOWPayments dashboard mein bhi ON karo.
   Payment address, QR, amount aur timer (default 60 min, Admin mein badlo) aapke apne page pe dikhte hain — NOWPayments ka page nahi khulta.
   Customer "Check status" dabaye to system NOWPayments se seedha status bhi check karta hai (IPN late ho to bhi).

**Resend (emails — login code, payment received, delivered, top-up):**
1. resend.com → Domains → `adsbhai.com` add → jo DNS records dikhaye wo Spaceship DNS mein add → Verify.
2. API keys → Create → Admin mein paste. Sender default: `AdsBhai <noreply@adsbhai.com>`.

**INR:** "Allow paying in INR" ON → rate set karo (1 USD = ? INR). UPI ID daaloge to QR + Paytm/PhonePe/GPay button aata hai,
customer UTR daalta hai → manager ko task → bank check karke **Mark as paid** → phir Deliver.

**Flow:** Order (bina OTP — sirf email, phone, BM) → payment → manager task → manager ad account IDs daalta hai → customer ko email + Telegram (chat account se) + Meta Purchase.
Top-up sirf website se khareede accounts pe (min $30 + fee). Telegram se khareede accounts → "support se contact karo".
Customer ka Telegram reply manager ki chat mein aata hai (chat account login hona chahiye — Settings → Auto first message).

## 6c. Telegram chat folders (har agent ka folder)

Chat account (@adsbhaisupport) login ho (Settings → Auto first message) to aapke Telegram app mein har agent ke naam
ka folder ban jaata hai — "Rahul", "Avik"… — jismein wahi chats hote hain jo wo agent handle kar raha hai. Har 2 min update.
Switch: Settings → Auto first message → "Chat folders per agent". OFF karne pe ye folders hat jaate hain (aapke apne folders ko touch nahi karta).
Limit: Telegram mein 20 folders (Premium), har folder mein newest 100 chats. Dead chats folder mein nahi aate.
Order: All chats → Manager ka folder → baaki agents. Agent remove karne pe uska folder 2 min mein hat jaata hai.
**Mute agents' chats** (ON): sirf Manager ki chats ki notification aati hai, baaki sab chats chat account pe mute.
**Block calls** (ON): chat account ko koi call nahi kar sakta.
**Save leads as contacts** (ON): har lead "AdsBhai Lead 12" naam se contact mein save, sale hone pe customer ke naam se rename, dead hone pe contact delete.
⚠️ Telegram → Settings → Business → Chatbots mein bot ke access mein **Contacts exclude NAHI hona chahiye**, warna saved leads ke message bot tak nahi aayenge.

## 6d. No reply → next agent → manager
Settings → Agent app → "Move unanswered leads". Working hours (default 9-22) mein agar agent 30 min (setting) mein reply nahi karta,
lead agle agent ko (pehle online wale), sab agents try hone ke baad Manager ko. Sirf working-hours ke minutes count hote hain.
Agent app, Telegram ya admin — kahin se bhi reply ho to count hota hai. Automatic welcome reply nahi maana jaata.

## 6e. Landing extras
- **Order now** (header + baaki buttons): website orders ON ho to pehle choice aata hai — Website $20 (Save $3) ya Telegram $23.
- **Chat with agent** button (neeche right): naam + number → Telegram alag pre-typed message ke saath → alag welcome message. Settings → Telegram.
- **Recent purchases ticker**: sirf ASLI sales / top-ups (last 30 din), naam ka pehla word + initial. Settings → Landing text: top of page.
- Agents ko new-lead alert welcome message jaane KE BAAD aata hai (welcome delay ke hisaab se).

## 6f. Tez notification sound (naya APK chahiye)
App v1.1 mein apna loud "ding-ding-DING" + vibration hai. Purane APK pe default sound hi bajega. Naya APK banao:
`cd /root/adflow && sudo bash scripts/build-apk.sh` → phone pe agent.apk / admin.apk dobara install (purane ke upar, data safe).

## 7. Roz ka kaam

- **Ad spend:** Admin app → Ad spend → din ka spend daalo → CPL / CPA / ROI apne-aap
- **Payouts:** agent wallet se request karta hai (Bank/UPI ya USDT BEP20) → Admin app → Payouts → Mark paid
- **Export:** leads CSV, Meta offline purchases (hashed), lookalike audience (hashed)

## 8. Update / maintenance

```bash
# naya version upload karke:
cd /root/adflow && bash scripts/update.sh
pm2 logs              # logs
pm2 restart all       # restart
bash scripts/backup.sh  # manual backup (daily backup cron already set)
```
Database: `data/adflow.db` · Backups: `backups/`

## Folder structure
```
src/app/            pages + API routes (landing, /p/[theme], /agent, /admin, /api/*)
src/components/site landing page (4 themes)
src/components/app  agent app + admin app (Telegram-style)
src/server/         database, settings, Telegram, CAPI, push, CRM logic
worker/             background jobs (follow-ups, CAPI retry)
mobile/agent|admin  Android app projects (Capacitor)
scripts/            setup-vps.sh, build-apk.sh, update.sh, backup.sh
```
