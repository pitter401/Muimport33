/* v168: LIVE mode for the agent daily-reel templates (E–T) inside the app (TemplatePlayer.tsx).
 * The templates were built for deterministic server rendering (a MUTED <video> seeked to t). In the app the video must play
 * in real time WITH its song, smoothly on low-end phones, so here:
 *  - boot: window.__REEL comes from the URL fragment  #r=<encodeURIComponent(JSON)>  (synchronous, before core.js runs;
 *    the fragment is never sent, so the HTML stays one cacheable URL). Without `live:true` this file does nothing and the
 *    template behaves exactly as before (previews / server renders).
 *  - ONE real <video> (the sharp one) plays from 0 with sound; every other video copy (full-screen veil, ambient
 *    backgrounds, reflections, duotone) becomes a small <canvas> fed from it at ~15 fps; film-strip thumbnails are stills
 *    grabbed from it while it plays. One decoder, no seeking, ever.
 *  - the timeline: requestAnimationFrame → the runtime's own render(t) with t = video.currentTime (never seeks the video),
 *    so the intro veil, quote cycling and the end card all follow the real playback position.
 *  - sound blocked → muted autoplay + {type:'sound',muted:true} to the parent (it shows "Tap for sound" and sends 'unmute').
 *  - messages to the parent (same origin): boot, playing, sound, progress, phase, skip, ready, tap, ended, error.
 *    From the parent: unmute, pause, play. No controls of any kind inside the page. */
(function () {
  'use strict';
  var W = window, D = document;
  try { var m = /[#&]r=([^&]*)/.exec(location.hash || ''); if (m) W.__REEL = JSON.parse(decodeURIComponent(m[1])); } catch (e) { /* bad fragment → not live */ }
  var R = W.__REEL;
  if (!R || R.live !== true) { W.__LIVE = null; return; }
  if (!R.logo_url) R.logo_url = '/reel/logo.png';
  // v168 (senior review): some formats put the name / quotes into innerHTML → no markup can come in with the text
  var noTag = function (s) { return typeof s === 'string' ? s.replace(/[<>]/g, '') : s; };
  ['name', 'greeting', 'line_of_day', 'date_long', 'date_short'].forEach(function (k) { R[k] = noTag(R[k]); });
  if (Array.isArray(R.quotes)) R.quotes = R.quotes.map(noTag);

  var POST = function (o) { o.src = 'reeltpl'; try { if (W.parent && W.parent !== W) W.parent.postMessage(o, location.origin); } catch (e) { /* */ } };
  W.addEventListener('error', function (e) { POST({ type: 'jserror', msg: String(e && e.message || e) }); });
  W.addEventListener('unhandledrejection', function (e) { POST({ type: 'jserror', msg: String(e && e.reason || e) }); });

  // no long-press menus / selection / callouts; the in-design skip pill only when the parent allows skipping
  var css = 'html,body{-webkit-user-select:none;user-select:none;-webkit-touch-callout:none;-webkit-tap-highlight-color:transparent}' +
    'video{pointer-events:none}' +
    'body.noskip .pill-skip,body.noskip .skip,body.noskip #skip{display:none!important}';
  var st = D.createElement('style'); st.textContent = css; (D.head || D.documentElement).appendChild(st);
  var addCls = function () { D.body.classList.add('live'); if (R.skip === false) D.body.classList.add('noskip'); };
  if (D.body) addCls(); else D.addEventListener('DOMContentLoaded', addCls);
  // v173: the manager / admin get yesterday's SALES (not earnings) → the formats' fixed "Yesterday you earned" text says the label
  var YL = R.yesterday && typeof R.yesterday.label === 'string' ? noTag(R.yesterday.label) : '';
  var YS = YL ? YL.replace(/^yesterday\s+/i, '').replace(/^\w/, function (c) { return c.toLowerCase(); }) : '';
  if (YL) {
    var fix = function (n) {
      var v = n.nodeValue; if (!v || !/earned/i.test(v)) return;
      // "Yesterday you earned" → the label; "you earned" alone (a "Yesterday" heading is next to it) → "you sold"; "earned" → "sold"
      var cs = function (m, t) { return m === m.toUpperCase() ? t.toUpperCase() : m.charAt(0) === m.charAt(0).toUpperCase() ? t.charAt(0).toUpperCase() + t.slice(1) : t; };
      var nv = v.replace(/yesterday\s+you\s+earned/gi, function (m) { return cs(m, YL); })
        .replace(/you\s+earned/gi, function (m) { return cs(m, YS); })
        .replace(/\bearned\b/gi, function (m) { return cs(m, 'sold'); });
      if (nv !== v) n.nodeValue = nv;
    };
    var relabel = function (root) {
      if (!root) return; if (root.nodeType === 3) { fix(root); return; }
      var tw = D.createTreeWalker(root, NodeFilter.SHOW_TEXT, null), n;
      while ((n = tw.nextNode())) fix(n);
    };
    // only the nodes that changed are looked at (count-ups change text every frame)
    var hook = function () { relabel(D.body); try { var mo = new MutationObserver(function (rs) { for (var i = 0; i < rs.length; i++) { var r = rs[i]; if (r.type === 'characterData') fix(r.target); else for (var j = 0; j < r.addedNodes.length; j++) relabel(r.addedNodes[j]); } }); mo.observe(D.body, { childList: true, subtree: true, characterData: true }); setTimeout(function () { mo.disconnect(); }, 90000); } catch (e) { /* old browser */ } };
    if (D.body && D.readyState !== 'loading') hook(); else D.addEventListener('DOMContentLoaded', hook);
  }
  D.addEventListener('contextmenu', function (e) { e.preventDefault(); });

  var V = null;              // the one playing video
  var mirrors = [];          // canvases fed from V
  var thumbs = [], stills = []; // film-strip stills
  var PROPS = ['position', 'left', 'top', 'right', 'bottom', 'width', 'height', 'display', 'objectFit', 'objectPosition', 'filter', 'transform',
    'transformOrigin', 'opacity', 'borderRadius', 'mixBlendMode', 'zIndex', 'boxShadow', 'maxWidth', 'maxHeight'];
  /* the templates' CSS often targets `img.vid` / `.x img`, which a <video> / <canvas> replacement would lose: carry the
     computed look over (inline styles the page set itself still win) */
  function carry(from, to) {
    var cs = getComputedStyle(from);
    to.setAttribute('style', from.getAttribute('style') || '');
    for (var i = 0; i < PROPS.length; i++) { var p = PROPS[i]; if (!from.style[p]) to.style[p] = cs[p]; }
    if (!from.style.objectFit && (cs.objectFit === 'fill' || !cs.objectFit)) to.style.objectFit = 'cover';
    to.className = from.className; if (from.id) to.id = from.id;
    for (var k in from.dataset) to.dataset[k] = from.dataset[k];
  }
  function blurPx(el) { var mx = 0; for (var x = el; x && x !== D.body; x = x.parentElement) { var f = getComputedStyle(x).filter || ''; var r = /blur\(([\d.]+)px\)/.exec(f); if (r) mx = Math.max(mx, +r[1]); } return mx; }
  /* a mirror's own CSS filter (blur 42–70px over a full-screen box, grayscale…) is applied while drawing into the small canvas
     (ctx.filter, scaled to canvas pixels) instead of by the compositor on a huge box at every video frame: the upscaled,
     pre-blurred bitmap looks the same and costs next to nothing */
  function mkMirror(img) {
    var b = blurPx(img), w = b >= 20 ? 48 : b >= 4 ? 112 : 192;
    var cs = getComputedStyle(img), own = cs.filter && cs.filter !== 'none' ? cs.filter : '';
    var bw = parseFloat(cs.width) || 160, bh = parseFloat(cs.height) || 90;
    var c = D.createElement('canvas'); carry(img, c); c.width = w; c.height = Math.round(w * 9 / 16); c.__w = w;
    var mi = { c: c, x: c.getContext('2d', { alpha: false }), every: b >= 20 ? 80 : 60, last: -1e9, f: '', m: 0, own: own, bw: bw, bh: bh };
    if (own && 'filter' in mi.x) {
      c.style.filter = 'none';
      // a big CSS blur used to fade the box's edges into the page; a pre-blurred bitmap has hard edges, so an ambient
      // copy that sits in the full-screen stage but does not cover it is stretched over the whole stage (+ the blur)
      var op = img.offsetParent, pr = op && op.getBoundingClientRect(), r0 = img.getBoundingClientRect();
      if (b >= 20 && pr && Math.abs(pr.width - 375) < 2 && Math.abs(pr.height - 812) < 2 && (r0.left > pr.left || r0.top > pr.top || r0.right < pr.right || r0.bottom < pr.bottom)) {
        bw = mi.bw = 375 + 2 * b; bh = mi.bh = 812 + 2 * b;
        c.style.left = -b + 'px'; c.style.top = -b + 'px'; c.style.right = 'auto'; c.style.bottom = 'auto'; c.style.width = bw + 'px'; c.style.height = bh + 'px';
      }
      fit(mi);
    }
    img.replaceWith(c);
    mirrors.push(mi);
    return c;
  }
  function fit(mi) { // canvas px per CSS px (object-fit: cover) → the blur in canvas pixels + an overscan so edges stay full
    if (!mi.own) return;
    var k = Math.max(mi.bw / mi.c.width, mi.bh / mi.c.height) || 1, r = 0;
    mi.f = mi.own.replace(/blur\(([\d.]+)px\)/g, function (m0, x) { r = +x / k; return 'blur(' + Math.max(.4, r).toFixed(2) + 'px)'; });
    mi.m = Math.ceil(r * 2);
  }
  var L = W.__LIVE = {};
  /** the page's video spots: the first sharp one plays, the rest mirror it */
  L.adopt = function (imgs) {
    if (!imgs.length) return;
    var pi = 0, i;
    for (i = 0; i < imgs.length; i++) if (!blurPx(imgs[i])) { pi = i; break; }
    var img = imgs[pi], vd = D.createElement('video');
    carry(img, vd);
    vd.playsInline = true; vd.setAttribute('playsinline', ''); vd.setAttribute('webkit-playsinline', 'true');
    vd.preload = 'auto'; vd.controls = false; vd.disablePictureInPicture = true; vd.disableRemotePlayback = true;
    vd.setAttribute('controlslist', 'nodownload nofullscreen noremoteplayback'); vd.muted = false; vd.style.pointerEvents = 'none';
    vd.src = R.video_url || '';
    img.replaceWith(vd); V = vd;
    for (i = 0; i < imgs.length; i++) if (i !== pi) mkMirror(imgs[i]);
    vd.addEventListener('loadedmetadata', function () { var a = vd.videoWidth && vd.videoHeight ? vd.videoHeight / vd.videoWidth : 9 / 16; mirrors.forEach(function (mi) { mi.c.height = Math.max(8, Math.round(mi.c.__w * a)); fit(mi); }); });
  };
  L.mirror = function (img) { if (img) mkMirror(img); };
  /** film-strip thumbnail at clip time tv: the nearest still grabbed so far (filled in when the first one exists) */
  L.thumb = function (img, tv) {
    img.dataset.tv = tv;
    var best = nearest(tv);
    if (best) img.src = best.u; else thumbs.push(img);
  };
  function nearest(tv) { var b = null; for (var i = 0; i < stills.length; i++) if (!b || Math.abs(stills[i].t - tv) < Math.abs(b.t - tv)) b = stills[i]; return b; }
  var still = D.createElement('canvas'); still.width = 160; still.height = 90; var sx = null;
  function grab(t) {
    try {
      sx = sx || still.getContext('2d'); sx.drawImage(V, 0, 0, 160, 90);
      var u = still.toDataURL('image/jpeg', .72); stills.push({ t: t, u: u });
      var pend = thumbs; thumbs = []; pend.forEach(function (im) { im.src = u; });
    } catch (e) { /* not ready */ }
  }
  /** resolves when the video has a frame to look at (≤ 1.5 s) */
  L.frameReady = function () {
    return new Promise(function (res) {
      if (!V || V.readyState >= 2) return res();
      var done = function () { V.removeEventListener('loadeddata', done); res(); };
      V.addEventListener('loadeddata', done); setTimeout(done, 1500);
    });
  };

  /* ---------- playback ---------- */
  L.start = function (render, o) {
    var E = W.E || {}, total = o.total || 11;
    L.stats = { frames: 0, ms: 0, max: 0, half: false }; // render cost (tests / debugging)
    if (!V) { POST({ type: 'error', code: 'novideo' }); return; }
    // cheaper per-frame helpers in live mode: refit text only when it changed; grain = set the image once, move it
    if (E.fit) { var f0 = E.fit; E.fit = function (el, maxW, base) { if (!el) return; var k = el.textContent + '|' + maxW + '|' + base; if (el.__fk === k) return; f0(el, maxW, base); if (el.scrollWidth > 0) el.__fk = k; }; }
    if (E.grain) { var gs = W.STYLE ? 192 : 160; E.grain = function (el, T) { if (!el) return; if (!el.__gi) { el.style.backgroundImage = 'url(' + E.grainURL + ')'; el.__gi = 1; } var f = Math.floor(T * 24); if (el.__gf === f) return; el.__gf = f; el.style.backgroundPosition = (f * 73) % gs + 'px ' + (f * 131) % gs + 'px'; }; }

    var stage = D.getElementById('stage'), bg = 'rgba(0,0,0,0)';
    try { bg = getComputedStyle(stage || D.body).backgroundColor; if (/rgba\(0, 0, 0, 0\)|transparent/.test(bg)) bg = getComputedStyle(D.body).backgroundColor; } catch (e) { /* */ }
    var pill = D.querySelector('.pill-skip') || D.getElementById('skip');
    var ready = findReady();
    var lastCt = -1, lastWall = 0, Tshown = -1, watched = 0, lastWT = 0, lastPost = 0, lastVis = 0, phase = '', started = false, ended = false;
    var cost = 0, n = 0, half = false, odd = false, lastGrab = -10, raf = 0, skipSt = '', readySt = '';
    POST({ type: 'boot', bg: bg, total: total, clear: o.clear, end: o.end, hasPill: !!pill, hasReady: !!ready });

    function rectOf(el) { var r = el.getBoundingClientRect(); return { x: r.left, y: r.top, w: r.width, h: r.height }; }
    function shown(el) {
      if (!el || !el.isConnected) return 0;
      var a = 1; for (var x = el; x && x !== D.documentElement; x = x.parentElement) { var cs = getComputedStyle(x); if (cs.display === 'none' || cs.visibility === 'hidden') return 0; a *= +cs.opacity; if (a < .05) return 0; }
      return a;
    }
    function report(kind, el, prev, latch) {
      var a = shown(el), on = a > .5, r = on ? rectOf(el) : null;
      if (!on && latch && prev !== '0' && prev !== '') return prev; // the end card's button stays tappable once it was there (neon flicker etc.)
      var s = on ? [Math.round(r.x), Math.round(r.y), Math.round(r.w), Math.round(r.h)].join(',') : '0';
      if (s !== prev) POST({ type: kind, on: on, rect: r });
      return s;
    }
    function draw(T) {
      if (T === Tshown) return;
      Tshown = T;
      var t0 = performance.now(), pr = null;
      try { pr = render(T); } catch (e) { POST({ type: 'jserror', msg: String(e && e.message || e) }); }
      if (pr && pr.then) pr.then(function () { took(performance.now() - t0); }, function (e) { POST({ type: 'jserror', msg: String(e && e.message || e) }); });
      else took(performance.now() - t0);
    }
    function took(dt) {
      cost += dt; n++; L.stats.frames++; L.stats.ms += dt; if (dt > L.stats.max) L.stats.max = dt; L.stats.half = half;
      if (n >= 30) { var avg = cost / n; half = avg > 7 ? true : avg < 3.5 ? false : half; cost = 0; n = 0; } // slow phone → 30 fps timeline
    }
    function tick(now) {
      raf = requestAnimationFrame(tick);
      var ct = V.currentTime || 0, du = V.duration && isFinite(V.duration) ? V.duration : total;
      if (ct !== lastCt) { lastCt = ct; lastWall = now; }
      var playing = !V.paused && !V.ended && V.readyState >= 3;
      var T = ct; if (playing) T = ct + Math.min(.1, (now - lastWall) / 1000 * (V.playbackRate || 1)); // smooth between coarse clock updates
      if (T < Tshown && Tshown - T < .1 && !V.seeking) T = Tshown;                                     // never step back on jitter
      if (ended) T = Math.max(T, total);
      T = Math.min(T, total);
      // watched seconds (really played), volume fade over the last second
      var d = ct - lastWT; if (d > 0 && d < 1.5 && !V.paused) watched += d; lastWT = ct;
      if (!V.muted) { var vol = ct > du - 1 ? Math.max(0, Math.min(1, (du - ct) / 1)) : 1; if (Math.abs(V.volume - vol) > .01) V.volume = vol; }
      // mirrors (~15 fps, only while visible) + stills for the film strip
      if (V.readyState >= 2) {
        for (var i = 0; i < mirrors.length; i++) {
          var mi = mirrors[i]; if (now - mi.last < mi.every) continue;
          if (!visibleCheap(mi.c)) continue;
          mi.last = now; try { if (mi.f) mi.x.filter = mi.f; mi.x.drawImage(V, -mi.m, -mi.m, mi.c.width + 2 * mi.m, mi.c.height + 2 * mi.m); } catch (e) { /* */ }
        }
        if ((thumbs.length || stills.length < 8) && ct - lastGrab >= 1.4 && (playing || !stills.length)) { lastGrab = ct; grab(ct); }
      }
      odd = !odd;
      if (!half || odd || !playing) draw(T);
      var ph = T < o.clear ? 'intro' : T < o.end ? 'stage' : 'end';
      if (ph !== phase) { phase = ph; POST({ type: 'phase', phase: ph, t: ct }); }
      if (now - lastVis > 200) { lastVis = now; if (pill) skipSt = report('skip', pill, skipSt); if (ready) readySt = report('ready', ready, readySt, true); }
      if (now - lastPost > 250) { lastPost = now; POST({ type: 'progress', t: ct, d: du, watched: watched, paused: V.paused, muted: V.muted, half: half }); }
    }
    function visibleCheap(c) { for (var x = c, k = 0; x && k < 4; x = x.parentElement, k++) { var s = x.style; if ((s.opacity !== '' && +s.opacity < .01) || s.visibility === 'hidden' || s.display === 'none') return false; } return true; }

    V.addEventListener('playing', function () { if (!started) { started = true; POST({ type: 'playing', muted: V.muted }); } });
    V.addEventListener('waiting', function () { POST({ type: 'waiting', t: V.currentTime }); });
    V.addEventListener('ended', function () {
      if (ended) return; ended = true;
      var dd = ct0() - lastWT; if (dd > 0 && dd < 1.5) watched += dd;
      draw(total);
      POST({ type: 'progress', t: V.currentTime, d: V.duration || total, watched: watched, paused: true, muted: V.muted });
      POST({ type: 'ended', t: V.currentTime, d: V.duration || total, watched: watched });
    });
    function ct0() { return V.currentTime || 0; }
    V.addEventListener('error', function () { POST({ type: 'error', code: V.error ? V.error.code : 0 }); });

    function play(withSound) {
      if (withSound) V.muted = false;
      var p; try { p = V.play(); } catch (e) { p = null; }
      if (p && p.then) p.then(function () { POST({ type: 'sound', muted: V.muted }); }, function (err) {
        if (err && err.name === 'NotAllowedError' && !V.muted) { V.muted = true; POST({ type: 'sound', muted: true }); play(false); }
        else if (err && err.name === 'NotAllowedError') POST({ type: 'blocked' });
      });
    }
    W.addEventListener('message', function (e) {
      if (e.source !== W.parent || !e.data || e.data.src !== 'reelhost') return;
      var t = e.data.type;
      if (t === 'unmute') { V.muted = false; play(true); }
      else if (t === 'pause') { try { V.pause(); } catch (x) { /* */ } }
      else if (t === 'play') { if (!ended) play(!V.muted); }
    });
    // a tap right on the in-design pill / button (the parent overlays its own hit areas too)
    D.addEventListener('click', function (e) {
      var tg = e.target;
      if (pill && pill.contains(tg) && shown(pill) > .5) POST({ type: 'tap', what: 'skip' });
      else if (ready && ready.contains(tg) && shown(ready) > .5) POST({ type: 'tap', what: 'ready' });
    });
    raf = requestAnimationFrame(tick);
    play(true);
  };
  function findReady() {
    var all = D.querySelectorAll('#stage *, body > *'), best = null;
    for (var i = 0; i < all.length; i++) {
      var el = all[i]; if (el.children.length > 2) continue;
      var own = ''; for (var c = el.firstChild; c; c = c.nextSibling) if (c.nodeType === 3) own += c.nodeValue;
      if (/i['’]?m ready/i.test(own)) { best = el; break; }
    }
    if (!best) return null;
    for (var k = 0; k < 2 && best.parentElement; k++) { if (/btn|rb|ready|rd|button/i.test(best.className + ' ' + best.id)) break; var p = best.parentElement; if (/btn|rb|ready|rd|button/i.test(p.className + ' ' + p.id)) { best = p; break; } }
    return best;
  }
})();
