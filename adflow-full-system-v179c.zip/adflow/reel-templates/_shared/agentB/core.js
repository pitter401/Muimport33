/* agentB core (formats M..T): a parameterised, deterministic daily-reel timeline.
   INPUT  window.__REEL (set before load), see notes-agentB.md. Missing fields fall back to the sample.
   OUTPUT window.__seek(t) (Promise) renders the frame at t seconds; window.__duration = clip length.
          body[data-ready="1"] once fonts, palette and the first frame are in.
   Timeline (all scaled to video_duration D, 10..45 s):
     0            video + song start (intro sits on a full-screen 40px blur veil)
     3.1 .. 4.2   intro text fades and the blur clears together
     4.2 .. D-2.5 playback layout; quotes[] cycle every QPER s with a crossfade
     D-2.5 .. D   end card overlaps the video tail; last 0.7 s the screen fades with the song */
(function(){
const Q=new URLSearchParams(location.search);
const E=window.E={};
const DEF={name:'Suvo',greeting:'Good morning',date_long:'Friday, 27 November',date_short:'Fri, 27 Nov',
  quotes:['Ek reply, ek client, ek sale.','Aaj ka din tumhara hai.','Every chat is a chance.','Small steps, big month.'],
  yesterday:{earned:50,sales:2},streak:5,line_of_day:'Aaj 3 sale ka target. Tum kar sakte ho.',
  video_url:'',video_duration:0,theme:'',logo_url:'',showing:1,palette:null,frames:null,frames_n:0,frames_fps:30};
const R=E.R=Object.assign({},DEF,window.__REEL||{});
if(Q.get('theme'))R.theme=Q.get('theme');
if(Q.get('show'))R.showing=+Q.get('show');
E.THEME=R.theme==='light'?'light':'dark';
E.SHOW=+R.showing||1;
E.DARK=E.THEME==='dark';
// ---- duration + timeline ----
E.VDUR=+R.video_duration||(R.frames_n?R.frames_n/(R.frames_fps||30):11);
E.VDUR=Math.max(10,Math.min(45,E.VDUR));
E.V0=0;E.VEND=E.VDUR;
E.IN_OUT=3.1;E.IN_FD=1.1;
E.END0=E.VEND-2.5;E.TOTAL=E.VEND;E.FIN=E.TOTAL-.7;
E.PLAY0=E.IN_OUT+E.IN_FD;              // playback layout fully clear
E.QPER=9;                               // quote cycle period (s)
// ---- copy (positive-only) ----
const pos=x=>typeof x==='number'?x>0:(x!=null&&String(x).trim()!==''&&+x!==0);
E.NAME=(R.name||'').trim();
E.GREET=(R.greeting||'Hello').trim();
E.QUOTES=(R.quotes||[]).map(s=>String(s).trim()).filter(Boolean);
if(!E.QUOTES.length)E.QUOTES=[DEF.quotes[0]];
E.QUOTE=E.QUOTES[0];
const Y=R.yesterday||{};
E.EARN=pos(Y.earned)?+Y.earned:0;
E.SALES=pos(Y.sales)?+Y.sales:0;
E.STREAK=pos(R.streak)?+R.streak:0;
E.LINE=(R.line_of_day||'').trim();
{const m=E.LINE.match(/^(.+?[.!?])\s+(.+)$/);E.LINE1=m?m[1]:E.LINE;E.LINE2=m?m[2]:'';}
E.HAS={earned:E.EARN>0&&E.SHOW===1,sales:E.SALES>0&&E.SHOW===1,streak:E.STREAK>0,line:!!E.LINE,name:!!E.NAME,earnplay:E.EARN>0};
E.SALES_T=E.SALES?E.SALES+(E.SALES===1?' sale':' sales'):'';
E.STREAK_T=E.STREAK?E.STREAK+(E.STREAK===1?' day':' days')+' in a row':'';
E.LOGO=R.logo_url||'../_shared/agentB/logo.png';
// ---- math ----
E.clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
E.lerp=(a,b,t)=>a+(b-a)*t;
E.seg=(T,a,b)=>E.clamp((T-a)/(b-a));
E.eo=t=>1-Math.pow(1-t,3);
E.eio=t=>t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2;
E.expo=t=>t>=1?1:1-Math.pow(2,-10*t);
E.spring=(t,k=6.5,w=5.2)=>{if(t<=0)return 0;if(t>=1)return 1;return 1-Math.exp(-k*t)*Math.cos(w*t);};
E.springT=(T,a,d,k,w)=>E.spring(E.seg(T,a,a+d),k,w);
E.hex=h=>{h=h.replace('#','');return [0,2,4].map(i=>parseInt(h.substr(i,2),16));};
E.rgba=(h,a)=>{const c=E.hex(h);return `rgba(${c[0]},${c[1]},${c[2]},${a})`;};
E.mix=(h1,h2,t)=>{const a=E.hex(h1),b=E.hex(h2);return '#'+a.map((v,i)=>Math.round(E.lerp(v,b[i],t)).toString(16).padStart(2,'0')).join('');};
E.tune=(h,s,l)=>{let [r,g,b]=E.hex(h).map(x=>x/255);const mx=Math.max(r,g,b),mn=Math.min(r,g,b);let H=0;const d=mx-mn;
  if(d){if(mx===r)H=((g-b)/d)%6;else if(mx===g)H=(b-r)/d+2;else H=(r-g)/d+4;H*=60;if(H<0)H+=360;}
  const C=(1-Math.abs(2*l-1))*s,X=C*(1-Math.abs((H/60)%2-1)),m=l-C/2;let rr,gg,bb;
  if(H<60)[rr,gg,bb]=[C,X,0];else if(H<120)[rr,gg,bb]=[X,C,0];else if(H<180)[rr,gg,bb]=[0,C,X];else if(H<240)[rr,gg,bb]=[0,X,C];else if(H<300)[rr,gg,bb]=[X,0,C];else [rr,gg,bb]=[C,0,X];
  return '#'+[rr,gg,bb].map(x=>Math.round((x+m)*255).toString(16).padStart(2,'0')).join('');};
E.PAL=null;
E.vib=i=>E.PAL[i%E.PAL.length];
E.vt=(i,s,l)=>E.tune(E.vib(i),s,l);
E.fmt=s=>{s=Math.max(0,Math.floor(s));return Math.floor(s/60)+':'+String(s%60).padStart(2,'0');};
E.typed=(str,T,t0,cps)=>str.slice(0,E.clamp(Math.floor((T-t0)*cps),0,str.length));
E.count=(T,a,b,to)=>to*(.4+.6*E.expo(E.seg(T,a,b)));
E.money=x=>'$'+(+x).toFixed(2);
E.rand=(function(){let s=987654;return()=>{s=(s*16807)%2147483647;return (s-1)/2147483646;};})();
E.$=s=>document.querySelector(s);
E.set=(el,o)=>{if(typeof el==='string')el=E.$(el);if(!el)return;for(const k in o)el.style[k]=o[k];};
E.fade=(T,a,b,c,d)=>Math.min(E.eo(E.seg(T,a,b)),1-E.eio(E.seg(T,c,d)));
/* quote cycling during playback: returns {i,text,a} — a = crossfade alpha (0..1) */
E.qAt=function(T){const n=E.QUOTES.length;const start=n>1?1:0;
  const t=T-E.PLAY0;if(t<0)return {i:start,text:E.QUOTES[start%n],a:1};
  const k=Math.floor(t/E.QPER),ph=t-k*E.QPER;const i=(start+k)%n;
  let a=1;if(n>1){const last=E.PLAY0+(k+1)*E.QPER>E.END0;if(!last&&ph>E.QPER-.6)a=1-E.eio((ph-(E.QPER-.6))/.6);if(k>0&&ph<.7)a=E.eo(ph/.7);}
  return {i,text:E.QUOTES[i],a};};
E.qBind=function(el,T){if(typeof el==='string')el=E.$(el);if(!el)return 1;const q=E.qAt(T);if(el.textContent!==q.text)el.textContent=q.text;el.style.opacity=q.a;return q.a;};
/* bind copy: data-t = key, data-if = key (hidden when empty / zero) */
E.bind=function(){
  const T={name:E.NAME,greet:E.GREET,quote:E.QUOTE,line:E.LINE,line_a:E.LINE1,line_b:E.LINE2,streak_n:String(E.STREAK||''),streak_t:E.STREAK_T,
    earned:E.money(E.EARN),sales_t:E.SALES_T,sales_n:String(E.SALES||''),date_long:R.date_long||'',date_short:R.date_short||''};
  document.querySelectorAll('[data-t]').forEach(el=>{const k=el.dataset.t;let v=T[k]!=null?T[k]:'';if(el.dataset.case==='up')v=v.toUpperCase();if(el.dataset.case==='low')v=v.toLowerCase();el.textContent=v;});
  document.querySelectorAll('[data-if]').forEach(el=>{const ok=el.dataset.if.split(' ').every(k=>k[0]==='!'?!E.HAS[k.slice(1)]:E.HAS[k]);if(!ok)el.style.display='none';});
  document.querySelectorAll('img[data-logo]').forEach(im=>im.src=E.LOGO);
  ['earned','sales','streak','line','name'].forEach(k=>document.body.classList.toggle('no-'+k,!E.HAS[k]));
};
/* ---- video layer: extracted frames (R.frames = printf pattern) or <video> seek ---- */
E.MODE=R.frames?'frames':'video';
E.frameSrc=v=>{const n=R.frames_n||Math.round(E.VDUR*30);const i=E.clamp(Math.floor(v*(R.frames_fps||30))+1,1,n);return R.frames.replace(/%0(\d)d/,(m,w)=>String(i).padStart(+w,'0'));};
E.setupVideo=function(){if(E.MODE!=='video')return;
  document.querySelectorAll('img.vid').forEach(im=>{const vd=document.createElement('video');vd.className=im.className;vd.muted=true;vd.playsInline=true;vd.preload='auto';vd.src=R.video_url;vd.style.cssText=im.style.cssText;vd.style.objectFit='cover';im.replaceWith(vd);});};
E.setFrame=async function(v){
  if(E.MODE==='frames'){const src=E.frameSrc(v);const ps=[];
    document.querySelectorAll('img.vid').forEach(im=>{if(im.getAttribute('src')!==src){im.setAttribute('src',src);ps.push(im.decode().catch(()=>{}));}});
    await Promise.all(ps);return;}
  const ps=[];document.querySelectorAll('video.vid').forEach(vd=>{if(Math.abs(vd.currentTime-v)>1e-3){ps.push(new Promise(r=>{const f=()=>{vd.removeEventListener('seeked',f);r();};vd.addEventListener('seeked',f);vd.currentTime=v;setTimeout(r,3000);}));}});
  await Promise.all(ps);};
/* ---- palette from the video (hue-binned vivid colours); R.palette overrides ---- */
E.analyze=async function(){
  if(Array.isArray(R.palette)&&R.palette.length){E.PAL=R.palette;return;}
  const fb=E.DARK?['#702639','#7d4d3e','#6f3454','#5f90a8','#2e466c']:['#f9e3d1','#fdead1','#d8e3f0','#d5e4f0','#e4d0d4'];
  try{const c=document.createElement('canvas');c.width=48;c.height=27;const x=c.getContext('2d');const bins={};
    for(const f of [.1,.3,.5,.7,.9]){const t=f*E.VDUR;let src;
      if(E.MODE==='frames'){src=new Image();src.src=E.frameSrc(t);await src.decode();}
      else{src=document.querySelector('video.vid');await E.setFrame(t);}
      x.drawImage(src,0,0,48,27);const d=x.getImageData(0,0,48,27).data;
      for(let i=0;i<d.length;i+=4){const r=d[i]/255,g=d[i+1]/255,b=d[i+2]/255,mx=Math.max(r,g,b),mn=Math.min(r,g,b),l=(mx+mn)/2,dd=mx-mn;if(!dd)continue;
        const s=dd/(1-Math.abs(2*l-1));if(s<.25||l<.12||l>.93)continue;let H;if(mx===r)H=((g-b)/dd)%6;else if(mx===g)H=(b-r)/dd+2;else H=(r-g)/dd+4;H=((H*60)+360)%360;
        const k=Math.floor(H/30),w=s*(1-Math.abs(l-.5)*1.2);const a=bins[k]||(bins[k]=[0,0,0,0]);a[0]+=w;a[1]+=d[i]*w;a[2]+=d[i+1]*w;a[3]+=d[i+2]*w;}}
    const top=Object.values(bins).sort((a,b)=>b[0]-a[0]).slice(0,5).map(a=>'#'+[a[1],a[2],a[3]].map(v=>Math.round(v/a[0]).toString(16).padStart(2,'0')).join(''));
    while(top.length&&top.length<5)top.push(top[top.length-1]);E.PAL=top.length?top:fb;}catch(e){E.PAL=fb;}
};
/* grain */
E.grainURL=(function(){const c=document.createElement('canvas');c.width=c.height=160;const x=c.getContext('2d');const d=x.createImageData(160,160);let s=12345;for(let i=0;i<d.data.length;i+=4){s=(s*16807)%2147483647;const v=s%255;d.data[i]=d.data[i+1]=d.data[i+2]=v;d.data[i+3]=255;}x.putImageData(d,0,0);return c.toDataURL();})();
E.grain=(el,T)=>{if(!el)return;el.style.backgroundImage=`url(${E.grainURL})`;const f=Math.floor(T*24);el.style.backgroundPosition=`${(f*73)%160}px ${(f*131)%160}px`;};
/* full-screen frosted veil: CSS blur on #stage (everything but the intro), uniform edge to edge */
E.veil=function(T,io,tint){const el=document.getElementById('veil');const k=E.clamp(io);const st=document.getElementById('stage');
  if(st){st.style.filter=k>0.001?`blur(${(40*k).toFixed(2)}px) saturate(${1+.2*k})`:'none';}
  if(el){el.style.background=tint.replace('A',(k*(E.DARK?.32:.30)).toFixed(3));el.style.visibility=k<=0.001?'hidden':'visible';}};
E.CHEV='<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M5 2.5 9.5 7 5 11.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
E.ARROW='<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M2.5 8h10M8.5 3.5 13 8l-4.5 4.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
window.__duration=E.TOTAL;
window.renderAt=window.__seek=async function(T){
  T=E.clamp(+T||0,0,E.TOTAL);
  const v=E.clamp(T-E.V0,0,E.VDUR-0.001);
  await E.setFrame(v);
  window.FMT.render(T,v);
  let f=document.getElementById('fin');if(!f){f=document.createElement('div');f.id='fin';f.style.cssText='position:absolute;inset:0;pointer-events:none;z-index:99;background:'+getComputedStyle(document.body).backgroundColor;document.body.appendChild(f);}
  f.style.opacity=E.eio(E.seg(T,E.FIN,E.TOTAL)).toFixed(3);
};
window.addEventListener('load',async()=>{
  document.body.classList.add(E.THEME);
  if(E.SHOW>1)document.body.classList.add('rep');
  E.setupVideo();
  await E.analyze();
  E.bind();
  window.FMT.init();
  await document.fonts.ready;
  const t=Q.get('t');await window.__seek(t!=null?+t:2.8);
  document.body.dataset.ready='1';
});
})();
