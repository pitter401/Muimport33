/* AdsBhai admin status templates (adminA) - shared runtime.
   Input: window.__REEL (see notes-adminA.md). Output: window.__seek(t) renders frame at t seconds. */
(function(){
const DEF={name:'AdsBhai Admin',greeting:'Good morning',
 dates:{today:'Fri 27 Nov',today_short:'27 Nov',yesterday:'Thu 26 Nov',yesterday_long:'Thursday, 26 November',weekday_y:'Thursday',weekday_t:'Friday',day_y:'26',day_t:'27',month:'November',year:'2026'},
 quotes:['New day. New clients. New wins.','Small steps, big month.','Every chat is a chance.','Consistency beats talent.','Win the morning, win the day.','Your next sale is one chat away.'],
 yesterday:{earned:134.87,sales:5,revenue:140,tg:{sales:4,amount:130},wa:{sales:1,amount:10},fees:0.87,fees_on:29.13},
 streak:5,line_of_day:'Aaj phir se shuru karte hain.',video_url:'',video_duration:338/30,theme:'dark',logo_url:'../_shared/adminA/logo.png'};
const _qs=new URLSearchParams(location.search);
const SAMPLE_FRAMES={sharp:'../_shared/adminA/sample/sharp/f_{n}.jpg',blur:'../_shared/adminA/sample/blur/f_{n}.jpg',fps:30,count:338};
const I=window.__REEL||{};
const R=Object.assign({},DEF,I);R.dates=Object.assign({},DEF.dates,I.dates||{});
const yIn=I.yesterday||DEF.yesterday;R.yesterday=Object.assign({tg:{},wa:{}},yIn);
if(!R.quotes||!R.quotes.length)R.quotes=DEF.quotes;
if(_qs.get('theme'))R.theme=_qs.get('theme');
if(!R.frames&&!I.video_url)R.frames=R.theme==='light'?{sharp:'../_shared/adminA/sample_light/sharp/f_{n}.jpg',blur:'../_shared/adminA/sample_light/blur/f_{n}.jpg',fps:30,count:335}:SAMPLE_FRAMES;
R.video_duration=Math.max(10,Math.min(45,+R.video_duration||DEF.video_duration));
window.R=R;window.Y=R.yesterday;window.LIGHT=R.theme==='light';if(window.LIGHT)document.documentElement.classList.add('light');
})();
const $=id=>document.getElementById(id);
const cl=(x,a=0,b=1)=>Math.max(a,Math.min(b,x)),lerp=(a,b,t)=>a+(b-a)*t,seg=(T,a,b)=>cl((T-a)/(b-a));
const eo=t=>1-Math.pow(1-t,3),eio=t=>t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2,expo=t=>t>=1?1:1-Math.pow(2,-10*t),sine=t=>-(Math.cos(Math.PI*t)-1)/2;
const spring=t=>{if(t<=0)return 0;if(t>=1)return 1;return 1-Math.exp(-6.5*t)*Math.cos(5.2*t);};
const VDUR=R.video_duration,T_VEND=VDUR,T_FADE=3.3,FADE_D=1.1,T_END=VDUR-2.05,TOTAL=VDUR,Q_EVERY=9;
window.TIMES={TOTAL,T_FADE,FADE_D,T_END};
// ---- data helpers ----
const pos=v=>typeof v==='number'&&isFinite(v)&&v>0;
const M=v=>{if(!pos(v))return '';const r=Math.round(v*100)/100;return '$'+(Number.isInteger(r)?r.toLocaleString('en-US'):r.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2}));};
const MN=v=>M(v).slice(1); // without $
const pl=(n,w)=>n+' '+w+(n===1?'':'s');
const U=s=>String(s).toUpperCase();
const HERO=()=>pos(Y.earned)?{l:'Yesterday you earned',k:'Earned',v:Y.earned}:pos(Y.revenue)?{l:"Yesterday's revenue",k:'Revenue',v:Y.revenue}:{l:'Yesterday',k:'',v:0};
const SR=(sep=' · ')=>[pos(Y.sales)?pl(Y.sales,'sale'):'',pos(Y.revenue)?M(Y.revenue)+' revenue':''].filter(Boolean).join(sep);
const CHN=()=>[['Telegram',Y.tg,'TG'],['WhatsApp',Y.wa,'WA']].filter(c=>c[1]&&pos(c[1].amount));
const SPLIT=(sep=' &nbsp;&middot;&nbsp; ',cnt=true)=>CHN().map(([n,c])=>`${n} <b>${M(c.amount)}</b>`+(cnt&&pos(c.sales)?` &middot; ${c.sales}`:'')).join(sep);
// ---- video layer: extracted frames (R.frames) or <video> seeked ----
const fidx=t=>{const F=R.frames;return cl(Math.floor(t*F.fps)+1,1,F.count);};
function prepVideo(){if(R.frames)return;document.querySelectorAll('img.vid,img.vblur').forEach(im=>{const v=document.createElement('video');v.muted=true;v.playsInline=true;v.preload='auto';v.src=R.video_url;
 v.id=im.id;v.className=im.className;const cs=getComputedStyle(im);['position','left','top','width','height','objectFit','opacity','display','borderRadius','transform'].forEach(k=>v.style[k]=cs[k]);
 if(im.classList.contains('vblur'))v.style.filter='blur(16px) saturate(1.1)';im.replaceWith(v);});}
async function setVid(t){t=Math.min(t,VDUR-.02);
 if(R.frames){const n=String(fidx(t)).padStart(4,'0');const ps=[];document.querySelectorAll('img.vid,img.vblur').forEach(im=>{const src=(im.classList.contains('vid')?R.frames.sharp:(R.frames.blur||R.frames.sharp)).replace('{n}',n);if(im.getAttribute('src')!==src){im.setAttribute('src',src);ps.push(im.decode().catch(()=>{}));}});await Promise.all(ps);return;}
 await Promise.all([...document.querySelectorAll('video.vid,video.vblur')].map(v=>new Promise(res=>{if(Math.abs(v.currentTime-t)<.001&&v.readyState>=2)return res();const f=()=>{v.removeEventListener('seeked',f);res();};v.addEventListener('seeked',f);v.currentTime=t;setTimeout(res,3000);})));}
// ---- bindings: data-b (text), data-h (html), data-if (hide when falsy) ----
function bind(root=document){root.querySelectorAll('[data-if]').forEach(el=>{let ok;try{ok=new Function('R','Y','M','pos','return '+el.dataset.if)(R,Y,M,pos);}catch(e){ok=false;}if(!ok)el.style.display='none';});
 root.querySelectorAll('[data-b]').forEach(el=>{el.textContent=new Function('R','Y','M','pl','U','return '+el.dataset.b)(R,Y,M,pl,U);});
 root.querySelectorAll('[data-h]').forEach(el=>{el.innerHTML=new Function('R','Y','M','pl','U','return '+el.dataset.h)(R,Y,M,pl,U);});
 document.querySelectorAll('img[data-logo]').forEach(im=>im.src=R.logo_url);}
// quotes cycling during playback (crossfade every ~9 s); elements with class "qcycle"
function qcycle(T){const n=R.quotes.length;const t=Math.max(0,T-T_FADE);const i=Math.floor(t/Q_EVERY)%n;const ph=t%Q_EVERY;
 const o=n<2?1:Math.min(1,ph/.6,(Q_EVERY-ph)/.6);const q=R.quotes[i];
 document.querySelectorAll('.qcycle').forEach(el=>{if(el._q!==q){el.textContent=q;el._q=q;}el.style.opacity=(T<T_FADE?1:o);});}
// ---- motion helpers ----
const introK=T=>1-sine(seg(T,T_FADE,T_FADE+FADE_D));
// Intro veil: a full-bleed pre-blurred video layer (uniform, no chrome visible) above a hidden #base.
// During the fade the veil fades out while #base fades in from a light blur (cheap), so the blur appears to clear.
function veil(T,max=40,dim=.28){const k=introK(T);const b=$('base');const v=$('veil');
 if(k>0.999){b.style.opacity=0;b.style.visibility='hidden';b.style.filter='none';}
 else{b.style.visibility='visible';b.style.opacity=(1-k).toFixed(3);b.style.filter=k>0.002?`blur(${(14*k).toFixed(2)}px)`:'none';}
 v.style.opacity=k.toFixed(3);v.style.visibility=k<=0.001?'hidden':'visible';
 $('veilDim').style.background=LIGHT?`rgba(250,247,242,${.42})`:`rgba(0,0,0,${dim})`;return k;}
const show=(el,o,tr)=>{el.style.opacity=o;el.style.visibility=o<=0.001?'hidden':'visible';if(tr!==undefined)el.style.transform=tr;};
const rise=(el,T,a,d,y,blur)=>{const k=expo(seg(T,a,a+d));el.style.opacity=seg(T,a,a+d*.55);el.style.transform=`translateY(${(1-k)*y}px)`;if(blur)el.style.filter=`blur(${(1-k)*blur}px)`;};
function outroStd(T){const pout=sine(seg(T,T_END,T_END+.7));show($('outro'),pout);
 const olk=spring(seg(T,T_END+.3,T_END+1.2));const lg=$('ologo');if(lg){lg.style.opacity=seg(T,T_END+.3,T_END+.55);lg.style.transform=`scale(${.82+.18*olk})`;}
 const sh=$('osh');if(sh)sh.style.left=lerp(-60,140,eio(seg(T,T_END+.8,T_END+1.4)))+'%';
 if($('ourl'))rise($('ourl'),T,T_END+.55,.8,8);if($('otag'))rise($('otag'),T,T_END+.75,.8,8);
 $('fade').style.opacity=seg(T,TOTAL-.3,TOTAL);return pout;}
function hx(h){h=h.replace('#','');return [0,2,4].map(i=>parseInt(h.substr(i,2),16)/255);}
function hsl(hex){let [r,g,b]=hx(hex);const mx=Math.max(r,g,b),mn=Math.min(r,g,b);let h=0,s=0,l=(mx+mn)/2;if(mx!==mn){const d=mx-mn;s=l>.5?d/(2-mx-mn):d/(mx+mn);h=mx===r?(g-b)/d+(g<b?6:0):mx===g?(b-r)/d+2:(r-g)/d+4;h*=60;}return [h,s,l];}
const css=(h,s,l,a=1)=>`hsla(${h.toFixed(1)},${(s*100).toFixed(1)}%,${(l*100).toFixed(1)}%,${a})`;
// palette: sampled live from the blurred video layer (works for frames or <video>)
const _pc=document.createElement('canvas');_pc.width=8;_pc.height=5;const _px=_pc.getContext('2d',{willReadFrequently:true});let _ph=280,_ps=.5;
function pal(){const src=document.querySelector('.vblur')||document.querySelector('.vid');try{_px.drawImage(src,0,0,8,5);const d=_px.getImageData(0,0,8,5).data;let best=-1,h=_ph,s=_ps;
 for(let i=0;i<d.length;i+=4){const hex='#'+[d[i],d[i+1],d[i+2]].map(v=>v.toString(16).padStart(2,'0')).join('');const [hh,ss,ll]=hsl(hex);const sc=ss*Math.min(ll,1-ll);if(sc>best){best=sc;h=hh;s=ss;}}
 let dh=((h-_ph+540)%360)-180;_ph=(_ph+dh*.08+360)%360;_ps+=(s-_ps)*.08;}catch(e){}return {h:_ph,s:_ps};}
const grain=(()=>{const c=document.createElement('canvas');c.width=c.height=160;const x=c.getContext('2d');const d=x.createImageData(160,160);let s=777;for(let i=0;i<d.data.length;i+=4){s=(s*16807)%2147483647;const v=s%255;d.data[i]=d.data[i+1]=d.data[i+2]=v;d.data[i+3]=255;}x.putImageData(d,0,0);return c.toDataURL();})();
let _rs=11;const rnd=()=>{_rs=(_rs*16807)%2147483647;return (_rs-1)/2147483646;};
function hash(a,b){let h=(a*374761393+b*668265263)^0x5bd1e995;h=(h^(h>>>13))*1274126177;return ((h^(h>>>16))>>>0)/4294967295;}
window.__seek=async t=>{await window.renderAt(t);};
function mkVeil(){const b=$('base');const v=document.createElement('div');v.id='veil';v.style.cssText='position:absolute;inset:0;overflow:hidden;z-index:'+(+getComputedStyle(b).zIndex||0);
 v.innerHTML='<img class="vblur" style="position:absolute;inset:-24px;width:408px;height:688px;object-fit:cover;filter:saturate(1.15)"><div id="veilDim" style="position:absolute;inset:0"></div>';b.after(v);}
window.addEventListener('load',async()=>{if(LIGHT)document.body.classList.add('light');mkVeil();prepVideo();bind();await document.fonts.ready;if(window.init)await window.init();const q=new URLSearchParams(location.search);await renderAt(+(q.get('t')||0));document.body.dataset.ready='1';});
