/* AdsBhai status-reel core (adminB formats). Data: window.__REEL. Seek: window.__seek(t). */
(function(G){
const SAMPLE={name:'AdsBhai Admin',greeting:'Good morning',
 date:{weekday:'Thursday',day:'26',month:'November',year:'2026',short:'Thu 26 Nov',long:'Thursday, 26 November 2026',numeric:'26.11.2026'},
 quotes:['Consistency beats talent.','Small steps, big month.','Discipline today, freedom tomorrow.','Great things take daily work.','Win the morning, win the day.'],
 yesterday:{earned:134.87,sales:5,revenue:140,tg:{sales:4,amount:130},wa:{sales:1,amount:10},fees:0.87,fees_on:29.13},
 streak:0,line_of_day:'',video_url:'',video_duration:337/30,logo_url:'../_shared/adminB/logo.png',
 frames:{base:'../_shared/adminB/sample/vf/f_',blur:'../_shared/adminB/sample/vb/f_',count:338,fps:30,ext:'.jpg',pad:4}};
const q=new URLSearchParams(location.search);
const R=G.__REEL||SAMPLE; if(!R.logo_url)R.logo_url=SAMPLE.logo_url;
if(q.get('dur'))R.video_duration=+q.get('dur');if(q.get('zero')){R.yesterday=JSON.parse(JSON.stringify(R.yesterday));R.yesterday.wa={sales:0,amount:0};R.yesterday.fees=0;R.yesterday.sales=4;R.yesterday.revenue=130;R.yesterday.earned=129.13;}
const VD=Math.max(1,+R.video_duration||11);
const T={F0:3.0,F1:4.1,E0:VD-2.05,E1:VD-1.35,TOTAL:VD};
G.R=R;G.TIMES={...T,T_TOTAL:VD};
const get=(p,o=R)=>p.split('.').reduce((a,k)=>a==null?undefined:a[k],o);
const has=p=>{const v=get(p);return typeof v==='number'?v>0:!!(v&&String(v).trim());};
const money=v=>'$'+(+v).toLocaleString('en-US',{minimumFractionDigits:(Math.round(v*100)%100)?2:0,maximumFractionDigits:2});
const num=v=>(+v).toLocaleString('en-US');
const cl=(x,a=0,b=1)=>Math.min(b,Math.max(a,x)),P=(t,a,b)=>cl((t-a)/(b-a));
const eo=x=>1-Math.pow(1-x,3),eio=x=>x<.5?4*x*x*x:1-Math.pow(-2*x+2,3)/2;
const eb=x=>{const c1=1.70158,c3=c1+1;return 1+c3*Math.pow(x-1,3)+c1*Math.pow(x-1,2)};
const L=(a,b,t)=>a+(b-a)*t,$=id=>document.getElementById(id);
function st(el,o){el=typeof el=='string'?$(el):el;if(!el)return;for(const k in o)el.style[k]=o[k];}
function rise(el,t,a,d=.6,dy=40){const k=eo(P(t,a,a+d));st(el,{opacity:k,transform:`translateY(${(1-k)*dy}px)`});}
const cuM=(t,a,b,v)=>money(Math.round(v*(0.15+0.85*eo(P(t,a,b)))*100)/100);
const cuN=(t,a,b,v)=>num(Math.max(1,Math.round(v*(0.15+0.85*eo(P(t,a,b))))));
const introOp=t=>1-eio(P(t,T.F0,T.F1)),endOp=t=>eio(P(t,T.E0,T.E1));
// quotes: cycle every 9 s during playback with 0.8 s crossfade
const QS=(Array.isArray(R.quotes)?R.quotes:[]).filter(s=>s&&String(s).trim());if(!QS.length&&has('line_of_day'))QS.push(R.line_of_day);
const QP=9;
function quoteAt(t){if(!QS.length)return{text:'',op:0};const u=Math.max(0,t-T.F0);const i=Math.floor(u/QP),l=u-i*QP;const last=t+QP-l>T.E0;
 let op=1;if(i>0)op=Math.min(op,l/0.8);if(!last)op=Math.min(op,(QP-l)/0.8);return{text:QS[i%QS.length],op:cl(op)};}
function veil(t,amt=40,dim=.32){const k=introOp(t);if(G.THEME=='light'){amt=Math.max(amt,72);dim=0;}let v=$('veil');if(!v){v=document.createElement('div');v.id='veil';v.style.cssText='position:absolute;inset:0;pointer-events:none';$('intro').before(v);}
 v.style.display=k>0.002?'block':'none';v.style.backdropFilter=v.style.webkitBackdropFilter=`blur(${(amt*k).toFixed(2)}px) brightness(${(1-dim*k).toFixed(3)}) saturate(${(1+0.25*k).toFixed(3)})`;
 document.querySelectorAll('.chrome').forEach(c=>c.style.opacity=(1-k).toFixed(3));
 const i=$('intro');i.style.opacity=k;i.style.display=k>0.002?'block':'none';return k;}
// bindings
function tagc(){document.querySelectorAll('[style]').forEach(e=>{if(e.dataset.c)return;const m=(e.getAttribute('style')||'').match(/(?:^|;)\s*color:\s*(#[0-9a-fA-F]{3,6})/);if(m)e.dataset.c=m[1].toLowerCase();});}
function fitAll(){document.querySelectorAll('.fit').forEach(e=>{if(!e.isConnected)return;const d=e.style.display;e.style.whiteSpace='nowrap';let fs=parseFloat(getComputedStyle(e).fontSize),n=0;while(e.scrollWidth>e.clientWidth+1&&fs>14&&n<80){fs*=0.95;e.style.fontSize=fs.toFixed(1)+'px';n++;}});}
function plural(n,w){return n==1?w:w+'s';}
function bind(){
 document.querySelectorAll('[data-if]').forEach(e=>{if(!e.dataset.if.split(' ').every(has))e.remove();});
 document.querySelectorAll('[data-t]').forEach(e=>{const v=get(e.dataset.t);e.textContent=v==null?'':v;});
 document.querySelectorAll('[data-m]').forEach(e=>{const v=get(e.dataset.m);e.textContent=v>0?money(v):'';});
 document.querySelectorAll('[data-n]').forEach(e=>{const v=get(e.dataset.n);e.textContent=v>0?num(v):'';});
 document.querySelectorAll('[data-pl]').forEach(e=>{const [p,w]=e.dataset.pl.split(':');e.textContent=plural(+get(p),w);});
 document.querySelectorAll('img[data-logo]').forEach(e=>e.src=R.logo_url);document.querySelectorAll('[data-greet]').forEach(e=>e.textContent=(R.greeting||'Hello')+',');
}
// video layer: canvases canvas[data-v=f|b]
let src=null,mode='frames',lastKey=null;const FR=R.frames;
async function vinit(){if(R.video_url&&!(FR&&FR.base)){mode='video';src=document.createElement('video');src.muted=true;src.preload='auto';if(R.video_cors)src.crossOrigin='anonymous';src.src=R.video_url;
 await new Promise(r=>{src.addEventListener('loadeddata',r,{once:true});src.addEventListener('error',()=>{console.warn('reel: video failed to load',R.video_url);r();},{once:true});setTimeout(r,15000);});}
 else{src=new Image();}
 document.querySelectorAll('canvas[data-v]').forEach(c=>{if(c.dataset.v=='b'){c.width=192;c.height=108;}else{c.width=1280;c.height=720;}});}
async function vseek(t){let s=src,key;
 if(mode=='video'){if(!(src.readyState>=1))return;const tt=Math.max(0,Math.min(t,(src.duration||VD)-0.04));key=tt.toFixed(3);if(key!==lastKey){await new Promise(r=>{const to=setTimeout(r,3000);src.addEventListener('seeked',()=>{clearTimeout(to);r();},{once:true});src.currentTime=tt;});}}
 else{const n=Math.max(1,Math.min(FR.count,Math.floor(t*FR.fps+1e-6)+1));key=n;if(key!==lastKey){src.src=FR.base+String(n).padStart(FR.pad,'0')+FR.ext;await src.decode().catch(()=>{});}}
 if(key===lastKey)return;lastKey=key;
 document.querySelectorAll('canvas[data-v]').forEach(c=>{const x=c.getContext('2d');if(c.dataset.v=='b'){x.filter='blur(4px)';x.drawImage(s,-12,-12,c.width+24,c.height+24);}else{x.drawImage(s,0,0,c.width,c.height);}});}
G.__seek=async t=>{G.draw(t);await vseek(t);};G.renderAt=G.__seek;
Object.assign(G,{R,get,has,money,num,cl,P,eo,eio,eb,L,$,st,rise,cuM,cuN,introOp,endOp,quoteAt,veil,plural,QS});
G.THEME=(q.get('theme')||R.theme||(G.__MANIFEST&&G.__MANIFEST.default_theme)||'dark')=='light'?'light':'dark';
G.addEventListener('load',async()=>{if(G.THEME=='light')document.body.classList.add('light');tagc();bind();await document.fonts.ready;if(G.setup)G.setup();tagc();G.draw(T.F0-0.02);fitAll();await vinit();await G.__seek(+(q.get('t')||0));document.body.dataset.ready='1';});
})(window);
