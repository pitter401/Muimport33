/* agentA shared reel engine (formats E-L).
   Data: window.__REEL (see notes-agentA.md). Deterministic: window.__seek(t) renders clip time t (seconds).
   Video layer: REEL.frames {dir,count,fps,pad,prefix,ext} (pre-extracted JPEGs) OR <video> elements seeked to t. */
(function(){
const Q=new URLSearchParams(location.search);
/* Contract matches agentB (M–T): name, greeting, date_long, date_short, quotes[], yesterday{earned,sales}, streak,
   line_of_day, video_url, video_duration (10–45), theme, logo_url, showing (1–4), palette[] (optional),
   frames (printf pattern) + frames_n + frames_fps (preview only). agentA extra (optional): target (today's sales target).
   With no window.__REEL at all, the page renders the built-in sample (Suvo, sample frames) for previews. */
const SAMPLE={name:'Suvo',greeting:'Good morning',date_long:'Friday, 27 November',date_short:'Fri, 27 Nov',
  quotes:['New day. New clients. New wins.','Every chat is a chance.','Ek reply, ek client, ek sale.','Small steps, big month.','Aaj ka din tumhara hai.'],
  yesterday:{earned:50,sales:2},streak:5,target:3,line_of_day:'Aaj 3 sale ka target. Tum kar sakte ho.',
  video_url:'',video_duration:338/30,theme:'dark',logo_url:'',showing:1,palette:null,
  frames:'/tmp/claude-0/-home-claude/cb845b55-c3c7-55a0-9e7b-bbaa7f953ad8/scratchpad/review166/reel/styles/frames/{theme}/f_%04d.jpg',frames_n:338,frames_fps:30};
const BLANK={name:'',greeting:'Hello',date_long:'',date_short:'',quotes:[],yesterday:{},streak:0,target:0,line_of_day:'',
  video_url:'',video_duration:0,theme:'dark',logo_url:'',showing:1,palette:null,frames:null,frames_n:0,frames_fps:30};
const R=window.__REEL?Object.assign({},BLANK,window.__REEL):Object.assign({},SAMPLE);
if(Q.get('theme'))R.theme=Q.get('theme'); if(Q.get('show'))R.showing=+Q.get('show'); if(Q.get('dur'))R.video_duration=+Q.get('dur');
const E=window.E={R};
E.THEME=R.theme==='light'?'light':'dark'; E.L=E.THEME==='light'; E.SHOW=+R.showing||1;
E.VDUR=+R.video_duration||(R.frames_n?R.frames_n/(R.frames_fps||30):11); E.VDUR=Math.max(10,Math.min(45,E.VDUR)); E.V0=0;
E.I_OUT=2.6; E.I_FADE=1.15;                         // intro holds 0-2.6 s, then veil + text clear together over 1.15 s
E.T_END=Math.max(E.I_OUT+3,E.VDUR-2.35);             // end card overlaps the last ~2.3 s of the video
E.TOTAL=E.VDUR;
E.SHARED=(document.currentScript&&document.currentScript.src||'').replace(/core\.js.*$/,'');
/* ---- data ---- */
const Y=R.yesterday||{}; /* earnings only on showing 1 */ E.earned=E.SHOW>1?0:Math.max(0,+Y.earned||0); E.sales=Math.max(0,Math.round(+Y.sales||0));
E.streak=Math.max(0,Math.round(+R.streak||0)); E.target=Math.max(0,Math.round(+R.target||0));
E.quotes=(R.quotes||[]).map(s=>String(s||'').trim()).filter(Boolean); if(!E.quotes.length)E.quotes=['New day. New clients. New wins.'];
E.fmt$=x=>'$'+x.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
E.plural=(n,w)=>n+' '+w+(n===1?'':'s');
const line=String(R.line_of_day||'').trim()||E.quotes[0]; const m=line.match(/^(.+?[.!?])\s+(.+)$/);
const MON={jan:1,feb:2,mar:3,apr:4,may:5,jun:6,jul:7,aug:8,sep:9,oct:10,nov:11,dec:12};
const dl=String(R.date_long||''),ds=String(R.date_short||'');const di=dl.indexOf(',');
const D={weekday:di>0?dl.slice(0,di).trim():dl,day_month:di>0?dl.slice(di+1).trim():'',short:ds.replace(',','')};
{const mm=(D.day_month||ds).match(/(\d{1,2})\s+([A-Za-z]{3})/);D.num=mm&&MON[mm[2].toLowerCase()]?mm[1].padStart(2,'0')+'.'+String(MON[mm[2].toLowerCase()]).padStart(2,'0'):'';}
D.year=String(R.year||'');
E.VAL={name:R.name||'',greeting:R.greeting||'Hello',gname:(R.greeting||'Hello')+',',weekday:D.weekday||'',daymonth:D.day_month||'',short:D.short||'',num:D.num||'',year:D.year||'',date_long:dl,
  q0:E.quotes[0],line:line,line1:m?m[1]:line,line2:m?m[2]:'',earned:E.fmt$(E.earned),sales:String(E.sales),salesw:E.plural(E.sales,'sale'),
  streak:String(E.streak),streakw:E.plural(E.streak,'day'),target:String(E.target),targetw:E.plural(E.target,'sale'),NAME:(R.name||'').toUpperCase()};
E.has={earned:E.earned>0,sales:E.sales>0,streak:E.streak>0,target:E.target>0,line2:!!(m&&m[2]),yesterday:E.earned>0||E.sales>0,s1:E.SHOW===1,s2:E.SHOW>1};
E.has.s1earn=E.has.s1&&E.has.earned; E.has.notarget=!E.has.target;
/* ---- timing ---- */
E.clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x)); E.lerp=(a,b,t)=>a+(b-a)*t; E.seg=(T,a,b)=>E.clamp((T-a)/(b-a));
E.eo=t=>1-Math.pow(1-t,3); E.eio=t=>t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2; E.expo=t=>t>=1?1:1-Math.pow(2,-10*t);
E.sine=t=>-(Math.cos(Math.PI*t)-1)/2;
E.back=t=>{const c1=1.4,c3=c1+1;return 1+c3*Math.pow(t-1,3)+c1*Math.pow(t-1,2);};
E.hex=h=>{h=h.replace('#','');return [0,2,4].map(i=>parseInt(h.substr(i,2),16));};
E.mix=(h1,h2,t)=>{const a=E.hex(h1),b=E.hex(h2);return `rgb(${a.map((v,i)=>Math.round(E.lerp(v,b[i],t))).join(',')})`;};
E.introK=T=>1-E.sine(E.seg(T,E.I_OUT,E.I_OUT+E.I_FADE));
E.endK=(T,d)=>E.eo(E.seg(T,E.T_END,E.T_END+(d||.9)));
E.money=(T,a,d)=>E.fmt$(E.earned*E.expo(E.seg(T,a,a+d)));
/* playback quotes: cycle every 9 s from the moment the intro clears, gentle dip-crossfade */
E.Q_P0=E.I_OUT+E.I_FADE; E.Q_PER=9;
E.qAt=T=>{const n=E.quotes.length;if(T<E.Q_P0)return {t:E.quotes[1%n],k:1};const p=T-E.Q_P0,i=Math.floor(p/E.Q_PER),l=p-i*E.Q_PER;
  let k=1;if(n>1){if(i>0)k=Math.min(k,E.sine(E.clamp(l/.7)));const nx=(i+1)*E.Q_PER+E.Q_P0;if(nx<E.T_END)k=Math.min(k,E.sine(E.clamp((E.Q_PER-l)/.7)));}
  return {t:E.quotes[(1+i)%n],k};};
E.tint=v=>{const M=window.META&&window.META[E.THEME];if(M&&!window.__REEL&&M.vib)return M.vib[E.fi(v)-1];if(Array.isArray(R.palette)&&R.palette[0])return R.palette[0];return E.L?'#f3d9c4':'#6a4a46';};
/* ---- video ---- */
const F=R.frames||null; E.FPS=+R.frames_fps||30; const FN=+R.frames_n||Math.round(E.VDUR*E.FPS);
E.fi=v=>F?E.clamp(Math.floor(v*E.FPS)+1,1,FN):0;
E.src=v=>F.replace('{theme}',E.THEME).replace(/%0(\d)d/,(m,w)=>String(E.fi(v)).padStart(+w,'0'));
E.setImg=(im,src,ps)=>{if(im.getAttribute('src')!==src){im.setAttribute('src',src);ps.push(im.decode().catch(()=>{}));}};
E.seekVid=(vd,t,ps)=>{t=Math.min(t,(vd.duration||E.VDUR)-.02);if(Math.abs(vd.currentTime-t)<.004)return;ps.push(new Promise(r=>{const f=()=>{vd.removeEventListener('seeked',f);r();};vd.addEventListener('seeked',f);vd.currentTime=t;setTimeout(r,1500);}));};
E.grainURL=(function(){const c=document.createElement('canvas');c.width=c.height=192;const x=c.getContext('2d');const d=x.createImageData(192,192);let s=12345;for(let i=0;i<d.data.length;i+=4){s=(s*16807)%2147483647;const v=s%255;d.data[i]=d.data[i+1]=d.data[i+2]=v;d.data[i+3]=255;}x.putImageData(d,0,0);return c.toDataURL();})();
E.grain=(el,T)=>{if(!el)return;el.style.backgroundImage=`url(${E.grainURL})`;const f=Math.floor(T*24);el.style.backgroundPosition=`${(f*73)%192}px ${(f*131)%192}px`;};
E.fit=(el,maxW,base)=>{if(!el)return;el.style.fontSize=base+'px';const w=el.scrollWidth;if(w>maxW)el.style.fontSize=(base*maxW/w).toFixed(2)+'px';};
E.CHEV='<svg width="14" height="14" viewBox="0 0 14 14"><path d="M5 2.5 9.5 7 5 11.5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
/* ---- bind data into the DOM ---- */
E.bind=function(){
  document.querySelectorAll('[data-if]').forEach(el=>{const ok=el.dataset.if.split(' ').every(k=>k[0]==='!'?!E.has[k.slice(1)]:E.has[k]);if(!ok)el.remove();});
  document.querySelectorAll('[data-r]').forEach(el=>{const k=el.dataset.r;if(k==='qplay'){el.innerHTML='<span class="qx"></span>';return;}if(E.VAL[k]!=null)el.textContent=E.VAL[k];});
  document.querySelectorAll('[data-dots]').forEach(el=>{const t=el.firstElementChild;if(!t)return;const n=Math.min(E.streak,+el.dataset.dots||7);el.innerHTML='';for(let i=0;i<n;i++)el.appendChild(t.cloneNode(true));});
  document.querySelectorAll('img[data-logo]').forEach(im=>im.src=R.logo_url||E.SHARED+'logo.png');
  document.querySelectorAll('.chev').forEach(el=>el.innerHTML=E.CHEV);
  if(!F){document.querySelectorAll('img.vid,img.vth').forEach(im=>{const vd=document.createElement('video');vd.muted=true;vd.playsInline=true;vd.preload='auto';vd.src=R.video_url;vd.className=im.className;vd.setAttribute('style',im.getAttribute('style')||'');if(im.id)vd.id=im.id;if(im.dataset.v)vd.dataset.v=im.dataset.v;im.replaceWith(vd);});}
};
window.renderAt=async function(T){
  const v=E.clamp(T-E.V0,0,E.VDUR-0.001); const ps=[];
  if(F){document.querySelectorAll('img.vid').forEach(im=>E.setImg(im,E.src(v),ps));document.querySelectorAll('img.vth').forEach(im=>E.setImg(im,E.src(E.clamp(+im.dataset.v,0,E.VDUR-.01)),ps));}
  else{document.querySelectorAll('video.vid').forEach(vd=>E.seekVid(vd,v,ps));document.querySelectorAll('video.vth').forEach(vd=>E.seekVid(vd,+vd.dataset.v,ps));}
  if(window.STYLE.pre) window.STYLE.pre(T,v,ps);
  await Promise.all(ps);
  const q=E.qAt(T);document.querySelectorAll('[data-r=qplay] .qx').forEach(s=>{if(s.textContent!==q.t)s.textContent=q.t;s.style.opacity=q.k.toFixed(3);});
  window.STYLE.render(T,v);
  const ik=E.introK(T), sc=document.getElementById('scene');
  const vl=document.getElementById('veil');if(vl)vl.style.opacity=ik.toFixed(3);
  const fo=E.seg(T,E.VDUR-.5,E.VDUR);document.getElementById('stage').style.opacity=(1-E.sine(fo)).toFixed(3);
  if(sc){sc.style.filter=ik>0.001?`blur(${(34*ik).toFixed(2)}px) brightness(${(1-(E.L?0.04:0.16)*ik).toFixed(3)})`:'none';sc.style.transform=ik>0.001?`scale(${(1+.06*ik).toFixed(4)})`:'none';}
};
window.__seek=t=>window.renderAt(t);
window.__duration=E.TOTAL;
window.addEventListener('load',async()=>{
  if(E.L)document.body.classList.add('light'); document.body.classList.add('show'+(E.SHOW>1?2:1));
  E.bind();
  const stg=document.getElementById('stage'),sc=document.createElement('div');sc.id='scene';sc.style.cssText='position:absolute;inset:0;transform-origin:50% 45%';
  [...stg.children].filter(c=>!c.classList.contains('ov')).forEach(c=>sc.appendChild(c));stg.insertBefore(sc,stg.firstChild);
  const vl=document.createElement('div');vl.id='veil';vl.style.cssText='position:absolute;inset:0;z-index:6;overflow:hidden;pointer-events:none;background:'+(E.L?'#efe9e4':'#0b0a0d');
  vl.innerHTML='<img class="vid" style="position:absolute;left:-90px;top:-90px;width:555px;height:992px;object-fit:cover;filter:blur(42px) saturate(1.25) brightness('+(E.L?1.02:.62)+')">';sc.after(vl);
  if(!F){const im=vl.querySelector('img');const vd=document.createElement('video');vd.muted=true;vd.playsInline=true;vd.src=R.video_url;vd.className='vid';vd.setAttribute('style',im.getAttribute('style'));im.replaceWith(vd);}
  await document.fonts.ready; window.STYLE.init(); await document.fonts.ready;
  const t=Q.get('t'); await window.renderAt(t!=null?+t:5); document.body.dataset.ready='1';
});
})();
