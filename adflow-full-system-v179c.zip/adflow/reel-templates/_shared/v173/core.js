/* AdsBhai admin status formats S21-S30 (v173) - shared runtime.
   Page: 1080x1920 CSS px (deviceScaleFactor 1). Input: window.__REEL (same object the v168 renderer builds).
   Output: window.__seek(t) draws frame t (seconds). Ready: body[data-ready="1"]. Length: window.TIMES.TOTAL (= video_duration).
   A template defines window.FMT = { build(H), frame(T, S, H) } and the elements #base, #intro, #outro, img.vid. */
(function () {
  const DEF = {
    name: 'AdsBhai Admin', greeting: 'Good morning',
    dates: { today: 'Fri 27 Nov', today_short: '27 Nov', yesterday: 'Thu 26 Nov', yesterday_long: 'Thursday, 26 November', weekday_y: 'Thursday', weekday_t: 'Friday', day_y: '26', day_t: '27', month: 'November', year: '2026' },
    date: { weekday: 'Thursday', day: '26', month: 'November', year: '2026', short: 'Thu 26 Nov', long: 'Thursday, 26 November 2026', numeric: '26.11.2026', num: '26.11' },
    quotes: ['Small steps every day build big results.', 'Your next sale is one conversation away.', 'Consistency beats talent when talent rests.', 'Win the morning, win the day.'],
    yesterday: { earned: 150.18, sales: 5, revenue: 140, tg: { sales: 4, amount: 130 }, wa: { sales: 1, amount: 10 }, fees: 12.4, fees_on: 310 },
    video_url: '', video_duration: 16, theme: 'dark', logo_url: '../_shared/v173/logo.png'
  };
  const I = window.__REEL || {};
  const qs = new URLSearchParams(location.search);
  const R = Object.assign({}, DEF, I);
  R.dates = Object.assign({}, DEF.dates, I.dates || {});
  R.date = Object.assign({}, DEF.date, I.date || {});
  R.yesterday = Object.assign({}, I.yesterday || DEF.yesterday);
  R.yesterday.tg = Object.assign({}, R.yesterday.tg || {});
  R.yesterday.wa = Object.assign({}, R.yesterday.wa || {});
  R.quotes = (Array.isArray(I.quotes) ? I.quotes : DEF.quotes).map(q => String(q || '').trim()).filter(Boolean);
  if (!R.quotes.length) R.quotes = [String(I.line_of_day || '').trim() || DEF.quotes[0]];
  if (qs.get('theme')) R.theme = qs.get('theme');
  if (qs.get('dur')) R.video_duration = +qs.get('dur');
  R.theme = R.theme === 'light' ? 'light' : 'dark';
  R.name = String(R.name || '').trim() || DEF.name;
  R.greeting = String(R.greeting || '').trim() || DEF.greeting;
  const fr = R.frames;
  R.vdur = Math.max(3, Math.min(45, (fr && fr.count && fr.fps) ? fr.count / fr.fps : (+R.video_duration || DEF.video_duration)));
  window.R = R; window.Y = R.yesterday; window.LIGHT = R.theme === 'light';
  if (window.LIGHT) document.documentElement.classList.add('light');
})();

/* ---------- maths ---------- */
const cl = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x)), lerp = (a, b, t) => a + (b - a) * t, seg = (T, a, b) => cl((T - a) / (b - a));
const eo = t => 1 - Math.pow(1 - t, 3), eio = t => t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2, expo = t => t >= 1 ? 1 : 1 - Math.pow(2, -10 * t), sine = t => -(Math.cos(Math.PI * t) - 1) / 2;
const back = t => { const c = 1.4; return 1 + (c + 1) * Math.pow(t - 1, 3) + c * Math.pow(t - 1, 2); };
const $ = id => document.getElementById(id);

/* ---------- timeline (scales to any video length) ---------- */
const VDUR = R.vdur, TOTAL = VDUR;
const T_FADE = 3.0, FADE_D = 1.15;          // intro text + blur clear together over 1.15 s
const T_END = Math.max(T_FADE + FADE_D + .5, VDUR - 2.05), END_D = .7; // end card overlaps the last ~2 s
const Q_EVERY = 9, Q_FADE = .7;
window.TIMES = { TOTAL, T_FADE, FADE_D, T_END };
window.__duration = TOTAL;

/* ---------- data helpers (positive only) ---------- */
const pos = v => typeof v === 'number' && isFinite(v) && v > 0;
const money = (v, dp) => { if (!pos(v)) return ''; const r = Math.round(v * 100) / 100; const two = dp === 2 || (dp !== 0 && !Number.isInteger(r)); return '$' + r.toLocaleString('en-US', { minimumFractionDigits: two ? 2 : 0, maximumFractionDigits: two ? 2 : 0 }); };
const M = v => money(v), M2 = v => money(v, 2);
const pl = (n, w) => n + ' ' + w + (n === 1 ? '' : 's');
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const H = {
  R, Y, pos, M, M2, pl, esc,
  hero() { return pos(Y.earned) ? { k: 'earned', label: 'Earned', v: Y.earned, s: M(Y.earned) } : pos(Y.revenue) ? { k: 'revenue', label: 'Revenue', v: Y.revenue, s: M(Y.revenue) } : pos(Y.sales) ? { k: 'sales', label: 'Sales', v: Y.sales, s: String(Y.sales) } : null; },
  chans() { return [['tg', 'Telegram', Y.tg], ['wa', 'WhatsApp', Y.wa]].filter(c => c[2] && (pos(c[2].amount) || pos(c[2].sales))).map(([k, n, c]) => ({ k, name: n, sales: pos(c.sales) ? c.sales : 0, amount: pos(c.amount) ? c.amount : 0 })); },
  /** the stat list a format can lay out: only positive values */
  stats(opts = {}) {
    const o = [];
    if (pos(Y.earned) && !opts.noEarned) o.push({ k: 'earned', label: 'Earned', v: M(Y.earned) });
    if (pos(Y.revenue)) o.push({ k: 'revenue', label: 'Revenue', v: M(Y.revenue) });
    if (pos(Y.sales)) o.push({ k: 'sales', label: Y.sales === 1 ? 'Sale' : 'Sales', v: String(Y.sales) });
    if (pos(Y.fees)) o.push({ k: 'fees', label: 'Top-up fees', short: 'Fees', v: M(Y.fees), sub: pos(Y.fees_on) ? 'on ' + M(Y.fees_on) : '' });
    return o;
  },
  greet() { return R.greeting + ', ' + R.name; },
  dayLong() { return R.dates.yesterday_long || R.date.long || ''; },
  /** fit an element's font-size so it is at most maxW wide (and optional maxH) */
  fit(el, maxW, maxH) { if (!el) return; const cw = () => { const r = document.createRange(); r.selectNodeContents(el); return r.getBoundingClientRect().width; }; let fs = parseFloat(getComputedStyle(el).fontSize); let n = 0; while (n++ < 60 && (cw() > maxW + .5 || (maxH && el.scrollHeight > maxH + .5)) && fs > 8) { fs *= .96; el.style.fontSize = fs + 'px'; } },
  /** a counter that never shows 0: starts at 45 % of the target */
  count(v, p, dp) { const x = v * lerp(.45, 1, eo(cl(p))); return money(p >= 1 ? v : x, dp === undefined ? (Number.isInteger(Math.round(v * 100) / 100) ? 0 : 2) : dp); },
  countInt(v, p) { return String(Math.max(1, Math.round(v * lerp(.4, 1, eo(cl(p)))))); },
  quote(T) { const n = R.quotes.length; const t = Math.max(0, T - T_FADE - FADE_D); const i = Math.floor(t / Q_EVERY) % n; const ph = t % Q_EVERY; const o = n < 2 ? 1 : Math.min(1, (ph + (t < Q_EVERY ? Q_FADE : 0)) / Q_FADE, (Q_EVERY - ph) / Q_FADE); return { text: R.quotes[i], i, o: cl(o) }; },
  /** set the cycling quote on every .qcycle element (+ data-fit width) */
  quotes(T) { const q = H.quote(T); document.querySelectorAll('.qcycle').forEach(el => { if (el._q !== q.text) { el.textContent = q.text; el._q = q.text; el.style.fontSize = ''; if (el.dataset.fit) H.fit(el, +el.dataset.fit, +el.dataset.fith || 0); } el.style.opacity = q.o.toFixed(3); }); return q; },
  show(el, o, tr) { if (!el) return; el.style.opacity = o.toFixed ? o.toFixed(3) : o; el.style.visibility = o <= .001 ? 'hidden' : 'visible'; if (tr !== undefined) el.style.transform = tr; },
  rise(el, T, a, d = .8, y = 30) { if (!el) return; const k = expo(seg(T, a, a + d)); el.style.opacity = seg(T, a, a + d * .5).toFixed(3); el.style.transform = `translateY(${((1 - k) * y).toFixed(2)}px)`; },
  hash(a, b = 0) { let h = (a * 374761393 + b * 668265263) ^ 0x5bd1e995; h = (h ^ (h >>> 13)) * 1274126177; return ((h ^ (h >>> 16)) >>> 0) / 4294967295; },
  T_FADE, FADE_D, T_END, END_D, VDUR, TOTAL, Q_EVERY
};
window.H = H;

/* ---------- video layer: extracted frames (R.frames: {sharp, blur, fps, count}, '{n}' = 0001..) or a <video> seeked ---------- */
let VSRC = null; // the element the veil reads (small blurred frame, or the <video>)
function fsrc(pat, n) { const F = R.frames; if (!pat) return ''; if (pat.includes('{n}')) return pat.replace('{n}', n); return pat + n + (F.ext || '.jpg'); }
function prepVideo() {
  const vb = document.createElement('img'); vb.className = 'vblur'; document.body.appendChild(vb);
  if (R.frames) { VSRC = vb; return; }
  if (!R.video_url) { VSRC = null; return; }
  const v = document.createElement('video'); v.muted = true; v.playsInline = true; v.preload = 'auto'; v.crossOrigin = 'anonymous'; v.src = R.video_url;
  v.style.cssText = 'position:absolute;width:2px;height:2px;opacity:0;left:-9px;top:-9px'; document.body.appendChild(v); VSRC = v;
  document.querySelectorAll('img.vid').forEach(im => { const c = document.createElement('canvas'); c.width = 1920; c.height = 1080; c.className = im.className; c.style.cssText = im.style.cssText; c.style.width = '100%'; c.style.height = '100%'; c.style.display = 'block'; c.id = im.id; im.replaceWith(c); });
}
async function setVid(t) {
  t = Math.min(Math.max(0, t), VDUR - .02);
  if (R.frames) {
    const F = R.frames; const n = String(cl(Math.floor(t * F.fps + 1e-6) + 1, 1, F.count)).padStart(4, '0');
    const ps = [];
    const put = (im, src) => { if (im.getAttribute('src') !== src) { im.setAttribute('src', src); ps.push(im.decode().catch(() => {})); } };
    document.querySelectorAll('img.vid').forEach(im => put(im, fsrc(F.sharp || F.base, n)));
    const vb = document.querySelector('img.vblur'); if (vb) put(vb, fsrc(F.blur || F.sharp || F.base, n));
    await Promise.all(ps); return;
  }
  if (!VSRC) return;
  const v = VSRC;
  await new Promise(res => { if (Math.abs(v.currentTime - t) < .001 && v.readyState >= 2) return res(); const f = () => { v.removeEventListener('seeked', f); res(); }; v.addEventListener('seeked', f); v.currentTime = t; setTimeout(res, 3000); });
  document.querySelectorAll('canvas.vid').forEach(c => { try { c.getContext('2d').drawImage(v, 0, 0, 1920, 1080); } catch (e) { } });
}

/* ---------- intro veil: the whole screen, uniformly blurred (cover), no card edges ---------- */
let VC = null, VX = null;
function mkVeil() {
  const st = $('stage'); const v = document.createElement('div'); v.id = 'veil';
  v.innerHTML = '<canvas width="80" height="136"></canvas><div class="tint"></div>';
  st.appendChild(v); VC = v.querySelector('canvas'); VX = VC.getContext('2d');
}
function drawVeil() {
  if (!VSRC || !VX) return;
  const sw0 = VSRC.naturalWidth || VSRC.videoWidth || 256, sh0 = VSRC.naturalHeight || VSRC.videoHeight || 144;
  if (!sw0 || !sh0) return;
  const ar = VC.width / VC.height; const sw = sh0 * ar, sx = (sw0 - sw) / 2;
  try { VX.filter = 'blur(2.2px) saturate(1.15)'; VX.drawImage(VSRC, sx, 0, sw, sh0, -6, -6, VC.width + 12, VC.height + 12); VX.filter = 'none'; } catch (e) { }
}

/* ---------- render ---------- */
let built = false;
window.renderAt = async function (T) {
  await setVid(T);
  const kIn = 1 - sine(seg(T, T_FADE, T_FADE + FADE_D)); // 1 = intro, 0 = playback
  const e = sine(seg(T, T_END, T_END + END_D));          // end card
  const veil = $('veil');
  if (kIn > .001) drawVeil();
  H.show(veil, kIn);
  const intro = $('intro');
  // the sharp video stays blurred while any intro text is on screen, so text is never over a sharp picture
  document.querySelectorAll('.vid').forEach(v => { v.style.filter = kIn > .002 && kIn < .999 ? `blur(${(kIn * 34).toFixed(2)}px)` : ''; });
  if (intro) { H.show(intro, Math.pow(kIn, 1.8)); intro.style.transform = `scale(${(1 + .035 * (1 - kIn)).toFixed(4)})`; }
  H.show($('outro'), e);
  const S = { k: kIn, p: 1 - kIn, e, T_END, T_FADE, FADE_D, play: T - (T_FADE + FADE_D) };
  if (window.FMT && FMT.frame) FMT.frame(T, S, H);
};
window.__seek = async t => { await window.renderAt(t); };
window.addEventListener('load', async () => {
  if (window.LIGHT) document.body.classList.add('light');
  prepVideo(); mkVeil();
  document.querySelectorAll('img[data-logo]').forEach(im => { im.src = R.logo_url; });
  await document.fonts.ready;
  if (window.FMT && FMT.build) await FMT.build(H);
  await Promise.all([...document.querySelectorAll('img[data-logo]')].map(im => im.decode().catch(() => { })));
  await window.renderAt(+(new URLSearchParams(location.search).get('t') || 0));
  document.body.dataset.ready = '1';
});
