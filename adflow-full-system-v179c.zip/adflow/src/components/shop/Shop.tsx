'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import QRCode from 'qrcode';
import clsx from 'clsx';
import { ArrowLeft, Check, Copy, Loader2, LogOut, Minus, Plus, ShieldCheck, Wallet, IndianRupee, Bitcoin, Send, RefreshCw, X, Clock, Gift, Repeat } from 'lucide-react';

/* ---------------- types & api ---------------- */
type Config = {
  tgp?: boolean; tier?: string; premium_title?: string; offer?: { text: string } | null;
  on: boolean; brand: string; delivery: string; prices: { account: number; full: number; funnel: number; telegram: number; topupMin: number; topupPct: number };
  coins: { id: string; name: string }[]; crypto: boolean; inr: boolean; inr_rate: number; upi: boolean; manager: string;
  customer: { email: string; name: string | null; phone: string | null } | null;
};
type Order = { id: number; code: string; kind: 'account' | 'funnel'; full?: number; qty: number; bm_id: string | null; amount: number; status: string; pay_method: string | null; inr_amount: number | null; utr: string | null; accounts: string[]; created_at: number };
type Topup = { id: number; code: string; act_id: string; amount: number; fee: number; total: number; status: string; pay_method: string | null; inr_amount: number | null; utr: string | null; created_at: number };
type Acct = { id: number; act_id: string; created_at: number };
type Me = { customer: { email: string; name: string | null; phone: string | null }; orders: Order[]; topups: Topup[]; accounts: Acct[] };

async function api<T = any>(path: string, body?: unknown): Promise<T> {
  const r = await fetch('/api/shop/' + path, { method: body ? 'POST' : 'GET', headers: body ? { 'content-type': 'application/json' } : undefined, body: body ? JSON.stringify(body) : undefined, cache: 'no-store', credentials: 'same-origin' });
  const j = await r.json().catch(() => ({}));
  if (!r.ok || j.error) { const e = new Error(j.error || 'Something went wrong. Please try again.') as Error & { status?: number }; e.status = r.status; throw e; }
  return j as T;
}
const usd = (n: number) => '$' + (Math.round(n * 100) / 100).toLocaleString('en-US', { maximumFractionDigits: 2 });
const inr = (n: number) => '₹' + Math.round(n).toLocaleString('en-IN');
const STATUS: Record<string, [string, string]> = {
  new: ['Not paid', 'bg-ov/10 text-fg-2'], pending_payment: ['Waiting for payment', 'bg-[#f59e0b]/15 text-[#f59e0b]'], awaiting_inr: ['Waiting for INR payment', 'bg-[#f59e0b]/15 text-[#f59e0b]'],
  inr_review: ['Checking your payment', 'bg-[#229ED9]/15 text-[#229ED9]'], paid: ['Paid · in progress', 'bg-[#229ED9]/15 text-[#229ED9]'],
  delivered: ['Delivered', 'bg-[#22c55e]/15 text-[#22c55e]'], done: ['Done', 'bg-[#22c55e]/15 text-[#22c55e]'], cancelled: ['Cancelled', 'bg-ov/10 text-fg-3'],
};
const Chip = ({ s }: { s: string }) => { const [t, c] = STATUS[s] || [s, 'bg-ov/10 text-fg-2']; return <span className={clsx('rounded-full px-2.5 py-1 text-[12px] font-semibold', c)}>{t}</span>; };
const input = 'w-full rounded-xl border border-edge bg-ov/[0.04] px-4 py-3.5 text-[16px] text-fg outline-none transition-colors placeholder:text-fg-3/70 focus:border-violet focus:bg-ov/[0.06]';
const card = 'rounded-[22px] border border-edge bg-plum/80 p-5 shadow-[0_20px_60px_-30px_rgba(0,0,0,.6)] backdrop-blur sm:p-7';

function Field({ label, hint, children }: { label: string; hint?: React.ReactNode; children: React.ReactNode }) {
  return <label className="mb-4 block"><span className="mb-1.5 block text-[13.5px] font-medium text-fg-2">{label}</span>{children}{hint && <span className="mt-1.5 block text-[12.5px] leading-snug text-fg-3">{hint}</span>}</label>;
}
function Err({ e }: { e: string }) { return e ? <p role="alert" className="mb-3 rounded-xl bg-[#ef4444]/12 px-4 py-3 text-[14px] text-[#f87171]">{e}</p> : null; }

/* ---------------- shell ---------------- */
function Shell({ brand, logo, right, children }: { brand: string; logo: string; right?: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="relative min-h-[100dvh] bg-void text-fg">
      {/* the landing page's hero colours at the top, fading into the page */}
      <div className="pointer-events-none absolute inset-x-0 top-0 -z-0 h-[340px] bg-[image:var(--m-hero)] opacity-90 [mask-image:linear-gradient(180deg,#000_35%,transparent)] sm:h-[400px]" />
      <header className="relative z-10 mx-auto flex max-w-[980px] items-center gap-3 px-4 py-4 sm:px-6">
        <a href="/" className="flex items-center gap-2.5 font-display text-[18px] font-semibold tracking-tight">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          {logo ? <img src={logo} alt="" className="h-8 w-8 rounded-[9px] object-contain" /> : <span className="grid h-8 w-8 place-items-center rounded-[9px] bg-violet font-bold text-onp">{brand.charAt(0)}</span>}
          {brand}
        </a>
        <div className="ml-auto flex items-center gap-2">{right}</div>
      </header>
      <main className="relative z-10 mx-auto max-w-[980px] px-4 pb-8 sm:px-6">{children}</main>
      {/* v125: payments are final — replacement, no refunds */}
      <footer className="relative z-10 mx-auto max-w-[980px] px-4 pb-10 text-center text-[12.5px] text-fg-3 sm:px-6" data-legal>
        By paying you agree to our <a href="/terms" className="underline hover:text-fg">Terms</a> and <a href="/refund-policy" className="underline hover:text-fg">Refund &amp; Replacement Policy</a> (no refunds, free replacement). <a href="/privacy" className="underline hover:text-fg">Privacy</a>
      </footer>
    </div>
  );
}

/* ---------------- email login ---------------- */
function Login({ onDone, title, sub }: { onDone: () => void; title: string; sub: string }) {
  const [email, setEmail] = useState(''); const [code, setCode] = useState('');
  const [sent, setSent] = useState(false); const [busy, setBusy] = useState(false); const [err, setErr] = useState(''); const [wait, setWait] = useState(0);
  useEffect(() => { if (wait <= 0) return; const t = setTimeout(() => setWait(w => w - 1), 1000); return () => clearTimeout(t); }, [wait]);
  async function send() {
    setErr(''); setBusy(true);
    try { await api('otp_send', { email }); setSent(true); setWait(45); } catch (e) { setErr((e as Error).message); } finally { setBusy(false); }
  }
  async function verify() {
    setErr(''); setBusy(true);
    try { await api('otp_verify', { email, code }); onDone(); } catch (e) { setErr((e as Error).message); } finally { setBusy(false); }
  }
  return (
    <div className={card}>
      <h2 className="font-display text-[22px] font-semibold tracking-tight">{title}</h2>
      <p className="mb-5 mt-1.5 text-[14.5px] text-fg-3">{sub}</p>
      <Err e={err} />
      {!sent ? (
        <form onSubmit={e => { e.preventDefault(); void send(); }}>
          <Field label="Email"><input className={input} type="email" autoComplete="email" inputMode="email" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} /></Field>
          <button disabled={busy || !email} className="btn-primary w-full">{busy ? <Loader2 size={17} className="animate-spin" /> : 'Send login code'}</button>
        </form>
      ) : (
        <form onSubmit={e => { e.preventDefault(); void verify(); }}>
          <p className="mb-4 rounded-xl bg-ov/[0.05] px-4 py-3 text-[14px] text-fg-2">We sent a 6-digit code to <b className="text-fg">{email}</b>. Check spam if you don’t see it.</p>
          <Field label="Code"><input className={clsx(input, 'text-center text-[24px] tracking-[0.4em]')} inputMode="numeric" autoComplete="one-time-code" maxLength={6} placeholder="••••••" value={code} onChange={e => setCode(e.target.value.replace(/\D/g, ''))} /></Field>
          <button disabled={busy || code.length !== 6} className="btn-primary w-full">{busy ? <Loader2 size={17} className="animate-spin" /> : 'Continue'}</button>
          <div className="mt-4 flex justify-between text-[13.5px]">
            <button type="button" onClick={() => { setSent(false); setCode(''); }} className="text-fg-3 hover:text-fg">Change email</button>
            <button type="button" disabled={wait > 0 || busy} onClick={() => void send()} className="font-medium text-lilac disabled:text-fg-3">{wait > 0 ? `Resend in ${wait}s` : 'Resend code'}</button>
          </div>
        </form>
      )}
    </div>
  );
}

/* ---------------- payment ---------------- */
function Qr({ text }: { text: string }) {
  const [src, setSrc] = useState('');
  useEffect(() => { QRCode.toDataURL(text, { margin: 1, width: 360, errorCorrectionLevel: 'M' }).then(setSrc).catch(() => setSrc('')); }, [text]);
  // eslint-disable-next-line @next/next/no-img-element
  return src ? <img src={src} alt="UPI QR code" className="mx-auto h-[200px] w-[200px] rounded-xl bg-white p-2" /> : <div className="mx-auto h-[200px] w-[200px] rounded-xl bg-white/80" />;
}

type Crypto = { currency: string; coin: string; ticker: string; network: string; address: string; amount: number | null; extra: string | null; expires: number; np_status: string };
function useCountdown(to: number) {
  const [n, setN] = useState(Date.now());
  useEffect(() => { const t = setInterval(() => setN(Date.now()), 1000); return () => clearInterval(t); }, []);
  const left = Math.max(0, to - n);
  const m = Math.floor(left / 60000), sec = Math.floor((left % 60000) / 1000);
  return { left, text: `${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}` };
}
function CopyRow({ label, value, big }: { label: string; value: string; big?: boolean }) {
  const [ok, setOk] = useState(false);
  return (
    <button type="button" onClick={() => { void navigator.clipboard?.writeText(value); setOk(true); setTimeout(() => setOk(false), 1500); }}
      className="flex w-full items-center gap-3 rounded-xl border border-edge bg-ov/[0.04] px-4 py-3 text-left hover:border-violet/50">
      <span className="min-w-0 flex-1"><span className="block text-[12px] text-fg-3">{label}</span>
        <span className={clsx('block break-all font-semibold', big ? 'font-display text-[22px] tracking-tight' : 'font-mono text-[13.5px] leading-snug')}>{value}</span></span>
      <span className={clsx('flex shrink-0 items-center gap-1 rounded-full px-2.5 py-1 text-[12px] font-semibold', ok ? 'bg-[#22c55e]/15 text-[#22c55e]' : 'bg-violet/15 text-lilac')}>{ok ? <><Check size={13} /> Copied</> : <><Copy size={13} /> Copy</>}</span>
    </button>
  );
}
function CryptoBox({ c, onRenew, onCheck, busy, onChange }: { c: Crypto; onRenew: () => void; onCheck: () => void; busy: boolean; onChange?: () => void }) {
  const { left, text } = useCountdown(c.expires);
  const amt = c.amount != null ? String(c.amount) : '';
  const seen = ['confirming', 'confirmed', 'sending', 'partially_paid'].includes(c.np_status);
  return (
    <div>
      {seen ? (
        <div className="mb-4 flex items-center gap-3 rounded-2xl bg-[#229ED9]/10 px-4 py-3.5">
          <Loader2 size={20} className="shrink-0 animate-spin text-[#229ED9]" />
          <span className="text-[14px]"><b className="block">{c.np_status === 'partially_paid' ? 'Part of the payment received' : 'Payment received — confirming on the network'}</b><span className="text-fg-3">{c.np_status === 'partially_paid' ? 'Your account manager will check it. Message them if you sent less by mistake.' : 'This takes a few minutes. You can keep this page open.'}</span></span>
        </div>
      ) : left > 0 ? (
        <div className="mb-4 flex items-center justify-between rounded-2xl bg-ov/[0.05] px-4 py-3">
          <span className="text-[13.5px] text-fg-2">Send the payment within</span>
          <span className="font-display text-[22px] font-semibold tabular-nums tracking-tight">{text}</span>
        </div>
      ) : (
        <div className="mb-4 rounded-2xl border border-[#f59e0b]/30 bg-[#f59e0b]/10 p-4 text-[14px]">
          <b className="block text-[#f59e0b]">Time is up for this address</b>
          <span className="text-fg-2">Already sent? It will still be detected — tap Check status. Not paid yet? Get a fresh address.</span>
          <button disabled={busy} onClick={onRenew} className="btn-primary mt-3 w-full">{busy ? <Loader2 size={17} className="animate-spin" /> : 'Get a new address'}</button>
        </div>
      )}
      <div className="rounded-2xl border border-edge p-4">
        <div className="mb-3 flex flex-wrap items-center justify-center gap-2 text-center">
          <span className="rounded-full bg-violet/15 px-3 py-1 text-[13px] font-semibold text-lilac">{c.coin}</span>
          {c.network && <span className="rounded-full bg-[#f59e0b]/12 px-3 py-1 text-[12.5px] font-semibold text-[#f59e0b]">Network: {c.network}</span>}
        </div>
        {onChange && !seen && (
          <button type="button" data-change-coin onClick={onChange} className="mb-4 flex w-full items-center justify-center gap-2 rounded-xl border border-edge bg-ov/[0.04] px-4 py-2.5 text-[14px] font-medium text-fg-2 hover:border-violet/50 hover:text-fg">
            <Repeat size={15} /> Wrong network? Change coin or network
          </button>
        )}
        <div className="mb-4"><Qr text={c.address} /></div>
        <div className="grid gap-2.5">
          {amt && <CopyRow label={`Send exactly`} value={`${amt} ${c.ticker}`} big />}
          <CopyRow label={`${c.ticker} address (${c.network || c.coin})`} value={c.address} />
          {c.extra && <CopyRow label="Memo / tag (required)" value={c.extra} />}
        </div>
        <p className="mt-3 text-[12.5px] leading-relaxed text-fg-3">Send only {c.ticker} on {c.network || c.coin}. Sending another coin or network can lose the money. If your exchange takes a fee, add it on top so we receive the full amount.</p>
      </div>
      <button onClick={onCheck} className="btn-ghost mt-3 w-full py-3 text-[14px]"><RefreshCw size={15} /> Check status</button>
      <p className="mt-2 text-center text-[12.5px] text-fg-3">This page updates by itself when the payment arrives.</p>
    </div>
  );
}

type Payable = { type: 'order' | 'topup'; id: number; code: string; total: number; status: string; pay_method: string | null; inr_amount: number | null; utr: string | null; label: string };

function Payment({ cfg, item, onPaid, onBack, okey }: { cfg: Config; item: Payable; onPaid: () => void; onBack?: () => void; okey?: string }) {
  const kq = okey ? { key: okey, code: item.code } : {};
  const [method, setMethod] = useState<'crypto' | 'inr' | null>(item.pay_method === 'inr' && item.status !== 'new' ? 'inr' : null);
  const [coin, setCoin] = useState(cfg.coins[0]?.id || '');
  const [crypto, setCrypto] = useState<Crypto | null>(null);
  const [inrInfo, setInrInfo] = useState<{ inr_amount: number; upi: string | null; upi_id: string | null; manager: string } | null>(null);
  const [utr, setUtr] = useState(item.utr || ''); const [status, setStatus] = useState(item.status);
  const [busy, setBusy] = useState(false); const [err, setErr] = useState(''); const [copied, setCopied] = useState(false);
  const isMobile = typeof navigator !== 'undefined' && /Android|iPhone|iPad/i.test(navigator.userAgent);

  const poll = useCallback(async () => {
    try {
      const r = await api<{ item: { status: string }; inr: any; crypto: Crypto | null }>(`item?type=${item.type}&code=${encodeURIComponent(item.code)}${okey ? '&key=' + encodeURIComponent(okey) : ''}${crypto ? '&check=1' : ''}`);
      setStatus(r.item.status);
      if (r.inr && !inrInfo) setInrInfo(r.inr);
      if (r.crypto) { setCrypto(r.crypto); setMethod('crypto'); }
      if (['paid', 'delivered', 'done'].includes(r.item.status)) onPaid();
    } catch { /* ignore */ }
  }, [item.type, item.code, onPaid, inrInfo, okey, crypto]);
  useEffect(() => { if (item.pay_method && item.status !== 'new') void poll(); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (!crypto && status !== 'inr_review') return; const t = setInterval(() => void poll(), 8000); return () => clearInterval(t); }, [crypto, status, poll]);

  async function start(m: 'crypto' | 'inr', renew = false) {
    setErr(''); setBusy(true);
    try {
      const r = await api('pay', { ...kq, type: item.type, id: item.id, method: m, currency: m === 'crypto' ? (renew && crypto ? crypto.currency : coin) : undefined, renew });
      if (m === 'crypto') { setCrypto(r.crypto); setStatus('pending_payment'); } else { setInrInfo(r); setStatus('awaiting_inr'); }
      setMethod(m);
    } catch (e) { setErr((e as Error).message); } finally { setBusy(false); }
  }
  async function sendUtr() {
    setErr(''); setBusy(true);
    try { await api('utr', { ...kq, type: item.type, id: item.id, utr }); setStatus('inr_review'); } catch (e) { setErr((e as Error).message); } finally { setBusy(false); }
  }
  const copy = (t: string) => { void navigator.clipboard?.writeText(t); setCopied(true); setTimeout(() => setCopied(false), 1500); };

  return (
    <div className={card}>
      <div className="mb-5 flex items-start gap-3">
        {onBack && <button onClick={onBack} className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-ov/[0.06] text-fg-2 hover:text-fg" aria-label="Back"><ArrowLeft size={18} /></button>}
        <div className="min-w-0 flex-1">
          <p className="text-[13px] text-fg-3">{item.label} · {item.code}</p>
          <p className="font-display text-[30px] font-semibold leading-tight tracking-tight">{usd(item.total)}</p>
        </div>
      </div>
      <Err e={err} />

      {status === 'inr_review' ? (
        <div className="rounded-2xl bg-[#229ED9]/10 p-5 text-center">
          <Clock className="mx-auto mb-2 text-[#229ED9]" />
          <p className="text-[17px] font-semibold">We’re checking your payment</p>
          <p className="mt-1.5 text-[14px] text-fg-2">Your account manager confirms INR payments by hand, usually within minutes. This page updates by itself.</p>
          {(inrInfo?.manager || cfg.manager) && <a href={inrInfo?.manager || cfg.manager} target="_blank" rel="noopener" className="btn-ghost mt-4 w-full"><Send size={16} /> Message account manager</a>}
        </div>
      ) : !method ? (
        <>
          <p className="mb-3 text-[14px] font-medium text-fg-2">How do you want to pay?</p>
          {cfg.crypto && (
            <div className="mb-3 rounded-2xl border border-edge p-4">
              <p className="mb-3 flex items-center gap-2 font-semibold"><Bitcoin size={18} className="text-[#f7931a]" /> Crypto</p>
              <div className="mb-3 flex flex-wrap gap-2">
                {cfg.coins.map(c => (
                  <button key={c.id} type="button" onClick={() => setCoin(c.id)} className={clsx('rounded-full border px-3.5 py-2 text-[13.5px] font-medium', coin === c.id ? 'border-violet bg-violet/15 text-fg' : 'border-edge text-fg-2 hover:border-violet/40')}>{c.name}</button>
                ))}
              </div>
              <button disabled={busy} onClick={() => void start('crypto')} className="btn-primary w-full">{busy ? <Loader2 size={17} className="animate-spin" /> : `Pay ${usd(item.total)} with crypto`}</button>
            </div>
          )}
          {cfg.inr && (
            <div className="rounded-2xl border border-edge p-4">
              <p className="mb-1 flex items-center gap-2 font-semibold"><IndianRupee size={18} className="text-[#22c55e]" /> Pay in INR {cfg.upi ? '(UPI)' : ''}</p>
              <p className="mb-3 text-[13.5px] text-fg-3">{inr(Math.ceil(item.total * cfg.inr_rate))} at ₹{cfg.inr_rate}/$. {cfg.upi ? 'Pay by any UPI app. We confirm and then deliver.' : 'Your account manager will share payment details on Telegram.'}</p>
              <button disabled={busy} onClick={() => void start('inr')} className="btn-ghost w-full">{busy ? <Loader2 size={17} className="animate-spin" /> : 'Pay in INR'}</button>
            </div>
          )}
          {!cfg.crypto && !cfg.inr && <p className="rounded-xl bg-ov/[0.05] p-4 text-[14px] text-fg-2">Online payment isn’t available right now. Please contact your account manager.</p>}
        </>
      ) : method === 'crypto' && crypto ? (
        <>
          <CryptoBox c={crypto} busy={busy} onRenew={() => void start('crypto', true)} onCheck={() => void poll()} onChange={() => { setCoin(crypto.currency); setMethod(null); setCrypto(null); }} />
        </>
      ) : method === 'inr' && inrInfo ? (
        <>
          <div className="rounded-2xl border border-edge p-4 text-center">
            <p className="text-[13px] text-fg-3">Amount to pay</p>
            <p className="font-display text-[34px] font-semibold tracking-tight">{inr(inrInfo.inr_amount)}</p>
            {inrInfo.upi ? (
              <>
                <div className="my-3"><Qr text={inrInfo.upi} /></div>
                <p className="text-[13px] text-fg-3">Scan with any UPI app, or</p>
                {isMobile && <a href={inrInfo.upi} className="btn-primary mt-3 w-full">Pay with UPI app (GPay, PhonePe, Paytm)</a>}
                <button onClick={() => copy(inrInfo.upi_id || '')} className="mt-3 inline-flex items-center gap-2 rounded-full bg-ov/[0.06] px-3.5 py-2 text-[13.5px]">{copied ? <Check size={15} /> : <Copy size={15} />} UPI ID: <b>{inrInfo.upi_id}</b></button>
              </>
            ) : (
              <>
                <p className="mt-2 text-[14px] text-fg-2">Message your account manager on Telegram to get the INR payment details. Your order stays on hold until you pay.</p>
                {inrInfo.manager && <a href={inrInfo.manager} target="_blank" rel="noopener" className="btn-primary mt-4 w-full"><Send size={16} /> Contact account manager</a>}
              </>
            )}
          </div>
          <div className="mt-4">
            <Field label="After paying, enter the UPI reference / UTR number" hint="You can find it in your payment app under the transaction details (usually 12 digits).">
              <input className={input} inputMode="text" placeholder="e.g. 412345678901" value={utr} onChange={e => setUtr(e.target.value)} />
            </Field>
            <button disabled={busy || utr.trim().length < 6} onClick={() => void sendUtr()} className="btn-primary w-full">{busy ? <Loader2 size={17} className="animate-spin" /> : 'I’ve paid'}</button>
            {inrInfo.upi && inrInfo.manager && <a href={inrInfo.manager} target="_blank" rel="noopener" className="mt-3 block text-center text-[13.5px] text-fg-3 hover:text-fg">Problem paying? Message your account manager</a>}
          </div>
        </>
      ) : null}
    </div>
  );
}

/* ---------------- ORDER page ---------------- */
export function OrderPage({ brand, logo }: { brand: string; logo: string }) {
  const [cfg, setCfg] = useState<Config | null>(null);
  const [kind, setKind] = useState<'account' | 'full' | 'funnel'>('account');
  const [qty, setQty] = useState(1); const [bm, setBm] = useState(''); const [name, setName] = useState(''); const [phone, setPhone] = useState(''); const [email, setEmail] = useState('');
  const [step, setStep] = useState<'form' | 'pay' | 'done'>('form');
  const [okey, setOkey] = useState('');
  const [leadTok, setLeadTok] = useState('');
  const [order, setOrder] = useState<Order | null>(null);
  const [busy, setBusy] = useState(false); const [err, setErr] = useState('');
  const load = useCallback(async () => { const sp = typeof location !== 'undefined' ? new URLSearchParams(location.search) : null; const qs = [sp?.get('tier') === 'premium' ? 'tier=premium' : '', sp?.get('tg') === '1' ? 'tg=1' : ''].filter(Boolean).join('&'); const c = await api<Config>('config' + (qs ? '?' + qs : '')); setCfg(c); if (c.customer) { setName(n => n || c.customer!.name || ''); setPhone(p => p || (c.customer!.phone || '').replace(/^\+91/, '')); } return c; }, []);
  useEffect(() => {
    void load();
    const q = new URLSearchParams(location.search);
    if (q.get('kind') === 'funnel') setKind('funnel');
    if (q.get('kind') === 'full' || q.get('full') === '1') setKind('full');
    const lt = q.get('lead');
    if (lt && /^[A-Za-z0-9]{8,40}$/.test(lt)) { // came from the landing form (Telegram didn't open) → fill in what they already typed
      setLeadTok(lt);
      api<{ lead: { name: string; phone: string; kind: 'account' | 'funnel' } | null }>(`prefill?lead=${encodeURIComponent(lt)}`).then(r => {
        if (!r.lead) return;
        setName(n => n || r.lead!.name); setPhone(p => p || r.lead!.phone);
        if (!q.get('kind') && q.get('full') !== '1') setKind(r.lead.kind);
      }).catch(() => { /* old link → empty form */ });
    }
    const code = q.get('o'), k = q.get('k');
    if (code && k) { // back from the payment page, or the link in their browser history
      api<{ item: Order }>(`item?type=order&code=${encodeURIComponent(code)}&key=${encodeURIComponent(k)}`).then(r => {
        setOrder(r.item); setOkey(k);
        setStep(['paid', 'delivered', 'done'].includes(r.item.status) ? 'done' : r.item.status === 'cancelled' ? 'form' : 'pay');
      }).catch(() => { /* old or wrong link → normal form */ });
    }
  }, [load]);
  if (!cfg) return <Shell brand={brand} logo={logo}><div className="grid h-[60vh] place-items-center"><Loader2 className="animate-spin text-fg-3" /></div></Shell>;
  const unit = kind === 'funnel' ? cfg.prices.funnel : kind === 'full' ? cfg.prices.full : cfg.prices.account;
  const total = Math.round(unit * (kind === 'funnel' ? 1 : qty) * 100) / 100;
  const save = Math.max(0, cfg.prices.telegram - cfg.prices.account);

  async function submit() {
    setErr('');
    if (kind !== 'funnel' && !/^\d{8,20}$/.test(bm.replace(/\s/g, ''))) return setErr('Enter your Business Manager ID (numbers only).');
    if (name.trim().length < 2) return setErr('Enter your name.');
    if (phone.replace(/\D/g, '').length < 10) return setErr('Enter your mobile number.');
    if (!cfg!.customer && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim())) return setErr('Enter a valid email address.');
    await createNow();
  }
  async function createNow() {
    setErr(''); setBusy(true);
    try {
      const r = await api<{ order: Order; key: string }>('order_create', { kind: kind === 'full' ? 'account' : kind, full: kind === 'full' ? 1 : 0, tg: cfg!.tgp ? 1 : 0, qty, bm_id: bm, name, phone, email, page_url: location.href, tier: cfg!.tier || '', src: (typeof location !== 'undefined' && new URLSearchParams(location.search).get('src')) || '', cj: (typeof location !== 'undefined' && new URLSearchParams(location.search).get('cj')) || '', ...(leadTok ? { lead_token: leadTok } : {}) });
      setOrder(r.order); setOkey(r.key); setStep('pay');
      try { history.replaceState(null, '', `/order?o=${r.order.code}&k=${r.key}`); } catch { /* ignore */ }
      window.scrollTo(0, 0);
    }
    catch (e) { setErr((e as Error).message); setStep('form'); } finally { setBusy(false); }
  }

  const right = <a href="/account" className="rounded-full border border-edge px-4 py-2 text-[13.5px] font-medium text-fg-2 hover:text-fg">My account</a>;
  return (
    <Shell brand={brand} logo={logo} right={right}>
      <div className="mx-auto max-w-[520px]">
        {step === 'form' && (
          <>
            <h1 className="mb-1 mt-2 font-display text-[28px] font-semibold tracking-tight sm:text-[34px]">Order on website</h1>
            <p className="mb-5 text-[15px] text-fg-3">Pay online and we deliver within {cfg.delivery}.{save > 0 ? ` You save ${usd(save)} per account.` : ''}</p>
            {cfg.offer?.text && <div data-offer className="mb-4 flex items-start gap-2.5 rounded-2xl border border-[#f59e0b]/30 bg-[#f59e0b]/10 px-4 py-3 text-[14px] font-medium text-fg"><Gift size={18} className="mt-0.5 shrink-0 text-[#f59e0b]" aria-hidden /><span>{cfg.offer.text}</span></div>}
            <div className={card}>
              <Err e={err} />
              <div className={clsx('mb-5 grid gap-2.5', cfg.prices.full > 0 ? 'grid-cols-3' : 'grid-cols-2')}>
                {([['account', cfg.tier === 'premium' ? `${cfg.premium_title || 'Premium ad account'} ` : 'Agency ad account', cfg.prices.account, 'per account'], ...(cfg.prices.full > 0 ? [['full', cfg.tier === 'premium' ? 'Full access Premium ' : 'Full access account', cfg.prices.full, 'you top up yourself']] as const : []), ['funnel', 'Landing + funnel', cfg.prices.funnel, 'per month']] as const).map(([k, t, p, u]) => (
                  <button key={k} type="button" onClick={() => setKind(k)} className={clsx('rounded-2xl border p-3.5 text-left transition-colors', kind === k ? 'border-violet bg-violet/12' : 'border-edge hover:border-violet/40')}>
                    <span className="block text-[13.5px] font-semibold">{t}</span>
                    <span className="mt-1 block font-display text-[24px] font-semibold tracking-tight">{usd(p)}</span>
                    <span className="block text-[12px] text-fg-3">{u}</span>
                  </button>
                ))}
              </div>
              {kind !== 'funnel' ? (
                <>
                  {kind === 'full' && <p className="mb-4 rounded-xl bg-ov/[0.05] px-4 py-3 text-[14px] text-fg-2">Full access: you top up the ad account yourself, with no top-up fee from us. Includes the account + 2 free replacements.</p>}
                  <Field label="How many ad accounts?">
                    <div className="flex items-center gap-3">
                      <button type="button" onClick={() => setQty(q => Math.max(1, q - 1))} className="grid h-12 w-12 place-items-center rounded-xl border border-edge" aria-label="Less"><Minus size={18} /></button>
                      <span className="min-w-[3ch] text-center font-display text-[24px] font-semibold">{qty}</span>
                      <button type="button" onClick={() => setQty(q => Math.min(20, q + 1))} className="grid h-12 w-12 place-items-center rounded-xl border border-edge" aria-label="More"><Plus size={18} /></button>
                    </div>
                  </Field>
                  <Field label="Your Business Manager ID" hint="business.facebook.com → Business settings → Business info. Numbers only.">
                    <input className={input} inputMode="numeric" placeholder="e.g. 1234567890123456" value={bm} onChange={e => setBm(e.target.value.replace(/[^\d]/g, ''))} />
                  </Field>
                </>
              ) : (
                <p className="mb-4 rounded-xl bg-ov/[0.05] px-4 py-3 text-[14px] text-fg-2">After payment, your account manager will message you on Telegram to plan your landing page and funnel.</p>
              )}
              <Field label="Your name"><input className={input} autoComplete="name" placeholder="Full name" value={name} onChange={e => setName(e.target.value)} /></Field>
              {!cfg.customer && (
                <Field label="Email" hint="Your order details and ad account IDs are sent here.">
                  <input className={input} type="email" inputMode="email" autoComplete="email" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} />
                </Field>
              )}
              <Field label="Mobile number (Telegram)" hint="We send your delivery update here on Telegram and by email.">
                <span className="flex items-stretch overflow-hidden rounded-xl border border-edge bg-ov/[0.04] focus-within:border-violet">
                  <span className="grid place-items-center border-r border-edge px-3.5 text-[16px] text-fg-2">+91</span>
                  <input className="min-w-0 flex-1 bg-transparent px-3.5 py-3.5 text-[16px] text-fg outline-none placeholder:text-fg-3/70" type="tel" inputMode="numeric" autoComplete="tel-national" placeholder="98765 43210" value={phone} onChange={e => setPhone(e.target.value.replace(/[^\d\s+-]/g, ''))} />
                </span>
              </Field>
              <div className="my-5 flex items-center justify-between rounded-xl bg-ov/[0.05] px-4 py-3.5">
                <span className="text-fg-2">Total</span><span className="font-display text-[24px] font-semibold">{usd(total)}</span>
              </div>
              <button disabled={busy} onClick={() => void submit()} className="btn-primary w-full">{busy ? <Loader2 size={17} className="animate-spin" /> : 'Continue to payment'}</button>
              <p className="mt-3 flex items-center justify-center gap-1.5 text-[12.5px] text-fg-3"><ShieldCheck size={14} /> {cfg.customer ? `Logged in as ${cfg.customer.email}` : 'Secure payment · details sent to your email'}</p>
            </div>
          </>
        )}
        {step === 'pay' && order && (
          <div className="mt-2">
            <Payment cfg={cfg} item={{ type: 'order', id: order.id, code: order.code, total: order.amount, status: order.status, pay_method: order.pay_method, inr_amount: order.inr_amount, utr: order.utr, label: order.kind === 'funnel' ? 'Landing + funnel' : `${order.qty}${order.full ? ' full access' : ''} ad account${order.qty > 1 ? 's' : ''}` }}
              onPaid={() => setStep('done')} onBack={() => { setStep('form'); try { history.replaceState(null, '', '/order'); } catch { /* ignore */ } }} okey={okey} />
          </div>
        )}
        {step === 'done' && order && (
          <div className={clsx(card, 'mt-2 text-center')}>
            <div className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-full bg-[#22c55e]/15 text-[#22c55e]"><Check size={30} strokeWidth={2.5} /></div>
            <h2 className="font-display text-[24px] font-semibold">Payment received</h2>
            <p className="mx-auto mt-2 max-w-[38ch] text-[15px] text-fg-2">{order.kind === 'funnel' ? 'Your account manager will message you on Telegram to start the setup.' : `Your ad account${order.qty > 1 ? 's' : ''} will be shared to your Business Manager within ${cfg.delivery}. We’ll email you and message you on Telegram.`}</p>
            {order.kind === 'funnel' && cfg.manager && <a href={cfg.manager} target="_blank" rel="noopener" className="btn-primary mt-5 w-full"><Send size={16} /> Message account manager</a>}
            <a href="/account" className="btn-ghost mt-3 w-full">Go to my account</a>
            <p className="mt-3 text-[12.5px] text-fg-3">Log in to My account with your email (we send a code) to see your ad accounts and top up.</p>
          </div>
        )}
      </div>
    </Shell>
  );
}

/* ---------------- ACCOUNT page ---------------- */
export function AccountPage({ brand, logo }: { brand: string; logo: string }) {
  const [cfg, setCfg] = useState<Config | null>(null);
  const [me, setMe] = useState<Me | null>(null);
  const [needLogin, setNeedLogin] = useState(false);
  const [pay, setPay] = useState<Payable | null>(null);
  const [tu, setTu] = useState<{ account: string; amount: string; manual: string; open: boolean }>({ account: '', amount: '', manual: '', open: false });
  const [busy, setBusy] = useState(false); const [err, setErr] = useState(''); const [msg, setMsg] = useState('');
  const first = useRef(true);
  const load = useCallback(async () => {
    const c = await api<Config>('config'); setCfg(c);
    try { const m = await api<Me>('me'); setMe(m); setNeedLogin(false); return m; } catch (e) { if ((e as { status?: number }).status === 401) setNeedLogin(true); return null; }
  }, []);
  useEffect(() => {
    void load().then(m => {
      if (!m || !first.current) return; first.current = false;
      const q = new URLSearchParams(location.search);
      const o = q.get('order') && m.orders.find(x => x.code === q.get('order'));
      const t = q.get('topup') && m.topups.find(x => x.code === q.get('topup'));
      if (o && ['new', 'pending_payment', 'awaiting_inr', 'inr_review'].includes(o.status)) setPay(orderPay(o));
      if (t && ['new', 'pending_payment', 'awaiting_inr', 'inr_review'].includes(t.status)) setPay(topupPay(t));
      if ((o && o.status === 'paid') || (t && t.status === 'paid')) setMsg('Payment received We’re on it.');
    });
  }, [load]);
  const fee = useMemo(() => { const a = parseFloat(tu.amount) || 0; const f = Math.round(a * (cfg?.prices.topupPct || 0)) / 100; return { a, f, t: Math.round((a + f) * 100) / 100 }; }, [tu.amount, cfg]);
  if (!cfg) return <Shell brand={brand} logo={logo}><div className="grid h-[60vh] place-items-center"><Loader2 className="animate-spin text-fg-3" /></div></Shell>;

  async function logout() { await api('logout', {}); setMe(null); setNeedLogin(true); }
  async function createTopup() {
    setErr(''); setBusy(true);
    try {
      const r = await api<{ topup: Topup }>('topup_create', tu.manual ? { act_id: tu.manual, amount: tu.amount } : { account_id: tu.account, amount: tu.amount });
      setPay(topupPay(r.topup)); setTu({ account: '', amount: '', manual: '', open: false }); void load();
    } catch (e) { setErr((e as Error).message); } finally { setBusy(false); }
  }
  async function cancel(type: 'order' | 'topup', id: number) {
    if (!confirm('Cancel this?')) return;
    try { await api('cancel', { type, id }); await load(); } catch (e) { setErr((e as Error).message); }
  }

  const right = me ? <button onClick={() => void logout()} className="inline-flex items-center gap-1.5 rounded-full border border-edge px-3.5 py-2 text-[13.5px] text-fg-2 hover:text-fg"><LogOut size={15} /> Log out</button>
    : <a href="/order" className="rounded-full border border-edge px-4 py-2 text-[13.5px] font-medium text-fg-2 hover:text-fg">Order</a>;

  return (
    <Shell brand={brand} logo={logo} right={right}>
      {needLogin ? (
        <div className="mx-auto mt-4 max-w-[480px]"><Login title="Log in to your account" sub="Enter the email you used for your order. We’ll send a 6-digit code." onDone={() => void load()} /></div>
      ) : !me ? <div className="grid h-[60vh] place-items-center"><Loader2 className="animate-spin text-fg-3" /></div>
      : pay ? (
        <div className="mx-auto mt-2 max-w-[520px]"><Payment cfg={cfg} item={pay} onPaid={() => { setPay(null); setMsg('Payment received We’re on it.'); void load(); }} onBack={() => { setPay(null); void load(); }} /></div>
      ) : (
        <div className="mt-2 grid gap-5 lg:grid-cols-[1.1fr_1fr]">
          <div className="min-w-0 space-y-5">
            <div>
              <h1 className="font-display text-[28px] font-semibold tracking-tight">Hi {me.customer.name?.split(' ')[0] || 'there'} </h1>
              <p className="text-[14.5px] text-fg-3">{me.customer.email}</p>
            </div>
            {msg && <p className="flex items-center justify-between rounded-xl bg-[#22c55e]/12 px-4 py-3 text-[14.5px] text-[#4ade80]">{msg}<button onClick={() => setMsg('')} aria-label="Close"><X size={16} /></button></p>}
            <Err e={err} />
            <div className={card}>
              <div className="mb-3 flex items-center justify-between"><h2 className="flex items-center gap-2 text-[17px] font-semibold"><Wallet size={18} /> Your ad accounts</h2><a href="/order" className="text-[13.5px] font-medium text-lilac">+ Order more</a></div>
              {me.accounts.length ? (
                <ul className="divide-y divide-edge">
                  {me.accounts.map(a => (
                    <li key={a.id} className="flex items-center gap-3 py-3">
                      <span className="min-w-0 flex-1 font-mono text-[15px]">{a.act_id}</span>
                      <button onClick={() => setTu({ account: String(a.id), amount: '', manual: '', open: true })} className="rounded-full bg-violet/15 px-3.5 py-1.5 text-[13.5px] font-semibold text-lilac">Top up</button>
                    </li>
                  ))}
                </ul>
              ) : <p className="text-[14px] text-fg-3">Your ad accounts appear here after delivery.</p>}
              <p className="mt-4 rounded-xl bg-ov/[0.05] px-4 py-3 text-[13px] leading-relaxed text-fg-3">Bought your account through our Telegram support? Top-ups for those accounts are handled by your support agent on Telegram.</p>
              {cfg.manager && <a href={cfg.manager} target="_blank" rel="noopener" className="btn-ghost mt-3 w-full py-3 text-[14px]"><Send size={15} /> Contact your account manager</a>}
            </div>
            {tu.open && (
              <div className={card}>
                <div className="mb-4 flex items-center justify-between"><h2 className="text-[17px] font-semibold">Top up an ad account</h2><button onClick={() => setTu(t => ({ ...t, open: false }))} aria-label="Close" className="text-fg-3"><X size={18} /></button></div>
                <Field label="Ad account">
                  <select className={input} value={tu.account} onChange={e => setTu(t => ({ ...t, account: e.target.value, manual: '' }))}>
                    {me.accounts.map(a => <option key={a.id} value={a.id}>{a.act_id}</option>)}
                  </select>
                </Field>
                <Field label={`Top-up amount (USD) · minimum ${usd(cfg.prices.topupMin)}`}>
                  <input className={input} type="number" inputMode="decimal" min={cfg.prices.topupMin} placeholder={String(Math.max(cfg.prices.topupMin, 50))} value={tu.amount} onChange={e => setTu(t => ({ ...t, amount: e.target.value }))} />
                </Field>
                <div className="mb-4 space-y-1.5 rounded-xl bg-ov/[0.05] px-4 py-3 text-[14px]">
                  <div className="flex justify-between"><span className="text-fg-3">Added to your ad account</span><span>{usd(fee.a)}</span></div>
                  <div className="flex justify-between"><span className="text-fg-3">Service fee ({cfg.prices.topupPct}%)</span><span>{usd(fee.f)}</span></div>
                  <div className="flex justify-between border-t border-edge pt-1.5 font-semibold"><span>You pay</span><span>{usd(fee.t)}</span></div>
                </div>
                <button disabled={busy || !(fee.a >= cfg.prices.topupMin)} onClick={() => void createTopup()} className="btn-primary w-full">{busy ? <Loader2 size={17} className="animate-spin" /> : 'Continue to payment'}</button>
              </div>
            )}
          </div>
          <div className="min-w-0 space-y-5">
            <div className={card}>
              <h2 className="mb-3 text-[17px] font-semibold">Orders</h2>
              {me.orders.length ? me.orders.map(o => (
                <div key={o.id} className="border-b border-edge py-3 last:border-0">
                  <div className="flex items-center justify-between gap-2"><span className="text-[14.5px] font-medium">{o.kind === 'funnel' ? 'Landing + funnel' : `${o.qty}${o.full ? ' full access' : ''} ad account${o.qty > 1 ? 's' : ''}`}</span><Chip s={o.status} /></div>
                  <p className="mt-1 text-[12.5px] text-fg-3">{o.code} · {usd(o.amount)}{o.bm_id ? ` · BM ${o.bm_id}` : ''} · {new Date(o.created_at).toLocaleDateString()}</p>
                  {o.accounts.length > 0 && <p className="mt-1 font-mono text-[13px] text-fg-2">{o.accounts.join(', ')}</p>}
                  {['new', 'pending_payment', 'awaiting_inr', 'inr_review'].includes(o.status) && (
                    <div className="mt-2 flex gap-2">
                      <button onClick={() => setPay(orderPay(o))} className="rounded-full bg-violet/15 px-3.5 py-1.5 text-[13px] font-semibold text-lilac">{o.status === 'inr_review' ? 'View' : 'Pay now'}</button>
                      {o.status !== 'inr_review' && <button onClick={() => void cancel('order', o.id)} className="rounded-full px-3 py-1.5 text-[13px] text-fg-3 hover:text-fg">Cancel</button>}
                    </div>
                  )}
                </div>
              )) : <p className="text-[14px] text-fg-3">No orders yet. <a href="/order" className="text-lilac">Order an ad account →</a></p>}
            </div>
            {me.topups.length > 0 && (
              <div className={card}>
                <h2 className="mb-3 text-[17px] font-semibold">Top-ups</h2>
                {me.topups.map(t => (
                  <div key={t.id} className="border-b border-edge py-3 last:border-0">
                    <div className="flex items-center justify-between gap-2"><span className="text-[14.5px] font-medium">{usd(t.amount)} → <span className="font-mono">act_{t.act_id}</span></span><Chip s={t.status} /></div>
                    <p className="mt-1 text-[12.5px] text-fg-3">{t.code} · paid {usd(t.total)} incl. fee · {new Date(t.created_at).toLocaleDateString()}</p>
                    {['new', 'pending_payment', 'awaiting_inr', 'inr_review'].includes(t.status) && (
                      <div className="mt-2 flex gap-2">
                        <button onClick={() => setPay(topupPay(t))} className="rounded-full bg-violet/15 px-3.5 py-1.5 text-[13px] font-semibold text-lilac">{t.status === 'inr_review' ? 'View' : 'Pay now'}</button>
                        {t.status !== 'inr_review' && <button onClick={() => void cancel('topup', t.id)} className="rounded-full px-3 py-1.5 text-[13px] text-fg-3 hover:text-fg">Cancel</button>}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </Shell>
  );
}
const orderPay = (o: Order): Payable => ({ type: 'order', id: o.id, code: o.code, total: o.amount, status: o.status, pay_method: o.pay_method, inr_amount: o.inr_amount, utr: o.utr, label: o.kind === 'funnel' ? 'Landing + funnel' : `${o.qty}${o.full ? ' full access' : ''} ad account${o.qty > 1 ? 's' : ''}` });
const topupPay = (t: Topup): Payable => ({ type: 'topup', id: t.id, code: t.code, total: t.total, status: t.status, pay_method: t.pay_method, inr_amount: t.inr_amount, utr: t.utr, label: `Top-up act_${t.act_id}` });

/* ---------------- PAYMENT LINK page (/pay/PL-XXXX, made by an agent in Telegram) ---------------- */
type LinkInfo = { link: { code: string; label: string; kind: string; amount: number; fee: number; total: number; status: string; fee_pct: number; wa?: boolean; lines?: [string, number][] | null; paid_usd?: number; due?: number }; coins: { id: string; name: string }[]; crypto: Crypto | null };
async function payApi<T = any>(code: string, q = '', b?: unknown): Promise<T> {
  const r = await fetch(`/api/pay/${encodeURIComponent(code)}${q}`, { method: b ? 'POST' : 'GET', headers: b ? { 'content-type': 'application/json' } : undefined, body: b ? JSON.stringify(b) : undefined, cache: 'no-store' });
  const j = await r.json().catch(() => ({}));
  if (!r.ok || j.error) throw new Error(j.error || 'Something went wrong. Please try again.');
  return j as T;
}
export function PayLinkPage({ code, brand, logo }: { code: string; brand: string; logo: string }) {
  const [d, setD] = useState<LinkInfo | null>(null);
  const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const [coin, setCoin] = useState('');
  const [pick, setPick] = useState(false);
  const load = useCallback(async (check = false) => {
    try { const r = await payApi<LinkInfo>(code, check ? '?check=1' : ''); setD(r); setCoin(c => c || r.coins[0]?.id || ''); }
    catch (e) { setErr((e as Error).message); }
  }, [code]);
  useEffect(() => { void load(); }, [load]);
  const waiting = d?.link.status === 'pending_payment' && !!d.crypto && !pick;
  useEffect(() => { if (!waiting) return; const t = setInterval(() => void load(true), 8000); return () => clearInterval(t); }, [waiting, load]);
  // Phone / browser Back while the address is shown → back to the coin list (instead of leaving the page)
  const seenPay = ['confirming', 'confirmed', 'sending', 'partially_paid'].includes(d?.crypto?.np_status || '');
  useEffect(() => {
    if (!waiting || seenPay) return;
    try { window.history.pushState({ pl: 'address' }, ''); } catch { return; }
    const onPop = () => { setPick(true); };
    window.addEventListener('popstate', onPop);
    return () => { window.removeEventListener('popstate', onPop); try { if (window.history.state?.pl === 'address') window.history.back(); } catch { /* ignore */ } };
  }, [waiting, seenPay]);
  async function start(renew = false) {
    setErr(''); setBusy(true);
    try { const r = await payApi<{ crypto: Crypto }>(code, '', { currency: renew && d?.crypto ? d.crypto.currency : coin, renew }); setD(x => x ? { ...x, crypto: r.crypto, link: { ...x.link, status: 'pending_payment' } } : x); setPick(false); }
    catch (e) { setErr((e as Error).message); } finally { setBusy(false); }
  }
  const l = d?.link;
  return (
    <Shell brand={brand} logo={logo}>
      <div className="mx-auto max-w-[520px] pt-4">
        {!d ? (err ? <div className={card}><Err e={err} /></div> : <div className="grid h-60 place-items-center"><Loader2 className="animate-spin text-fg-3" /></div>) : (
          <div className={card}>
            <p className="text-[13px] text-fg-3">{l!.label} · {l!.code}</p>
            <p className="font-display text-[34px] font-semibold leading-tight tracking-tight">{usd(l!.total)}</p>
            {!!l!.lines && l!.lines.length > 1 && (
              <div className="mt-3 space-y-1 rounded-xl bg-ov/[0.05] px-4 py-3 text-[14px]" data-breakdown>
                {l!.lines.map(([t, v], i) => <div key={i} className="flex justify-between gap-3"><span className="text-fg-3">{t}</span><span className={v < 0 ? 'text-[#22c55e]' : ''}>{v < 0 ? '−' + usd(-v) : usd(v)}</span></div>)}
                <div className="flex justify-between border-t border-edge pt-1"><b>Total</b><b>{usd(l!.total)}</b></div>
              </div>
            )}
            {!l!.lines && l!.kind === 'topup' && l!.fee > 0 && (
              <div className="mt-3 space-y-1 rounded-xl bg-ov/[0.05] px-4 py-3 text-[14px]">
                <div className="flex justify-between"><span className="text-fg-3">Top-up</span><span>{usd(l!.amount)}</span></div>
                <div className="flex justify-between"><span className="text-fg-3">Service fee ({l!.fee_pct}%)</span><span>{usd(l!.fee)}</span></div>
                <div className="flex justify-between border-t border-edge pt-1"><b>Total</b><b>{usd(l!.total)}</b></div>
              </div>
            )}
            {!['paid', 'done', 'cancelled'].includes(l!.status) && (l!.paid_usd || 0) > 0 && (l!.due || 0) > 0 && (
              <div data-short className="mt-3 rounded-xl border border-[#f5b83d]/40 bg-[#f5b83d]/10 px-4 py-3 text-[14px]">
                <div className="flex justify-between"><span className="text-fg-2">Received</span><span>{usd(l!.paid_usd!)}</span></div>
                <div className="flex justify-between font-semibold"><span>Remaining to pay</span><span>{usd(l!.due!)}</span></div>
                <p className="mt-1.5 text-[12.5px] text-fg-3">Your payment is not confirmed yet. Pay the remaining amount here to complete it.</p>
              </div>
            )}
            <div className="mt-5"><Err e={err} /></div>
            {['paid', 'done'].includes(l!.status) ? (
              <div className="rounded-2xl bg-[#22c55e]/12 p-5 text-center">
                <Check className="mx-auto mb-2 text-[#22c55e]" size={28} />
                <p className="text-[18px] font-semibold">Payment received </p>
                <p className="mt-1.5 text-[14px] text-fg-2">Thank you! Your account manager has been notified and will continue on {l?.wa ? 'WhatsApp' : 'Telegram'}.</p>
              </div>
            ) : l!.status === 'cancelled' ? (
              <p className="rounded-xl bg-ov/[0.05] p-4 text-[14px] text-fg-2">This payment link was cancelled. Please ask your account manager on Telegram for a new one.</p>
            ) : waiting ? (
              <>
                <CryptoBox c={d.crypto!} busy={busy} onRenew={() => void start(true)} onCheck={() => void load(true)} onChange={() => { setCoin(d.crypto!.currency); setPick(true); }} />
              </>
            ) : d.coins.length ? (
              <>
                <p className="mb-3 flex items-center gap-2 font-semibold"><Bitcoin size={18} className="text-[#f7931a]" /> Choose a coin</p>
                <div className="mb-4 flex flex-wrap gap-2">
                  {d.coins.map(c => (
                    <button key={c.id} type="button" onClick={() => setCoin(c.id)} className={clsx('rounded-full border px-3.5 py-2 text-[13.5px] font-medium', coin === c.id ? 'border-violet bg-violet/15 text-fg' : 'border-edge text-fg-2 hover:border-violet/40')}>{c.name}</button>
                  ))}
                </div>
                <button disabled={busy || !coin} onClick={() => void start()} className="btn-primary w-full">{busy ? <Loader2 size={17} className="animate-spin" /> : `Pay ${usd((l!.paid_usd || 0) > 0 && (l!.due || 0) > 0 ? l!.due! : l!.total)} with crypto`}</button>
                {pick && d.crypto && l!.status === 'pending_payment' && <button data-back-address onClick={() => setPick(false)} className="mt-3 block w-full text-center text-[13.5px] text-fg-3 hover:text-fg">Back to the {d.crypto.coin} address</button>}
                <p className="mt-3 flex items-center justify-center gap-1.5 text-center text-[12.5px] text-fg-3"><ShieldCheck size={14} /> Confirmed automatically on the blockchain</p>
              </>
            ) : <p className="rounded-xl bg-ov/[0.05] p-4 text-[14px] text-fg-2">Crypto payment isn’t available right now. Please contact your account manager.</p>}
          </div>
        )}
      </div>
    </Shell>
  );
}

