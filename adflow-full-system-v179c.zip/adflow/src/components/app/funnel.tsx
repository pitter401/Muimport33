'use client';
// v168: Home → Landing page funnel (admin only). One stepped-bar funnel per landing page / ad type, from our own tracking.
import { useCallback, useEffect, useState } from 'react';
import clsx from 'clsx';
import { SectionHead, Tag, InfoTip, useInterval } from './ui';

type FStep = { k: string; label: string; sub?: string; n: number | null; partial?: boolean; step_pct: number | null; overall_pct: number | null; drop: number; biggest?: boolean };
type FEntry = { k: string; kind: 'form' | 'wa_page' | 'wa_comm' | 'tg_page' | 'ch_page'; line: 'agency' | 'premium' | 'funnel' | null; title: string; path: string; steps: FStep[];
  visitors: number | null; chats: number; buyers: number; buy_pct: number | null; left: { n: number; of: number; pct: number | null; after: string } | null; note?: string };
type FData = { since: number; partial: boolean; entries: FEntry[] };

const KIND: Record<FEntry['kind'], string> = { form: 'Lead form', wa_page: 'WhatsApp', wa_comm: 'Community', ch_page: 'Channel ad', tg_page: 'Telegram' };
const COLOR: Record<FEntry['kind'], string> = { form: '#3390EC', wa_page: '#25A244', wa_comm: '#25A244', ch_page: '#30B0C7', tg_page: '#30B0C7' };
const LINE_C: Record<string, string> = { agency: '#3390EC', premium: '#D98A00', funnel: '#7C5CE0' };
const p = (v: number | null | undefined) => (v == null ? '—' : `${v}%`);
const nf = (v: number | null | undefined) => (v == null ? '—' : Math.max(0, v).toLocaleString());
// the summary table's short name: the entry type, with the line on a small second line (v168 senior review: one line
// "Agency · WhatsApp" was cut to "Agency · Whats…" at 375 px)
const typeName = (e: FEntry) => ({ form: 'Lead form', wa_page: 'WhatsApp', wa_comm: 'Community', ch_page: 'Channel', tg_page: 'Telegram page' } as const)[e.kind];
const lineName = (e: FEntry) => (e.line ? e.line[0].toUpperCase() + e.line.slice(1) : '');
const day = (ms: number) => new Date(ms).toLocaleDateString([], { day: 'numeric', month: 'short' });

function FunnelCard({ e, since }: { e: FEntry; since: number }) {
  const top = Math.max(1, ...e.steps.map(s => s.n || 0));
  const c = e.kind === 'form' && e.line ? LINE_C[e.line] : COLOR[e.kind];
  return (
    <div className="af-card overflow-hidden px-3.5 pb-3 pt-3" data-funnel={e.k}>
      <div className="flex min-w-0 items-center gap-2">
        <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: c }} />
        <b className="min-w-0 flex-1 truncate text-[15px] font-semibold">{e.title}</b>
        <Tag tone="mute">{KIND[e.kind]}</Tag>
      </div>
      <p className="mt-0.5 truncate pl-4 text-[12px] text-tg-faint">{e.path}</p>
      {e.left && e.left.of > 0 && (
        <p className="mt-2 text-[13px] leading-snug" data-left>
          <b className={clsx('af-num font-semibold', (e.left.pct || 0) >= 50 ? 'text-tg-bad' : 'text-tg-text')}>{p(e.left.pct)}</b>
          <span className="text-tg-sub"> left on the page · {nf(e.left.n)} of {nf(e.left.of)} never got to “{e.left.after}”</span>
        </p>
      )}
      <div className="mt-2.5 space-y-2" role="list">
        {e.steps.map((s, i) => (
          <div key={s.k} role="listitem" data-step={s.k} data-n={s.n ?? ''}>
            <div className="flex min-w-0 items-baseline gap-2">
              <span className="min-w-0 flex-1 truncate text-[13px]">{s.label}{s.sub && <span className="text-tg-faint"> · {s.sub}</span>}</span>
              {s.biggest && <Tag tone="bad" className="!h-[18px] !px-1.5 !text-[10.5px]">Biggest drop</Tag>}
              <b className="af-num shrink-0 text-[14px] font-semibold">{nf(s.n)}</b>
            </div>
            <div className="mt-1 flex items-center gap-2">
              <div className="h-2 min-w-0 flex-1 overflow-hidden rounded-full bg-tg-track">
                <i className="block h-full rounded-full transition-[width] duration-500" style={{ width: `${s.n ? Math.max(2, Math.min(100, (s.n / top) * 100)) : 0}%`, background: c, opacity: s.partial ? 0.45 : 1 - i * 0.09 }} />
              </div>
              <span className="af-num w-[104px] shrink-0 text-right text-[11.5px] text-tg-sub">
                {s.partial ? `tracking from ${day(since)}` : s.n == null ? 'not tracked' : s.step_pct == null ? (s.overall_pct === 100 ? 'start' : '—') : <><b className={clsx('font-semibold', s.biggest ? 'text-tg-bad' : 'text-tg-text')}>{p(s.step_pct)}</b> · {p(s.overall_pct)} all</>}
              </span>
            </div>
          </div>
        ))}
      </div>
      {e.note && <p className="mt-2 text-[12px] text-tg-faint">{e.note}</p>}
    </div>
  );
}

/** conv = the Home stats' conv (the Bought / Buying rate tiles), shown under the cards so the numbers line up. */
export function LandingFunnel({ api, range, line, conv }: { api: (path: string) => Promise<any>; range: string; line: string; conv?: { buyers: number; active: number; conv_pct: number | null } | null }) {
  const [d, setD] = useState<FData | null>(null);
  const [more, setMore] = useState(false);
  const load = useCallback(() => api(`landing_funnel?range=${encodeURIComponent(range)}${line === 'all' ? '' : '&line=' + line}`).then((r: FData) => setD(r)).catch(() => {}), [api, range, line]);
  useEffect(() => { setD(null); void load(); }, [load]);
  useInterval(() => void load(), 30000);
  const list = d?.entries || [];
  const shown = more ? list : list.slice(0, 3);
  return (
    <section data-landing-funnel className="min-w-0">
      <SectionHead title={<span className="inline-flex items-center gap-1.5">Landing page funnel<InfoTip title="Landing page funnel">Each landing page / ad type with its own steps, from our own tracking (not Meta). Each % is of the step above; “all” is of the first step. Buyers are the people of that step who bought by the end of the period. “Tapped Order / Chat”, “Reached name &amp; number” and the WhatsApp page visits are counted from v168{d ? ` (${day(d.since)})` : ''}.</InfoTip></span>} />
      {!d ? <div className="af-card h-[120px] animate-pulse" /> : !list.length ? (
        <div className="af-card px-4 py-3.5 text-[13.5px] text-tg-sub">No landing page visits in this period yet.</div>
      ) : (
        <div className="space-y-2.5">
          {line === 'all' && list.length > 1 && (
            <div className="af-card overflow-hidden" data-funnel-table>
              <div className="grid grid-cols-[minmax(0,1fr)_44px_44px_44px_48px] gap-x-1 px-3.5 pb-1.5 pt-2.5 text-[10.5px] font-medium uppercase tracking-normal text-tg-sub">
                <span>Page</span><span className="text-right">Visits</span><span className="text-right">Chats</span><span className="text-right">Bought</span><span className="text-right">Rate</span>
              </div>
              {list.map(e => (
                <div key={e.k} className="af-sepabove relative grid grid-cols-[minmax(0,1fr)_44px_44px_44px_48px] items-center gap-x-1 px-3.5 py-2 text-[13px]" data-row={e.k}>
                  <span className="flex min-w-0 items-center gap-1.5"><span className="h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: e.kind === 'form' && e.line ? LINE_C[e.line] : COLOR[e.kind] }} /><span className="min-w-0" title={e.title}><span className="block truncate leading-tight">{typeName(e)}</span>{e.line && <span className="block truncate text-[11px] leading-tight text-tg-sub">{lineName(e)}</span>}</span></span>
                  <span className="af-num text-right">{nf(e.visitors)}</span>
                  <span className="af-num text-right">{nf(e.chats)}</span>
                  <span className="af-num text-right">{nf(e.buyers)}</span>
                  <span className="af-num text-right font-semibold">{p(e.buy_pct)}</span>
                </div>
              ))}
            </div>
          )}
          {shown.map(e => <FunnelCard key={e.k} e={e} since={d.since} />)}
          {list.length > 3 && <button type="button" onClick={() => setMore(v => !v)} className="w-full py-1.5 text-center text-[13.5px] font-medium text-tg-link">{more ? 'Show less' : `Show ${list.length - 3} more`}</button>}
          {conv && <p className="mx-1 text-[12px] text-tg-sub" data-funnel-conv>All buyers this period: <b className="af-num text-tg-text">{nf(conv.buyers)}</b> · buying rate <b className="af-num text-tg-text">{p(conv.conv_pct)}</b> ({nf(conv.buyers)} of {nf(conv.active)} people, the Bought tile)</p>}
        </div>
      )}
    </section>
  );
}
