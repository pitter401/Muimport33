'use client';

/** Ad accounts from our own BMs: panel for admin + manager, and the "Ad account" sheet in a chat (all agents). */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { RefreshCw, Plus, Search, KeyRound, ShieldCheck, AlertTriangle, CreditCard, ChevronRight, ChevronDown, Ban, Copy, Zap, Banknote, Power, Camera, ArrowUp, Share2, MessageSquareText, Send, Check, Trash2, RotateCcw } from 'lucide-react';
import clsx from 'clsx';
import { makeApi, useToast, Sheet, Field, inputCls, Btn, Seg, Toggle, useInterval, listTime, Skeleton, Group, Row, SectionHead, IconTile, TILE, Tag, Badge, InfoTip, Avatar, Chips, DropPill } from './ui';
import { Profiles, Queue, ManualShareSheet, CAT, useOpenKey } from './metaprof';

/** $42.10 · $388 · $1,250.50 */
const usd = (n: number | null | undefined) => { if (n == null || !Number.isFinite(Number(n))) return '—'; const v = Math.round(Number(n) * 100) / 100; return '$' + v.toLocaleString('en-US', { minimumFractionDigits: v % 1 ? 2 : 0, maximumFractionDigits: 2 }); };

type Api = ReturnType<typeof makeApi>;
export type Acct = {
  act_id: string; no: number; name: string | null; status: number; status_label: string; currency: string | null; created_time: number | null; spent: number; cap: number; left: number; today: number;
  card: string | null; state: string; step: string | null; err: string | null; bm_id: string; bm_name: string | null; bm_status: string | null; tier: string; share_mode: string | null;
  client_bm: string | null; client_email: string | null; assigned_at: number | null; disabled_at: number | null; synced_at: number | null; lead: { id: number; name: string; agent: string | null } | null;
  /** v167 (server adds these; optional until then) */
  status_text?: string | null; disable_text?: string | null; pay_fail?: boolean | number | null; pay_due?: number | null; pay_fail_at?: number | null;
};
type Bm = { id: number; bm_id: string; name: string | null; label: string | null; su_name: string | null; verification: string | null; tier: string; created_time: number | null; acct_limit: number | null; status: string; error: string | null; error_at: number | null; synced_at: number | null; proxy: string; has_secret: boolean; accounts: number; free: number; assigned: number; disabled: number };
type Req = { id: number; kind: string; lead_id: number; act_id: string | null; tier: string | null; mode: string | null; client_bm: string | null; client_email: string | null; paid: number | null; fee: number | null; amount: number | null; method: string; pay_code: string | null; note: string | null; status: string; error: string | null; created_at: number; done_at: number | null; summary: string; lead: { id: number; name: string } | null; agent: string | null; credit: number };

export const TIER: Record<string, [string, string]> = { premium: ['Premium', 'bg-[#f59e0b] text-black'], std: ['$25 account', 'bg-[#4FA3F7]/20 text-tg-link'], verified: ['Verified', 'bg-[#4FA3F7]/20 text-tg-link'], review: ['In review', 'bg-tg-orange/15 text-tg-orange'], unverified: ['Unverified', 'bg-white/10 text-tg-sub'], any: ['Any type', 'bg-white/10 text-tg-sub'] };
const STATE: Record<string, [string, string]> = { free: ['Free', 'bg-white/10 text-tg-sub'], assigned: ['With client', 'bg-tg-green/15 text-tg-ok'], invited: ['Invite sent', 'bg-tg-acc/20 text-tg-link'], disabled: ['Disabled', 'bg-tg-red/15 text-tg-bad'] };
const BMSTATE: Record<string, [string, string]> = { ok: ['API OK', 'bg-tg-green/15 text-tg-ok'], blocked: ['API blocked', 'bg-tg-red/15 text-tg-bad'], error: ['Error', 'bg-tg-orange/15 text-tg-orange'], banned: ['Banned', 'bg-tg-red/25 text-tg-bad'] };
const REQSTATE: Record<string, [string, string]> = { pending: ['Waiting', 'bg-tg-orange/15 text-tg-orange'], manual: ['Do by hand', 'bg-tg-red/15 text-tg-bad'], failed: ['Failed', 'bg-tg-red/15 text-tg-bad'], running: ['Running…', 'bg-tg-acc/20 text-tg-link'], queued: ['In queue', 'bg-tg-acc/20 text-tg-link'], done: ['Done', 'bg-tg-green/15 text-tg-ok'], rejected: ['Rejected', 'bg-white/10 text-tg-sub'] };
export const Chip = ({ m, k }: { m: Record<string, [string, string]>; k: string }) => { const [l, c] = m[k] || [k, 'bg-white/10 text-tg-sub']; return <span className={clsx('inline-flex h-5 shrink-0 items-center whitespace-nowrap rounded-[6px] px-[7px] text-[11.5px] font-semibold', c)}>{l}</span>; };
export function age(ms: number | null) {
  if (!ms) return '—';
  const d = Math.floor((Date.now() - ms) / 86400000);
  if (d < 31) return `${d} day${d === 1 ? '' : 's'}`;
  const m = Math.floor(d / 30.4); if (m < 12) return `${m} mo`;
  const y = Math.floor(m / 12); return `${y} yr${m % 12 ? ` ${m % 12} mo` : ''}`;
}
const card = 'af-card p-3.5';
/** v167: status line pieces — the account's Meta status with the disable reason, and the payment-failed tag. */
const statusTxt = (a: Acct) => `${a.status_text || a.status_label || `Status ${a.status}`}${a.disable_text ? ` · ${a.disable_text}` : ''}`;
const payFailTxt = (a: Acct) => `Payment failed${a.pay_due != null && Number(a.pay_due) > 0 ? ` · ${usd(a.pay_due)} due` : ''}`;
const initials = (n: string) => { const p = n.replace(/[^\p{L}\p{N} ]/gu, ' ').trim().split(/\s+/); return ((p[0]?.[0] || '?') + (p.length > 1 ? (/^\d+$/.test(p[p.length - 1]) ? p[p.length - 1].slice(-1) : p[1][0]) : '')).toUpperCase(); };
const copyT = (t: string, toast: (m: string) => void) => { try { void navigator.clipboard.writeText(t); toast('Copied'); } catch { /* ignore */ } };

/* ================================= PANEL ================================= */
let EMAIL_ON = false;
type Tab = 'overview' | 'profiles' | 'queue' | 'accounts' | 'requests' | 'bms' | 'credits' | 'cards' | 'report';
export function MetaPanel({ api, isAdmin }: { api: Api; isAdmin?: boolean }) {
  const [tab, setTab] = useState<Tab>('overview');
  const [ov, setOv] = useState<any>(null);
  const [give, setGive] = useState<{ lead?: { id: number; name: string } | null } | null>(null);
  const [open, setOpen] = useState<string | null>(null);
  const [bmOpen, setBmOpen] = useState<number | null>(null);
  const [ver, setVer] = useState(0);
  const [manual, setManual] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  const toast = useToast();
  const load = useCallback(async () => { try { const o = await api<any>('meta/overview'); EMAIL_ON = !!o?.settings?.email_invites; setOv(o); } catch (e) { toast((e as Error).message, 'err'); } }, [api, toast]);
  useEffect(() => { void load(); }, [load, ver]);
  useInterval(() => void load(), 20000);
  const bump = () => setVer(v => v + 1);
  // v171 (owner): actions that go through the queue (IP change first) finish a minute or two later → the lists refresh by themselves
  useEffect(() => { const t = setInterval(() => { if (document.visibilityState === 'visible') setVer(v => v + 1); }, 15000); return () => clearInterval(t); }, []);
  async function setOn(v: boolean) {
    if (!v && !confirm('Switch OFF the ad account system? Agents won’t see it, payment links go back to the old manager tasks and BMs are not read automatically. You can still set up and test here. Data stays saved.')) return;
    if (v && !confirm('Switch ON? Agents will see “Ad account” in chats and paid links will share / top up from your BMs.')) return;
    try { await api('settings_save', { meta_enabled: v ? '1' : '0' }); toast(v ? 'Ad account system ON' : 'Ad account system OFF'); await load(); bump(); } catch (e) { toast((e as Error).message, 'err'); }
  }
  // v167: one "System is on" row (long text behind the (i))
  const master = ov && (
    <div className="af-card mb-3 flex items-center gap-3 px-4 py-3" data-meta-master>
      <IconTile icon={Power} color={ov.off ? TILE.grey : TILE.green} size="lg" />
      <span className="min-w-0 flex-1">
        <span className="flex items-center gap-1 text-[15.5px] font-semibold">{ov.off ? 'System is off' : 'System is on'}<InfoTip title={ov.off ? 'System is OFF · setup mode' : 'System is ON'}>{ov.off ? 'Add BMs and test here. Agents don’t see it, payment links use the old manager tasks and BMs are read only when you tap Sync now. Client messages still go out when a manager task is done.' : 'Agents see “Ad account” in chats. Master switch: OFF = back to the old way, data stays saved.'}</InfoTip></span>
        <span className="block truncate text-[13px] text-tg-sub">{ov.off ? 'Setup mode · agents don’t see it' : 'Agents can share & top up'}{ov.last_sync ? ` · synced ${listTime(ov.last_sync)}` : ''}</span>
      </span>
      {ov.can_toggle ? <Toggle on={!ov.off} onChange={v => void setOn(v)} /> : null}
    </div>
  );
  const MAIN: [Tab, string][] = [['overview', 'Overview'], ['accounts', 'Accounts'], ['requests', 'Requests']];
  const MORE: [Tab, string][] = [['profiles', 'Profiles'], ['queue', 'Queue'], ['bms', 'BMs'], ['credits', 'Credits'], ['cards', 'Cards'], ['report', 'Report']];
  const inMore = MORE.find(m => m[0] === tab);
  const tabBtn = (on: boolean) => clsx('relative flex h-11 shrink-0 items-center gap-1.5 text-[15px] font-semibold transition-colors', on ? 'text-tg-text after:absolute after:inset-x-0 after:bottom-0 after:h-[2.5px] after:rounded-full after:bg-tg-acc' : 'text-tg-sub');
  return (
    <div className="mx-auto w-full max-w-[860px]">
      <div className={clsx('sticky z-20 mb-3 flex gap-5 border-b border-tg-sep px-4', isAdmin ? 'top-[calc(50px+env(safe-area-inset-top))] -mx-4 bg-tg-bg md:top-0' : 'top-9 -mx-5 bg-tg-panel px-5')} data-meta-tabs>
        {MAIN.map(([t, l]) => <button key={t} data-meta-tab={t} onClick={() => setTab(t)} className={tabBtn(tab === t)}>{l}{t === 'requests' && <Badge n={ov?.requests || 0} tone="blue" />}</button>)}
        <button data-meta-tab="more" onClick={() => setMoreOpen(true)} className={clsx(tabBtn(!!inMore), 'ml-auto')}>{inMore ? inMore[1] : 'More'}<ChevronDown size={16} /></button>
      </div>
      <Sheet open={moreOpen} onClose={() => setMoreOpen(false)} title="Ad accounts">
        <Group tiles className="mb-2">
          {MORE.map(([t, l]) => <Row key={t} data-meta-more={t} onClick={() => { setMoreOpen(false); setTab(t); }} icon={<IconTile icon={({ profiles: KeyRound, queue: RefreshCw, bms: ShieldCheck, credits: Banknote, cards: CreditCard, report: MessageSquareText } as Record<string, any>)[t]} color={({ profiles: TILE.indigo, queue: TILE.teal, bms: TILE.blue, credits: TILE.green, cards: TILE.orange, report: TILE.purple } as Record<string, string>)[t]} />} title={l} right={tab === t ? <Check size={17} className="text-tg-link" /> : undefined} chevron={false} />)}
        </Group>
      </Sheet>
      {tab === 'overview' && master}
      {tab === 'overview' && <Overview api={api} ov={ov} reload={load} go={setTab} openBm={setBmOpen} openAcct={setOpen} onManual={() => setManual(true)} />}
      {tab === 'profiles' && <Profiles api={api} isAdmin={isAdmin} onAcct={setOpen} />}
      {tab === 'queue' && <Queue api={api} />}
      {tab === 'accounts' && <Accounts api={api} ver={ver} onOpen={setOpen} />}
      {tab === 'requests' && <Requests api={api} ver={ver} changed={bump} />}
      {tab === 'bms' && <Bms api={api} ver={ver} onOpen={setBmOpen} changed={bump} />}
      {tab === 'credits' && <Credits api={api} ver={ver} isAdmin={isAdmin} onGive={l => setGive({ lead: l })} changed={bump} />}
      {tab === 'cards' && <Cards api={api} ver={ver} />}
      {tab === 'report' && <Report api={api} isAdmin={isAdmin} />}
      <AccountSheet api={api} act={open} onClose={() => { setOpen(null); bump(); }} changed={bump} />
      <BmSheet api={api} id={bmOpen} onClose={() => setBmOpen(null)} changed={bump} onAcct={a => { setBmOpen(null); setOpen(a); }} />
      <GiveSheet api={api} open={!!give} preset={give} onClose={() => setGive(null)} changed={bump} />
      <ManualShareSheet api={api} open={manual} onClose={() => { setManual(false); bump(); }} manager />
    </div>
  );
}

function Stat({ k, v, s, tone, bare }: { k: string; v: React.ReactNode; s?: React.ReactNode; tone?: string; bare?: boolean }) {
  return <div className={bare ? 'min-w-0' : 'af-card min-w-0 p-3.5'}><div className="text-[12.5px] font-medium text-tg-sub">{k}</div><div className={clsx('af-mid-num mt-0.5', tone)}>{v}</div>{s && <div className="mt-0.5 truncate text-[12px] text-tg-sub">{s}</div>}</div>;
}
/** v167: a row in the "Needs attention" group (coloured tile + title + one line). */
function Attn({ icon, tone, title, sub, onClick }: { icon: React.ReactNode; tone: string; title: string; sub: string; onClick?: () => void }) {
  const c = tone.includes('red') ? TILE.red : tone.includes('orange') ? TILE.orange : TILE.blue;
  return <Row onClick={onClick} icon={<span className="af-tile" style={{ background: c }}>{icon}</span>} title={<span className="font-medium">{title}</span>} sub={sub} />;
}

function Overview({ api, ov, reload, go, openBm, openAcct, onManual }: { api: Api; ov: any; reload: () => void; go: (t: Tab) => void; openBm: (id: number) => void; openAcct: (a: string) => void; onManual?: () => void }) {
  const [rules, setRules] = useState(false);
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  async function sync() { setBusy(true); try { const r = await api<{ synced: number; profiles?: number; eta_min?: number }>('meta/sync_all', {}); toast(r.profiles ? `${r.profiles} profile${r.profiles === 1 ? '' : 's'} added to the queue to read their BMs${r.eta_min ? ` · about ${r.eta_min} min` : ''}${r.synced ? ` · ${r.synced} old BM${r.synced === 1 ? '' : 's'} read` : ''}` : `Synced ${r.synced} BM${r.synced === 1 ? '' : 's'}`); reload(); } catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); } }
  if (!ov) return <div className="p-3"><Skeleton rows={3} h={68} /></div>;
  if (!ov.bms) return (
    <div className={clsx(card, 'p-5')}>
      <h3 className="text-[18px] font-semibold">Connect your first BM</h3>
      <p className="mt-2 text-[14px] leading-relaxed text-tg-sub">In each BM: Business settings → Users → System users → Add (Admin) → Assign assets (all ad accounts, Full control; your app) → Generate token (Never expires, ads_management + ads_read + business_management). Then paste it here in BMs → Add BM.</p>
      <Btn className="mt-4" onClick={() => go('bms')}><Plus size={18} />Add BM</Btn>
    </div>
  );
  const tot = Math.max(1, Number(ov.free) + Number(ov.assigned) + Number(ov.disabled));
  const payFailN = Number(ov.pay_failed || 0);
  const attnN = ov.blocked.length + (ov.requests > 0 ? 1 : 0) + ov.recent_disabled.length + ov.cards_low.length + (ov.low.length > 0 ? 1 : 0) + (payFailN > 0 ? 1 : 0);
  const st = ov.settings || {};
  const SYNC_L: Record<string, string> = { '30': '30 min', '60': '1 h', '180': '3 h', '360': '6 h', '720': '12 h', '1440': '24 h' };
  return (
    <div>
      <div className="af-card mb-3 px-4 pb-3.5 pt-3" data-inventory>
        <div className="mb-2 flex items-baseline justify-between text-[13px]"><span className="font-medium text-tg-sub">Inventory · {ov.accounts} account{ov.accounts === 1 ? '' : 's'}</span><span className="text-tg-sub">{ov.bms} BM{ov.bms === 1 ? '' : 's'}</span></div>
        <div className="af-bar !h-2 gap-[2px] !bg-transparent">{([[ov.free, '#34C759'], [ov.assigned, 'rgb(var(--tg-acc))'], [ov.disabled, 'rgb(var(--tg-red))']] as [number, string][]).filter(x => Number(x[0]) > 0).map(([n, c], i) => <i key={i} className="rounded-[3px]" style={{ width: `${(Number(n) / tot) * 100}%`, background: c }} />)}{!(Number(ov.accounts) > 0) && <i className="w-full rounded-[3px] bg-tg-track" />}</div>
        <div className="mt-2.5 grid grid-cols-3 gap-2">
          <button onClick={() => go('accounts')} className="text-left"><p className="af-mid-num text-tg-ok">{ov.free}</p><p className="text-[12.5px] text-tg-sub">Free</p></button>
          <button onClick={() => go('accounts')} className="text-left"><p className="af-mid-num text-tg-link">{ov.assigned}</p><p className="text-[12.5px] text-tg-sub">With clients</p></button>
          <button onClick={() => go('accounts')} className="text-left"><p className={clsx('af-mid-num', ov.disabled ? 'text-tg-bad' : 'text-tg-sub')}>{ov.disabled}</p><p className="text-[12.5px] text-tg-sub">Disabled</p></button>
        </div>
        <p className="mt-2 text-[12px] leading-snug text-tg-sub">Free: <span className={ov.free_by.verified ? 'text-tg-link' : 'text-tg-bad'}>{ov.free_by.verified} verified</span> · {ov.free_by.review} in review · {ov.free_by.unverified} unverified</p>
      </div>
      <div className="af-card af-grid2 mb-1 overflow-hidden">
        <Stat bare k="Spend today" v={usd(ov.spend_today)} s="all accounts" />
        <Stat bare k="Client balance left" v={usd(ov.client_left)} s={ov.low.length ? `${ov.low.length} account${ov.low.length > 1 ? 's' : ''} low` : 'limit − spent'} tone={ov.low.length ? 'text-tg-orange' : ''} />
      </div>
      <SectionHead title={`Needs attention${attnN ? ` · ${attnN}` : ''}`} action={<span className="inline-flex items-center gap-1"><RefreshCw size={13} className={busy ? 'animate-spin' : ''} />{busy ? 'Syncing…' : 'Sync now'}</span>} onAction={() => { if (!busy) void sync(); }} />
      <Group tiles data-attn>
        {ov.blocked.map((b: any) => <Attn key={b.id} icon={b.status === 'banned' ? <Ban size={17} /> : <KeyRound size={17} />} tone="bg-tg-red/15 text-tg-bad" title={`${b.status === 'banned' ? 'Banned' : b.status === 'blocked' ? 'API blocked' : 'Error'} · ${b.name}${b.label ? ' (' + b.label + ')' : ''}`} sub={b.error || ''} onClick={() => openBm(b.id)} />)}
        {ov.requests > 0 && <Attn icon={<span className="text-[14px] font-bold">{ov.requests}</span>} tone="bg-tg-orange/15 text-tg-orange" title="Requests to approve" sub="Ad accounts and top-ups from agents" onClick={() => go('requests')} />}
        {payFailN > 0 && <Attn icon={<CreditCard size={17} />} tone="red" title={`Payment failed · ${payFailN}`} sub="Meta could not charge our card" onClick={() => go('accounts')} />}
        {ov.recent_disabled.map((a: any) => <Attn key={a.act_id} icon={<AlertTriangle size={17} />} tone="bg-tg-red/15 text-tg-bad" title={`${a.name} disabled`} sub={`${listTime(a.at)}${a.step === 'active_again' ? ' · active again now' : ''} · balance moved to client credit`} onClick={() => openAcct(a.act_id)} />)}
        {ov.cards_low.map((c: any) => <Attn key={c.card} icon={<CreditCard size={17} />} tone="bg-tg-orange/15 text-tg-orange" title={`Load ${c.card}`} sub={`About ${usd(c.load)} more needed for client balances`} onClick={() => go('cards')} />)}
        {ov.low.length > 0 && <Attn icon={<Zap size={16} />} tone="bg-tg-orange/15 text-tg-orange" title={`Low balance · ${ov.low.length} client${ov.low.length > 1 ? 's' : ''}`} sub={ov.low.slice(0, 3).map((l: any) => `${l.lead || l.name} ${usd(l.left)}`).join(' · ') + ' · agents were told'} onClick={() => go('accounts')} />}
        {ov.credits > 0 && <Attn icon={<Banknote size={16} />} tone="bg-tg-acc/20 text-tg-link" title={`Client credits ${usd(ov.credits)}`} sub="Added automatically to their next account" onClick={() => go('credits')} />}
        {!attnN && !(ov.credits > 0) && <Row icon={<IconTile icon={Check} color={TILE.green} />} title="All good" sub={ov.last_sync ? `Last sync ${listTime(ov.last_sync)}` : undefined} />}
      </Group>
      <SectionHead title="Tools" />
      <Group tiles>
        <Row onClick={() => go('bms')} icon={<IconTile icon={ShieldCheck} color={TILE.blue} />} title="Business managers" value={`${ov.bms}`} />
        {onManual && <Row onClick={onManual} icon={<IconTile icon={Send} color={TILE.teal} />} title="Share without a chat" sub="WhatsApp group, client not in the apps" />}
        {ov.can_toggle && <Row data-meta-rules onClick={() => setRules(true)} icon={<IconTile icon={MessageSquareText} color={TILE.purple} />} title="Client messages & rules" sub={`Sync every ${SYNC_L[String(st.sync_min ?? 360)] || (st.sync_min ?? 360) + ' min'} · low balance $${st.low_usd ?? 15} · messages ${st.msgs !== '0' ? 'on' : 'off'}`} />}
      </Group>
      {ov.can_toggle && <Sheet open={rules} onClose={() => setRules(false)} title="Client messages & rules" wide><MetaSettings api={api} st={ov.settings} saved={() => { reload(); setRules(false); }} /></Sheet>}
    </div>
  );
}

function MetaSettings({ api, st, saved }: { api: Api; st: any; saved: () => void }) {
  const toast = useToast();
  const [v, setV] = useState({ sync: String(st?.sync_min ?? 360), low: String(st?.low_usd ?? 15), pattern: st?.pattern || '{brand} Ad Account {n}', msgs: st?.msgs !== '0', email: !!st?.email_invites, share: st?.msg_share || '', invite: st?.msg_invite || '', invite_ok: st?.msg_invite_ok || '', topup: st?.msg_topup || '', low_msg: st?.msg_low || '', footer: st?.auto_footer ?? '', repl: st?.msg_replace || '', top_hand: st?.msg_topup_hand || '', top_req: st?.msg_topup_req || '' });
  const [busy, setBusy] = useState(false);
  async function save() {
    setBusy(true);
    try { await api('settings_save', { meta_sync_min: v.sync, meta_low_usd: v.low, meta_name_pattern: v.pattern, meta_client_msgs: v.msgs ? '1' : '0', meta_email_invites: v.email ? '1' : '0', meta_msg_share: v.share, meta_msg_invite: v.invite, meta_msg_invite_ok: v.invite_ok, meta_msg_topup: v.topup, meta_msg_low: v.low_msg, meta_auto_footer: v.footer, meta_msg_replace: v.repl, meta_msg_topup_hand: v.top_hand, meta_msg_topup_req: v.top_req }); toast('Saved'); saved(); }
    catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); }
  }
  return (
    <div data-meta-settings>
      <Field label="Old BMs (System User token): read every" hint="Only for BMs added with “Add BM (paste token)”. Profile BMs are read by Auto sync in Ad accounts → Profiles, through iProxy. Fewer reads = fewer API calls. Share, top-up and unshare always read the account fresh, and you can tap “Sync now” any time. Disabled accounts and low balance are noticed at the next read.">
        <select className={inputCls} value={v.sync} onChange={e => setV({ ...v, sync: e.target.value })}>
          {[['30', '30 minutes'], ['60', '1 hour'], ['180', '3 hours'], ['360', '6 hours'], ['720', '12 hours'], ['1440', '24 hours']].map(([k, l]) => <option key={k} value={k}>{l}</option>)}
        </select>
      </Field>
      <Field label="Low balance alert under ($)"><input className={inputCls} type="number" value={v.low} onChange={e => setV({ ...v, low: e.target.value })} /></Field>
      <Field label="Account name pattern" hint="{brand} = your brand name, {n} = account number"><input className={inputCls} value={v.pattern} onChange={e => setV({ ...v, pattern: e.target.value })} /></Field>
      <div className="mb-3 flex items-center justify-between rounded-xl bg-tg-input px-4 py-3"><span><span className="block">Email invites</span><span className="block text-[12.5px] text-tg-sub">OFF = only “client’s BM ID” is offered. ON = clients without a BM can be invited to our BM (only the manager sends these)</span></span><Toggle on={v.email} onChange={x => setV({ ...v, email: x })} /></div>
      <div className="mb-3 flex items-center justify-between rounded-xl bg-tg-input px-4 py-3"><span><span className="block">Message the client automatically</span><span className="block text-[12.5px] text-tg-sub">When an account is shared, an invite is accepted or a top-up is added</span></span><Toggle on={v.msgs} onChange={x => setV({ ...v, msgs: x })} /></div>
      {v.msgs && <>
        <p className="mb-2 text-[12.5px] text-tg-sub">Sent from your Telegram chat account. Use {'{act}'} {'{bm}'} {'{email}'} {'{amount}'} {'{balance}'} {'{verified}'} (BM verified-since date; the line is left out when the BM has none). Don’t write the account type here.</p>
        <Field label="Account shared (client BM)"><textarea className={inputCls} rows={4} value={v.share} onChange={e => setV({ ...v, share: e.target.value })} /></Field>
        <Field label="Email invite sent"><textarea className={inputCls} rows={4} value={v.invite} onChange={e => setV({ ...v, invite: e.target.value })} /></Field>
        <Field label="Invite accepted"><textarea className={inputCls} rows={2} value={v.invite_ok} onChange={e => setV({ ...v, invite_ok: e.target.value })} /></Field>
        <Field label="Top-up added"><textarea className={inputCls} rows={3} value={v.topup} onChange={e => setV({ ...v, topup: e.target.value })} /></Field>
        <Field label="Low balance (to the client)" hint="Sent at most once a day when the balance drops under the low-balance line above."><textarea className={inputCls} rows={3} value={v.low_msg} onChange={e => setV({ ...v, low_msg: e.target.value })} /></Field>
        <Field label="Replacement account (to the client)" hint="{act} new account · {bm} · {verified} · {balance}"><textarea className={inputCls} rows={4} value={v.repl} onChange={e => setV({ ...v, repl: e.target.value })} /></Field>
        <Field label="Top-up done by hand (account not in the system)" hint="{act} · {amount}"><textarea className={inputCls} rows={2} value={v.top_hand} onChange={e => setV({ ...v, top_hand: e.target.value })} /></Field>
        <Field label="Top-up request sent to the manager" hint="{act} · {amount} — when an agent (or the admin from a chat) asks for a top-up"><textarea className={inputCls} rows={3} value={v.top_req} onChange={e => setV({ ...v, top_req: e.target.value })} /></Field>
        <Field label="Line under every automatic message and channel post" hint="So the client knows it came from the system, not a reply we skipped. Empty = no line."><input className={inputCls} value={v.footer} onChange={e => setV({ ...v, footer: e.target.value })} /></Field>
      </>}
      <div className="sticky bottom-0 -mx-5 bg-tg-panel px-5 pb-1 pt-2"><Btn className="w-full" busy={busy} onClick={() => void save()}>Save</Btn></div>
    </div>
  );
}

/** v167: account row — avatar, name + client tag, one sub line, coloured balance bar, state lines (dot + text). */
function AcctRow({ a, onClick }: { a: Acct; onClick: () => void }) {
  const pct = a.cap > 0 ? Math.min(100, (a.spent / a.cap) * 100) : 0;
  const leftPct = a.cap > 0 ? (a.left / a.cap) * 100 : 100;
  const barC = leftPct <= 5 || a.left <= 0 ? 'rgb(var(--tg-red))' : a.left < 15 || leftPct < 25 ? '#E8902A' : '#34C759';
  const live = a.state === 'assigned' || a.state === 'invited';
  const name = a.name || `Account ${a.no}`;
  const lines: [string, React.ReactNode][] = [];
  if (a.status !== 1) lines.push(['bad', statusTxt(a)]);
  if (a.err) lines.push(['bad', <>Sync failed · {a.err}</>]);
  if ((a as any).post_wait) lines.push(['warn', 'Waiting for chat screenshot']);
  if (a.step === 'active_again') lines.push(['ok', 'Active again']);
  return (
    <button onClick={onClick} className="af-row !items-start !py-3" data-acct-row={a.act_id}>
      <span className="mt-0.5 grid h-10 w-10 shrink-0 place-items-center rounded-full text-[14px] font-semibold text-white" style={{ background: a.state === 'disabled' ? '#8E8E93' : a.state === 'free' ? 'linear-gradient(#7FD88A,#4CB860)' : 'linear-gradient(#72B5FF,#3E8EEB)' }}>{initials(name)}</span>
      <span className="min-w-0 flex-1">
        <span className="flex items-center gap-2"><span className="min-w-0 flex-1 truncate text-[15.5px] font-semibold">{name}</span>{a.lead ? <Tag tone="acc" className="max-w-[45%] truncate">{a.lead.name}</Tag> : <Chip m={STATE} k={a.state} />}</span>
        <span className="mt-px block truncate text-[12.5px] text-tg-sub"><span className="font-mono">act_{a.act_id}</span>{a.card ? ` · ${a.card}` : ''}{(a as any).profile ? ` · ${(a as any).profile}` : ''} · {(a as any).verified_since ? <span className="text-tg-ok">Verified</span> : <span className={a.tier === 'verified' ? 'text-tg-link' : a.tier === 'premium' ? 'text-tg-premium' : ''}>{TIER[a.tier]?.[0]}</span>}{a.share_mode === 'email' && a.lead ? ' · email invite' : ''}</span>
        {live && <>
          <span className="af-bar mt-2 !h-[5px]"><i style={{ width: pct + '%', background: barC }} /></span>
          <span className="mt-1 flex items-center justify-between text-[12.5px] af-num"><span className="text-tg-sub">{usd(a.spent)} of {usd(a.cap)} spent{a.today ? ` · ${usd(a.today)} today` : ''}</span><b className="font-semibold" style={{ color: barC }}>{usd(a.left)} left</b></span>
        </>}
        {a.pay_fail ? <span className="mt-1.5 block" data-pay-fail-tag><Tag tone="bad">{payFailTxt(a)}</Tag></span> : null}
        {lines.map(([t, l], i) => <span key={i} className={clsx('mt-1 flex items-center gap-1.5 text-[12.5px]', t === 'bad' ? 'text-tg-bad' : t === 'warn' ? 'text-tg-warn' : 'text-tg-ok')} data-acct-line={t}><span className="h-1.5 w-1.5 shrink-0 rounded-full bg-current" /><span className="truncate">{l}</span></span>)}
      </span>
    </button>
  );
}

function Accounts({ api, ver, onOpen }: { api: Api; ver: number; onOpen: (a: string) => void }) {
  const [rows, setRows] = useState<Acct[] | null>(null);
  const [f, setF] = useState('all'); const [q, setQ] = useState('');
  // v173 (owner): sync one BM right from its group in the list
  const toast = useToast(); const [syncing, setSyncing] = useState('');
  async function syncBm(bmId: string) {
    setSyncing(bmId);
    try { const r = await api<any>('meta/bm_sync', { bm_id: bmId }); if (r.queued) toast(`Sync in the queue · ~${r.job?.eta_min || 2} min (IP change first)`); else if (r.ok === false) toast(r.error || 'Sync failed', 'err'); else toast('Synced'); const x = await api<{ accounts: Acct[]; removed?: number }>('meta/accounts'); setRows(x.accounts); }
    catch (e) { toast((e as Error).message, 'err'); } finally { setSyncing(''); }
  }
  const [rmN, setRmN] = useState(0); const [rmRows, setRmRows] = useState<Acct[] | null>(null); // v170: removed from the system
  useEffect(() => { void (async () => { try { const r = await api<{ accounts: Acct[]; removed?: number }>('meta/accounts'); setRows(r.accounts); setRmN(r.removed || 0); } catch { /* ignore */ } })(); }, [api, ver]);
  useEffect(() => { if (f !== 'removed') return; void (async () => { try { setRmRows((await api<{ accounts: Acct[] }>('meta/accounts?state=removed')).accounts); } catch { setRmRows([]); } })(); }, [api, ver, f]);
  const issue = (a: Acct) => !!(a.err || a.pay_fail || (a as any).post_wait || (a.status !== 1 && a.state !== 'disabled'));
  const match = (a: Acct, s: string) => s === 'all' || (s === 'assigned' ? ['assigned', 'invited'].includes(a.state) : s === 'issues' ? issue(a) : s === 'payfail' ? !!a.pay_fail : a.state === s);
  const list = (f === 'removed' ? rmRows || [] : rows || []).filter(a => (f === 'removed' || match(a, f)) && (!q || `${a.name} ${a.act_id} ${a.lead?.name || ''} ${a.client_bm || ''} ${a.client_email || ''} ${a.bm_name || ''}`.toLowerCase().includes(q.toLowerCase())));
  const n = (s: string) => (rows || []).filter(a => match(a, s)).length;
  // group by BM
  const groups: { key: string; label: string; tier: string; rows: Acct[] }[] = [];
  for (const a of list) { let g = groups.find(x => x.key === a.bm_id); if (!g) { g = { key: a.bm_id, label: a.bm_name || a.bm_id, tier: (a as any).verified_since ? 'Verified' : TIER[a.tier]?.[0] || '', rows: [] }; groups.push(g); } g.rows.push(a); }
  const chips: [string, string, number?][] = [['all', 'All', n('all')], ['free', 'Free', n('free')], ['assigned', 'With clients', n('assigned')], ...(n('issues') ? [['issues', 'Issues', n('issues')] as [string, string, number]] : []), ...(n('payfail') ? [['payfail', 'Payment failed', n('payfail')] as [string, string, number]] : []), ['disabled', 'Disabled', n('disabled')], ...(rmN || f === 'removed' ? [['removed', 'Removed', rmN] as [string, string, number]] : [])];
  return (
    <div>
      <label className="mb-2.5 flex h-[38px] items-center gap-2 rounded-xl bg-tg-panel px-3 text-tg-faint shadow-[var(--tg-card-shadow)]"><Search size={16} className="shrink-0" /><input className="h-full min-w-0 flex-1 bg-transparent text-[15px] text-tg-text outline-none placeholder:text-tg-faint" placeholder="Name, act ID, client, BM" value={q} onChange={e => setQ(e.target.value)} /></label>
      <Chips className="-mx-4 mb-1 px-4" value={f} onChange={setF} items={chips} />
      {!rows || (f === 'removed' && !rmRows) ? <div className="pt-2"><Skeleton rows={3} h={68} /></div> : !list.length ? <div className="af-card mt-2 p-8 text-center text-tg-sub">No accounts here.</div> : groups.map(g => (
        <section key={g.key}>
          <SectionHead title={<span className="normal-case">{g.label}{g.tier ? ` · ${g.tier}` : ''}</span>} action={<span className="inline-flex items-center gap-2">{g.rows.length}{g.key !== 'hand' && <button type="button" aria-label={`Sync ${g.label}`} disabled={syncing === g.key} onClick={() => void syncBm(g.key)} className="af-press grid h-7 w-7 place-items-center rounded-full bg-tg-panel text-tg-link shadow-[var(--tg-card-shadow)] disabled:opacity-50" data-bm-sync><RefreshCw size={14} className={syncing === g.key ? 'animate-spin' : ''} /></button>}</span>} />
          <Group avs>{g.rows.map(a => <AcctRow key={a.act_id} a={a} onClick={() => onOpen(a.act_id)} />)}</Group>
        </section>
      ))}
    </div>
  );
}

const KV = ({ k, v }: { k: string; v: React.ReactNode }) => <div className="af-row !min-h-[44px] !py-2 text-[14.5px]"><span className="shrink-0 text-tg-sub">{k}</span><span className="min-w-0 flex-1 break-words text-right">{v}</span></div>;
/** v167: round quick action under the balance. */
const QuickBtn = ({ icon: I, label, onClick }: { icon: any; label: string; onClick: () => void }) => <button type="button" onClick={onClick} className="af-press flex w-[72px] flex-col items-center gap-1 text-[12.5px] font-medium text-tg-link"><span className="grid h-11 w-11 place-items-center rounded-full bg-tg-panel2"><I size={19} /></span>{label}</button>;

const VS = ({ v, tier }: { v?: string | null; tier: string }) => v ? <span className="rounded-full bg-tg-green/15 px-2.5 py-1 text-[12.5px] font-semibold text-tg-ok">Verified since {fmtVS(v)}</span> : <Chip m={TIER} k={tier} />;
const fmtVS = (d: string) => { const t = new Date(d + 'T00:00:00'); return isNaN(t.getTime()) ? d : t.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }); };
function AccountSheet({ api, act, onClose, changed }: { api: Api; act: string | null; onClose: () => void; changed: () => void }) {
  const toast = useToast();
  const [d, setD] = useState<{ account: Acct; log: any[]; credit: number } | null>(null);
  const [paid, setPaid] = useState(''); const [busy, setBusy] = useState(''); const [give, setGive] = useState(false); const [repl, setRepl] = useState(false); const [isAdm, setIsAdm] = useState(false); /* v173 QA: remove = admin only */ const [hand, setHand] = useState(''); const [sold, setSold] = useState(false); const [bm2, setBm2] = useState(''); const [sv, setSv] = useState({ name: '', bm: '' }); const [pct, setPct] = useState(3);
  const load = useCallback(async () => { if (!act) return; try { setD(await api('meta/account?act=' + act)); const o = await api<any>('meta/overview'); setPct(o.settings.topup_pct); setIsAdm(!!o.can_toggle); } catch (e) { toast((e as Error).message, 'err'); } }, [api, act, toast]);
  useEffect(() => { setD(null); setPaid(''); setHand(''); if (act) void load(); }, [act, load]);
  // v171: the open account refreshes itself too (a queued take-back / share finishes later)
  useEffect(() => { if (!act) return; const t = setInterval(() => { if (document.visibilityState === 'visible') void (async () => { try { setD(await api('meta/account?act=' + act)); } catch { /* next time */ } })(); }, 8000); return () => clearInterval(t); }, [act, api]);
  const a = d?.account;
  const [cutAmt, setCutAmt] = useState(''); // v161: take back a top-up
  const lastTop = d?.log?.find((l: any) => l.kind === 'topup' && l.amount > 0) as { amount: number; created_at: number; fee?: number | null } | undefined;
  async function takeBack(last: boolean) {
    if (!a || !lastTop) return;
    const amt = last ? lastTop.amount : Number(cutAmt) || 0;
    if (!(amt > 0)) { toast('Enter the amount to take back', 'err'); return; }
    if (amt > lastTop.amount + 0.004) { toast(`The last top-up was ${usd(lastTop.amount)}. You can take back at most that.`, 'err'); return; }
    if (!confirm(`Take back ${usd(amt)} from ${a.name || 'this account'}?\n\nThe spend limit on Meta goes down by ${usd(amt)} (never below what is already spent).\n${last || amt >= lastTop.amount - 0.004 ? 'The last top-up and its fee are removed from sales.' : `The last top-up becomes ${usd(lastTop.amount - amt)} in sales (fee goes down the same way).`}\nThe client gets no message.`)) return;
    const r = await call('meta/topup_cut', last ? { act_id: a.act_id, last: 1 } : { act_id: a.act_id, amount: amt }, `${usd(amt)} taken back`, 'cut');
    if (r !== false) setCutAmt('');
  }
  // v157: the amount typed goes on the account as it is; the fee comes on top
  const add = Number(paid) || 0; const fee = Math.round(add * pct) / 100; const payTotal = Math.round((add + fee) * 100) / 100;
  async function call(path: string, body: Record<string, unknown>, okMsg: string, key: string) {
    setBusy(key);
    try { const r = await api<any>(path, body); if (r.queued) toast(`In the queue · ~${r.job?.eta_min || 2} min (IP change first)`); else if (r.done === false) { toast(r.error || 'Could not do it', 'err'); return false; } else toast(okMsg); setPaid(''); setHand(''); await load(); changed(); return true; }
    catch (e) { toast((e as Error).message, 'err'); return false; } finally { setBusy(''); }
  }
  return (
    <Sheet open={!!act} onClose={onClose} title={a ? a.name || `Account ${a.no}` : 'Ad account'} wide>
      {!a ? <div className="p-3"><Skeleton rows={3} h={68} /></div> : <>
        {/* v167: tags · balance hero · quick actions · notices · grouped details */}
        <p className="-mt-2 mb-2 truncate text-[13px] text-tg-sub"><span className="font-mono">act_{a.act_id}</span> · {a.bm_name || a.bm_id}</p>
        <div className="mb-3 flex flex-wrap gap-1.5">{a.lead ? <Tag tone="acc">With {a.lead.name}</Tag> : <Chip m={STATE} k={a.state} />}{(a as any).cat && <Chip m={CAT} k={(a as any).cat} />}{(a as any).verified_since ? <Tag tone="ok">Verified {age(new Date((a as any).verified_since + 'T00:00:00').getTime())}</Tag> : <Chip m={TIER} k={a.tier} />}{a.status !== 1 && <Tag tone="bad">{statusTxt(a)}</Tag>}{a.pay_fail ? <Tag tone="bad">{payFailTxt(a)}</Tag> : null}{a.bm_status && a.bm_status !== 'ok' && <Chip m={BMSTATE} k={a.bm_status} />}</div>
        {(() => { const leftPct = a.cap > 0 ? (a.left / a.cap) * 100 : 100; const c = leftPct <= 5 || a.left <= 0 ? 'rgb(var(--tg-red))' : a.left < 15 || leftPct < 25 ? '#E8902A' : 'rgb(var(--tg-ok))'; return (
          <div className="mb-3 rounded-2xl bg-tg-panel2 px-4 pb-3.5 pt-3" data-balance>
            <div className="flex items-baseline justify-between text-[13px] text-tg-sub"><span className="font-medium">Balance left</span><span className="af-num">limit {usd(a.cap)}</span></div>
            <p className="mt-0.5 flex flex-wrap items-baseline gap-x-2"><span className="af-hero-num" style={{ color: c }}>{usd(a.left)}</span><span className="text-[13px] text-tg-sub af-num">{usd(a.spent)} spent · {usd(a.today)} today</span></p>
            <div className="af-bar mt-2.5"><i style={{ width: `${a.cap > 0 ? Math.min(100, (a.spent / a.cap) * 100) : 0}%`, background: c }} /></div>
          </div>
        ); })()}
        <div className="mb-3 flex justify-around gap-2" data-quick>
          {(a.state === 'assigned' || a.state === 'invited') && a.status === 1 && <QuickBtn icon={ArrowUp} label="Top up" onClick={() => document.querySelector('[data-topup-box]')?.scrollIntoView({ behavior: 'smooth', block: 'center' })} />}
          {a.state === 'assigned' && a.share_mode === 'bm' && a.status === 1 && <QuickBtn icon={Share2} label="Share" onClick={() => document.querySelector('[data-share-bm]')?.scrollIntoView({ behavior: 'smooth', block: 'center' })} />}
          {a.state === 'free' && <QuickBtn icon={Send} label="Give" onClick={() => setGive(true)} />}
          <QuickBtn icon={Copy} label="Copy ID" onClick={() => copyT('act_' + a.act_id, toast)} />
        </div>
        {a.pay_fail ? (
          <div className="af-note bad mb-3 !block" data-pay-fail>
            <p className="flex items-center gap-2 font-semibold text-tg-bad"><CreditCard size={16} />Payment failed{a.pay_due != null && Number(a.pay_due) > 0 ? ` · ${usd(a.pay_due)} due` : ''}</p>
            <p className="mt-1 text-[13px] text-tg-sub">Card {a.card || '—'}{a.pay_fail_at ? ` · since ${new Date(a.pay_fail_at).toLocaleString(undefined, { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' })}` : ''}{a.status_text ? ` · ${a.status_text}` : ''}</p>
          </div>
        ) : null}
        {a.err && <div className="af-note bad mb-3"><AlertTriangle size={17} className="mt-0.5 shrink-0 text-tg-bad" /><span className="min-w-0"><b className="block font-semibold text-tg-bad">Last sync failed</b><span className="text-[13px] text-tg-sub">{a.err}{a.synced_at ? ` · ${listTime(a.synced_at)}` : ''}</span></span></div>}
        {a.lead || (a.share_mode && a.state !== 'free') ? <>
          <SectionHead title="Client" className="!mt-1" />
          <div className="af-group mb-1 !bg-tg-panel2">
            {a.lead && <KV k="Client" v={`${a.lead.name}${a.lead.agent ? ' · ' + a.lead.agent : ''}`} />}
            {a.share_mode && a.state !== 'free' && (a.share_mode === 'email' ? a.client_email : a.client_bm) && <KV k={a.share_mode === 'email' ? 'Invited email' : 'Shared to BM'} v={a.share_mode === 'email' ? `${a.client_email}${a.state === 'invited' ? ' (not accepted yet)' : ''}` : <button className="font-mono af-num" onClick={() => copyT(String(a.client_bm), toast)}>{String(a.client_bm).replace(/(\d{4})(?=\d)/g, '$1 ')} <Copy size={12} className="inline text-tg-link" /></button>} />}
            {((a as any).extra_bms || []).length > 0 && <KV k="Also shared" v={((a as any).extra_bms as string[]).map(x => 'BM ' + x).join(', ')} />}
            {(a as any).partner_name && <KV k="Partner" v={(a as any).partner_name} />}
          </div>
        </> : null}
        <SectionHead title="Account" />
        <div className="af-group !bg-tg-panel2">
          <KV k="Ad account ID" v={<button className="text-tg-link" onClick={() => copyT('act_' + a.act_id, toast)}>act_{a.act_id} <Copy size={12} className="inline" /></button>} />
          <KV k="BM" v={`${a.bm_name || ''} · ${a.bm_id}`} />
          {a.created_time ? <KV k="Account age" v={age(a.created_time)} /> : null}
          {(a as any).verified_since && <KV k="BM verified since" v={`${fmtVS((a as any).verified_since)} · ${age(new Date((a as any).verified_since + 'T00:00:00').getTime())}`} />}
          <KV k="Card" v={<CardPick api={api} a={a as any} done={() => void load()} />} />
          {(a as any).profile && <KV k="Profile" v={(a as any).profile} />}
          {a.status !== 1 && <KV k="Status" v={<span className="text-tg-bad">{statusTxt(a)}</span>} />}
          {(a as any).dsl != null && <KV k="Daily limit (Meta)" v={usd((a as any).dsl)} />}
          {a.synced_at && <KV k="Read from Meta" v={listTime(a.synced_at)} />}
        </div>
        {((a as any).post_wait || (a as any).post_sending) && <ShotBox api={api} act={a.act_id} sending={!!(a as any).post_sending} done={() => { void load(); changed(); }} />}

        {a.state === 'free' && <Btn className="mt-4 w-full" onClick={() => setGive(true)}>Give to client</Btn>}
        {a.state === 'free' && <Btn kind="ghost" className="mt-2 w-full" onClick={() => setRepl(true)} data-give-repl>Give as replacement</Btn>}
        {a.state === 'free' && <Btn kind="ghost" className="mt-2 w-full" onClick={() => { setSv({ name: '', bm: '' }); setSold(true); }}>Already sold (before this system)</Btn>}
        <ReplaceGiveSheet api={api} open={repl} a={a} onClose={() => setRepl(false)} done={() => { setRepl(false); void load(); changed(); }} />
        <Sheet open={sold} onClose={() => setSold(false)} title="Already sold">
          <p className="mb-3 text-[13px] leading-relaxed text-tg-sub">For an account you shared by hand before this system. It is only saved here as this client’s account: nothing is sent to Meta, no message to the client, no channel post. Take back and top-ups work as usual after this.</p>
          <Field label="Client name"><input className={inputCls} value={sv.name} onChange={e => setSv({ ...sv, name: e.target.value })} placeholder="Zenn" /></Field>
          <Field label="Client BM ID"><input className={inputCls} inputMode="numeric" value={sv.bm} onChange={e => setSv({ ...sv, bm: e.target.value })} placeholder="Business Manager ID" /></Field>
          <Btn className="w-full" busy={busy === 'sb'} onClick={() => { void call('meta/manual', { act_id: a.act_id, kind: 'sold_before', client_name: sv.name, client_bm: sv.bm }, 'Saved as sold', 'sb').then(ok => { if (ok) setSold(false); }); }}>Save as sold</Btn>
        </Sheet>

        {a.state === 'assigned' && a.share_mode === 'bm' && !(a as any).partner_name && <Btn className="mt-4 w-full" busy={busy === 'fin'} onClick={() => void call('meta/finish', { act_id: a.act_id }, 'Done', 'fin')}>Finish setup: check partner, name, proof</Btn>}
        {a.state === 'assigned' && a.share_mode === 'bm' && a.status === 1 && <>
          <h4 data-share-bm className="af-h2 !mt-5"><span>Share to another BM of this client</span></h4>
          <div className="flex gap-2"><input className={inputCls} inputMode="numeric" placeholder="Client’s other BM ID" value={bm2} onChange={e => setBm2(e.target.value)} /><Btn kind="ghost" busy={busy === 'bm2'} onClick={() => { if (confirm(`Share ${a.name || 'this account'} also to BM ${bm2}? Same account, same limit.`)) void call('meta/add_bm', { act_id: a.act_id, client_bm: bm2 }, 'Shared', 'bm2').then(() => setBm2('')); }}>Share</Btn></div>
          <p className="mt-1 text-[12px] text-tg-sub">Take back removes the access from every BM.</p>
        </>}
        {(a.state === 'assigned' || a.state === 'invited') && a.status === 1 && <>
          <h4 data-topup-box className="af-h2 !mt-5"><span>Top-up</span></h4>
          <Field label="Top-up amount (USD) — goes on the account as it is"><input className={inputCls} type="number" inputMode="decimal" placeholder="e.g. 200" value={paid} onChange={e => setPaid(e.target.value)} /></Field>
          <div className="mb-3 space-y-1 rounded-xl bg-tg-input px-4 py-3 text-[14px]">
            <div className="flex justify-between"><span className="text-tg-sub">Added to limit</span><b>{usd(add)}</b></div>
            <div className="flex justify-between"><span className="text-tg-sub">Fee {pct}% (on top)</span><span>+ {usd(fee)}</span></div>
            <div className="flex justify-between"><span className="text-tg-sub">Client pays</span><b>{usd(payTotal)}</b></div>
            <div className="flex justify-between"><span className="text-tg-sub">Balance after</span><b className="text-tg-ok">{usd(a.left + add)}</b></div>
          </div>
          <Btn kind="green" className="w-full" busy={busy === 'top'} disabled={!(add > 0)} onClick={() => void call('meta/topup', { act_id: a.act_id, amount: add }, `${usd(add)} added`, 'top')}>Add top-up</Btn>
          <button className="mt-2 w-full text-center text-[13px] text-tg-link disabled:opacity-50" disabled={busy === 'timg'} onClick={() => void call('meta/topup_img', { act_id: a.act_id }, 'Top-up image sent (client chat + Saved Messages)', 'timg')}>{busy === 'timg' ? 'Making the image…' : 'Send the last top-up image again'}</button>
          {lastTop && <div className="mt-4 rounded-xl border border-tg-line px-3.5 py-3" data-topup-cut>
            <p className="text-[14px] font-semibold">Take back a top-up</p>
            <p className="mb-2.5 text-[12.5px] leading-relaxed text-tg-sub">Done by mistake? Last top-up: <b className="text-tg-text">{usd(lastTop.amount)}</b> · {new Date(lastTop.created_at).toLocaleString(undefined, { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' })}. The Meta limit goes down and sales are fixed. No message to the client.</p>
            <Btn kind="danger" className="w-full" busy={busy === 'cut'} onClick={() => void takeBack(true)}>Remove last top-up · {usd(lastTop.amount)}</Btn>
            <div className="mt-2.5 flex gap-2">
              <input className={clsx(inputCls, '!mb-0 flex-1')} type="number" inputMode="decimal" placeholder="Or type an amount" value={cutAmt} onChange={e => setCutAmt(e.target.value)} />
              <Btn kind="ghost" className="shrink-0" busy={busy === 'cut'} disabled={!(Number(cutAmt) > 0)} onClick={() => void takeBack(false)}>Take back</Btn>
            </div>
          </div>}
        </>}

        {!(a as any).removed_at && (a.lead || a.state === 'assigned' || a.state === 'invited') && <>
          <h4 className="af-h2 !mt-5"><span>Remove client</span></h4>
          <p className="mb-2 text-[13px] leading-relaxed text-tg-sub">1 Remove access ({a.share_mode === 'email' ? 'from our BM' : 'from their BM'}) → 2 delete the client’s campaigns → {a.state === 'disabled' ? '' : `3 save ${usd(a.left)} left as their credit → `}4 reset limit + $0.10 lock → 5 name back. No message goes to the client.{a.step && a.step !== 'active_again' ? ` Stopped at “${a.step}” last time; it continues from there.` : ''}</p>
          <Btn kind="danger" className="w-full" busy={busy === 'un'} onClick={() => { if (confirm(`Take ${a.name || 'this account'} back from ${a.lead?.name || 'the client'}? This can't be undone.`)) void call('meta/unshare', { act_id: a.act_id }, 'Account is free again', 'un'); }}>Take back access</Btn>
          <Btn kind="ghost" className="mt-2 w-full" busy={busy === 'pf'} onClick={() => void call('meta/proof_again', { act_id: a.act_id }, 'Proof images queued', 'pf')}>Send proof images again</Btn>
        </>}

        {a.state === 'free' && a.step === 'check' && <p className="mt-4 rounded-xl bg-tg-orange/15 px-3 py-2 text-[13px] text-tg-orange">A share stopped half way on this account, so it is kept out of stock. Check it in Ads Manager (partners, spending limit), then tap Mark free below.</p>}
        {!(a as any).removed_at && <details className="mt-5 rounded-xl bg-tg-input/50 px-3.5 py-2.5" open={a.state === 'free' && a.step === 'check'}>
          <summary className="cursor-pointer text-[14px] font-semibold">API not working? Done by hand</summary>
          <p className="mt-2 text-[12.5px] leading-relaxed text-tg-sub">If Meta blocked this BM’s API, do it in Ads Manager yourself, then save it here so the records stay right.</p>
          {(a.state === 'assigned' || a.state === 'invited') && <div className="mt-2 flex gap-2"><input className={inputCls} type="number" placeholder="Amount added ($)" value={hand} onChange={e => setHand(e.target.value)} /><Btn kind="ghost" busy={busy === 'h1'} onClick={() => void call('meta/manual', { act_id: a.act_id, kind: 'topup', amount: hand }, 'Saved', 'h1')}>Saved top-up</Btn></div>}
          {(a.state !== 'free' || a.step === 'check') && <Btn kind="ghost" className="mt-2 w-full" busy={busy === 'h2'} onClick={() => { if (confirm('Mark free? Do this only after you removed the client’s access, deleted campaigns and reset the spend in Ads Manager.')) void call('meta/manual', { act_id: a.act_id, kind: 'free' }, 'Marked free', 'h2'); }}>Mark free (done by hand)</Btn>}
        </details>}
        {a.state === 'free' && <Btn kind="ghost" className="mt-2 w-full" busy={busy === 'rn'} onClick={() => void call('meta/rename', { act_id: a.act_id }, 'Renamed', 'rn')}>Rename to pattern</Btn>}

        {/* v170 (owner): take just this account out of the system, or bring it back */}
        {!isAdm ? null : (a as any).removed_at ? <>
          <div className="af-note mt-5 !block" data-removed><p className="font-semibold">Removed from the system</p><p className="mt-1 text-[13px] text-tg-sub">Since {new Date((a as any).removed_at).toLocaleString(undefined, { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' })}. It is out of the lists, stock and alerts. Nothing was changed on Meta.</p></div>
          <Btn kind="ghost" className="mt-2 w-full" busy={busy === 'rs'} onClick={() => void call('meta/acct_restore', { act_id: a.act_id }, 'Back in the system', 'rs').then(r => { if (r !== false) changed(); })}><RotateCcw size={15} className="mr-1.5 inline" />Bring back to the system</Btn>
        </> : <Btn kind="ghost" className="mt-5 w-full !text-tg-bad" busy={busy === 'rm'} data-acct-remove onClick={() => { if (confirm(`Remove ${a.name || 'this account'} from the system?\n\nIt leaves the lists, stock and alerts, and sync won't bring it back. Nothing changes on Meta${a.lead ? `: ${a.lead.name} keeps access and no credit is saved (use Take back access first if you want that)` : ''}. Its history stays. You can bring it back from Ad accounts → Removed.`)) void call('meta/acct_remove', { act_id: a.act_id }, 'Removed from the system', 'rm').then(r => { if (r !== false) { changed(); onClose(); } }); }}><Trash2 size={15} className="mr-1.5 inline" />Remove from system</Btn>}

        {d!.log.length > 0 && <>
          <h4 className="af-h2 !mt-5"><span>History</span></h4>
          {d!.log.map((l: any) => <div key={l.id} className="border-b border-tg-line py-2 text-[13px]"><b className="capitalize">{l.kind.replace('_', ' ')}</b>{l.amount ? ` · ${usd(l.amount)}` : ''}{l.fee ? ` (fee ${usd(l.fee)})` : ''} <span className="text-tg-sub">· {l.note || ''} · {listTime(l.created_at)}</span></div>)}
        </>}
        <GiveSheet api={api} open={give} preset={{ act: a.act_id }} onClose={() => setGive(false)} changed={() => { void load(); changed(); }} />
      </>}
    </Sheet>
  );
}

/** v173 (owner): give THIS free account to a client as a replacement (no sale, no commission; replacement record + client message). */
function ReplaceGiveSheet({ api, open, a, onClose, done }: { api: Api; open: boolean; a: Acct; onClose: () => void; done: () => void }) {
  const toast = useToast();
  const [lead, setLead] = useState<{ id: number; name: string; credit?: number } | null>(null);
  const [olds, setOlds] = useState<Acct[]>([]); const [old, setOld] = useState(''); const [oldTyped, setOldTyped] = useState('');
  const [bm, setBm] = useState(''); const [hand, setHand] = useState(false); const [note, setNote] = useState(''); const [busy, setBusy] = useState(false);
  const ok = useOpenKey(open);
  useEffect(() => { if (ok) { setLead(null); setOlds([]); setOld(''); setOldTyped(''); setBm(''); setHand(false); setNote(''); } }, [ok]);
  useEffect(() => { setOlds([]); setOld(''); if (!lead) return; void (async () => { try { const r = (await api<{ accounts: Acct[] }>('meta/accounts?lead=' + lead.id)).accounts.filter(x => x.act_id !== a.act_id); setOlds(r); const o = r.find(x => x.state === 'disabled' || x.status !== 1) || r[0]; if (o) { setOld(o.act_id); if (o.client_bm) setBm(o.client_bm); } else setOld('none'); } catch { setOld('none'); } })(); }, [api, lead, a.act_id]);
  async function go() {
    if (!lead) { toast('Choose the client', 'err'); return; }
    setBusy(true);
    try {
      const r = await api<any>('meta/replace_give', { lead_id: lead.id, new_act: a.act_id, old_act: old === 'other' ? oldTyped : old === 'none' ? '' : old, client_bm: bm, hand, note });
      if (r.queued) toast(`In the queue · ~${r.job?.eta_min || 2} min (IP change first)`); else if (r.done === false) { toast(r.error || 'Could not do it', 'err'); return; } else toast(`Replaced: ${r.name || a.name || 'account'}`);
      done();
    } catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); }
  }
  return (
    <Sheet open={open} onClose={onClose} title="Give as replacement">
      <p className="mb-3 text-[13px] text-tg-sub">{a.name || 'Account ' + a.no} · act_{a.act_id} goes to the client as a replacement. No sale, no commission: records keep only our account cost.</p>
      <Field label="Client"><LeadPicker api={api} value={lead} onChange={setLead} /></Field>
      {lead && <>
        <Field label="Old account (optional)"><select className={inputCls} value={old} onChange={e => { setOld(e.target.value); const o = olds.find(x => x.act_id === e.target.value); if (o?.client_bm) setBm(o.client_bm); }}>
          {olds.map(x => <option key={x.act_id} value={x.act_id}>{x.name || 'Account ' + x.no} · act_{x.act_id}{x.status !== 1 ? ' · ' + x.status_label : ''}</option>)}
          <option value="other">Not in the system (type the ID)</option><option value="none">Skip (don’t know it)</option></select></Field>
        {old === 'other' && <Field label="Old ad account ID (optional)"><input className={inputCls} inputMode="numeric" placeholder="act_… or the number" value={oldTyped} onChange={e => setOldTyped(e.target.value)} /></Field>}
        <Field label="Client’s Business Manager ID" hint="Filled from the old account. Change it if the client wants the new one on another BM."><input className={inputCls} inputMode="numeric" value={bm} onChange={e => setBm(e.target.value)} data-repl-bm /></Field>
        <label className="mb-3 flex items-center gap-2.5 text-[14px]"><input type="checkbox" className="h-4 w-4" checked={hand} onChange={e => setHand(e.target.checked)} />I already shared it in Meta by hand</label>
        <Field label="What happened (optional)"><input className={inputCls} placeholder="e.g. disabled by Meta" value={note} onChange={e => setNote(e.target.value)} /></Field>
        <p className="mb-3 rounded-xl bg-tg-input px-3.5 py-2.5 text-[12.5px] leading-relaxed text-tg-sub">{hand ? 'Nothing is shared again: it is saved to this client, ' : 'The system shares it to the BM above, then '}the client gets “Your account has been successfully replaced” with the account. If the old account is this client’s in our system, its balance comes over as credit.</p>
      </>}
      <Btn className="w-full" busy={busy} onClick={() => void go()}>Give as replacement</Btn>
    </Sheet>
  );
}

/** v175 (owner): an account / top-up given by hand outside our BMs: upload the Meta screenshots → the system reads the IDs,
 *  records it, sends the client the screenshots + message, and makes the channel post / story (IDs blurred). Admin + manager. */
async function shrinkJpeg(f: File): Promise<string> {
  const url = URL.createObjectURL(f);
  try {
    const img = await new Promise<HTMLImageElement>((ok, bad) => { const i = new Image(); i.onload = () => ok(i); i.onerror = () => bad(new Error('This file is not an image')); i.src = url; });
    const k = Math.min(1, 2200 / Math.max(img.naturalWidth, img.naturalHeight));
    const c = document.createElement('canvas'); c.width = Math.round(img.naturalWidth * k); c.height = Math.round(img.naturalHeight * k);
    c.getContext('2d')!.drawImage(img, 0, 0, c.width, c.height);
    return c.toDataURL('image/jpeg', 0.92);
  } finally { URL.revokeObjectURL(url); }
}
function HandBox({ api, leadId, mine, done }: { api: Api; leadId: number; mine: Acct[]; done: () => void }) {
  const toast = useToast();
  const [hk, setHk] = useState<'account' | 'topup'>('account');
  const [shots, setShots] = useState<string[]>([]); const [busy, setBusy] = useState('');
  const [act, setAct] = useState(''); const [bm, setBm] = useState(''); const [tier, setTier] = useState('std'); const [bal, setBal] = useState('');
  const [sale, setSale] = useState(true); const [price, setPrice] = useState(''); const [amt, setAmt] = useState(''); const [post, setPost] = useState(true);
  const [found, setFound] = useState<{ amounts: number[] } | null>(null);
  const inp = useRef<HTMLInputElement>(null);
  useEffect(() => { if (hk === 'topup' && !act && mine[0]) setAct(mine[0].act_id); }, [hk, act, mine]);
  async function add(fs: FileList | null) {
    if (!fs) return;
    try { const out = [...shots]; for (const f of Array.from(fs).slice(0, 4 - out.length)) out.push(await shrinkJpeg(f)); setShots(out); setFound(null);
      if (out.length) { setBusy('scan'); try { const r = await api<any>('meta_hand_scan', { shots: out }); if (r.act && !act) setAct(r.act); if (r.bm && !bm && hk === 'account') setBm(r.bm); setFound({ amounts: r.amounts || [] }); } catch { /* fill by hand */ } finally { setBusy(''); } } }
    catch (e) { toast((e as Error).message, 'err'); }
  }
  async function go() {
    if (!shots.length) { toast('Add the screenshot(s)', 'err'); return; }
    if (!confirm(hk === 'account' ? `Deliver act_${act} to this client by hand? The client gets the screenshots + the "ready" message${sale ? ', the sale is recorded' : ''}${Number(bal) > 0 ? `, a $${bal} top-up is recorded (fee on top)` : ''}${post ? ' and the channel post / story are made' : ''}.` : `Top-up ${amt ? '$' + amt : ''} on act_${act} by hand? The client gets the screenshot + "Top-up done".`)) return;
    setBusy('go');
    try {
      const r = await api<any>('meta_hand', hk === 'account' ? { lead_id: leadId, kind: 'account', shots, act_id: act, client_bm: bm, tier, balance: Number(bal) || 0, sale, price: Number(price) || 0, post }
        : { lead_id: leadId, kind: 'topup', shots, act_id: act, amount: Number(amt) || 0 });
      toast(hk === 'account' ? `Delivered${r.post?.client ? ` · Client #${r.post.client} posted` : ''}` : `Top-up saved · fee $${Number(r.fee || 0).toFixed(2)}`);
      setShots([]); setAct(''); setBm(''); setBal(''); setPrice(''); setAmt(''); setFound(null); done();
    } catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(''); }
  }
  return (
    <div data-hand-box>
      <p className="mb-3 rounded-xl bg-tg-input px-3.5 py-2.5 text-[12.5px] leading-relaxed text-tg-sub">For an account / top-up you gave by hand (not in our BMs). Upload the Meta screenshots: the system reads the IDs, the client gets the screenshots + message, and the channel post / story are made with the IDs blurred.</p>
      <div className="mb-3"><Seg value={hk} onChange={v => { setHk(v as 'account' | 'topup'); setAct(''); setFound(null); }} items={[['account', 'New account'], ['topup', 'Top-up']]} /></div>
      <Field label={`Screenshots (${shots.length}/4)`} hint={hk === 'account' ? 'e.g. partner assigned, billing / limit, the account page.' : 'The top-up (spending limit) screenshot.'}>
        <div className="flex flex-wrap gap-2">
          {shots.map((u, i) => <div key={i} className="relative"><img src={u} alt="" className="h-20 w-20 rounded-lg object-cover" /><button type="button" aria-label="Remove" className="absolute -right-1.5 -top-1.5 grid h-6 w-6 place-items-center rounded-full bg-black/70 text-[13px] text-white" onClick={() => setShots(shots.filter((_, j) => j !== i))}>×</button></div>)}
          {shots.length < 4 && <button type="button" className="grid h-20 w-20 place-items-center rounded-lg border-2 border-dashed border-tg-line text-[28px] text-tg-sub" onClick={() => inp.current?.click()} data-hand-add>+</button>}
        </div>
        <input ref={inp} type="file" accept="image/*" multiple className="hidden" onChange={e => { void add(e.target.files); e.target.value = ''; }} />
        {busy === 'scan' && <p className="mt-1.5 text-[12.5px] text-tg-sub">Reading the screenshots…</p>}
      </Field>
      {hk === 'topup' && mine.length > 0 ? <Field label="Ad account"><select className={inputCls} value={act} onChange={e => setAct(e.target.value)}>{mine.map(a => <option key={a.act_id} value={a.act_id}>{a.name || 'Account ' + a.no} · act_{a.act_id}</option>)}<option value="">Other (type the ID)</option></select></Field> : null}
      {(hk === 'account' || !mine.length || !mine.some(a => a.act_id === act)) && <Field label="Ad account ID" hint="Read from the screenshots; check it."><input className={inputCls} inputMode="numeric" placeholder="act_… or the number" value={act} onChange={e => setAct(e.target.value)} data-hand-act /></Field>}
      {hk === 'account' ? <>
        <Field label="Client’s Business Manager ID (optional)"><input className={inputCls} inputMode="numeric" value={bm} onChange={e => setBm(e.target.value)} /></Field>
        <Field label="Account type"><Seg value={tier} onChange={setTier} items={[['std', '$25'], ['premium', 'Premium']]} /></Field>
        <Field label="Top-up with the account (USD)" hint={`${found?.amounts.length ? `Seen in the screenshots: ${found.amounts.map(x => '$' + x).join(', ')}. ` : ''}Recorded as a top-up (fee on top) and goes into tonight's top-up post. 0 = none. The 3rd screenshot is used as its image.`}><input className={inputCls} type="number" inputMode="decimal" placeholder="0" value={bal} onChange={e => setBal(e.target.value)} /></Field>
        <label className="mb-2 flex items-center gap-2.5 text-[14px]"><input type="checkbox" className="h-4 w-4" checked={sale} onChange={e => setSale(e.target.checked)} />Record the sale now (untick if you already tapped Mark sold)</label>
        {sale && <Field label="Client paid for the account (USD)"><input className={inputCls} type="number" inputMode="decimal" value={price} onChange={e => setPrice(e.target.value)} /></Field>}
        <label className="mb-3 flex items-center gap-2.5 text-[14px]"><input type="checkbox" className="h-4 w-4" checked={post} onChange={e => setPost(e.target.checked)} />Channel post + story (IDs blurred)</label>
      </> : <Field label="Top-up amount (USD added to the account)" hint={found?.amounts.length ? `Seen in the screenshot: ${found.amounts.map(x => '$' + x).join(', ')}. The fee comes on top.` : 'The fee comes on top.'}><input className={inputCls} type="number" inputMode="decimal" value={amt} onChange={e => setAmt(e.target.value)} /></Field>}
      <Btn className="w-full !min-h-[44px] !bg-[#3390EC] !text-white" busy={busy === 'go'} disabled={busy === 'scan'} onClick={() => void go()} data-hand-go>{hk === 'account' ? 'Deliver to the client' : 'Save top-up · tell the client'}</Btn>
    </div>
  );
}

/** Pick a client chat */
function LeadPicker({ api, value, onChange }: { api: Api; value: { id: number; name: string; credit?: number } | null; onChange: (l: { id: number; name: string; credit?: number } | null) => void }) {
  const [q, setQ] = useState(''); const [rows, setRows] = useState<any[]>([]); const [ch, setCh] = useState('');
  useEffect(() => { if (value) return; const t = setTimeout(async () => { try { setRows((await api<{ leads: any[] }>('meta/leads?q=' + encodeURIComponent(q) + '&ch=' + ch)).leads); } catch { /* ignore */ } }, 250); return () => clearTimeout(t); }, [api, q, ch, value]);
  if (value) return <div className="mb-3 flex items-center gap-2 rounded-xl bg-tg-input px-3.5 py-3"><b className="flex-1">{value.name}</b>{!!value.credit && <span className="text-[13px] text-tg-orange">credit {usd(value.credit)}</span>}<button className="text-[13px] text-tg-link" onClick={() => onChange(null)}>Change</button></div>;
  return (
    <div className="mb-3">
      <div className="mb-2"><Seg value={ch} onChange={setCh} items={[['', 'All'], ['tg', 'Telegram'], ['wa', 'WhatsApp']]} /></div>
      <input className={inputCls} placeholder="Search name, @username, phone, #id" value={q} onChange={e => setQ(e.target.value)} />
      <div className="mt-1 max-h-[220px] overflow-y-auto">{rows.length === 0 ? <div className="px-1 py-3 text-[13px] text-tg-sub">No chats found.</div> : rows.map(l => (
        <button key={l.id} onClick={() => onChange(l)} className="flex w-full items-center gap-2 border-b border-tg-line px-1 py-2.5 text-left text-[14px]">
          <span className={clsx('shrink-0 rounded-md px-1.5 py-0.5 text-[10.5px] font-bold', l.ch === 'wa' ? 'bg-[#25D366]/15 text-[#25D366]' : 'bg-[#2AABEE]/15 text-[#2AABEE]')}>{l.ch === 'wa' ? 'WhatsApp' : 'Telegram'}</span>
          <span className="min-w-0 flex-1 truncate">{l.name} <span className="text-tg-sub">#{l.id}{l.agent ? ' · ' + l.agent : ''}</span></span>
          {!!l.credit && <span className="text-[12px] text-tg-orange">credit {usd(l.credit)}</span>}
          {l.last_at && <span className="shrink-0 text-[11.5px] text-tg-sub">{listTime(l.last_at)}</span>}
        </button>))}</div>
    </div>
  );
}

function GiveSheet({ api, open, preset, onClose, changed }: { api: Api; open: boolean; preset: { act?: string; lead?: { id: number; name: string } | null } | null; onClose: () => void; changed: () => void }) {
  const toast = useToast();
  const [lead, setLead] = useState<{ id: number; name: string; credit?: number } | null>(null);
  const [mode, setMode] = useState<'bm' | 'email'>('bm'); const [bm, setBm] = useState(''); const [email, setEmail] = useState('');
  const [tier, setTier] = useState('any'); const [act, setAct] = useState(''); const [free, setFree] = useState<Acct[]>([]); const [busy, setBusy] = useState(false); const [biz, setBiz] = useState('');
  const ok1 = useOpenKey(open);
  const [topPaid, setTopPaid] = useState(''); const [noChat, setNoChat] = useState(false); const [cname, setCname] = useState('');
  const [PCT, setPct] = useState(3); const [hand, setHandMode] = useState(true);
  useEffect(() => { if (ok1) void api<any>('meta/overview').then(o => { setPct(Number(o.settings?.topup_pct) || 3); setHandMode(o.settings?.partner_hand !== false); }).catch(() => {}); }, [ok1, api]);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => { if (!ok1) return; setBiz(''); setTopPaid(''); setNoChat(false); setCname(''); setLead(preset?.lead ? { ...preset.lead } : null); setMode('bm'); setBm(''); setEmail(''); setTier('any'); setAct(preset?.act || ''); }, [ok1]);
  useEffect(() => { if (!open || preset?.act) return; void (async () => { try { setFree((await api<{ accounts: Acct[] }>('meta/free?tier=' + tier)).accounts); } catch { /* ignore */ } })(); }, [api, open, tier, preset]);
  useEffect(() => { if (open && lead && lead.credit === undefined) void (async () => { try { const r = await api<{ leads: any[] }>('meta/leads?q=' + lead.id); const m = r.leads.find(x => x.id === lead.id); if (m) setLead(m); } catch { /* ignore */ } })(); }, [api, open, lead]);
  async function go() {
    if (!lead && !(noChat && cname.trim())) { toast(noChat ? 'Enter the client’s name' : 'Choose the chat, or tap “No chat in the app”', 'err'); return; }
    setBusy(true);
    try {
      const r = !lead ? await api<any>('meta/manual_share', { client_name: cname.trim(), act_id: act || undefined, tier, client_bm: bm, biz_name: biz, topup_amount: Number(topPaid) || undefined, method: 'manual' }) : await api<any>('meta/share', { lead_id: lead.id, act_id: act || undefined, tier, mode: EMAIL_ON ? mode : 'bm', client_bm: bm, client_email: email, biz_name: biz, topup_amount: Number(topPaid) || undefined });
      if (r.queued) { toast(`In the queue · ~${r.job?.eta_min || 2} min (IP change first)`); changed(); onClose(); }
      else if (r.done) { toast(r.invited ? 'Invite sent. Access is given when they accept.' : `Shared: ${r.name}`); changed(); onClose(); }
      else toast(r.error || 'Could not share', 'err');
    } catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); }
  }
  return (
    <Sheet open={open} onClose={onClose} title="Give ad account to client">
      <Field label="Client">
        <div className="mb-2"><Seg value={noChat ? 'no' : 'chat'} onChange={v => setNoChat(v === 'no')} items={[['chat', 'Chat in the app'], ['no', 'No chat in the app']]} /></div>
        {noChat ? <input className={inputCls} placeholder="Client name (sold on WhatsApp group, call…)" value={cname} onChange={e => setCname(e.target.value)} />
          : <LeadPicker api={api} value={lead} onChange={setLead} />}
      </Field>
      {!preset?.act && <>
        <Field label="Account type"><Seg value={tier} onChange={setTier} items={[['any', 'Any'], ['premium', 'Premium'], ['std', '$25'], ['verified', 'Verified']]} /></Field>
        <Field label={`Account (${free.length} free)`} hint="Empty = the first free one of this type">
          <select className={inputCls} value={act} onChange={e => setAct(e.target.value)}>
            <option value="">Auto: first free</option>
            {free.map(a => <option key={a.act_id} value={a.act_id}>{a.name || 'Account ' + a.no}{(a as any).cat === 'premium' ? ' · Premium' : (a as any).cat === 'std' ? ' · $25' : ''} · {a.bm_name}{a.created_time ? ' · ' + age(a.created_time) : ''}</option>)}
          </select>
        </Field>
        {!free.length && tier !== 'any' && <button type="button" className="af-note mb-3 w-full text-left text-[13px]" onClick={() => setTier('any')}>No {tier === 'std' ? '$25' : tier === 'premium' ? 'Premium' : tier} account is free. <b className="text-tg-link">Show all free accounts</b> and pick another one.</button>}
      </>}
      {EMAIL_ON && <Field label="How to share"><Seg value={mode} onChange={v => setMode(v as 'bm' | 'email')} items={[['bm', 'Client’s BM ID'], ['email', 'Email invite']]} /></Field>}
      {mode === 'bm' || !EMAIL_ON ? <Field label="Client’s Business Manager ID"><input className={inputCls} inputMode="numeric" placeholder="1489220735610042" value={bm} onChange={e => setBm(e.target.value)} /></Field>
        : <Field label="Client’s Facebook email" hint="They get an invite to our BM with access to this one account only."><input className={inputCls} type="email" placeholder="client@gmail.com" value={email} onChange={e => setEmail(e.target.value)} /></Field>}
      <Field label="Top-up with the account (USD, optional)" hint={Number(topPaid) > 0 ? `${usd(Number(topPaid))} goes on the limit · fee ${PCT}% on top → client pays ${usd(Math.round(Number(topPaid) * (100 + PCT)) / 100)}` : 'Goes on the account as it is (fee on top). Empty = $0, top up later.'}><input className={inputCls} type="number" inputMode="decimal" placeholder="0" value={topPaid} onChange={e => setTopPaid(e.target.value)} /></Field>
      <Field label="Client’s business name (optional)" hint="Only for the account name “Adsbhai {our BM} X {client} {iX} {business}”. Leave it empty: the system reads the client’s business name from their BM on Meta."><input className={inputCls} value={biz} onChange={e => setBiz(e.target.value)} placeholder="Shree Shyam" /></Field>
      <div className="mb-3 rounded-xl bg-tg-input px-4 py-3 text-[13.5px]">
        <div><span className="text-tg-sub">Access</span><div className="mt-0.5">✓ Campaigns · ✓ Performance · ✓ Creative Hub · <span className="text-tg-bad">✕ Manage (card / billing / sharing)</span></div></div>
        <div className="mt-1 flex justify-between"><span className="text-tg-sub">Starting balance</span><b className="text-tg-ok">{(() => { const add = Number(topPaid) > 0 ? Number(topPaid) : 0; const cr = lead?.credit || 0; return cr + add > 0 ? `${usd(cr + add)}${cr ? ` (credit ${usd(cr)}${add ? ` + top-up ${usd(add)}` : ''})` : ' (top-up)'}` : '$0 (top up after)'; })()}</b></div>
      </div>
      {hand && <p className="mb-2 rounded-xl bg-tg-orange/10 px-3.5 py-2.5 text-[13px] leading-relaxed text-tg-orange">First assign the partner in Business Settings → Ad accounts → this account → Assign partner → the client’s BM ID (Advertise + Analyze). Then tap below: the system checks the partner on Meta and does the rest (limit, name, records, client message, proof, channel post).</p>}
      <Btn className="w-full" busy={busy} onClick={() => void go()}>{hand ? 'Partner assigned → finish' : 'Share account'}</Btn>
    </Sheet>
  );
}

/** v136: the ad account request queue (Admin → Inbox). */
export function MetaRequests({ api, changed }: { api: Api; changed: () => void }) { return <Requests api={api} ver={0} changed={changed} />; }
/** v159: upload the client-chat screenshot → IDs blurred (OCR) → preview → Post now. Or send without it. */
async function shrinkImage(f: File): Promise<string> {
  const url = URL.createObjectURL(f);
  try {
    const img = await new Promise<HTMLImageElement>((ok, bad) => { const i = new Image(); i.onload = () => ok(i); i.onerror = () => bad(new Error('This file is not an image')); i.src = url; });
    const k = Math.min(1, 2400 / Math.max(img.naturalWidth, img.naturalHeight));
    const c = document.createElement('canvas'); c.width = Math.round(img.naturalWidth * k); c.height = Math.round(img.naturalHeight * k);
    c.getContext('2d')!.drawImage(img, 0, 0, c.width, c.height);
    return c.toDataURL('image/png');
  } finally { URL.revokeObjectURL(url); }
}
function ShotBox({ api, act, sending, done }: { api: Api; act: string; sending: boolean; done: () => void }) {
  const toast = useToast();
  const [prev, setPrev] = useState<string | null>(null); const [found, setFound] = useState<number | null>(null); const [busy, setBusy] = useState('');
  const inp = useRef<HTMLInputElement>(null);
  useEffect(() => { setPrev(null); setFound(null); void (async () => { try { const r = await api<any>('meta/shot_img?act=' + act); if (r.preview) setPrev(r.preview); } catch { /* */ } })(); }, [api, act]);
  async function pick(f: File | undefined) {
    if (!f) return;
    setBusy('up');
    try { const image = await shrinkImage(f); const r = await api<any>('meta/shot_upload', { act_id: act, image }); setPrev(r.preview); setFound(r.found); }
    catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(''); if (inp.current) inp.current.value = ''; }
  }
  async function go(path: string, msg: string, key: string) {
    setBusy(key);
    try { await api(path, { act_id: act }); toast(msg); done(); } catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(''); }
  }
  if (sending) return <div className="mt-3 rounded-2xl bg-tg-acc/10 px-3.5 py-3 text-[13.5px] text-tg-link" data-shotbox>Posting to the channel and story…</div>;
  return (
    <div className="mt-3 rounded-2xl bg-tg-warnsoft p-3" data-shotbox>
      <b className="flex items-center gap-1.5 text-[14.5px] text-tg-warn"><Camera size={16} />Waiting for chat screenshot</b>
      <span className="block text-[12.5px] leading-relaxed text-tg-sub">The account is delivered. The channel post, story and Saved Messages copy go after the screenshot. Long ID numbers are blurred by the system (phone numbers half).</span>
      <input ref={inp} type="file" accept="image/*" className="hidden" onChange={e => void pick(e.target.files?.[0])} />
      {prev && <div className="mt-2.5 text-center"><img src={prev} alt="Chat screenshot" className="mx-auto max-h-[55vh] w-auto rounded-xl" /><span className="mt-1 block text-[12px] text-tg-sub">{found == null ? 'Uploaded screenshot' : found ? `${found} number${found === 1 ? '' : 's'} blurred · check nothing private is left` : 'No long ID number found · check nothing private is left'}</span></div>}
      {busy === 'up' ? <div className="mt-2.5 rounded-xl bg-tg-input px-3 py-3 text-center text-[13.5px]">Reading the screenshot and blurring IDs…</div> : <>
        {prev && <Btn kind="green" className="mt-2.5 w-full" busy={busy === 'go'} onClick={() => void go('meta/shot_post', 'Posting with the screenshot', 'go')}>Post now</Btn>}
        <Btn kind={prev ? 'ghost' : 'primary'} className="mt-2 w-full" onClick={() => inp.current?.click()}>{prev ? 'Choose another screenshot' : 'Upload chat screenshot'}</Btn>
      </>}
      <button className="mt-2 w-full text-center text-[13px] text-tg-link disabled:opacity-50" disabled={!!busy} onClick={() => { if (confirm('Post to the channel and story now, without the chat screenshot (the usual post)?')) void go('meta/shot_skip', 'Posting without screenshot', 'skip'); }}>Send without screenshot</button>
    </div>
  );
}

function Requests({ api, ver, changed }: { api: Api; ver: number; changed: () => void }) {
  const toast = useToast();
  const [st, setSt] = useState<'open' | 'all'>('open');
  const [rows, setRows] = useState<Req[] | null>(null);
  const [edit, setEdit] = useState<Req | null>(null);
  const load = useCallback(async () => { try { setRows((await api<{ requests: Req[] }>('meta/requests?status=' + st)).requests); } catch { /* ignore */ } }, [api, st]);
  useEffect(() => { void load(); }, [load, ver]);
  const [waits, setWaits] = useState<{ act_id: string; name: string | null; client: string | null; since: number; sending: boolean }[]>([]);
  const [shot, setShot] = useState<string | null>(null);
  const loadW = useCallback(async () => { try { setWaits((await api<any>('meta/shot_waiting')).posts || []); } catch { /* ignore */ } }, [api]);
  useEffect(() => { void loadW(); }, [loadW, ver]);
  useInterval(() => { void load(); void loadW(); }, 10000);
  const sh = waits.find(w => w.act_id === shot);
  return (
    <div>
      {waits.length > 0 && <div className="mb-3 rounded-2xl bg-tg-warnsoft p-3" data-shotwait>
        <b className="flex items-center gap-1.5 text-[14.5px] text-tg-warn"><Camera size={16} />Waiting for chat screenshot ({waits.length})</b>
        <span className="block text-[12.5px] text-tg-sub">Delivered. The channel post and story go after you upload the client-chat screenshot.</span>
        {waits.map(w => <button key={w.act_id} onClick={() => setShot(w.act_id)} className="mt-2 flex w-full items-center gap-2 rounded-xl bg-tg-panel px-3 py-2 text-left"><span className="min-w-0 flex-1"><span className="block truncate text-[14px] font-semibold">{w.client || 'Client'}</span><span className="block truncate text-[12px] text-tg-sub">{w.name || 'act_' + w.act_id} · {listTime(w.since)}</span></span><span className="shrink-0 text-[13px] font-semibold text-tg-link">{w.sending ? 'Posting…' : 'Upload'}</span></button>)}
      </div>}
      <Sheet open={!!shot} onClose={() => setShot(null)} title={sh ? `Chat screenshot · ${sh.client || ''}` : 'Chat screenshot'}>
        {shot && <ShotBox api={api} act={shot} sending={!!sh?.sending} done={() => { setShot(null); void loadW(); changed(); }} />}
      </Sheet>
      <div className="mb-3"><Seg value={st} onChange={v => setSt(v as 'open' | 'all')} items={[['open', 'To do'], ['all', 'All']]} /></div>
      {!rows ? <div className="p-3"><Skeleton rows={3} h={68} /></div> : !rows.length ? <div className="p-8 text-center text-tg-sub">{st === 'open' ? 'Nothing to approve.' : 'No requests yet.'}</div> : rows.map(r => (
        <button key={r.id} onClick={() => setEdit(r)} className="mb-2 block w-full af-card p-3 text-left">
          <span className="flex items-center gap-2"><span className="flex-1 text-[15px] font-semibold">{r.kind === 'account' ? 'Ad account' : r.kind === 'replace' ? 'Replacement' : 'Top-up'} · {r.lead?.name}</span>{(r.method === 'upi' || r.method === 'crypto') && <Chip m={{ x: [r.method === 'upi' ? 'UPI' : 'Crypto direct', 'bg-tg-orange/15 text-tg-orange'] }} k="x" />}<Chip m={REQSTATE} k={r.status} /></span>
          <span className="mt-0.5 block text-[12.5px] text-tg-sub">{r.summary}{r.agent ? ` · ${r.agent}` : ''} · {listTime(r.created_at)}</span>
          {r.note && <span className="mt-1 block text-[12.5px] text-tg-orange">{r.note}</span>}
          {r.error && <span className="mt-1 block text-[12.5px] text-tg-bad">{r.error}</span>}
        </button>
      ))}
      <ReqSheet api={api} r={edit} onClose={() => setEdit(null)} done={() => { setEdit(null); void load(); changed(); }} toast={toast} />
    </div>
  );
}

function ReqSheet({ api, r, onClose, done, toast }: { api: Api; r: Req | null; onClose: () => void; done: () => void; toast: (m: string, k?: 'ok' | 'err') => void }) {
  const [bm, setBm] = useState(''); const [email, setEmail] = useState(''); const [tier, setTier] = useState('any'); const [act, setAct] = useState(''); const [free, setFree] = useState<Acct[]>([]); const [busy, setBusy] = useState(''); const [note, setNote] = useState(''); const [addAmt, setAddAmt] = useState(''); // v173
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => { if (!r) return; setBm(r.client_bm || ''); setEmail(r.client_email || ''); setTier(r.tier || 'any'); setAct(r.act_id || ''); setNote(''); setAddAmt((r as any).add_amount ? String((r as any).add_amount) : ''); }, [r?.id]); // v153: only when another request opens (the list refreshes every 10s)
  useEffect(() => { if (!r || r.kind === 'topup') return; void (async () => { try { setFree((await api<{ accounts: Acct[] }>('meta/free?tier=' + tier)).accounts); } catch { /* ignore */ } })(); }, [api, r, tier]);
  const open = r && ['pending', 'failed', 'manual'].includes(r.status);
  const ext = !!(r as (Req & { ext?: number }) | null)?.ext; // v156: top-up on an account not in the system
  async function act2(path: string, body: Record<string, unknown>, msg: string, key: string) {
    setBusy(key);
    try { const x = await api<any>(path, { id: r!.id, ...body }); if (x.queued) { toast(`In the queue · ~${x.job?.eta_min || 2} min`); done(); } else if (x.done === false) toast(x.error || 'Could not do it', 'err'); else { toast(msg); done(); } }
    catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(''); }
  }
  return (
    <Sheet open={!!r} onClose={onClose} title={r ? `${r.kind === 'account' ? 'Ad account' : r.kind === 'replace' ? 'Replacement' : 'Top-up'} · ${r.lead?.name || ''}` : ''}>
      {r && <>
        <div className="mb-3 rounded-xl bg-tg-input px-3.5 py-1">
          <KV k="Request" v={r.summary} />
          <KV k="By" v={r.agent || '—'} />
          {(r.method === 'upi' || r.method === 'crypto') && <KV k="Payment" v={<span className="text-tg-orange">{r.method === 'upi' ? 'UPI' : 'Crypto to our wallet'}: check the money arrived</span>} />}
          {r.kind === 'topup' && <KV k="Paid · fee · added" v={`${usd(r.paid)} · ${usd(r.fee)} · ${usd(r.amount)}`} />}
          {r.credit > 0 && r.kind !== 'topup' && <KV k="Client credit added" v={usd(r.credit)} />}
          <KV k="Status" v={<Chip m={REQSTATE} k={r.status} />} />
        </div>
        {r.error && <p className="mb-3 rounded-xl bg-tg-red/10 px-3 py-2 text-[13px] text-tg-bad">{r.error}</p>}
        {open && r.kind !== 'topup' && <>
          <Field label="Account type"><Seg value={tier} onChange={setTier} items={[['any', 'Any'], ['premium', 'Premium'], ['std', '$25'], ['verified', 'Verified']]} /></Field>
          <Field label={`Account (${free.length} free)`}><select className={inputCls} value={act} onChange={e => setAct(e.target.value)}><option value="">Choose the account…</option>{free.map(a => <option key={a.act_id} value={a.act_id}>{a.name || 'Account ' + a.no}{(a as any).cat === 'premium' ? ' · Premium' : (a as any).cat === 'std' ? ' · $25' : ''} · {a.bm_name}{a.created_time ? ' · ' + age(a.created_time) : ''}</option>)}</select></Field>
          {/* v171 (owner): none of the asked type free → give another type (e.g. Premium instead of $25) */}
          {!free.length && tier !== 'any' && <button type="button" className="af-note mb-3 w-full text-left text-[13px]" onClick={() => setTier('any')} data-no-type>No {tier === 'std' ? '$25' : tier === 'premium' ? 'Premium' : tier} account is free. <b className="text-tg-link">Show all free accounts</b> and pick another one (e.g. Premium).</button>}
          {(r.kind === 'account' || r.kind === 'replace') && <Field label={r.kind === 'replace' ? 'Client’s old balance to add (USD)' : 'Top-up with the account (USD)'} hint={r.kind === 'replace' ? `Goes on the new account’s limit: no fee, no sale.${r.credit > 0 ? ` Credit already in the system: ${usd(r.credit)} (added by itself, don’t type it again).` : ''}${r.credit > 0 && Math.abs(Number(addAmt) - r.credit) < 0.01 ? ' Warning: this is the same as the credit, it would be given twice.' : ''}` : Number(addAmt) > 0 ? `${usd(Number(addAmt))} goes on the limit with the account; the fee is on top.` : 'Empty = no top-up with this account.'}><input className={inputCls} type="number" inputMode="decimal" placeholder="0" value={addAmt} onChange={e => setAddAmt(e.target.value)} data-req-topup /></Field>}
          {r.mode === 'email' ? <Field label="Client’s Facebook email"><input className={inputCls} value={email} onChange={e => setEmail(e.target.value)} /></Field>
            : <Field label="Client’s Business Manager ID"><input className={inputCls} inputMode="numeric" value={bm} onChange={e => setBm(e.target.value)} /></Field>}
        </>}
        {open && <>
          {r.kind !== 'topup' && r.mode !== 'email' && <p className="mb-2 rounded-xl bg-tg-orange/10 px-3 py-2 text-[12.5px] leading-relaxed text-tg-orange">Partner by hand: assign the client’s BM ID ({bm || r.client_bm || '—'}) as partner in Business Settings first, then tap below. The system checks it on Meta and does the rest.</p>}
          {ext && <p className="mb-2 rounded-xl bg-tg-orange/10 px-3 py-2 text-[12.5px] leading-relaxed text-tg-orange">This account is not in the system. Add {usd(r.amount)} to act_{r.act_id} in Ads Manager (raise the spending limit), then tap Done by hand: records and the client message follow.</p>}
          {!ext && <Btn kind="green" className="w-full" busy={busy === 'run'} onClick={() => void act2('meta/request_run', r.kind !== 'topup' ? { act_id: act || undefined, client_bm: bm || undefined, client_email: email || undefined, tier, ...(r.kind === 'account' || r.kind === 'replace' ? { add_amount: addAmt === '' ? 0 : Number(addAmt) } : {}) } : {}, r.kind === 'topup' ? 'Top-up added' : r.kind === 'replace' ? 'Replaced' : 'Shared', 'run')}>{(r.method === 'upi' || r.method === 'crypto') && r.status === 'pending' ? 'Money received · approve' : r.status === 'pending' ? (r.kind === 'replace' ? 'Replace now' : 'Approve') : 'Try again'}</Btn>}
          {(r.status === 'manual' || r.status === 'failed' || ext) && <Btn kind="ghost" className="mt-2 w-full" busy={busy === 'hand'} onClick={() => { if (r.kind !== 'topup' && !act && !r.act_id) { toast('Choose the account you shared by hand', 'err'); return; } if (confirm('Did you already do this in Ads Manager?')) void act2('meta/request_hand', { act_id: act || r.act_id, ...(r.kind === 'account' || r.kind === 'replace' ? { add_amount: addAmt === '' ? 0 : Number(addAmt) } : {}) }, 'Saved as done by hand', 'hand'); }}>Done by hand in Ads Manager</Btn>}
          <div className="mt-4 flex gap-2"><input className={inputCls} placeholder="Reason (optional)" value={note} onChange={e => setNote(e.target.value)} /><Btn kind="danger" busy={busy === 'rej'} onClick={() => void act2('meta/request_reject', { note }, 'Rejected', 'rej')}>{r.method === 'upi' || r.method === 'crypto' ? 'Not received' : 'Reject'}</Btn></div>
        </>}
      </>}
    </Sheet>
  );
}

function Bms({ api, ver, onOpen, changed }: { api: Api; ver: number; onOpen: (id: number) => void; changed: () => void }) {
  const [rows, setRows] = useState<Bm[] | null>(null); const [f, setF] = useState('all'); const [add, setAdd] = useState(false);
  useEffect(() => { void (async () => { try { setRows((await api<{ bms: Bm[] }>('meta/bms')).bms); } catch { /* ignore */ } })(); }, [api, ver]);
  const list = (rows || []).filter(b => f === 'all' || (f === 'problem' ? b.status !== 'ok' : b.tier === f));
  const n = (k: string) => (rows || []).filter(b => k === 'all' || (k === 'problem' ? b.status !== 'ok' : b.tier === k)).length;
  return (
    <div>
      <div className="mb-3 flex items-center gap-2"><Chips className="-ml-4 min-w-0 flex-1 pl-4" value={f} onChange={setF} items={[['all', 'All', n('all')], ['verified', 'Verified', n('verified')], ['review', 'In review', n('review')], ['unverified', 'Unverified', n('unverified')], ['problem', 'Problems', n('problem')]]} /><Btn kind="soft" size="sm" className="shrink-0" onClick={() => setAdd(true)}><Plus size={15} />Add BM</Btn></div>
      {!rows ? <div className="p-3"><Skeleton rows={3} h={68} /></div> : list.map(b => (
        <button key={b.id} onClick={() => onOpen(b.id)} className="mb-2 block w-full af-card p-3 text-left">
          <span className="flex items-center gap-2"><span className="min-w-0 flex-1 truncate text-[15.5px] font-semibold">{b.name || b.bm_id}</span><VS v={(b as any).verified_since} tier={b.tier} /><Chip m={BMSTATE} k={b.status} /></span>
          <span className="mt-0.5 block text-[12.5px] text-tg-sub">ID {b.bm_id}{(b as any).profile ? ` · profile ${(b as any).profile}` : `${b.label ? ` · ${b.label}` : ''}${b.proxy ? ` · proxy ${b.proxy}` : ' · no proxy'}`}</span>
          <span className="mt-1.5 flex gap-3 text-[13px]"><span>Accounts <b>{b.accounts}{b.acct_limit ? ` / ${b.acct_limit}` : ''}</b></span><span className="text-tg-sub">{b.assigned} with clients · {b.free} free · {b.disabled} disabled</span></span>
          {b.status !== 'ok' && b.error && <span className="mt-1 block text-[12px] text-tg-bad">{b.error}</span>}
        </button>
      ))}
      <AddBmSheet api={api} open={add} onClose={() => setAdd(false)} done={() => { setAdd(false); changed(); }} />
    </div>
  );
}

function AddBmSheet({ api, open, onClose, done, bm }: { api: Api; open: boolean; onClose: () => void; done: () => void; bm?: Bm }) {
  const toast = useToast();
  const [v, setV] = useState({ token: '', bm_id: '', proxy: '', label: '', secret: '', acct_limit: '' }); const [busy, setBusy] = useState(false);
  const ok2 = useOpenKey(open);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => { if (ok2) setV({ token: '', bm_id: bm?.bm_id || '', proxy: '', label: bm?.label || '', secret: '', acct_limit: bm?.acct_limit ? String(bm.acct_limit) : '' }); }, [ok2]);
  const set = (k: keyof typeof v) => (e: React.ChangeEvent<HTMLInputElement>) => setV(x => ({ ...x, [k]: e.target.value }));
  async function save() {
    setBusy(true);
    try {
      const body: Record<string, unknown> = { ...v };
      if (bm) { body.id = bm.id; if (!v.proxy) delete body.proxy; if (!v.secret) delete body.secret; }
      const r = await api<any>(bm ? 'meta/bm_update' : 'meta/bm_add', body);
      toast(bm ? 'Token updated' : `Added: ${r.bm.name} · ${r.bm.accounts} account${r.bm.accounts === 1 ? '' : 's'}`); done();
    } catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); }
  }
  return (
    <Sheet open={open} onClose={onClose} title={bm ? `New token · ${bm.name || bm.bm_id}` : 'Add BM'}>
      <Field label="System User token" hint="Business settings → System users → Generate token (Never). Permissions: ads_management, ads_read, business_management."><input className={inputCls} placeholder="EAAG…" value={v.token} onChange={set('token')} autoComplete="off" /></Field>
      {!bm && <Field label="Business ID" hint="Business settings → Business info"><input className={inputCls} inputMode="numeric" placeholder="3062021164151986" value={v.bm_id} onChange={set('bm_id')} /></Field>}
      <Field label={bm ? 'Proxy (empty = keep current)' : 'Proxy for this BM (recommended)'} hint="host:port:user:pass or http://user:pass@host:port or socks5://… · BMs of the same FB profile can use the same proxy."><input className={inputCls} placeholder="in.proxy.com:8000:user:pass" value={v.proxy} onChange={set('proxy')} autoComplete="off" /></Field>
      <Field label="FB profile / label" hint="Only for you, e.g. “Amit 2”"><input className={inputCls} value={v.label} onChange={set('label')} /></Field>
      <Field label="Ad account limit of this BM (optional)" hint="1, 3, 5… Meta does not give it in the API"><input className={inputCls} type="number" value={v.acct_limit} onChange={set('acct_limit')} /></Field>
      <Field label="App Secret (optional)" hint="Only if “Require App Secret” is ON in your Meta app"><input className={inputCls} value={v.secret} onChange={set('secret')} autoComplete="off" /></Field>
      <Btn className="w-full" busy={busy} onClick={() => void save()}>{bm ? 'Save new token' : 'Check and add'}</Btn>
    </Sheet>
  );
}

function BmSheet({ api, id, onClose, changed, onAcct }: { api: Api; id: number | null; onClose: () => void; changed: () => void; onAcct: (a: string) => void }) {
  const toast = useToast();
  const [d, setD] = useState<{ bm: Bm; accounts: Acct[] } | null>(null); const [busy, setBusy] = useState(''); const [tok, setTok] = useState(false);
  const [label, setLabel] = useState(''); const [limit, setLimit] = useState(''); const [proxy, setProxy] = useState('');
  const load = useCallback(async () => { if (!id) return; try { const r = await api<{ bm: Bm; accounts: Acct[] }>('meta/bm?id=' + id); setD(r); setLabel(r.bm.label || ''); setLimit(r.bm.acct_limit ? String(r.bm.acct_limit) : ''); setProxy(''); } catch (e) { toast((e as Error).message, 'err'); } }, [api, id, toast]);
  useEffect(() => { setD(null); if (id) void load(); }, [id, load]);
  async function call(path: string, body: Record<string, unknown>, msg: string, key: string, close = false) {
    setBusy(key);
    try { const r = await api<any>(path, { id, ...body }); if (r.ok === false) toast(r.error || 'Error', 'err'); else toast(typeof msg === 'string' ? msg : 'Done'); changed(); if (close) onClose(); else await load(); }
    catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(''); }
  }
  const b = d?.bm;
  return (
    <Sheet open={!!id} onClose={onClose} title={b ? b.name || b.bm_id : 'BM'} wide>
      {!b ? <div className="p-3"><Skeleton rows={3} h={68} /></div> : <>
        <div className="mb-2 flex flex-wrap gap-1.5"><VS v={(b as any).verified_since} tier={b.tier} /><Chip m={BMSTATE} k={b.status} /></div>
        {(b as any).profile_id && <p className="mb-3 rounded-xl bg-tg-acc/10 px-3.5 py-2.5 text-[13px] text-tg-sub">This BM comes from profile <b className="text-tg-text">{(b as any).profile || ''}</b>. Its token, the iProxy line, limits and the verified date are set in <b className="text-tg-text">Ad accounts → Profiles</b>.</p>}
        {b.status !== 'ok' && <div className="mb-3 rounded-xl bg-tg-red/10 px-3.5 py-2.5 text-[13px] text-tg-bad">
          <b>{b.status === 'banned' ? 'Marked banned.' : b.status === 'blocked' ? 'Meta blocked the API for this BM.' : 'Last sync failed.'}</b> {b.error}
          {b.status !== 'banned' && <div className="mt-1 text-tg-sub">{(b as any).profile_id ? 'Make a new token for the profile: Ad accounts → Profiles → New token.' : <>Make a new System User token and tap “Update token”.</>} Until then shares and top-ups here go to Requests as “Do by hand”.</div>}
        </div>}
        <div className="rounded-2xl bg-tg-input/60 px-3.5 py-1">
          <KV k="Business ID" v={<button className="text-tg-link" onClick={() => copyT(b.bm_id, toast)}>{b.bm_id} <Copy size={12} className="inline" /></button>} />
          <KV k="Verification" v={({ verified: 'Verified', not_verified: 'Not verified', pending: 'In review', pending_submission: 'Not sent yet', failed: 'Failed', rejected: 'Rejected' } as Record<string, string>)[b.verification || ''] || (b.verification ? String(b.verification).replace(/_/g, ' ') : '—')} />
          {b.created_time ? <KV k="Created" v={`${age(b.created_time)} ago`} /> : null}
          {(b as any).profile_id ? <KV k="Profile" v={(b as any).profile || '—'} /> : <>
            <KV k="System user" v={b.su_name || '—'} />
            <KV k="Proxy" v={b.proxy || 'none'} />
          </>}
          <KV k="Accounts" v={`${b.accounts}${b.acct_limit ? ' / ' + b.acct_limit : ''} · ${b.assigned} with clients · ${b.free} free`} />
          <KV k="Last read" v={b.synced_at ? listTime(b.synced_at) : '—'} />
        </div>
        <div className="mt-3 grid grid-cols-2 gap-2">
          <Btn kind="ghost" busy={busy === 'sync'} onClick={() => void call('meta/bm_sync', {}, 'Synced', 'sync')}><RefreshCw size={16} />Sync now</Btn>
          {!(b as any).profile_id && <Btn kind="ghost" onClick={() => setTok(true)}><KeyRound size={16} />Update token</Btn>}
        </div>
        <h4 className="mb-2 mt-5 text-[12.5px] font-semibold uppercase tracking-wide text-tg-sub">Ad accounts on this BM</h4>
        {d!.accounts.map(a => <AcctRow key={a.act_id} a={a} onClick={() => onAcct(a.act_id)} />)}
        <h4 className="mb-2 mt-5 text-[12.5px] font-semibold uppercase tracking-wide text-tg-sub">Settings</h4>
        {!(b as any).profile_id && <>
          <Field label="FB profile / label"><input className={inputCls} value={label} onChange={e => setLabel(e.target.value)} /></Field>
          <Field label="Ad account limit (1, 3, 5…)"><input className={inputCls} type="number" value={limit} onChange={e => setLimit(e.target.value)} /></Field>
          <Field label="New proxy (empty = keep)"><input className={inputCls} placeholder="host:port:user:pass" value={proxy} onChange={e => setProxy(e.target.value)} /></Field>
          <Btn className="w-full" busy={busy === 'save'} onClick={() => void call('meta/bm_update', { label, acct_limit: limit, ...(proxy ? { proxy } : {}) }, 'Saved', 'save')}>Save</Btn>
        </>}
        <Btn kind="ghost" className="mt-2 w-full" busy={busy === 'rn'} onClick={() => void call('meta/rename_all', { bm_id: b.bm_id }, 'Accounts renamed', 'rn')}>Rename free accounts to pattern</Btn>
        {b.status !== 'banned' && <Btn kind="danger" className="mt-2 w-full" busy={busy === 'ban'} onClick={() => { if (confirm('Mark this BM as banned? Every client account on it is marked disabled and the balance left is saved as each client’s credit.')) void call('meta/bm_ban', {}, 'Marked banned. Client balances moved to credit.', 'ban'); }}><Ban size={16} />BM banned · move clients to credit</Btn>}
        <button className="mt-4 w-full py-2 text-[13.5px] text-tg-bad" onClick={() => { if (confirm('Remove this BM from the panel? (Nothing changes in Meta.)')) void call('meta/bm_delete', {}, 'Removed', 'del', true); }}>Remove BM from panel</button>
        <AddBmSheet api={api} open={tok} bm={b} onClose={() => setTok(false)} done={() => { setTok(false); void load(); changed(); }} />
      </>}
    </Sheet>
  );
}

function Credits({ api, ver, isAdmin, onGive, changed }: { api: Api; ver: number; isAdmin?: boolean; onGive: (l: { id: number; name: string }) => void; changed: () => void }) {
  const toast = useToast();
  const [rows, setRows] = useState<any[] | null>(null);
  const load = useCallback(async () => { try { setRows((await api<{ credits: any[] }>('meta/credits')).credits); } catch { /* ignore */ } }, [api]);
  useEffect(() => { void load(); }, [load, ver]);
  const total = (rows || []).reduce((x, c) => x + c.amount, 0);
  // v165 (admin): refunded by hand / not owed → remove the credit (all or one entry), with a note
  async function remove(c: any, id: number | null, amt: string) {
    const note = prompt(`Remove ${amt} credit of ${c.lead?.name || 'this client'}?\nIt will not go on their next account. Note (e.g. refunded by UPI):`, 'Refunded');
    if (note === null) return;
    try { await api('meta/credit_cancel', { lead_id: c.lead_id, id, note }); toast(`${amt} credit removed`); void load(); changed(); } catch (e) { toast((e as Error).message, 'err'); }
  }
  return (
    <div>
      <p className="mb-3 text-[13px] text-tg-sub">Balance left on disabled / taken-back accounts. It is added automatically to the client’s next account. Total {usd(total)}.</p>
      {!rows ? <div className="p-3"><Skeleton rows={3} h={68} /></div> : !rows.length ? <div className="p-8 text-center text-tg-sub">No pending credit.</div> : rows.map(c => (
        <div key={c.lead_id} className="mb-2 af-card p-3">
          <div className="flex items-center"><b className="flex-1 text-[15.5px]">{c.lead?.name || '#' + c.lead_id}</b><b className="text-[20px] text-tg-orange">{usd(c.amount)}</b></div>
          {c.from.map((f: any) => <div key={f.id ?? f.act_id} className="flex items-center gap-2 text-[12.5px] text-tg-sub"><span className="flex-1">act_{f.act_id} · {usd(f.amount)} · {f.reason === 'bm_banned' ? 'BM banned' : f.reason} · {listTime(f.created_at)}</span>{isAdmin && c.from.length > 1 && f.id && <button data-credit-del={f.id} className="text-tg-bad" onClick={() => void remove(c, f.id, usd(f.amount))}>Remove</button>}</div>)}
          {c.lead?.agent && <div className="text-[12.5px] text-tg-sub">Agent: {c.lead.agent}</div>}
          <div className="mt-2.5 flex gap-2"><Btn className="flex-1" onClick={() => onGive({ id: c.lead_id, name: c.lead?.name || '#' + c.lead_id })}>Give new account + {usd(c.amount)}</Btn>{isAdmin && <Btn kind="ghost" data-credit-all onClick={() => void remove(c, null, usd(c.amount))}>Remove credit</Btn>}</div>
        </div>
      ))}
    </div>
  );
}

function Cards({ api, ver }: { api: Api; ver: number }) {
  const toast = useToast();
  const [rows, setRows] = useState<any[] | null>(null); const [ed, setEd] = useState<any>(null); const [bal, setBal] = useState('');
  const load = useCallback(async () => { try { setRows((await api<{ cards: any[] }>('meta/cards')).cards); } catch { /* ignore */ } }, [api]);
  useEffect(() => { void load(); }, [load, ver]);
  return (
    <div>
      {!rows ? <div className="p-3"><Skeleton rows={3} h={68} /></div> : !rows.length ? <div className="p-8 text-center text-tg-sub">No cards yet (they come from the ad accounts).</div> : rows.map(c => (
        <div key={c.card} className="mb-2 af-card p-3">
          <div className="flex items-center"><b className="flex-1 text-[15.5px]">{c.card}</b>{c.load === null ? <Chip m={{ x: ['Enter balance', 'bg-white/10 text-tg-sub'] }} k="x" /> : c.load > 0 ? <Chip m={{ x: [`Load ${usd(c.load)}`, 'bg-tg-red/15 text-tg-bad'] }} k="x" /> : <Chip m={{ x: ['OK', 'bg-tg-green/15 text-tg-ok'] }} k="x" />}</div>
          <div className="text-[12.5px] text-tg-sub">On {c.accounts} account{c.accounts === 1 ? '' : 's'} in {c.bms} BM{c.bms > 1 ? 's' : ''}</div>
          {c.bm_list?.length > 0 && <div className="mt-2 space-y-1.5">{c.bm_list.map((b: any) => <div key={b.bm_id} className="rounded-xl bg-tg-input/50 px-3 py-2 text-[12.5px]"><b className="text-[13px]">{b.name}</b> <span className="text-tg-sub">· {b.bm_id}</span><div className="mt-0.5 text-tg-sub">{b.accounts.map((a: any) => `${a.name}${a.state !== 'free' ? ` (${a.state === 'assigned' || a.state === 'invited' ? 'with client' : a.state})` : ''}`).join(' · ')}</div></div>)}</div>}
          <div className="mt-2 rounded-xl bg-tg-input px-3.5 py-1">
            <KV k="Client balance left (can still be charged)" v={usd(c.client_left)} />
            <KV k="Top-ups today" v={usd(c.topups_today)} />
            <KV k="Spend today" v={usd(c.spend_today)} />
            <KV k="Card balance (you enter)" v={c.balance === null ? '—' : `${usd(c.balance)} · ${listTime(c.bal_at)}`} />
            {c.balance !== null && <KV k="Charged by Meta since then · estimated now" v={`${usd(c.used_since)} · ${usd(c.est_balance)}`} />}
          </div>
          <Btn kind="ghost" className="mt-2 w-full" onClick={() => { setEd(c); setBal(''); }}>Update card balance</Btn>
        </div>
      ))}
      <p className="mt-2 text-[12.5px] text-tg-sub">Meta shows which card each account uses. The card’s bank balance can’t be read from Meta, so type it after you load it.</p>
      <Sheet open={!!ed} onClose={() => setEd(null)} title={`Balance · ${ed?.card || ''}`}>
        <Field label="Balance on the card now (USD)"><input className={inputCls} type="number" inputMode="decimal" value={bal} onChange={e => setBal(e.target.value)} /></Field>
        <Btn className="w-full" onClick={async () => { try { await api('meta/card_balance', { card: ed.card, balance: bal }); toast('Saved'); setEd(null); void load(); } catch (e) { toast((e as Error).message, 'err'); } }}>Save</Btn>
      </Sheet>
    </div>
  );
}

function Report({ api, isAdmin }: { api: Api; isAdmin?: boolean }) {
  const [range, setRange] = useState('today'); const [r, setR] = useState<any>(null);
  useEffect(() => { void (async () => { try { setR(await api('meta/report?range=' + range)); } catch { /* ignore */ } })(); }, [api, range]);
  return (
    <div>
      <div className="mb-3"><DropPill value={range} onChange={setRange} menuTitle="Period" items={[['today', 'Today'], ['yesterday', 'Yesterday'], ['7d', '7 days'], ['30d', '30 days'], ['all', 'All time']]} /></div>
      {!r ? <div className="p-3"><Skeleton rows={3} h={68} /></div> : <>
        <div className="grid grid-cols-2 gap-2.5 md:grid-cols-3">
          <Stat k="Ad accounts sold" v={r.sold} s={`${usd(r.sold_revenue)} revenue (system + marked sold)`} />
          <Stat k="Accounts shared" v={r.shares} s={`${r.unshares} taken back · ${r.disabled} disabled`} />
          <Stat k="Top-ups" v={usd(r.topup_paid)} s={`${r.topups} top-ups · ${usd(r.topup_added)} added`} />
          <Stat k="Top-up fee earned" v={usd(r.topup_fee)} tone="text-tg-ok" />
          {isAdmin !== false && <Stat k="Earned" v={usd(r.earned)} s="account sales + top-up fees" tone="text-tg-ok" />}
          <Stat k="Credits pending" v={usd(r.credits)} tone="text-tg-orange" />
          <Stat k="Replacements" v={r.replacements ?? 0} s={isAdmin !== false ? `cost ${usd(r.replace_cost || 0)} · no sale, no commission` : 'no sale, no commission'} />
        </div>
        <h4 className="mb-2 mt-5 text-[12.5px] font-semibold uppercase tracking-wide text-tg-sub">Recent</h4>
        {r.recent.map((l: any) => <div key={l.id} className="mb-1.5 flex items-center gap-2 rounded-xl bg-tg-panel px-3 py-2.5 text-[13.5px]"><span className="flex-1"><b className="capitalize">{l.kind.replace('_', ' ')}</b>{l.lead ? ` · ${l.lead}` : ''} <span className="text-tg-sub">· {l.acct_name || 'act_' + l.act_id} · {l.note || ''} · {listTime(l.created_at)}</span></span>{l.kind === 'topup' && <span className="text-tg-ok">+{usd(l.fee)}</span>}{l.kind !== 'topup' && !!l.amount && <span className="text-tg-sub">{usd(l.amount)}</span>}</div>)}
      </>}
    </div>
  );
}

/* ============================ CHAT SHEET (agents) ============================ */
type FreePick = { act_id: string; no: number; name: string | null; cat: string | null; api_ok: boolean; bm_name: string };
type ChatMeta = { free_list?: FreePick[]; on: boolean; off?: boolean; email_invites?: boolean; accounts: Acct[]; credit: number; free: Record<string, number>; cats?: Record<string, number>; requests: Req[]; links: { code: string; kind: string; label: string; total: number; amount: number; fee: number; act_id: string | null }[] };
export function ChatAccountSheet({ open, onClose, api, leadId, pct, autoAcct, autoTopup, manager, admin, onDone }: { open: boolean; onClose: () => void; api: Api; leadId: number | null; pct: number; autoAcct?: boolean; autoTopup?: boolean; manager?: boolean; admin?: boolean; onDone: () => void }) {
  const toast = useToast();
  const [d, setD] = useState<ChatMeta | null>(null);
  const [kind, setKind] = useState<'account' | 'topup' | 'replace' | 'hand'>('account');
  const [extAct, setExtAct] = useState(''); const [oldAct, setOldAct] = useState(''); const [rnote, setRnote] = useState(''); // v156
  const [tier, setTier] = useState('any'); const [mode, setMode] = useState<'bm' | 'email'>('bm'); const [bm, setBm] = useState(''); const [email, setEmail] = useState('');
  const [method, setMethod] = useState('upi'); const [code, setCode] = useState(''); const [paid, setPaid] = useState(''); const [act, setAct] = useState(''); const [busy, setBusy] = useState(false); const [biz, setBiz] = useState('');
  const [pickAct, setPickAct] = useState(''); const [hand, setHand] = useState(false); // v171: the manager / admin picks the account (Give / Replace); '' = the system picks
  const load = useCallback(async () => { if (!leadId) return; try { setD(await api<ChatMeta>('meta_chat?lead_id=' + leadId)); } catch (e) { toast((e as Error).message, 'err'); } }, [api, leadId, toast]);
  const ok3 = useOpenKey(open);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => { if (ok3) { setD(null); setPaid(''); setCode(''); setBm(''); setEmail(''); setExtAct(''); setOldAct(''); setRnote(''); setPickAct(''); setHand(false); void load(); } }, [ok3]);
  const mine = (d?.accounts || []).filter(a => ['assigned', 'invited'].includes(a.state));
  useEffect(() => { if (mine.length && !act) setAct(mine[0].act_id); }, [mine, act]);
  const ext = kind === 'topup' && (act === 'ext' || !mine.length); // v156: the account is not in our system → manager does it by hand
  const olds = d?.accounts || [];
  const oldPick = olds.find(a => a.act_id === oldAct);
  // v171: account picker (manager / admin): every free account; "already shared by hand" also lists this client's own accounts
  const canPick = false; // v173 (owner): the chat only makes the request; the account is chosen in Ad accounts → Requests
  const toRequests = (kind === 'account' || kind === 'replace') && !!(manager || admin);
  const [topAmt, setTopAmt] = useState(''); // v173: a top-up the client paid together with the account
  const [rcred, setRcred] = useState(''); // v173: replace → the client's old balance typed by hand
  const pickRow = (d?.free_list || []).find(x => x.act_id === pickAct);
  const handOn = hand || (!!pickRow && !pickRow.api_ok);
  useEffect(() => { if (kind === 'replace' && !oldAct && olds.length) { const o = olds.find(a => a.state === 'disabled' || a.status !== 1) || olds[0]; setOldAct(o.act_id); } }, [kind, oldAct, olds]);
  useEffect(() => { if (kind === 'replace' && oldPick?.client_bm && !bm) setBm(oldPick.client_bm); }, [kind, oldPick, bm]);
  const links = (d?.links || []).filter(l => (kind === 'topup') === (l.kind === 'topup'));
  useEffect(() => { if (!d) return; if (kind === 'account' && d.credit > 0 && method !== 'link') setMethod('credit'); else if (method === 'credit' && !(d.credit > 0)) setMethod('upi'); }, [d, kind, method]);
  // v157: top-up: the amount typed goes on the account, fee on top · account: what the client paid
  const p = Number(paid) || 0; const fee = Math.round(p * pct) / 100; const add = p; const payTotal = Math.round((p + fee) * 100) / 100;
  const link = links.find(l => l.code === code);
  const byHand = kind !== 'replace' && (method === 'upi' || method === 'crypto');
  const emailAgent = kind === 'account' && mode === 'email' && !manager && !!d?.email_invites;
  // v156: top-ups: the agent's auto top-up (with Auto approve ON) works for every payment; replacements: only the manager
  // v160: master switch OFF → agents only ask for top-ups (always to the manager); the admin's top-up from a chat goes to the manager too
  const offAgent = !!d?.off && !manager;
  const adminTop = !!admin && kind === 'topup';
  useEffect(() => { if (offAgent && !admin && kind !== 'topup') setKind('topup'); }, [offAgent, admin, kind]);
  const auto = emailAgent || adminTop || (offAgent && !admin) || kind === 'account' ? false : kind === 'replace' ? false : ext ? false : manager ? true : kind === 'topup' ? !!autoTopup : method === 'link' ? autoAcct : method === 'credit' ? autoAcct : false;
  async function send() {
    if (!leadId) return;
    setBusy(true);
    try {
      const r = await api<any>('meta_request', kind === 'replace'
        ? { lead_id: leadId, kind, old_act: oldAct === 'none' ? '' : oldAct === 'other' || !olds.length ? extAct : oldAct, client_bm: bm, tier, note: rnote, credit_amount: Number(rcred) > 0 ? Number(rcred) : undefined, ...(canPick && pickAct ? { new_act: pickAct, hand: handOn } : {}) }
        : { lead_id: leadId, kind, tier, mode: d?.email_invites ? mode : 'bm', client_bm: bm, client_email: email, method, pay_code: code, ...(kind === 'topup' ? { amount: paid } : { paid }), ...(adminTop ? { to_manager: true } : {}), act_id: kind === 'topup' ? (ext ? extAct : act) : canPick && pickAct ? pickAct : undefined, ...(kind === 'account' && canPick && pickAct ? { hand: handOn } : {}), ...(kind === 'account' ? { chat: 1, topup_amount: Number(topAmt) > 0 ? Number(topAmt) : undefined } : {}), ext: ext ? 1 : undefined, biz_name: biz });
      if (r.queued) toast(`In the queue · ~${r.job?.eta_min || 2} min`);
      else if (r.pending) toast(manager || admin ? 'In Requests: choose the account there' : 'Sent to the manager for approval');
      else if (r.done) toast(kind === 'replace' ? `Replaced: ${r.name}` : kind === 'account' ? (r.invited ? 'Invite sent to the client' : `Shared: ${r.name}`) : `${usd(r.added)} added`);
      else toast(r.error || 'Could not do it. The manager was told.', 'err');
      setTopAmt(''); setRcred(''); onDone(); void load();
    } catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); }
  }
  return (
    <Sheet open={open} onClose={onClose} title="Ad account">
      {!d ? <div className="p-3"><Skeleton rows={3} h={68} /></div> : !d.on ? <p className="text-[14px] text-tg-sub">The ad account system is not set up yet (Admin → Ad accounts → BMs).</p> : <>
        {(d.accounts.length > 0 || (d.credit ?? 0) > 0) && <div className="mb-4">
          {d.accounts.map(a => <div key={a.act_id} className="mb-1.5 rounded-xl bg-tg-input px-3.5 py-2.5">
            <div className="flex items-center gap-2"><b className="flex-1 text-[14.5px]">{a.name || 'Account ' + a.no}</b><Chip m={STATE} k={a.state} /></div>
            <div className="text-[12.5px] text-tg-sub">act_{a.act_id} · {a.share_mode === 'email' ? a.client_email : 'BM ' + (a.client_bm || '')}{a.status !== 1 ? ` · ${a.status_label}` : ''}</div>
            {['assigned', 'invited'].includes(a.state) && <div className="mt-1 text-[13px]">Balance <b className={a.left < 15 ? 'text-tg-orange' : 'text-tg-ok'}>{usd(a.left)}</b> <span className="text-tg-sub">· spent {usd(a.spent)} · today {usd(a.today)}</span></div>}
          </div>)}
          {(d.credit ?? 0) > 0 && <p className="rounded-xl bg-tg-orange/10 px-3.5 py-2 text-[13px] text-tg-orange">Credit {usd(d.credit)}: added automatically to the next account.</p>}
        </div>}
        {offAgent && !admin && <p className="mb-2 rounded-xl bg-tg-orange/10 px-3.5 py-2 text-[12.5px] text-tg-orange">The ad account system is OFF: only top-up requests (they go to the manager).</p>}
        {/* v167 (agent-app redesign): one segmented control for the mode */}
        <div className="af-seg mb-4" data-acct-kind>
          {([['account', 'Give'], ['topup', 'Top-up'], ['replace', 'Replace'], ...((manager || admin) ? [['hand', 'By hand']] as const : [])] as const).map(([v, l]) => <button key={v} type="button" aria-pressed={kind === v} disabled={offAgent && !admin && v !== 'topup'} onClick={() => setKind(v)} className="af-press disabled:opacity-40">{l}</button>)}
        </div>
        {kind === 'hand' && leadId && <HandBox api={api} leadId={leadId} mine={(d.accounts || []).filter(x => ['assigned', 'invited'].includes(x.state))} done={() => { onDone(); void load(); }} />}
        {kind !== 'hand' && <>
        {kind === 'account' ? <>
          {(mode === 'bm' || !d.email_invites) && <Field label="Account type">
            {/* v167: a clear selected state (tick + accent ring); "Any type" is the default the server already gets */}
            <div className="grid grid-cols-2 gap-2" data-acct-tiers>{(d.cats && (d.cats.premium + d.cats.std) > 0 ? (['any', 'premium', 'std'] as const) : (['any', 'verified', 'review', 'unverified'] as const)).map(t => <button key={t} type="button" aria-pressed={tier === t} onClick={() => setTier(t)} className={clsx('af-press flex min-h-[44px] items-center gap-2 rounded-xl px-3 py-2 text-left text-[13.5px]', tier === t ? 'bg-tg-accsoft font-semibold text-tg-text ring-2 ring-inset ring-tg-acc' : 'bg-tg-input text-tg-text')}><span className="min-w-0 flex-1 leading-tight">{TIER[t][0]}<span className="block text-[12px] font-normal text-tg-sub">{t === 'any' ? (d.cats && (d.cats.premium + d.cats.std) > 0 ? d.cats.premium + d.cats.std : d.free.verified + d.free.review + d.free.unverified) : t === 'premium' || t === 'std' ? d.cats![t] : d.free[t]} free</span></span>{tier === t && <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full bg-tg-acc text-[12px] font-bold text-white" aria-hidden>✓</span>}</button>)}</div>
          </Field>}
          {canPick && <>
            <Field label={(kind as string) === 'replace' ? 'New account' : 'Which account'} hint={!pickAct ? 'It goes to Ad accounts → Requests; pick the account there.' : pickRow && !pickRow.api_ok ? 'This BM’s API is blocked: share it in Meta by hand first. Then this only saves it, sends the client message and the records.' : handOn ? 'Nothing is shared again: it is saved to this client, the client gets the message, records are made.' : 'The system shares this account.'}>
              <select className={inputCls} value={pickAct} onChange={e => setPickAct(e.target.value)} data-pick-acct>
                <option value="">Choose later in Requests</option>
                {(d?.free_list || []).map(x => <option key={x.act_id} value={x.act_id}>{x.name || 'Account ' + x.no} · {x.cat === 'premium' ? 'Premium' : x.cat === 'std' ? '$25' : 'free'}{x.api_ok ? '' : ' · API blocked'} · act_{x.act_id}</option>)}
                {hand && (d?.accounts || []).filter(x => ['assigned', 'invited'].includes(x.state)).map(x => <option key={x.act_id} value={x.act_id}>{x.name || 'Account ' + x.no} · already with this client · act_{x.act_id}</option>)}
              </select>
            </Field>
            {pickAct && <label className="mb-3 flex items-center gap-2.5 text-[14px]"><input type="checkbox" className="h-4 w-4" checked={handOn} disabled={!!pickRow && !pickRow.api_ok} onChange={e => setHand(e.target.checked)} data-pick-hand />I already shared it in Meta by hand</label>}
            {!pickAct && <label className="mb-3 flex items-center gap-2.5 text-[14px] text-tg-sub"><input type="checkbox" className="h-4 w-4" checked={hand} onChange={e => setHand(e.target.checked)} />I already shared one by hand (show this client’s accounts too)</label>}
          </>}
          <Field label="Top-up with the account (USD, optional)" hint={Number(topAmt) > 0 ? `${usd(Number(topAmt))} goes on the account; the fee comes on top.` : 'If the client paid a top-up together with the account. Empty = none.'}><input className={inputCls} type="number" inputMode="decimal" placeholder="0" value={topAmt} onChange={e => setTopAmt(e.target.value)} data-chat-topup /></Field>
          <Field label="Client’s business name" hint={biz.trim() ? `The new account’s name ends with “${biz.trim()}”, so you can find it later.` : 'Added to the end of the new account’s name, so you can find it later.'}><input className={inputCls} value={biz} onChange={e => setBiz(e.target.value)} placeholder="Shree Shyam" /></Field>
          {d.email_invites && <Field label="How to share"><Seg value={mode} onChange={v => setMode(v as 'bm' | 'email')} items={[['bm', 'Client’s BM ID'], ['email', 'Email invite']]} /></Field>}
          {mode === 'bm' || !d.email_invites ? <Field label="Client’s Business Manager ID"><input className={inputCls} inputMode="numeric" placeholder="1489220735610042" value={bm} onChange={e => setBm(e.target.value)} /></Field>
            : <Field label="Client’s Facebook email" hint="Email invites always go to the manager, who picks the account."><input className={inputCls} type="email" value={email} onChange={e => setEmail(e.target.value)} /></Field>}
        </> : kind === 'topup' ? <>
          <Field label="Client’s account"><select className={inputCls} value={ext ? 'ext' : act} onChange={e => setAct(e.target.value)}>{mine.map(a => <option key={a.act_id} value={a.act_id}>{a.name || 'Account ' + a.no} · balance {usd(a.left)}</option>)}<option value="ext">Not in the system (type the ID)</option></select></Field>
          {ext && <Field label="Ad account ID" hint="Not in our system: the manager adds it by hand in Ads Manager. Records and the client message are done when they tap Done by hand."><input className={inputCls} inputMode="numeric" placeholder="act_… or the number" value={extAct} onChange={e => setExtAct(e.target.value)} /></Field>}
        </> : <>
          <Field label="Old account (optional)"><select className={inputCls} value={oldAct} onChange={e => setOldAct(e.target.value)}>{olds.map(a => <option key={a.act_id} value={a.act_id}>{a.name || 'Account ' + a.no} · act_{a.act_id}{a.status !== 1 ? ' · ' + a.status_label : ''}</option>)}<option value="other">Not in the system (type the ID)</option><option value="none">Skip (don’t know it)</option></select></Field>
          {(oldAct === 'other' || !olds.length) && <Field label="Old ad account ID (optional)" hint="Leave it empty if you don't know it. The new account is given either way."><input className={inputCls} inputMode="numeric" placeholder="act_… or the number" value={extAct} onChange={e => setExtAct(e.target.value)} /></Field>}
          <Field label="Client’s Business Manager ID" hint="The new account goes to this BM."><input className={inputCls} inputMode="numeric" value={bm} onChange={e => setBm(e.target.value)} /></Field>
          <Field label="New account type"><Seg value={tier} onChange={setTier} items={[['any', 'Same as old'], ['premium', 'Premium'], ['std', '$25']]} /></Field>
          {canPick && <>
            <Field label={(kind as string) === 'replace' ? 'New account' : 'Which account'} hint={!pickAct ? 'The system picks a free one of the type above.' : pickRow && !pickRow.api_ok ? 'This BM’s API is blocked: share it in Meta by hand first. Then this only saves it, sends the client message and the records.' : handOn ? 'Nothing is shared again: it is saved to this client, the client gets the message, records are made.' : 'The system shares this account.'}>
              <select className={inputCls} value={pickAct} onChange={e => setPickAct(e.target.value)} data-pick-acct>
                <option value="">Auto (system picks)</option>
                {(d?.free_list || []).map(x => <option key={x.act_id} value={x.act_id}>{x.name || 'Account ' + x.no} · {x.cat === 'premium' ? 'Premium' : x.cat === 'std' ? '$25' : 'free'}{x.api_ok ? '' : ' · API blocked'} · act_{x.act_id}</option>)}
                {hand && (d?.accounts || []).filter(x => ['assigned', 'invited'].includes(x.state)).map(x => <option key={x.act_id} value={x.act_id}>{x.name || 'Account ' + x.no} · already with this client · act_{x.act_id}</option>)}
              </select>
            </Field>
            {pickAct && <label className="mb-3 flex items-center gap-2.5 text-[14px]"><input type="checkbox" className="h-4 w-4" checked={handOn} disabled={!!pickRow && !pickRow.api_ok} onChange={e => setHand(e.target.checked)} data-pick-hand />I already shared it in Meta by hand</label>}
            {!pickAct && <label className="mb-3 flex items-center gap-2.5 text-[14px] text-tg-sub"><input type="checkbox" className="h-4 w-4" checked={hand} onChange={e => setHand(e.target.checked)} />I already shared one by hand (show this client’s accounts too)</label>}
          </>}
          {(manager || admin) && <Field label="Client’s old balance to add (USD, optional)" hint={`${(d?.credit ?? 0) > 0 ? `Credit already in the system: ${usd(d!.credit)} (added by itself). ` : ''}Type an extra old balance here if the client had one; it goes on the new account (no fee, no sale).`}><input className={inputCls} type="number" inputMode="decimal" placeholder="0" value={rcred} onChange={e => setRcred(e.target.value)} data-repl-credit /></Field>}
          <Field label="What happened (optional)"><input className={inputCls} placeholder="e.g. disabled by Meta" value={rnote} onChange={e => setRnote(e.target.value)} /></Field>
          <p className="mb-3 rounded-xl bg-tg-input px-3.5 py-2.5 text-[12.5px] leading-relaxed text-tg-sub">No payment, no commission. Records keep only our account cost. The client gets “Your account has been successfully replaced” with the new account. If the old account is with this client in our system, its balance comes over as credit.</p>
        </>}
        {kind !== 'replace' && <Field label="Payment">
          <Seg value={method} onChange={setMethod} items={[...(d.credit > 0 ? [['credit', kind === 'topup' ? `Credit ${usd(d.credit)}` : 'From credit'] as [string, string]] : []), ['link', `Pay link${links.length ? ` (${links.length})` : ''}`], ['upi', 'UPI'], ['crypto', 'Crypto direct']]} />
        </Field>}
        {kind !== 'replace' && method === 'link' && (links.length ? <Field label="Paid link"><select className={inputCls} value={code} onChange={e => setCode(e.target.value)}><option value="">Choose…</option>{links.map(l => <option key={l.code} value={l.code}>{l.code} · {l.label} · {usd(l.total)}</option>)}</select></Field>
          : <p className="mb-3 text-[13px] text-tg-sub">No paid crypto link in this chat. Make one with Payment link (it shares / tops up by itself when paid).</p>)}
        {kind === 'topup' && method === 'credit' && <Field label="Credit to put on this account (USD)" hint={`The client has ${usd(d.credit)} credit (old balance). It goes on the account: no fee, no new top-up record. Empty = all of it.`}><input className={inputCls} type="number" inputMode="decimal" placeholder={String(d.credit)} value={paid} onChange={e => setPaid(e.target.value)} data-credit-amt /></Field>}
        {byHand && <Field label={kind === 'topup' ? 'Top-up amount (USD) — goes on the account as it is' : 'Client paid (USD)'} hint={method === 'upi' ? 'Paid by UPI. The manager checks the money arrived, then approves.' : 'Paid in crypto straight to our wallet (not a payment link). The manager checks it arrived, then approves.'}><input className={inputCls} type="number" inputMode="decimal" value={paid} onChange={e => setPaid(e.target.value)} /></Field>}
        {kind === 'topup' && (byHand ? p > 0 : !!link) && <div className="mb-3 space-y-1 rounded-xl bg-tg-input px-4 py-3 text-[14px]">
          <div className="flex justify-between"><span className="text-tg-sub">Added to the account</span><b className="text-tg-ok">{usd(byHand ? add : link!.amount)}</b></div>
          <div className="flex justify-between"><span className="text-tg-sub">Fee (on top)</span><span>+ {usd(byHand ? fee : link!.fee)}</span></div>
          <div className="flex justify-between"><span className="text-tg-sub">Client pays</span><span>{usd(byHand ? payTotal : link!.total)}</span></div>
        </div>}
        <Btn className="w-full !min-h-[44px] !bg-[#3390EC] !text-white" busy={busy} onClick={() => void send()}>{toRequests ? 'Send to Requests' : auto ? (kind === 'account' ? 'Share now' : kind === 'replace' ? 'Replace now' : 'Add top-up now') : 'Send to manager'}</Btn>
        {!auto && <p className="mt-2 text-[12.5px] text-tg-sub">{emailAgent ? 'Email invites are always sent by the manager.' : kind === 'replace' ? 'The manager gives the new account.' : ext ? 'Not in the system: the manager adds it in Ads Manager by hand.' : kind === 'account' && byHand ? 'Payments by hand (UPI / crypto direct) are checked by the manager.' : 'You don’t have auto-approve for this, so the manager approves it.'}</p>}
        </>}
        {d.requests.length > 0 && <>
          <h4 className="mb-1 mt-5 text-[12.5px] font-semibold uppercase tracking-wide text-tg-sub">Requests</h4>
          {d.requests.map(r => <div key={r.id} className="flex items-center gap-2 border-b border-tg-line py-2 text-[13px]"><span className="flex-1">{r.summary}</span><Chip m={REQSTATE} k={r.status} /></div>)}
        </>}
      </>}
    </Sheet>
  );
}

export const useMetaTiers = () => useMemo(() => TIER, []);

/** v165: the card on an account. A business-portfolio card comes from Meta without its number → set it here (or it is taken from the BM's other accounts). */
function CardPick({ api, a, done }: { api: Api; a: { act_id: string; card: string | null; card_guess?: boolean; card_set?: string | null }; done: () => void }) {
  const toast = useToast();
  const [open, setOpen] = useState(false); const [cards, setCards] = useState<string[]>([]); const [v, setV] = useState('');
  useEffect(() => { if (!open) return; setV(a.card_set || ''); void api<{ cards: string[] }>('meta/card_list').then(r => setCards(r.cards)).catch(() => setCards([])); }, [open, api, a.card_set]);
  async function save() {
    try { await api('meta/acct_card', { act_id: a.act_id, card: v }); toast(v ? `Card set: ${v}` : 'Card: automatic again'); setOpen(false); done(); } catch (e) { toast((e as Error).message, 'err'); }
  }
  if (!open) return <span data-card-row>{a.card || '—'}{a.card_guess ? <span className="text-tg-sub"> (from the BM)</span> : a.card_set ? <span className="text-tg-sub"> (set by hand)</span> : null} <button className="text-tg-link" onClick={() => setOpen(true)}>{a.card ? 'Change' : 'Set'}</button></span>;
  return (
    <span className="flex flex-wrap items-center justify-end gap-1.5" data-card-edit>
      <select className="max-w-[180px] rounded-lg bg-tg-input px-2 py-1 text-[13px] text-tg-text" value={v} onChange={e => setV(e.target.value)}>
        <option value="">Automatic (from Meta)</option>
        {cards.map(c => <option key={c} value={c}>{c}</option>)}
      </select>
      <button className="font-semibold text-tg-link" onClick={() => void save()}>Save</button>
      <button className="text-tg-sub" onClick={() => setOpen(false)}>Cancel</button>
    </span>
  );
}
