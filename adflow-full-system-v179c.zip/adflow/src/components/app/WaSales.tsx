'use client';

// WhatsApp sales: sales made on WhatsApp (no Meta event) written down by the admin or the manager, so revenue includes them.
import { useCallback, useEffect, useState } from 'react';
import clsx from 'clsx';
import { Pencil, Trash2 } from 'lucide-react';
import { useToast, Field, inputCls, Btn, usd, ToggleRow } from './ui';

type Api = <T = any>(path: string, body?: unknown) => Promise<T>;
type Row = { id: number; item: string; qty: number; amount: number; list_price?: number | null; cust_name: string | null; cust_phone: string | null; note: string | null; by_name: string | null; agent_id?: number | null; created_at: number };
type Top = { id: number; amount: number; fee: number; note: string | null; created_at: number };
type Data = { items: { k: string; label: string; price: number }[]; totals: Record<'today' | 'month' | 'all', { n: number; v: number }>; today: string; rows: Row[]; topups?: Top[]; topup_pct?: number; premium_pct?: number; agents?: { id: number; name: string; role: string }[] };

export function WaSales({ api }: { api: Api }) {
  const toast = useToast();
  const [d, setD] = useState<Data | null>(null);
  const [item, setItem] = useState('account'); const [qty, setQty] = useState(1); const [amount, setAmount] = useState('');
  const [name, setName] = useState(''); const [phone, setPhone] = useState(''); const [date, setDate] = useState(''); const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const [who, setWho] = useState(''); // v161: admin: who made the sale (Team counts it on them)
  // v129: top-ups sold on WhatsApp (any amount, our fee is the income)
  const [mode, setMode] = useState<'sale' | 'topup'>('sale');
  const [top, setTop] = useState(''); const [fee, setFee] = useState(''); const [feeTyped, setFeeTyped] = useState(false); const [act, setAct] = useState('');
  const [premTop, setPremTop] = useState(false); // v136: a Premium customer pays the Premium top-up fee
  const pct = (premTop ? d?.premium_pct : d?.topup_pct) ?? 3;
  useEffect(() => { if (!feeTyped) setFee(Number(top) > 0 ? String(Math.round(Number(top) * pct) / 100) : ''); }, [top, pct, feeTyped]);
  const load = useCallback(() => api<Data>('wa_sales').then(r => { setD(r); setDate(x => x || r.today); setWho(x => x || String(r.agents?.find(a => a.role === 'manager')?.id || '')); }).catch(e => toast((e as Error).message, 'err')), [api, toast]);
  useEffect(() => { void load(); }, [load]);
  const price = d?.items.find(x => x.k === item)?.price || 0;
  // v144: price per account (per month for the funnel), prefilled with the normal price; total = price × quantity
  const [typed, setTyped] = useState(false);
  useEffect(() => { if (!typed) setAmount(price ? String(price) : ''); }, [price, typed]);
  const unitN = Math.round((Number(amount) || 0) * 100) / 100;
  const totalN = Math.round(unitN * qty * 100) / 100;
  const svcOf = (k: string) => k === 'funnel' ? 'funnel' : k === 'fb_old' || k === 'other' ? 'custom' : 'account';
  const special = svcOf(item) !== 'custom' && price > 0 && unitN > 0 && Math.abs(unitN - price) > 0.004;
  const label = (k: string) => d?.items.find(x => x.k === k)?.label || k;

  async function fix(r: Row) {
    const v = prompt(`Change the amount for ${label(r.item)} (USD)`, String(r.amount));
    if (v == null) return;
    try { await api('wa_sale_edit', { id: r.id, amount: v.replace(/[^\d.]/g, '') }); toast('Amount changed'); await load(); } catch (e) { toast((e as Error).message, 'err'); }
  }

  async function save() {
    if (!(unitN > 0)) { toast('Enter the price', 'err'); return; }
    setBusy(true);
    try {
      await api('wa_sale_add', { item, qty, unit_price: unitN, amount: totalN, name, phone, date, note, agent_id: who || null });
      toast(`Sale added: ${usd(totalN)}${special ? ' (special price)' : ''}`);
      setName(''); setPhone(''); setNote(''); setQty(1); setTyped(false); setAmount(price ? String(price) : '');
      await load();
    } catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); }
  }
  async function saveTop() {
    if (!(Number(top) > 0)) { toast('Enter the top-up amount', 'err'); return; }
    setBusy(true);
    try {
      const r = await api<{ amount: number; fee: number }>('wa_topup_add', { amount: top, fee, name, phone, act_id: act, date, note, tier: premTop ? 'premium' : '' });
      toast(`Top-up added: ${usd(r.amount)} · fee ${usd(r.fee)}`);
      setName(''); setPhone(''); setNote(''); setTop(''); setAct(''); setFeeTyped(false);
      await load();
    } catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); }
  }
  async function delTop(r: Top) {
    if (!confirm(`Delete this WhatsApp top-up?\n\n${usd(r.amount)} · fee ${usd(r.fee)}`)) return;
    try { await api('wa_topup_del', { id: r.id }); toast('Deleted'); await load(); } catch (e) { toast((e as Error).message, 'err'); }
  }
  async function setAgent(r: Row, v: string) {
    try { await api('wa_sale_agent', { id: r.id, agent_id: v || null }); toast(v ? 'Sale moved to ' + (d?.agents?.find(a => String(a.id) === v)?.name || 'the agent') : 'Sale is not on any agent now'); await load(); } catch (e) { toast((e as Error).message, 'err'); }
  }
  const agentSel = (value: string, onChange: (v: string) => void, extra = '') => (
    <select data-wa-agent={extra} value={value} onChange={e => onChange(e.target.value)} className={extra ? clsx('max-w-[160px] rounded-lg bg-tg-input px-2 py-1 text-[12.5px]', value ? 'text-tg-text' : 'text-tg-warn') : inputCls}>
      <option value="">Not on any agent</option>
      {(d?.agents || []).map(a => <option key={a.id} value={a.id}>{a.name} · {a.role === 'manager' ? 'Manager' : 'Agent'}</option>)}
    </select>
  );
  async function del(r: Row) {
    if (!confirm(`Delete this WhatsApp sale?\n\n${label(r.item)} × ${r.qty} · ${usd(r.amount)}${r.cust_name ? ' · ' + r.cust_name : ''}`)) return;
    try { await api('wa_sale_del', { id: r.id }); toast('Deleted'); await load(); } catch (e) { toast((e as Error).message, 'err'); }
  }

  return (
    <div>
      <div className="mb-4 grid grid-cols-3 gap-2">
        {([['today', 'Today'], ['month', 'This month'], ['all', 'All time']] as const).map(([k, l]) => (
          <div key={k} className="af-card px-3 py-3">
            <p className="text-[12.5px] text-tg-sub">{l}</p>
            <p className="text-[19px] font-bold text-tg-ok">{usd(d?.totals[k].v || 0)}</p>
            <p className="text-[12.5px] text-tg-sub">{d?.totals[k].n || 0} sale{d?.totals[k].n === 1 ? '' : 's'}</p>
          </div>
        ))}
      </div>

      <div className="mb-5 af-card p-4">
        <p className="mb-1 text-[16px] font-semibold">Add a WhatsApp sale</p>
        <p className="mb-3 text-[13px] text-tg-sub">Sales made on WhatsApp. Saved in revenue and profit. Nothing is sent to Meta.</p>
        <div className="af-seg mb-4" data-wa-mode>
          {([['sale', 'Sale'], ['topup', 'Top-up']] as const).map(([k, l]) => (
            <button key={k} data-mode={k} aria-pressed={mode === k} onClick={() => setMode(k)} className="af-press">{l}</button>
          ))}
        </div>
        {mode === 'topup' ? (<>
          <ToggleRow k="premium_top" title="Premium customer" sub={`Premium top-up fee: ${d?.premium_pct ?? '—'}% (normal ${d?.topup_pct ?? 3}%)`} on={premTop} onChange={v => { setPremTop(v); setFeeTyped(false); }} />
          <div className="grid grid-cols-2 gap-3">
            <Field label="Top-up amount ($)" hint="Any amount"><input data-top-amount inputMode="decimal" value={top} onChange={e => setTop(e.target.value.replace(/[^\d.]/g, ''))} className={inputCls} placeholder="0" /></Field>
            <Field label="Our fee ($)" hint={`${pct}% by default, can change`}><input data-top-fee inputMode="decimal" value={fee} onChange={e => { setFee(e.target.value.replace(/[^\d.]/g, '')); setFeeTyped(true); }} className={inputCls} placeholder="0" /></Field>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Customer name"><input value={name} onChange={e => setName(e.target.value)} className={inputCls} placeholder="Optional" /></Field>
            <Field label="WhatsApp number"><input inputMode="tel" value={phone} onChange={e => setPhone(e.target.value)} className={inputCls} placeholder="Optional" /></Field>
          </div>
          <Field label="Ad account ID"><input inputMode="numeric" value={act} onChange={e => setAct(e.target.value)} className={inputCls} placeholder="Optional" /></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Date"><input type="date" value={date} max={d?.today} onChange={e => setDate(e.target.value)} className={inputCls} /></Field>
            <Field label="Note"><input value={note} onChange={e => setNote(e.target.value)} className={inputCls} placeholder="Optional" /></Field>
          </div>
          <Btn kind="green" busy={busy} onClick={() => void saveTop()} className="w-full">Add top-up{Number(top) > 0 ? ` · ${usd(Number(top))} + ${usd(Number(fee) || 0)} fee` : ''}</Btn>
        </>) : (<>
        <Field label="Product">
          <select value={item} onChange={e => { setItem(e.target.value); setTyped(false); }} className={inputCls}>
            {(d?.items || []).map(x => <option key={x.k} value={x.k}>{x.label}{x.price ? ` · ${usd(x.price)}` : ''}</option>)}
          </select>
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Quantity"><input type="number" min={1} max={100} value={qty} onChange={e => setQty(Math.max(1, Math.min(100, parseInt(e.target.value) || 1)))} className={inputCls} /></Field>
          <Field label={item === 'funnel' ? 'Price per month ($)' : svcOf(item) === 'custom' ? 'Price each ($)' : 'Price per account ($)'}><input data-wa-unit inputMode="decimal" value={amount} onChange={e => { setAmount(e.target.value.replace(/[^\d.]/g, '')); setTyped(true); }} className={inputCls} placeholder="0" /></Field>
        </div>
        {special && <p data-special-note className="-mt-1 mb-3 rounded-lg bg-tg-warn/15 px-3 py-2 text-[13px] text-tg-warn">Special price (${unitN} instead of ${price})</p>}
        <div className="mb-3 flex justify-between rounded-xl bg-black/20 px-4 py-2.5 text-[14px]"><span className="text-tg-sub">Total</span><b className="tabular-nums">{usd(totalN)}</b></div>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Customer name"><input value={name} onChange={e => setName(e.target.value)} className={inputCls} placeholder="Optional" /></Field>
          <Field label="WhatsApp number"><input inputMode="tel" value={phone} onChange={e => setPhone(e.target.value)} className={inputCls} placeholder="Optional" /></Field>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Date"><input type="date" value={date} max={d?.today} onChange={e => setDate(e.target.value)} className={inputCls} /></Field>
          <Field label="Note"><input value={note} onChange={e => setNote(e.target.value)} className={inputCls} placeholder="Optional" /></Field>
        </div>
        {!!d?.agents?.length && <Field label="Sold by" hint="Team and the agent's dashboard count it. No commission is added.">{agentSel(who, setWho)}</Field>}
        <Btn kind="green" busy={busy} onClick={() => void save()} className="w-full">Add sale{totalN > 0 ? ` · ${usd(totalN)}` : ''}</Btn>
        </>)}
      </div>

      <p className="mb-2 px-1 text-[14px] font-semibold text-tg-sub">WhatsApp sales</p>
      <div className="overflow-hidden af-card">
        {d && !d.rows.length && <p className="px-4 py-6 text-center text-[14px] text-tg-sub">No WhatsApp sales added yet</p>}
        {d?.rows.map(r => (
          <div key={r.id} className="flex items-center gap-3 border-b border-white/[0.04] px-4 py-3 last:border-0">
            <div className="min-w-0 flex-1">
              <p className="truncate text-[15px] font-medium">{label(r.item)}{r.qty > 1 ? ` × ${r.qty}` : ''}</p>
              <p className="truncate text-[13px] text-tg-sub">
                {[r.cust_name, r.cust_phone, new Date(r.created_at).toLocaleDateString(undefined, { day: 'numeric', month: 'short' }), r.by_name && `by ${r.by_name}`].filter(Boolean).join(' · ')}
              </p>
              {!!r.list_price && <p className="truncate text-[12.5px] text-tg-warn">Special price ({usd(r.amount / Math.max(1, r.qty))} instead of {usd(r.list_price)})</p>}
              {r.note && <p className="truncate text-[13px] text-tg-sub">{r.note}</p>}
              {!!d?.agents?.length && <div className="mt-1 flex items-center gap-1.5 whitespace-nowrap text-[12.5px] text-tg-sub">Sold by {agentSel(String(r.agent_id || ''), v => void setAgent(r, v), String(r.id))}</div>}
            </div>
            <button aria-label="Change amount" onClick={() => void fix(r)} className="rounded-lg px-1.5 py-1 text-[15px] font-bold text-tg-ok hover:bg-tg-hover" title="Tap to change the amount">{usd(r.amount)} <Pencil size={13} className="inline -mt-0.5 opacity-60" /></button>
            <button aria-label="Delete sale" onClick={() => void del(r)} className="grid h-9 w-9 place-items-center rounded-full text-tg-sub hover:bg-tg-hover hover:text-tg-bad"><Trash2 size={17} /></button>
          </div>
        ))}
      </div>

      {!!d?.topups?.length && (<>
        <p className="mb-2 mt-5 px-1 text-[14px] font-semibold text-tg-sub">WhatsApp top-ups</p>
        <div className="overflow-hidden af-card" data-wa-topups>
          {d.topups.map(r => (
            <div key={r.id} className="flex items-center gap-3 border-b border-white/[0.04] px-4 py-3 last:border-0">
              <div className="min-w-0 flex-1">
                <p className="truncate text-[15px] font-medium">Top-up {usd(r.amount)}</p>
                <p className="truncate text-[13px] text-tg-sub">{[new Date(r.created_at).toLocaleDateString(undefined, { day: 'numeric', month: 'short' }), (r.note || '').replace(/^WhatsApp · /, '')].filter(Boolean).join(' · ')}</p>
              </div>
              <span className="text-[14px] font-bold text-tg-ok">fee {usd(r.fee)}</span>
              <button aria-label="Delete top-up" onClick={() => void delTop(r)} className="grid h-9 w-9 place-items-center rounded-full text-tg-sub hover:bg-tg-hover hover:text-tg-bad"><Trash2 size={17} /></button>
            </div>
          ))}
        </div>
      </>)}
    </div>
  );
}
