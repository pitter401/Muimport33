'use client';

/** Bridges to the Android app (Capacitor). In a normal browser these fall back gracefully. */
export async function isNative() {
  try { const { Capacitor } = await import('@capacitor/core'); return Capacitor.isNativePlatform(); } catch { return false; }
}

/** v139: push registration that does not hang on the Capacitor "registration" event (it stopped reaching the server):
 *  1. the app's own native methods (AppUpdater.fcmToken + pushPlatform → 'android4') — on every start and resume
 *  2. the Capacitor plugin event as a fallback (old apps)
 *  Every failed step is posted to push_debug ({stage, error, platform, perm, version}), so Admin → Phone notifications
 *  shows why a phone is not registered. A denied notification permission is reported but the token is still registered. */
type PushDebug = (d: { stage: string; error: string; platform?: string; perm?: string; version?: string }) => Promise<unknown>;
export type AppInfo = { version: string; build: string };
export type PushDeps = { isNative: () => Promise<boolean>; updater: () => Promise<Record<string, (o?: unknown) => Promise<any>> | null>; push: () => Promise<any>; build: () => Promise<number>;
  /** v143: the app's version (Capacitor App plugin) — shown in Phones registered and in the "too old" message */
  appInfo?: () => Promise<AppInfo | null>;
  /** v143: how long one native call may take (default 4 s; tests use less) */
  timeoutMs?: number };
const appInfoReal = async (): Promise<AppInfo | null> => { try { const { App } = await import('@capacitor/app'); const i = await App.getInfo(); return { version: String(i.version || ''), build: String(i.build || '') }; } catch { return null; } };
const realDeps: PushDeps = {
  isNative,
  updater: () => updater(),
  push: async () => noThen((await import('@capacitor/push-notifications')).PushNotifications),
  build: async () => { try { const { App } = await import('@capacitor/app'); return Number((await withTimeout(App.getInfo(), 4000, 'App.getInfo')).build) || 1; } catch { return 1; } },
  appInfo: () => withTimeout(appInfoReal(), 4000, 'App.getInfo').catch(() => null),
};
/** v144: a Capacitor plugin object answers EVERY property — including `then` — with a native-call wrapper, so `await plugin`
 *  (or returning it from an async function) waits for a native "then" call that never comes and hangs for ever. That silently
 *  broke push registration, "check this phone" and the status bar. Wrap the plugin so it is not a thenable. */
export function noThen<T extends object>(plugin: T): T {
  return new Proxy(plugin, { get: (t, prop) => (prop === 'then' ? undefined : (t as Record<string | symbol, unknown>)[prop]) }) as T;
}
const errText = (e: unknown) => String((e as { message?: string })?.message || e || 'unknown').slice(0, 300);
/** v143: a native plugin call on an older APK can hang for ever (missing method) — every call gets a time limit. */
export function withTimeout<T>(p: Promise<T> | T, ms = 4000, what = 'the app'): Promise<T> {
  let h: ReturnType<typeof setTimeout> | undefined;
  return Promise.race([
    Promise.resolve(p),
    new Promise<T>((_, rej) => { h = setTimeout(() => rej(new Error(`${what} did not answer within ${Math.round(ms / 1000)} s (old app?)`)), ms); }),
  ]).finally(() => { if (h) clearTimeout(h); });
}
/** Calls one method of the AppUpdater plugin with the time limit; a missing method → a clear error at once. */
async function call<T = any>(p: Record<string, (o?: unknown) => Promise<any>>, m: string, arg?: unknown, ms = 4000): Promise<T> {
  if (typeof p[m] !== 'function') throw new Error(`${m} is missing in this app (old app)`);
  return withTimeout(arg === undefined ? p[m]() : p[m](arg), ms, m);
}
let lastNativeReg = 0;
export type RegExtra = { app_version?: string; build?: string };
export async function setupPush(register: (token: string, platform: string, extra?: RegExtra) => Promise<unknown>, onOpen: (data: Record<string, string>) => void, debug: PushDebug = async () => null, deps: PushDeps = realDeps): Promise<'web' | 'on' | 'denied' | 'error'> {
  if (!(await deps.isNative())) return 'web';
  const ms = deps.timeoutMs ?? 4000;
  const dbg = (stage: string, error: unknown, more: Record<string, string> = {}) => { void debug({ stage, error: errText(error), ...more }).catch(() => null); };
  let platform = '', version = '', nativeOk = false;
  // v143: the app's own version goes with every registration (Phones registered shows it)
  const info = deps.appInfo ? await deps.appInfo().catch(() => null) : null;
  const extra: RegExtra = info ? { app_version: info.version, build: info.build } : {};
  if (info?.version) version = info.version;
  // 1) native token (new app): independent of the plugin event and of the notification permission
  const p = await withTimeout(deps.updater(), ms, 'AppUpdater').catch(() => null);
  if (p) {
    try { const pp = await call(p, 'pushPlatform', undefined, ms); platform = String(pp?.platform || ''); version = String(pp?.version || '') || version; } catch { /* older app: no such method */ }
    if (platform) {
      try {
        const r = await call(p, 'fcmToken', undefined, ms * 3);
        if (!r?.token) throw new Error('no token');
        await register(String(r.token), platform, extra).catch(e => { dbg('register_api', e, { platform, version }); throw e; });
        nativeOk = true; lastNativeReg = Date.now();
      } catch (e) { dbg('fcm_token', e, { platform, version }); }
    }
  }
  // 2) the Capacitor plugin: channels, permission, the tap handler, and its own registration as the fallback
  let perm = 'unknown';
  try {
    const PN = await withTimeout(deps.push(), ms, 'PushNotifications');
    let pr = await withTimeout(PN.checkPermissions(), ms, 'checkPermissions') as { receive: string };
    if (pr.receive === 'prompt' || pr.receive === 'prompt-with-rationale') pr = await withTimeout(PN.requestPermissions(), 120000, 'requestPermissions') as { receive: string }; // the person answers the dialog
    perm = String(pr.receive);
    if (perm !== 'granted') dbg('permission', 'notifications not allowed: ' + perm, { platform, version, perm });
    const build = await withTimeout(deps.build(), ms, 'App.getInfo').catch(() => 1);
    const loud = build >= 2;
    if (loud) await withTimeout(PN.createChannel({ id: 'alerts', name: 'Lead alerts', description: 'New leads and messages (loud)', importance: 5, visibility: 1, sound: 'alert.wav', vibration: true, lights: true, lightColor: '#7C5CFF' }), ms, 'createChannel').catch(() => {});
    else await withTimeout(PN.createChannel({ id: 'chats', name: 'Chats', description: 'New leads and messages', importance: 5, visibility: 1, sound: 'default', vibration: true }), ms, 'createChannel').catch(() => {});
    if (!platform) platform = (await withTimeout(groupedNotifs(), ms, 'clearChat').catch(() => false)) ? 'android4' : (await withTimeout(alarmState(), ms, 'alarmStatus').catch(() => null)) ? 'android3' : loud ? 'android2' : 'android';
    await withTimeout(PN.removeAllListeners(), ms, 'removeAllListeners').catch(() => {});
    let gotToken = false;
    await PN.addListener('registration', (t: { value: string }) => { gotToken = true; if (!nativeOk) void register(t.value, platform, extra).catch(e => dbg('register_js', e, { platform, version, perm })); });
    await PN.addListener('registrationError', (e: unknown) => dbg('registration_error', (e as { error?: string })?.error || e, { platform, version, perm }));
    await PN.addListener('pushNotificationActionPerformed', (a: { notification: { data?: unknown } }) => onOpen((a.notification.data || {}) as Record<string, string>));
    if (!nativeOk) {
      await withTimeout(PN.register(), ms, 'PushNotifications.register');
      // v143: the JS (Capacitor) path never got a token → say so in push_debug, so Phones registered shows why
      const nt = setTimeout(() => { if (!gotToken && !nativeOk) dbg('no_token', `no push token from the app within ${Math.round(ms * 5 / 1000)} s (the Capacitor registration event never came)`, { platform, version, perm }); }, ms * 5);
      (nt as { unref?: () => void })?.unref?.();
    }
  } catch (e) { dbg('plugin', e, { platform, version, perm }); if (!nativeOk) return 'error'; }
  return perm === 'granted' ? 'on' : nativeOk ? 'denied' : perm === 'unknown' ? 'error' : 'denied';
}
/** v143: what the app on this phone is (sent as push_seen on every start, so Admin → Phone notifications can show
 *  "app opened" apart from "registered" — an app opened after its last registration that never registered again = old APK). */
export async function appSeen(deps: Pick<PushDeps, 'isNative' | 'updater' | 'appInfo'> = realDeps) {
  const native = await withTimeout(deps.isNative(), 4000, 'isNative').catch(() => false);
  if (!native) return { native: 0 };
  const info = deps.appInfo ? await deps.appInfo().catch(() => null) : null;
  let platform = '', plugin = 0;
  const p = await withTimeout(deps.updater(), 4000, 'AppUpdater').catch(() => null);
  if (p) { plugin = 1; try { platform = String((await call(p, 'pushPlatform'))?.platform || ''); } catch { /* old app */ } }
  return { native: 1, app_version: info?.version || '', build: info?.build || '', platform, plugin };
}
/** v139: tell the app's Java side where the server is + a login token for its own calls (push_register from Java,
 *  ring reports, the queue of reports that could not be sent). Every start. 'web' / 'old' when there is no such method. */
export async function nativeConfig(apiPath: string, getAuth: () => Promise<{ token?: string; role?: string }>, deps: Pick<PushDeps, 'isNative' | 'updater'> = realDeps) {
  if (!(await deps.isNative())) return 'web';
  const p = await deps.updater().catch(() => null);
  if (!p) return 'old';
  try {
    const a = await getAuth();
    await p.pushConfig({ base: location.origin, api: apiPath, auth: String(a?.token || ''), role: String(a?.role || '') });
    return 'ok';
  } catch { return 'old'; }
}
/** v139: register again when the app comes back to the front (max once per 10 minutes; new app only). */
export function watchPush(register: (token: string, platform: string, extra?: RegExtra) => Promise<unknown>, debug: PushDebug = async () => null) {
  const onVis = async () => {
    if (document.visibilityState !== 'visible' || Date.now() - lastNativeReg < 10 * 60000) return;
    const p = await updater().catch(() => null);
    if (!p) return;
    try { const pp = await call(p, 'pushPlatform'); const r = await call(p, 'fcmToken', undefined, 12000); const i = await realDeps.appInfo!(); if (r?.token) { await register(String(r.token), String(pp?.platform || 'android4'), i ? { app_version: i.version, build: i.build } : {}); lastNativeReg = Date.now(); } }
    catch (e) { void debug({ stage: 'resume', error: errText(e) }).catch(() => null); }
  };
  document.addEventListener('visibilitychange', onVis);
  return () => document.removeEventListener('visibilitychange', onVis);
}

/* ---- v139: "Alerts when the app is closed: check this phone" ---- */
export type PhoneCheck =
  | { kind: 'web' }
  | { kind: 'old'; error: string; version?: string }
  | { kind: 'new'; notif: NotifState; alarm: AlarmState | null; push: { platform: string; ok_at: number; err: string; err_at: number; token_end: string; snd_ver: string; snd_file: string; server: string; queued?: number; auth?: boolean }; version: string };
/** v143: every native call has a ~4 s limit — an old APK (1.3 / 1.4) whose method is missing or never answers gives the
 *  clear "too old" state with the app version, never an endless "Checking this phone…". */
export async function phoneCheck(deps: Pick<PushDeps, 'isNative' | 'updater' | 'appInfo' | 'timeoutMs'> = realDeps): Promise<PhoneCheck> {
  const ms = deps.timeoutMs ?? 4000;
  if (!(await withTimeout(deps.isNative(), ms, 'isNative').catch(() => true))) return { kind: 'web' };
  const ver = async () => { try { return String((await withTimeout(deps.appInfo ? deps.appInfo() : Promise.resolve(null), ms, 'App.getInfo'))?.version || ''); } catch { return ''; } };
  let p: Record<string, (o?: unknown) => Promise<any>> | null = null;
  try { p = await withTimeout(deps.updater(), ms, 'AppUpdater'); } catch (e) { return { kind: 'old', error: errText(e), version: await ver() }; }
  if (!p) return { kind: 'old', error: 'the app has no AppUpdater plugin', version: await ver() };
  try {
    const notif = await call<NotifState>(p, 'notifStatus', undefined, ms);
    const push = await call(p, 'pushStatus', undefined, ms);
    const pp = await call(p, 'pushPlatform', undefined, ms);
    let alarm: AlarmState | null = null;
    try { alarm = await call<AlarmState>(p, 'alarmStatus', undefined, ms); } catch { /* fine */ }
    return { kind: 'new', notif, alarm, push, version: String(pp?.version || '') };
  } catch (e) { return { kind: 'old', error: errText(e), version: await ver() }; }
}
export async function phoneAction(m: 'reRegister' | 'testRing' | 'requestBattery' | 'openAutostart' | 'openAppSettings', deps: Pick<PushDeps, 'updater'> = realDeps) {
  const p = await withTimeout(deps.updater(), 4000, 'AppUpdater').catch(() => null);
  if (!p) throw new Error('This needs the Android app');
  await call(p, m, undefined, m === 'reRegister' ? 15000 : 8000);
}

/** Opens a WhatsApp chat with the message already typed.
 *  In the app: the whatsapp:// link goes straight to WhatsApp (wa.me through the in-app browser loses the text on the redirect).
 *  The text is also copied, so it can be pasted if WhatsApp still opens empty. */
export async function openWhatsApp(phone: string, text?: string | null) {
  const digits = String(phone || '').replace(/\D/g, '');
  if (text) { try { await navigator.clipboard.writeText(text); } catch { /* not allowed — fine */ } }
  const q = `phone=${digits}${text ? '&text=' + encodeURIComponent(text) : ''}`;
  if (await isNative()) { window.location.href = `whatsapp://send?${q}`; return; }
  window.open(`https://api.whatsapp.com/send?${q}`, '_blank', 'noopener');
}

export async function openExternal(url: string) {
  if (await isNative()) {
    try { const { Browser } = await import('@capacitor/browser'); await Browser.open({ url }); return; } catch { /* fall back */ }
  }
  window.open(url, '_blank', 'noopener');
}

/* ---- Background notifications (app 1.3+): battery saver and the phone maker's "Autostart" can hold alerts until the app is opened ---- */
export type NotifState = { battery_ok: boolean; notif_on: boolean; maker: string; autostart: boolean };
async function updater() {
  const { registerPlugin, Capacitor } = await import('@capacitor/core');
  if (!Capacitor.isNativePlatform() || !Capacitor.isPluginAvailable('AppUpdater')) return null;
  return noThen(registerPlugin<Record<string, (o?: unknown) => Promise<any>>>('AppUpdater'));
}
/** v144: the phone's ringer mode for the in-app sound (AppUpdater.alarmStatus → ringer). null = unknown (browser, old app, no answer). */
export async function ringerMode(ms = 1500): Promise<'normal' | 'vibrate' | 'silent' | null> {
  try {
    const p = await withTimeout(updater(), ms, 'AppUpdater'); if (!p) return null;
    const r = await call<{ ringer?: string }>(p, 'alarmStatus', undefined, ms);
    return r && (r.ringer === 'normal' || r.ringer === 'vibrate' || r.ringer === 'silent') ? r.ringer : null;
  } catch { return null; }
}
/** null = not the Android app; 'old' = the app is older than 1.3 (no background-fix screens yet). */
export async function notifState(): Promise<NotifState | 'old' | null> {
  try { const p = await withTimeout(updater(), 4000, 'AppUpdater'); if (!p) return null; return await call<NotifState>(p, 'notifStatus'); } catch { return (await isNative()) ? 'old' : null; }
}
export async function notifAction(m: 'requestBattery' | 'openAutostart' | 'openAppSettings') {
  try { const p = await updater(); if (p) await p[m](); } catch { /* old app */ }
}

/* ---- New-lead sound on silent / vibrate (app with AlertMessagingService): plays on the ALARM volume ---- */
export type AlarmState = { on: boolean; volume?: number; max?: number; ringer?: string };
/** null = not this app version (switch hidden). */
export async function alarmState(): Promise<AlarmState | null> {
  try { const p = await updater(); if (!p || typeof p.alarmStatus !== 'function') return null; return await call<AlarmState>(p, 'alarmStatus'); } catch { return null; }
}
export async function setAlarm(on: boolean) { try { const p = await updater(); if (p) await p.setAlarm({ on }); } catch { /* old app */ } }
export async function testAlarm() { try { const p = await updater(); if (p) await p.testAlarm(); } catch { /* old app */ } }

/* ---- v134: WhatsApp-like notifications (app 1.4+): one per chat; opening the chat removes it ---- */
export async function groupedNotifs() {
  try { const p = await updater(); return !!p && typeof p.clearChat === 'function' && (await import('@capacitor/core')).Capacitor.isPluginAvailable('AppUpdater') && await withTimeout(p.clearChat({ lead: '' }), 4000, 'clearChat').then(() => true, () => false); } catch { return false; }
}
export async function clearChatNotif(leadId: number) { try { const p = await updater(); if (p && typeof p.clearChat === 'function') await p.clearChat({ lead: String(leadId) }); } catch { /* old app */ } }

/* ---- v137: the admin's own notification sound saved on the phone while the app is open (same-origin fetch: no Cloudflare
   block on the native download), so alerts with the app closed already have it. Also tells the app where to send ring reports. ---- */
let savedSnd = '';
export async function syncSound(apiPath: string, ver: string | null | undefined) {
  try {
    const p = await updater();
    if (!p) return 'web';
    const v = String(ver || '');
    const path = v ? `/api/notif-sound?v=${encodeURIComponent(v)}` : '';
    const r = await p.soundConfig({ base: location.origin, api: apiPath, snd: v, snd_url: v ? location.origin + path : '' }).catch(() => null);
    if (!r) return 'old';
    if (!v || r.have || savedSnd === v) return 'have';
    const res = await fetch(path, { cache: 'no-store', credentials: 'same-origin' });
    if (!res.ok || !/^audio\//.test(res.headers.get('content-type') || '')) return 'fetch-failed';
    const bytes = new Uint8Array(await res.arrayBuffer());
    let bin = '';
    for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
    const ok = await p.saveSound({ ver: v, data: btoa(bin) }).catch(() => null);
    if (ok?.ok) { savedSnd = v; return 'saved'; }
    return 'save-failed';
  } catch { return 'error'; }
}
/** On every open / resume: the current sound version from the server → saved on the phone if it changed. */
export function watchSound(apiPath: string, getVer: () => Promise<string | null | undefined>) {
  const run = () => { void getVer().then(v => syncSound(apiPath, v)).catch(() => null); };
  run();
  const onVis = () => { if (document.visibilityState === 'visible') run(); };
  document.addEventListener('visibilitychange', onVis);
  return () => document.removeEventListener('visibilitychange', onVis);
}
