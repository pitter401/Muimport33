'use client';

import { WaSales } from './WaSales';
import { LiveCounter, onResume, setRingOnSilent } from './beepgate';
import { WaPayLinks } from './WaPayLinks';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Menu, Search, X, Wallet, Send, LogOut, Bell, CheckCircle2, MessageSquareText, Circle, CreditCard, Link2, UserRoundCheck, AlarmClock, CircleDollarSign, Plus, Users, Banknote, ArrowLeft, LifeBuoy, PauseCircle, LayoutDashboard, MessagesSquare, ListChecks, Flame, Phone, TrendingUp, MessageCircle, Clock, Star, Package, Sparkles, History, ChevronRight, Check, Ellipsis } from 'lucide-react';
import { AgentsList, CashPayouts, payLine, type TeamRow } from './TeamTools';
import clsx from 'clsx';
import { makeApi, ToastProvider, useToast, Sheet, Field, inputCls, Btn, Toggle, Avatar, Seg, listTime, usd, useInterval, beep, setBeepSound, useBackEntry, useAppear, useBanner, ChanSwitch, Skeleton, daysTxt, TgGlyph, WaGlyph, type ProductRow } from './ui';
import { ChatScreen, ChatActionBar, leadName, remindLabel, waitingC, lastInOf, rowStatus, TierLetter, campOf, previewText, type BarAct } from './chat';
import { StatusBarSync } from './statusbar';
import { setupPush, openExternal, setAlarm, watchSound, watchPush, nativeConfig, appSeen } from './native';
import { AppUpdate } from './appupdate';
import { NotifFix } from './notiffix';
import { TasksList, ForwardSheet } from './tasks';
import { MetaPanel, ChatAccountSheet } from './meta';
import { ManualShareSheet } from './metaprof';
import { CallsList, HotList } from './calls';
import { SoldSheet, TopupSheet, PayLinkSheet, DeleteRequestSheet, priceCtxFor, type SalesCtx } from './sales-sheets';
import { ReelGate, ReelBackground, markPushOpen, pushOpenedRecently, earlyReelPrefetch } from './reel/ReelGate'; // v167: Daily reel
import { ForceUpdate } from './reel/ForceUpdate'; // v167: forced app update
import { useFreshOpen } from './reel/useFreshOpen';
import { TodayReelCard } from './reel/TodayReelCard'; // v168: download my reel (only when the admin allows it)

type Me = SalesCtx & { auto_off?: boolean; wa_on?: boolean; meta_on?: boolean; meta_email?: boolean; auto_acct?: boolean; auto_topup?: boolean; has_manager?: boolean; web_on?: boolean; agent: { role?: string; id: number; name: string; username: string; online: number; receive: number; comm_per_sale: number; comm_premium?: number | null; comm_funnel?: number | null; tg_linked: boolean }; tg_link: string | null; brand: string; paylinks?: boolean; quick_replies: string[]; fu: string[]; quick_replies_f?: string[]; fu_f?: string[]; premium?: { price_account: number; topup_pct: number; quick_replies: string[]; fu: string[] } };
type Chat = { camp_label?: string | null; camp_ad?: string | null; camp_kind?: string | null; line_k?: string | null; line?: string | null; menu?: number | null; service?: string | null; cover_label?: string; cover_for?: string; covered_by?: string; cover_deal?: boolean; read_only?: boolean; ch?: string | null; camp?: string | null; ad?: string | null; tier?: string | null; offer_until?: number | null; biz?: string | null; remind_at?: number | null; remind_due?: number; last_in_at?: number | null; last_out_at?: number | null; noreply_at?: number | null; id: number; name: string | null; tg_name: string | null; tg_username: string | null; phone: string | null; status: string; fu_stage: number; fu_due: number; last_text: string | null; last_at: number | null; niche: string | null; unread: number; last_dir: string | null; contact?: string | null };

export default function AgentApp() { return <ToastProvider><StatusBarSync /><AppUpdate app="agent" /><ForceUpdate app="agent" /><NotifFix app="agent" /><Inner /></ToastProvider>; }

function Inner() {
  const toast = useToast();
  const [authed, setAuthed] = useState<boolean | null>(null);
  const api = useMemo(() => makeApi('/api/agent', () => setAuthed(false)), []);
  const [me, setMe] = useState<Me | null>(null);

  const loadMe = useCallback(async () => {
    try { const r = await api<Me>('me'); setMe(r); setAuthed(true); setBeepSound((r as { snd?: string }).snd); setRingOnSilent((r as { ring_silent?: boolean }).ring_silent); return r; } catch { return null; }
  }, [api]);
  useEffect(() => { void loadMe().then(r => { if (!r) setAuthed(false); }); }, [loadMe]);
  useEffect(() => { earlyReelPrefetch('/api/agent/reel'); }, []); // v168: reel files start downloading before the login check ends

  if (authed === null) return <Splash />;
  if (!authed || !me) return <Login onDone={() => void loadMe()} />;
  return <Main api={api} me={me} reloadMe={loadMe} onLogout={async () => { await fetch('/api/agent/logout', { method: 'POST' }); setAuthed(false); setMe(null); toast('Logged out'); }} />;
}

function Splash() {
  return <div className="grid h-[100dvh] place-items-center bg-tg-bg"><div className="h-10 w-10 animate-spin rounded-full border-2 border-tg-acc border-t-transparent" /></div>;
}

function Login({ onDone }: { onDone: () => void }) {
  const [u, setU] = useState(''); const [p, setP] = useState(''); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setErr(''); setBusy(true);
    try {
      const r = await fetch('/api/agent/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ username: u, password: p }) });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || 'Could not log in');
      onDone();
    } catch (e) { setErr((e as Error).message); } finally { setBusy(false); }
  }
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-tg-bg px-6 text-tg-text">
      <form onSubmit={submit} className="af-page w-full max-w-[360px]">
        <div className="mx-auto mb-6 grid h-20 w-20 place-items-center rounded-full bg-tg-acc"><MessageSquareText size={36} className="text-white" /></div>
        <h1 className="text-center text-[24px] font-semibold">Agent login</h1>
        <p className="mb-7 mt-1.5 text-center text-[14.5px] text-tg-sub">Use the username and password your admin gave you.</p>
        <Field label="Username"><input className={clsx(inputCls, 'bg-tg-panel ring-1 ring-tg-line')} autoCapitalize="none" autoCorrect="off" autoComplete="username" value={u} onChange={e => setU(e.target.value)} /></Field>
        <Field label="Password"><input className={clsx(inputCls, 'bg-tg-panel ring-1 ring-tg-line')} type="password" autoComplete="current-password" value={p} onChange={e => setP(e.target.value)} /></Field>
        <p role="alert" className="mb-3 min-h-[20px] text-[14px] text-tg-bad">{err}</p>
        <Btn type="submit" busy={busy} className="w-full">Log in</Btn>
      </form>
    </div>
  );
}

// v141: the owner's chats that a cover agent has right now live only in "Covered for you" (read-only, not "Needs reply" for the owner)
const coveredAway = (c: Chat) => !!c.covered_by;
const needsReply = (c: Chat) => !coveredAway(c) && (c.status === 'active' || c.status === 'sold') && waitingC(c); // v144 / v147: sold customers who wrote again too
const inFolder = (c: Chat, f: string) => f === 'covered' ? coveredAway(c) : coveredAway(c) ? false : f === 'all' ? c.status !== 'dead' || c.unread > 0 : f === 'unread' ? c.unread > 0 : f === 'reply' ? needsReply(c) : f === 'fu' ? (!!c.fu_due && c.status === 'active') || !!c.remind_due : f === 'sold' ? c.status === 'sold' : c.status === 'dead';
const LIST_FOLDERS = ['all', 'unread', 'reply', 'fu', 'covered', 'sold', 'dead'];
type View = { id: number; name: string; onExit: () => void };
// v167: Hot, Calls, Tasks, Dashboard and Wallet are screens of the bottom tab bar (were folder tabs / sheets)
type Tab = 'chats' | 'tasks' | 'hot' | 'calls' | 'dash' | 'wallet';

function Main({ api: api0, me, reloadMe, onLogout, view }: { api: ReturnType<typeof makeApi>; me: Me; reloadMe: () => Promise<Me | null>; onLogout: () => void; view?: View }) {
  const toast = useToast();
  // v141: manager → Agents → one agent: every call carries ?as_agent=<id> (the server allows it only for the manager)
  const viewId = view?.id;
  const api = useMemo(() => (viewId ? (<T = any,>(p: string, b?: unknown) => api0<T>(p + (p.includes('?') ? '&' : '?') + 'as_agent=' + viewId, b)) as ReturnType<typeof makeApi> : api0), [api0, viewId]);
  const [viewA, setViewA] = useState<TeamRow | null>(null);
  const [agentsOpen, setAgentsOpen] = useState(false);
  const [cashOpen, setCashOpen] = useState(false);
  const [team, setTeam] = useState<TeamRow[]>([]);
  const banner = useBanner();
  const [chats, setChats] = useState<Chat[]>([]);
  const [today, setToday] = useState<{ n: number; rev: number; c: number } | null>(null);
  const [loaded, setLoaded] = useState(false);
  const [folder, setFolder] = useState('all');
  const [tab, setTab] = useState<Tab>('chats');
  const [folderMore, setFolderMore] = useState(false);
  // v131: Telegram / WhatsApp chats (WhatsApp only when it is ON and this agent may get WhatsApp chats)
  const [chan, setChanS] = useState<'tg' | 'wa'>(() => { try { return localStorage.getItem('af_chan') === 'wa' ? 'wa' : 'tg'; } catch { return 'tg'; } });
  const setChan = (c: 'tg' | 'wa') => { setChanS(c); try { localStorage.setItem('af_chan', c); } catch { /* ignore */ } };
  const [q, setQ] = useState('');
  const [searching, setSearching] = useState(false);
  const [open, setOpen] = useState<number | null>(null);
  const [drawer, setDrawer] = useState(false);
  const [sheet, setSheet] = useState<null | 'sold' | 'topup' | 'forward' | 'paylink' | 'acct' | 'del'>(null);
  const [withdraw, setWithdraw] = useState(false);
  const [metaOpen, setMetaOpen] = useState(false);
  const [manualOpen, setManualOpen] = useState(false); // v152: ad account for a client without a chat
  const [waOpen, setWaOpen] = useState(false);
  const [wplOpen, setWplOpen] = useState(false);
  const isMgr = me.agent.role === 'manager';
  const [taskN, setTaskN] = useState(0);
  const [callN, setCallN] = useState(0);
  const [hotN, setHotN] = useState(0);
  const taskRef = useRef(-1);
  const [push, setPush] = useState('');
  const unreadRef = useRef(-1);
  const prevUnread = useRef<Map<number, number> | null>(null);
  // v144: open / resume → the next load sets new baselines (unread, banners, tasks) without a sound or catch-up banners
  const unreadLive = useRef(new LiveCounter()), taskLive = useRef(new LiveCounter());
  useEffect(() => onResume(() => { unreadLive.current.reset(); taskLive.current.reset(); prevUnread.current = null; }), []);
  const openRef = useRef<number | null>(null); openRef.current = open;

  // v167: on a fresh open (cold start / reload, or back after 30+ min away — the same rule as before): the Daily reel first
  // (agents, and the manager when picked; the server decides), then the greeting splash (normal agents only).
  // Opened by tapping a push notification → neither, the chat opens (the reel waits for the next normal fresh open).
  const freshKey = useFreshOpen(!!view);
  const splashKey = freshKey;
  const [stage, setStage] = useState<'reel' | 'splash' | 'done'>(view ? 'done' : 'reel');
  useEffect(() => { if (freshKey > 1 && !view) setStage('reel'); }, [freshKey, view]);

  const load = useCallback(async () => {
    try {
      const r = await api<{ chats: Chat[]; calls_todo?: number; hot_n?: number; today?: { n: number; rev: number; c: number } }>('chats');
      setChats(r.chats); setLoaded(true); setCallN(r.calls_todo || 0); setHotN(r.hot_n || 0); setToday(r.today || null);
      if (viewId) return; // v141: looking at an agent's chats → no sounds, banners or title for the manager
      const u = r.chats.reduce((a, c) => a + (c.unread > 0 ? 1 : 0), 0);
      if (unreadLive.current.next(u)) beep();
      unreadRef.current = u;
      // v136: a chat that got new messages (and is not open) → banner at the top
      const prev = prevUnread.current;
      if (prev) {
        const grew = r.chats.filter(c => c.unread > (prev.get(c.id) || 0) && c.id !== openRef.current).sort((a, b) => (b.last_at || 0) - (a.last_at || 0))[0];
        if (grew) banner({ key: 'c' + grew.id, name: leadName(grew), text: grew.last_text || 'New message', avatarId: grew.id, onOpen: () => openChatRef.current(grew.id) });
      }
      prevUnread.current = new Map(r.chats.map(c => [c.id, c.unread]));
      document.title = (u ? `(${u}) ` : '') + 'Chats';
    } catch { /* keep last list */ }
    if (isMgr && !viewId) try {
      const t = await api<{ tasks: unknown[] }>('tasks?status=open');
      if (taskLive.current.next(t.tasks.length)) beep();
      taskRef.current = t.tasks.length; setTaskN(t.tasks.length);
    } catch { /* ignore */ }
  }, [api, isMgr, banner, viewId]);
  useEffect(() => { if (isMgr) void api<{ agents: TeamRow[] }>('team').then(r => setTeam(r.agents)).catch(() => {}); }, [api, isMgr, viewId]);
  useBackEntry(!!viewA, () => setViewA(null));
  useEffect(() => { void load(); }, [load]);
  useInterval(() => void load(), 4000);

  const openChat = useCallback((id: number) => {
    setOpen(id); setDrawer(false);
    setChats(cs => cs.map(c => (c.id === id ? { ...c, unread: 0 } : c)));
  }, []);
  const openChatRef = useRef(openChat); openChatRef.current = openChat;
  const closeChat = useCallback(() => { setOpen(null); void load(); }, [load]);
  // v136: Android Back closes the chat / the drawer (one history stack with the sheets)
  useBackEntry(!!open, closeChat);
  useBackEntry(drawer, () => setDrawer(false));
  useBackEntry(tab !== 'chats', () => setTab('chats')); // v167: Back on another tab → Chats

  useEffect(() => {
    if (viewId) return; // v141: the agents view never sets up the phone again
    void setAlarm(true); // v134: the ring-on-silent switch is the admin's (server decides per alert) — the phone's own switch stays on
    // v139: the phone registers itself (native token + platform, Capacitor as the fallback); failed steps go to push_debug
    const reg = (t: string, platform: string, extra?: { app_version?: string; build?: string }) => api('push_register', { token: t, platform, ...(extra || {}) }); // v143: + app version
    const dbg = (d: Record<string, unknown>) => api('push_debug', d);
    void nativeConfig('/api/agent/', () => api('native_auth', {}));
    void appSeen().then(i => api('push_seen', i)).catch(() => null); // v143: "app opened" (shown apart from "registered")
    void setupPush(reg, d => { if (d.lead_id) { markPushOpen(); setStage('done'); openChat(Number(d.lead_id)); } }, dbg).then(setPush); // v167: a push tap skips the reel + splash
    const offPush = watchPush(reg, dbg);
    const offSound = watchSound('/api/agent/', () => api<{ snd?: string }>('me').then(r => r.snd || '')); // v137: own sound kept on the phone
    return () => { offPush(); offSound(); };
  }, [api, openChat, viewId]);

  const qd = (() => { let d = q.replace(/\D/g, ''); if (d.length === 12 && d.startsWith('91')) d = d.slice(2); if (d.length === 11 && d.startsWith('0')) d = d.slice(1); return d.length >= 4 ? d : ''; })();
  // the open chat's prices: Premium price + fee, retargeting offer price (sheets)
  const oc = open ? chats.find(c => c.id === open) : undefined;
  const openPremium = oc?.tier === 'premium';
  const meX: Me = priceCtxFor(me, oc);
  const waOn = !!me.wa_on;
  const cur: 'tg' | 'wa' = waOn ? chan : 'tg';
  const inChan = (c: Chat) => (c.ch === 'wa' ? 'wa' : 'tg') === cur;
  const chUnread = (x: 'tg' | 'wa') => chats.filter(c => (c.ch === 'wa' ? 'wa' : 'tg') === x && c.unread > 0).length;
  const list = chats.filter(c => inChan(c) && inFolder(c, folder) && (!q || `${leadName(c)} ${c.phone || ''} ${c.tg_username || ''} #${c.id}`.toLowerCase().includes(q.toLowerCase()) || (!!qd && String(c.phone || '').replace(/\D/g, '').includes(qd))))
    .sort(folder === 'reply' ? (a, b) => lastInOf(a) - lastInOf(b) // oldest waiting first (senior-ui: same "last in" as the folder, so bug-7 rows sort by their real wait)
      : (a, b) => ((b.unread > 0 ? 1 : 0) - (a.unread > 0 ? 1 : 0)) || ((b.last_at || 0) - (a.last_at || 0)));
  // v167: 5 chat folders up front; Covered and Dead behind "More"
  const folders: [string, string][] = [['all', 'All'], ['reply', 'Needs reply'], ['unread', 'Unread'], ['fu', 'Follow-up'], ['sold', 'Sold']];
  const extraFolders: [string, string][] = [['covered', viewId ? 'Covered' : 'Covered for you'], ['dead', 'Dead']];
  const counts: Record<string, number> = Object.fromEntries(LIST_FOLDERS.map(f => [f, f === 'all' ? 0 : chats.filter(c => inChan(c) && inFolder(c, f)).length]));
  const unreadChats = chats.filter(c => c.unread > 0).length;
  const appear = useAppear(chats.map(c => c.id));

  async function setOnline(v: boolean) {
    try { await api('online', { online: v }); await reloadMe(); toast(v ? 'You are online. New leads will come to you.' : 'You are away. New leads go to online agents first.'); }
    catch (e) { toast((e as Error).message, 'err'); }
  }

  // v167: the chat dock — Pay link · Ad account · Mark sold (manager) / Send to manager (agent) · More (everything else)
  type Act = BarAct;
  const barFor = (lead: { status?: string; remind_at?: number | null } | null, remind: () => void): Act[] => {
    const rOn = !!lead?.remind_at && lead.remind_at > Date.now();
    const a: Act[] = [];
    if (me.paylinks) a.push({ k: 'paylink', label: 'Payment link', icon: <Link2 size={15} />, onClick: () => setSheet('paylink'), tone: 'link' });
    if (me.meta_on || (me as any).meta_acct) a.push({ k: 'acct', label: 'Ad account', icon: <CreditCard size={15} />, onClick: () => setSheet('acct') });
    if (isMgr) a.push({ k: 'sold', label: lead?.status === 'sold' ? 'Sell again' : 'Mark sold', icon: <CircleDollarSign size={15} />, onClick: () => setSheet('sold'), tone: 'green', on: lead?.status === 'sold' });
    if (me.has_manager && !isMgr) a.push({ k: 'forward', label: 'Send to manager', icon: <UserRoundCheck size={15} />, onClick: () => setSheet('forward') });
    a.push({ k: 'topup', label: 'Add topup', icon: <Plus size={15} />, onClick: () => setSheet('topup') });
    a.push({ k: 'remind', label: rOn ? remindLabel(lead!.remind_at!) : 'Remind me', icon: <AlarmClock size={15} />, onClick: remind, on: rOn });
    return a;
  };

  const tabs: [Tab, string, React.ReactNode, number, boolean?][] = [
    ['chats', 'Chats', <MessagesSquare key="i" size={23} />, unreadChats, true],
    ...(isMgr && !viewId ? [['tasks', 'Tasks', <ListChecks key="i" size={23} />, taskN] as [Tab, string, React.ReactNode, number]] : []),
    ['hot', 'Hot', <Flame key="i" size={23} />, hotN],
    ['calls', 'Calls', <Phone key="i" size={22} />, callN],
    ...(!viewId ? [['dash', 'Dashboard', <LayoutDashboard key="i" size={23} />, 0] as [Tab, string, React.ReactNode, number]] : []),
    ...(!viewId && !isMgr ? [['wallet', 'Wallet', <Wallet key="i" size={23} />, 0] as [Tab, string, React.ReactNode, number]] : []),
  ];
  const tabTitle: Record<Tab, string> = { chats: 'Chats', tasks: 'Tasks', hot: 'Hot leads', calls: 'Calls', dash: 'Dashboard', wallet: 'Wallet' };
  const statusTxt = me.agent.online ? (me.auto_off ? 'Online · not receiving new leads' : 'Online · receiving leads') : 'Away';
  const grey = tab === 'dash' || tab === 'wallet';

  return (
    <div className="flex h-[100dvh] overflow-hidden bg-tg-bg text-tg-text">
      {/* list column */}
      <div className={clsx('relative flex w-full flex-col border-r border-tg-sep md:w-[380px] md:shrink-0', grey ? 'bg-tg-bg' : 'bg-tg-panel', open && 'hidden md:flex')} data-chan={cur}>
        <div className={clsx('flex items-center gap-1 px-1.5 pb-1 pt-[calc(6px+env(safe-area-inset-top))]', grey ? 'bg-tg-bg' : 'bg-tg-panel')}>
          {searching && tab === 'chats' ? (
            <>
              <button onClick={() => { setSearching(false); setQ(''); }} className="grid h-10 w-10 place-items-center rounded-full hover:bg-tg-hover" aria-label="Close search"><X size={22} /></button>
              <input autoFocus value={q} onChange={e => setQ(e.target.value)} placeholder="Search name or number" className="h-10 flex-1 bg-transparent text-[17px] outline-none placeholder:text-tg-sub" />
            </>
          ) : (
            <>
              {view ? <button onClick={view.onExit} className="grid h-10 w-10 shrink-0 place-items-center rounded-full hover:bg-tg-hover" aria-label="Back to Agents"><ArrowLeft size={22} /></button>
                : <button onClick={() => setDrawer(true)} className="relative grid h-10 w-10 shrink-0 place-items-center rounded-full hover:bg-tg-hover" aria-label={taskN ? `Menu, ${taskN} tasks` : 'Menu'}><Menu size={22} />{isMgr && taskN > 0 && <span className="absolute right-1.5 top-1.5 h-2.5 w-2.5 rounded-full bg-tg-orange ring-2 ring-tg-panel" data-menu-dot />}</button>}
              <div className="min-w-0 flex-1 px-1 text-center">
                <p className="truncate text-[17px] font-semibold leading-tight" data-view-title={view ? view.id : undefined}>{view && tab === 'chats' ? `${view.name}’s chats` : tabTitle[tab]}</p>
                {tab === 'chats' && <p className="mt-0.5 flex items-center justify-center gap-1.5 truncate text-[12.5px] text-tg-sub" data-agent-sub>
                  {view ? <span className="truncate">You see what {view.name} sees · replies show as {me.agent.name} (manager) · no alerts</span>
                    : <><span className={clsx('h-[7px] w-[7px] shrink-0 rounded-full', me.agent.online ? 'bg-[#34C759]' : 'bg-tg-sub/60')} aria-hidden /><span className="truncate">{statusTxt}</span></>}
                </p>}
              </div>
              {tab === 'chats' ? <button onClick={() => setSearching(true)} className="grid h-10 w-10 shrink-0 place-items-center rounded-full hover:bg-tg-hover" aria-label="Search"><Search size={21} /></button> : <span className="w-10 shrink-0" />}
            </>
          )}
        </div>
        {/* v141: receiving leads was turned off automatically (3 missed chats in a row) → one tap turns it back on */}
        {!view && me.auto_off && tab === 'chats' && (
          <button data-autooff-banner onClick={async () => { try { await api('receive_on', {}); await reloadMe(); toast('Receiving new leads is ON again'); } catch (e) { toast((e as Error).message, 'err'); } }}
            className="af-note warn mx-2 mb-1 mt-1 items-start text-left leading-snug text-tg-text">
            <PauseCircle size={20} className="mt-px shrink-0 text-tg-orange" aria-hidden />
            <span><b>You were not active, so receiving new leads was turned off.</b> <span className="font-semibold text-tg-link">Tap to turn it back on.</span></span>
          </button>
        )}
        {tab === 'chats' && <>
          {!view && today && <button type="button" onClick={() => setTab('dash')} data-dash-btn className="af-press mx-2 mb-1.5 mt-1.5 flex items-center gap-2.5 rounded-xl bg-tg-input px-3 py-2 text-left">
            <span className="af-tile bg-[linear-gradient(180deg,#5fd97a,#2fb14f)]"><TrendingUp size={17} aria-hidden /></span>
            <span className="min-w-0 flex-1"><span className="block text-[11.5px] leading-tight text-tg-sub">Today</span>
              {/* v168 F5: no sale yet today → the encouraging line, never "0 sales · $0" */}
              {!(today.n > 0) ? <span className="block truncate text-[15px] font-semibold" data-today-cheer>Your next sale is one chat away</span>
              : <span className="block truncate text-[15px] font-semibold af-num">{today.n} sale{today.n === 1 ? '' : 's'}{isMgr ? (today.rev ? <><span className="text-tg-sub"> · </span><span className="text-tg-ok">{usd(today.rev)}</span></> : null) : <><span className="text-tg-sub"> · </span><span className="text-tg-ok">{usd(today.c)} earned</span></>}</span>}</span>
            <span className="flex shrink-0 items-center gap-0.5 text-[13.5px] font-semibold text-tg-link">Dashboard<ChevronRight size={16} aria-hidden /></span>
          </button>}
          {waOn && <ChanSwitch className="mx-2 mb-1 mt-1" value={cur} onChange={setChan} unread={chUnread} id={view ? 'chsw_view' : 'chsw_agent'} />}
          <div className="relative flex border-b border-tg-sep">
            <div className="flex min-w-0 flex-1 gap-0.5 overflow-x-auto px-1.5 [mask-image:linear-gradient(to_right,#000_calc(100%-14px),transparent)] [scrollbar-width:none]" data-folders>
              {[...folders, ...extraFolders.filter(([f]) => f === folder)].map(([f, l]) => (
                <button key={f} onClick={e => { setFolder(f); e.currentTarget.scrollIntoView({ inline: 'nearest', block: 'nearest' }); }} data-folder={f} className={clsx('relative flex shrink-0 items-center gap-1.5 px-2.5 pb-2.5 pt-2 text-[14.5px] font-medium', folder === f ? 'text-tg-link' : 'text-tg-sub')}>
                  {l}{counts[f] > 0 && <span key={counts[f]} className={clsx('af-pop af-cnt h-[18px] min-w-[18px] rounded-full px-[5px] text-[11.5px] font-semibold', f === 'reply' ? 'bg-tg-badge text-white' : 'bg-tg-sub/20 text-tg-text')}><i className="af-n">{counts[f]}</i></span>}
                  {folder === f && <span className="absolute inset-x-1.5 bottom-0 h-[3px] rounded-t-full bg-tg-link" />}
                </button>
              ))}
            </div>
            <button onClick={() => setFolderMore(v => !v)} aria-label="More folders" aria-expanded={folderMore} data-folder-more className="grid w-10 shrink-0 place-items-center text-tg-sub"><Ellipsis size={20} /></button>
            {folderMore && <>
              <div className="fixed inset-0 z-40" onClick={() => setFolderMore(false)} />
              <div className="af-menu absolute right-1.5 top-10 z-50 min-w-[210px] overflow-hidden rounded-xl bg-tg-menu py-1 shadow-2xl ring-1 ring-tg-sep" role="menu">
                {extraFolders.map(([f, l]) => (
                  <button key={f} role="menuitem" data-folder={f} onClick={() => { setFolder(f); setFolderMore(false); }} className={clsx('flex w-full items-center gap-2 px-4 py-3 text-left text-[15px] hover:bg-tg-hover', folder === f ? 'text-tg-link' : 'text-tg-text')}>
                    <span className="flex-1">{l}</span>{counts[f] > 0 && <span className="rounded-full bg-tg-sub/20 px-1.5 text-[11.5px] font-semibold">{counts[f]}</span>}
                  </button>
                ))}
              </div>
            </>}
          </div>
        </>}
        <div className="min-h-0 flex-1 overflow-y-auto pb-2">
          <div key={tab + folder + cur} className="af-page">
          {tab === 'calls' ? <CallsList api={api} onCount={setCallN} />
            : tab === 'hot' ? <HotList api={api} onCount={setHotN} onOpenChat={id => { if (chats.some(c => c.id === id)) openChat(id); else toast('This chat belongs to another agent'); }} />
            : tab === 'tasks' ? <div className="p-3"><TasksList api={api} onOpenChat={id => { if (chats.some(c => c.id === id)) openChat(id); else toast('This chat is with the agent who sent it. They’ll get your update.'); }} /></div>
            : tab === 'dash' ? <div className="px-4 pb-4"><TodayReelCard api={api} />{/* v168 */}<Dashboard api={api} isMgr={isMgr} onPayout={() => { setTab('wallet'); setWithdraw(true); }} onHot={() => setTab('hot')} onWallet={() => setTab('wallet')} /></div>
            : tab === 'wallet' ? <div className="px-4 pb-4"><WalletScreen api={api} onDash={() => setTab('dash')} withdraw={withdraw} setWithdraw={setWithdraw} /></div>
            : !loaded ? <div className="space-y-1 p-2">{Array.from({ length: 7 }, (_, i) => <div key={i} className="af-skel flex items-center gap-3 px-1 py-2"><span className="h-[54px] w-[54px] rounded-full bg-tg-input" /><span className="flex-1 space-y-2"><span className="block h-3.5 w-2/5 rounded bg-tg-input" /><span className="block h-3 w-4/5 rounded bg-tg-input" /></span></div>)}</div>
            : !list.length ? <Empty folder={folder} any={chats.length > 0} />
              : list.map(c => { const ap = appear(c.id); return <Row key={c.id} c={c} active={open === c.id} onClick={() => openChat(c.id)} cls={ap.className} style={ap.style} />; })}
          </div>
        </div>
        {/* v167: bottom tab bar */}
        <nav className="af-tabbar relative z-20 flex shrink-0 pb-[env(safe-area-inset-bottom)]" data-tabbar>
          {tabs.map(([k, l, icon, n, blue]) => (
            <button key={k} onClick={() => { setTab(k); if (k === 'chats' && tab === 'chats') setFolder('all'); }} data-tab={k} aria-current={tab === k ? 'page' : undefined}
              className={clsx('relative flex min-w-0 flex-1 flex-col items-center gap-0.5 pb-1.5 pt-2 text-[10.5px] font-medium', tab === k ? 'text-tg-link' : 'text-tg-sub')}>
              {icon}<span className="max-w-full truncate px-0.5">{l}</span>
              {n > 0 && <span key={n} className={clsx('af-tbadge af-pop', blue && 'blue')}><i className="af-n">{n > 99 ? '99+' : n}</i></span>}
            </button>
          ))}
        </nav>
      </div>

      {/* chat column */}
      <div className={clsx('min-w-0 flex-1', !open && 'hidden md:block')}>
        {open ? (
          <ChatScreen key={open} role="agent" api={api} leadId={open} canRetype={isMgr} showAgents={!!view} onBack={() => (window.innerWidth < 768 ? history.back() : closeChat())} onChanged={() => void load()}
            productMsgs={(me as any).product_msgs} quickReplies={me.quick_replies} followups={me.fu} quickRepliesF={me.quick_replies_f} followupsF={me.fu_f} quickRepliesP={me.premium?.quick_replies} followupsP={me.premium?.fu}
            barHas={['remind']}
            extraMenu={(lead, reload) => { soldReload.current = reload; return [
              // v135: junk chat → ask the admin to delete it
              lead?.del_req_at ? { label: 'Delete requested (waiting for admin)', onClick: () => toast('Already sent to the admin') }
                : { label: 'Request chat delete', danger: true, onClick: () => setSheet('del') },
              // v141: the manager moves a chat for good (also ends a cover)
              ...(isMgr ? team.filter(a => a.id !== lead?.agent_id).map(a => ({ label: `Assign to ${a.name}`, onClick: async () => { try { await api('assign', { lead_id: lead!.id, agent_id: a.id }); toast(`Assigned to ${a.name}`); reload(); void load(); } catch (e) { toast((e as Error).message, 'err'); } } })) : []),
            ]; }}
            actionBar={(lead, act) => <ChatActionBar items={barFor(lead, act.remind)} />} />
        ) : (
          <div className="grid h-full place-items-center bg-tg-bg">
            <span className="tg-pill rounded-full px-4 py-1.5 text-[14px]">Select a chat to start messaging</span>
          </div>
        )}
      </div>

      {!view && <Drawer open={drawer} onClose={() => setDrawer(false)} me={me} push={push} today={today} onAgents={isMgr ? () => { setDrawer(false); setAgentsOpen(true); } : undefined} onCash={isMgr ? () => { setDrawer(false); setCashOpen(true); } : undefined} taskN={isMgr ? taskN : 0} onTasks={isMgr ? () => { setDrawer(false); setTab('tasks'); } : undefined} onOnline={setOnline} onWallet={() => { setDrawer(false); setTab('wallet'); }} onDash={() => { setDrawer(false); setTab('dash'); }} onLogout={onLogout} onMeta={isMgr ? () => { setDrawer(false); setMetaOpen(true); } : undefined} onWa={isMgr ? () => { setDrawer(false); setWaOpen(true); } : undefined} onWaLink={me.paylinks ? () => { setDrawer(false); setWplOpen(true); } : undefined} onManual={(me as { meta_on?: boolean }).meta_on ? () => { setDrawer(false); setManualOpen(true); } : undefined} />}
      <Sheet open={agentsOpen} onClose={() => setAgentsOpen(false)} title="Agents" wide>{agentsOpen && <AgentsList api={api} onPick={a => { setAgentsOpen(false); setViewA(a); }} />}</Sheet>
      <Sheet open={cashOpen} onClose={() => setCashOpen(false)} title="Record cash payout" wide>{cashOpen && <CashPayouts api={api} role="manager" />}</Sheet>
      {viewA && <div className="fixed inset-0 z-[140] bg-tg-bg" data-agent-view={viewA.id}><Main api={api0} me={me} reloadMe={reloadMe} onLogout={onLogout} view={{ id: viewA.id, name: viewA.name, onExit: () => (window.innerWidth < 768 ? history.back() : setViewA(null)) }} /></div>}
      <Sheet open={waOpen} onClose={() => setWaOpen(false)} title="WhatsApp sales" wide>{waOpen && <WaSales api={api} />}</Sheet>
      <Sheet open={wplOpen} onClose={() => setWplOpen(false)} title="Payment link (no chat)" wide>{wplOpen && <WaPayLinks api={api} />}</Sheet>
      <SoldSheet open={sheet === 'sold'} onClose={() => setSheet(null)} api={api} me={meX} premium={openPremium} stdPrice={me.price_account} leadId={open} forName={oc ? leadName(oc) : undefined} forId={oc?.id} forLine={oc} onDone={() => { soldReload.current?.(); void load(); }} />
      <TopupSheet open={sheet === 'topup'} onClose={() => setSheet(null)} api={api} me={meX} leadId={open} onDone={() => { soldReload.current?.(); }} />
      <ForwardSheet open={sheet === 'forward'} onClose={() => setSheet(null)} api={api} leadId={open} onDone={() => { soldReload.current?.(); }} />
      <PayLinkSheet open={sheet === 'paylink'} onClose={() => setSheet(null)} api={api} me={meX} premium={openPremium} stdPrice={me.price_account} leadId={open} onDone={() => { soldReload.current?.(); }} />
      <DeleteRequestSheet open={sheet === 'del'} onClose={() => setSheet(null)} api={api} leadId={open} onDone={() => { soldReload.current?.(); }} />
      <ChatAccountSheet open={sheet === 'acct'} onClose={() => setSheet(null)} api={api} leadId={open} pct={meX.topup_pct} autoAcct={me.auto_acct} autoTopup={me.auto_topup} manager={isMgr} onDone={() => { soldReload.current?.(); }} />
      <Sheet open={metaOpen} onClose={() => setMetaOpen(false)} title="Ad accounts" wide full>{metaOpen && <MetaPanel api={api} isAdmin={false} />}</Sheet>
      <ManualShareSheet api={api} open={manualOpen} onClose={() => setManualOpen(false)} path="meta_manual" manager={isMgr} />
      {stage === 'reel' && !view && <ReelGate key={'reel' + freshKey} api="/api/agent/reel" cover={!isMgr} onDone={r => setStage(r.splash && !isMgr && !pushOpenedRecently() ? 'splash' : 'done')} />}
      {stage === 'splash' && !view && !isMgr && <AgentSplash key={splashKey} api={api} name={me.agent.name} onDone={() => setStage('done')} />}
      {!view && <ReelBackground api="/api/agent/reel" />}
    </div>
  );
}
const soldReload: { current: (() => void) | null } = { current: null };

function Row({ c, active, onClick, cls, style }: { c: Chat; active: boolean; onClick: () => void; cls?: string; style?: React.CSSProperties }) {
  const name = leadName(c);
  const st = rowStatus(c);
  const camp = campOf(c).label;
  return (
    <button onClick={onClick} style={style} className={clsx('flex w-full items-center gap-3 px-2.5 text-left', active ? 'bg-tg-active' : 'hover:bg-tg-hover active:bg-tg-hover', cls)} data-row={c.id}>
      <span className="relative shrink-0">
        <Avatar name={name} id={c.id} size={54} />
        <span className="absolute -bottom-0.5 -right-0.5 grid place-items-center rounded-full ring-2 ring-tg-panel" data-chan-badge={c.ch === 'wa' ? 'wa' : 'tg'}>{c.ch === 'wa' ? <WaGlyph size={17} /> : <TgGlyph size={17} />}</span>
      </span>
      <span className="min-w-0 flex-1 border-b border-tg-sep py-2">
        <span className="flex items-center gap-1.5">
          <span className={clsx('min-w-0 truncate text-[16px] font-semibold', c.unread > 0 ? 'text-tg-strong' : 'text-tg-text')}>{name}</span>
          <TierLetter l={c} />
          <span className="flex-1" />
          <span className={clsx('shrink-0 text-[12.5px] af-num', c.unread > 0 ? 'text-tg-link' : 'text-tg-sub')}>{listTime(c.last_at)}</span>
        </span>
        <span className="mt-px flex items-center gap-2">
          <span className={clsx('min-w-0 flex-1 truncate text-[14.5px]', c.unread > 0 ? 'text-tg-text' : 'text-tg-sub')}>
            {c.last_dir === 'out' && <span className="text-tg-link">You: </span>}{previewText(c.last_text) || 'New chat'}
          </span>
          {c.unread > 0 && <span key={c.unread} className="af-pop af-badge blue min-w-[22px] h-[22px] rounded-full text-[12.5px]"><i className="af-n">{c.unread}</i></span>}
        </span>
        {/* v167: one quiet meta line, coloured only when it needs action */}
        <span className="mt-0.5 flex min-w-0 items-center gap-1.5 text-[12.5px] text-tg-sub" data-row-meta>
          {c.cover_label && <span data-cover-badge className="inline-flex min-w-0 shrink items-center gap-1 truncate font-semibold text-tg-orange"><LifeBuoy size={12} className="shrink-0" aria-hidden />{c.cover_label}</span>}
          {c.cover_label && <span aria-hidden>·</span>}
          <span data-status={st.tone || 'plain'} className={clsx('inline-flex shrink-0 items-center gap-1 whitespace-nowrap', st.tone === 'bad' ? 'font-semibold text-tg-bad' : st.tone === 'warn' ? 'font-medium text-tg-orange' : st.tone === 'ok' ? 'font-medium text-tg-ok' : st.tone === 'acc' ? 'text-tg-link' : '')}>
            {st.tone === 'bad' && <span className="h-[7px] w-[7px] rounded-full bg-tg-bad" aria-hidden />}{st.tone === 'warn' && <AlarmClock size={12} aria-hidden />}{st.tone === 'ok' && <Check size={12} strokeWidth={3} aria-hidden />}{st.t}
          </span>
          {camp && <><span aria-hidden>·</span><span className="min-w-0 truncate" data-camp>{camp}</span></>}
        </span>
      </span>
    </button>
  );
}

function Empty({ folder, any }: { folder: string; any: boolean }) {
  const t: Record<string, [string, string]> = {
    covered: ['Nothing covered right now', 'When you are away, other agents cover your customers. Those chats show here (read-only) until they come back to you.'],
    all: any ? ['No open chats', 'Chats that need you show up here.'] : ['No chats yet', 'New leads appear here as soon as they message.'],
    unread: ['All caught up', 'You have read every message.'], reply: ['Nobody is waiting', 'Every customer has a reply.'], fu: ['No follow-ups due', 'Follow-ups and reminders show here when they are due.'],
    sold: ['No sales here yet', 'Sales you make through payment links appear here. Paid by UPI? Send to manager.'], dead: ['No dead chats', 'Chats with no reply after all follow-ups move here. A new message from the client reopens them.'],
  };
  const [h, p] = t[folder] || ['Nothing here', ''];
  return (
    <div className="px-8 py-14 text-center" data-empty={folder}>
      <span className="mx-auto mb-3 grid h-14 w-14 place-items-center rounded-full bg-tg-accsoft text-tg-link"><MessagesSquare size={26} aria-hidden /></span>
      <p className="text-[16px] font-semibold">{h}</p>
      <p className="mt-1 text-[13.5px] leading-relaxed text-tg-sub">{p}</p>
    </div>
  );
}

function Drawer({ open, onClose, me, push, taskN, today, onTasks, onOnline, onWallet, onDash, onLogout, onMeta, onWa, onWaLink, onAgents, onCash, onManual }: { open: boolean; onClose: () => void; me: Me; push: string; taskN: number; today: { n: number; rev: number; c: number } | null; onTasks?: () => void; onOnline: (v: boolean) => void; onWallet: () => void; onDash: () => void; onLogout: () => void; onMeta?: () => void; onWa?: () => void; onWaLink?: () => void; onAgents?: () => void; onCash?: () => void; onManual?: () => void }) {
  const isMgr = me.agent.role === 'manager';
  const It = ({ on, icon, bg, label, right, danger, data }: { on: () => void; icon: React.ReactNode; bg: string; label: React.ReactNode; right?: React.ReactNode; danger?: boolean; data?: string }) => (
    <button onClick={on} className={clsx('af-row !min-h-[46px] !py-2', danger && '!text-tg-bad')} {...(data ? { [data]: '' } : {})}>
      <span className="af-tile" style={{ background: bg }}>{icon}</span><span className="min-w-0 flex-1 truncate text-[15px]">{label}</span>{right}
    </button>
  );
  const H = ({ t }: { t: string }) => <p className="af-h2 !mx-5 !mb-1.5 !mt-4"><span>{t}</span></p>;
  return (
    <div className={clsx('fixed inset-0 z-[150] transition-[visibility]', open ? 'visible' : 'invisible delay-[260ms]')} aria-hidden={!open}>
      <div className={clsx('absolute inset-0 bg-black/50 transition-opacity duration-200', open ? 'opacity-100' : 'opacity-0')} onClick={onClose} />
      <aside className={clsx('absolute inset-y-0 left-0 w-[300px] max-w-[85vw] overflow-y-auto bg-tg-bg pb-6 shadow-2xl transition-transform duration-[260ms] ease-[var(--ease-sheet)]', open ? 'translate-x-0' : '-translate-x-full')}>
        <div className="bg-tg-panel px-5 pb-4 pt-[calc(22px+env(safe-area-inset-top))]">
          <span className="relative inline-block"><Avatar name={me.agent.name} id={me.agent.id} size={60} /><span className={clsx('absolute bottom-0.5 right-0.5 h-3.5 w-3.5 rounded-full ring-[3px] ring-tg-panel', me.agent.online ? 'bg-[#34C759]' : 'bg-tg-sub/60')} aria-hidden /></span>
          <p className="mt-2.5 text-[17px] font-semibold text-tg-text">{me.agent.name}</p>
          <p className="text-[13px] text-tg-sub">@{me.agent.username} · {isMgr ? 'Manager' : `$${me.agent.comm_per_sale}/sale${me.agent.comm_premium != null ? ` · Premium $${me.agent.comm_premium}` : ''}${Number(me.agent.comm_funnel) > 0 ? ` · Funnel $${me.agent.comm_funnel}` : ''}`}</p>
          {!isMgr && today && <span className="mt-2 inline-flex rounded-full bg-tg-oksoft px-2.5 py-0.5 text-[12.5px] font-semibold text-tg-ok af-num">Today {usd(today.c)}</span>}
        </div>
        <H t="Status" />
        <div className="af-group af-tiles mx-3">
          <div role="button" tabIndex={0} onClick={e => { if (!(e.target as HTMLElement).closest('[role=switch]')) onOnline(!me.agent.online); }} className="af-row !min-h-[46px] cursor-pointer !py-2"><span className="af-tile" style={{ background: me.agent.online ? '#34C759' : '#8E8E93' }}><Circle size={15} className="fill-white" /></span><span className="flex-1 text-[15px]">Online</span><Toggle on={!!me.agent.online} onChange={onOnline} label="Online" /></div>
          <It on={onDash} icon={<LayoutDashboard size={17} />} bg="#3390EC" label="Dashboard" data="data-menu-dash" />
          <It on={onWallet} icon={<Wallet size={17} />} bg="#34C759" label="My wallet & payouts" />
        </div>
        {(onWaLink || onManual) && <><H t="Sell" />
          <div className="af-group af-tiles mx-3">
            {onWaLink && <It on={onWaLink} icon={<Link2 size={17} />} bg="#3390EC" label="Payment link (no chat)" />}
            {onManual && <It on={onManual} icon={<CreditCard size={17} />} bg="#5856D6" label="Ad account (no chat)" />}
          </div></>}
        {isMgr && <><H t="Team" />
          <div className="af-group af-tiles mx-3">
            {onTasks && <It on={onTasks} icon={<CheckCircle2 size={17} />} bg="#FF9500" label="Tasks" right={taskN > 0 ? <span className="af-badge orange"><i className="af-n">{taskN}</i></span> : undefined} />}
            {onAgents && <It on={onAgents} icon={<Users size={17} />} bg="#3390EC" label="Agents" data="data-menu-agents" />}
            {onCash && <It on={onCash} icon={<Banknote size={17} />} bg="#34C759" label="Record cash payout" data="data-menu-cash" />}
            {onWa && <It on={onWa} icon={<MessageSquareText size={17} />} bg="#25D366" label="WhatsApp sales" />}
            {onMeta && <It on={onMeta} icon={<CreditCard size={17} />} bg="#5856D6" label="Ad accounts (BMs)" />}
          </div></>}
        <H t="Settings" />
        <div className="af-group af-tiles mx-3">
          {me.tg_link && <It on={() => void openExternal(me.tg_link!)} icon={<Send size={16} />} bg="#2AABEE" label={me.agent.tg_linked ? 'Telegram alerts' : 'Connect Telegram alerts'} right={me.agent.tg_linked ? <CheckCircle2 size={18} className="text-tg-ok" aria-label="connected" /> : undefined} />}
          <It on={() => window.dispatchEvent(new Event('af-notif-fix'))} icon={<Bell size={16} />} bg="#FF3B30" label="Notifications" right={<span className="text-[13px] text-tg-sub">{push === 'on' ? 'On' : push === 'denied' ? 'Blocked' : push === 'web' ? 'App only' : '…'}</span>} />
          <It on={onLogout} icon={<LogOut size={16} />} bg="#8E8E93" label="Log out" danger />
        </div>
      </aside>
    </div>
  );
}

/* ---------------- v167: Dashboard (full screen + the daily splash use the same view) ---------------- */
const fmt2 = (n: number) => '$' + (Math.round((Number(n) || 0) * 100) / 100).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const PERIOD: Record<string, string> = { today: 'today', yesterday: 'yesterday', month: 'this month', lastmonth: 'last month', all: 'in total' };
const periodWord = (r: string) => PERIOD[r] || 'in this period';
const PROD_ICON: Record<string, [React.ReactNode, string]> = {
  agency: [<CreditCard key="i" size={17} />, '#3390EC'], premium: [<Star key="i" size={17} />, '#F5A623'], full: [<CreditCard key="i" size={17} />, '#18B5C9'],
  fb: [<Users key="i" size={17} />, '#2F6FE4'], fb_old: [<Users key="i" size={17} />, '#2F6FE4'], funnel: [<Package key="i" size={17} />, '#AF52DE'],
};
const SRC_COL = ['#3390EC', '#2AABEE', '#34C759', '#AF52DE', '#FF9500', '#5856D6'];

/** A number that counts up once (splash), or just the number. */
function CountUp({ v, run }: { v: number; run?: boolean }) {
  const [x, setX] = useState(run ? 0 : v);
  useEffect(() => {
    if (!run) { setX(v); return; }
    let raf = 0; const t0 = performance.now();
    const step = (t: number) => { const p = Math.min(1, (t - t0) / 900); setX(v * (1 - Math.pow(1 - p, 3))); if (p < 1) raf = requestAnimationFrame(step); };
    raf = requestAnimationFrame(step); return () => cancelAnimationFrame(raf);
  }, [v, run]);
  return <>{fmt2(x)}</>;
}

function Kpi({ icon, bg, k, v, sub, tone }: { icon: React.ReactNode; bg: string; k: string; v: React.ReactNode; sub?: React.ReactNode; tone?: 'ok' }) {
  return (
    <div className="af-card min-w-0 px-3 py-2.5" data-dash-card={k}>
      <p className="flex items-center gap-1.5 text-[12.5px] text-tg-sub"><span className="grid h-5 w-5 shrink-0 place-items-center rounded-[6px] text-white [&>svg]:h-3 [&>svg]:w-3" style={{ background: bg }}>{icon}</span><span className="truncate">{k}</span></p>
      <p className={clsx('mt-1 truncate text-[23px] font-bold leading-tight tracking-tight af-num', tone === 'ok' ? 'text-tg-ok' : 'text-tg-text')}>{v}</p>
      {sub != null && <p className="mt-px line-clamp-2 text-[12px] leading-snug text-tg-sub">{sub}</p>}
    </div>
  );
}

/** The dashboard numbers. `splash` = the greeting splash: no withdraw button, no zero / empty tiles, count-up hero. */
function DashView({ d, isMgr, range, splash, onPayout, onHot, onAll }: { d: any; isMgr: boolean; range: string; splash?: boolean; onPayout?: () => void; onHot?: () => void; onAll?: () => void }) {
  const pl = (n: number, w: string, many = w + 's') => `${n} ${n === 1 ? w : many}`;
  const pct = (v: number | null) => v == null ? '—' : v + '%';
  const empty = d.people === 0 && d.customers === 0 && d.leads === 0;
  const sold = (d.products || []).filter((r: ProductRow) => r.n > 0) as ProductRow[];
  const srcs = ((d.sources || []) as { k: string; label: string; chats: number; wrote: number; sales: number; buyers: number; rev: number }[]).filter(r => !(splash || (range === 'today' && !(d.sales > 0))) || r.rev > 0); // v168 F5
  const srcMax = Math.max(1, ...srcs.map(r => r.rev));
  const unit = (r: ProductRow) => r.k === 'funnel' ? pl(r.units, 'month') : ['agency', 'premium', 'full'].includes(r.k) ? pl(r.units, 'account') : `${r.units} sold`;
  const tiles: { k: string; node: React.ReactNode; zero: boolean }[] = [
    { k: 'rate', zero: !d.conv_pct, node: <Kpi key="rate" icon={<TrendingUp />} bg="#34C759" k="Buying rate" v={pct(d.conv_pct)} tone={d.conv_pct ? 'ok' : undefined} sub={`${d.conv_buyers ?? d.customers} of ${pl(d.active, 'person', 'people')} bought${d.no_chat ? ` (${d.no_chat} without a chat)` : ''}`} /> },
    { k: 'new', zero: !d.leads, node: <Kpi key="new" icon={<MessageCircle />} bg="#3390EC" k="New chats" v={d.leads} sub={`${d.new_bought} bought${d.new_conv_pct != null ? ` · ${d.new_conv_pct}%` : ''}`} /> },
    { k: 'time', zero: d.avg_days_to_buy == null, node: <Kpi key="time" icon={<Clock />} bg="#FF9500" k="Time to buy" v={daysTxt(d.avg_days_to_buy)} sub="first message → paid" /> },
    { k: 'old', zero: !d.old_buyers, node: <Kpi key="old" icon={<Users />} bg="#AF52DE" k="Old chats bought" v={d.old_buyers} sub={d.avg_days_old != null ? `Avg ${daysTxt(d.avg_days_old).toLowerCase()} after the first message` : 'started 7+ days before'} /> },
  ];
  // v168 F5: a day with no sales yet (Today) looks like the splash: no zero tiles / rows, an encouraging line instead
  const quiet = !!splash || (range === 'today' && !(d.sales > 0));
  const shown = quiet ? tiles.filter(t => !t.zero) : tiles;
  return (
    <div data-dash-view>
      {/* hero */}
      <div className="relative overflow-hidden rounded-[18px] bg-[linear-gradient(135deg,#2f8ae6,#1d63c5_60%,#1b4fa8)] p-4 text-white shadow-[0_8px_24px_-10px_rgba(29,99,197,.55)] dark:bg-[linear-gradient(135deg,#2b5278,#1f3d5c)]" data-dash-earning>
        <span aria-hidden className="pointer-events-none absolute -right-10 -top-10 h-40 w-40 rounded-full bg-white/[0.08]" />
        {splash && d.sales > 0 && <Sparkle />}
        {quiet && !(isMgr ? d.sales > 0 : d.earned > 0) ? <>
          <p className="text-[13px] text-white/85">{range === 'today' ? 'Today' : 'This month'}</p>
          <p className="mt-1 text-[24px] font-bold leading-tight tracking-tight" data-dash-cheer>Your next sale is one chat away</p>
          <p className="mt-0.5 text-[13px] text-white/85">Reply fast, follow up, close the deal.</p>
        </> : isMgr ? <>
          <p className="text-[13px] text-white/85">Sales {periodWord(range)}</p>
          <p className="mt-0.5 text-[36px] font-bold leading-tight tracking-tight af-num">{usd(d.revenue)}</p>
          <p className="text-[13px] text-white/85">{pl(d.sales, 'sale')} · {pl(d.accounts, 'account')} · {pl(d.customers, 'buyer')}</p>
        </> : <>
          <p className="text-[13px] text-white/85">Earned {periodWord(range)}</p>
          <p className="mt-0.5 text-[38px] font-bold leading-[1.1] tracking-[-0.03em] af-num"><CountUp v={d.earned} run={splash} /></p>
          <p className="text-[13px] text-white/85">Commission {usd(d.commission)} · Incentive {usd(d.bonus)} · <b className="text-white">{pl(d.sales, 'sale')}</b></p>
        </>}
        {!isMgr && !(quiet && !(d.wallet?.available > 0) && !(d.wallet?.pending > 0)) && <div className="relative mt-3.5 flex items-center gap-2.5 rounded-xl bg-white/[0.14] py-2.5 pl-3 pr-2.5">
          <span className="af-tile bg-white/20"><Wallet size={17} aria-hidden /></span>
          <span className="min-w-0 flex-1"><span className="block truncate text-[12px] text-white/85">{splash ? 'Wallet · ready to withdraw' : 'Ready to withdraw'}</span><b className="block text-[18px] leading-tight af-num">{usd(d.wallet.available)}</b>{d.wallet.pending > 0 && <span className="block text-[11.5px] text-white/85">{usd(d.wallet.pending)} payout requested</span>}</span>
          {!splash && onPayout && <button type="button" onClick={onPayout} className="af-press h-9 shrink-0 rounded-[10px] bg-white px-3.5 text-[14px] font-bold text-[#1d63c5] dark:text-[#2b5278]" data-dash-withdraw>{d.wallet.available > 0 ? 'Withdraw' : 'Wallet'}</button>}
        </div>}
      </div>
      {!splash && d.hot_now > 0 && <button type="button" onClick={onHot} className="af-press af-card mt-3 flex w-full items-center gap-3 px-3 py-2.5 text-left" data-dash-hot>
        <span className="af-tile bg-[#FF9500]"><Flame size={17} aria-hidden /></span>
        <span className="min-w-0 flex-1"><b className="block text-[15px]">{pl(d.hot_now, 'hot lead')} waiting for you</b><span className="text-[12px] text-tg-sub">Talked before, waiting for your reply · right now</span></span>
        <ChevronRight size={18} className="shrink-0 text-tg-faint" aria-hidden />
      </button>}
      {isMgr && !splash && <p className="mt-3 px-1 text-[12.5px] text-tg-sub">Your own chats only. Team numbers: Menu → Agents.</p>}
      {!splash && empty && <div className="af-note acc mt-3 items-center"><span className="min-w-0 flex-1 text-tg-text">{range === 'all' ? 'No chats yet.' : `No chats ${periodWord(range)} yet.`}</span>{onAll && range !== 'all' && <Btn kind="soft" size="sm" onClick={onAll}>See all time</Btn>}</div>}
      {shown.length > 0 && <div className="mt-3 grid grid-cols-2 gap-2.5 [&>*:last-child:nth-child(odd)]:col-span-2" data-dash-conv>{shown.map(t => t.node)}</div>}
      {(!quiet || sold.length > 0 || d.topups > 0) && <>
        <h4 className="af-h2"><span>What sold</span></h4>
        <div className="af-group af-tiles" data-what-sold>
          {sold.map(r => { const [ic, bg] = PROD_ICON[r.k] || [<CircleDollarSign key="i" size={17} />, '#8E8E93']; return (
            <div key={r.k} className="af-row" data-product={r.k}>
              <span className="af-tile" style={{ background: bg }}>{ic}</span>
              <span className="min-w-0 flex-1"><span className="block truncate text-[15px] font-medium">{r.label}</span><span className="block truncate text-[12.5px] text-tg-sub">{unit(r)} · {pl(r.n, 'sale')}{r.wa_n ? ` · WhatsApp ${r.wa_n} (${usd(r.wa_rev || 0)})` : ''}{!isMgr && r.comm ? ` · you earned ${usd(r.comm)}` : ''}</span></span>
              <b className="shrink-0 text-[15px] af-num">{usd(r.rev)}</b>
            </div>); })}
          {!sold.length && !quiet && <div className="af-row"><span className="af-tile bg-[#8E8E93]"><CircleDollarSign size={17} aria-hidden /></span><span className="flex-1 text-[15px] text-tg-sub">Nothing sold {periodWord(range)}</span></div>}
          {(!quiet || d.topups > 0) && <div className="af-row">
            <span className="af-tile bg-[#8E8E93]"><Plus size={17} aria-hidden /></span>
            <span className="min-w-0 flex-1"><span className="block text-[15px] font-medium">Top-ups</span><span className="block text-[12.5px] text-tg-sub">{d.topups ? `${pl(d.topups, 'top-up')} added` : `none ${periodWord(range)}`}</span></span>
            <b className={clsx('shrink-0 text-[15px] af-num', !d.topups && 'text-tg-sub')}>{usd(d.topup_vol)}</b>
          </div>}
        </div>
      </>}
      {srcs.length > 0 && <>
        <h4 className="af-h2"><span>Where sales came from</span></h4>
        <div className="af-group" data-sources>
          {srcs.map((r, i) => (
            <div key={r.k} className="af-row !block !py-2.5" data-source={r.k}>
              <span className="flex items-center gap-3"><span className="min-w-0 flex-1 truncate text-[15px] font-medium">{r.label}</span><b className={clsx('shrink-0 text-[15px] af-num', !r.rev && 'text-tg-sub')}>{usd(r.rev)}</b></span>
              <span className="af-bar mt-1.5"><i style={{ width: `${Math.max(r.rev ? 4 : 0, Math.round(r.rev / srcMax * 100))}%`, background: SRC_COL[i % SRC_COL.length] }} /></span>
              <span className="mt-1 block text-[12px] text-tg-sub">{[r.chats ? pl(r.chats, 'new chat') : '', r.wrote ? `${r.wrote} wrote` : '', pl(r.sales, 'sale')].filter(Boolean).join(' · ')}</span>
            </div>
          ))}
        </div>
      </>}
      {!splash && (!quiet || d.people > 0) && <>
        <h4 className="af-h2"><span>Chats and buyers</span></h4>
        <div className="af-group" data-dash-more>
          <div className="af-row"><span className="min-w-0 flex-1"><span className="block text-[15px]">People who messaged</span><span className="block text-[12.5px] text-tg-sub">{range === 'all' ? 'Each person once' : quiet ? [d.people_new > 0 && `${d.people_new} new`, d.people_old > 0 && pl(d.people_old, 'old chat')].filter(Boolean).join(' · ') : `${d.people_new} new · ${pl(d.people_old, 'old chat')}`}</span></span><b className="af-num text-[15px]">{d.people}</b></div>
          {!quiet && <div className="af-row"><span className="min-w-0 flex-1"><span className="block text-[15px]">Customers</span><span className="block text-[12.5px] text-tg-sub">People who bought</span></span><b className="af-num text-[15px]">{d.customers}</b></div>}
          {!quiet && <div className="af-row"><span className="min-w-0 flex-1"><span className="block text-[15px]">Accounts sold</span><span className="block text-[12.5px] text-tg-sub">{pl(d.sales, 'sale')} · {usd(d.revenue)}</span></span><b className="af-num text-[15px]">{d.accounts}</b></div>}
        </div>
      </>}
      {!isMgr && !splash && d.bonus_rows?.length > 0 && <>
        <h4 className="af-h2"><span>Incentives</span></h4>
        <div className="af-group af-tiles">
          {d.bonus_rows.map((b: any, i: number) => <div key={i} className="af-row"><span className="af-tile bg-[#FF9500]"><Star size={16} aria-hidden /></span><span className="min-w-0 flex-1"><span className="block text-[15px]">Incentive added by manager</span><span className="block truncate text-[12.5px] text-tg-sub">{new Date(b.created_at).toLocaleString([], { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' })}{b.note ? ' · ' + b.note : ''}</span></span><b className="shrink-0 text-tg-ok af-num">+{usd(b.amount)}</b></div>)}
        </div>
      </>}
    </div>
  );
}

/** A few soft sparkles drifting in the hero on a sale day (CSS only; reduced motion = still). */
function Sparkle() {
  const pts = [[14, 22, 0], [78, 14, 0.4], [62, 58, 0.9], [88, 70, 1.3], [34, 76, 0.6], [50, 30, 1.1]];
  return <span aria-hidden className="pointer-events-none absolute inset-0">{pts.map(([x, y, d], i) => <span key={i} className="ag-spark absolute" style={{ left: `${x}%`, top: `${y}%`, animationDelay: `${d}s` }}><Sparkles size={i % 2 ? 10 : 14} /></span>)}</span>;
}

/** v160/v167: the agent's own numbers. Full screen (tab bar) with a period control. */
function Dashboard({ api, isMgr, onPayout, onHot, onWallet }: { api: ReturnType<typeof makeApi>; isMgr: boolean; onPayout: () => void; onHot: () => void; onWallet: () => void }) {
  // v167: no saved choice → This month (a period that usually has numbers)
  // v168 F5 (owner): the dashboard ALWAYS opens on Today (the last period is not restored); switching still works on the page
  const [range, setRange] = useState('today');
  useEffect(() => { try { localStorage.removeItem('af_dash_range'); } catch { /* private mode */ } }, []);
  const [d, setD] = useState<any>(null); const [err, setErr] = useState(''); const [retry, setRetry] = useState(0);
  const [more, setMore] = useState(() => ['lastmonth'].includes(range) || range.startsWith('d:'));
  useEffect(() => { let on = true; setErr(''); void (async () => { try { const r = await api('dashboard?range=' + encodeURIComponent(range)); if (on) setD(r); } catch (e) { if (on) setErr((e as Error).message); } })(); return () => { on = false; }; }, [api, range, retry]);
  const busy = !!d && d.range !== range; // the old numbers stay (dimmed) while the new range loads: no jump
  const main: [string, string][] = [['today', 'Today'], ['yesterday', 'Yesterday'], ['month', 'This month'], ['all', 'All time']];
  const inMain = main.some(([k]) => k === range);
  const today = new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10);
  const custom = range.startsWith('d:');
  const [a, b] = custom ? [range.split(':')[1], range.split(':')[2] || range.split(':')[1]] : [today, today];
  const setD2 = (x: string, y: string) => setRange(`d:${x}${y && y !== x ? ':' + y : ''}`);
  return (
    <div data-dashboard>
      <div className="af-seg mb-1 mt-1" data-range-pick>
        {main.map(([k, l]) => <button key={k} type="button" aria-pressed={range === k} onClick={() => { setRange(k); setMore(false); }} className="af-press !px-1.5">{l}</button>)}
        <button type="button" aria-pressed={!inMain} aria-label="More periods" onClick={() => setMore(m => !m)} className="af-press !flex-none !px-3"><Ellipsis size={17} /></button>
      </div>
      {(more || !inMain) && <div className="af-sec mb-1 mt-2 flex flex-wrap items-center gap-1.5" data-range-more>
        <button type="button" aria-pressed={range === 'lastmonth'} onClick={() => setRange('lastmonth')} className="af-chip">Last month</button>
        <button type="button" aria-pressed={custom} onClick={() => { if (!custom) setD2(today, today); }} className="af-chip">Pick dates</button>
        {custom && <span className="flex items-center gap-1.5 text-[13px]" data-range-dates>
          <input type="date" max={today} value={a} onChange={e => e.target.value && setD2(e.target.value, b < e.target.value ? e.target.value : b)} className="rounded-lg bg-tg-panel px-2 py-1.5 text-tg-text" aria-label="From" />
          <span className="text-tg-sub">to</span>
          <input type="date" max={today} value={b} min={a} onChange={e => e.target.value && setD2(a, e.target.value)} className="rounded-lg bg-tg-panel px-2 py-1.5 text-tg-text" aria-label="To" />
        </span>}
      </div>}
      <div className="mt-2.5">
        {err && !d ? <div className="py-8 text-center"><p className="mb-3 text-tg-bad">{err}</p><Btn kind="ghost" onClick={() => setRetry(x => x + 1)}>Try again</Btn></div>
          : !d ? <Skeleton rows={4} h={86} />
            : <div className={clsx('transition-opacity duration-150', busy && 'opacity-50')} aria-busy={busy}><DashView d={d} isMgr={isMgr} range={range} onPayout={d.wallet?.available > 0 ? onPayout : onWallet} onHot={onHot} onAll={() => setRange('all')} /></div>}
      </div>
    </div>
  );
}

/* ---------------- v167: the daily greeting splash (normal agents) ---------------- */
const pick = <T,>(xs: T[]) => xs[Math.floor(Date.now() / 86400000) % xs.length];
function cheer(t: any, m: any, lm: any): string {
  const n = t?.sales || 0;
  if (n > 0) return pick([
    `${n} sale${n === 1 ? '' : 's'} already today. Great going!`,
    `${usd(t.earned)} earned today. Keep the momentum going!`,
    `${n} happy customer${n === 1 ? '' : 's'} today. Nice work, keep it up!`,
    ...(m && lm && m.sales > lm.sales ? ['You are ahead of last month. Keep it up!'] : []),
  ]);
  if (m && lm && m.sales > 0 && m.sales > lm.sales) return 'You are ahead of last month. Keep it up!';
  if (m && m.sales > 0) return pick([`${m.sales} sale${m.sales === 1 ? '' : 's'} this month so far. Let's add one more today.`, 'Good month so far. Today is a great day to grow it.']);
  return pick(['New day, new chances. Your next sale is one chat away.', 'Every quick reply counts. Let us make today a good one.', 'Fresh start today. Your customers are waiting to hear from you.']);
}
const SPLASH_MS = 4000;
/** Self-contained: mount it, it calls onDone when finished (a later "daily reel" can sit in front of it). Fades in from dark.
 *  Full-screen greeting + the agent's own dashboard for ~4 s, then the chat list. No skip (owner); taps do nothing.
 *  Data not there in 1.5 s, or an error → no splash at all (chats are never blocked). */
function AgentSplash({ api, name, onDone }: { api: ReturnType<typeof makeApi>; name: string; onDone: () => void }) {
  const [data, setData] = useState<{ d: any; range: string; line: string } | null>(null);
  const [left, setLeft] = useState(4);
  const [out, setOut] = useState(false);
  const doneRef = useRef(onDone); doneRef.current = onDone;
  // test hook: ?af_splash_slow=<n> stretches the countdown n times (screenshots only)
  const slow = (() => { try { return Math.max(1, Number(new URLSearchParams(location.search).get('af_splash_slow')) || 1); } catch { return 1; } })();
  useEffect(() => {
    let on = true, tm = 0;
    const timeout = new Promise<null>(r => { tm = window.setTimeout(() => r(null), 1500); });
    const get = (r: string) => api<any>('dashboard?range=' + r).catch(() => null);
    void Promise.race([Promise.all([get('today'), get('month'), get('lastmonth')]), timeout]).then(res => {
      if (!on) return;
      if (!res || !res[0] || !res[1]) { doneRef.current(); return; }
      const [t, m, lm] = res;
      setData({ d: t, range: 'today', line: cheer(t, m, lm) }); // v168 F5: the splash is always TODAY (never This month)
    });
    return () => { on = false; clearTimeout(tm); };
  }, [api]);
  useEffect(() => {
    if (!data) return;
    let outT = 0;
    const t0 = Date.now(), total = SPLASH_MS * slow;
    const id = setInterval(() => {
      const el = Date.now() - t0;
      setLeft(Math.max(1, 4 - Math.floor(el / (total / 4))));
      if (el >= total) { clearInterval(id); setOut(true); outT = window.setTimeout(() => doneRef.current(), 320); }
    }, 100);
    return () => { clearInterval(id); clearTimeout(outT); }; // senior-ui: a splash remounted (back after 30 min) during the fade is not closed by the old one's timer
  }, [data, slow]);
  const h = new Date().getHours();
  const greet = h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
  const first = String(name || '').trim().split(/\s+/)[0] || '';
  const dateTxt = new Date().toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'long' });
  return (
    <div className={clsx('ag-splash-bg fixed inset-0 z-[300] overflow-hidden bg-tg-bg text-tg-text transition-[opacity,transform] duration-300 ease-[var(--ease-out)]', out && 'pointer-events-none -translate-y-3 opacity-0')} data-splash={data ? 'on' : 'load'} onClickCapture={e => { e.preventDefault(); e.stopPropagation(); }}>
      <div aria-hidden className="pointer-events-none absolute inset-x-0 top-0 h-[300px] bg-[radial-gradient(120%_80%_at_20%_0%,rgb(var(--tg-acc)/0.22),transparent_70%)]" />
      <div className="ag-splash-in relative mx-auto h-full max-w-[520px] overflow-hidden px-4 pt-[calc(28px+env(safe-area-inset-top))]">
        {!data ? <div className="af-page">
          <div className="mb-5 space-y-2"><div className="af-skel h-4 w-40 rounded bg-tg-panel" /><div className="af-skel h-8 w-64 rounded-lg bg-tg-panel" /><div className="af-skel h-4 w-56 rounded bg-tg-panel" /></div>
          <Skeleton rows={4} h={92} />
        </div> : <div className="af-page" data-splash-body>
          <p className="text-[13.5px] font-medium text-tg-sub">{dateTxt}</p>
          <h1 className="mt-0.5 text-[28px] font-bold leading-[1.15] tracking-[-0.02em]" data-splash-greet>{greet}{first ? `, ${first}` : ''}</h1>
          <p className="mt-1.5 text-[15.5px] leading-snug text-tg-text/80" data-splash-line>{data.line}</p>
          <p className="mb-2 mt-4 flex items-center gap-1.5 text-[12.5px] font-semibold uppercase tracking-[.04em] text-tg-sub"><span className="h-1.5 w-1.5 rounded-full bg-tg-acc" aria-hidden />{data.range === 'today' ? 'Today' : 'This month'}</p>
          <DashView d={data.d} isMgr={false} range={data.range} splash />
        </div>}
      </div>
      {/* the bottom fades out under the pill */}
      <div aria-hidden className="pointer-events-none absolute inset-x-0 bottom-0 h-28 bg-gradient-to-t from-tg-bg via-tg-bg/85 to-transparent" />
      {data && <div className="absolute inset-x-0 bottom-[calc(22px+env(safe-area-inset-bottom))] flex justify-center" data-splash-count={left}>
        <span className="ag-frost flex items-center gap-2.5 rounded-full py-2 pl-2 pr-4 text-[14.5px] font-semibold shadow-[0_8px_28px_rgba(0,0,0,.18)] ring-1 ring-tg-sep">
          <svg width="28" height="28" viewBox="0 0 28 28" aria-hidden className="-rotate-90">
            <circle cx="14" cy="14" r="11" fill="none" stroke="rgb(var(--tg-sub) / .22)" strokeWidth="3" />
            <circle cx="14" cy="14" r="11" fill="none" stroke="rgb(var(--tg-acc))" strokeWidth="3" strokeLinecap="round" strokeDasharray={69.1} style={{ strokeDashoffset: 69.1 * (left - 1) / 4, transition: 'stroke-dashoffset 900ms linear' }} />
          </svg>
          <span className="af-num">Opening chats in {left}</span>
        </span>
      </div>}
    </div>
  );
}

/* ---------------- v167: Wallet (full screen, banking-app layout) ---------------- */
function WalletScreen({ api, onDash, withdraw, setWithdraw }: { api: ReturnType<typeof makeApi>; onDash: () => void; withdraw: boolean; setWithdraw: (v: boolean) => void }) {
  const toast = useToast();
  const [d, setD] = useState<any>(null);
  const [method, setMethod] = useState<'bank' | 'usdt'>('bank');
  const [amount, setAmount] = useState(''); const [details, setDetails] = useState(''); const [busy, setBusy] = useState(false);
  const histRef = useRef<HTMLDivElement>(null);
  const load = useCallback(async () => { try { const r = await api('wallet'); setD(r); setAmount(r.wallet.available > 0 ? String(r.wallet.available) : ''); } catch (e) { toast((e as Error).message, 'err'); } }, [api, toast]);
  useEffect(() => { void load(); }, [load]);
  async function req() {
    setBusy(true);
    try { await api('payout', { amount, method, details }); toast('Payout requested. Admin will be notified.'); setDetails(''); setWithdraw(false); await load(); }
    catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); }
  }
  const w = d?.wallet;
  if (!w) return <div className="pt-4"><Skeleton rows={4} h={70} /></div>;
  const avail = Math.round((Number(w.available) || 0) * 100) / 100; // senior-ui: a negative balance reads −$12.50, not $-12.50
  const [whole, cents] = Math.abs(avail).toFixed(2).split('.');
  const Round = ({ icon, label, on, pri, data }: { icon: React.ReactNode; label: string; on: () => void; pri?: boolean; data?: string }) => (
    <button type="button" onClick={on} className="af-press flex w-[84px] flex-col items-center gap-1.5 text-[13px] font-medium" {...(data ? { [data]: '' } : {})}>
      <span className={clsx('grid h-[52px] w-[52px] place-items-center rounded-full', pri ? 'bg-[#3390EC] text-white shadow-[0_6px_16px_-6px_#3390EC]' : 'af-card text-tg-link')}>{icon}</span>{label}
    </button>
  );
  return (
    <div data-wallet>
      <div className="pb-4 pt-3 text-center">
        <p className="text-[14px] text-tg-sub">Available to withdraw</p>
        <p className="mt-0.5 font-bold tracking-[-0.03em] af-num" data-wallet-bal><span className="text-[44px] leading-none">{avail < 0 ? '−' : ''}${Number(whole).toLocaleString()}</span><span className="text-[26px] text-tg-text/70">.{cents}</span></p>
        <p className="mt-1.5 text-[13.5px] text-tg-sub">Today: {d.today.n} sale{d.today.n === 1 ? '' : 's'} · {usd(d.today.c + (d.bonus_today || 0))} earned{d.bonus_today ? ` (incl. ${usd(d.bonus_today)} incentive)` : ''}</p>
        <div className="mt-4 flex justify-center gap-3">
          <Round icon={<Send size={21} />} label="Withdraw" on={() => setWithdraw(true)} pri data="data-wallet-withdraw" />
          <Round icon={<LayoutDashboard size={21} />} label="Dashboard" on={onDash} />
          <Round icon={<History size={21} />} label="History" on={() => histRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })} />
        </div>
      </div>
      <h4 className="af-h2"><span>Breakdown</span></h4>
      <div className="af-group af-tiles" data-wallet-breakdown>
        {([[<CircleDollarSign key="i" size={17} />, '#34C759', 'Sales commission', `${w.sales} sale${w.sales === 1 ? '' : 's'}`, usd(w.sale_comm), !w.sale_comm],
          [<Star key="i" size={17} />, '#FF9500', 'Incentives', 'from your manager', usd(w.bonus || 0), !w.bonus],
          [<Plus key="i" size={17} />, '#3390EC', 'Top-ups handled', `${w.topups} top-up${w.topups === 1 ? '' : 's'}`, usd(w.topup_vol), !w.topup_vol],
          [<Clock key="i" size={17} />, '#AF52DE', 'Payout requested', 'waiting for the admin', usd(w.pending), !w.pending],
          [<Check key="i" size={17} />, '#8E8E93', 'Paid out so far', '', usd(w.paid), !w.paid]] as [React.ReactNode, string, string, string, string, boolean][]).map(([ic, bg, l, s, v, z]) => (
          <div key={l} className="af-row"><span className="af-tile" style={{ background: bg }}>{ic}</span><span className="min-w-0 flex-1"><span className="block text-[15px]">{l}</span>{s && <span className="block text-[12.5px] text-tg-sub">{s}</span>}</span><b className={clsx('shrink-0 text-[15px] af-num', z && 'text-tg-sub')}>{v}</b></div>
        ))}
      </div>
      {d.splits?.length > 0 && <>
        <h4 className="af-h2"><span>Shared sales</span></h4>
        <div className="af-group">{d.splits.map((x: any, i: number) => <div key={i} className="af-row"><span className="min-w-0 flex-1 text-[14px] text-tg-sub">{x.reason}</span><b className="shrink-0 af-num">{usd(x.share)}</b></div>)}</div>
      </>}
      <div ref={histRef} className="scroll-mt-2"><h4 className="af-h2"><span>History</span></h4></div>
      <div className="af-group af-tiles" data-wallet-history>
        {d.payouts.length ? d.payouts.map((p: any) => (
          <div key={p.id} className="af-row">
            <span className="af-tile" style={{ background: p.kind === 'cash' ? '#34C759' : '#5856D6' }}>{p.kind === 'cash' ? <Banknote size={17} /> : <Send size={16} />}</span>
            <span className="min-w-0 flex-1"><span className="block truncate text-[15px]">{payLine(p)}</span><span className="block truncate text-[12.5px] text-tg-sub">{new Date(p.pay_date || p.created_at).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' })}{p.note && p.kind !== 'cash' ? ' · ' + p.note : ''}</span></span>
            <span className="flex shrink-0 flex-col items-end gap-1"><b className="text-[15px] af-num">−{usd(p.amount)}</b><span className={clsx('af-tag', p.status === 'paid' ? 'ok' : p.status === 'pending' ? 'warn' : 'bad')}>{String(p.status).toUpperCase()}</span></span>
          </div>
        )) : <div className="af-row"><span className="af-tile bg-[#8E8E93]"><History size={17} aria-hidden /></span><span className="text-[15px] text-tg-sub">No payouts yet</span></div>}
      </div>
      <Sheet open={withdraw} onClose={() => setWithdraw(false)} title="Withdraw">
        <div data-withdraw-sheet>
          <p className="mb-3 text-[13.5px] text-tg-sub">Available: <b className="text-tg-text af-num">{usd(w.available)}</b></p>
          <div className="mb-3"><Seg full value={method} onChange={setMethod} items={[['bank', 'Bank / UPI'], ['usdt', 'USDT BEP20']]} /></div>
          <Field label="Amount (USD)"><input className={inputCls} type="number" inputMode="decimal" value={amount} onChange={e => setAmount(e.target.value)} /></Field>
          <Field label={method === 'usdt' ? 'USDT BEP20 address' : 'Account holder, account number, IFSC or UPI ID'}>
            <textarea className={inputCls} rows={2} value={details} placeholder={method === 'usdt' ? '0x…' : ''} onChange={e => setDetails(e.target.value)} />
          </Field>
          <Btn busy={busy} disabled={!(Number(amount) > 0)} onClick={() => void req()} className="w-full !min-h-[44px] !bg-[#3390EC] !text-white">Request payout</Btn>
        </div>
      </Sheet>
    </div>
  );
}
