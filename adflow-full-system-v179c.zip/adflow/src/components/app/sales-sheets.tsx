'use client';

/** v136: the sale / top-up / payment link / delete-request sheets, shared by the agent app and the admin app (chat screen). */
import { useCallback, useEffect, useRef, useState } from 'react';
import { ChevronDown, Minus, Plus, Check, CreditCard, Star, Users, Package, CircleDollarSign, Link2, Copy, X as XIcon } from 'lucide-react';
import clsx from 'clsx';
import { Sheet, Field, inputCls, Btn, Seg, usd, useToast, Avatar } from './ui';
import { TierWord } from './chat';
import { AccountPicker } from './tasks';

type Api = <T = any>(path: string, body?: unknown) => Promise<T>;

/** What the sheets need to know about prices and the person who gets the sale. */
export type SalesCtx = {
  agent: { role?: string; name?: string; comm_per_sale: number; comm_premium?: number | null; comm_funnel?: number | null };
  price_account: number; price_funnel: number; price_account_full: number; price_premium_full: number; price_fb_old?: number;
  topup_pct: number; topup_min?: number; max_discount_pct?: number; meta_on?: boolean; meta_email?: boolean; auto_acct?: boolean; offerFree?: number;
  premium?: { price_account: number; topup_pct: number; quick_replies?: string[]; fu?: string[] };
  offer?: { account: number; funnel: number; free: number } | null;
};
type ChatLike = { tier?: string | null; offer_until?: number | null; biz?: string | null; [k: string]: unknown } | undefined | null;

/** The prices for THIS chat: Premium chats use the Premium price + fee, retargeting offer chats the offer price. */
export function priceCtxFor<T extends SalesCtx>(base: T, chat: ChatLike): T {
  const premium = chat?.tier === 'premium';
  const meP: T = premium && base.premium ? { ...base, price_account: base.premium.price_account, topup_pct: base.premium.topup_pct } : base;
  const offerLive = !!base.offer && Number(chat?.offer_until || 0) > Date.now();
  if (!offerLive || !base.offer) return meP;
  if (premium) return { ...meP, offerFree: base.offer.free };
  if (chat?.biz === 'funnel') return base.offer.funnel ? { ...meP, price_funnel: base.offer.funnel } : meP;
  return base.offer.account ? { ...meP, price_account: base.offer.account } : meP;
}

/* v167: one look for every sales sheet — grouped list (radio rows), compact stepper, sticky total + confirm footer */
export const sheetGroup = 'af-group !bg-tg-input/70 !shadow-none';
const Foot = ({ children }: { children: React.ReactNode }) => (
  <div className="sticky -mx-5 -mb-[calc(20px+env(safe-area-inset-bottom))] mt-4 border-t border-tg-sep bg-tg-panel px-5 pb-[calc(14px+env(safe-area-inset-bottom))] pt-2.5 [bottom:calc(-20px-env(safe-area-inset-bottom))]" data-sheet-foot>{children}</div>
);
const Radio = ({ on }: { on: boolean }) => (
  <span aria-hidden className={clsx('grid h-[22px] w-[22px] shrink-0 place-items-center rounded-full', on ? 'bg-tg-acc text-white' : 'ring-[1.5px] ring-inset ring-tg-sub/50')}>{on && <Check size={14} strokeWidth={3} />}</span>
);
const H = ({ t }: { t: string }) => <p className="af-h2 !mx-1 !mb-1.5 !mt-3.5"><span>{t}</span></p>;
const ICONS: Record<string, [React.ReactNode, string]> = {
  account: [<CreditCard key="i" size={17} />, '#3390EC'], account_std: [<CreditCard key="i" size={17} />, '#3390EC'], account_prem: [<Star key="i" size={17} />, '#F5A623'],
  full: [<CreditCard key="i" size={17} />, '#18B5C9'], fb: [<Users key="i" size={17} />, '#2F6FE4'], funnel: [<Package key="i" size={17} />, '#AF52DE'], custom: [<CircleDollarSign key="i" size={17} />, '#8E8E93'],
  agency: [<CreditCard key="i" size={17} />, '#3390EC'], premium: [<Star key="i" size={17} />, '#F5A623'], topup: [<Plus key="i" size={17} />, '#34C759'],
};
const Ico = ({ k }: { k: string }) => { const [i, bg] = ICONS[k] || ICONS.custom; return <span className="af-tile" style={{ background: bg }}>{i}</span>; };

const Stepper = ({ v, set, max }: { v: number; set: (f: (q: number) => number) => void; max: number }) => (
  <div className="flex h-9 items-center rounded-[10px] bg-tg-panel shadow-[0_0_0_1px_rgb(var(--tg-sep))]" data-stepper>
    <button type="button" onClick={() => set(q => Math.max(1, q - 1))} className="grid h-9 w-10 place-items-center text-tg-link disabled:opacity-40" disabled={v <= 1}><Minus size={17} /><span className="sr-only">Less</span></button>
    <span className="w-8 text-center text-[16px] font-semibold tabular-nums">{v}</span>
    <button type="button" onClick={() => set(q => Math.min(max, q + 1))} className="grid h-9 w-10 place-items-center text-tg-link"><Plus size={17} /><span className="sr-only">More</span></button>
  </div>
);
/** a $ price box that sits at the right end of a grouped row */
const PriceIn = ({ v, set, min, bad, label }: { v: string; set: (v: string) => void; min: number; bad?: boolean; label: string }) => (
  <span className={clsx('relative flex h-9 w-[110px] shrink-0 items-center rounded-[10px] bg-tg-panel shadow-[0_0_0_1px_rgb(var(--tg-sep))]', bad && 'shadow-[0_0_0_1.5px_rgb(var(--tg-bad))]')}>
    <span className="pointer-events-none pl-3 text-tg-sub">$</span>
    <input data-unit-price aria-label={label} className="h-full w-full min-w-0 bg-transparent pl-1 pr-3 text-right text-[16px] font-semibold tabular-nums text-tg-text outline-none" type="number" inputMode="decimal" min={min} step="0.01" value={v} onChange={e => set(e.target.value)} />
  </span>
);
const Choice = ({ on, onClick, children, className }: { on: boolean; onClick: () => void; children: React.ReactNode; className?: string }) => (
  <button type="button" aria-pressed={on} onClick={onClick} className={clsx('af-press rounded-xl border-2 px-3 py-2.5 text-left text-[14px] font-medium', on ? 'border-tg-acc bg-tg-acc/10' : 'border-transparent bg-tg-input', className)}>{children}</button>
);

/** Mark as sold (manager in the agent app, the owner in the admin app). `who` = the agent who gets the commission (admin app). */
export function SoldSheet({ open, onClose, api, me, leadId, onDone, premium, stdPrice, who, admin, forName, forId, forLine }: { open: boolean; onClose: () => void; api: Api; me: SalesCtx; leadId: number | null; onDone: () => void; premium?: boolean; stdPrice?: number; who?: string; admin?: boolean; forName?: string; forId?: number; forLine?: { line_k?: string | null; line?: string | null; tier?: string | null; biz?: string | null; service?: string | null; menu?: number | null } | null }) {
  const toast = useToast();
  const [svc, setSvc] = useState<'account' | 'account_std' | 'account_prem' | 'full' | 'fb' | 'funnel' | 'custom'>('account');
  const [qty, setQty] = useState(1); const [amt, setAmt] = useState(''); const [busy, setBusy] = useState(false);
  // v144: the price per account (per month for the funnel) can be changed: "special price" (still an account / funnel sale)
  const listOf = (v: typeof svc) => v === 'fb' ? Number(me.price_fb_old || 0) : v === 'full' ? (premium ? me.price_premium_full : me.price_account_full) : v === 'funnel' ? me.price_funnel : v === 'account_std' ? (stdPrice ?? me.price_account) : v === 'account_prem' ? (me.premium?.price_account ?? me.price_account) : me.price_account;
  const [up, setUp] = useState('');
  useEffect(() => { if (open) { setSvc('account'); setQty(1); setAmt(''); setUp(String(listOf('account'))); } }, [open]); // eslint-disable-line react-hooks/exhaustive-deps
  const pick = (v: typeof svc) => { setSvc(v); if (v !== 'custom') setUp(String(listOf(v))); };
  const list = svc === 'custom' ? 0 : listOf(svc);
  const unit = Math.round((Number(up) || 0) * 100) / 100;
  const special = svc !== 'custom' && unit > 0 && Math.abs(unit - list) > 0.004;
  const total = svc === 'custom' ? Number(amt) || 0 : Math.round(unit * qty * 100) / 100;
  const isMgr = me.agent.role === 'manager'; // the manager gets no commission (his sales are the business's)
  const capPct = me.max_discount_pct ?? 40;
  const minUnit = isMgr || admin ? 0.01 : Math.round(list * (1 - capPct / 100) * 100) / 100; // agents: at most capPct% off (checked on the server too)
  const tooLow = svc !== 'custom' && unit > 0 && unit + 0.004 < minUnit;
  const comm = isMgr || svc === 'custom' ? 0 : svc === 'funnel' ? Number(me.agent.comm_funnel || 0) * qty : (((premium && svc === 'account') || svc === 'account_prem') && me.agent.comm_premium != null ? me.agent.comm_premium : me.agent.comm_per_sale) * qty;
  async function go() {
    if (!leadId) return;
    setBusy(true);
    const send = (force?: boolean) => api<{ amount: number; commission: number; by?: string }>('sold', { lead_id: leadId, service: svc === 'account_prem' || svc === 'full' ? 'account' : svc === 'fb' ? 'custom' : svc, ...(svc === 'account_prem' ? { tier: 'premium' } : {}), ...(svc === 'full' ? { full: 1 } : {}), ...(svc === 'fb' ? { item: 'fb_old', amount: total } : { amount: amt }), qty, ...(special && svc !== 'fb' ? { unit_price: unit } : {}), ...(force ? { force: 1 } : {}) });
    try {
      let r: { amount: number; commission: number; by?: string };
      try { r = await send(); }
      catch (e) {
        // v135: the payment link already saved this sale → only record again if it is really a new sale
        if ((e as { data?: { code?: string } }).data?.code !== 'paid_link' || !confirm(`${(e as Error).message}\n\nRecord another sale anyway?`)) throw e;
        r = await send(true);
      }
      toast(who ? `Sold for $${r.amount}${r.commission ? ` · ${who} earns $${r.commission}` : ''}` : isMgr ? `Sold for $${r.amount}` : `Sold for $${r.amount}. You earned $${r.commission}`); onClose(); onDone();
    }
    catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); }
  }
  const opts = ([['account', premium ? 'Premium ad account' : 'Agency ad account', `$${me.price_account}`], ...(premium ? [['account_std', 'Normal ad account', `$${stdPrice ?? me.price_account}`] as const] : me.premium ? [['account_prem', 'Premium ad account', `$${me.premium.price_account}`] as const] : []), ...((premium ? me.price_premium_full : me.price_account_full) > 0 ? [['full', premium ? 'Full access Premium account' : 'Full access ad account', `$${premium ? me.price_premium_full : me.price_account_full}`] as const] : []), ...(Number(me.price_fb_old) > 0 ? [['fb', 'Facebook account + BM', `$${me.price_fb_old}`] as const] : []), ['funnel', 'Landing page + funnel', `$${me.price_funnel}/mo`], ['custom', 'Custom amount', 'any']] as const);
  const picked = opts.find(o => o[0] === svc);
  return (
    <Sheet open={open} onClose={onClose} title="Mark as sold">
      {(forName || who) && <p className="-mt-2 mb-2 flex min-w-0 items-center gap-1.5 text-[13.5px] text-tg-sub" data-sold-for>
        {forName && forId != null && <Avatar name={forName} id={forId} size={20} />}
        <span className="min-w-0 truncate">{forName}{forName && forLine ? <> · <TierWord l={forLine} /></> : null}{who ? `${forName ? ' · ' : ''}for ${who}` : ''}{premium ? ' · Premium price' : ''}</span>
      </p>}
      <H t="What did they buy?" />
      <div className={clsx(sheetGroup, 'af-tiles')} data-sold-opts role="radiogroup">
        {opts.map(([v, l, p]) => (
          <button key={v} type="button" role="radio" aria-checked={svc === v} aria-pressed={svc === v} onClick={() => pick(v)} className="af-row !min-h-[48px] !py-2">
            <Ico k={v} /><span className="min-w-0 flex-1 truncate text-[15px] font-medium">{l}</span><span className="shrink-0 text-[14.5px] text-tg-sub af-num">{p}</span><Radio on={svc === v} />
          </button>
        ))}
      </div>
      <H t="Details" />
      <div className={sheetGroup}>
        {svc === 'custom'
          ? <div className="af-row"><span className="flex-1 text-[15px]">Amount</span>
              <span className="relative flex h-9 w-[120px] items-center rounded-[10px] bg-tg-panel shadow-[0_0_0_1px_rgb(var(--tg-sep))]"><span className="pl-3 text-tg-sub">$</span><input aria-label="Amount (USD)" className="h-full w-full min-w-0 bg-transparent pl-1 pr-3 text-right text-[16px] font-semibold tabular-nums text-tg-text outline-none" type="number" inputMode="decimal" min="1" value={amt} onChange={e => setAmt(e.target.value)} /></span></div>
          : <>
            <div className="af-row"><span className="flex-1 text-[15px]">{svc === 'funnel' ? 'Months' : 'Accounts'}</span><Stepper v={qty} set={setQty} max={100} /></div>
            <div className="af-row"><span className="min-w-0 flex-1 text-[15px]">{svc === 'funnel' ? 'Price per month' : 'Price per account'}</span><PriceIn v={up} set={setUp} min={minUnit} bad={tooLow} label={svc === 'funnel' ? 'Price per month (USD)' : 'Price per account (USD)'} /></div>
          </>}
        {!isMgr && <div className="af-row"><span className="flex-1 text-[15px]">{who ? `${who} earns` : 'Your commission'}</span><b className="af-num text-[15px] text-tg-ok">{usd(comm)}</b></div>}
      </div>
      {special && <p data-special-note className="af-note warn mt-2 !py-2 text-[13px] text-tg-warn">Special price (${unit} instead of ${list}{svc === 'funnel' ? ' / month' : ''})</p>}
      {tooLow && <p className="mt-2 px-1 text-[13px] text-tg-bad">You can lower the price by at most {capPct}%: the lowest is ${minUnit}. Ask the manager or the admin.</p>}
      {isMgr && who && <p className="mt-2 px-1 text-[12.5px] text-tg-sub">Recorded for {who} (manager, no commission).</p>}
      <p className="mt-2 px-1 text-[12.5px] leading-snug text-tg-sub">Confirming records the sale and sends the Purchase event to Meta for this customer.</p>
      <Foot>
        <div className="mb-2 flex items-baseline justify-between gap-3"><span className="min-w-0 truncate text-[14px] text-tg-sub">{svc === 'custom' ? 'Custom amount' : `${qty} × ${picked?.[1] || ''}`}</span><b className="shrink-0 text-[22px] tracking-tight af-num" data-sold-total>{usd(total)}</b></div>
        <Btn kind="green" busy={busy} disabled={!(total > 0) || tooLow} onClick={() => void go()} className="w-full !min-h-[44px]"><Check size={18} strokeWidth={2.6} aria-hidden />Confirm sale · {usd(total)}</Btn>
      </Foot>
    </Sheet>
  );
}

/** A top-up the client paid outside a payment link (UPI, cash…). */
export function TopupSheet({ open, onClose, api, me, leadId, onDone }: { open: boolean; onClose: () => void; api: Api; me: SalesCtx; leadId: number | null; onDone: () => void }) {
  const toast = useToast();
  const [amt, setAmt] = useState(''); const [note, setNote] = useState(''); const [busy, setBusy] = useState(false);
  useEffect(() => { if (open) { setAmt(''); setNote(''); } }, [open]);
  const a = Number(amt) || 0;
  const fee = Math.round(a * me.topup_pct) / 100;
  const total = Math.round((a + fee) * 100) / 100;
  async function go() {
    if (!leadId) return;
    setBusy(true);
    try {
      const send = (force?: boolean) => api<{ fee: number; total: number }>('topup', { lead_id: leadId, amount: amt, note, ...(force ? { force: 1 } : {}) });
      let r: { fee: number; total: number };
      try { r = await send(); }
      catch (e) { if ((e as { data?: { code?: string } }).data?.code !== 'paid_link' || !confirm(`${(e as Error).message}\n\nRecord another top-up anyway?`)) throw e; r = await send(true); } // v156
      toast(`Top-up saved · fee $${r.fee} · client pays $${r.total}`); onClose(); onDone(); }
    catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); }
  }
  return (
    <Sheet open={open} onClose={onClose} title="Record top-up">
      <p className="mb-4 text-[14px] text-tg-sub">Records a top-up the client paid outside a payment link. Our {me.topup_pct}% top-up fee is added on top.</p>
      {!!me.offerFree && <p className="mb-4 rounded-xl bg-tg-premium/15 px-3 py-2 text-[13.5px] text-tg-warn">Offer: the client&apos;s first top-up has no fee on up to ${me.offerFree}. The app applies it.</p>}
      <Field label="Top-up amount (USD)"><input className={inputCls} type="number" inputMode="decimal" min="1" placeholder="200" value={amt} onChange={e => setAmt(e.target.value)} /></Field>
      <Field label="Note (optional)"><input className={inputCls} placeholder="Second top-up" value={note} onChange={e => setNote(e.target.value)} /></Field>
      {a > 0 && <div className={clsx(sheetGroup, 'af-sec')} data-topup-breakdown>
        <div className="af-row !min-h-[44px]"><span className="flex-1 text-[14.5px] text-tg-sub">Top-up to ad account</span><span className="af-num">{usd(a)}</span></div>
        <div className="af-row !min-h-[44px]"><span className="flex-1 text-[14.5px] text-tg-sub">Top-up fee ({me.topup_pct}%)</span><span className="af-num">{usd(fee)}</span></div>
      </div>}
      <Foot>
        <div className="mb-2 flex items-baseline justify-between"><span className="text-[14px] text-tg-sub">Client pays</span><b className="text-[22px] tracking-tight text-tg-ok af-num">{a > 0 ? usd(total) : '—'}</b></div>
        <Btn busy={busy} disabled={!(Number(amt) > 0)} onClick={() => void go()} className="w-full !min-h-[44px] !bg-[#3390EC] !text-white disabled:!opacity-40">Save top-up</Btn>
      </Foot>
    </Sheet>
  );
}

type PayLink = { id: number; code: string; kind: string; qty: number; amount: number; fee: number; total: number; label: string; status: string; url: string; created_at: number; paid_usd?: number; due?: number; list_price?: number | null; item?: string | null };
export const LINK_ST: Record<string, [string, string]> = { new: ['Not opened', 'text-tg-sub'], pending_payment: ['Waiting for payment', 'text-tg-warn'], paid: ['Paid', 'text-tg-ok'], cancelled: ['Cancelled', 'text-tg-sub line-through'] };

/** v144: one product of this chat (server: chatCatalog — the same products + setting prices as /products and the WhatsApp sales sheet). */
export type CatItem = { k: string; group: 'agency' | 'premium' | 'fb' | 'funnel'; label: string; short: string; kind: 'account' | 'funnel' | 'custom'; tier: 'premium' | 'agency' | null; full: 0 | 1; price: number; unit: string };
const GROUPS: [string, string][] = [['agency', 'Agency'], ['premium', 'Premium'], ['fb', 'Facebook account'], ['funnel', 'Funnel'], ['topup', 'Top-up'], ['custom', 'Custom']];

/** Crypto payment link for this chat: every product we sell (Agency / Premium normal + full access, Facebook account + BM, funnel), top-up + fee, custom.
 *  Paid = sale / top-up recorded automatically, as exactly that product. The price per account can be changed (agents: within the limit). */
export function PayLinkSheet({ open, onClose, api, me, leadId, onDone, premium, noMin, who }: { open: boolean; onClose: () => void; api: Api; me: SalesCtx; leadId: number | null; onDone: () => void; premium?: boolean; stdPrice?: number; noMin?: boolean; who?: string }) {
  const toast = useToast();
  const [grp, setGrp] = useState<string>(premium ? 'premium' : 'agency');
  const [k, setK] = useState<string>(premium ? 'premium' : 'account');
  const [items, setItems] = useState<CatItem[] | null>(null);
  const [capPct, setCapPct] = useState<number>(me.max_discount_pct ?? 40);
  const [cLabel, setCLabel] = useState('');
  const [qty, setQty] = useState(1); const [bm, setBm] = useState(''); const [amt, setAmt] = useState(''); const [act, setAct] = useState('');
  const [up, setUp] = useState('');
  const [tier, setTier] = useState('any'); const [shareMode, setShareMode] = useState<'bm' | 'email'>('bm'); const [cEmail, setCEmail] = useState('');
  const [busy, setBusy] = useState(false);
  const [made, setMade] = useState<{ url: string; message: string } | null>(null);
  const sendCid = useRef(''); // one id per link message (bh2 #8)
  const [msg, setMsg] = useState('');
  const [links, setLinks] = useState<PayLink[]>([]);
  const [linksOpen, setLinksOpen] = useState(false);
  // v159: several products in one link — items added here, plus the one in the form
  const [cart, setCart] = useState<{ body: Record<string, unknown>; label: string; total: number }[]>([]);
  const [picked, setPicked] = useState(true); // after "Add", the form counts again only once a product is tapped / typed
  const loadLinks = useCallback(async () => {
    if (!leadId) return;
    try { const r = await api<{ links: PayLink[]; items?: CatItem[]; max_discount_pct?: number }>('paylinks?lead_id=' + leadId); setLinks(r.links); if (r.items) setItems(r.items); if (r.max_discount_pct != null) setCapPct(r.max_discount_pct); } catch { /* ignore */ }
  }, [api, leadId]);
  useEffect(() => { if (open) { setItems(null); setQty(1); setBm(''); setAmt(''); setAct(''); setTier('any'); setShareMode('bm'); setCEmail(''); setCLabel(''); setMade(null); setLinksOpen(false); setCart([]); setPicked(true); void loadLinks(); } }, [open, loadLinks]);
  const groups = GROUPS.filter(([g]) => g === 'topup' || g === 'custom' || (items || []).some(x => x.group === g));
  const inGrp = (items || []).filter(x => x.group === grp);
  const it = (items || []).find(x => x.k === k && x.group === grp) || inGrp[0];
  // first load / the chat changed: land on the chat's own line (Premium chat → Premium; never the Agency account there)
  useEffect(() => {
    if (!items) return;
    const first = items.find(x => x.group === (premium ? 'premium' : 'agency')) || items[0];
    if (first) { setGrp(first.group); setK(first.k); setUp(String(first.price)); }
  }, [items, premium]);
  const choose = (g: string) => { setGrp(g); const f = (items || []).find(x => x.group === g); if (f) { setK(f.k); setUp(String(f.price)); } };
  const chooseItem = (x: CatItem) => { setK(x.k); setUp(String(x.price)); };
  const product = grp !== 'topup' && grp !== 'custom' ? it : undefined;
  const isAcct = product?.kind === 'account';
  const a = Number(amt) || 0;
  const fee = Math.round(a * me.topup_pct) / 100;
  const unit = Math.round((Number(up) || 0) * 100) / 100;
  const n = product?.kind === 'funnel' ? 1 : qty;
  const special = !!product && unit > 0 && Math.abs(unit - product.price) > 0.004;
  const free = !!noMin || me.agent.role === 'manager'; // the manager and the owner: any price > 0
  const minUnit = product && !free ? Math.round(product.price * (1 - capPct / 100) * 100) / 100 : 0.01;
  const tooLow = !!product && unit > 0 && unit + 0.004 < minUnit;
  const total = grp === 'topup' ? Math.round((a + fee) * 100) / 100 : grp === 'custom' ? a : product ? Math.round(unit * n * 100) / 100 : 0;
  const min = noMin || me.agent.role === 'manager' ? 1 : me.topup_min || 30; // v134: the manager (and the owner) may make a smaller top-up link
  const per = product?.kind === 'funnel' ? 'month' : product?.kind === 'custom' ? 'item' : 'account';
  const curBody = (): Record<string, unknown> => product
    ? { item: product.k, qty: n, ...(special ? { unit_price: unit } : {}), ...(isAcct ? { bm_id: shareMode === 'bm' || !me.meta_email ? bm : '', tier, share_mode: me.meta_email ? shareMode : 'bm', client_email: cEmail } : {}) }
    : { kind: grp, amount: amt, act_id: act, label: cLabel };
  const curLabel = () => product ? `${product.kind === 'funnel' ? '' : n + ' × '}${product.label}` : grp === 'topup' ? `Top-up ${usd(a)} + fee` : cLabel || 'Custom';
  const curOk = picked && total > 0 && !tooLow && !(grp === 'topup' && a < min) && !(grp === 'custom' && a < 1);
  const cartTotal = Math.round(cart.reduce((x, c) => x + c.total, 0) * 100) / 100;
  function addToCart() {
    if (!curOk) return;
    if (cart.length >= 9) { toast('Maximum 10 products in one link', 'err'); return; }
    setCart(c => [...c, { body: curBody(), label: curLabel(), total }]);
    setAmt(''); setAct(''); setCLabel(''); setQty(1); setBm(''); setCEmail(''); setPicked(false);
    toast('Added. Tap the next product, or create the link.');
  }
  async function create() {
    if (!leadId) return;
    setBusy(true);
    try {
      const items = [...cart.map(c => c.body), ...(curOk ? [curBody()] : [])];
      const body = cart.length ? { lead_id: leadId, items } : { lead_id: leadId, ...curBody() };
      const r = await api<{ url: string; message: string }>('paylink', body);
      setCart([]);
      sendCid.current = ''; setMade(r); setMsg(r.message); onDone(); void loadLinks();
    } catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); }
  }
  async function sendIt() {
    if (!leadId) return;
    setBusy(true);
    if (!sendCid.current) sendCid.current = `${leadId}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`; // bh2 #8: a second tap after a timeout reuses it → not sent twice
    try { await api('send', { lead_id: leadId, text: msg, cid: sendCid.current }); sendCid.current = ''; toast('Link sent to the client'); onDone(); onClose(); }
    catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); }
  }
  async function cancel(l: PayLink) {
    if (!confirm(`Cancel payment link ${l.code} (${usd(l.total)})? The client can no longer pay it.`)) return;
    try { await api('paylink_cancel', { id: l.id }); toast('Link cancelled'); void loadLinks(); onDone(); } catch (e) { toast((e as Error).message, 'err'); }
  }
  const copy = (t: string) => { try { void navigator.clipboard.writeText(t); toast('Copied'); } catch { /* ignore */ } };
  const openN = links.filter(l => ['new', 'pending_payment'].includes(l.status)).length;
  return (
    <Sheet open={open} onClose={onClose} title="Crypto payment link">
      {made ? (
        <>
          <div className="mb-3 flex items-center gap-2.5 rounded-xl bg-tg-input py-2 pl-2.5 pr-2 text-[13.5px]" data-pl-made><span className="af-tile bg-[#34C759]"><Check size={17} strokeWidth={2.6} /></span><b className="min-w-0 flex-1 truncate text-tg-link">{made.url}</b><Btn kind="soft" size="sm" onClick={() => copy(made.url)}><Copy size={14} aria-hidden />Copy</Btn></div>
          <Field label="Message to the client (you can edit it)"><textarea className={inputCls} rows={8} value={msg} onChange={e => { setMsg(e.target.value); sendCid.current = ''; }} /></Field>
          <Btn busy={busy} onClick={() => void sendIt()} className="w-full !min-h-[44px] !bg-[#3390EC] !text-white">Send to client</Btn>
          <button onClick={() => copy(msg)} className="mt-2 w-full rounded-xl py-2.5 text-[14px] text-tg-link">Copy message</button>
          <p className="mt-2 text-[12.5px] text-tg-sub">When the client pays, the {grp === 'topup' ? 'top-up' : 'sale'} is recorded for {who || 'you'} automatically, the manager gets a task{who ? '' : ' and you get a notification'}. Don’t mark it again.</p>
        </>
      ) : (
        <>
          {links.length > 0 && (
            <div className="mb-4 rounded-xl bg-tg-input" data-chat-links>
              <button type="button" onClick={() => setLinksOpen(o => !o)} aria-expanded={linksOpen} className="flex w-full items-center gap-2 px-3.5 py-2.5 text-left text-[13.5px] font-medium">
                <span className="flex-1">Links in this chat · {links.length}{openN ? ` · ${openN} open` : ''}</span>
                <ChevronDown size={17} className={clsx('text-tg-sub transition-transform', linksOpen && 'rotate-180')} />
              </button>
              {linksOpen && <div className="af-sec space-y-2 px-2.5 pb-2.5">
                {links.map(l => (
                  <div key={l.id} className="rounded-lg bg-tg-panel px-3 py-2 text-[13.5px]">
                    <div className="flex items-center justify-between gap-2"><span className="min-w-0 truncate">{l.label}</span><b className="tabular-nums">{usd(l.total)}</b></div>
                    {!!l.list_price && <div className="mt-0.5 text-[12px] text-tg-warn">Special price (normal ${l.list_price} each)</div>}
                    {['new', 'pending_payment'].includes(l.status) && (l.paid_usd || 0) > 0 && <div data-short-link className="mt-1.5 rounded-lg bg-tg-warn/15 px-2.5 py-1.5 text-[12.5px] text-tg-warn">Short: got {usd(l.paid_usd || 0)} · {usd(l.due || 0)} still due. Confirms when the rest is paid on the same link.</div>}
                    <div className="mt-1 flex items-center gap-3 text-[12.5px]">
                      <span className={LINK_ST[l.status]?.[1]}>{LINK_ST[l.status]?.[0] || l.status}</span>
                      <span className="text-tg-sub">{l.code}</span>
                      {['new', 'pending_payment'].includes(l.status) && <>
                        <button className="ml-auto text-tg-link" onClick={() => copy(l.url)}>Copy link</button>
                        {(l.paid_usd || 0) > 0 ? <span className="text-tg-warn">Part paid {usd(l.paid_usd || 0)}</span> : <button className="text-tg-bad" onClick={() => void cancel(l)}>Cancel</button>}
                      </>}
                    </div>
                  </div>
                ))}
              </div>}
            </div>
          )}
          <div onClickCapture={() => setPicked(true)} onInput={() => setPicked(true)} className={clsx(!picked && 'opacity-60')} data-pl-form>
          {!picked && <p className="mb-2 text-[13px] text-tg-link">Tap the next product to add it, or create the link.</p>}
          <H t="Product" />
          <div className={clsx(sheetGroup, 'af-tiles')} data-pl-groups role="radiogroup">
            {groups.map(([g, l]) => {
              const first = (items || []).find(x => x.group === g);
              return (
                <button key={g} type="button" role="radio" aria-checked={grp === g} aria-pressed={grp === g} onClick={() => choose(g)} className="af-row !min-h-[46px] !py-2">
                  <Ico k={g} /><span className="min-w-0 flex-1 truncate text-[15px] font-medium">{l}</span>
                  <span className="shrink-0 text-[14px] text-tg-sub af-num">{first ? `$${first.price}${first.kind === 'funnel' ? '/mo' : ''}` : g === 'topup' ? `+${me.topup_pct}%` : 'any'}</span><Radio on={grp === g} />
                </button>
              );
            })}
          </div>
          {!items && grp !== 'topup' && grp !== 'custom' && <p className="mt-2 px-1 text-[13.5px] text-tg-sub">Loading products…</p>}
          {product && (<>
            {inGrp.length > 1 && <><H t="Option" /><div data-acct-choice><Seg full value={product.k} onChange={k => { const x = inGrp.find(i => i.k === k); if (x) chooseItem(x); }} items={inGrp.map(x => [x.k, `${x.short} · $${x.price}`] as [string, string])} /></div></>}
            <p className="mt-2 px-1 text-[12.5px] leading-snug text-tg-sub" data-pl-product>{product.label} · ${product.price} {product.unit}{product.full ? ' · client tops up himself, no fee; 1 account + 2 replacements. When paid, the manager gets a FULL ACCESS task (not shared automatically).' : product.k === 'fb_old' ? ' · we create the Facebook account + Business Manager; delivered by you in the chat.' : product.kind === 'funnel' ? ' · 1 month.' : ''}</p>
            <H t="Details" />
            <div className={sheetGroup}>
              {product.kind !== 'funnel' && <div className="af-row"><span className="flex-1 text-[15px]">{product.kind === 'account' ? 'Accounts' : 'How many'}</span><Stepper v={qty} set={setQty} max={50} /></div>}
              <div className="af-row"><span className="min-w-0 flex-1 text-[15px]">{product.kind === 'funnel' ? 'Price per month' : product.kind === 'account' ? 'Price per account' : 'Price each'}</span><PriceIn v={up} set={setUp} min={minUnit} bad={tooLow} label={`Price per ${per} (USD)`} /></div>
            </div>
            {special && <p data-special-note className="af-note warn mt-2 !py-2 text-[13px] text-tg-warn">Special price (${unit} instead of ${product.price}{product.kind === 'funnel' ? ' / month' : ''})</p>}
            {tooLow && <p className="mt-2 px-1 text-[13px] text-tg-bad">You can lower the price by at most {capPct}%: the lowest is ${minUnit}. Ask the manager or the admin.</p>}
            {isAcct && <H t="Client" />}
            {isAcct && me.meta_on && me.meta_email && <div className="mb-2.5"><Seg full value={shareMode} onChange={v => setShareMode(v as 'bm' | 'email')} items={[['bm', 'Client’s BM ID'], ['email', 'Email invite']]} /></div>}
            {isAcct && (shareMode === 'bm' || !me.meta_email ? <Field label="Business Manager ID (optional)" hint={me.meta_on ? (me.auto_acct ? 'With the BM ID the account is shared automatically when paid.' : 'When paid, it goes to the manager to approve.') : undefined}><input className={inputCls} inputMode="numeric" placeholder="1234567890123456" value={bm} onChange={e => setBm(e.target.value)} /></Field>
              : <Field label="Client’s Facebook email" hint="When paid it goes to the manager, who picks the account and sends the invite."><input className={inputCls} type="email" value={cEmail} onChange={e => setCEmail(e.target.value)} /></Field>)}
          </>)}
          {grp === 'topup' && (<>
            <H t="Top-up" />
            <Field label={`Top-up amount (USD) · min $${min}`}><input className={inputCls} type="number" inputMode="decimal" min={min} placeholder="100" value={amt} onChange={e => setAmt(e.target.value)} /></Field>
            <AccountPicker api={api} leadId={leadId} open={open && grp === 'topup'} value={act} onChange={setAct} />
            {a > 0 && <div className={sheetGroup}>
              <div className="af-row !min-h-[44px]"><span className="flex-1 text-[14.5px] text-tg-sub">Top-up</span><span className="af-num">{usd(a)}</span></div>
              <div className="af-row !min-h-[44px]"><span className="flex-1 text-[14.5px] text-tg-sub">Fee ({me.topup_pct}%)</span><span className="af-num">{usd(fee)}</span></div>
            </div>}
          </>)}
          {grp === 'custom' && (<>
            <H t="Custom" />
            <Field label="What is it for" hint="The client sees this on the payment page. Paid = recorded as a sale."><input className={inputCls} maxLength={80} placeholder="e.g. Extra service" value={cLabel} onChange={e => setCLabel(e.target.value)} /></Field>
            <Field label="Amount (USD) · no fee added"><input className={inputCls} type="number" inputMode="decimal" min={1} placeholder="60" value={amt} onChange={e => setAmt(e.target.value)} /></Field>
          </>)}
          </div>
          <H t={cart.length ? 'In this link' : 'More products'} />
          <div className={sheetGroup} data-pl-cart>
            {cart.map((c, i) => <div key={i} className="af-row !min-h-[44px]"><span className="min-w-0 flex-1 truncate text-[14.5px]">{c.label}</span><b className="af-num">{usd(c.total)}</b><button aria-label="Remove" className="-mr-1 grid h-7 w-7 place-items-center rounded-full text-tg-bad hover:bg-tg-hover" onClick={() => setCart(x => x.filter((_, j) => j !== i))}><XIcon size={15} /></button></div>)}
            {cart.length > 0 && curOk && <div className="af-row !min-h-[44px] text-tg-sub"><span className="min-w-0 flex-1 truncate text-[14.5px]">+ {curLabel()} (above)</span><span className="af-num">{usd(total)}</span><span className="w-6" /></div>}
            <button type="button" data-pl-add disabled={!curOk} onClick={addToCart} className="af-row !min-h-[44px] text-[15px] font-medium !text-tg-link disabled:opacity-40"><Plus size={18} aria-hidden />Add another product to this link</button>
          </div>
          <Foot>
            <div className="mb-2 flex items-baseline justify-between gap-3"><span className="text-[14px] text-tg-sub">Client pays</span><b className="text-[22px] tracking-tight text-tg-ok af-num" data-pl-total>{usd(Math.round((cartTotal + (curOk || !cart.length ? total : 0)) * 100) / 100)}</b></div>
            <Btn busy={busy} disabled={cart.length ? !(cart.length + (curOk ? 1 : 0) >= 1) : !curOk} onClick={() => void create()} className="w-full !min-h-[44px] !bg-[#3390EC] !text-white"><Link2 size={17} aria-hidden />{cart.length ? `Create one link · ${cart.length + (curOk ? 1 : 0)} products` : 'Create payment link'}</Btn>
          </Foot>
        </>
      )}
    </Sheet>
  );
}

const DEL_REASONS = ['Spam', 'Abusive', 'No budget', 'Time-waster', 'Other'] as const;
/** v136: ask the admin to delete a junk chat (replaces the old text prompt). */
export function DeleteRequestSheet({ open, onClose, api, leadId, onDone }: { open: boolean; onClose: () => void; api: Api; leadId: number | null; onDone: () => void }) {
  const toast = useToast();
  const [why, setWhy] = useState<string>(''); const [note, setNote] = useState(''); const [busy, setBusy] = useState(false);
  useEffect(() => { if (open) { setWhy(''); setNote(''); } }, [open]);
  const reason = [why === 'Other' ? '' : why, note.trim()].filter(Boolean).join(': ');
  async function go() {
    if (!leadId || !reason) return;
    setBusy(true);
    try { await api('del_request', { lead_id: leadId, reason }); toast('Sent to the admin'); onClose(); onDone(); } catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); }
  }
  return (
    <Sheet open={open} onClose={onClose} title="Request chat delete">
      <p className="mb-3 text-[14px] text-tg-sub">The admin sees your reason and decides. Nothing is deleted in Telegram or WhatsApp.</p>
      <div className="mb-3 flex flex-wrap gap-2" data-del-reasons>
        {DEL_REASONS.map(r => <button key={r} type="button" aria-pressed={why === r} onClick={() => setWhy(r)} className={clsx('af-press min-h-[36px] rounded-full px-3.5 text-[14px] font-medium', why === r ? 'bg-tg-acc text-white' : 'bg-tg-input text-tg-text')}>{r}</button>)}
      </div>
      <Field label={why === 'Other' ? 'Reason' : 'Note (optional)'}><input className={inputCls} maxLength={180} value={note} onChange={e => setNote(e.target.value)} placeholder={why === 'Other' ? 'Why should it be deleted?' : 'e.g. sends links again and again'} /></Field>
      <Btn kind="danger" busy={busy} disabled={!reason} onClick={() => void go()} className="w-full">Send to admin</Btn>
    </Sheet>
  );
}
