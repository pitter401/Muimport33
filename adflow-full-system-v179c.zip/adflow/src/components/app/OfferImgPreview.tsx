'use client';

// v140: small preview of each line's offer image (the one sent with the welcome buttons), labelled with its line.
import { useEffect, useState } from 'react';

type Api = <T = any>(path: string, body?: unknown) => Promise<T>;
type Row = { line: 'agency' | 'premium' | 'funnel'; url: string; own: boolean; preview: string };
const NAME = { agency: 'Agency', premium: 'Premium', funnel: 'Funnel' } as const;

export function OfferImgPreview({ api, on }: { api: Api; on: boolean }) {
  const [rows, setRows] = useState<Row[] | null>(null);
  useEffect(() => { api<{ lines: Row[] }>('offer_images').then(r => setRows(r.lines)).catch(() => setRows([])); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  if (!rows) return null;
  return (
    <div data-offer-preview className={'mb-3 rounded-xl bg-tg-input p-3 ' + (on ? '' : 'opacity-50')}>
      <p className="mb-2 text-[12.5px] text-tg-sub">Each line gets only its own image (Premium chats: the Premium image, never the Agency price). Prices and delivery come from your settings. Own image: Settings → Channel ads → Image (https link).</p>
      <div className="grid grid-cols-3 gap-2">
        {rows.map(r => (
          <figure key={r.line} data-offer-line={r.line} className="min-w-0">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={r.preview} alt={NAME[r.line] + ' offer image'} className="aspect-video w-full rounded-lg bg-black/20 object-cover" loading="lazy" />
            <figcaption className="mt-1 truncate text-[11.5px] text-tg-sub"><b className="text-tg-text">{NAME[r.line]}</b> · {r.own ? 'own image' : 'built-in'}{r.url ? '' : ' · not sent: set PUBLIC_URL'}</figcaption>
          </figure>
        ))}
      </div>
    </div>
  );
}
