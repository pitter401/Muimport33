'use client';

/* v150 — Admin → Comments: every comment on the Facebook Page (posts + all active ads) and on the ads' Instagram posts.
   Scam / fake / competitor comments are found by rules + AI and can be auto-deleted; anything can be deleted by hand. */
import { useCallback, useEffect, useState } from 'react';
import clsx from 'clsx';
import { RefreshCw, Trash2, Check, ChevronDown, ExternalLink } from 'lucide-react';
import { Btn, Toggle, Field, inputCls, useToast, listTime, Page, Chips, ToggleRow, EmptyState, Skeleton } from './ui';

type Api = <T = any>(path: string, body?: unknown) => Promise<T>;
type Row = { id: string; src: 'fb' | 'ig'; ad_id: string | null; ad_name: string | null; kind: 'ad' | 'post'; author: string | null; text: string; created_at: number; label: '' | 'bad' | 'doubt' | 'ok'; reason: string | null; status: 'live' | 'deleted' | 'auto_deleted' | 'gone'; deleted_at: number | null; permalink: string | null };
type Status = { connected: boolean; page: string; accounts: { id: string; name: string }[]; app_id: string; has_secret: boolean; proxy: string; token_exp: number; on: boolean; auto: boolean; ai: boolean; has_ai_key: boolean; every: number; words: string; last_sync: number; last_err: string; ads: { ad_id: string; name: string; fb_post: string | null; ig_media: string | null; n: number; bad: number }[] };
type Counts = { all_n: number; bad: number; doubt: number; deleted: number; today: number };
type F = 'all' | 'check' | 'auto' | 'deleted' | 'fb' | 'ig';

const PROXY_HINT = 'http://user:pass@host:port · socks5://user:pass@host:port · host:port:user:pass';

function Connect({ api, st, onDone }: { api: Api; st: Status | null; onDone: () => void }) {
  const toast = useToast();
  const [f, setF] = useState({ proxy: '', app_id: st?.app_id || '', app_secret: '', token: '' });
  const [busy, setBusy] = useState(false);
  const go = async () => {
    setBusy(true);
    try {
      const r = await api<{ page: string; accounts: number; expires: number }>('cm_connect', { ...f, proxy: f.proxy || undefined, app_secret: f.app_secret || undefined });
      toast(`Connected: ${r.page} · ${r.accounts} ad account${r.accounts === 1 ? '' : 's'}`);
      setF(x => ({ ...x, token: '', app_secret: '' })); onDone();
    } catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); }
  };
  return (
    <div className="af-card p-4">
      <p className="mb-3 text-[13px] text-tg-sub">Graph API Explorer → your app → Generate Access Token (Page + ad accounts selected) → paste it here. The server turns it into a 60-day token; the Page token never ends.</p>
      <Field label="Proxy (the one your Facebook profile uses)" hint={st?.proxy ? `Saved: ${st.proxy} — leave empty to keep it` : PROXY_HINT}>
        <input className={inputCls} value={f.proxy} onChange={e => setF({ ...f, proxy: e.target.value })} placeholder={st?.proxy ? 'keep saved proxy' : 'socks5://user:pass@host:port'} autoComplete="off" />
      </Field>
      <Field label="App ID"><input className={inputCls} inputMode="numeric" value={f.app_id} onChange={e => setF({ ...f, app_id: e.target.value })} /></Field>
      <Field label="App Secret" hint={st?.has_secret ? 'Saved — leave empty to keep it' : 'App settings → Basic → Show'}>
        <input className={inputCls} type="password" value={f.app_secret} onChange={e => setF({ ...f, app_secret: e.target.value })} placeholder={st?.has_secret ? '•••••• (saved)' : ''} autoComplete="off" />
      </Field>
      <Field label="Access token (from Graph API Explorer)"><textarea className={clsx(inputCls, 'h-24 font-mono text-[12px]')} value={f.token} onChange={e => setF({ ...f, token: e.target.value })} autoComplete="off" /></Field>
      <Btn busy={busy} onClick={go} className="w-full">{st?.connected ? 'Save new token' : 'Connect'}</Btn>
    </div>
  );
}

export function CommentsView({ api, back }: { api: Api; back?: () => void }) {
  const toast = useToast();
  const [st, setSt] = useState<Status | null>(null);
  const [rows, setRows] = useState<Row[] | null>(null);
  const [counts, setCounts] = useState<Counts | null>(null);
  const [f, setF] = useState<F>('all');
  const [ad, setAd] = useState('');
  const [setup, setSetup] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [words, setWords] = useState('');
  const [proxy, setProxy] = useState('');

  const loadSt = useCallback(() => api<Status>('cm_status').then(s => { setSt(s); setWords(s.words); return s; }).catch(e => { toast((e as Error).message, 'err'); return null; }), [api, toast]);
  const loadRows = useCallback(() => {
    const p = new URLSearchParams();
    if (f === 'check') p.set('label', 'bad');
    if (f === 'auto') p.set('status', 'auto');
    if (f === 'deleted') p.set('status', 'deleted');
    if (f === 'fb' || f === 'ig') p.set('src', f);
    if (ad) p.set('ad', ad);
    return Promise.all([
      api<{ rows: Row[]; counts: Counts }>('cm_list?' + p.toString()),
      f === 'check' ? api<{ rows: Row[] }>('cm_list?label=doubt' + (ad ? '&ad=' + encodeURIComponent(ad) : '')) : Promise.resolve({ rows: [] as Row[] }),
    ]).then(([a, b]) => { setRows([...a.rows, ...b.rows].sort((x, y) => y.created_at - x.created_at)); setCounts(a.counts); }).catch(e => toast((e as Error).message, 'err'));
  }, [api, f, ad, toast]);
  useEffect(() => { void loadSt(); }, [loadSt]);
  useEffect(() => { void loadRows(); }, [loadRows]);

  const sync = async () => {
    setSyncing(true);
    try { const r = await api<{ new: number; deleted: number; ads: number }>('cm_sync', {}); toast(`${r.ads} active ads · ${r.new} new comment${r.new === 1 ? '' : 's'}${r.deleted ? ` · ${r.deleted} auto-deleted` : ''}`); await Promise.all([loadSt(), loadRows()]); }
    catch (e) { toast((e as Error).message, 'err'); void loadSt(); } finally { setSyncing(false); }
  };
  const save = async (b: Record<string, unknown>) => { try { await api('cm_save', b); await loadSt(); toast('Saved'); } catch (e) { toast((e as Error).message, 'err'); } };
  const del = async (r: Row) => {
    if (!confirm(`Delete this ${r.src === 'ig' ? 'Instagram' : 'Facebook'} comment? It can't be brought back.\n\n"${r.text.slice(0, 140)}"`)) return;
    try { await api('cm_delete', { ids: [r.id] }); toast('Deleted'); void loadRows(); } catch (e) { toast((e as Error).message, 'err'); }
  };
  const keep = async (r: Row) => { try { await api('cm_keep', { ids: [r.id] }); void loadRows(); } catch (e) { toast((e as Error).message, 'err'); } };

  const days = st?.token_exp ? Math.ceil((st.token_exp - Date.now()) / 86400000) : null;
  return (
    <Page title="Comments" back={back} right={st?.connected && st.on ? <Btn kind="ghost" busy={syncing} onClick={sync}><RefreshCw size={16} />Check now</Btn> : undefined}>
      {!st ? <Skeleton rows={3} /> : !st.connected ? <Connect api={api} st={st} onDone={() => { void loadSt(); void sync(); }} /> : (
        <>
          <div data-cm-master className={clsx('mb-3 flex items-center justify-between gap-3 rounded-2xl p-4', st.on ? 'bg-tg-green/15 ring-1 ring-tg-green/40' : 'bg-tg-panel ring-1 ring-tg-line')}>
            <span className="min-w-0"><span className="block text-[16px] font-bold">Comments system {st.on ? 'ON' : 'OFF'}</span>
              <span className="block text-[12.5px] text-tg-sub">{st.on ? `Working: checks every ${st.every === 60 ? '1 hour' : st.every + ' min'}${st.auto ? ', auto-deletes bad comments' : ''}, delete buttons work` : 'Stopped: no checking, no auto-delete, no deleting. The saved list stays.'}</span></span>
            <Toggle on={st.on} onChange={v => void save({ on: v }).then(() => { if (v) void sync(); })} label="Comments system" />
          </div>
          <div className="mb-3 af-card p-4">
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[14px]">
              <b>{st.page}</b>
              <span className="text-tg-sub">{st.accounts.length} ad account{st.accounts.length === 1 ? '' : 's'} · {st.ads.length} active ad{st.ads.length === 1 ? '' : 's'}</span>
              <span className="text-tg-sub">{st.on ? `checked ${st.last_sync ? listTime(st.last_sync) : '—'} · every ${st.every === 60 ? '1 hour' : st.every + ' min'}` : 'checking is OFF'}</span>
              <span className={clsx('rounded-full px-2 py-0.5 text-[12px]', st.auto ? 'bg-tg-red/15 text-tg-bad' : 'bg-tg-chip text-tg-sub')}>Auto-delete {st.auto ? 'ON' : 'OFF'}</span>
              {days !== null && <span className={clsx('text-[12.5px]', days <= 7 ? 'text-tg-orange' : 'text-tg-sub')}>token ends in {days} day{days === 1 ? '' : 's'}</span>}
            </div>
            {st.last_err && <p className="mt-2 rounded-lg bg-tg-red/15 px-3 py-2 text-[13px] text-tg-bad">{st.last_err}</p>}
            <button onClick={() => setSetup(v => !v)} className="mt-2 inline-flex items-center gap-1 text-[13.5px] text-tg-link">Settings <ChevronDown size={15} className={clsx('transition-transform', setup && 'rotate-180')} /></button>
            {setup && (
              <div className="mt-3">
                <ToggleRow title="Auto-delete scam / fake / competitor comments" sub="Deleted comments can't come back — keep it OFF for a few days and check the list first" on={st.auto} onChange={v => save({ auto: v })} tone={st.auto ? 'warn' : undefined} />
                <ToggleRow title="AI check" sub={st.has_ai_key ? 'AI reads each new comment (costs almost nothing). OFF → only the word rules' : 'Needs the Anthropic key in Admin → AI → Setup'} on={st.ai} onChange={v => save({ ai: v })} />
                <Field label="Always delete comments with these words" hint="One per line or comma — e.g. a competitor's name or number. Links and phone numbers are always caught.">
                  <textarea className={clsx(inputCls, 'h-20')} value={words} onChange={e => setWords(e.target.value)} />
                </Field>
                <div className="mb-3 flex gap-2"><Btn kind="ghost" onClick={() => save({ words })}>Save words</Btn>
                  <select className={clsx(inputCls, 'w-auto')} value={st.every} onChange={e => save({ every: +e.target.value })}>{[1, 2, 5, 10, 15, 30, 60].map(m => <option key={m} value={m}>{m === 60 ? 'every 1 hour' : `every ${m} min`}</option>)}</select></div>
                <Field label="Proxy" hint={`Saved: ${st.proxy || '—'}. ${PROXY_HINT}`}>
                  <div className="flex gap-2"><input className={inputCls} value={proxy} onChange={e => setProxy(e.target.value)} placeholder="new proxy" autoComplete="off" /><Btn kind="ghost" onClick={() => { if (proxy) void save({ proxy }).then(() => setProxy('')); }}>Save</Btn></div>
                </Field>
                <p className="mb-2 mt-4 text-[13px] font-semibold">New token (every 60 days, or when it stops)</p>
                <Connect api={api} st={st} onDone={() => { void loadSt(); }} />
                <button className="mt-3 text-[13px] text-tg-bad" onClick={async () => { if (confirm('Disconnect comments? The saved list stays.')) { await api('cm_disconnect', {}); void loadSt(); } }}>Disconnect</button>
              </div>
            )}
          </div>

          <Chips className="mb-2" value={f} onChange={setF} items={[
            ['all', 'All', counts?.all_n], ['check', 'To check', (counts?.bad || 0) + (counts?.doubt || 0)], ['auto', 'Auto deleted'], ['deleted', 'Deleted', counts?.deleted],
            ['fb', 'Facebook'], ['ig', 'Instagram'],
          ]} />
          <select className={clsx(inputCls, 'mb-3')} value={ad} onChange={e => setAd(e.target.value)}>
            <option value="">All ads + Page posts</option>
            <option value="posts">Normal Page posts</option>
            {st.ads.map(a => <option key={a.ad_id} value={a.ad_id}>{a.name} · {a.n} comment{a.n === 1 ? '' : 's'}{a.ig_media ? '' : ' (no Instagram)'}</option>)}
          </select>

          {!rows ? <Skeleton rows={4} /> : !rows.length ? <EmptyState text={f === 'check' ? 'Nothing to check 👍' : 'No comments yet'} /> : (
            <div className="space-y-2">
              {rows.map(r => (
                <div key={r.id} data-cm={r.id} className={clsx('af-card p-3', r.status !== 'live' && 'opacity-60')}>
                  <div className="flex flex-wrap items-center gap-1.5 text-[12.5px]">
                    <span className={clsx('rounded-md px-1.5 py-0.5 font-semibold text-white', r.src === 'ig' ? 'bg-[#C13584]' : 'bg-[#1877F2]')}>{r.src === 'ig' ? 'IG' : 'FB'}</span>
                    <b className="text-[13.5px]">{r.author || 'Someone'}</b>
                    <span className="text-tg-sub">{listTime(r.created_at)} · {r.kind === 'post' ? 'Page post' : r.ad_name || 'Ad'}</span>
                    {r.status === 'auto_deleted' && <span className="rounded-full bg-tg-red/15 px-2 py-0.5 text-tg-bad">Auto deleted</span>}
                    {r.status === 'deleted' && <span className="rounded-full bg-tg-chip px-2 py-0.5 text-tg-sub">Deleted</span>}
                    {r.status === 'gone' && <span className="rounded-full bg-tg-chip px-2 py-0.5 text-tg-sub">Already removed</span>}
                    {r.status === 'live' && r.label === 'bad' && <span className="rounded-full bg-tg-red/15 px-2 py-0.5 text-tg-bad">Delete? {r.reason ? '· ' + r.reason : ''}</span>}
                    {r.status === 'live' && r.label === 'doubt' && <span className="rounded-full bg-tg-orange/15 px-2 py-0.5 text-tg-orange">Check {r.reason ? '· ' + r.reason : ''}</span>}
                    {r.permalink && <a href={r.permalink} target="_blank" rel="noreferrer" className="ml-auto text-tg-link" aria-label="Open"><ExternalLink size={14} /></a>}
                  </div>
                  <p className="mt-1.5 whitespace-pre-wrap break-words text-[15px]">{r.text || <i className="text-tg-sub">(no text — sticker / photo)</i>}</p>
                  {r.status === 'live' && (
                    <div className="mt-2 flex gap-2">
                      <button data-cm-del disabled={!st.on} title={st.on ? undefined : 'Turn the Comments system ON first'} onClick={() => del(r)} className="af-press disabled:opacity-40 inline-flex items-center gap-1.5 rounded-full bg-tg-red/15 px-3 py-1.5 text-[13.5px] font-medium text-tg-bad"><Trash2 size={15} />Delete</button>
                      {(r.label === 'bad' || r.label === 'doubt') && <button onClick={() => keep(r)} className="af-press inline-flex items-center gap-1.5 rounded-full bg-tg-chip px-3 py-1.5 text-[13.5px] font-medium"><Check size={15} />Keep</button>}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </Page>
  );
}
