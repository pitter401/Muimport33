'use client';
import { noThen } from './native';
/* v142: phone status bar / nav bar for the agent + admin apps.
 *  - New APK (1.5+): AppUpdater.setBars({ dark, color, navColor, navDark }) → the app paints solid bars in the page colour,
 *    keeps the page out from under them and picks dark icons on a light page (light icons on a dark page).
 *    The page then gets no insets (env(safe-area-inset-top) = 0), so nothing is padded twice.
 *  - Old APKs (edge-to-edge WebView on Android 15): a fixed strip as tall as env(safe-area-inset-top) in the page colour
 *    sits behind the status icons, so scrolling content never shows through. It has 0 height wherever there is no inset.
 * `dark` = DARK ICONS (a light page), like Android's setAppearanceLightStatusBars. */
import { useEffect } from 'react';

export type BarsPlugin = { setBars: (o: { dark: boolean; color: string; navColor?: string; navDark?: boolean }) => Promise<{ ok?: boolean; insets?: boolean } | undefined> };
export type BarsDeps = { plugin: () => Promise<BarsPlugin | null> };
export type BarColors = { top: string; bottom: string };

/** 'rgb(1, 2, 3)' / 'rgba(…)' / '#rrggbb' / '#rgb' → [r, g, b, a] or null */
export function parseColor(s: string | null | undefined): [number, number, number, number] | null {
  if (!s) return null;
  const t = s.trim().toLowerCase();
  let m = t.match(/^rgba?\(\s*([\d.]+)[\s,]+([\d.]+)[\s,]+([\d.]+)(?:[\s,/]+([\d.]+%?))?\s*\)$/);
  if (m) { const a = m[4] == null ? 1 : m[4].endsWith('%') ? parseFloat(m[4]) / 100 : parseFloat(m[4]); return [+m[1], +m[2], +m[3], a]; }
  m = t.match(/^#([0-9a-f]{3}|[0-9a-f]{6})$/);
  if (m) { const h = m[1].length === 3 ? m[1].split('').map(c => c + c).join('') : m[1]; return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16), 1]; }
  return null;
}
export const toHex = (c: [number, number, number, number] | null) => c ? '#' + c.slice(0, 3).map(v => Math.round(v).toString(16).padStart(2, '0')).join('') : '#0e1621';
/** true = a light colour → dark icons on it */
export function isLightColor(s: string) {
  const c = parseColor(s); if (!c) return false;
  const lin = (v: number) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; };
  return 0.2126 * lin(c[0]) + 0.7152 * lin(c[1]) + 0.0722 * lin(c[2]) > 0.4;
}
/** The call the app gets for these page colours. */
export function barsFor(col: BarColors) {
  return { dark: isLightColor(col.top), color: toHex(parseColor(col.top)), navDark: isLightColor(col.bottom), navColor: toHex(parseColor(col.bottom)) };
}

const opaque = (el: Element) => { const c = parseColor(getComputedStyle(el).backgroundColor); return c && c[3] > 0.9 ? c : null; };
const pinned = (el: Element) => { const p = getComputedStyle(el).position; return p === 'fixed' || p === 'sticky'; };
const scroller = (el: Element) => { const s = getComputedStyle(el); return /(auto|scroll)/.test(s.overflowY) && el.scrollHeight > el.clientHeight + 1; };
/** The colour that stays under a screen edge: a header / nav bar that does not scroll, else the background of whatever
 *  holds the scrolling content (never a card that is just passing by). */
export function edgeColor(y: number): string {
  const body = getComputedStyle(document.body).backgroundColor;
  const fallback = opaque(document.body) ? body : 'rgb(14, 22, 33)';
  const docScrolls = (document.scrollingElement?.scrollHeight || 0) > innerHeight + 1;
  const staysPut = (el: Element) => {
    for (let a: Element | null = el; a && a !== document.body; a = a.parentElement) {
      if (pinned(a)) return true;
      if (a !== el && scroller(a)) return false;
    }
    return !docScrolls;
  };
  let el: Element | null = document.elementsFromPoint(Math.round(innerWidth / 2), y).find(e => !(e as HTMLElement).dataset?.statusStrip) || null;
  for (; el && el !== document.body && el !== document.documentElement; el = el.parentElement) {
    const c = opaque(el);
    if (c && staysPut(el)) return `rgb(${c[0]}, ${c[1]}, ${c[2]})`;
  }
  return fallback;
}

/** Sends the colours to the app when they change. Returns true when the app handles the bars natively (new APK). */
export function makeBarSync(deps: BarsDeps) {
  let last = '', native: boolean | null = null, busy: Promise<boolean> | null = null;
  return async (col: BarColors): Promise<boolean> => {
    const b = barsFor(col); const key = JSON.stringify(b);
    if (key === last && native !== null) return native;
    if (busy) await busy.catch(() => null);
    busy = (async () => {
      const p = await deps.plugin().catch(() => null);
      if (!p || typeof p.setBars !== 'function') { native = false; return false; }
      try { const r = await p.setBars(b); last = key; native = r?.insets !== false; }
      catch { native = false; } // old APK: the method does not exist ("not implemented")
      return native;
    })();
    return busy;
  };
}

const realDeps: BarsDeps = {
  plugin: async () => {
    const { registerPlugin, Capacitor } = await import('@capacitor/core');
    if (!Capacitor.isNativePlatform() || !Capacitor.isPluginAvailable('AppUpdater')) return null;
    return noThen(registerPlugin<BarsPlugin>('AppUpdater')); // v144: not a thenable, or `await` hangs
  },
};

/** The strip + the sync. Put it once in each app shell. */
export function StatusBarSync({ deps = realDeps }: { deps?: BarsDeps }) {
  useEffect(() => {
    const sync = makeBarSync(deps);
    const root = document.documentElement;
    let t: ReturnType<typeof setTimeout> | null = null, scrolling = 0;
    const run = () => {
      t = null;
      if (Date.now() - scrolling < 250) { t = setTimeout(run, 260); return; }
      const strip = document.querySelector<HTMLElement>('[data-status-strip]');
      const sat = strip ? strip.getBoundingClientRect().height : 0;
      const col = { top: edgeColor(Math.max(1, sat + 1)), bottom: edgeColor(innerHeight - 2) };
      if (strip) strip.style.backgroundColor = col.top;
      root.style.setProperty('--sb-color', col.top);
      void sync(col).then(n => { root.classList.toggle('native-bars', n); });
    };
    const soon = () => { if (!t) t = setTimeout(run, 120); };
    run();
    const mo = new MutationObserver(soon);
    mo.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'data-chan'] });
    const mq = matchMedia('(prefers-color-scheme: dark)');
    mq.addEventListener?.('change', soon);
    const onScroll = () => { scrolling = Date.now(); };
    const onVis = () => { if (document.visibilityState === 'visible') soon(); };
    addEventListener('scroll', onScroll, { capture: true, passive: true });
    addEventListener('resize', soon);
    document.addEventListener('visibilitychange', onVis);
    return () => {
      mo.disconnect(); mq.removeEventListener?.('change', soon); if (t) clearTimeout(t);
      removeEventListener('scroll', onScroll, { capture: true } as EventListenerOptions); removeEventListener('resize', soon); document.removeEventListener('visibilitychange', onVis);
    };
  }, [deps]);
  return <div data-status-strip="1" aria-hidden className="af-status-strip" />;
}
