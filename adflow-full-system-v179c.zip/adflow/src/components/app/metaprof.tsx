'use client';

/** v152: Ad accounts by profile (one FB profile behind the iProxy line) — profiles, the queue, settings, limits, manual share. */
import { useCallback, useEffect, useRef, useState } from 'react';
import { RefreshCw, Plus, KeyRound, Trash2, Globe, Clock } from 'lucide-react';
import clsx from 'clsx';
import { makeApi, useToast, Sheet, Field, inputCls, Btn, Toggle, useInterval, listTime, Skeleton } from './ui';

type Api = ReturnType<typeof makeApi>;
const usd = (n: number | null | undefined) => (n == null ? '—' : '$' + (Math.round(Number(n) * 100) / 100).toLocaleString('en-US', { minimumFractionDigits: Number(n) % 1 ? 2 : 0, maximumFractionDigits: 2 }));
const card = 'af-card p-3.5';
const H = ({ children }: { children: React.ReactNode }) => <h4 className="mb-2 mt-5 text-[13px] font-semibold uppercase tracking-wide text-tg-link">{children}</h4>;
export const CAT: Record<string, [string, string]> = { premium: ['Premium', 'bg-[#f59e0b] text-black'], std: ['$25', 'bg-[#4FA3F7]/20 text-tg-link'], none: ['Set limit', 'bg-tg-orange/15 text-tg-orange'] };
const PSTATE: Record<string, [string, string]> = { new: ['Connecting…', 'bg-tg-acc/20 text-tg-link'], ok: ['OK', 'bg-tg-green/15 text-tg-ok'], blocked: ['API blocked', 'bg-tg-red/15 text-tg-bad'], error: ['Error', 'bg-tg-orange/15 text-tg-orange'], ip_error: ['IP not changing', 'bg-tg-red/15 text-tg-bad'] };
const JSTATE: Record<string, [string, string]> = { queued: ['Waiting', 'bg-tg-orange/15 text-tg-orange'], running: ['Running', 'bg-tg-acc/20 text-tg-link'], done: ['Done', 'bg-tg-green/15 text-tg-ok'], failed: ['Failed', 'bg-tg-red/15 text-tg-bad'], cancelled: ['Cancelled', 'bg-white/10 text-tg-sub'] };
export const Pill = ({ m, k }: { m: Record<string, [string, string]>; k: string }) => { const [l, c] = m[k] || [k, 'bg-white/10 text-tg-sub']; return <span className={clsx('shrink-0 whitespace-nowrap rounded-full px-2 py-0.5 text-[11.5px] font-bold', c)}>{l}</span>; };

/* ============================== PROFILES TAB ============================== */
export function Profiles({ api, isAdmin, onAcct }: { api: Api; isAdmin?: boolean; onAcct: (a: string) => void }) {
  const toast = useToast();
  const [d, setD] = useState<any>(null); const [add, setAdd] = useState(false); const [open, setOpen] = useState<number | null>(null);
  const load = useCallback(async () => { try { setD(await api('meta/profiles')); } catch (e) { toast((e as Error).message, 'err'); } }, [api, toast]);
  useEffect(() => { void load(); }, [load]);
  useInterval(() => void load(), 8000);
  if (!d) return <div className="p-3"><Skeleton rows={3} h={68} /></div>;
  return (
    <div data-profiles>
      <QSettingsCard api={api} q={d.q} isAdmin={isAdmin} saved={load} />
      <H>Profiles ({d.profiles.length})</H>
      {d.profiles.map((p: any) => (
        <button key={p.id} data-profile={p.id} onClick={() => setOpen(p.id)} className="mb-2 block w-full af-card p-3 text-left">
          <span className="flex items-center gap-2"><span className="min-w-0 flex-1 truncate text-[16px] font-semibold">{p.ix} · {p.name}</span>{p.queued > 0 && <Pill m={{ x: [`${p.queued} in queue`, 'bg-tg-acc/20 text-tg-link'] }} k="x" />}<Pill m={PSTATE} k={p.status} /></span>
          <span className="mt-0.5 block text-[12.5px] text-tg-sub">{p.bms.length} BM{p.bms.length === 1 ? '' : 's'} · {p.accounts} account{p.accounts === 1 ? '' : 's'} · {p.free} free · {p.sold} with client{p.no_limit ? <span className="text-tg-orange"> · {p.no_limit} need the daily limit</span> : ''}</span>
          {p.bms.length > 0 && <span className="mt-1.5 flex flex-wrap gap-1.5">{p.bms.map((b: any) => <span key={b.bm_id} className="rounded-full bg-tg-input px-2.5 py-0.5 text-[12px]">{b.name || b.bm_id} · {b.accounts}</span>)}</span>}
          <span className="mt-0.5 block text-[12.5px] text-tg-sub">Last sync {p.last_sync ? listTime(p.last_sync) : '—'}{p.last_ip ? ` · IP ${p.last_ip.replace(/^(\d+\.\d+)\.\d+\.\d+$/, '$1.x.x')}` : ''}{p.token_days != null ? <span className={p.token_days <= 7 ? 'text-tg-orange' : ''}> · token {p.token_days} days</span> : ''}{p.fb_name ? ` · ${p.fb_name}` : ''}</span>
          {p.error && p.status !== 'ok' && <span className="mt-1 block text-[12px] text-tg-bad">{p.error}</span>}
        </button>
      ))}
      {isAdmin && <Btn kind="ghost" className="w-full" onClick={() => setAdd(true)}><Plus size={18} />Add profile</Btn>}
      <AddProfileSheet api={api} open={add} onClose={() => setAdd(false)} done={() => { setAdd(false); void load(); }} />
      <ProfileSheet api={api} id={open} isAdmin={isAdmin} onClose={() => setOpen(null)} changed={load} onAcct={a => { setOpen(null); onAcct(a); }} />
    </div>
  );
}

/** v153: counts each time a sheet opens. Forms reset only then, not when the page data refreshes (coming back to the app, polling). */
export function useOpenKey(open: boolean) {
  const [k, setK] = useState(0);
  const was = useRef(false);
  useEffect(() => { if (open && !was.current) setK(x => x + 1); was.current = open; }, [open]);
  return open ? k : 0;
}
function QSettingsCard({ api, q, isAdmin, saved }: { api: Api; q: any; isAdmin?: boolean; saved: () => void }) {
  const toast = useToast();
  const [ed, setEd] = useState(false);
  const [v, setV] = useState<any>({});
  const okE = useOpenKey(ed);
  const [ipc, setIpc] = useState<any>(null); const [ipBusy, setIpBusy] = useState(false);
  async function checkIp() { setIpBusy(true); try { setIpc(await api('meta/ip_check')); } catch (e) { toast((e as Error).message, 'err'); } finally { setIpBusy(false); } }
  useEffect(() => { setV({ proxy: '', ip_link: '', wait_s: String(q.wait_s), country: q.country, every_min: String(q.every_min), cat_usd: String(q.cat_usd), post_chat: q.post_chat, post_next: String(q.post_next), digest_time: q.digest_time || '22:00' }); }, [okE]); // eslint-disable-line react-hooks/exhaustive-deps
  const [dBusy, setDBusy] = useState(false);
  // v158: closed by default (the page stays short); remembered on this phone
  const [openQ, setOpenQ0] = useState(() => { try { return localStorage.getItem('af_q_open') === '1'; } catch { return false; } });
  const setOpenQ = (v: boolean) => { setOpenQ0(v); try { localStorage.setItem('af_q_open', v ? '1' : '0'); } catch { /* */ } };
  async function digestNow() {
    if (dBusy) return;
    setDBusy(true);
    try {
      let r = await api<any>('meta/digest_now', {});
      if (r.already) { if (!confirm(`Today's top-up post already went at ${r.at}.\n\nPost it again? The channel and the story get it a 2nd time.`)) return; r = await api<any>('meta/digest_now', { force: 1 }); }
      toast(r.started ? `Posting ${r.n} top-up${r.n === 1 ? '' : 's'}… check the channel in a minute` : r.ok ? 'No top-ups today' : r.error || 'Not posted', r.ok ? undefined : 'err');
      saved();
    } catch (e) { toast((e as Error).message, 'err'); } finally { setDBusy(false); }
  }
  const sw = async (k: string, val: boolean) => { try { await api('meta/q_save', { [k]: val }); toast('Saved'); saved(); } catch (e) { toast((e as Error).message, 'err'); } };
  async function save() { try { await api('meta/q_save', v); toast('Saved'); setEd(false); saved(); } catch (e) { toast((e as Error).message, 'err'); } }
  const row = (t: string, s: string, on: boolean, k: string) => <div className="flex items-center justify-between gap-3 border-b border-tg-line py-2.5 last:border-0"><span><span className="block text-[14.5px]">{t}</span><span className="block text-[12px] text-tg-sub">{s}</span></span>{isAdmin ? <Toggle on={on} onChange={x => void sw(k, x)} /> : <span className="text-[13px] text-tg-sub">{on ? 'ON' : 'OFF'}</span>}</div>;
  return (
    <div className={card} data-qsettings>
      <div className="flex items-center gap-2"><button type="button" className="flex flex-1 items-center gap-2 text-left" onClick={() => setOpenQ(!openQ)} aria-expanded={openQ}><Globe size={18} className="text-tg-link" /><b className="flex-1 text-[15px]">iProxy line &amp; switches</b><span className={`text-tg-sub transition-transform ${openQ ? 'rotate-180' : ''}`}>▾</span></button>{isAdmin && <button className="text-[13px] text-tg-link" onClick={() => setEd(true)}>Edit</button>}</div>
      <p className="mt-1 text-[12.5px] text-tg-sub">{q.proxy ? `Proxy ${q.proxy}` : <span className="text-tg-orange">No proxy yet</span>} · {q.has_link ? 'change-IP link saved' : <span className="text-tg-orange">no change-IP link</span>} · wait {q.wait_s}s · {q.country || 'any country'}{q.last_ip ? ` · last IP ${q.last_ip.replace(/^(\d+\.\d+)\.\d+\.\d+$/, '$1.x.x')} ${listTime(q.last_ip_at)}` : ''}</p>
      {!openQ && <p className="mt-1 text-[12px] text-tg-sub">{[q.auto_sync && 'Auto sync', q.partner_hand && 'Partner by hand', q.auto_approve && 'Auto approve', q.proof_client && 'Proof to client', q.post_on && 'Channel post', q.story_on && 'Story', q.shot_wait && 'Wait for chat screenshot', q.digest_on && 'Daily top-up post'].filter(Boolean).join(' · ') || 'All switches OFF'} · tap to open</p>}
      {openQ && <>
      <div className="mt-2">
        {row('Auto sync', `Every ${q.every_min >= 60 ? q.every_min / 60 + ' hour' + (q.every_min > 60 ? 's' : '') : q.every_min + ' min'} · one profile at a time (only while the system is ON)`, q.auto_sync, 'auto_sync')}
        {row('Partner assign by hand', 'Meta blocks partner assign for new apps (#3). ON = you assign the partner in Business Settings, the system checks it and does the rest. Website orders then wait for you.', q.partner_hand, 'partner_hand')}
        {row('Auto approve', 'Paid + in stock + agent allowed → shared without the manager (chat, payment link, website). OFF = every request waits in Requests', q.auto_approve, 'auto_approve')}
        {row('Proof images to the client', 'After a share: Partner assigned + Billing (live from Meta)', q.proof_client, 'proof_client')}
        {row('Post to the Telegram channel', q.post_chat ? `${q.post_chat} · next Client #${q.post_next}` : 'Set the channel in Edit', q.post_on, 'post_on')}
        {row('Wait for chat screenshot', 'ON: the account, client album + message go at once; the channel post, story and Saved Messages copy wait until you upload the client-chat screenshot (IDs blurred by the system) or tap "Send without screenshot"', !!q.shot_wait, 'shot_wait')}
        {row('Telegram story', '9:16 image + short caption on the chat account (24 h, no button)', q.story_on, 'story_on')}
        {row('Daily top-up post', `Every day at ${q.digest_time || '22:00'}: albums of the day's top-up images + cover with all details + buttons, and a story${q.digest_last ? ` · last: ${q.digest_last}` : ''}`, q.digest_on, 'digest_on')}
      </div>
      {isAdmin && <button className="mt-1 text-[13px] text-tg-link disabled:opacity-50" disabled={dBusy} onClick={() => { if (confirm("Post today's top-ups to the channel and the story now? Tonight's automatic post will then not go again.")) void digestNow(); }}>{dBusy ? 'Posting…' : "Post today's top-ups now"}</button>}
      {isAdmin && <div className="mt-2 rounded-xl bg-white/5 p-2.5" data-ipcheck>
        <div className="flex items-center gap-2"><b className="flex-1 text-[13.5px]">Which IP does Meta see?</b><button className="text-[13px] text-tg-link disabled:opacity-50" disabled={ipBusy} onClick={() => void checkIp()}>{ipBusy ? 'Checking…' : 'Check now'}</button></div>
        {ipc ? <div className="mt-1.5 space-y-0.5 text-[12.5px]">
          <div>Server (VPS): <b>{ipc.server.ip || '?'}</b>{ipc.server.country ? ` · ${ipc.server.country}` : ''}</div>
          <div>Ad accounts (iProxy): {ipc.iproxy ? (ipc.iproxy.ip ? <><b className={ipc.iproxy_leak ? 'text-tg-red' : 'text-tg-green'}>{ipc.iproxy.ip}</b> · {ipc.iproxy.country} · {ipc.iproxy_leak ? 'SAME AS THE SERVER, not safe' : 'OK, not the server IP'}</> : <span className="text-tg-red">proxy not working: {ipc.iproxy.error}</span>) : <span className="text-tg-sub">no proxy saved</span>}</div>
          <div>Comments / Ads data: {ipc.comments ? (ipc.comments.ip ? <><b className={ipc.comments_leak ? 'text-tg-red' : 'text-tg-green'}>{ipc.comments.ip}</b> · {ipc.comments.country} · {ipc.comments_leak ? 'SAME AS THE SERVER, not safe' : 'OK, not the server IP'}</> : <span className="text-tg-red">proxy not working: {ipc.comments.error}</span>) : <span className="text-tg-sub">no proxy saved</span>}</div>
        </div> : <p className="mt-1 text-[12px] text-tg-sub">Checks through the same code the Meta calls use. Does not change the iProxy IP.</p>}
      </div>}
      <p className="mt-1 text-[12px] text-tg-sub">Premium = Meta daily limit ${q.cat_usd} or more · below = $25 account</p>
      </>}
      <Sheet open={ed} onClose={() => setEd(false)} title="iProxy line & posts">
        <Field label="iProxy proxy" hint={`${q.proxy ? 'Saved: ' + q.proxy + '. Empty = keep. ' : ''}http://user:pass@host:port · socks5://user:pass@host:port · host:port:user:pass`}><input className={inputCls} value={v.proxy} onChange={e => setV({ ...v, proxy: e.target.value })} placeholder="new proxy" autoComplete="off" /></Field>
        <Field label="Change-IP link" hint={q.has_link ? 'Saved. Empty = keep.' : 'iProxy → your phone → Change IP by URL'}><input className={inputCls} value={v.ip_link} onChange={e => setV({ ...v, ip_link: e.target.value })} placeholder="https://…" autoComplete="off" /></Field>
        <div className="grid grid-cols-2 gap-2"><Field label="Wait after change (s)"><input className={inputCls} type="number" value={v.wait_s} onChange={e => setV({ ...v, wait_s: e.target.value })} /></Field><Field label="IP country"><input className={inputCls} value={v.country} onChange={e => setV({ ...v, country: e.target.value })} placeholder="IN" /></Field></div>
        <Field label="Auto sync every"><select className={inputCls} value={v.every_min} onChange={e => setV({ ...v, every_min: e.target.value })}>{[['30', '30 minutes'], ['60', '1 hour'], ['120', '2 hours'], ['180', '3 hours'], ['360', '6 hours']].map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select></Field>
        <Field label="Premium line (Meta daily limit, $)" hint="At or above = Premium account, below = $25 account"><input className={inputCls} type="number" value={v.cat_usd} onChange={e => setV({ ...v, cat_usd: e.target.value })} /></Field>
        <Field label="Telegram channel" hint="@username or -100… id. The bot must be admin there."><input className={inputCls} value={v.post_chat} onChange={e => setV({ ...v, post_chat: e.target.value })} placeholder="@adsbhai" /></Field>
        <Field label="Next client number"><input className={inputCls} type="number" value={v.post_next} onChange={e => setV({ ...v, post_next: e.target.value })} /></Field>
        <Field label="Daily top-up post time (India)" hint="24h, like 22:00"><input className={inputCls} value={v.digest_time} onChange={e => setV({ ...v, digest_time: e.target.value })} placeholder="22:00" /></Field>
        <Btn className="w-full" onClick={() => void save()}>Save</Btn>
      </Sheet>
    </div>
  );
}

function AddProfileSheet({ api, open, onClose, done, edit }: { api: Api; open: boolean; onClose: () => void; done: () => void; edit?: any }) {
  const toast = useToast();
  const [v, setV] = useState({ name: '', ix: '', app_id: '', secret: '', token: '' }); const [busy, setBusy] = useState(false);
  const okA = useOpenKey(open);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => { if (okA) setV({ name: edit?.name || '', ix: edit?.ix || '', app_id: edit?.app_id || '', secret: '', token: '' }); }, [okA]);
  const set = (k: keyof typeof v) => (e: React.ChangeEvent<HTMLInputElement>) => setV(x => ({ ...x, [k]: e.target.value }));
  async function save() {
    setBusy(true);
    try {
      const r = await api<any>(edit ? 'meta/profile_update' : 'meta/profile_add', edit ? { id: edit.id, ...v } : v);
      toast(r.job ? `In the queue: IP change → connect (~${r.job.eta_min} min)` : 'Saved'); done();
    } catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); }
  }
  return (
    <Sheet open={open} onClose={onClose} title={edit ? `New token · ${edit.ix}` : 'Add profile'}>
      {!edit && <p className="mb-3 text-[12.5px] leading-relaxed text-tg-sub">In that iX profile: developers.facebook.com → app (no business portfolio) → Graph API Explorer → User token with ads_management, ads_read, business_management → tick every BM and ad account. The token becomes a 60-day token here.</p>}
      {!edit && <div className="grid grid-cols-2 gap-2"><Field label="Profile name"><input className={inputCls} value={v.name} onChange={set('name')} placeholder="Profile 2" /></Field><Field label="iX profile"><input className={inputCls} value={v.ix} onChange={set('ix')} placeholder="IX7" /></Field></div>}
      {!edit && <Field label="App ID"><input className={inputCls} inputMode="numeric" value={v.app_id} onChange={set('app_id')} /></Field>}
      <Field label={edit ? 'App Secret (empty = keep)' : 'App Secret'}><input className={inputCls} value={v.secret} onChange={set('secret')} autoComplete="off" /></Field>
      <Field label="Token (Graph API Explorer)"><input className={inputCls} value={v.token} onChange={set('token')} placeholder="EAA…" autoComplete="off" /></Field>
      <Btn className="w-full" busy={busy} onClick={() => void save()}>{edit ? 'Save new token' : 'Add and connect'}</Btn>
    </Sheet>
  );
}

function ProfileSheet({ api, id, isAdmin, onClose, changed, onAcct }: { api: Api; id: number | null; isAdmin?: boolean; onClose: () => void; changed: () => void; onAcct: (a: string) => void }) {
  const toast = useToast();
  const [d, setD] = useState<any>(null); const [tok, setTok] = useState(false);
  const load = useCallback(async () => { if (!id) return; try { setD(await api('meta/profile?id=' + id)); } catch (e) { toast((e as Error).message, 'err'); } }, [api, id, toast]);
  useEffect(() => { setD(null); if (id) void load(); }, [id, load]);
  useInterval(() => { if (id) void load(); }, 8000);
  const p = d?.profile;
  async function call(path: string, body: Record<string, unknown>, msg: string, close = false) {
    try { const r = await api<any>(path, body); toast(r.job ? `${msg} · in the queue ~${r.job.eta_min} min` : msg); changed(); if (close) onClose(); else void load(); } catch (e) { toast((e as Error).message, 'err'); }
  }
  return (
    <Sheet open={!!id} onClose={onClose} title={p ? `${p.ix} · ${p.name}` : 'Profile'} wide>
      {!p ? <div className="p-3"><Skeleton rows={3} h={68} /></div> : <>
        <div className="mb-2 flex flex-wrap gap-1.5"><Pill m={PSTATE} k={p.status} />{p.token_days != null && <Pill m={{ x: [`Token ${p.token_days} days`, p.token_days <= 7 ? 'bg-tg-orange/15 text-tg-orange' : 'bg-white/10 text-tg-sub'] }} k="x" />}</div>
        {p.error && p.status !== 'ok' && <p className="mb-2 rounded-xl bg-tg-red/10 px-3 py-2 text-[13px] text-tg-bad">{p.error}</p>}
        <div className="grid grid-cols-2 gap-2">
          <Btn kind="ghost" onClick={() => void call('meta/profile_sync', { id }, 'Sync')}><RefreshCw size={16} />Sync now</Btn>
          {isAdmin && <Btn kind="ghost" onClick={() => setTok(true)}><KeyRound size={16} />New token</Btn>}
        </div>
        {d.bms.map((b: any) => <BmBlock key={b.id} api={api} b={b} onAcct={onAcct} changed={load} />)}
        {!d.bms.length && <p className="mt-4 text-[13.5px] text-tg-sub">No BM yet. The first connect runs in the queue (IP change → token → BMs).</p>}
        {isAdmin && <button className="mt-5 flex w-full items-center justify-center gap-1.5 py-2 text-[13.5px] text-tg-bad" onClick={() => { if (confirm('Remove this profile and its BMs from the panel? (Nothing changes in Meta.)')) void call('meta/profile_delete', { id }, 'Removed', true); }}><Trash2 size={15} />Remove profile</button>}
        <AddProfileSheet api={api} open={tok} edit={p} onClose={() => setTok(false)} done={() => { setTok(false); void load(); changed(); }} />
      </>}
    </Sheet>
  );
}

function BmBlock({ api, b, onAcct, changed }: { api: Api; b: any; onAcct: (a: string) => void; changed: () => void }) {
  const toast = useToast();
  const [vd, setVd] = useState(b.verified_since || '');
  useEffect(() => setVd(b.verified_since || ''), [b.verified_since]);
  return (
    <div className="mt-4 rounded-2xl bg-tg-input/60 p-3" data-bm-block={b.bm_id}>
      <div className="flex items-center gap-2"><b className="flex-1 text-[15px]">{b.name || b.bm_id}</b><Pill m={{ x: [b.verification === 'verified' ? 'Verified' : b.verification || 'Unverified', b.verification === 'verified' ? 'bg-tg-green/15 text-tg-ok' : 'bg-white/10 text-tg-sub'] }} k="x" /></div>
      <div className="text-[12.5px] text-tg-sub">BM {b.bm_id} · {b.accounts} account{b.accounts === 1 ? '' : 's'} · {b.free} free</div>
      <div className="mt-2 flex items-center gap-2 text-[13px]"><span className="text-tg-sub">Verified since</span><input type="date" className={clsx(inputCls, '!w-auto !py-1.5')} value={vd} onChange={e => setVd(e.target.value)} /><button className="text-tg-link" onClick={async () => { try { await api('meta/bm_update', { id: b.id, verified_since: vd }); toast('Saved'); changed(); } catch (e) { toast((e as Error).message, 'err'); } }}>Save</button></div>
      <div className="mt-2">{b.accounts_list.map((a: any) => <LimitRow key={a.act_id} api={api} a={a} onOpen={() => onAcct(a.act_id)} changed={changed} />)}</div>
    </div>
  );
}

/** One account: category, state, and the Meta daily limit + billing threshold the admin types once. */
export function LimitRow({ api, a, onOpen, changed }: { api: Api; a: any; onOpen: () => void; changed: () => void }) {
  const toast = useToast();
  const [dsl, setDsl] = useState(a.dsl ?? ''); const [th, setTh] = useState(a.bill_threshold ?? ''); const [ed, setEd] = useState(false);
  useEffect(() => { setDsl(a.dsl ?? ''); setTh(a.bill_threshold ?? ''); }, [a.dsl, a.bill_threshold]);
  const state = a.state === 'free' ? 'Free' : a.state === 'disabled' ? 'Disabled' : 'With client';
  return (
    <div className="border-t border-tg-line py-2.5 first:border-0" data-limit-row={a.act_id}>
      <button onClick={onOpen} className="flex w-full items-center gap-2 text-left"><span className="min-w-0 flex-1 truncate text-[14px] font-semibold">{a.name || 'Account ' + a.no}</span><Pill m={CAT} k={a.cat || 'none'} /><Pill m={{ x: [state, state === 'Free' ? 'bg-white/10 text-tg-sub' : state === 'With client' ? 'bg-[#7c3aed]/25 text-[#C4B5FD]' : 'bg-tg-red/15 text-tg-bad'] }} k="x" /></button>
      <div className="text-[12px] text-tg-sub">act_{a.act_id}{a.card ? ` · ${a.card}${a.card_guess ? ' (from the BM)' : ''}` : ''} · daily limit {usd(a.dsl)} · spent {usd(a.spent)}{a.lead ? ` · ${a.lead.name}` : ''}{a.bill_threshold != null ? ` · bills at ${usd(a.bill_threshold)}` : ''} <button className="text-tg-link" onClick={() => setEd(x => !x)}>{a.dsl == null ? 'Set limit' : 'Edit'}</button></div>
      {ed && <div className="mt-2 grid grid-cols-[1fr_1fr_auto] gap-2">
        <input className={clsx(inputCls, '!py-2')} type="number" inputMode="decimal" placeholder="Daily limit $" value={dsl} onChange={e => setDsl(e.target.value)} />
        <input className={clsx(inputCls, '!py-2')} type="number" inputMode="decimal" placeholder="Pay at $ (optional)" value={th} onChange={e => setTh(e.target.value)} />
        <Btn className="!py-2" onClick={async () => { try { await api('meta/acct_limits', { act_id: a.act_id, dsl, bill_threshold: th }); toast('Saved'); setEd(false); changed(); } catch (e) { toast((e as Error).message, 'err'); } }}>Save</Btn>
      </div>}
    </div>
  );
}

/* ============================== QUEUE TAB ============================== */
export function Queue({ api }: { api: Api }) {
  const toast = useToast();
  const [d, setD] = useState<any>(null); const [open, setOpen] = useState<any>(null);
  const load = useCallback(async () => { try { setD(await api('meta/jobs')); } catch { /* ignore */ } }, [api]);
  useEffect(() => { void load(); }, [load]);
  useInterval(() => void load(), 4000);
  const Row = ({ j }: { j: any }) => (
    <button onClick={() => setOpen(j)} className="mb-2 block w-full af-card p-3 text-left" data-job={j.id}>
      <span className="flex items-center gap-2"><span className="flex-1 text-[15px] font-semibold">{j.label} · {j.profile}</span><Pill m={JSTATE} k={j.status} /></span>
      <span className="mt-0.5 block text-[12.5px] text-tg-sub">{j.error && /^Failed/.test(j.step || '') ? 'Failed' : (j.step || '—')}{j.status === 'queued' && j.eta_min ? ` · ~${j.eta_min} min` : ''} · {j.by || ''} · {listTime(j.done_at || j.started_at || j.created_at)}</span>
      {j.error && <span className="mt-1 block text-[12px] text-tg-bad">{j.error}</span>}
    </button>
  );
  if (!d) return <div className="p-3"><Skeleton rows={3} h={68} /></div>;
  return (
    <div data-queue>
      <p className="mb-3 flex items-center gap-1.5 text-[12.5px] text-tg-sub"><Clock size={14} />One profile at a time: IP change → check → that profile’s work. Shares, top-ups and take-backs go first.</p>
      {d.open.length ? d.open.map((j: any) => <Row key={j.id} j={j} />) : <p className="af-card p-4 text-[14px] text-tg-sub">Queue is empty.</p>}
      <H>Done lately</H>
      {d.recent.map((j: any) => <Row key={j.id} j={j} />)}
      <Sheet open={!!open} onClose={() => setOpen(null)} title={open ? `${open.label} · ${open.profile}` : ''}>
        {open && <>
          <div className="mb-3 flex gap-1.5"><Pill m={JSTATE} k={open.status} /></div>
          {(open.log || []).map((l: any, i: number) => <div key={i} className="flex gap-2 border-b border-tg-line py-1.5 text-[13px]"><span className="w-[64px] shrink-0 whitespace-nowrap text-tg-sub">{new Date(l.at).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span><span>{l.t}</span></div>)}
          {open.status === 'queued' && <Btn kind="danger" className="mt-4 w-full" onClick={async () => { try { await api('meta/job_cancel', { id: open.id }); toast('Cancelled'); setOpen(null); void load(); } catch (e) { toast((e as Error).message, 'err'); } }}>Cancel</Btn>}
        </>}
      </Sheet>
    </div>
  );
}

/* ============================== MANUAL SHARE (no chat) ============================== */
export function ManualShareSheet({ api, open, onClose, path = 'meta/manual_share', manager }: { api: Api; open: boolean; onClose: () => void; path?: string; manager?: boolean }) {
  const toast = useToast();
  const [v, setV] = useState({ client_name: '', client_bm: '', biz_name: '', tier: 'std', paid: '', note: '' }); const [busy, setBusy] = useState(false);
  // v171 (owner): the manager / admin picks WHICH account ('' = the system picks one of the type)
  const [pick, setPick] = useState(''); const [hand, setHand] = useState(false);
  const [freeL, setFreeL] = useState<{ act_id: string; no: number; name: string | null; cat: string | null; api_ok: boolean; bm_name: string }[]>([]);
  useEffect(() => { if (open) { setV({ client_name: '', client_bm: '', biz_name: '', tier: 'std', paid: '', note: '' }); setPick(''); setHand(false); } }, [open]);
  useEffect(() => { if (!open || !manager) return; void api<{ accounts: typeof freeL }>(path === 'meta_manual' ? 'meta_free' : 'meta/free_pick').then(r => setFreeL(r.accounts || [])).catch(() => setFreeL([])); }, [open, manager, api, path]);
  const pickRow = freeL.find(x => x.act_id === pick);
  const handOn = hand || (!!pickRow && !pickRow.api_ok);
  const set = (k: keyof typeof v) => (e: React.ChangeEvent<HTMLInputElement>) => setV(x => ({ ...x, [k]: e.target.value }));
  async function go() {
    setBusy(true);
    try {
      const r = await api<any>(path, { ...v, method: manager ? 'manual' : 'upi', ...(manager && pick ? { act_id: pick, hand: handOn } : {}) });
      toast(r.queued ? `In the queue · ~${r.job?.eta_min || 2} min` : r.pending ? 'Sent to the manager' : r.done ? 'Shared' : r.error || 'Could not do it', r.done === false && !r.queued ? 'err' : 'ok');
      onClose();
    } catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); }
  }
  return (
    <Sheet open={open} onClose={onClose} title="Ad account · client without a chat">
      <p className="mb-3 text-[12.5px] text-tg-sub">For clients from WhatsApp groups etc. The proof images go to our Telegram Saved Messages.</p>
      <Field label="Client name"><input className={inputCls} value={v.client_name} onChange={set('client_name')} /></Field>
      <Field label="Client’s Business Manager ID"><input className={inputCls} inputMode="numeric" value={v.client_bm} onChange={set('client_bm')} /></Field>
      <Field label="Business name (for the account name)"><input className={inputCls} value={v.biz_name} onChange={set('biz_name')} placeholder="Shree Shyam" /></Field>
      <Field label="Account type"><div className="grid grid-cols-2 gap-2">{(['std', 'premium'] as const).map(t => <button key={t} onClick={() => setV({ ...v, tier: t })} className={clsx('rounded-xl border-2 px-2 py-2 text-[13.5px]', v.tier === t ? 'border-tg-acc bg-tg-acc/10' : 'border-transparent bg-tg-input')}>{t === 'premium' ? 'Premium' : '$25 account'}</button>)}</div></Field>
      {manager && <Field label="Which account" hint={!pick ? 'The system picks a free one of the type above.' : handOn ? 'Nothing is shared again: it is saved to this client with the records and proof.' : 'The system shares this account.'}>
        <select className={inputCls} value={pick} onChange={e => setPick(e.target.value)} data-pick-acct>
          <option value="">Auto (system picks)</option>
          {freeL.map(x => <option key={x.act_id} value={x.act_id}>{x.name || 'Account ' + x.no} · {x.cat === 'premium' ? 'Premium' : x.cat === 'std' ? '$25' : 'free'}{x.api_ok ? '' : ' · API blocked'} · act_{x.act_id}</option>)}
        </select>
      </Field>}
      {manager && pick && <label className="mb-3 flex items-center gap-2.5 text-[14px]"><input type="checkbox" className="h-4 w-4" checked={handOn} disabled={!!pickRow && !pickRow.api_ok} onChange={e => setHand(e.target.checked)} />I already shared it in Meta by hand</label>}
      {!manager && <Field label="Client paid (USD)"><input className={inputCls} type="number" value={v.paid} onChange={set('paid')} /></Field>}
      <Btn className="w-full" busy={busy} onClick={() => void go()}>{manager ? 'Share now' : 'Send to manager'}</Btn>
    </Sheet>
  );
}
