'use client';

/** In the Android app: when a newer APK was built on the server, show an update popup.
 *  "Update now" opens the download in the phone's browser → tap the downloaded file → Update. */
import { useEffect, useState } from 'react';
import { isNative, openExternal } from './native';

export function AppUpdate({ app }: { app: 'agent' | 'admin' }) {
  const [up, setUp] = useState<{ code: number; name: string; mine: string } | null>(null);
  const [later, setLater] = useState(false);
  const [started, setStarted] = useState(false);
  // v147: after a server update the app (phone or browser) loads the new code by itself the next time it is opened / comes back
  useEffect(() => {
    let boot = '', stop = false;
    const webCheck = async (reloadIfNew: boolean) => {
      try {
        const v = await (await fetch('/api/app-version', { cache: 'no-store' })).json();
        const w = String(v.web || '');
        if (!w || stop) return;
        if (!boot) { boot = w; return; }
        if (w !== boot && reloadIfNew) { stop = true; location.reload(); }
      } catch { /* offline */ }
    };
    void webCheck(false);
    const vis = () => { if (document.visibilityState === 'visible') void webCheck(true); };
    document.addEventListener('visibilitychange', vis);
    window.addEventListener('online', vis);
    return () => { stop = true; document.removeEventListener('visibilitychange', vis); window.removeEventListener('online', vis); };
  }, []);
  useEffect(() => {
    let stop = false;
    const check = async () => {
      if (!(await isNative())) return;
      let mine = 1, mineName = '';
      try {
        const { App } = await import('@capacitor/app');
        const info = await Promise.race([App.getInfo(), new Promise<null>(r => setTimeout(() => r(null), 4000))]);
        if (!info) return; // could not read our own version — don't nag
        mine = Number(info.build) || 1; mineName = info.version || '';
      } catch { /* very old app */ }
      try {
        const v = await (await fetch('/api/app-version', { cache: 'no-store' })).json();
        if (!stop && v.code > mine) setUp({ code: v.code, name: v.name, mine: mineName });
      } catch { /* offline */ }
    };
    void check();
    const t = setInterval(check, 30 * 60000);
    const vis = () => { if (document.visibilityState === 'visible') void check(); };
    document.addEventListener('visibilitychange', vis);
    return () => { stop = true; clearInterval(t); document.removeEventListener('visibilitychange', vis); };
  }, []);

  if (!up || later) return null;
  const url = `${location.origin}/downloads/${app}.apk?v=${up.code}`;
  return (
    <div className="fixed inset-0 z-[80] grid place-items-center bg-black/60 p-5">
      <div className="w-full max-w-[360px] rounded-2xl bg-tg-panel p-5 text-tg-text shadow-2xl">
        <div className="mx-auto mb-3 grid h-14 w-14 place-items-center rounded-full bg-tg-acc/20 text-[26px]">⬆️</div>
        <h2 className="text-center text-[18px] font-semibold">Update available</h2>
        <p className="mt-1 text-center text-[14px] text-tg-sub">Version {up.name} is ready{up.mine ? ` (you have ${up.mine})` : ''}.</p>
        {started && <p className="mt-4 text-center text-[14px]">Download started in the browser.<br /><span className="text-[12.5px] text-tg-sub">When it finishes, tap the downloaded file (or the notification) → <b>Update</b>. If Android asks, allow installing from the browser.</span></p>}
        <div className="mt-5 flex flex-col gap-2">
          <button onClick={() => { setStarted(true); void openExternal(url); }} className="rounded-xl bg-tg-acc py-3 text-[15px] font-semibold text-white">{started ? 'Download again' : 'Update now'}</button>
          <button onClick={() => setLater(true)} className="py-2 text-[14px] text-tg-sub">Later</button>
        </div>
      </div>
    </div>
  );
}
