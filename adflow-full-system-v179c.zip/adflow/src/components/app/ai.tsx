'use client';

import { Mic } from 'lucide-react';

/* Admin → AI: setup (keys, who gets auto-replies, voice), knowledge + examples, Test Lab, Learn (agent edits, sold chats), Proofs. */

import { useCallback, useEffect, useState } from 'react';
import clsx from 'clsx';
import { Btn, Field, Toggle, Seg, inputCls, useToast, usd, listTime, useInterval, Page } from './ui';

type Api = <T = any>(path: string, body?: unknown) => Promise<T>;
type Tab = 'setup' | 'knowledge' | 'lab' | 'learn' | 'proofs';
type Out = { messages: { text: string; reply_to?: number | null }[]; voice?: boolean; voice_audio?: string; voice_error?: string; action: string; pay_kind?: string; qty?: number; bm_id?: string; act_id?: string; amount?: number; remind_at?: string; remind_note?: string; handoff_reason?: string; next_step?: string; summary?: string };
type Case = { id: number; title: string; biz: 'agency' | 'funnel'; turns: string; expect: string; facts: string | null; out: string | null; verdict: string | null; reason: string | null; mark: string | null; fix: string | null; run_at: number | null };

const Box = ({ title, desc, children, right }: { title: string; desc?: string; children: React.ReactNode; right?: React.ReactNode }) => (
  <section className="mb-4 af-card p-4">
    <div className="mb-3 flex flex-wrap items-start justify-between gap-2"><div><h2 className="text-[17px] font-semibold">{title}</h2>{desc && <p className="mt-0.5 text-[13px] text-tg-sub">{desc}</p>}</div>{right}</div>
    {children}
  </section>
);
const Row = ({ label, desc, on, onChange }: { label: string; desc?: string; on: boolean; onChange: (v: boolean) => void }) => (
  <div className="flex items-start justify-between gap-4 border-b border-tg-line py-3 last:border-0"><div><p className="text-[15px]">{label}</p>{desc && <p className="mt-0.5 text-[12.5px] text-tg-sub">{desc}</p>}</div><Toggle on={on} onChange={onChange} label={label} /></div>
);

/** How the AI's answer looks (used in the simulator and the Test Lab). */
export function OutView({ out, turns }: { out: Out; turns?: { from: string; text: string }[] }) {
  const act: Record<string, string> = { none: '', payment_link: 'Payment link', handoff: 'Hand to manager', reminder: 'Reminder', send_proofs: 'Send proofs' };
  return (
    <div className="space-y-1.5">
      {out.messages.length === 0 && turns && <p className="text-[13px] italic text-tg-sub">(no message)</p>}
      {out.messages.map((m, i) => (
        <div key={i} className="ml-auto max-w-[88%] rounded-2xl rounded-br-md bg-tg-out px-3 py-2 text-[14.5px] text-tg-outtx">
          {m.reply_to && turns?.[m.reply_to - 1] && <span className="mb-1 block border-l-2 border-[#8BC3F7] pl-2 text-[12px] text-[#B9DBFF]">↪ {turns[m.reply_to - 1].text.slice(0, 60)}</span>}
          {i === 0 && out.voice && <span className="mb-1 block text-[11.5px] font-semibold uppercase tracking-wide text-[#B9DBFF]">Goes as a voice note</span>}
          <span className="whitespace-pre-line">{m.text}</span>
          {i === 0 && out.voice_audio && <audio controls src={out.voice_audio} className="mt-2 h-10 w-full max-w-[320px]" />}
          {i === 0 && out.voice && out.voice_error && <span className="mt-1 block text-[12px] text-[#FFB4A8]">Voice not made: {out.voice_error}</span>}
        </div>
      ))}
      {out.action && out.action !== 'none' && (
        <p className="text-right text-[12.5px] text-tg-orange">
          {act[out.action] || out.action}
          {out.action === 'payment_link' && ` · ${out.pay_kind || ''}${out.qty ? ' ×' + out.qty : ''}${out.bm_id ? ' · BM ' + out.bm_id : ''}${out.act_id ? ' · act ' + out.act_id : ''}${out.amount ? ' · $' + out.amount : ''}`}
          {out.action === 'reminder' && ` · ${out.remind_at || ''} ${out.remind_note || ''}`}
          {out.action === 'handoff' && out.handoff_reason ? ` · ${out.handoff_reason}` : ''}
        </p>
      )}
      {out.next_step && <p className="text-[12.5px] text-tg-sub">{out.next_step}</p>}
    </div>
  );
}

export function AiAdmin({ api, back }: { api: Api; back?: () => void }) {
  const [tab, setTab] = useState<Tab>('setup');
  const [d, setD] = useState<any>(null);
  const load = useCallback(() => api('ai').then(setD).catch(() => {}), [api]);
  useEffect(() => { void load(); }, [load]);
  return (
    <Page title="AI" back={back}>
      <div className="mb-2 min-h-[18px] px-1">{d && <p className="text-[13px] text-tg-sub">Today {usd(d.cost_today)} · Test score {d.score != null ? d.score + '%' : '—'}</p>}</div>
      <div className="mb-4 overflow-x-auto"><Seg value={tab} onChange={setTab} items={[['setup', 'Setup'], ['knowledge', 'Knowledge'], ['lab', 'Test Lab'], ['learn', `Learn${d?.counts?.feedback ? ` · ${d.counts.feedback}` : ''}`], ['proofs', 'Proofs']]} /></div>
      {!d ? <p className="text-tg-sub">Loading…</p>
        : tab === 'setup' ? <Setup api={api} d={d} reload={load} />
          : tab === 'knowledge' ? <Knowledge api={api} d={d} reload={load} />
            : tab === 'lab' ? <Lab api={api} reload={load} />
              : tab === 'learn' ? <Learn api={api} reload={load} />
                : <Proofs api={api} />}
    </Page>
  );
}

/* ---------------- Setup ---------------- */
function Setup({ api, d, reload }: { api: Api; d: any; reload: () => void }) {
  const toast = useToast();
  const a = d.ai;
  const [f, setF] = useState({ ai_key: a.key, ai_model: a.model, ai_coach_model: a.coach_model || 'claude-opus-5-5', ai_wait_sec: a.wait_sec, ai_human_hold_min: a.hold_min, ai_min_score: a.min_score, ai_daily_cap: a.daily_cap, ai_price_in: a.price_in, ai_price_out: a.price_out, el_key: a.el_key, el_voice_id: a.el_voice_id, el_model: a.el_model, ai_voice_every: a.voice_every, ai_voice_max: a.voice_max, ai_fu_hours: a.fu_hours, ai_fu_dead_hours: a.fu_dead_hours });
  const [busy, setBusy] = useState(false);
  const save = async (extra: Record<string, unknown> = {}, quiet = false) => {
    setBusy(true);
    try { await api('ai_save', { ...f, ...extra }); if (!quiet) toast('Saved'); reload(); } catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); }
  };
  const agents: { id: number; name: string; role: string }[] = d.agents || [];
  const picked: number[] = a.auto_agents || [];
  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });
  return (
    <>
      <Box title="Claude (AI)" desc="Anthropic API key. Model: the cheapest Claude model (Haiku) by default.">
        <div className="grid gap-3 md:grid-cols-2">
          <Field label="Anthropic API key" hint={a.key_set ? 'Saved. Type a new key to replace it.' : 'console.anthropic.com → API keys'}><input className={inputCls} value={f.ai_key} onChange={set('ai_key')} placeholder="sk-ant-…" autoComplete="off" /></Field>
          <Field label="Model"><input className={inputCls} value={f.ai_model} onChange={set('ai_model')} /></Field>
          <Field label="Coach model" hint="Agent app suggestions. Opus = best advice (costs more per suggestion). Empty = same as Model."><input className={inputCls} value={f.ai_coach_model} onChange={set('ai_coach_model')} /></Field>
          <Field label="Daily budget ($)" hint="All AI stops for the day after this. 0 = no limit."><input className={inputCls} inputMode="decimal" value={f.ai_daily_cap} onChange={set('ai_daily_cap')} /></Field>
          <div className="grid grid-cols-2 gap-2">
            <Field label="$ / M input tokens"><input className={inputCls} inputMode="decimal" value={f.ai_price_in} onChange={set('ai_price_in')} /></Field>
            <Field label="$ / M output tokens"><input className={inputCls} inputMode="decimal" value={f.ai_price_out} onChange={set('ai_price_out')} /></Field>
          </div>
        </div>
        <Btn className="mt-3" busy={busy} onClick={() => void save()}>Save</Btn>
      </Box>

      <Box title="Agent coach" desc="In every chat the agent sees the next step + 2-3 ready replies. They tap one, change it if needed, and send.">
        <Row label="Coach for agents and manager" desc="Agency + Funnel chats" on={a.coach_on} onChange={v => void save({ ai_coach_on: v ? '1' : '0' }, true)} />
      </Box>

      <Box title="AI auto-reply" desc={`AI answers by itself — only in the chats of the people you tick. Allowed only when the Test Lab score is at least ${a.min_score}% (now ${d.score ?? '—'}%).`}>
        <Row label="AI answers chats by itself" desc="Waits until the customer stops typing, answers all their messages together, hands over to a person when needed." on={a.auto_on} onChange={v => void save({ ai_auto_on: v ? '1' : '0' }, true)} />
        <p className="mb-1 mt-3 text-[13px] text-tg-sub">AI answers the chats of:</p>
        <div className="flex flex-wrap gap-2">
          {agents.map(g => {
            const on = picked.includes(g.id);
            return <button key={g.id} onClick={() => void save({ ai_auto_agents: (on ? picked.filter(x => x !== g.id) : [...picked, g.id]).join(',') }, true)}
              className={clsx('rounded-full px-3 py-1.5 text-[13.5px] font-semibold', on ? 'bg-tg-acc text-white' : 'bg-tg-input text-tg-sub')}>{on ? '✓ ' : ''}{g.name}{g.role === 'manager' ? ' (manager)' : ''}</button>;
          })}
          {!agents.length && <p className="text-[13px] text-tg-sub">No agents yet.</p>}
        </div>
        <div className="mt-3 grid gap-3 md:grid-cols-3">
          <Field label="Wait after the last message (sec)" hint="Customers often send 4-5 short messages."><input className={inputCls} inputMode="numeric" value={f.ai_wait_sec} onChange={set('ai_wait_sec')} /></Field>
          <Field label="A person wrote → AI quiet for (min)"><input className={inputCls} inputMode="numeric" value={f.ai_human_hold_min} onChange={set('ai_human_hold_min')} /></Field>
          <Field label="Minimum Test Lab score (%)"><input className={inputCls} inputMode="numeric" value={f.ai_min_score} onChange={set('ai_min_score')} /></Field>
        </div>
        <Btn className="mt-3" kind="ghost" busy={busy} onClick={() => void save()}>Save</Btn>
      </Box>

      <Box title="AI follow-ups (hot leads)" desc={`Customers who replied at least once and then went quiet get follow-ups written by the AI from their chat — in their language, continuing where the chat stopped, never a payment link. If they named a time ("sham 9:30 free"), a reminder is set instead. Others keep the normal follow-up texts. Works only with the key and a Test Lab score of at least ${a.min_score}%.`}>
        <Row label="AI writes follow-ups for hot leads" desc={a.fu_on ? (a.fu_active ? 'Active now' : `Waiting for ${!a.key_set ? 'the API key' : 'the Test Lab score'} — normal follow-ups are used until then`) : 'Off — normal follow-up texts for everyone'} on={a.fu_on} onChange={v => void save({ ai_fu_on: v ? '1' : '0' }, true)} />
        <div className="mt-2 grid gap-3 md:grid-cols-2">
          <Field label="Follow-up gaps (hours: 1st, 2nd, 3rd)"><input className={inputCls} value={f.ai_fu_hours} onChange={set('ai_fu_hours')} placeholder="4,24,72" /></Field>
          <Field label="After the 3rd → Dead after (hours)"><input className={inputCls} inputMode="numeric" value={f.ai_fu_dead_hours} onChange={set('ai_fu_dead_hours')} /></Field>
        </div>
        <Btn className="mt-3" kind="ghost" busy={busy} onClick={() => void save()}>Save</Btn>
      </Box>

      <VoiceBox api={api} a={a} f={f} set={set} save={save} busy={busy} />

      <Box title="AI cost (last 7 days)">
        {!d.usage?.length ? <p className="text-[13px] text-tg-sub">Nothing used yet.</p> : (
          <div className="overflow-x-auto"><table className="w-full text-[13.5px]"><thead><tr className="text-left text-tg-sub"><th className="py-1">Day</th><th>Used for</th><th>Calls</th><th>Cost</th></tr></thead>
            <tbody>{d.usage.map((u: any, i: number) => <tr key={i} className="border-t border-tg-line"><td className="py-1.5">{u.day}</td><td>{({ coach: 'Coach', auto: 'Auto-reply', followup: 'Follow-ups', lab: 'Test Lab', grade: 'Test grading', voice: 'Team voice' } as Record<string, string>)[u.kind] || u.kind}</td><td>{u.calls}</td><td>{usd(u.cost)}</td></tr>)}</tbody></table></div>
        )}
      </Box>
    </>
  );
}

/* ---------------- Voice notes ---------------- */
/** Records from the mic (same as the chat). Calls onDone with the file when stopped. */
function useRecorder(onDone: (f: File) => void, raw = false) {
  const toast = useToast();
  const [rec, setRec] = useState<{ mr: MediaRecorder; start: number } | null>(null);
  const [sec, setSec] = useState(0);
  useInterval(() => { if (rec) setSec(Math.round((Date.now() - rec.start) / 1000)); }, rec ? 500 : null);
  const toggle = async () => {
    if (rec) { rec.mr.stop(); return; }
    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === 'undefined') return toast('Recording is not supported on this device', 'err');
    try {
      // raw = record the room as it is (phones otherwise remove background noise from the mic)
      const st = await navigator.mediaDevices.getUserMedia({ audio: raw ? { noiseSuppression: false, echoCancellation: false, autoGainControl: false } : true });
      const mt = ['audio/ogg;codecs=opus', 'audio/mp4', 'audio/webm;codecs=opus', 'audio/webm'].find(x => MediaRecorder.isTypeSupported?.(x)) || '';
      const mr = new MediaRecorder(st, mt ? { mimeType: mt } : undefined);
      const chunks: Blob[] = [];
      mr.ondataavailable = e => { if (e.data.size) chunks.push(e.data); };
      mr.onstop = () => {
        st.getTracks().forEach(t => t.stop());
        const type = mr.mimeType || 'audio/webm';
        setRec(null); setSec(0);
        const blob = new Blob(chunks, { type });
        if (blob.size < 1500) return toast('Hold on a little longer to record', 'err');
        const ext = type.includes('ogg') ? 'ogg' : type.includes('mp4') ? 'm4a' : 'webm';
        onDone(new File([blob], `voice.${ext}`, { type }));
      };
      mr.start(); setRec({ mr, start: Date.now() }); setSec(0);
    } catch { toast('Allow microphone access to record', 'err'); }
  };
  return { recording: !!rec, sec, toggle };
}

function VoiceBox({ api, a, f, set, save, busy }: { api: Api; a: any; f: any; set: (k: string) => (e: React.ChangeEvent<HTMLInputElement>) => void; save: (extra?: Record<string, unknown>, quiet?: boolean) => Promise<void>; busy: boolean }) {
  const toast = useToast();
  const [sample, setSample] = useState<string | null>(null);
  const [sBusy, setSBusy] = useState(false);
  const [room, setRoom] = useState<{ seconds: number } | null>(a.room);
  const [rBusy, setRBusy] = useState(false);
  const [roomUrl, setRoomUrl] = useState<string | null>(null);
  const uploadRoom = async (file: File) => {
    setRBusy(true);
    try {
      const fd = new FormData(); fd.append('file', file);
      const r = await fetch('/api/admin/ai_voice_room', { method: 'POST', body: fd, credentials: 'include' });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(j.error || 'Upload failed');
      setRoom({ seconds: j.seconds }); setRoomUrl(null); toast('Saved — voice notes now use your room sound');
    } catch (e) { toast((e as Error).message, 'err'); } finally { setRBusy(false); }
  };
  const recRoom = useRecorder(file => void uploadRoom(file), true);
  const play = async (noise: string) => {
    setSBusy(true); setSample(null);
    try { const r = await api<{ audio: string; ogg: boolean }>('ai_voice_sample', { noise, bg }); setSample(r.audio); }
    catch (e) { toast((e as Error).message, 'err'); } finally { setSBusy(false); }
  };
  const [chg, setChg] = useState<string | null>(null);
  const [said, setSaid] = useState<{ heard: string | null; text: string | null; fixed?: { from: string; to: string }[] } | null>(null);
  const [style, setStyle] = useState<string>(a.team_voice_style || 'female_words');
  const [gender, setGender] = useState<string>(a.team_voice_gender || 'female');
  const [tvid, setTvid] = useState<string>(a.team_voice_id || '');
  const male = gender === 'male';
  const [officeSec, setOfficeSec] = useState<number>(a.office_sec || 0);
  const [oBusy, setOBusy] = useState(false);
  const [oStep, setOStep] = useState('');
  const [officeUrl, setOfficeUrl] = useState<string | null>(null);
  const bg: string = a.voice_bg || 'office';
  const makeOffice = async () => {
    setOBusy(true);
    try {
      await api('ai_voice_office', { make: true });
      // made in the background (1-2 min) — check every 3 s
      for (let i = 0; i < 100; i++) {
        await new Promise(r => setTimeout(r, 3000));
        const st = await api<{ job: { running: boolean; error: string; step: number; total: number }; seconds: number }>('ai_voice_office?status=1').catch(() => null);
        if (!st) continue;
        setOStep(st.job.running ? `${st.job.step}/${st.job.total}` : '');
        if (st.job.running) continue;
        if (st.job.error) throw new Error(st.job.error);
        setOfficeSec(st.seconds); setOfficeUrl(null); toast(`Office background ready (${Math.floor(st.seconds / 60)}:${String(st.seconds % 60).padStart(2, '0')} min)`);
        return;
      }
    } catch (e) { toast((e as Error).message, 'err'); } finally { setOBusy(false); setOStep(''); }
  };
  const [cBusy, setCBusy] = useState(false);
  const recChange = useRecorder(async file => {
    setCBusy(true); setChg(null); setSaid(null);
    try {
      const fd = new FormData(); fd.append('file', file); fd.append('style', style); fd.append('gender', gender); fd.append('voice_id', tvid);
      const r = await fetch('/api/admin/ai_voice_change_test', { method: 'POST', body: fd, credentials: 'include' });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(j.error || 'Voice change failed');
      setChg(j.audio); setSaid({ heard: j.heard, text: j.text, fixed: j.fixed });
    } catch (e) { toast((e as Error).message, 'err'); } finally { setCBusy(false); }
  });
  const mode: string = a.voice_mode || 'interest';
  return (
    <Box title="Voice notes (ElevenLabs)" desc="AI replies can go as voice notes that sound recorded on a phone (soft room sound, phone-mic sound, real Telegram voice-note format). Customer voice notes are turned into text too. Test it first: Test Lab → Try it as a customer → .">
      <Row label="Send AI voice notes" desc="Keep this off until you have tested the voice in the Test Lab." on={a.voice_on} onChange={v => void save({ ai_voice_on: v ? '1' : '0' }, true)} />
      <div className="mt-2 grid gap-3 md:grid-cols-3">
        <Field label="ElevenLabs API key" hint={a.el_key_set ? 'Saved.' : 'elevenlabs.io → Developers → API keys'}><input className={inputCls} value={f.el_key} onChange={set('el_key')} autoComplete="off" /></Field>
        <Field label="Voice ID" hint="Voices → ⋮ → Copy voice ID"><input className={inputCls} value={f.el_voice_id} onChange={set('el_voice_id')} /></Field>
        <Field label="Voice model"><input className={inputCls} value="Eleven v4" readOnly /></Field>
      </div>
      <Btn className="mt-3" kind="ghost" busy={busy} onClick={() => void save()}>Save</Btn>

      <p className="mb-1.5 mt-5 text-[14px] font-semibold">When to send a voice note</p>
      <div className="overflow-x-auto"><Seg value={mode} onChange={v => void save({ ai_voice_mode: v }, true)} items={[['interest', 'Interested'], ['every', 'Every few'], ['mirror', 'Voice → voice']]} /></div>
      <p className="mt-1.5 text-[12.5px] text-tg-sub">{mode === 'interest' ? 'The AI decides: when the customer asks the price or wants to start.' : mode === 'every' ? 'Every Nth AI reply in a chat goes as a voice note.' : 'Only when the customer’s last message was a voice note — feels the most natural.'}</p>
      <div className="mt-2 grid gap-3 md:grid-cols-3">
        {mode === 'every' && <Field label="Every … reply" hint="3 = the 3rd, 6th, 9th reply"><input className={inputCls} inputMode="numeric" value={f.ai_voice_every} onChange={set('ai_voice_every')} /></Field>}
        <Field label="Max voice notes per chat" hint="0 = no limit"><input className={inputCls} inputMode="numeric" value={f.ai_voice_max} onChange={set('ai_voice_max')} /></Field>
      </div>
      <Btn className="mt-3" kind="ghost" busy={busy} onClick={() => void save()}>Save</Btn>

      <p className="mb-1.5 mt-5 text-[14px] font-semibold">Voice loudness</p>
      <div className="overflow-x-auto"><Seg value={String(a.voice_volume ?? '-3')} onChange={v => void save({ ai_voice_volume: v }, true)} items={[['-6', 'Softer'], ['-3', 'A bit softer'], ['0', 'Normal'], ['3', 'Louder']]} /></div>

      <p className="mb-1.5 mt-5 text-[14px] font-semibold">Speaking speed</p>
      <Seg value={String(a.voice_speed || '0.9')} onChange={v => void save({ ai_voice_speed: v }, true)} items={[['1', 'Normal'], ['0.9', 'A bit slower'], ['0.82', 'Slow']]} />
      <p className="mt-1.5 text-[12.5px] text-tg-sub">Same voice, just slower — AI voices talk faster than a person on the phone. Used for every voice note (AI, welcome, team).</p>

      <p className="mb-1.5 mt-5 text-[14px] font-semibold">Room sound (so it sounds really recorded)</p>
      {!a.ffmpeg && <p className="mb-2 rounded-xl bg-tg-orange/15 px-3 py-2 text-[13px] text-tg-orange">The server has no ffmpeg yet, so voice notes can't be made (the AI sends text instead). The next update installs it — or run: apt-get install -y ffmpeg</p>}
      <div className="flex flex-wrap gap-2">
        <Seg value={bg} onChange={v => void save({ ai_voice_bg: v }, true)} items={[['office', 'Office'], ['fan', 'Fan room']]} />
        <Seg value={a.voice_noise || 'light'} onChange={v => void save({ ai_voice_noise: v }, true)} items={[['off', 'Off'], ['light', 'Light'], ['medium', 'Medium']]} />
      </div>
      {bg === 'office' && (
        <div className="mt-3 rounded-xl bg-tg-bg/50 p-3">
          <p className="text-[13px] text-tg-sub">Office = keyboard typing, one or two girls talking on the phone far away, fan. Made once (about 3 minutes long); every voice note takes a different part of it.</p>
          {officeSec ? <p className="mt-1.5 text-[13px] text-tg-ok">✓ Office background ready ({Math.floor(officeSec / 60)}:{String(officeSec % 60).padStart(2, '0')} min)</p>
            : <p className="mt-1.5 text-[13px] text-tg-orange">Not made yet — until then the fan room sound is used. Tap “Make office background” (about a minute; the ElevenLabs key needs “Sound Effects” access).</p>}
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <Btn kind={officeSec ? 'ghost' : 'primary'} busy={oBusy} onClick={() => void makeOffice()}>{oBusy ? `Making… ${oStep}` : officeSec ? 'Make a new one' : 'Make office background'}</Btn>
            {!!officeSec && <Btn kind="ghost" onClick={() => setOfficeUrl(`/api/admin/ai_voice_office?t=${Date.now()}`)}>▶ Listen</Btn>}
          </div>
          {officeUrl && <audio controls autoPlay src={officeUrl} className="mt-2 h-10 max-w-full" />}
        </div>
      )}
      <div className="mt-3 flex flex-wrap items-center gap-2">
        <Btn kind="ghost" busy={sBusy} onClick={() => void play(a.voice_noise || 'light')}>▶ Play a sample</Btn>
        {sample && <audio controls autoPlay src={sample} className="h-10 max-w-full" />}
      </div>
      <div className="mt-4 rounded-xl bg-tg-bg/50 p-3">
        <p className="text-[14px]">Your own room sound <span className="text-tg-sub">(optional)</span></p>
        <p className="mt-0.5 text-[12.5px] text-tg-sub">Record 10-20 seconds of your room — don&apos;t speak. When set, it is used instead of the office / fan background.</p>
        {room && <p className="mt-2 text-[13px] text-tg-ok">✓ Your room sound is used ({room.seconds} s)</p>}
        <div className="mt-2 flex flex-wrap items-center gap-2">
          <Btn kind={recRoom.recording ? 'danger' : 'ghost'} busy={rBusy} onClick={() => void recRoom.toggle()}>{recRoom.recording ? `■ Stop (${recRoom.sec}s)` : '● Record room'}</Btn>
          <label className="cursor-pointer rounded-xl bg-tg-input px-4 py-2.5 text-[14px] font-semibold">Upload file<input type="file" accept="audio/*,video/*" className="hidden" onChange={e => { const x = e.target.files?.[0]; if (x) void uploadRoom(x); e.target.value = ''; }} /></label>
          {room && <Btn kind="ghost" onClick={() => setRoomUrl(`/api/admin/ai_voice_room?t=${Date.now()}`)}>▶ Listen</Btn>}
          {room && <Btn kind="danger" onClick={async () => { try { await api('ai_voice_room', { delete: true }); setRoom(null); setRoomUrl(null); toast('Removed — the made-up room sound is used'); } catch (e) { toast((e as Error).message, 'err'); } }}>Remove</Btn>}
        </div>
        {roomUrl && <audio controls autoPlay src={roomUrl} className="mt-2 h-10 max-w-full" />}
      </div>

      <WelcomeVoice api={api} a={a} save={save} />

      <div className="mt-5 border-t border-tg-line pt-2">
        <Row label="Team voice notes in our voice" desc="When an agent, the manager or you record a voice note in the app (or answer a notification in Telegram with a voice note), the customer gets it in our voice with the background sound. If it fails, nothing is sent and the sender sees an error." on={!!a.team_voice_change} onChange={v => void save({ team_voice_change: v ? '1' : '0' }, true)} />
        <div className="mb-3 rounded-xl bg-tg-bg/50 p-3">
          <p className="mb-2 text-[13px] text-tg-sub">Voice for team voice notes</p>
          <div className="mb-2"><Seg value={gender} onChange={v => { setGender(v); void save({ team_voice_gender: v }, true); }} items={[['female', 'Female'], ['male', 'Male']]} /></div>
          <Field label="Voice ID for team voice notes" hint="ElevenLabs → Voices → ⋮ → Copy voice ID. Empty = the same voice as the AI / welcome voice (Setup).">
            <div className="flex gap-2"><input className={inputCls} value={tvid} onChange={e => setTvid(e.target.value)} placeholder={a.el_voice_id || 'Same as the AI voice'} /><Btn kind="ghost" onClick={() => void save({ team_voice_id: tvid.trim() }, true)}>Save</Btn></div>
          </Field>
          <p className="text-[12.5px] text-tg-sub">Only team voice notes use this. The welcome voice and AI voice replies keep the voice in Setup. Pick Male when this voice is a man, so the words stay “deta hun”, not “deti hun”.</p>
        </div>
        <div className="mb-2 overflow-x-auto"><Seg value={style} onChange={v => { setStyle(v); void save({ team_voice_style: v }, true); }} items={[['mix', 'Mix (human + AI)'], ['female_words', male ? 'Clean words' : 'Female words'], ['same', 'Same voice change']]} /></div>
        <p className="mb-2 text-[12.5px] text-tg-sub">{style === 'mix' ? `Most real: your own recording is kept (your tone, pauses, emotion), only the voice changes. When a word has to be fixed (a mistake${male ? '' : ', or “deta hun” → “deti hun”'}), that note is spoken fresh with the fixed words instead.${male ? '' : ' With a female voice most notes need “deti hun”, so most will be the fixed version — Mix works best with the Male voice.'}` : style === 'female_words' ? (male ? 'Your words are written down, cleaned up (Hindi fixed, “umm” removed, “deti hun” → “deta hun”) and the male voice speaks them. Your tone is not kept. Takes a few seconds more.' : 'Your words are written down, the AI turns them into how a girl says them (“karwa deta hun” → “karwa deti hun”, Hindi cleaned up) and our voice speaks them. Your tone is not kept. Takes a few seconds more.') : 'Only the voice changes — your exact words, accent and way of speaking stay (also “deta hun”).'}</p>
        <div className="flex flex-wrap items-center gap-2">
          <Btn kind={recChange.recording ? 'danger' : 'ghost'} busy={cBusy} onClick={() => void recChange.toggle()}>{recChange.recording ? `■ Stop (${recChange.sec}s)` : 'Try it — record yourself'}</Btn>
          {chg && <audio controls autoPlay src={chg} className="h-10 max-w-full" />}
        </div>
        {said?.text && <div className="mt-2 rounded-xl bg-tg-bg/50 p-2.5 text-[13px]"><p className="text-tg-sub">You said: <span className="text-tg-text">{said.heard}</span></p><p className="mt-1 text-tg-sub">Customer hears: <span className="text-tg-text" data-hears>{hl(said.text, said.fixed)}</span></p>{!!said.fixed?.length && <p className="mt-1 text-[12px] text-tg-sub">Fixed for the voice: {said.fixed.map(f => `${f.from} → ${f.to}`).join(', ')} (spoken fresh)</p>}</div>}
        <p className="mt-1.5 text-[12.5px] text-tg-sub">Nothing is sent when you try it. The ElevenLabs key needs “Speech to Text” and (for Same voice change) “Speech to Speech” access.</p>
      </div>
    </Box>
  );
}

/** Welcome voice note: a short AI voice note a little after the welcome message to new leads from the ads. */
function WelcomeVoice({ api, a, save }: { api: Api; a: any; save: (extra?: Record<string, unknown>, quiet?: boolean) => Promise<void> }) {
  const toast = useToast();
  const [v, setV] = useState({ welcome_voice_delay_sec: a.wv_delay || '25', welcome_voice_text: a.wv_text || '', welcome_voice_text_f: a.wv_text_f || '', welcome_voice_text_c: a.wv_text_c ?? '', welcome_voice_text_cf: a.wv_text_cf ?? '', welcome_voice_text_m: a.wv_text_m ?? '' });
  const [audio, setAudio] = useState<{ k: string; src: string } | null>(null);
  const [busy, setBusy] = useState('');
  type WK = 'welcome_voice_text' | 'welcome_voice_text_f' | 'welcome_voice_text_c' | 'welcome_voice_text_cf' | 'welcome_voice_text_m';
  const listen = async (k: WK) => {
    setBusy(k); setAudio(null);
    try { const r = await api<{ audio: string }>('ai_voice_sample', { text: v[k] }); setAudio({ k, src: r.audio }); } catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(''); }
  };
  const field = (k: WK, label: string, note?: string) => (
    <div className="mt-3">
      <Field label={label} hint={`${note ? note + ' · ' : ''}${v[k].length}/400 · {brand} = our name · {name} = their first name (then it is made for every lead)`}>
        <textarea className={clsx(inputCls, 'min-h-[84px] text-[14px]')} value={v[k]} onChange={e => setV({ ...v, [k]: e.target.value })} />
      </Field>
      <div className="mt-1.5 flex flex-wrap items-center gap-2">
        <Btn kind="ghost" busy={busy === k} onClick={() => void listen(k)}>▶ Listen</Btn>
        {audio?.k === k && <audio controls autoPlay src={audio.src} className="h-10 max-w-full" />}
      </div>
    </div>
  );
  return (
    <div className="mt-5 border-t border-tg-line pt-2">
      <Row label="Welcome voice note" desc="New leads get a short voice note from us a little after the welcome message (Hindi + English mix). Same text for everyone → it is made once and re-used, so it costs nothing per lead." on={!!a.wv_on} onChange={on => void save({ welcome_voice_on: on ? '1' : '0' }, true)} />
      <Field label="Seconds after the welcome message"><input className={inputCls} inputMode="numeric" value={v.welcome_voice_delay_sec} onChange={e => setV({ ...v, welcome_voice_delay_sec: e.target.value })} /></Field>
      {field('welcome_voice_text', 'Ad accounts (Agency / Premium) — what she says')}
      {field('welcome_voice_text_f', 'Funnel — what she says')}
      <p className="mt-4 text-[12.5px] text-tg-sub">“Chat with agent” people (“Hi! I have a question…”) get the chat welcome (Settings → Telegram / Funnel), so they get their own voice text. Leave empty = no voice for them.</p>
      {field('welcome_voice_text_c', '“Chat with agent” (ad accounts) — what she says')}
      {field('welcome_voice_text_cf', '“Chat with agent” (funnel) — what she says')}
      <p className="mt-4 text-[12.5px] text-tg-sub">People who wrote to us with no link get the 1/2/3/4 menu (Settings → Telegram), Telegram and WhatsApp. Empty = the Agency voice.</p>
      {field('welcome_voice_text_m', 'No link (got the menu) — what she says')}
      <Btn className="mt-3" kind="ghost" onClick={() => void save(v)}>Save</Btn>
    </div>
  );
}

/* ---------------- Knowledge + examples ---------------- */
function Knowledge({ api, d, reload }: { api: Api; d: any; reload: () => void }) {
  const toast = useToast();
  const [k, setK] = useState<string>(d.ai.knowledge_custom ? d.ai.knowledge : d.ai.knowledge_default);
  const [ex, setEx] = useState<any[] | null>(null);
  const [edit, setEdit] = useState<any | null>(null);
  const loadEx = useCallback(() => api('ai_examples').then(r => setEx(r.examples)).catch(() => setEx([])), [api]);
  useEffect(() => { void loadEx(); }, [loadEx]);
  const saveK = async (v: string) => { try { await api('ai_save', { ai_knowledge: v }); toast(v ? 'Saved' : 'Back to the built-in sheet'); reload(); } catch (e) { toast((e as Error).message, 'err'); } };
  const src: Record<string, string> = { seed: 'Sample', correction: 'Lab fix', sold: 'Real chat', agent: 'Agent fix', admin: 'Admin' };
  return (
    <>
      <Box title="Knowledge sheet" desc="Everything the AI may say: services, rules, when to hand over. Prices come from Settings ({price_account}, {price_funnel}, {topup_pct}, {topup_min}).">
        <textarea className={clsx(inputCls, 'min-h-[360px] font-mono text-[13px] leading-relaxed')} value={k} onChange={e => setK(e.target.value)} />
        <div className="mt-3 flex flex-wrap gap-2"><Btn onClick={() => void saveK(k)}>Save</Btn>{d.ai.knowledge_custom && <Btn kind="ghost" onClick={() => { if (confirm('Use the built-in sheet again?')) { void saveK(''); setK(d.ai.knowledge_default); } }}>Reset to built-in</Btn>}</div>
      </Box>
      <Box title="Example chats" desc="The AI copies the style of these. Lab fixes and agent fixes are followed exactly." right={<Btn kind="ghost" onClick={() => setEdit({ title: '', biz: 'any', chat: 'C: \nA: ', on_: 1 })}>+ Add</Btn>}>
        {!ex ? <p className="text-tg-sub">Loading…</p> : ex.map(e => (
          <div key={e.id} className="flex items-center gap-3 border-b border-tg-line py-2.5 last:border-0">
            <button onClick={() => setEdit(e)} className="min-w-0 flex-1 text-left"><p className="truncate text-[15px]">{e.title}</p><p className="text-[12.5px] text-tg-sub">{src[e.source] || e.source} · {e.biz === 'any' ? 'Both' : e.biz === 'funnel' ? 'Funnel' : 'Agency'}</p></button>
            <Toggle on={!!e.on_} onChange={async v => { await api('ai_example_save', { ...e, on_: v ? 1 : 0 }); void loadEx(); }} />
          </div>
        ))}
      </Box>
      {edit && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/60 p-3" onClick={() => setEdit(null)}>
          <div className="w-full max-w-[640px] af-card p-4" onClick={e => e.stopPropagation()}>
            <Field label="Title"><input className={inputCls} value={edit.title} onChange={e => setEdit({ ...edit, title: e.target.value })} /></Field>
            <div className="my-3"><Seg value={edit.biz} onChange={v => setEdit({ ...edit, biz: v })} items={[['any', 'Both'], ['agency', 'Agency'], ['funnel', 'Funnel']]} /></div>
            <Field label="Chat (C: customer, A: us — one message per line)"><textarea className={clsx(inputCls, 'min-h-[260px] font-mono text-[13px]')} value={edit.chat} onChange={e => setEdit({ ...edit, chat: e.target.value })} /></Field>
            <div className="mt-3 flex flex-wrap gap-2">
              <Btn onClick={async () => { try { await api('ai_example_save', edit); setEdit(null); void loadEx(); reload(); } catch (e) { toast((e as Error).message, 'err'); } }}>Save</Btn>
              <Btn kind="ghost" onClick={() => setEdit(null)}>Cancel</Btn>
              {edit.id && <Btn kind="danger" onClick={async () => { if (!confirm('Delete this example?')) return; await api('ai_example_delete', { id: edit.id }); setEdit(null); void loadEx(); }}>Delete</Btn>}
            </div>
          </div>
        </div>
      )}
    </>
  );
}

/* ---------------- Test Lab ---------------- */
function Lab({ api, reload }: { api: Api; reload: () => void }) {
  const toast = useToast();
  const [cases, setCases] = useState<Case[] | null>(null);
  const [lab, setLab] = useState<any>(null);
  const [score, setScore] = useState<number | null>(null);
  const [open, setOpen] = useState<number | null>(null);
  const [filter, setFilter] = useState<'all' | 'fail' | 'pass' | 'new'>('all');
  const [editCase, setEditCase] = useState<any | null>(null);
  const load = useCallback(() => api('ai_cases').then(r => { setCases(r.cases); setLab(r.lab); setScore(r.score); }).catch(() => setCases([])), [api]);
  useEffect(() => { void load(); }, [load]);
  useInterval(() => { if (lab?.running) void load(); }, lab?.running ? 3000 : null);
  useEffect(() => { if (lab && !lab.running) reload(); }, [lab?.running]); // eslint-disable-line react-hooks/exhaustive-deps
  const runAll = async (ids?: number[]) => { try { await api('ai_lab_run', { ids }); void load(); } catch (e) { toast((e as Error).message, 'err'); } };
  const status = (c: Case) => (c.mark ? (c.mark === 'ok' ? 'pass' : 'fail') : c.verdict || 'new');
  const list = (cases || []).filter(c => filter === 'all' || status(c) === filter);
  const fails = (cases || []).filter(c => status(c) === 'fail').map(c => c.id);
  return (
    <>
      <Simulator api={api} onSaveCase={c => setEditCase(c)} />
      <Box title={`Test library · ${score ?? '—'}%`} desc="Every question is answered by the AI and checked automatically against the rule. Mark wrong answers and write the right one — it becomes an example."
        right={<div className="flex flex-wrap gap-2">
          <Btn busy={lab?.running} onClick={() => void runAll()}>{lab?.running ? `Running ${lab.done}/${lab.total}` : 'Run all'}</Btn>
          {fails.length > 0 && !lab?.running && <Btn kind="ghost" onClick={() => void runAll(fails)}>Re-run {fails.length} wrong</Btn>}
          <Btn kind="ghost" onClick={() => setEditCase({ title: '', biz: 'agency', turns: [{ from: 'c', text: '' }], expect: '', facts: '' })}>+ Case</Btn>
        </div>}>
        {lab?.error && <p className="mb-2 text-[13px] text-tg-red">{lab.error}</p>}
        <div className="mb-3"><Seg value={filter} onChange={setFilter} items={[['all', 'All'], ['fail', 'Wrong'], ['pass', 'Right'], ['new', 'Not run']]} /></div>
        {!cases ? <p className="text-tg-sub">Loading…</p> : list.map(c => {
          const st = status(c);
          const turns = JSON.parse(c.turns || '[]');
          return (
            <div key={c.id} className="border-b border-tg-line last:border-0">
              <button onClick={() => setOpen(open === c.id ? null : c.id)} className="flex w-full items-center gap-3 py-2.5 text-left">
                <span className={clsx('grid h-7 w-7 shrink-0 place-items-center rounded-full text-[13px] font-bold', st === 'pass' ? 'bg-tg-green/20 text-tg-ok' : st === 'fail' ? 'bg-tg-red/20 text-tg-bad' : 'bg-tg-input text-tg-sub')}>{st === 'pass' ? '✓' : st === 'fail' ? '✗' : '·'}</span>
                <span className="min-w-0 flex-1"><span className="block truncate text-[15px]">{c.title}</span><span className="block truncate text-[12.5px] text-tg-sub">{c.biz === 'funnel' ? 'Funnel' : 'Agency'} · {turns[turns.length - 1]?.text}</span></span>
                {c.run_at && <span className="shrink-0 text-[12px] text-tg-sub">{listTime(c.run_at)}</span>}
              </button>
              {open === c.id && <CaseView api={api} c={c} turns={turns} onChanged={load} onEdit={() => setEditCase({ ...c, turns })} />}
            </div>
          );
        })}
      </Box>
      {editCase && <CaseEditor api={api} c={editCase} onClose={() => setEditCase(null)} onSaved={() => { setEditCase(null); void load(); }} />}
    </>
  );
}

function CaseView({ api, c, turns, onChanged, onEdit }: { api: Api; c: Case; turns: { from: string; text: string }[]; onChanged: () => void; onEdit: () => void }) {
  const toast = useToast();
  const [fix, setFix] = useState(c.fix || '');
  const [busy, setBusy] = useState(false);
  const out: Out | null = c.out ? JSON.parse(c.out) : null;
  const mark = async (m: string) => { try { await api('ai_case_mark', { id: c.id, mark: m, fix }); toast(fix ? 'Saved — the AI will follow your answer' : 'Marked'); onChanged(); } catch (e) { toast((e as Error).message, 'err'); } };
  return (
    <div className="mb-3 rounded-xl bg-tg-bg/50 p-3">
      <div className="space-y-1.5">
        {turns.map((t, i) => <div key={i} className={clsx('max-w-[85%] rounded-2xl px-3 py-1.5 text-[14px]', t.from === 'a' ? 'ml-auto rounded-br-md bg-tg-out/70 text-tg-outtx/85' : 'rounded-bl-md bg-tg-input')}><span className="mr-1 text-[11px] text-tg-sub">#{i + 1}</span>{t.text}</div>)}
      </div>
      <p className="mt-3 text-[12.5px] text-tg-sub"><b className="text-tg-text">Must do:</b> {c.expect}</p>
      {c.facts && <p className="mt-1 text-[12.5px] text-tg-sub"><b className="text-tg-text">Facts:</b> {c.facts}</p>}
      <div className="mt-3 border-t border-tg-line pt-3">
        <p className="mb-1.5 text-[12.5px] font-semibold text-tg-sub">AI answer</p>
        {out ? <OutView out={out} turns={turns} /> : <p className="text-[13px] text-tg-sub">Not run yet.</p>}
        {c.reason && <p className={clsx('mt-2 text-[12.5px]', c.verdict === 'pass' ? 'text-tg-ok' : 'text-tg-bad')}>Checker: {c.reason}</p>}
      </div>
      <div className="mt-3" />
      <Field label="Right answer (optional — becomes an example the AI follows)"><textarea className={clsx(inputCls, 'min-h-[80px] text-[14px]')} value={fix} onChange={e => setFix(e.target.value)} placeholder={'Ek line = ek message\nSir ... '} /></Field>
      <div className="mt-2 flex flex-wrap gap-2">
        <Btn kind="green" onClick={() => void mark('ok')}>✓ Right</Btn>
        <Btn kind="danger" onClick={() => void mark('bad')}>✗ Wrong</Btn>
        <Btn kind="ghost" busy={busy} onClick={async () => { setBusy(true); try { await api('ai_case_run', { id: c.id }); onChanged(); } catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); } }}>Run again</Btn>
        <Btn kind="ghost" onClick={onEdit}>Edit</Btn>
      </div>
    </div>
  );
}

function CaseEditor({ api, c, onClose, onSaved }: { api: Api; c: any; onClose: () => void; onSaved: () => void }) {
  const toast = useToast();
  const [v, setV] = useState({ ...c, turns: c.turns?.length ? c.turns : [{ from: 'c', text: '' }] });
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/60 p-3" onClick={onClose}>
      <div className="max-h-[92vh] w-full max-w-[640px] overflow-y-auto af-card p-4" onClick={e => e.stopPropagation()}>
        <Field label="Title"><input className={inputCls} value={v.title} onChange={e => setV({ ...v, title: e.target.value })} /></Field>
        <div className="my-3"><Seg value={v.biz} onChange={b => setV({ ...v, biz: b })} items={[['agency', 'Agency'], ['funnel', 'Funnel']]} /></div>
        <p className="mb-1 text-[13px] text-tg-sub">Chat (last customer messages are the ones the AI answers)</p>
        {v.turns.map((t: any, i: number) => (
          <div key={i} className="mb-1.5 flex gap-1.5">
            <button onClick={() => setV({ ...v, turns: v.turns.map((x: any, j: number) => (j === i ? { ...x, from: x.from === 'c' ? 'a' : 'c' } : x)) })} className="w-16 shrink-0 rounded-xl bg-tg-input text-[12.5px] font-semibold">{t.from === 'c' ? 'Customer' : 'Us'}</button>
            <input className={inputCls} value={t.text} onChange={e => setV({ ...v, turns: v.turns.map((x: any, j: number) => (j === i ? { ...x, text: e.target.value } : x)) })} />
            <button onClick={() => setV({ ...v, turns: v.turns.filter((_: any, j: number) => j !== i) })} className="px-2 text-tg-sub">✕</button>
          </div>
        ))}
        <button onClick={() => setV({ ...v, turns: [...v.turns, { from: 'c', text: '' }] })} className="mb-3 text-[13.5px] text-tg-link">+ message</button>
        <Field label="Must do (what a right answer does)"><textarea className={clsx(inputCls, 'min-h-[70px]')} value={v.expect} onChange={e => setV({ ...v, expect: e.target.value })} /></Field>
        <Field label="Facts (optional — e.g. their old BM ID)"><input className={inputCls} value={v.facts || ''} onChange={e => setV({ ...v, facts: e.target.value })} /></Field>
        <div className="mt-3 flex flex-wrap gap-2">
          <Btn onClick={async () => { try { await api('ai_case_save', v); onSaved(); } catch (e) { toast((e as Error).message, 'err'); } }}>Save</Btn>
          <Btn kind="ghost" onClick={onClose}>Cancel</Btn>
          {v.id && <Btn kind="danger" onClick={async () => { if (!confirm('Delete this case?')) return; await api('ai_case_delete', { id: v.id }); onSaved(); }}>Delete</Btn>}
        </div>
      </div>
    </div>
  );
}

/** Talk to the AI as a customer — nothing is sent anywhere. */
function Simulator({ api, onSaveCase }: { api: Api; onSaveCase: (c: any) => void }) {
  const toast = useToast();
  const [biz, setBiz] = useState<'agency' | 'funnel'>('funnel');
  const [turns, setTurns] = useState<{ from: 'c' | 'a'; text: string }[]>([]);
  const [msg, setMsg] = useState('');
  const [facts, setFacts] = useState('');
  const [out, setOut] = useState<Out | null>(null);
  const [busy, setBusy] = useState(false);
  const [alwaysVoice, setAlwaysVoice] = useState(false);
  const [voices, setVoices] = useState<Record<number, string>>({}); // turn index → AI voice audio
  const [heardIdx, setHeardIdx] = useState<Record<number, boolean>>({});
  const showReply = (t: { from: 'c' | 'a'; text: string }[], o: Out) => {
    if (o.voice_audio && o.messages.length) setVoices(v => ({ ...v, [t.length]: o.voice_audio! }));
    setTurns([...t, ...o.messages.map(m => ({ from: 'a' as const, text: m.text }))]);
    setOut(o);
  };
  const sendVoice = async (file: File) => {
    setBusy(true); setOut(null);
    try {
      const fd = new FormData(); fd.append('file', file); fd.append('biz', biz); fd.append('facts', facts); fd.append('turns', JSON.stringify(turns)); fd.append('voice', alwaysVoice ? 'always' : 'auto');
      const r = await fetch('/api/admin/ai_sim_voice', { method: 'POST', body: fd, credentials: 'include' });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(j.error || 'Voice test failed');
      const t = [...turns, { from: 'c' as const, text: `[voice note: "${j.heard}"]` }];
      setHeardIdx(h => ({ ...h, [turns.length]: true }));
      showReply(t, j.out);
    } catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); }
  };
  const mic = useRecorder(file => void sendVoice(file));
  const add = () => { if (!msg.trim()) return; setTurns([...turns, { from: 'c', text: msg.trim() }]); setMsg(''); setOut(null); };
  const ask = async () => {
    const t = msg.trim() ? [...turns, { from: 'c' as const, text: msg.trim() }] : turns;
    if (msg.trim()) { setTurns(t); setMsg(''); }
    if (!t.some(x => x.from === 'c')) return toast('Type a customer message first', 'err');
    setBusy(true); setOut(null);
    try {
      const r = await Promise.race([
        api<{ out: Out }>('ai_sim', { biz, turns: t, facts, voice: alwaysVoice ? 'always' : 'auto', audio: true }),
        new Promise<never>((_, rej) => setTimeout(() => rej(new Error('The AI took too long — try again')), 75000)),
      ]);
      // the AI's answer stays in the chat, so you can just keep typing as the customer
      showReply(t, r.out);
    } catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); }
  };
  const meta = out && (out.action !== 'none' || out.next_step || !out.messages.length);
  return (
    <Box title="Try it as a customer" desc="Chat like a customer — several short messages are fine — and tap AI reply. Tap the mic to send a voice note: the AI hears it and answers (as a voice note when the voice rules say so). The AI's answer stays in the chat, so just keep typing. Nothing goes to Telegram."
      right={<Seg value={biz} onChange={v => { setBiz(v); setTurns([]); setOut(null); }} items={[['funnel', 'Funnel'], ['agency', 'Agency']]} />}>
      <div className="mb-2 min-h-[80px] space-y-1.5 rounded-xl bg-tg-bg/50 p-3">
        {turns.length === 0 && <p className="text-[13px] text-tg-sub">e.g. “hello”, “ad account chahiye”, “kitne ka hai”</p>}
        {turns.map((t, i) => (
          <div key={i} className={clsx('max-w-[85%] whitespace-pre-line rounded-2xl px-3 py-1.5 text-[14px]', t.from === 'a' ? 'ml-auto rounded-br-md bg-tg-out text-tg-outtx' : 'rounded-bl-md bg-tg-input')}>
            {heardIdx[i] && <span className="mb-0.5 block text-[11.5px] font-semibold uppercase tracking-wide text-tg-sub">Your voice note — the AI heard:</span>}
            {voices[i] && <span className="mb-1 block text-[11.5px] font-semibold uppercase tracking-wide text-[#B9DBFF]">Voice note</span>}
            {heardIdx[i] ? t.text.replace(/^\[voice note: "|"\]$/g, '') : t.text}
            {voices[i] && <audio controls autoPlay src={voices[i]} className="mt-2 h-10 w-full max-w-[300px]" />}
          </div>
        ))}
        {busy && <p className="text-right text-[13px] text-tg-sub">typing…</p>}
        {meta && <div className="border-t border-tg-line pt-2"><OutView out={{ ...out!, messages: [] }} />{!out!.messages.length && <p className="text-right text-[12.5px] text-tg-sub">(AI sent no message)</p>}</div>}
      </div>
      {out?.voice && out.voice_error && <p className="mb-2 text-[12.5px] text-tg-bad">Voice note not made: {out.voice_error}</p>}
      <div className="flex gap-1.5">
        <button onClick={() => void mic.toggle()} disabled={busy && !mic.recording} aria-label={mic.recording ? 'Stop and send' : 'Record a voice note'}
          className={clsx('grid h-[46px] shrink-0 place-items-center rounded-xl px-3 text-[14px] font-semibold', mic.recording ? 'bg-tg-red text-white' : 'bg-tg-input')}>{mic.recording ? `■ ${mic.sec}s` : <Mic size={19} />}</button>
        <input className={inputCls} value={msg} onChange={e => setMsg(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') add(); }} placeholder="Customer message…" />
        <Btn kind="ghost" className="shrink-0 whitespace-nowrap" onClick={add}>Add</Btn>
        <Btn className="shrink-0 whitespace-nowrap" busy={busy} onClick={() => void ask()}>AI reply</Btn>
      </div>
      <label className="mt-2 flex items-center gap-2 text-[13px] text-tg-sub"><input type="checkbox" checked={alwaysVoice} onChange={e => setAlwaysVoice(e.target.checked)} /> Every AI reply as a voice note (only for this test)</label>
      <input className={clsx(inputCls, 'mt-2 text-[13.5px]')} value={facts} onChange={e => setFacts(e.target.value)} placeholder="Facts (optional): e.g. Their BM ID used before: 98765432" />
      <div className="mt-2 flex flex-wrap gap-2">
        {turns.length > 0 && <Btn kind="ghost" onClick={() => onSaveCase({ title: '', biz, turns: turns[turns.length - 1]?.from === 'a' ? turns.slice(0, turns.map(x => x.from).lastIndexOf('c') + 1) : turns, expect: '', facts })}>Save as test case</Btn>}
        {turns.length > 0 && <Btn kind="ghost" onClick={() => { setTurns([]); setOut(null); setVoices({}); setHeardIdx({}); }}>New chat</Btn>}
      </div>
    </Box>
  );
}

/* ---------------- Learn ---------------- */
function Learn({ api, reload }: { api: Api; reload: () => void }) {
  const toast = useToast();
  const [d, setD] = useState<any>(null);
  const load = useCallback(() => api('ai_learn').then(setD).catch(() => setD({ feedback: [], sold: [] })), [api]);
  useEffect(() => { void load(); }, [load]);
  if (!d) return <p className="text-tg-sub">Loading…</p>;
  return (
    <>
      <Box title="Agents changed the coach's reply" desc="What the coach suggested vs what the agent really sent. Good ones → teach the AI.">
        {!d.feedback.length && <p className="text-[13px] text-tg-sub">Nothing yet.</p>}
        {d.feedback.map((f: any) => (
          <div key={f.id} className="border-b border-tg-line py-3 last:border-0">
            <p className="text-[12.5px] text-tg-sub">{f.agent_name || 'Admin'} · {f.lead_name || 'Chat #' + f.lead_id} · {listTime(f.created_at)}</p>
            <p className="mt-1 whitespace-pre-line text-[13.5px] text-tg-sub line-through decoration-white/30">{f.suggested}</p>
            <p className="mt-1 whitespace-pre-line text-[14.5px]">{f.sent}</p>
            <div className="mt-2 flex gap-2">
              <Btn kind="green" onClick={async () => { await api('ai_feedback_use', { id: f.id }); toast('Added as an example'); void load(); reload(); }}>Teach AI</Btn>
              <Btn kind="ghost" onClick={async () => { await api('ai_feedback_use', { id: f.id, use: false }); void load(); reload(); }}>Ignore</Btn>
            </div>
          </div>
        ))}
      </Box>
      <Box title="Sold chats" desc="Turn a real sold chat into an example (names, numbers and IDs are hidden).">
        {!d.sold.length && <p className="text-[13px] text-tg-sub">No sold chats yet.</p>}
        {d.sold.map((l: any) => (
          <div key={l.id} className="flex items-center gap-3 border-b border-tg-line py-2.5 last:border-0">
            <span className="min-w-0 flex-1"><span className="block truncate text-[15px]">{l.name || l.tg_name || 'Chat #' + l.id}</span><span className="text-[12.5px] text-tg-sub">{l.biz === 'funnel' ? 'Funnel' : 'Agency'} · {l.n} messages</span></span>
            <Btn kind="ghost" onClick={async () => { try { await api('ai_example_from_lead', { lead_id: l.id, title: `Sold: ${l.biz === 'funnel' ? 'funnel' : 'account'} #${l.id}` }); toast('Added as an example'); reload(); } catch (e) { toast((e as Error).message, 'err'); } }}>Use as example</Btn>
          </div>
        ))}
      </Box>
    </>
  );
}

/* ---------------- Proofs ---------------- */
function Proofs({ api }: { api: Api }) {
  const toast = useToast();
  const [rows, setRows] = useState<any[] | null>(null);
  const [biz, setBiz] = useState<'agency' | 'funnel' | 'any'>('agency');
  const [busy, setBusy] = useState(false);
  const load = useCallback(() => api('ai_proofs').then(r => setRows(r.proofs)).catch(() => setRows([])), [api]);
  useEffect(() => { void load(); }, [load]);
  const upload = async (files: FileList | null) => {
    if (!files?.length) return;
    setBusy(true);
    try {
      for (const f of Array.from(files)) {
        const fd = new FormData(); fd.append('file', f); fd.append('biz', biz);
        const r = await fetch('/api/admin/ai_proof_upload', { method: 'POST', body: fd, credentials: 'include' });
        if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || 'Upload failed');
      }
      toast('Uploaded'); void load();
    } catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); }
  };
  return (
    <Box title="Proof screenshots" desc="When a customer asks to see our work, the AI sends 3-4 of these. Only real screenshots, with names and numbers hidden."
      right={<div className="flex flex-wrap items-center gap-2"><Seg value={biz} onChange={setBiz} items={[['agency', 'Agency'], ['funnel', 'Funnel'], ['any', 'Both']]} />
        <label className={clsx('cursor-pointer rounded-xl bg-tg-acc px-4 py-2.5 text-[14px] font-semibold text-white', busy && 'opacity-60')}>{busy ? 'Uploading…' : '+ Upload'}<input type="file" accept="image/*" multiple className="hidden" onChange={e => void upload(e.target.files)} /></label></div>}>
      {!rows ? <p className="text-tg-sub">Loading…</p> : !rows.length ? <p className="text-[13px] text-tg-sub">No proofs yet.</p> : (
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          {rows.map(p => (
            <div key={p.id} className="overflow-hidden rounded-xl bg-tg-bg/50">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={`/api/admin/ai_proof_img?id=${p.id}`} alt="" className={clsx('aspect-[3/4] w-full object-cover', p.status !== 'on' && 'opacity-40')} />
              <div className="flex items-center gap-2 p-2 text-[12.5px]">
                <span className="text-tg-sub">{p.biz === 'any' ? 'Both' : p.biz === 'funnel' ? 'Funnel' : 'Agency'}</span>
                <span className="ml-auto"><Toggle on={p.status === 'on'} onChange={async v => { await api('ai_proof_set', { id: p.id, status: v ? 'on' : 'off' }); void load(); }} /></span>
                <button onClick={async () => { if (!confirm('Delete?')) return; await api('ai_proof_delete', { id: p.id }); void load(); }} className="text-tg-red">✕</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </Box>
  );
}

/** v137: the words the gender fix changed, highlighted in "Customer hears". */
function hl(text: string, fixed?: { from: string; to: string }[]) {
  const set = new Set((fixed || []).map(f => f.to.replace(/[,.?!।;]+$/, '')));
  if (!set.size) return text;
  return text.split(/(\s+)/).map((w, i) => set.has(w.replace(/[,.?!।;]+$/, '')) ? <mark key={i} className="rounded bg-tg-acc/20 px-0.5 text-tg-text">{w}</mark> : w);
}
