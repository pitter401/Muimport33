'use client';

// v124: Admin → Sale history — every sale (Telegram chats, WhatsApp, website) or top-up in a period, and who sold it.
import { useCallback, useEffect, useState } from 'react';
import { MessageCircle, Globe, Trash2, Search, Send } from 'lucide-react';
import clsx from 'clsx';
import { Seg, usd, useInterval, useToast, RangePick, Skeleton, DropPill, Avatar, Tag, SectionHead, Group, MiniBars, dayLabel } from './ui';

type Api = <T = any>(path: string, body?: unknown) => Promise<T>;
type Who = { key: string; name: string; role: string };
type Row = { id: string; at: number; src: 'chat' | 'whatsapp' | 'website'; product: string; line: string; qty: number; amount: number; commission: number; fee?: number; who: Who; customer: string; sub: string; lead_id: number | null; note: string | null; offer?: boolean; repeat?: boolean; status?: string; special?: { unit: number; list: number } | null };
type Data = { kind: string; total: { n: number; amount: number; commission: number; fee: number }; by: (Who & { n: number; amount: number; commission: number; fee: number })[]; people: Who[]; rows: Row[]; truncated?: boolean };
type Range = string;

const ROLE: Record<string, [string, string]> = { manager: ['Manager', 'bg-tg-orange text-black'], agent: ['Agent', 'bg-tg-acc/80 text-white'], whatsapp: ['WhatsApp', 'bg-[#25D366] text-black'], website: ['Website', 'bg-[#a78bfa] text-black'], admin: ['Admin', 'bg-white/20 text-white'] };
const when = (ms: number, range: Range) => new Date(ms).toLocaleString(undefined, range === 'today' || range === 'yesterday' ? { hour: '2-digit', minute: '2-digit' } : { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });

const ROLE_T: Record<string, ['ok' | 'acc' | 'prem' | 'fun' | 'mute', string]> = { manager: ['prem', 'Manager'], agent: ['acc', 'Agent'], whatsapp: ['ok', 'WhatsApp'], website: ['fun', 'Website'], admin: ['mute', 'Admin'] };
function RoleChip({ role }: { role: string }) {
  const [t, l] = ROLE_T[role] || ROLE_T.agent;
  return <Tag tone={t}>{l}</Tag>;
}
void ROLE;
/** v167: small app badge on the avatar (Telegram / WhatsApp / Website). */
function SrcBadge({ src }: { src: Row['src'] }) {
  const [bg, I] = src === 'whatsapp' ? ['#25D366', MessageCircle] : src === 'website' ? ['#8E8E93', Globe] : ['#2AABEE', Send];
  return <span className="absolute -bottom-0.5 -right-0.5 grid h-[17px] w-[17px] place-items-center rounded-full text-white ring-2 ring-tg-panel" style={{ background: bg }}><I size={9.5} strokeWidth={2.6} /></span>;
}
const LINE_L: Record<string, [string, string]> = { agency: ['Agency', 'text-tg-link'], premium: ['Premium', 'text-tg-premium'], funnel: ['Funnel', 'text-tg-funnel'] };

export function SalesHistory({ api, onOpenChat, onAddWa, reloadKey = 0 }: { api: Api; onOpenChat: (id: number) => void; onAddWa?: () => void; reloadKey?: number }) {
  const [q, setQ] = useState(''); // v136: search customer / #id
  const [range, setRange] = useState<Range>('today');
  const [kind, setKind] = useState<'sales' | 'topups'>('sales');
  const [line, setLine] = useState<'all' | 'agency' | 'premium' | 'funnel'>('all');
  const [who, setWho] = useState('all');
  const [d, setD] = useState<Data | null>(null);
  const load = useCallback(() => api<Data>(`sale_history?range=${range}&kind=${kind}&line=${line}&who=${encodeURIComponent(who)}`).then(setD).catch(() => {}), [api, range, kind, line, who]);
  useEffect(() => { setD(null); void load(); }, [load]);
  useEffect(() => { if (reloadKey) void load(); }, [reloadKey]); // eslint-disable-line react-hooks/exhaustive-deps
  const ql = q.trim().toLowerCase().replace(/^#/, '');
  const rows = (d?.rows || []).filter(r => !ql || `${r.customer} ${r.sub} ${r.lead_id ?? ''} ${r.product} ${r.who.name}`.toLowerCase().includes(ql));
  useInterval(() => void load(), 30000);
  const tops = kind === 'topups';
  const toast = useToast();
  async function delTop(r: Row) {
    if (!confirm(`Remove this top-up?\n\n${usd(r.amount)} · ${r.customer}\n\nOnly for a top-up added by mistake. It comes off revenue and fees.`)) return;
    try { await api('topup_del', { id: r.id }); toast('Top-up removed'); await load(); } catch (e) { toast((e as Error).message, 'err'); }
  }
  // v167: day groups with a day total; a daily bar chart when the period has 2+ days with sales (real data only)
  const days: { key: string; label: string; n: number; amount: number; rows: Row[] }[] = [];
  for (const r of rows) {
    const k = new Date(r.at).toDateString(); let g = days[days.length - 1];
    if (!g || g.key !== k) { g = { key: k, label: dayLabel(r.at), n: 0, amount: 0, rows: [] }; days.push(g); }
    g.n++; g.amount += Number(r.amount) || 0; g.rows.push(r);
  }
  const multiDay = !['today', 'yesterday'].includes(range);
  const bars = multiDay && days.length >= 2 ? [...days].reverse().map(g => g.amount) : [];
  const RL: Record<string, string> = { today: 'today', yesterday: 'yesterday', '7d': '· 7 days', '30d': '· 30 days', all: '· lifetime' };
  const people: [string, string][] = [['all', 'Everyone'], ...(d?.people || []).map(p => [p.key, `${p.name}${p.role === 'manager' ? ' (Manager)' : p.role === 'agent' ? ' (Agent)' : ''}`] as [string, string])];
  if (who !== 'all' && !people.some(p => p[0] === who)) people.push([who, d?.by.find(b => b.key === who)?.name || who]);
  return (
    <div>
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <RangePick value={range} onChange={setRange} />
        {!tops && <DropPill value={line} onChange={v => setLine(v as typeof line)} menuTitle="Line" dot={line === 'agency' ? '#3390EC' : line === 'premium' ? '#D98A00' : line === 'funnel' ? '#7C5CE0' : undefined} items={[['all', 'All lines'], ['agency', 'Agency'], ['premium', 'Premium'], ['funnel', 'Funnel']]} />}
        <DropPill value={who} onChange={setWho} menuTitle="Who sold" items={people as any} />
        {onAddWa && <button onClick={onAddWa} data-add-wa className="af-pill af-press !text-tg-link">Add WhatsApp sale</button>}
      </div>

      <div className="af-card overflow-hidden" data-sale-hero>
        <div className="px-4 pb-3 pt-3.5">
          <p className="text-[13.5px] font-medium text-tg-sub">{tops ? 'Top-up volume' : 'Revenue'} {RL[range] || '· chosen dates'}</p>
          <p className="af-hero-num mt-0.5 text-tg-ok">{d ? usd(d.total.amount) : '…'}</p>
          {bars.length > 0 && <MiniBars className="mt-3" values={bars} highlightLast={range !== 'all'} />}
        </div>
        <div className="af-grid3">
          <div><p className="text-[12.5px] font-medium text-tg-sub">{tops ? 'Top-ups' : 'Sales'}</p><p className="af-mid-num">{d ? d.total.n : '…'}</p></div>
          <div><p className="text-[12.5px] font-medium text-tg-sub">{tops ? 'Average' : 'Avg sale'}</p><p className="af-mid-num">{d && d.total.n ? usd(d.total.amount / d.total.n) : '—'}</p></div>
          <div><p className="truncate text-[12.5px] font-medium text-tg-sub">{tops ? 'Fees earned' : 'Commission'}</p><p className="af-mid-num">{d ? usd(tops ? d.total.fee : d.total.commission) : '…'}</p></div>
        </div>
      </div>

      <Seg full className="my-3" value={kind} onChange={v => { setKind(v); setWho('all'); }} items={[['sales', `Sales${!tops && d ? ` · ${d.total.n}` : ''}`], ['topups', `Top-ups${tops && d ? ` · ${d.total.n}` : ''}`]]} />
      <label className="mb-1 flex h-[38px] items-center gap-2 rounded-xl bg-tg-panel px-3 text-tg-faint shadow-[var(--tg-card-shadow)]"><Search size={17} className="shrink-0" /><input value={q} onChange={e => setQ(e.target.value)} placeholder="Customer or #id" aria-label="Search sales" className="h-full min-w-0 flex-1 bg-transparent text-[15px] text-tg-text outline-none placeholder:text-tg-faint" /></label>

      {!!d?.by.length && (
        <>
          <SectionHead title={tops ? 'Who added them' : 'Who sold'} />
          <Group>
            {d.by.map(b => (
              <button key={b.key} onClick={() => setWho(who === b.key ? 'all' : b.key)} className={clsx('af-row', who === b.key && '!bg-tg-accsoft')}>
                <span className="min-w-0 flex-1"><span className="flex items-center gap-2"><span className="truncate text-[15px] font-medium">{b.name}</span><RoleChip role={b.role} /></span>
                  <span className="block truncate text-[12.5px] text-tg-sub">{b.n} {tops ? 'top-up' : 'sale'}{b.n === 1 ? '' : 's'}{!tops && b.commission ? ` · commission ${usd(b.commission)}` : ''}{tops && b.fee ? ` · fees ${usd(b.fee)}` : ''}</span></span>
                <span className="text-[15.5px] font-semibold af-num text-tg-ok">{usd(b.amount)}</span>
              </button>
            ))}
          </Group>
        </>
      )}

      {!d && <div className="mt-4"><Skeleton rows={3} h={68} /></div>}
      {d && !rows.length && <div className="af-card mt-4 px-4 py-8 text-center text-[14px] text-tg-sub">{q ? 'Nothing matches the search' : `No ${tops ? 'top-ups' : 'sales'} in this period`}</div>}
      {d?.truncated && <p className="mx-1 mt-3 text-[12.5px] text-tg-sub" data-truncated>Showing the latest {d.rows.length}. Pick a shorter period to see all.</p>}
      {days.map(g => (
        <section key={g.key} data-sale-day>
          <SectionHead title={g.label} action={<span className="af-num">{usd(g.amount)} · {g.n}</span>} />
          <Group avs>
            {g.rows.map(r => (
              <div key={r.id} role={r.lead_id ? 'button' : undefined} onClick={() => r.lead_id && onOpenChat(r.lead_id)} className={clsx('af-row !items-start', r.lead_id && 'cursor-pointer active:bg-tg-hover')} data-sale-row>
                <span className="relative mt-0.5 shrink-0"><Avatar name={r.customer || '?'} id={r.lead_id || r.customer.length} size={40} /><SrcBadge src={r.src} /></span>
                <div className="min-w-0 flex-1">
                  <p className="flex items-center gap-1.5 text-[15px] font-medium"><span className="truncate">{r.customer}</span>{r.offer && <Tag tone="warn">offer</Tag>}{r.repeat && <Tag>repeat</Tag>}{r.special && <span data-special title={`Special price: $${r.special.unit} instead of $${r.special.list}`}><Tag tone="warn">special</Tag></span>}</p>
                  <p className="truncate text-[13px] text-tg-sub">{r.product}{r.qty > 1 ? ` × ${r.qty}` : ''}{!tops && LINE_L[r.line] ? <> · <span className={LINE_L[r.line][1]}>{LINE_L[r.line][0]}</span></> : null} · {r.who.name}</p>
                  {(r.sub || r.lead_id || r.status) && <p className="truncate text-[12px] text-tg-sub">{[r.sub, r.lead_id ? `#${r.lead_id}` : '', r.who.role ? (ROLE_T[r.who.role] || ROLE_T.agent)[1] : ''].filter(Boolean).join(' · ')}{r.status && <span className={r.status.startsWith('Paid,') ? 'text-tg-orange' : ''}> · {r.status}</span>}</p>}
                  {r.special && <p className="truncate text-[12px] text-tg-warn">Special price (${r.special.unit} instead of ${r.special.list})</p>}
                  {r.note && <p className="truncate text-[12px] text-tg-sub">{r.note}</p>}
                </div>
                <div className="shrink-0 text-right">
                  <p className="text-[15.5px] font-semibold af-num text-tg-ok">+{usd(r.amount)}</p>
                  <p className="text-[12px] text-tg-sub af-num">{when(r.at, multiDay ? 'today' : range)}</p>
                  {!!r.commission && <p className="text-[11.5px] text-tg-sub af-num">comm. {usd(r.commission)}</p>}
                  {!!r.fee && <p className="text-[11.5px] text-tg-sub af-num">fee {usd(r.fee)}</p>}
                  {tops && r.id.startsWith('t') && <button aria-label="Remove top-up" onClick={e => { e.stopPropagation(); void delTop(r); }} className="ml-auto mt-1 grid h-8 w-8 place-items-center rounded-full text-tg-sub hover:bg-tg-hover hover:text-tg-bad"><Trash2 size={16} /></button>}
                </div>
              </div>
            ))}
          </Group>
        </section>
      ))}
    </div>
  );
}
