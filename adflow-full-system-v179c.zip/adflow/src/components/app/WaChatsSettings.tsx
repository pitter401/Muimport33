'use client';

// v131: Admin → Settings → WhatsApp chats (WATI). Master switch, API key, webhook URL to paste in WATI, test message,
// pixels for WhatsApp chats, follow-up timing, the page texts and the raw webhook log (to see what WATI sends).
import { useEffect, useRef, useState } from 'react';
import { Copy } from 'lucide-react';
import { Btn, Field, inputCls, Toggle, useToast } from './ui';
import { OfferImgPreview } from './OfferImgPreview';
import { BTN_PLACEHOLDERS, parseLabels, parseReplies, effectiveLine, remapLine, isTalkToAgent, cleanButtons, type BtnLine, type BtnReplies } from '@/server/btnreplies';

type Api = <T = any>(path: string, body?: unknown) => Promise<T>;
type S = Record<string, string>;

export function WaChatsSettings({ api, s, set, T, noMaster }: { api: Api; s: S; set: (k: string, v: string) => void; T: (k: string, label: string, hint?: React.ReactNode, rows?: number, type?: string) => React.ReactNode; noMaster?: boolean }) {
  const toast = useToast();
  const [info, setInfo] = useState<{ hook_url: string; ready: boolean; log: { id: number; at: number; kind: string; body: string }[]; api_log?: { id: number; at: number; kind: string; body: string }[]; btn_preview?: Record<string, Record<string, string>> } | null>(null);
  const [to, setTo] = useState(''); const [busy, setBusy] = useState(false); const [showLog, setShowLog] = useState(false);
  const load = () => api('wati').then(setInfo).catch(() => {});
  useEffect(() => { void load(); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const copy = (x: string) => { try { void navigator.clipboard.writeText(x); toast('Copied'); } catch { /* ignore */ } };
  async function test() {
    setBusy(true);
    try { await api('wati_test', { phone: to, text: 'Test message from ' + (s.brand_name || 'AdsBhai') }); toast('Sent. Check WhatsApp on that number.'); }
    catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); void load(); }
  }
  const on = s.wati_on === '1';
  const pages = ['agency', 'premium', 'funnel'];
  return (
    <div data-wa-settings>
      {!noMaster && <div className={'mb-3 flex items-center justify-between gap-3 rounded-xl px-4 py-3 ' + (on ? 'bg-[#25d366]/15' : 'bg-tg-red/15')}>
        <span><span className="block font-semibold">WhatsApp chats — master switch</span><span className="text-[12.5px] text-tg-sub">OFF = the whole WhatsApp chat system stops: no chats from the webhook, no sending, the WhatsApp pages go to your home page, no WhatsApp follow-ups or events.</span></span>
        <Toggle on={on} onChange={v => set('wati_on', v ? '1' : '0')} />
      </div>}
      {T('wati_url', 'WATI API endpoint', 'WATI → API Docs. Default: https://live-mt-server.wati.io')}
      {T('wati_token', 'WATI API key', 'WATI → API Docs → access token. Stays hidden after saving.')}
      {T('wa_number', 'Your WhatsApp number', 'The number customers write to (same as in WATI).')}
      <Field label="Webhook URL — paste in WATI → Connectors → Webhooks (event: message, Status: Enabled)">
        <div className="flex items-center gap-2 rounded-xl bg-tg-input p-2.5"><code className="min-w-0 flex-1 break-all text-[12.5px]" data-hook-url>{info?.hook_url || '…'}</code><button aria-label="Copy" onClick={() => copy(info?.hook_url || '')} className="grid h-9 w-9 shrink-0 place-items-center rounded-lg text-tg-link hover:bg-tg-hover"><Copy size={17} /></button></div>
      </Field>
      <Field label="Send a test message" hint="Save the settings first. The number must have messaged you in the last 24 hours (WhatsApp rule), or the message may not arrive.">
        <div className="flex gap-2"><input className={inputCls} value={to} onChange={e => setTo(e.target.value)} placeholder="919876543210" inputMode="tel" /><Btn busy={busy} onClick={() => void test()}>Send</Btn></div>
      </Field>
      <WatiPro api={api} s={s} set={set} T={T} preview={info?.btn_preview} />
      <Sw on={s.wati_sync_phone !== '0'} onChange={v => set('wati_sync_phone', v ? '1' : '0')} title="Show replies typed on the phone" help="Messages you type in the WhatsApp Business app reach WATI but not our webhook. We pull them from WATI when the customer writes and when a chat is opened. Works on any WATI plan." k="wati_sync_phone" />
      <div className="mb-4 rounded-xl bg-tg-input p-3" data-wati-api-log>
        <div className="mb-1.5 flex items-center justify-between gap-2"><span className="text-[13.5px] font-semibold">Last WATI API results</span><button onClick={() => void load()} className="text-[13px] font-medium text-tg-link">Refresh</button></div>
        <p className="mb-2 text-[12px] text-tg-sub">Sends, buttons, chat status, contact attributes and phone sync. Use it to check the Pro calls on your account.</p>
        {!info?.api_log?.length && <p className="py-1 text-[12.5px] text-tg-sub">Nothing yet.</p>}
        {info?.api_log?.map(l => (
          <p key={l.id} className="border-t border-tg-line py-1.5 font-mono text-[11.5px] leading-snug break-all first-of-type:border-t-0">
            <span className={'mr-1.5 rounded px-1 py-px text-[10.5px] font-semibold uppercase ' + (/^(2\d\d|ok)\b|→ ok|messages=/.test(l.body) ? 'bg-tg-green/15 text-tg-green' : /^\d{3}\b|fail|error/.test(l.body) ? 'bg-tg-red/15 text-tg-red' : 'bg-tg-hover text-tg-sub')}>{l.kind}</span>
            <span className="text-tg-sub">{new Date(l.at).toLocaleTimeString()}</span> {l.body.slice(0, 300)}
          </p>
        ))}
      </div>
      <div className="mb-3 flex items-center justify-between gap-3 rounded-xl bg-tg-input px-4 py-3"><span><span className="block">AI replies on WhatsApp chats</span><span className="text-[12.5px] text-tg-sub">Same AI and the same agents as Telegram (Admin → AI). Only inside the 24-hour window.</span></span><Toggle on={s.wa_ai_on !== '0'} onChange={v => set('wa_ai_on', v ? '1' : '0')} /></div>
      <div className="mb-3 flex items-center justify-between gap-3 rounded-xl bg-tg-input px-4 py-3"><span><span className="block">Automatic follow-ups on WhatsApp</span><span className="text-[12.5px] text-tg-sub">Inside the 24-hour window (no quiet hours, or the window would close). Same follow-up texts as Telegram.</span></span><Toggle on={s.wa_fu_on !== '0'} onChange={v => set('wa_fu_on', v ? '1' : '0')} /></div>
      <div className="grid gap-x-3 sm:grid-cols-3">
        {T('wa_fu_hours', 'Follow-up 1 and 2 (hours)', 'After our last message, e.g. 6,12', undefined)}
        {T('wa_fu_last_min', 'Last follow-up (minutes before the window closes)', undefined, undefined, 'number')}
        {T('wa_lead_turns', 'Lead after this many customer replies', 'Customer → us → customer → us → customer = 2', undefined, 'number')}
      </div>
      <p className="mb-2 mt-2 text-[14px] font-semibold">Meta pixel for WhatsApp chats</p>
      <p className="mb-3 text-[12.5px] text-tg-sub">Own pixels, never the Telegram ones. Lead (real conversation), Purchase (with the customer’s number), Subscribe (community), and the WhatsApp pages’ PageView / ViewContent.</p>
      <div className="grid gap-x-3 sm:grid-cols-3">
        {T('wa_pixel_id', 'Agency + Premium: Pixel ID')}
        {T('wa_capi_token', 'Agency + Premium: CAPI token')}
        {T('wa_test_event_code', 'Test event code', 'Only while testing')}
        {T('wa_f_pixel_id', 'Funnel: Pixel ID')}
        {T('wa_f_capi_token', 'Funnel: CAPI token')}
        {T('wa_f_test_event_code', 'Test event code', 'Only while testing')}
      </div>
      <p className="mb-2 mt-2 text-[14px] font-semibold">WhatsApp ad pages</p>
      <div className="mb-3 rounded-xl bg-tg-input px-4 py-3 text-[13px]">
        <p className="mb-1 text-tg-sub">Chat ads (button opens WhatsApp with a code):</p>
        {pages.map(p => <p key={p} className="break-all">/{p}/whatsapp</p>)}
        <p className="mb-1 mt-2 text-tg-sub">Community ads (their number, then the community link from “WhatsApp community” above):</p>
        {pages.map(p => <p key={p} className="break-all">/{p}/community</p>)}
      </div>
      {T('wa_prefill', 'Pre-typed message', '{what} = the service, {code} = their code (keep it, it links the chat to the ad).')}
      {T('wa_page_title', 'Chat page: title')}
      {T('wa_page_text', 'Chat page: text', undefined, 2)}
      {T('wa_comm_page_title', 'Community page: title')}
      {T('wa_comm_page_text', 'Community page: text', undefined, 2)}
      <button onClick={() => { setShowLog(v => !v); void load(); }} className="mt-1 text-[13.5px] font-medium text-tg-link">{showLog ? 'Hide' : 'Show'} WATI log (last 40)</button>
      {showLog && (
        <div className="mt-2 max-h-[320px] overflow-y-auto rounded-xl bg-tg-input p-2 text-[11.5px]" data-wati-log>
          {!info?.log.length && <p className="p-2 text-tg-sub">Nothing yet.</p>}
          {info?.log.map(l => <p key={l.id} className="border-b border-tg-line py-1 font-mono break-all"><span className="text-tg-sub">{new Date(l.at).toLocaleTimeString()} {l.kind}</span> {l.body.slice(0, 600)}</p>)}
        </div>
      )}
    </div>
  );
}

function Sw({ on, onChange, title, help, k, sub }: { on: boolean; onChange: (v: boolean) => void; title: string; help: string; k: string; sub?: boolean }) {
  return (
    <div data-sw={k} className={'flex items-center justify-between gap-3 rounded-xl px-4 py-3 ' + (sub ? 'bg-tg-panel' : 'mb-3 bg-tg-input')}>
      <span className="min-w-0"><span className="block">{title}</span><span className="text-[12.5px] text-tg-sub">{help}</span></span>
      <Toggle on={on} onChange={onChange} />
    </div>
  );
}

/** v137: WATI Pro plan extras. Everything here is OFF (no extra API calls) while the main switch is off. */
function WatiPro({ s, set, T, preview, api }: { api: Api; s: S; set: (k: string, v: string) => void; T: (k: string, label: string, hint?: React.ReactNode, rows?: number, type?: string) => React.ReactNode; preview?: Record<string, Record<string, string>> }) {
  const pro = s.wati_pro === '1';
  return (
    <div className="mb-3 rounded-xl bg-tg-input" data-wati-pro>
      <div className="flex items-center justify-between gap-3 px-4 py-3">
        <span className="min-w-0"><span className="block font-semibold">We’re on the WATI Pro plan</span><span className="text-[12.5px] text-tg-sub">Turns on tap-to-answer menus and buttons, chat status sync and contact attributes. OFF = everything works as before, no extra WATI calls.</span></span>
        <Toggle on={pro} onChange={v => set('wati_pro', v ? '1' : '0')} />
      </div>
      {!pro && (
        <div className="border-t border-tg-line px-2.5 pb-2.5 pt-2.5">
          <Sw sub k="wati_plain_img" on={s.wati_plain_img !== '0'} onChange={v => set('wati_plain_img', v ? '1' : '0')} title="Send the offer image before the welcome" help="Normal WhatsApp (no Pro buttons): the chat's line image goes as its own message right before the plain welcome (inside the 24-hour window the customer just opened, no template). Not sent → just the welcome." />
        </div>
      )}
      {pro && (
        <div className="space-y-2 border-t border-tg-line px-2.5 pb-2.5 pt-2.5">
          <Sw sub k="wati_buttons" on={s.wati_buttons !== '0'} onChange={v => set('wati_buttons', v ? '1' : '0')} title="Buttons and list menu" help="The 1/2/3/4 menu becomes a list to tap. Every other WhatsApp welcome gets up to 3 buttons (each label may start with one of the 6 approved icons, e.g. the money bag on See pricing). If WATI refuses, the plain text goes instead." />
          {s.wati_buttons !== '0' && (
            <div className="rounded-xl bg-tg-panel px-3 pb-1 pt-3" data-wati-btns>
              <Sw sub k="wati_btn_img" on={s.wati_btn_img !== '0'} onChange={v => set('wati_btn_img', v ? '1' : '0')} title="Send the offer image with buttons" help="The welcome buttons message gets the chat's line image as its header (one message: image, short caption, 3 buttons). WATI refuses the image → the buttons go again without it (both tries in the API log). The list menu has no image." />
              <OfferImgPreview api={api} on={s.wati_btn_img !== '0'} />
              <Sw sub k="img_on_replies" on={s.img_on_replies === '1'} onChange={v => set('img_on_replies', v ? '1' : '0')} title="Also on the button auto-replies" help="Same switch as in Settings → Telegram channel. OFF (recommended) = See pricing / What's included replies are text with follow-up buttons." />
              <p data-tg-also className="mb-2 rounded-lg bg-tg-input px-2.5 py-1.5 text-[12px] text-tg-sub">Also used in the Telegram bot welcome: the pricing, "What's included" and get-started replies answer the bot's See pricing / What's included buttons (Settings → Telegram channel).</p>
              <p className="mb-2 px-1 text-[12.5px] text-tg-sub">Button labels per chat type: comma separated, max 3, up to 20 characters each. One approved icon at the start is allowed (money bag, package, check, gem, chart, speech bubble), no other emoji; taps match with or without it. Premium chats only ever see the Premium buttons.</p>
              <BtnReplyHelp />
              {(['agency', 'premium', 'funnel'] as BtnLine[]).map(ln => (
                <div key={ln} data-btn-line={ln} className="mb-3 last:mb-1">
                  {T('wati_btn_' + ln, ({ agency: 'Agency buttons', premium: 'Premium buttons', funnel: 'Funnel buttons' } as const)[ln])}
                  <BtnReplies ln={ln} s={s} set={set} preview={preview?.[ln]} />
                </div>
              ))}
            </div>
          )}
          <Sw sub k="wati_status_sync" on={s.wati_status_sync !== '0'} onChange={v => set('wati_status_sync', v ? '1' : '0')} title="Chat status sync" help="Sold, Dead or deleted here → Solved in the WATI inbox. The customer writes again → Open." />
          <Sw sub k="wati_attr_sync" on={s.wati_attr_sync !== '0'} onChange={v => set('wati_attr_sync', v ? '1' : '0')} title="Contact attributes" help="Saves adsbhai_line, adsbhai_status, adsbhai_agent, adsbhai_accounts and adsbhai_lead_id on the WATI contact, only when a value changes." />
        </div>
      )}
    </div>
  );
}

/** v138: placeholders the button replies can use (filled from the current prices when the reply is sent). */
function BtnReplyHelp() {
  return (
    <details className="mb-3 rounded-lg bg-tg-input px-3 py-2 text-[12.5px]" data-btn-help>
      <summary className="cursor-pointer font-medium text-tg-text">Auto-replies: how they work</summary>
      <p className="mt-1.5 text-tg-sub">When the customer taps a button, this reply goes at once (once per button per chat in 10 minutes). The agent still gets the chat. Leave a reply empty for no auto-reply. Prices come from your settings, so write them as placeholders:</p>
      <p className="mt-1.5 leading-relaxed">{BTN_PLACEHOLDERS.map(([k, d]) => <span key={k} className="mr-2 inline-block"><code className="text-tg-link">{k}</code> <span className="text-tg-sub">{d}</span></span>)}</p>
    </details>
  );
}

/** v138: one row per button label: the reply text, a voice note switch and up to 3 buttons under the reply.
 *  Renaming a label keeps its reply (same position). Saved as one JSON setting: wati_btn_replies. */
function BtnReplies({ ln, s, set, preview }: { ln: BtnLine; s: S; set: (k: string, v: string) => void; preview?: Record<string, string> }) {
  const labels = parseLabels(s['wati_btn_' + ln], ln);
  const map: BtnReplies = parseReplies(s.wati_btn_replies);
  const rows = effectiveLine(map, ln, labels);
  const prev = useRef<string[] | null>(null);
  const key = labels.join('\u0001');
  const save = (line: Record<string, { text: string; voice: boolean; buttons: string[] }>) => set('wati_btn_replies', JSON.stringify({ ...map, [ln]: line }));
  useEffect(() => { // a label was renamed → its reply moves with it
    const p = prev.current;
    prev.current = labels;
    if (!p || p.join('\u0001') === key) return;
    save(remapLine(map, ln, p, labels));
  }, [key]); // eslint-disable-line react-hooks/exhaustive-deps
  const edit = (label: string, patch: Partial<{ text: string; voice: boolean; buttons: string[] }>) => save({ ...rows, [label]: { ...rows[label], ...patch } });
  return (
    <div className="-mt-1.5 space-y-2" data-btn-replies={ln}>
      {labels.map(l => {
        const r = rows[l], talk = isTalkToAgent(l);
        const pv = preview?.[l];
        return (
          <div key={l} data-btn-reply={l} className="rounded-xl border border-tg-line bg-tg-bg/40 p-2.5">
            <div className="mb-1.5 flex items-center justify-between gap-2">
              <span className="min-w-0 truncate text-[13px] font-semibold"><span className="mr-1.5 rounded-md bg-tg-hover px-1.5 py-px text-[11.5px] font-medium text-tg-sub">Tap</span>{l}</span>
              <span className="flex shrink-0 items-center gap-2 text-[12.5px] text-tg-sub">Voice note<Toggle label={`Voice note for ${l}`} on={!!r?.voice} onChange={v => edit(l, { voice: v })} /></span>
            </div>
            {talk && <p className="mb-1.5 text-[12px] text-tg-sub">Also adds a note in the chat and rings the agent.</p>}
            <textarea data-btn-text aria-label={`Auto-reply for ${l}`} className={inputCls + ' !py-2.5 text-[14px] leading-snug'} rows={talk ? 2 : 4} value={r?.text ?? ''} placeholder="No auto-reply" onChange={e => edit(l, { text: e.target.value })} />
            {!talk && (
              <input data-btn-follow aria-label={`Buttons under the reply for ${l}`} className={inputCls + ' mt-1.5 !py-2 text-[13px]'} value={(r?.buttons || []).join(', ')} placeholder="Buttons under the reply (optional, max 3)"
                onChange={e => edit(l, { buttons: e.target.value.split(',').map(x => x.trimStart()).slice(0, 3) })} onBlur={e => edit(l, { buttons: cleanButtons(e.target.value) })} />
            )}
            {pv && <p data-btn-preview className="mt-1.5 line-clamp-3 whitespace-pre-line text-[12px] leading-snug text-tg-sub"><span className="font-medium text-tg-text">Customer gets: </span>{pv}</p>}
          </div>
        );
      })}
    </div>
  );
}
