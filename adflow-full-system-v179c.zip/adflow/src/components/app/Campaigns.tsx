'use client';

// v130: which Meta campaign / ad brings joins, chats and sales — so the one that SELLS gets scaled, not the one with cheap joins.
import { useCallback, useEffect, useState } from 'react';
import { ChevronDown, Copy, Megaphone, Settings2, Trophy } from 'lucide-react';
import clsx from 'clsx';
import { useToast, Field, inputCls, Btn, usd, Seg, TgGlyph, WaGlyph, Skeleton, DropPill } from './ui';
const MODE_SHORT: Record<string, string> = { sales: 'Sales in period', chats: 'Chats in period' };

type Api = <T = any>(path: string, body?: unknown) => Promise<T>;
type M = { visitors: number; forms: number; join_req: number; joined: number; still: number; join_chat: number; chats: number; sold: number; revenue: number; spend: number | null;
  topup_fees?: number; web_sold?: number; web_revenue?: number; earlier?: number; wa_clicks?: number; wa_comm?: number; wa_comm_msg?: number; manual_spend?: number; profit?: number | null; roi?: number | null; bot_info?: number; bot_info_support?: number };
type Ad = M & { ad: string | null; adset: string | null };
type Row = M & { camp: string | null; kind?: 'camp' | 'none' | 'wa'; app?: 'tg' | 'wa'; ads: Ad[] };
type App = 'all' | 'tg' | 'wa';
const APPS: [App, string][] = [['all', 'All apps'], ['tg', 'Telegram'], ['wa', 'WhatsApp']];
type Data = { rows: Row[]; params: string; spend_on: boolean; spend_err: string | null; inr_rate: number; mode?: Mode; wa_ads_on?: boolean };
type Mode = 'sales' | 'chats';
const MODES: [Mode, string][] = [['sales', 'Sales made in this period'], ['chats', 'Chats started in this period']];
type Range = string; // also 'd:YYYY-MM-DD[:YYYY-MM-DD]' (v135)
type Line = 'all' | 'agency' | 'premium' | 'funnel';
const LINES: [Line, string][] = [['all', 'All'], ['agency', 'Agency'], ['premium', 'Premium'], ['funnel', 'Funnel']];

const pct = (a: number, b: number) => (b > 0 ? Math.round((a / b) * 1000) / 10 : null);
const per = (sp: number | null, n: number) => (sp != null && sp > 0 && n > 0 ? sp / n : null);
const inr = (v: number | null, rate: number) => (v == null ? '' : ` · ₹${Math.round(v * rate).toLocaleString()}`);

function Steps({ m, rate, mode = 'chats' }: { m: M; rate: number; mode?: Mode }) {
  // the path a person takes: visit → (channel) → chat → sale, with the % that moved on at each step
  const items: [string, number, string | null][] = [];
  if (m.visitors) items.push(['Visitors', m.visitors, null]);
  if (m.wa_clicks) items.push(['Chat taps', m.wa_clicks, m.visitors ? `${pct(m.wa_clicks, m.visitors)}% of visitors` : null]);
  if (m.wa_comm) items.push(['Community numbers', m.wa_comm, null]);
  if (m.wa_comm) items.push(['Messaged', m.wa_comm_msg || 0, pct(m.wa_comm_msg || 0, m.wa_comm) != null ? `${pct(m.wa_comm_msg || 0, m.wa_comm)}% of numbers` : null]);
  if (m.join_req) items.push(['Join requests', m.join_req, null]);
  if (m.join_req) items.push(['Still in channel', m.still, pct(m.still, m.join_req) != null ? `${pct(m.still, m.join_req)}%` : null]);
  // v139: the bot's info buttons as a filter — saw the price in the bot, then went to support (or not)
  if (m.bot_info) items.push(['Saw pricing in bot', m.bot_info, m.join_req ? `${pct(m.bot_info, m.join_req)}% of joins` : null]);
  if (m.bot_info) items.push(['Went to support', m.bot_info_support || 0, `${pct(m.bot_info_support || 0, m.bot_info)}% of them`]);
  if (m.forms) items.push(['Forms', m.forms, null]);
  items.push(['Chats', m.chats, m.join_req ? (m.join_chat ? `${pct(m.join_chat, m.join_req)}% of joins wrote` : '0% of joins wrote') : null]);
  items.push(['Sold', m.sold + (m.web_sold || 0), mode === 'sales' ? (m.earlier ? `${m.earlier} from chats started earlier` : null) : pct(m.sold, m.chats) != null ? `${pct(m.sold, m.chats)}% of chats` : null]);
  return (
    <div className="grid grid-cols-3 gap-1.5 sm:grid-cols-6">
      {items.map(([l, v, sub]) => (
        <div key={l} className="rounded-[10px] bg-tg-panel2 px-2.5 py-2">
          <p className="text-[11.5px] text-tg-sub">{l}</p>
          <p className="text-[17px] font-bold">{v.toLocaleString()}</p>
          {sub && <p className="text-[11px] text-tg-link">{sub}</p>}
        </div>
      ))}
      {m.spend != null && (
        <div className="col-span-3 grid grid-cols-2 gap-x-3 gap-y-0.5 rounded-xl bg-black/20 px-2.5 py-2 text-[12.5px] sm:col-span-6 sm:grid-cols-4" data-cost>
          <span><span className="text-tg-sub">Spend </span>{usd(m.spend)}</span>
          {m.join_req > 0 && <span><span className="text-tg-sub">Per join </span>{usd(per(m.spend, m.join_req))}{inr(per(m.spend, m.join_req), rate)}</span>}
          <span><span className="text-tg-sub">Per chat </span>{per(m.spend, m.chats) == null ? '—' : usd(per(m.spend, m.chats))}</span>
          <span><span className="text-tg-sub">Per sale </span>{per(m.spend, m.sold) == null ? '—' : usd(per(m.spend, m.sold))}</span>
          {m.revenue > 0 && m.spend > 0 && <span className="text-tg-ok"><span className="text-tg-sub">Return </span>{(m.revenue / m.spend).toFixed(2)}x</span>}
          {m.profit != null && <span className={m.profit >= 0 ? 'text-tg-ok' : 'text-tg-bad'} data-profit><span className="text-tg-sub">Profit </span>{usd(m.profit)}{m.roi != null ? ` · ROI ${m.roi}%` : ''}</span>}
          {!!m.topup_fees && <span><span className="text-tg-sub">Top-up fees </span>{usd(m.topup_fees)}</span>}
          {!!m.manual_spend && <span className="text-tg-sub">incl. {usd(m.manual_spend)} WhatsApp spend typed in Ad spend</span>}
        </div>
      )}
    </div>
  );
}

export function Campaigns({ api, range }: { api: Api; range: Range }) {
  const toast = useToast();
  const [line, setLine] = useState<Line>('all');
  const [mode, setMode] = useState<Mode>('sales');
  const [app, setApp] = useState<App>('all');
  const [d, setD] = useState<Data | null>(null);
  const [open, setOpen] = useState<string | null>(null);
  const [setup, setSetup] = useState(false);
  const [acts, setActs] = useState(''); const [tok, setTok] = useState(''); const [tokSet, setTokSet] = useState(false); const [busy, setBusy] = useState(false);
  const load = useCallback(() => api<Data>(`campaigns?range=${range}&line=${line}&mode=${mode}&app=${app}`).then(setD).catch(e => toast((e as Error).message, 'err')), [api, range, line, mode, app, toast]);
  useEffect(() => { setD(null); void load(); }, [load]);
  useEffect(() => { if (setup) api<{ acts: string; token_set: boolean }>('camp_spend').then(r => { setActs(r.acts); setTokSet(r.token_set); }).catch(() => {}); }, [setup, api]);
  const copy = (x: string) => { try { void navigator.clipboard.writeText(x); toast('Copied'); } catch { /* ignore */ } };

  async function saveSpend() {
    setBusy(true);
    try { await api('camp_spend_save', { camp_acts: acts, ...(tok ? { camp_token: tok } : {}) }); toast('Saved'); setTok(''); setSetup(false); await load(); }
    catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); }
  }

  // v137: WhatsApp ads not running (More → What's running) → their campaign cards fold away under "Not running" (still counted)
  const sleeping = d && d.wa_ads_on === false ? (d.rows || []).filter(r => r.app === 'wa' && r.kind === 'camp') : [];
  const [showSleep, setShowSleep] = useState(false);
  const rows = (d?.rows || []).filter(r => !sleeping.includes(r) || showSleep);
  const tagged = rows.filter(r => r.camp);
  // best seller: highest chat → sale % (at least 3 chats); cheapest sale when spend is known
  const best = tagged.filter(r => r.chats >= 3 && r.sold > 0).sort((a, b) => b.sold / b.chats - a.sold / a.chats)[0]?.camp;
  const cheap = tagged.filter(r => r.sold > 0 && r.spend).sort((a, b) => a.spend! / a.sold - b.spend! / b.sold)[0]?.camp;
  const rate = d?.inr_rate || 90;

  return (
    <div data-campaigns>
      {/* v167: segmented "counted by" + dropdown pills for line and app */}
      <div className="af-seg mb-2.5" data-camp-mode role="tablist">
        {MODES.map(([k, l]) => <button key={k} role="tab" aria-pressed={mode === k} aria-selected={mode === k} data-mode={k} onClick={() => setMode(k)} className="af-press">{MODE_SHORT[k] || l}</button>)}
      </div>
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <DropPill value={line} onChange={setLine} menuTitle="Line" items={LINES.map(([k, l]) => [k, k === 'all' ? 'All lines' : l]) as any} />
        <span data-camp-app className="contents"><DropPill value={app} onChange={setApp} menuTitle="App" items={APPS.map(([k, l]) => [k, l]) as any} /></span>
        <button data-camp-setup onClick={() => setSetup(v => !v)} className="af-pill af-press ml-auto !text-tg-sub"><Settings2 size={15} />Setup</button>
      </div>

      {(setup || (d && !tagged.length)) && (
        <div className="af-card mb-4 p-4 text-[14px]">
          <p className="mb-1 font-semibold">1. Tag every ad</p>
          <p className="mb-2 text-tg-sub">In Ads Manager, open each ad → Tracking → URL parameters, and paste this. Meta fills in the campaign, ad set and ad names by itself.</p>
          <div className="mb-4 flex items-center gap-2 rounded-xl bg-tg-input p-2.5"><code className="min-w-0 flex-1 break-all text-[12.5px]" data-params>{d?.params}</code><button aria-label="Copy" onClick={() => copy(d?.params || '')} className="grid h-9 w-9 shrink-0 place-items-center rounded-lg text-tg-link hover:bg-tg-hover"><Copy size={17} /></button></div>
          <p className="mb-1 font-semibold">2. Spend per campaign (optional)</p>
          <p className="mb-2 text-tg-sub">The ad accounts you run your own ads from. If the account is in a BM added under Ad accounts, its token is used; otherwise paste a token that can read the account’s insights.</p>
          <Field label="Your ad account IDs"><input value={acts} onChange={e => setActs(e.target.value)} className={inputCls} placeholder="act_123…, act_456…" /></Field>
          <Field label="Token" hint={tokSet ? 'A token is saved. Leave empty to keep it.' : 'Optional'}><input value={tok} onChange={e => setTok(e.target.value)} className={inputCls} placeholder={tokSet ? '••••••••' : 'EAA…'} /></Field>
          <Btn busy={busy} onClick={() => void saveSpend()} className="w-full">Save</Btn>
        </div>
      )}
      {setup && <CampPlanner api={api} />}

      {d?.spend_err && <p className="mb-3 rounded-xl bg-tg-orange/15 px-3 py-2 text-[13px] text-tg-orange">Spend from Meta: {d.spend_err}</p>}
      {!d && <div className="p-3"><Skeleton rows={3} h={68} /></div>}
      {d && !rows.length && <p className="af-card px-4 py-8 text-center text-tg-sub">Nothing in this period yet.</p>}

      <div className="grid gap-3">
        {rows.map(r => {
          const k = (r.app || 'tg') + ':' + (r.camp || '');
          const isOpen = open === k;
          return (
            <div key={(r.app || 'tg') + k + (r.kind || '')} data-camp-row={r.camp || r.kind || 'none'} data-camp-app-row={r.app || 'tg'} className="af-card p-3.5">
              <div className="mb-2.5 flex items-start gap-2">
                <Megaphone size={18} className={clsx('mt-0.5 shrink-0', r.camp ? 'text-tg-link' : r.kind === 'wa' ? 'text-[#25D366]' : 'text-tg-sub')} />
                <div className="min-w-0 flex-1">
                  <p className={clsx('flex items-center gap-1.5 break-words text-[15.5px] font-semibold', !r.camp && 'text-tg-sub')}><span className="inline-flex shrink-0" title={r.app === 'wa' ? 'WhatsApp' : 'Telegram'} data-app-badge={r.app || 'tg'}>{r.app === 'wa' ? <WaGlyph size={15} /> : <TgGlyph size={15} />}</span><span className="min-w-0">{r.camp || (r.kind === 'wa' ? 'WhatsApp – no campaign tag' : 'Telegram – no campaign tag')}</span></p>
                  <div className="mt-0.5 flex flex-wrap gap-1.5">
                    {r.camp && r.camp === best && <span className="inline-flex items-center gap-1 rounded-full bg-tg-green/15 px-2 py-0.5 text-[11.5px] font-semibold text-tg-ok"><Trophy size={11} />Best sale rate</span>}
                    {r.camp && r.camp === cheap && <span className="rounded-full bg-tg-acc/15 px-2 py-0.5 text-[11.5px] font-semibold text-tg-link">Cheapest sale</span>}
                    {!r.camp && <span className="text-[12px] text-tg-sub">{r.kind === 'wa' ? 'Chats without a campaign tag (their chat chip says “Direct WhatsApp”, “Old non-tracked ads” or “Community”), WhatsApp sales / top-ups added by hand without a chat' : 'Ads without URL parameters, old visitors, Telegram directly (their chat chip says “Old non-tracked ads”)'}</span>}
                  </div>
                </div>
                <div className="text-right" data-card-rev><p className="text-[17px] font-bold text-tg-ok">{usd(r.revenue + (r.web_revenue || 0))}</p><p className="text-[11.5px] text-tg-sub">{r.sold + (r.web_sold || 0)} sold{r.topup_fees ? ` · ${usd(r.topup_fees)} fees` : ''}</p>{r.profit != null && <p className={clsx('text-[11.5px] font-semibold', r.profit >= 0 ? 'text-tg-ok' : 'text-tg-bad')}>profit {usd(r.profit)}</p>}</div>
              </div>
              <Steps m={r} rate={rate} mode={mode} />
              {mode === 'sales' && !!r.earlier && <p className="mt-1.5 text-[12px] text-tg-sub" data-earlier>sold from chats started earlier: {r.earlier}</p>}
              {r.ads.length > 0 && r.camp && (
                <>
                  <button data-ads-toggle onClick={() => setOpen(isOpen ? null : k)} className="mt-2.5 flex w-full items-center justify-center gap-1 rounded-xl py-2 text-[13.5px] font-medium text-tg-link hover:bg-tg-hover">{isOpen ? 'Hide ads' : `Ads (${r.ads.length})`}<ChevronDown size={16} className={clsx('transition-transform', isOpen && 'rotate-180')} /></button>
                  {isOpen && (
                    <div className="mt-1 grid gap-2" data-ads>
                      {r.ads.map(a => (
                        <div key={a.ad || ''} className="rounded-xl border border-white/[0.06] p-2.5">
                          <div className="mb-2 flex items-start gap-2"><p className="min-w-0 flex-1 break-words text-[14px] font-medium">{a.ad || 'Ad name not set'}{a.adset && <span className="block text-[12px] font-normal text-tg-sub">{a.adset}</span>}</p><span className="text-[14px] font-semibold text-tg-ok">{usd(a.revenue)}</span></div>
                          <Steps m={a} rate={rate} mode={mode} />
                        </div>
                      ))}
                    </div>
                  )}
                </>
              )}
            </div>
          );
        })}
      </div>
      {sleeping.length > 0 && <button data-not-running onClick={() => setShowSleep(v => !v)} className="mt-3 w-full af-card px-4 py-3 text-left text-[13.5px] text-tg-sub hover:bg-tg-hover">{showSleep ? 'Hide' : 'Show'} {sleeping.length} WhatsApp ad campaign{sleeping.length === 1 ? '' : 's'} · Not running ({usd(sleeping.reduce((a, r) => a + r.revenue, 0))} sales, counted in the totals)</button>}
      {d && rows.length > 0 && <p className="mt-3 px-1 text-[12px] leading-relaxed text-tg-sub">{mode === 'sales'
        ? 'Sold, revenue and top-up fees count what was SOLD in this period (same totals as Home), credited to the campaign of the chat it came from, even if that chat started earlier. Website orders count when delivered. Chats count chats started in this period.'
        : 'Chats and sales count people whose chat started in this period, and their sales at any time after.'} Join requests count people who asked to join in this period; “wrote” = later messaged us. Spend comes from Meta for your ad accounts (matched by campaign and ad name).</p>}
    </div>
  );
}

/** Home: the top campaigns of the period (by sales), tap → the Campaigns page. */
export function TopCamps({ api, range, line, onMore }: { api: Api; range: Range; line?: string; onMore: () => void }) {
  const [d, setD] = useState<Data | null>(null);
  const ln = line === 'agency' || line === 'premium' || line === 'funnel' ? line : 'all';
  useEffect(() => { api<Data>(`campaigns?range=${range}&line=${ln}`).then(setD).catch(() => {}); }, [api, range, ln]);
  const rows = (d?.rows || []).filter(r => r.camp).slice(0, 5);
  if (!d) return <Skeleton rows={2} h={56} />; // v160: the section keeps its size while loading
  if (!rows.length) return null;
  return (
    <div data-top-camps>
      <h2 className="mb-3 mt-7 flex items-center justify-between text-[17px] font-semibold">Top campaigns<button onClick={onMore} className="text-[14px] font-medium text-tg-link">See all</button></h2>
      <div className="af-card overflow-hidden">
        {rows.map(r => (
          <button key={(r.app || "tg") + r.camp} onClick={onMore} className="flex w-full items-center gap-3 border-b border-white/[0.04] px-4 py-3 text-left last:border-0 hover:bg-tg-hover">
            <Megaphone size={17} className="shrink-0 text-tg-link" />
            <span className="min-w-0 flex-1">
              <span className="block truncate text-[14.5px] font-medium">{r.camp}</span>
              <span className="block truncate text-[12.5px] text-tg-sub">{[r.join_req ? `${r.join_req} joins` : '', `${r.chats} chats`, `${r.sold} sold`, pct(r.sold, r.chats) != null ? `${pct(r.sold, r.chats)}% sale rate` : '', r.spend ? `${usd(r.spend)} spent` : ''].filter(Boolean).join(' · ')}</span>
            </span>
            <span className="text-[15px] font-bold text-tg-ok">{usd(r.revenue)}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

/* ---------- v131: campaign planner — every name made for you ---------- */
type Plan = { id?: number; kind: string; label: string; campaign: string; adsets: { name: string; ads: string[] }[]; url: string | null; params: string | null; event: string; pixel: string; dest: string; hook: string; country: string; creative: string; audiences: string; n_adsets: number; n_ads: number };
function CopyRow({ label, value }: { label?: string; value: string }) {
  const toast = useToast();
  return (
    <div className="flex items-center gap-2 rounded-lg bg-tg-input px-2.5 py-1.5">
      <span className="min-w-0 flex-1 break-all text-[13px]">{label && <span className="text-tg-sub">{label} </span>}{value}</span>
      <button aria-label="Copy" onClick={() => { try { void navigator.clipboard.writeText(value); toast('Copied'); } catch { /* ignore */ } }} className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-tg-link hover:bg-tg-hover"><Copy size={15} /></button>
    </div>
  );
}
function PlanView({ p }: { p: Plan }) {
  return (
    <div className="grid gap-1.5 text-[13px]" data-plan>
      <p className="text-tg-sub">{p.label} · {p.dest === 'WhatsApp' ? 'Conversion location: WhatsApp' : `Conversion location: Website · optimise for ${p.event} (${p.pixel})`}</p>
      <CopyRow label="Campaign:" value={p.campaign} />
      {p.adsets.map((s, i) => (
        <div key={i} className="ml-2 grid gap-1.5 border-l-2 border-tg-line pl-2">
          <CopyRow label="Ad set:" value={s.name} />
          {s.ads.map(a => <div key={a} className="ml-2"><CopyRow label="Ad:" value={a} /></div>)}
        </div>
      ))}
      {p.url && <CopyRow label="Website URL:" value={p.url} />}
      {p.params && <CopyRow label="URL parameters:" value={p.params} />}
      {p.dest === 'WhatsApp' && <p className="text-[12.5px] text-tg-sub">No URL needed: the ad opens WhatsApp. The system sees which ad (ad ID) each chat came from.</p>}
    </div>
  );
}
function CampPlanner({ api }: { api: Api }) {
  const toast = useToast();
  const [kinds, setKinds] = useState<{ k: string; label: string }[]>([]); const [plans, setPlans] = useState<Plan[]>([]);
  const [f, setF] = useState({ kind: 'wa_premium', hook: 'Hook1', country: 'IN', adsets: '1', ads: '2', creative: 'Reel', audiences: '' });
  const [prev, setPrev] = useState<Plan | null>(null); const [busy, setBusy] = useState(false); const [open, setOpen] = useState<number | null>(null);
  const load = () => api<{ kinds: { k: string; label: string }[]; plans: Plan[] }>('camp_plan_kinds').then(r => { setKinds(r.kinds); setPlans(r.plans); }).catch(() => {});
  useEffect(() => { void load(); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { const t = setTimeout(() => { api<Plan>('camp_plan_preview', f).then(setPrev).catch(() => setPrev(null)); }, 250); return () => clearTimeout(t); }, [f, api]);
  const set = (k: keyof typeof f, v: string) => setF(x => ({ ...x, [k]: v }));
  async function save() {
    setBusy(true);
    try { await api('camp_plan_save', f); toast('Plan saved'); await load(); } catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); }
  }
  async function del(id: number) { if (!confirm('Delete this saved plan?')) return; try { await api('camp_plan_del', { id }); await load(); } catch (e) { toast((e as Error).message, 'err'); } }
  return (
    <div className="af-card mb-4 p-4 text-[14px]" data-planner>
      <p className="mb-1 font-semibold">3. Plan a campaign (names made for you)</p>
      <p className="mb-3 text-tg-sub">Pick the ad type and how many ad sets / ads. Copy each name into Ads Manager, so every chat and sale shows the right campaign and ad.</p>
      <Field label="Ad type"><select data-plan-kind value={f.kind} onChange={e => set('kind', e.target.value)} className={inputCls}>{kinds.map(k => <option key={k.k} value={k.k}>{k.label}</option>)}</select></Field>
      <div className="grid grid-cols-2 gap-x-3 sm:grid-cols-3">
        <Field label="Hook / angle"><input value={f.hook} onChange={e => set('hook', e.target.value)} className={inputCls} placeholder="Hook1" /></Field>
        <Field label="Country"><input value={f.country} onChange={e => set('country', e.target.value)} className={inputCls} placeholder="IN" /></Field>
        <Field label="Creative"><input value={f.creative} onChange={e => set('creative', e.target.value)} className={inputCls} placeholder="Reel" /></Field>
        <Field label="Ad sets"><input data-plan-sets type="number" min={1} max={10} value={f.adsets} onChange={e => set('adsets', e.target.value)} className={inputCls} /></Field>
        <Field label="Ads per ad set"><input data-plan-ads type="number" min={1} max={10} value={f.ads} onChange={e => set('ads', e.target.value)} className={inputCls} /></Field>
        <Field label="Audience per ad set" hint="Optional, comma separated"><input value={f.audiences} onChange={e => set('audiences', e.target.value)} className={inputCls} placeholder="25-45, Broad" /></Field>
      </div>
      {prev && <div className="mb-3 rounded-xl border border-tg-line p-2.5"><PlanView p={prev} /></div>}
      <Btn busy={busy} onClick={() => void save()} className="w-full">Save plan</Btn>
      {plans.length > 0 && (
        <div className="mt-4" data-plans>
          <p className="mb-2 font-semibold">Saved plans</p>
          <div className="grid gap-2">
            {plans.map(p => (
              <div key={p.id} className="rounded-xl bg-tg-input p-2.5">
                <div className="flex items-center gap-2">
                  <button onClick={() => setOpen(open === p.id ? null : p.id!)} className="min-w-0 flex-1 text-left"><b className="block break-all text-[14px]">{p.campaign}</b><span className="text-[12.5px] text-tg-sub">{p.label} · {p.n_adsets} ad set{p.n_adsets > 1 ? 's' : ''} × {p.n_ads} ad{p.n_ads > 1 ? 's' : ''}</span></button>
                  <button onClick={() => void del(p.id!)} className="rounded-lg px-2 py-1 text-[12.5px] text-tg-bad hover:bg-tg-hover">Delete</button>
                </div>
                {open === p.id && <div className="mt-2"><PlanView p={p} /></div>}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
