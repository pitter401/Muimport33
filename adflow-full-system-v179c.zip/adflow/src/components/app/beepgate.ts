'use client';

/** v144: when the in-app sound may play (admin + agent apps). The native push / ring path is not touched by this.
 *  1. Only LIVE events while the app is visible: what arrived while the app was closed or in the background never rings
 *     (the apps reset their baselines on open / resume, and a hidden page never rings).
 *  2. The phone's ringer: normal → sound. Silent / vibrate → sound only when "Ring on silent / vibrate" applies to this
 *     person (global alarm_on AND not switched off for them), else vibrate (vibrate mode) or nothing (silent).
 *     Ringer unknown: the Android app → the same as silent when ring-on-silent is off for this person; a browser → sound. */
export type Ringer = 'normal' | 'vibrate' | 'silent' | null;
export type BeepAct = 'sound' | 'vibrate' | 'none';
export function beepDecision(o: { visible: boolean; ringer: Ringer; ringOnSilent: boolean; native: boolean }): BeepAct {
  if (!o.visible) return 'none';
  if (o.ringer === 'normal') return 'sound';
  if (o.ringer === 'vibrate' || o.ringer === 'silent') return o.ringOnSilent ? 'sound' : o.ringer === 'vibrate' ? 'vibrate' : 'none';
  if (o.native) return o.ringOnSilent ? 'sound' : 'vibrate';
  return 'sound';
}

/** Ring on silent / vibrate for the person using this app (from the server: agent `me.ring_silent`, admin settings). Default ON. */
let ringOnSilent = true;
export function setRingOnSilent(on: boolean | null | undefined) { ringOnSilent = on !== false; }
export const ringOnSilentNow = () => ringOnSilent;

export type GateDeps = { visible: () => boolean; native: () => Promise<boolean>; ringer: () => Promise<Ringer> };
let ringerCache: { v: Ringer; at: number } | null = null;
const realDeps: GateDeps = {
  visible: () => typeof document === 'undefined' || document.visibilityState === 'visible',
  native: async () => { try { const { isNative } = await import('./native'); return await isNative(); } catch { return false; } },
  ringer: async () => {
    if (ringerCache && Date.now() - ringerCache.at < 5000) return ringerCache.v;
    let v: Ringer = null;
    try { const { ringerMode } = await import('./native'); v = await ringerMode(); } catch { v = null; }
    ringerCache = { v, at: Date.now() };
    return v;
  },
};
let deps: GateDeps = realDeps;
/** tests: swap the visible / native / ringer readers */
export function setGateDeps(d: Partial<GateDeps> | null) { deps = d ? { ...realDeps, ...d } : realDeps; ringerCache = null; }

/** What to do for one live event right now. */
export async function beepAction(): Promise<BeepAct> {
  if (!deps.visible()) return 'none';
  const native = await deps.native().catch(() => false);
  const ringer = native ? await deps.ringer().catch(() => null) : null;
  return beepDecision({ visible: deps.visible(), ringer, ringOnSilent, native });
}

/** Baselines for "new since last look": the first load and the first load after open / resume set the baseline and never ring. */
export class LiveCounter {
  private base = -1;
  private rebase = true;
  /** call on open / resume (visible again): the next value is the new baseline */
  reset() { this.rebase = true; }
  /** true = this value is a live increase (ring / banner); false = first look, catch-up, or no increase */
  next(v: number): boolean {
    const grew = !this.rebase && this.base >= 0 && v > this.base;
    this.base = v; this.rebase = false;
    return grew;
  }
  get value() { return this.base; }
  get rebasing() { return this.rebase; }
}

/** Calls `fn` when the app comes back: the page becomes visible again or the Android app resumes. */
export function onResume(fn: () => void): () => void {
  let hidden = typeof document !== 'undefined' && document.visibilityState !== 'visible';
  const vis = () => { if (document.visibilityState === 'visible') { if (hidden) fn(); hidden = false; } else hidden = true; };
  document.addEventListener('visibilitychange', vis);
  let off: (() => void) | null = null, stop = false;
  void (async () => {
    try {
      const { isNative } = await import('./native'); if (!(await isNative())) return;
      const { App } = await import('@capacitor/app');
      const h = await App.addListener('resume', () => fn());
      if (stop) void h.remove(); else off = () => void h.remove();
    } catch { /* old app / browser */ }
  })();
  return () => { stop = true; document.removeEventListener('visibilitychange', vis); off?.(); };
}
