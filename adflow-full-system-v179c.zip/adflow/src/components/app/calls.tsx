'use client';

/* Call list (agent / manager app): people who filled the form but never messaged on Telegram.
   Call or WhatsApp them, then mark what happened. */

import { useCallback, useEffect, useState } from 'react';
import { Phone, MessageCircle } from 'lucide-react';
import clsx from 'clsx';
import { useToast, Avatar, listTime, inputCls, Skeleton } from './ui';
import { openWhatsApp } from './native';

type Api = <T = any>(path: string, b?: unknown) => Promise<T>;
export type CallLead = {
  id: number; name: string | null; phone: string | null; email: string | null; service: string | null; biz: string | null; has_bm: string | null; niche: string | null; budget: string | null;
  theme: string | null; line: string | null; created_at: number; call_state: string | null; call_at: number | null; call_by: string | null; call_note: string | null; wa_text: string | null;
};

export const CALL_LABEL: Record<string, [string, string]> = {
  called: ['✓ Called', 'bg-tg-green/15 text-tg-ok'],
  no_answer: ['No answer', 'bg-tg-orange/15 text-tg-orange'],
  interested: ['Interested', 'bg-tg-acc/20 text-tg-link'],
  converted: ['✓ Converted', 'bg-tg-green/25 text-tg-ok'],
  not_interested: ['Not interested', 'bg-tg-red/15 text-tg-bad'],
};

/** Call / WhatsApp buttons + "what happened" — used in the agent app list and the admin lead sheet. */
export function CallActions({ l, onMark }: { l: { phone: string | null; wa_text: string | null; call_state: string | null; call_note: string | null }; onMark: (state: string, note: string) => Promise<void> }) {
  const toast = useToast();
  const [note, setNote] = useState(l.call_note || '');
  const [busy, setBusy] = useState('');
  const mark = async (st: string) => { setBusy(st); try { await onMark(st, note); } catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(''); } };
  return (
    <div>
      {l.phone && (
        <div className="grid grid-cols-2 gap-2">
          <a href={`tel:+${l.phone.replace(/\D/g, '')}`} className="flex items-center justify-center gap-2 rounded-xl bg-tg-acc py-2.5 font-semibold text-white"><Phone size={17} />Call</a>
          <button onClick={() => { void openWhatsApp(l.phone!, l.wa_text); toast(l.wa_text ? 'Opening WhatsApp · message also copied' : 'Opening WhatsApp'); }} className="flex items-center justify-center gap-2 rounded-xl bg-[#1f8f4e] py-2.5 font-semibold text-white"><MessageCircle size={17} />WhatsApp</button>
        </div>
      )}
      <input value={note} onChange={e => setNote(e.target.value)} placeholder="Note (optional) — e.g. call back after 6 pm" className={clsx(inputCls, 'mt-2 h-10 text-[14px]')} />
      <div className="mt-2 grid grid-cols-3 gap-2 text-[13px] font-semibold">
        {(['called', 'no_answer', 'interested', 'converted', 'not_interested'] as const).map(st => (
          <button key={st} disabled={!!busy} onClick={() => void mark(l.call_state === st ? '' : st)}
            className={clsx('rounded-xl py-2.5', l.call_state === st ? CALL_LABEL[st][1] + ' ring-1 ring-current' : 'bg-tg-input text-tg-text', busy === st && 'opacity-60')}>
            {CALL_LABEL[st][0]}
          </button>
        ))}
      </div>
      {l.call_state && <p className="mt-1.5 text-[12px] text-tg-sub">Tap the marked button again to undo.</p>}
    </div>
  );
}

export function CallsList({ api, onCount }: { api: Api; onCount?: (n: number) => void }) {
  const [rows, setRows] = useState<CallLead[] | null>(null);
  const [open, setOpen] = useState<number | null>(null);
  const [niOpen, setNiOpen] = useState(false);
  const load = useCallback(() => api<{ calls: CallLead[] }>('calls').then(r => { setRows(r.calls); onCount?.(r.calls.filter(c => !c.call_state || c.call_state === 'no_answer').length); }).catch(() => setRows([])), [api, onCount]);
  useEffect(() => { void load(); }, [load]);
  if (!rows) return <div className="p-3"><Skeleton rows={3} h={68} /></div>;
  if (!rows.length) return <div className="p-10 text-center text-tg-sub"><p className="text-[15px] text-tg-text">No one to call </p><p className="mt-1 text-[13.5px]">People who fill the form but don’t message on Telegram in 10 minutes show up here.</p></div>;
  const todo = rows.filter(c => !c.call_state || c.call_state === 'no_answer'), inte = rows.filter(c => c.call_state === 'interested'), done = rows.filter(c => c.call_state === 'called' || c.call_state === 'converted'), ni = rows.filter(c => c.call_state === 'not_interested');
  const Item = (c: CallLead) => {
    const name = c.name || 'Lead #' + c.id;
    return (
      <div key={c.id} className="border-b border-tg-line/60">
        <button onClick={() => setOpen(open === c.id ? null : c.id)} className="flex w-full items-center gap-3 px-3 py-2.5 text-left hover:bg-tg-hover">
          <Avatar name={name} id={c.id} size={46} />
          <span className="min-w-0 flex-1">
            <span className="flex items-center gap-2"><span className="truncate text-[16px] font-medium">{name}</span>{c.biz === 'funnel' && <span className="rounded-full bg-[#a78bfa] px-1.5 py-px text-[10.5px] font-bold text-black">Funnel</span>}</span>
            <span className="block truncate text-[13.5px] text-tg-sub">{[c.phone, c.niche, c.budget].filter(Boolean).join(' · ')}</span>
          </span>
          <span className="flex shrink-0 flex-col items-end gap-1 text-[12px]">
            {c.call_state ? <span className={clsx('rounded-full px-2 py-0.5', CALL_LABEL[c.call_state]?.[1])}>{CALL_LABEL[c.call_state]?.[0]}</span> : <span className="rounded-full bg-tg-acc/15 px-2 py-0.5 text-tg-link">To call</span>}
            <span className="text-tg-sub">{listTime(c.created_at)}</span>
          </span>
        </button>
        {open === c.id && (
          <div className="bg-tg-bg/40 px-3 pb-3 pt-1">
            <div className="mb-2 grid grid-cols-2 gap-x-3 text-[13px]">
              {[['Wants', c.service === 'funnel' ? 'Funnel' : 'Ad account'], ['Has BM', c.has_bm], ['Advertises', c.niche], ['Budget', c.budget], ['Email', c.email], ['Filled form', new Date(c.created_at).toLocaleString()]]
                .filter(x => x[1]).map(([k, v]) => <p key={k} className="truncate py-0.5"><span className="text-tg-sub">{k}: </span>{v}</p>)}
            </div>
            {c.call_note && c.call_by && <p className="mb-2 text-[12.5px] text-tg-sub">Last: {CALL_LABEL[c.call_state || '']?.[0] || ''} by {c.call_by}{c.call_at ? ' · ' + listTime(c.call_at) : ''}</p>}
            <CallActions l={c} onMark={async (state, note) => { await api('call_mark', { lead_id: c.id, state, note }); await load(); }} />
          </div>
        )}
      </div>
    );
  };
  return (
    <div>
      <p className="px-3 py-2 text-[12.5px] text-tg-sub">Filled the form but didn’t message on Telegram. Call them, then mark what happened.</p>
      {todo.length > 0 && <p className="px-3 pb-1 pt-2 text-[13px] font-semibold text-tg-link">To call · {todo.length}</p>}
      {todo.map(Item)}
      {inte.length > 0 && <p className="px-3 pb-1 pt-4 text-[13px] font-semibold text-tg-link">Interested · {inte.length} <span className="font-normal text-tg-sub">— check later: Converted, or call again</span></p>}
      {inte.map(Item)}
      {done.length > 0 && <p className="px-3 pb-1 pt-4 text-[13px] font-semibold text-tg-sub">Done · {done.length}</p>}
      {done.map(Item)}
      {/* Not interested: tucked away at the bottom, closed by default */}
      {ni.length > 0 && (
        <>
          <button onClick={() => setNiOpen(!niOpen)} aria-expanded={niOpen} className="flex w-full items-center gap-2 px-3 pb-2 pt-5 text-left text-[13px] font-semibold text-tg-sub">
            <span className={clsx('inline-block transition-transform', niOpen && 'rotate-90')}>▸</span> Not interested · {ni.length}
          </button>
          {niOpen && ni.map(Item)}
        </>
      )}
    </div>
  );
}

type HotLead = CallLead & { last_in_at: number | null; last_text: string | null; tg_username: string | null; agent_name: string | null; mine: boolean };
const ago = (t: number | null) => { if (!t) return ''; const h = (Date.now() - t) / 3600000; return h < 24 ? `${Math.max(1, Math.round(h))} h` : `${Math.round(h / 24)} day${Math.round(h / 24) > 1 ? 's' : ''}`; };
/** Hot leads (agent / manager app): they chatted on Telegram, then went quiet → give them a call. */
export function HotList({ api, onCount, onOpenChat }: { api: Api; onCount?: (n: number) => void; onOpenChat: (id: number) => void }) {
  const [rows, setRows] = useState<HotLead[] | null>(null);
  const [open, setOpen] = useState<number | null>(null);
  const load = useCallback(() => api<{ hot: HotLead[] }>('hot').then(r => { setRows(r.hot); onCount?.(r.hot.filter(c => !c.call_state).length); }).catch(() => setRows([])), [api, onCount]);
  useEffect(() => { void load(); }, [load]);
  if (!rows) return <div className="p-3"><Skeleton rows={3} h={68} /></div>;
  if (!rows.length) return <div className="p-10 text-center text-tg-sub"><p className="text-[15px] text-tg-text">No hot leads right now</p><p className="mt-1 text-[13.5px]">Customers who chatted with you and then went quiet for 6+ hours show up here, so you can call them.</p></div>;
  return (
    <div>
      <p className="px-3 py-2 text-[12.5px] text-tg-sub">They talked with us on Telegram, then stopped replying. Call them, then mark what happened. Converted / Not interested leave the list; they also leave when they write again.</p>
      {rows.map(c => {
        const name = c.name || 'Lead #' + c.id;
        return (
          <div key={c.id} className="border-b border-tg-line/60">
            <button onClick={() => setOpen(open === c.id ? null : c.id)} className="flex w-full items-center gap-3 px-3 py-2.5 text-left hover:bg-tg-hover">
              <Avatar name={name} id={c.id} size={46} />
              <span className="min-w-0 flex-1">
                <span className="flex items-center gap-2"><span className="truncate text-[16px] font-medium">{name}</span>{c.biz === 'funnel' && <span className="rounded-full bg-[#a78bfa] px-1.5 py-px text-[10.5px] font-bold text-black">Funnel</span>}{c.agent_name && <span className="truncate text-[12px] text-tg-sub">· {c.agent_name}</span>}</span>
                <span className="block truncate text-[13.5px] text-tg-sub">{c.last_text ? `They said: ${c.last_text}` : [c.phone, c.niche].filter(Boolean).join(' · ')}</span>
              </span>
              <span className="flex shrink-0 flex-col items-end gap-1 text-[12px]">
                {c.call_state ? <span className={clsx('rounded-full px-2 py-0.5', CALL_LABEL[c.call_state]?.[1])}>{CALL_LABEL[c.call_state]?.[0]}</span> : <span className="rounded-full bg-[#F5A623]/15 px-2 py-0.5 text-[#F5A623]">Call</span>}
                <span className="text-tg-sub">quiet {ago(c.last_in_at)}</span>
              </span>
            </button>
            {open === c.id && (
              <div className="bg-tg-bg/40 px-3 pb-3 pt-1">
                <div className="mb-2 grid grid-cols-2 gap-x-3 text-[13px]">
                  {[['Phone', c.phone || 'not given — message them'], ['Telegram', c.tg_username ? '@' + c.tg_username : ''], ['Advertises', c.niche], ['Budget', c.budget], ['Last reply', c.last_in_at ? new Date(c.last_in_at).toLocaleString() : '']]
                    .filter(x => x[1]).map(([k, v]) => <p key={k} className="truncate py-0.5"><span className="text-tg-sub">{k}: </span>{v}</p>)}
                </div>
                {c.call_note && c.call_by && <p className="mb-2 text-[12.5px] text-tg-sub">Last: {CALL_LABEL[c.call_state || '']?.[0] || ''} by {c.call_by}{c.call_at ? ' · ' + listTime(c.call_at) : ''} — “{c.call_note}”</p>}
                {c.mine && <button onClick={() => onOpenChat(c.id)} className="mb-2 w-full rounded-xl bg-tg-input py-2.5 text-[14px] font-semibold">Open chat</button>}
                <CallActions l={c} onMark={async (state, note) => { await api('call_mark', { lead_id: c.id, state, note }); await load(); }} />
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
