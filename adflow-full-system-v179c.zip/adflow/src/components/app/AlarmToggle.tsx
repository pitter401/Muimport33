'use client';

import { useEffect, useState } from 'react';
import { BellRing, BellOff } from 'lucide-react';
import clsx from 'clsx';
import { alarmState, setAlarm, testAlarm, type AlarmState } from './native';
import { useToast } from './ui';

/** Small bell above the chats: new-lead sound even when the phone is on silent / vibrate (app with the new push receiver only). */
export function AlarmToggle({ className }: { className?: string }) {
  const [st, setSt] = useState<AlarmState | null>(null);
  const toast = useToast();
  useEffect(() => { void alarmState().then(setSt); }, []);
  if (!st) return null;
  async function flip() {
    const on = !st!.on;
    await setAlarm(on);
    const fresh = await alarmState();
    setSt(fresh || { ...st!, on });
    if (on) {
      void testAlarm();
      toast(fresh && !fresh.volume ? 'New-lead sound ON — but your ALARM volume is 0. Turn it up in the phone volume settings.' : 'New-lead sound ON, even on silent / vibrate (uses the alarm volume).');
    } else toast('New-lead sound on silent: OFF. On silent / vibrate the phone stays quiet.');
  }
  return (
    <button onClick={() => void flip()} aria-label={st.on ? 'New-lead sound on silent: on' : 'New-lead sound on silent: off'} title="New-lead sound even on silent"
      className={clsx('grid h-10 w-10 place-items-center rounded-full hover:bg-tg-hover', st.on ? 'text-tg-link' : 'text-tg-sub', className)}>
      {st.on ? <BellRing size={21} /> : <BellOff size={21} />}
    </button>
  );
}
