'use client';

// v140: Settings → Phone notifications → "Ring for each person": the admin turns "ring on silent / vibrate" off (or back on)
// for the manager, each agent and the admin phones. Default ON for everyone. It can only turn the ring off — the global
// switch above still applies. The normal notification with the team sound still comes; only the ring on silent is skipped.
import { useEffect, useState } from 'react';
import { Toggle, useToast } from './ui';

type Api = <T = any>(path: string, body?: unknown) => Promise<T>;
type P = { key: string; name: string; role: 'manager' | 'agent' | 'admin'; ring: boolean; phones: number };

export function RingPeople({ api, globalOn }: { api: Api; globalOn: boolean }) {
  const toast = useToast();
  const [rows, setRows] = useState<P[] | null>(null);
  const [busy, setBusy] = useState('');
  useEffect(() => { api<{ people: P[] }>('ring_people').then(r => setRows(r.people)).catch(() => setRows([])); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  async function flip(p: P, ring: boolean) {
    setBusy(p.key);
    try { const r = await api<{ people: P[] }>('ring_set', { key: p.key, ring }); setRows(r.people); toast(`${p.name}: ring on silent ${ring ? 'ON' : 'OFF'}`); }
    catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(''); }
  }
  if (!rows) return null;
  return (
    <div data-ring-people className="mb-3 rounded-xl bg-tg-input px-4 py-3">
      <p className="text-[14px] font-medium">Ring for each person</p>
      <p className="mb-2 text-[12.5px] text-tg-sub">{globalOn ? 'OFF = that phone does not ring on silent / vibrate. Notifications with the team sound still come.' : 'The switch above is OFF, so no phone rings on silent / vibrate. These only matter while it is ON.'}</p>
      <div className={'divide-y divide-tg-line ' + (globalOn ? '' : 'opacity-50')}>
        {rows.map(p => (
          <div key={p.key} data-ring-row={p.key} className="flex items-center justify-between gap-3 py-2">
            <span className="min-w-0">
              <span className="block truncate text-[14px]">{p.name}{p.role === 'manager' ? <span className="ml-1.5 rounded-full bg-tg-acc/15 px-2 py-0.5 text-[11px] text-tg-link">manager</span> : null}</span>
              <span className="text-[12px] text-tg-sub">{p.phones ? `${p.phones} phone${p.phones === 1 ? '' : 's'}` : 'no phone yet'}{p.ring ? '' : ' · ring off'}</span>
            </span>
            <Toggle on={p.ring} onChange={v => { if (busy !== p.key) void flip(p, v); }} />
          </div>
        ))}
      </div>
    </div>
  );
}
