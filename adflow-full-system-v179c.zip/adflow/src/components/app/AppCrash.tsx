'use client';
/* v179: the app page crashed (e.g. a part of the app could not load while the phone switched Wi-Fi → mobile data).
 * Instead of Next's bare "Application error" screen: report the reason to the server log ([reel-diag] line, what=app-error),
 * wait until the phone is online, and reload by itself (at most 2 times a minute; after that a Reload button). */
import { useEffect, useState } from 'react';

const KEY = 'af_crash_reloads';
export function AppCrash({ error, reset }: { error: Error & { digest?: string }; reset?: () => void }) {
  const [manual, setManual] = useState(false);
  useEffect(() => {
    const path = location.pathname;
    const api = path.startsWith('/admin') ? '/api/admin/reel/view' : path.startsWith('/agent') ? '/api/agent/reel' : null;
    const msg = `${error?.name || 'Error'}: ${String(error?.message || '').slice(0, 220)} digest=${error?.digest || ''} path=${path} online=${navigator.onLine}`;
    if (api) void fetch(`${api}/diag`, { method: 'POST', credentials: 'same-origin', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ what: 'app-error', info: msg }) }).catch(() => {});
    let list: number[] = [];
    try { list = (JSON.parse(sessionStorage.getItem(KEY) || '[]') as number[]).filter(t => Date.now() - t < 60000); } catch { /* */ }
    if (list.length >= 2) { setManual(true); return; }
    let done = false;
    const go = () => { if (done) return; done = true; try { sessionStorage.setItem(KEY, JSON.stringify([...list, Date.now()])); } catch { /* */ } location.reload(); };
    const t1 = setTimeout(() => { if (navigator.onLine) go(); }, 900);
    const t2 = setTimeout(go, 10000); // offline for 10 s → try anyway
    const on = () => setTimeout(go, 600);
    window.addEventListener('online', on);
    return () => { clearTimeout(t1); clearTimeout(t2); window.removeEventListener('online', on); };
  }, [error]);
  return (
    <div style={{ position: 'fixed', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 18, background: '#0b0b12', color: '#e9e9f2', fontFamily: 'system-ui, sans-serif', padding: 24, textAlign: 'center' }} data-app-crash>
      <div style={{ fontSize: 17, fontWeight: 600 }}>{manual ? 'Connection problem' : 'Reconnecting…'}</div>
      <div style={{ fontSize: 14, opacity: .65, maxWidth: 300 }}>{manual ? 'The app could not load. Check the internet and reload.' : 'One moment, the app is reloading.'}</div>
      {manual && <button type="button" onClick={() => { try { sessionStorage.removeItem(KEY); } catch { /* */ } if (reset) reset(); location.reload(); }}
        style={{ marginTop: 6, padding: '12px 26px', borderRadius: 999, border: 0, background: '#7c5cff', color: '#fff', fontSize: 15, fontWeight: 600 }}>Reload</button>}
    </div>
  );
}
