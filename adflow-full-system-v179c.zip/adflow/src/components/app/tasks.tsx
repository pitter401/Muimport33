'use client';

import { useCallback, useEffect, useState } from 'react';
import { Copy, Globe, MessageSquareText, Inbox } from 'lucide-react';
import clsx from 'clsx';
import { makeApi, useToast, Sheet, Field, inputCls, Btn, Seg, usd, useInterval, listTime, noEmoji, Skeleton } from './ui';

type Api = ReturnType<typeof makeApi>;
export type Task = {
  id: number; kind: string; source: string; title: string; summary: string; who: string; status: string; note: string | null; result: string | null;
  created_at: number; done_at: number | null; done_by: string | null; lead_id: number | null; order_id: number | null; topup_id: number | null;
  bm_id: string | null; act_id: string | null; qty: number | null; amount: number | null; agent: string | null;
  order?: any; topup?: any; customer?: { id: number; email: string; name: string; phone: string } | null; lead?: { id: number; name: string; phone: string } | null;
  pay?: { method: string | null; status: string; inr: number | null; utr: string | null; currency: string | null } | null;
};

export const STATUS_LABEL: Record<string, [string, string]> = {
  new: ['Not paid', 'bg-white/10 text-tg-sub'], pending_payment: ['Waiting for crypto', 'bg-tg-orange/15 text-tg-orange'],
  awaiting_inr: ['Waiting for INR', 'bg-tg-orange/15 text-tg-orange'], inr_review: ['INR to check', 'bg-tg-orange/20 text-tg-orange'],
  paid: ['Paid · to deliver', 'bg-tg-acc/20 text-tg-link'], delivered: ['Delivered', 'bg-tg-green/15 text-tg-ok'], done: ['Done', 'bg-tg-green/15 text-tg-ok'],
  cancelled: ['Cancelled', 'bg-tg-red/15 text-tg-bad'], open: ['Open', 'bg-tg-acc/20 text-tg-link'],
};
export function StatusChip({ s }: { s: string }) {
  const [l, c] = STATUS_LABEL[s] || [s, 'bg-white/10 text-tg-sub'];
  return <span className={clsx('shrink-0 rounded-full px-2.5 py-1 text-[12px] font-semibold', c)}>{l}</span>;
}

function copy(t: string, toast: (m: string) => void) { try { void navigator.clipboard.writeText(t); toast('Copied'); } catch { /* ignore */ } }

/** Tasks for the manager (agent app) and admin: website orders to deliver, INR to confirm, requests forwarded by agents. */
export function TasksList({ api, onOpenChat, dark = true }: { api: Api; onOpenChat?: (leadId: number) => void; dark?: boolean }) {
  const toast = useToast();
  const [st, setSt] = useState<'open' | 'done'>('open');
  const [tasks, setTasks] = useState<Task[] | null>(null);
  const [act, setAct] = useState<Task | null>(null);
  const load = useCallback(async () => { try { const r = await api<{ tasks: Task[] }>('tasks?status=' + st); setTasks(r.tasks); } catch (e) { toast((e as Error).message, 'err'); } }, [api, st, toast]);
  useEffect(() => { setTasks(null); void load(); }, [load]);
  useInterval(() => void load(), 10000);
  void dark;
  return (
    <div>
      <div className="mb-3"><Seg value={st} onChange={setSt} items={[['open', 'To do'], ['done', 'Done']]} /></div>
      {!tasks ? <div className="p-3"><Skeleton rows={3} h={68} /></div>
        : !tasks.length ? (
          <div className="py-14 text-center text-tg-sub"><Inbox className="mx-auto mb-3 opacity-60" size={34} /><p className="text-[14.5px]">{st === 'open' ? 'Nothing to do right now.' : 'No finished tasks yet.'}</p></div>
        ) : (
          <div className="grid gap-2.5">
            {tasks.map(t => (
              <button key={t.id} onClick={() => setAct(t)} className="w-full af-card p-4 text-left hover:bg-tg-hover">
                <div className="flex items-start gap-3">
                  <span className={clsx('grid h-10 w-10 shrink-0 place-items-center rounded-full', t.source === 'web' ? 'bg-[#7BC862]/15 text-tg-ok' : 'bg-tg-acc/15 text-tg-link')}>{t.source === 'web' ? <Globe size={19} /> : <MessageSquareText size={19} />}</span>
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center gap-2"><span className="min-w-0 flex-1 truncate text-[15.5px] font-semibold">{t.title} <span className="font-normal text-tg-sub">#{t.id}</span></span><span className="shrink-0 text-[12px] text-tg-sub">{listTime(t.done_at || t.created_at)}</span></span>
                    <span className="mt-0.5 block text-[14px] text-tg-text">{noEmoji(t.summary) || '—'}</span>
                    {t.who && <span className="mt-0.5 block truncate text-[13px] text-tg-sub">{t.who}</span>}
                    <span className="mt-2 flex flex-wrap items-center gap-1.5">
                      {t.pay && <StatusChip s={t.pay.status} />}
                      {t.status === 'done' && <StatusChip s="done" />}
                      {t.note && t.status === 'open' && <span className="text-[12.5px] text-tg-orange">{noEmoji(t.note)}</span>}
                      {t.result && t.status === 'done' && <span className="truncate text-[12.5px] text-tg-sub">{t.result}</span>}
                    </span>
                  </span>
                </div>
              </button>
            ))}
          </div>
        )}
      <TaskSheet api={api} t={act} onClose={() => setAct(null)} onDone={() => { setAct(null); void load(); }} onOpenChat={onOpenChat} />
    </div>
  );
}

function TaskSheet({ api, t, onClose, onDone, onOpenChat }: { api: Api; t: Task | null; onClose: () => void; onDone: () => void; onOpenChat?: (id: number) => void }) {
  const toast = useToast();
  const [accounts, setAccounts] = useState(''); const [note, setNote] = useState(''); const [busy, setBusy] = useState('');
  const [stype, setStype] = useState(''); const [noComm, setNoComm] = useState(false); // v156: sale type check
  useEffect(() => { setAccounts(''); setNote(''); setNoComm(false); setStype(/Premium ad account/.test(t?.note || '') ? 'premium' : 'normal'); }, [t?.id]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!t) return <Sheet open={false} onClose={onClose}>{null}</Sheet>;
  const item = t.order || t.topup;
  const type = t.topup_id ? 'topup' : 'order';
  const itemId = t.order_id || t.topup_id;
  const needPay = !!item && ['awaiting_inr', 'inr_review', 'new', 'pending_payment'].includes(item.status);
  const isAccount = (t.order && t.order.kind === 'account') || (!item && t.kind === 'account');
  const isFunnelOrder = t.order && t.order.kind === 'funnel';
  async function call(what: string, body: object, ok: string) {
    setBusy(what);
    try { await api(what, body); toast(ok); onDone(); } catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(''); }
  }
  const rows: [string, React.ReactNode][] = [];
  if (t.order) {
    rows.push(['Order', t.order.code], ['Product', t.order.kind === 'funnel' ? 'Landing + funnel' : `${t.order.full ? 'FULL ACCESS · ' : ''}${t.order.qty} ad account${t.order.qty > 1 ? 's' : ''}`]);
    if (t.order.bm_id) rows.push(['Business Manager ID', <CopyVal key="bm" v={t.order.bm_id} />]);
    rows.push(['Amount', usd(t.order.amount)]);
  } else if (t.topup) {
    rows.push(['Top-up', t.topup.code], ['Ad account', <CopyVal key="a" v={'act_' + t.topup.act_id} />], ['Add to account', <b key="x">{usd(t.topup.amount)}</b>], ['Client paid', `${usd(t.topup.total)} (fee ${usd(t.topup.fee)})`]);
  } else {
    if (t.bm_id) rows.push(['Business Manager ID', <CopyVal key="bm" v={t.bm_id} />]);
    if (t.qty) rows.push(['Accounts', String(t.qty)]);
    if (t.act_id) rows.push(['Ad account', <CopyVal key="a" v={'act_' + t.act_id} />]);
    if (t.amount) rows.push(['Top-up amount', usd(t.amount)]);
    if (t.agent) rows.push(['From agent', t.agent]);
  }
  if (t.customer) { rows.push(['Customer', t.customer.name || '—'], ['Email', <CopyVal key="e" v={t.customer.email} />]); if (t.customer.phone) rows.push(['Phone', <CopyVal key="p" v={t.customer.phone} />]); }
  if (t.lead) rows.push(['Client', `${t.lead.name}${t.lead.phone ? ' · ' + t.lead.phone : ''}`]);
  if (t.pay?.method) rows.push(['Payment', t.pay.method === 'inr' ? `INR ₹${t.pay.inr ?? '—'}${t.pay.utr ? ' · UTR ' + t.pay.utr : ''}` : `Crypto${t.pay.currency ? ' · ' + t.pay.currency.toUpperCase() : ''}`]);
  if (t.note) rows.push(['Note', noEmoji(t.note)]);
  if (t.result) rows.push(['Result', t.result]);

  return (
    <Sheet open onClose={onClose} title={`${t.title} #${t.id}`}>
      {item && <div className="mb-3"><StatusChip s={item.status} /></div>}
      <div className="mb-4 divide-y divide-white/5 rounded-xl bg-tg-input px-4">
        {rows.map(([k, v], i) => <div key={i} className="flex items-start justify-between gap-4 py-2.5 text-[14px]"><span className="shrink-0 text-tg-sub">{k}</span><span className="min-w-0 break-words text-right">{v}</span></div>)}
      </div>
      {t.lead && onOpenChat && <Btn kind="ghost" className="mb-3 w-full" onClick={() => { onClose(); onOpenChat(t.lead!.id); }}>Open chat</Btn>}

      {t.status === 'open' && t.kind === 'sale_check' && (
        <>
          <p className="mb-3 rounded-xl bg-tg-orange/10 px-3 py-2 text-[13px] leading-relaxed text-tg-orange">The agent sold the other account type for this chat. Check what was really given, then approve. Nothing is in the records (sale, commission, Meta Purchase) until you approve.</p>
          <Field label="Record it as"><Seg value={stype} onChange={setStype} items={[['premium', 'Premium ad account'], ['normal', 'Normal ($25) account']]} /></Field>
          <button type="button" onClick={() => setNoComm(v => !v)} className="mb-3 flex w-full items-center justify-between rounded-xl bg-tg-input px-4 py-3 text-left text-[14px]"><span>No commission for the agent</span><span className={noComm ? 'font-semibold text-tg-orange' : 'text-tg-sub'}>{noComm ? 'ON' : 'OFF'}</span></button>
          <Btn kind="green" className="w-full" busy={busy === 'task_done'} onClick={() => void call('task_done', { id: t.id, type: stype, no_comm: noComm ? 1 : 0 }, 'Approved · sale recorded')}>Approve · record as {stype === 'premium' ? 'Premium' : 'Normal'}{noComm ? ' · no commission' : ''}</Btn>
          <Btn kind="danger" className="mt-2 w-full" busy={busy === 'task_done'} onClick={() => { if (confirm('Reject? The sale is NOT recorded.')) void call('task_done', { id: t.id, reject: 1 }, 'Rejected'); }}>Reject (don’t record)</Btn>
        </>
      )}
      {t.status === 'open' && t.kind !== 'sale_check' && (
        <>
          {needPay && item.status === 'inr_review' && (
            <div className="mb-3 rounded-xl border border-tg-orange/30 bg-tg-orange/10 p-3 text-[13.5px] text-tg-orange">Check your bank / UPI app for ₹{item.inr_amount} with UTR <b>{item.utr}</b>. If you received it, tap “Mark as paid”.</div>
          )}
          {needPay && (
            <div className="mb-4 grid grid-cols-2 gap-2">
              <Btn kind="green" busy={busy === 'mark_paid'} onClick={() => void call('mark_paid', { type, id: itemId }, 'Marked as paid')}>Mark as paid</Btn>
              <Btn kind="danger" busy={busy === 'cancel_item'} onClick={() => { if (confirm('Cancel this ' + type + '?')) void call('cancel_item', { type, id: itemId }, 'Cancelled'); }}>Cancel</Btn>
            </div>
          )}
          {!needPay && (
            <>
              {isAccount && (
                <Field label={`Ad account ID${(t.order?.qty || t.qty || 1) > 1 ? 's (one per line)' : ''} you shared`} hint="The customer gets these by email and Telegram. Numbers only is fine — act_ is added for you.">
                  <textarea className={inputCls} rows={Math.min(5, Math.max(2, t.order?.qty || t.qty || 1))} placeholder="1234567890123456" value={accounts} onChange={e => setAccounts(e.target.value)} />
                </Field>
              )}
              <Field label={t.topup ? 'Note for the customer (optional)' : isFunnelOrder ? 'Message for the customer (optional)' : 'Note (optional)'}>
                <input className={inputCls} value={note} onChange={e => setNote(e.target.value)} placeholder={t.topup ? 'Added, check Ads Manager' : ''} />
              </Field>
              <Btn kind="green" className="w-full" busy={busy === 'task_done'} disabled={!!isAccount && !accounts.trim()}
                onClick={() => void call('task_done', { id: t.id, accounts, note }, t.order ? 'Delivered — customer notified' : t.topup ? 'Top-up done — customer notified' : 'Done — agent notified')}>
                {t.order ? (isFunnelOrder ? 'Start setup & notify customer' : 'Deliver & notify customer') : t.topup ? 'Top-up added · notify customer' : 'Mark done'}
              </Btn>
              {t.order && <p className="mt-2 text-[12px] text-tg-sub">Sends email + Telegram message to the customer and the Purchase event to Meta.</p>}
            </>
          )}
        </>
      )}
    </Sheet>
  );
}

function CopyVal({ v }: { v: string }) {
  const toast = useToast();
  return <button onClick={() => copy(v, toast)} className="inline-flex items-center gap-1.5 font-medium text-tg-link">{v}<Copy size={13} /></button>;
}

type LeadAcct = { act_id: string; bm_id: string | null; source: string; created_at: number; topped: number; last_topup: number | null };
const shortDate = (t: number) => new Date(t).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
/** Pick one of this client's ad accounts (delivered by the manager / topped up before) or type another one. */
export function AccountPicker({ api, leadId, open, value, onChange }: { api: Api; leadId: number | null; open: boolean; value: string; onChange: (v: string) => void }) {
  const [list, setList] = useState<LeadAcct[] | null>(null);
  const [other, setOther] = useState(false);
  useEffect(() => {
    if (!open || !leadId) return;
    setList(null); setOther(false);
    api<{ accounts: LeadAcct[] }>('lead_accounts?lead_id=' + leadId).then(r => { setList(r.accounts); if (r.accounts.length === 1) onChange(r.accounts[0].act_id); else if (!r.accounts.length) setOther(true); }).catch(() => { setList([]); setOther(true); });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, leadId, api]);
  const clean = value.replace(/^act_/i, '').replace(/\D/g, '');
  return (
    <Field label={list?.length ? `Which ad account? (${list.length} with this client)` : 'Ad account ID'}>
      {!!list?.length && (
        <div className="mb-2 space-y-1.5">
          {list.map(a => (
            <button key={a.act_id} type="button" onClick={() => { setOther(false); onChange(a.act_id); }}
              className={clsx('flex w-full items-center gap-3 rounded-xl border-2 px-3.5 py-2.5 text-left', !other && clean === a.act_id ? 'border-tg-acc bg-tg-acc/10' : 'border-transparent bg-tg-input')}>
              <span className={clsx('grid h-5 w-5 shrink-0 place-items-center rounded-full border-2', !other && clean === a.act_id ? 'border-tg-acc bg-tg-acc' : 'border-tg-sub')}>{!other && clean === a.act_id && <span className="h-2 w-2 rounded-full bg-white" />}</span>
              <span className="min-w-0 flex-1">
                <span className="block font-mono text-[14px]">act_{a.act_id}</span>
                <span className="block text-[12px] text-tg-sub">{a.source === 'manager' ? 'Given' : 'Added'} {shortDate(a.created_at)}{a.topped > 0 ? ` · topped up ${usd(a.topped)}` : ''}{a.last_topup ? ` · last ${shortDate(a.last_topup)}` : ''}</span>
              </span>
            </button>
          ))}
          <button type="button" onClick={() => { setOther(true); onChange(''); }} className={clsx('w-full rounded-xl border-2 px-3.5 py-2 text-left text-[13.5px]', other ? 'border-tg-acc bg-tg-acc/10' : 'border-transparent bg-tg-input text-tg-sub')}>+ Another account ID</button>
        </div>
      )}
      {(other || !list) && <input className={inputCls} inputMode="numeric" placeholder="act_123456789" value={value} onChange={e => onChange(e.target.value)} />}
    </Field>
  );
}

/** Agent → manager: account / top-up / funnel / other request for this chat. */
export function ForwardSheet({ open, onClose, api, leadId, onDone }: { open: boolean; onClose: () => void; api: Api; leadId: number | null; onDone: () => void }) {
  const toast = useToast();
  const [kind, setKind] = useState<'account' | 'topup' | 'funnel' | 'other'>('account');
  const [bm, setBm] = useState(''); const [qty, setQty] = useState(1); const [act, setAct] = useState(''); const [amt, setAmt] = useState(''); const [note, setNote] = useState(''); const [busy, setBusy] = useState(false);
  useEffect(() => { if (open) { setKind('account'); setBm(''); setQty(1); setAct(''); setAmt(''); setNote(''); } }, [open]);
  async function go() {
    if (!leadId) return;
    setBusy(true);
    try { await api('forward', { lead_id: leadId, kind, bm_id: bm, qty, act_id: act, amount: amt, note }); toast('Sent to manager'); onClose(); onDone(); }
    catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); }
  }
  const ok = kind === 'account' ? bm.replace(/\D/g, '').length >= 8 : kind === 'topup' ? act.replace(/\D/g, '').length >= 6 && Number(amt) > 0 : kind === 'other' ? !!note.trim() : true;
  return (
    <Sheet open={open} onClose={onClose} title="Send to manager">
      <div className="mb-4 grid grid-cols-2 gap-2">
        {([['account', 'Ad account'], ['topup', 'Top-up'], ['funnel', 'Funnel'], ['other', 'Other']] as const).map(([v, l]) => (
          <button key={v} onClick={() => setKind(v)} className={clsx('rounded-xl border-2 px-3 py-2.5 text-[14.5px] font-medium', kind === v ? 'border-tg-acc bg-tg-acc/10' : 'border-transparent bg-tg-input')}>{l}</button>
        ))}
      </div>
      {kind === 'account' && (
        <>
          <Field label="Client’s Business Manager ID"><input className={inputCls} inputMode="numeric" placeholder="123456789012345" value={bm} onChange={e => setBm(e.target.value.replace(/\D/g, ''))} /></Field>
          <Field label="How many accounts">
            <div className="flex items-center gap-3"><Btn kind="ghost" onClick={() => setQty(q => Math.max(1, q - 1))}>−</Btn><span className="w-10 text-center text-[20px] font-semibold">{qty}</span><Btn kind="ghost" onClick={() => setQty(q => Math.min(50, q + 1))}>+</Btn></div>
          </Field>
        </>
      )}
      {kind === 'topup' && (
        <>
          <AccountPicker api={api} leadId={leadId} open={open && kind === 'topup'} value={act} onChange={setAct} />
          <Field label="Amount to add (USD)"><input className={inputCls} type="number" inputMode="decimal" value={amt} onChange={e => setAmt(e.target.value)} /></Field>
        </>
      )}
      <Field label={kind === 'other' ? 'What should the manager do?' : 'Note (optional)'}>
        <textarea className={inputCls} rows={2} value={note} onChange={e => setNote(e.target.value)} placeholder={kind === 'funnel' ? 'Niche, budget, anything the client said' : kind === 'other' ? 'Describe the request' : 'Paid via USDT, etc.'} />
      </Field>
      <p className="mb-3 text-[12.5px] text-tg-sub">The manager gets an alert. When they finish, you’ll see it in this chat.</p>
      <Btn busy={busy} disabled={!ok} onClick={() => void go()} className="w-full">Send to manager</Btn>
    </Sheet>
  );
}
