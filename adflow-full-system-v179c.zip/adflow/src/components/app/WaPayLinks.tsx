'use client';

// v122: WhatsApp payment links — a crypto link for a customer on WhatsApp (no Telegram chat).
// Paid → saved in WhatsApp sales automatically (no commission, nothing sent to Meta) and the manager gets a task.
import { useCallback, useEffect, useState } from 'react';
import { Copy, X, Plus } from 'lucide-react';
import clsx from 'clsx';
import { useToast, Field, inputCls, Btn, usd, useInterval, Toggle } from './ui';
import { openExternal } from './native';

type Api = <T = any>(path: string, body?: unknown) => Promise<T>;
type Link = { id: number; code: string; label: string; total: number; status: string; url: string; created_at: number; paid_at: number | null; cust_name: string | null; cust_phone: string | null; pay_currency: string | null; paid_usd?: number; due?: number };
type Data = { on: boolean; links: Link[]; items: { k: string; label: string; price: number }[]; topup_pct?: number; premium_pct?: number; topup_min?: number };

const ST: Record<string, [string, string]> = { new: ['Not opened', 'text-tg-sub'], pending_payment: ['Opened, waiting', 'text-tg-orange'], paid: ['Paid', 'text-tg-ok'], cancelled: ['Cancelled', 'text-tg-bad'] };
const waDigits = (p: string) => p.replace(/\D/g, '').replace(/^0+/, '');

type Row = { item: string; qty: number; amount: string; typed: boolean; label: string };
const newRow = (item = 'premium'): Row => ({ item, qty: 1, amount: '', typed: false, label: '' });
const r2 = (n: number) => Math.round(n * 100) / 100;

export function WaPayLinks({ api }: { api: Api }) {
  const toast = useToast();
  const [d, setD] = useState<Data | null>(null);
  const [rows, setRows] = useState<Row[]>([newRow()]);
  const [feeOn, setFeeOn] = useState(true); const [disc, setDisc] = useState('');
  const [name, setName] = useState(''); const [phone, setPhone] = useState(''); const [bm, setBm] = useState(''); const [act, setAct] = useState('');
  const [busy, setBusy] = useState(false);
  const [made, setMade] = useState<{ url: string; message: string; phone: string } | null>(null);
  const load = useCallback(() => api<Data>('wa_paylinks').then(setD).catch(e => toast((e as Error).message, 'err')), [api, toast]);
  useEffect(() => { void load(); }, [load]);
  useInterval(() => void load(), 15000);
  const price = (k: string) => d?.items.find(x => x.k === k)?.price || 0;
  const multi = (k: string) => k !== 'funnel' && k !== 'other' && k !== 'topup';
  const amt = (r: Row) => (r.typed || r.item === 'topup' ? Number(r.amount) || 0 : r2(price(r.item) * (multi(r.item) ? r.qty : 1)));
  const set = (i: number, p: Partial<Row>) => setRows(rs => rs.map((r, j) => (j === i ? { ...r, ...p } : r)));
  // v129: "Top-up" is picked from the same product list (one per link); it is the client's ad money + our fee
  const svc = rows.filter(r => r.item !== 'topup'), topRow = rows.find(r => r.item === 'topup');
  const hasAcct = svc.some(r => !['funnel', 'fb_old', 'other'].includes(r.item));
  const [premTop, setPremTop] = useState(false); // v136: top-up-only link for a Premium customer → Premium fee
  const prem = svc.some(r => r.item === 'premium' || r.item === 'premium_full') || (premTop && !!topRow);
  const pct = (prem ? d?.premium_pct : d?.topup_pct) ?? 3;
  const sub = r2(svc.reduce((a, r) => a + amt(r), 0));
  const t = topRow ? amt(topRow) : 0, fee = t > 0 && feeOn ? r2(t * pct / 100) : 0, dc = Math.min(Number(disc) || 0, r2(sub + fee));
  const total = r2(sub + t + fee - dc);
  const copy = (x: string) => { try { void navigator.clipboard.writeText(x); toast('Copied'); } catch { /* ignore */ } };
  const sendWa = (msg: string, ph: string) => void openExternal(`https://wa.me/${waDigits(ph)}?text=${encodeURIComponent(msg)}`);

  async function create() {
    if (topRow && !(t > 0)) { toast('Enter the top-up amount', 'err'); return; }
    if (!(total > 0)) { toast('Add a service or a top-up', 'err'); return; }
    if (rows.some(r => r.item === 'other' && !r.label.trim())) { toast('Write what "Other" is for', 'err'); return; }
    setBusy(true);
    try {
      const r = await api<{ url: string; message: string }>('wa_paylink', {
        items: svc.map(r => ({ item: r.item, qty: multi(r.item) ? r.qty : 1, amount: amt(r), label: r.label })),
        topup: t || '', fee_on: feeOn, discount: Number(disc) || '', name, phone, bm_id: hasAcct ? bm : '', act_id: topRow ? act : '', tier: premTop && topRow ? 'premium' : '',
      });
      setMade({ url: r.url, message: r.message, phone });
      setRows([newRow()]); setDisc(''); setFeeOn(true); setPremTop(false); setName(''); setPhone(''); setBm(''); setAct('');
      await load();
    } catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); }
  }
  async function cancel(l: Link) {
    if (!confirm(`Cancel link ${l.code} (${usd(l.total)})?`)) return;
    try { await api('paylink_cancel', { id: l.id }); toast('Cancelled'); await load(); } catch (e) { toast((e as Error).message, 'err'); }
  }

  if (d && !d.on) return <p className="af-card p-4 text-[14px] text-tg-sub">Crypto payment links are off. The admin turns them on in Settings → Website orders (NOWPayments).</p>;
  return (
    <div>
      {made ? (
        <div className="mb-5 af-card p-4">
          <p className="mb-2 text-[16px] font-semibold text-tg-ok">Link ready</p>
          <pre className="mb-3 whitespace-pre-wrap rounded-xl bg-tg-input p-3 font-sans text-[14px]">{made.message}</pre>
          <div className="grid gap-2">
            {waDigits(made.phone).length >= 8 && <Btn kind="green" onClick={() => sendWa(made.message, made.phone)} className="w-full">Send on WhatsApp</Btn>}
            <Btn onClick={() => copy(made.message)} className="w-full">Copy message</Btn>
            <Btn kind="ghost" onClick={() => setMade(null)} className="w-full">Make another link</Btn>
          </div>
        </div>
      ) : (
        <div className="mb-5 af-card p-4">
          <p className="mb-1 text-[16px] font-semibold">New WhatsApp payment link</p>
          <p className="mb-4 text-[13px] text-tg-sub">One link for one or more services, a top-up and a discount. The customer pays with crypto; when paid it is saved in WhatsApp sales by itself (nothing goes to Meta) and you get a notification.</p>
          {rows.map((r, i) => (
            <div key={i} className="mb-3 rounded-xl border border-white/[0.06] p-3">
              <div className="mb-2 flex items-center gap-2">
                <select value={r.item} onChange={e => set(i, { item: e.target.value, typed: false, amount: '' })} className={clsx(inputCls, 'flex-1')} aria-label="Service">
                  {(d?.items || []).map(x => <option key={x.k} value={x.k}>{x.label}{x.price ? ` · ${usd(x.price)}` : ''}</option>)}
                  {(!topRow || r.item === 'topup') && <option value="topup">Top-up · any amount</option>}
                </select>
                {rows.length > 1 && <button aria-label="Remove service" onClick={() => setRows(rs => rs.filter((_, j) => j !== i))} className="grid h-11 w-11 shrink-0 place-items-center rounded-xl text-tg-sub hover:bg-tg-hover hover:text-tg-bad"><X size={18} /></button>}
              </div>
              {r.item === 'other' && <input value={r.label} onChange={e => set(i, { label: e.target.value })} className={clsx(inputCls, 'mb-2')} placeholder="What is it for (e.g. Ad setup)" />}
              {r.item === 'topup' ? (<div data-top-row>
                <div className="grid grid-cols-2 gap-2">
                  <label className="text-[12.5px] text-tg-sub">Top-up amount ($)<input data-top-amount inputMode="decimal" value={r.amount} onChange={e => set(i, { amount: e.target.value.replace(/[^\d.]/g, ''), typed: true })} className={clsx(inputCls, 'mt-1')} placeholder="Any amount" /></label>
                  <label className="text-[12.5px] text-tg-sub">Ad account ID<input value={act} onChange={e => setAct(e.target.value)} className={clsx(inputCls, 'mt-1')} placeholder="Optional" /></label>
                </div>
                <label className="mt-2 flex items-center justify-between gap-3 rounded-xl bg-tg-input px-3.5 py-3 text-[14.5px]"><span>Top-up fee ({pct}%) · {usd(t > 0 ? r2(t * pct / 100) : 0)}</span><Toggle on={feeOn} onChange={setFeeOn} label="Top-up fee" /></label>
                {!svc.some(x => x.item === 'premium' || x.item === 'premium_full') && <label className="mt-2 flex items-center justify-between gap-3 rounded-xl bg-tg-input px-3.5 py-3 text-[14.5px]" data-prem-top><span><span className="block">Premium customer</span><span className="text-[12.5px] text-tg-sub">Premium top-up fee {d?.premium_pct ?? '—'}%</span></span><Toggle on={premTop} onChange={setPremTop} label="Premium customer" /></label>}
              </div>) : (
              <div className="grid grid-cols-2 gap-2">
                {multi(r.item) ? <label className="text-[12.5px] text-tg-sub">Quantity<input type="number" min={1} max={50} value={r.qty} onChange={e => set(i, { qty: Math.max(1, Math.min(50, parseInt(e.target.value) || 1)) })} className={clsx(inputCls, 'mt-1')} /></label> : <div />}
                <label className="text-[12.5px] text-tg-sub">Amount ($)<input inputMode="decimal" value={r.typed ? r.amount : String(amt(r))} onChange={e => set(i, { amount: e.target.value.replace(/[^\d.]/g, ''), typed: true })} className={clsx(inputCls, 'mt-1')} /></label>
              </div>)}
            </div>
          ))}
          {rows.length < 11 && <button onClick={() => setRows(rs => [...rs, newRow('account')])} className="mb-4 flex w-full items-center justify-center gap-2 rounded-xl border border-dashed border-tg-sub/30 py-2.5 text-[14.5px] font-medium text-tg-acc hover:bg-tg-hover"><Plus size={17} />Add another service or top-up</button>}
          <Field label="Discount ($)" hint="Optional"><input inputMode="decimal" value={disc} onChange={e => setDisc(e.target.value.replace(/[^\d.]/g, ''))} className={inputCls} placeholder="0" /></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Customer name"><input value={name} onChange={e => setName(e.target.value)} className={inputCls} placeholder="Optional" /></Field>
            <Field label="WhatsApp number"><input inputMode="tel" value={phone} onChange={e => setPhone(e.target.value)} className={inputCls} placeholder="+91 98765 43210" /></Field>
          </div>
          {hasAcct && <Field label="Client's Business Manager ID"><input inputMode="numeric" value={bm} onChange={e => setBm(e.target.value.replace(/\D/g, ''))} className={inputCls} placeholder="Optional, can be added later" /></Field>}
          <div className="mb-4 space-y-1 rounded-xl bg-tg-input px-3.5 py-3 text-[14px]" data-sum>
            {svc.map((r, i) => <div key={i} className="flex justify-between gap-3"><span className="text-tg-sub">{r.item === 'other' ? r.label || 'Other' : d?.items.find(x => x.k === r.item)?.label}{multi(r.item) && r.qty > 1 ? ` × ${r.qty}` : ''}</span><span>{usd(amt(r))}</span></div>)}
            {t > 0 && <div className="flex justify-between"><span className="text-tg-sub">Top-up</span><span>{usd(t)}</span></div>}
            {fee > 0 && <div className="flex justify-between"><span className="text-tg-sub">Top-up fee ({pct}%)</span><span>{usd(fee)}</span></div>}
            {dc > 0 && <div className="flex justify-between text-tg-ok"><span>Discount</span><span>−{usd(dc)}</span></div>}
            <div className="flex justify-between border-t border-white/10 pt-1 text-[15px] font-semibold"><span>Total</span><span>{usd(total)}</span></div>
          </div>
          <Btn kind="green" busy={busy} onClick={() => void create()} className="w-full">Create link{total > 0 ? ` · ${usd(total)}` : ''}</Btn>
        </div>
      )}

      <p className="mb-2 px-1 text-[14px] font-semibold text-tg-sub">Recent WhatsApp links</p>
      <div className="overflow-hidden af-card">
        {d && !d.links.length && <p className="px-4 py-6 text-center text-[14px] text-tg-sub">No links yet</p>}
        {d?.links.map(l => (
          <div key={l.id} className="flex items-center gap-3 border-b border-white/[0.04] px-4 py-3 last:border-0">
            <div className="min-w-0 flex-1">
              <p className="truncate text-[15px] font-medium">{l.label} · {usd(l.total)}</p>
              <p className="truncate text-[13px] text-tg-sub">{[l.cust_name, l.cust_phone, l.code, new Date(l.created_at).toLocaleDateString(undefined, { day: 'numeric', month: 'short' })].filter(Boolean).join(' · ')}</p>
              <p className={clsx('text-[13px] font-medium', (ST[l.status] || ST.new)[1])}>{(ST[l.status] || [l.status])[0]}{l.status === 'paid' && l.pay_currency ? ` · ${l.pay_currency.toUpperCase()}` : ''}</p>
              {l.status !== 'paid' && l.status !== 'cancelled' && (l.paid_usd || 0) > 0 && <p data-short-link className="text-[13px] text-[#f5b83d]">Short: got {usd(l.paid_usd || 0)} · {usd(l.due || 0)} still due — confirms when the rest is paid on the same link</p>}
            </div>
            {l.status !== 'paid' && l.status !== 'cancelled' && <>
              <button aria-label="Copy link" onClick={() => copy(l.url)} className="grid h-9 w-9 place-items-center rounded-full text-tg-sub hover:bg-tg-hover"><Copy size={17} /></button>
              {(l.paid_usd || 0) > 0 ? <span className="shrink-0 text-[12.5px] text-[#f5b83d]">Part paid {usd(l.paid_usd || 0)}</span> : <button aria-label="Cancel link" onClick={() => void cancel(l)} className="grid h-9 w-9 place-items-center rounded-full text-tg-sub hover:bg-tg-hover hover:text-tg-bad"><X size={18} /></button>}
            </>}
          </div>
        ))}
      </div>
    </div>
  );
}
