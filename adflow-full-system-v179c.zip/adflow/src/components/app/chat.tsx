'use client';

import { createContext, useCallback, useContext, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { LifeBuoy, ArrowLeft, Phone, MoreVertical, Paperclip, Mic, Send, Square, Zap, Clock, Check, CheckCheck, Image as ImageIcon, FileText, Play, Pause, ChevronDown, AlertCircle, Pin, AlarmClock, X as XIcon, Sparkles, Star, MessageCircle, Bot as BotIcon, Lightbulb, AlertTriangle, Info, Megaphone, Reply, RotateCw, MousePointerClick, Briefcase, LayoutGrid, Link2, Copy, ExternalLink, CircleCheck } from 'lucide-react';
import clsx from 'clsx';
import { Avatar, Sheet, Btn, Field, inputCls, useToast, useInterval, hhmm, dayLabel, usd, noEmoji, LineChip, Skeleton } from './ui';
import { CALL_LABEL } from './calls';
import { campLabel, campAd, lineKey, LINE_BADGE, type LineKey } from '@/server/chatchips';
import { openExternal, openWhatsApp, clearChatNotif } from './native';

/** v158: WhatsApp-style *bold*, _italic_ and ~strike~ shown as formatting (the client sees it that way), not as stars. */
function waFormat(t: string): React.ReactNode {
  if (!/[*_~]/.test(t)) return t;
  const re = /(^|[\s(>"'])([*_~])(?!\s)([^\n*_~]*?[^\s*_~])\2(?=$|[\s).,!?:;"'<])/g;
  const out: React.ReactNode[] = [];
  let last = 0, k = 0, m: RegExpExecArray | null;
  while ((m = re.exec(t))) {
    const start = m.index + m[1].length;
    if (start > last) out.push(t.slice(last, start));
    const inner = m[3];
    out.push(m[2] === '*' ? <b key={k++}>{inner}</b> : m[2] === '_' ? <i key={k++}>{inner}</i> : <s key={k++}>{inner}</s>);
    last = start + inner.length + 2;
  }
  if (last < t.length) out.push(t.slice(last));
  return out.length ? out : t;
}

export type Msg = { id: number; dir: 'in' | 'out' | 'sys'; sender: string; text: string; file_id: string | null; file_type: string | null; file_name: string | null; created_at: number; agent_name?: string | null; pending?: boolean; failed?: boolean; retryUpload?: { file: File; kind?: string; caption: string; cid?: string }; cid?: string; read_at?: number | null; delivered_at?: number | null; reply_to?: number | null; deleted_at?: number | null; deleted_by?: string | null; agent_id?: number | null; via?: string | null; dur?: number | null };
export type LeadFull = Record<string, any> & { remind_at?: number | null; remind_note?: string | null; remind_due?: number; id: number; name: string | null; tg_name: string | null; tg_username: string | null; phone: string | null; email: string | null; status: string; fu_stage: number; fu_due: number };
type Api = <T = any>(path: string, body?: unknown) => Promise<T>;

/** Telegram-style "last seen" (from the chat account; '' when the client hides it). */
export function seenText(state?: string | null, at?: number | null) {
  const t = Date.now();
  if (state === 'online') return at && at > t ? 'online' : 'last seen just now';
  if (state === 'recently') return 'last seen recently';
  if (state === 'week') return 'last seen within a week';
  if (state === 'month') return 'last seen within a month';
  if (state !== 'at' || !at) return '';
  const m = Math.floor((t - at) / 60000);
  if (m < 1) return 'last seen just now';
  if (m < 60) return `last seen ${m} min ago`;
  const d = new Date(at), today = new Date(); const hm = d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  if (d.toDateString() === today.toDateString()) return `last seen today at ${hm}`;
  if (d.toDateString() === new Date(t - 86400000).toDateString()) return `last seen yesterday at ${hm}`;
  return `last seen ${d.toLocaleDateString([], { day: 'numeric', month: 'short' })} at ${hm}`;
}
/** v132: WhatsApp chats show the contact name saved in our apps (e.g. "Ravi · Premium Lead 2"). */
export const leadName = (l: { id: number; name?: string | null; tg_name?: string | null; tg_username?: string | null; contact?: string | null }) => l.contact || l.name || l.tg_name || (l.tg_username ? '@' + l.tg_username : `Lead #${l.id}`);

const WALLPAPER = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='120' height='120' viewBox='0 0 120 120'%3E%3Cg fill='none' stroke='%23ffffff' stroke-opacity='.022' stroke-width='2'%3E%3Ccircle cx='20' cy='20' r='7'/%3E%3Cpath d='M70 14l8 8-8 8-8-8z'/%3E%3Cpath d='M100 60c0 6-10 6-10 0s10-6 10 0z'/%3E%3Cpath d='M18 78h18M27 69v18'/%3E%3Cpath d='M60 98l6-10 6 10z'/%3E%3Ccircle cx='96' cy='104' r='4'/%3E%3Cpath d='M48 48q6-8 12 0t12 0'/%3E%3C/g%3E%3C/svg%3E"), radial-gradient(ellipse at 30% 0%, #16263A 0%, #0E1621 60%)`;
// v132: Telegram light wallpaper (phone in light mode)
// v167: calmer — a fine dot grid on a soft, desaturated green-grey (was big doodles on a strong green)
const WALLPAPER_LIGHT = `radial-gradient(rgba(60,90,50,.09) 1.4px, transparent 1.6px), linear-gradient(160deg, #e3eadb 0%, #d7e2cd 55%, #cddabf 100%)`;
// v131: WhatsApp chat wallpaper (light beige with a faint doodle, like WhatsApp)
const WA_WALLPAPER = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='120' height='120' viewBox='0 0 120 120'%3E%3Cg fill='none' stroke='%23000000' stroke-opacity='.045' stroke-width='2'%3E%3Ccircle cx='20' cy='20' r='7'/%3E%3Cpath d='M70 14l8 8-8 8-8-8z'/%3E%3Cpath d='M100 60c0 6-10 6-10 0s10-6 10 0z'/%3E%3Cpath d='M18 78h18M27 69v18'/%3E%3Cpath d='M60 98l6-10 6 10z'/%3E%3Ccircle cx='96' cy='104' r='4'/%3E%3Cpath d='M48 48q6-8 12 0t12 0'/%3E%3C/g%3E%3C/svg%3E"), linear-gradient(#efeae2, #efeae2)`;

/** v139: chat order = real time (created_at, then id); our unsent / failed bubbles (id ≤ 0) stay at the bottom.
 *  Empty customer bubbles (no text, no media) are never shown. */
export function byTime(list: Msg[]): Msg[] {
  const seen = list.filter(m => m.id > 0 && !(m.dir === 'in' && !String(m.text || '').trim() && !m.file_id && !m.file_type && !m.via));
  seen.sort((a, b) => (a.created_at - b.created_at) || (a.id - b.id));
  return [...seen, ...list.filter(m => m.id <= 0)];
}

/* ---------------- Media ---------------- */
function Voice({ src, mine, known }: { src: string; mine: boolean; known?: number | null }) {
  const ref = useRef<HTMLAudioElement>(null);
  const [playing, setPlaying] = useState(false);
  const [p, setP] = useState(0);
  // v139: the stored length first; else the file's own (an OGG without a length in its header → ask the browser to read to the end)
  const [dur, setDur] = useState(known && known > 0 ? known : 0);
  const probing = useRef(false);
  const fit = (a: HTMLAudioElement) => {
    const d = a.duration;
    if (Number.isFinite(d) && d > 0) { if (probing.current) { probing.current = false; a.currentTime = 0; } setDur(d); return; }
    if (!probing.current && (d === Infinity || !d)) { probing.current = true; try { a.currentTime = 1e7; } catch { probing.current = false; } }
  };
  const bars = useRef(Array.from({ length: 28 }, (_, i) => 6 + Math.abs(Math.sin(i * 1.7 + src.length)) * 16)).current;
  return (
    <div className="flex min-w-[200px] items-center gap-3 py-1">
      <button type="button" onClick={() => { const a = ref.current!; if (a.paused) { void a.play(); } else a.pause(); }}
        className={clsx('grid h-11 w-11 shrink-0 place-items-center rounded-full', mine ? 'bg-tg-outtx text-tg-out' : 'bg-tg-acc text-white')} aria-label={playing ? 'Pause' : 'Play'}>
        {playing ? <Pause size={20} fill="currentColor" /> : <Play size={20} fill="currentColor" className="ml-0.5" />}
      </button>
      <div className="flex-1">
        <div className="flex h-6 items-end gap-[2px]">
          {bars.map((h, i) => <span key={i} className={clsx('w-[3px] rounded-full', i / bars.length <= p ? (mine ? 'bg-tg-outtx' : 'bg-tg-link') : mine ? 'bg-tg-outtx/40' : 'bg-tg-sub/50')} style={{ height: h }} />)}
        </div>
        <span className="text-[11.5px] opacity-70" data-voice-dur={dur ? Math.round(dur) : ''}>{dur > 0 ? fmtDur(playing || p > 0 ? dur * p : dur) : '-:--'}</span>
      </div>
      <audio ref={ref} src={src} preload="metadata" onLoadedMetadata={e => fit(e.currentTarget)} onDurationChange={e => fit(e.currentTarget)} onSeeked={e => { const a = e.currentTarget; if (probing.current && !(Number.isFinite(a.duration) && a.duration > 0)) { probing.current = false; a.currentTime = 0; } }} onPlay={() => setPlaying(true)} onPause={() => setPlaying(false)}
        onEnded={() => { setPlaying(false); setP(0); }} onTimeUpdate={e => { const a = e.currentTarget; if (probing.current) return; const d = Number.isFinite(a.duration) && a.duration > 0 ? a.duration : dur; setP(d ? Math.min(1, a.currentTime / d) : 0); }} />
    </div>
  );
}
const fmtDur = (s: number) => (Number.isFinite(s) && s > 0 ? `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}` : '0:00');

/** v160: a photo keeps its space while loading (no jump in the chat) and says so when it cannot load. */
function Photo({ src, sticker }: { src: string; sticker: boolean }) {
  const [st, setSt] = useState<'load' | 'ok' | 'err'>('load');
  const [open, setOpen] = useState(false); // v176: opens INSIDE the app (a new tab showed a black screen in the apps)
  if (st === 'err') return <span className="block rounded-[12px] bg-tg-sub/15 px-4 py-6 text-center text-[13px] text-tg-sub">Photo not available</span>;
  return <>
    <button type="button" className="block" onClick={() => { if (!sticker) setOpen(true); }} aria-label="Open photo"><img src={src} alt="" loading="lazy" onLoad={() => setSt('ok')} onError={() => setSt('err')}
      className={clsx('block max-h-[340px] w-full max-w-[300px] object-cover', sticker ? 'max-w-[160px] bg-transparent' : 'rounded-[12px]', st === 'load' && !sticker && 'aspect-[4/3] w-[260px] bg-tg-sub/15')} /></button>
    {open && <PhotoViewer src={src} onClose={() => setOpen(false)} />}
  </>;
}
/** v176: full-screen photo inside the app: tap the X / back to close, double-tap (or the button) to zoom, drag to look around. */
function PhotoViewer({ src, onClose }: { src: string; onClose: () => void }) {
  const [zoom, setZoom] = useState(false); const [ok, setOk] = useState(false); const [err, setErr] = useState(false);
  const last = useRef(0);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    // the phone's back button closes the photo, not the chat
    history.pushState({ photo: 1 }, ''); const onPop = () => onClose();
    window.addEventListener('keydown', onKey); window.addEventListener('popstate', onPop);
    return () => { window.removeEventListener('keydown', onKey); window.removeEventListener('popstate', onPop); if (history.state?.photo) history.back(); };
  }, [onClose]);
  const tap = () => { const t = Date.now(); if (t - last.current < 300) setZoom(z => !z); last.current = t; };
  return (
    <div className="fixed inset-0 z-[90] flex flex-col bg-black" role="dialog" aria-modal="true" aria-label="Photo" data-photo-viewer>
      <div className="flex items-center justify-end gap-2 p-3 pt-[max(12px,env(safe-area-inset-top))]">
        <button type="button" className="rounded-full bg-white/15 px-3.5 py-2 text-[14px] font-medium text-white" onClick={() => setZoom(z => !z)}>{zoom ? 'Fit' : 'Zoom'}</button>
        <button type="button" className="grid h-10 w-10 place-items-center rounded-full bg-white/15 text-[22px] text-white" onClick={onClose} aria-label="Close">×</button>
      </div>
      <div className={clsx('min-h-0 flex-1', zoom ? 'overflow-auto' : 'flex items-center justify-center overflow-hidden')} onClick={tap} style={{ touchAction: zoom ? 'pan-x pan-y pinch-zoom' : 'pinch-zoom' }}>
        {!ok && !err && <p className="absolute inset-x-0 top-1/2 text-center text-[14px] text-white/60">Loading…</p>}
        {err ? <p className="text-center text-[14px] text-white/70">Photo not available</p>
          : <img src={src} alt="" onLoad={() => setOk(true)} onError={() => setErr(true)} draggable={false}
            className={zoom ? 'max-w-none' : 'max-h-full max-w-full object-contain'} style={zoom ? { width: '250%' } : undefined} />}
      </div>
    </div>
  );
}
function Media({ m }: { m: Msg }) {
  const src = `/api/f/${encodeURIComponent(m.file_id!)}`;
  const t = m.file_type;
  if (t === 'photo' || t === 'sticker') return <Photo src={src} sticker={t === 'sticker'} />;
  if (t === 'video' || t === 'animation') return <video src={src} controls={t === 'video'} autoPlay={t === 'animation'} muted={t === 'animation'} loop={t === 'animation'} playsInline preload="metadata" className="block max-h-[340px] w-full max-w-[300px] rounded-[12px] bg-black" />;
  if (t === 'video_note') return <video src={src} controls playsInline preload="metadata" className="block h-[200px] w-[200px] rounded-full bg-black object-cover" />;
  if (t === 'voice' || t === 'audio') return <Voice src={src} mine={m.dir === 'out'} known={m.dur} />;
  return (
    <a href={src} target="_blank" rel="noopener" className="flex items-center gap-3 py-1">
      <span className={clsx('grid h-11 w-11 shrink-0 place-items-center rounded-full', m.dir === 'out' ? 'bg-tg-outtx text-tg-out' : 'bg-tg-acc text-white')}><FileText size={20} /></span>
      <span className="min-w-0"><span className="block truncate text-[14.5px] font-medium">{m.file_name || 'File'}</span><span className="text-[12px] opacity-70">Tap to open</span></span>
    </a>
  );
}

/* ---------------- Bubble ---------------- */
const quoteText = (q: Msg) => q.text || (q.file_type === 'voice' ? 'Voice message' : q.file_type === 'photo' ? 'Photo' : q.file_type ? 'File' : '');
function Bubble({ m, showAgent, tail, read, delivered, quoted, onReply, onQuote, onRetry, onMenu }: { m: Msg; showAgent: boolean; tail: boolean; read?: boolean; delivered?: boolean; quoted?: Msg; onReply?: (m: Msg) => void; onQuote?: (id: number) => void; onRetry?: (m: Msg) => void; onMenu?: (m: Msg) => void }) {
  const [dx, setDx] = useState(0);
  const start = useRef<{ x: number; y: number } | null>(null);
  const hold = useRef<ReturnType<typeof setTimeout> | null>(null);
  // v137: a deleted message of ours → a small grey line, no content
  if (m.deleted_at) return <div className={clsx('my-0.5 flex', m.dir === 'out' ? 'justify-end' : 'justify-start')} data-deleted-msg><span className="rounded-full bg-tg-panel/70 px-3 py-1 text-[12.5px] italic text-tg-sub ring-1 ring-tg-line">Message deleted{m.deleted_by ? ` by ${m.deleted_by}` : ''}</span></div>;
  if (m.dir === 'sys') return <div className="my-1.5 flex justify-center"><span className="tg-pill rounded-full px-3 py-1 text-center text-[12.5px]">{noEmoji(m.text)}</span></div>;
  // swipe left (like Telegram) or double-tap → reply to this message
  const canReply = !!onReply && m.id > 0;
  // v137: long-press (or right-click) one of our messages → its menu (Delete)
  const menuOk = !!onMenu && m.dir === 'out' && m.id > 0;
  const stopHold = () => { if (hold.current) { clearTimeout(hold.current); hold.current = null; } };
  const touch = canReply || menuOk ? {
    onTouchStart: (e: React.TouchEvent) => { start.current = { x: e.touches[0].clientX, y: e.touches[0].clientY }; if (menuOk) { stopHold(); hold.current = setTimeout(() => { hold.current = null; start.current = null; setDx(0); if (navigator.vibrate) navigator.vibrate(20); onMenu!(m); }, 550); } },
    onTouchMove: (e: React.TouchEvent) => { const st = start.current; if (!st) return; const x = e.touches[0].clientX - st.x, y = e.touches[0].clientY - st.y; if (Math.abs(x) > 8 || Math.abs(y) > 8) stopHold(); if (!canReply) return; if (Math.abs(y) > Math.abs(x) && Math.abs(y) > 10) { start.current = null; setDx(0); return; } setDx(Math.max(-80, Math.min(0, x))); },
    onTouchEnd: () => { stopHold(); if (canReply && dx <= -55) { onReply!(m); if (navigator.vibrate) navigator.vibrate(15); } setDx(0); start.current = null; },
    onDoubleClick: () => { if (!canReply) return; window.getSelection()?.removeAllRanges(); onReply!(m); },
    onContextMenu: (e: React.MouseEvent) => { if (!menuOk) return; e.preventDefault(); onMenu!(m); },
  } : {};
  const mine = m.dir === 'out';
  const label = mine && (m.sender !== 'agent' || showAgent)
    ? m.sender === 'ai' ? 'AI' : m.sender === 'bot' ? 'Auto-reply' : m.sender === 'followup' ? 'Auto follow-up' : m.sender === 'auto' ? 'Auto first message' : m.sender === 'owner' ? 'Owner (phone)' : m.sender === 'admin' ? 'Admin' : m.agent_name || (m.id <= 0 || m.pending || m.failed ? 'You' : 'Agent') : null;
  const mediaOnly = m.file_id && !m.text && ['photo', 'video', 'sticker', 'animation', 'video_note'].includes(m.file_type || '');
  return (
    <div className={clsx('group relative flex', mine ? 'justify-end' : 'justify-start')} {...touch} style={dx ? { transform: `translateX(${dx}px)` } : undefined}>
      {dx < -20 && <span className="absolute -right-8 top-1/2 -translate-y-1/2 text-tg-sub"><Reply size={18} /></span>}
      {canReply && <button onClick={() => onReply!(m)} className={clsx('mx-1 hidden self-center rounded-full p-1 text-tg-sub hover:bg-white/10 md:group-hover:block', mine ? 'order-first' : 'order-last')} title="Reply" aria-label="Reply"><Reply size={15} /></button>}
      {menuOk && <button onClick={() => onMenu!(m)} data-msg-menu={m.id} className="order-first mx-0.5 hidden self-center rounded-full p-1 text-tg-sub hover:bg-white/10 md:group-hover:block" title="Message menu" aria-label="Message menu"><MoreVertical size={15} /></button>}
      <div className={clsx('relative max-w-[min(82%,460px)] text-[15px] leading-[1.38]',
        mediaOnly ? 'p-0' : 'px-2.5 pb-1.5 pt-1.5',
        mine ? 'bg-tg-out text-tg-outtx wa-shadow' : 'bg-tg-in text-tg-text wa-shadow',
        'rounded-[16px]', tail && (mine ? 'rounded-br-[5px]' : 'rounded-bl-[5px]'), mediaOnly && 'overflow-hidden bg-transparent')}>
        {label && <p className={clsx('mb-0.5 text-[12.5px] font-semibold', mine ? 'text-[#9CC8F5]' : 'text-tg-link', mediaOnly && 'px-2.5 pt-1.5')}>{label}</p>}
        {quoted && (
          <button onClick={() => onQuote?.(quoted.id)} className={clsx('mb-1 block w-full rounded-md border-l-[3px] px-2 py-0.5 text-left text-[13px] leading-snug', mine ? 'border-tg-link bg-tg-outtx/10' : 'border-tg-link bg-tg-link/10')}>
            <span className={clsx('block text-[12px] font-semibold', mine ? 'text-[#9CC8F5]' : 'text-tg-link')}>{quoted.dir === 'in' ? 'Customer' : 'You'}</span>
            <span className="line-clamp-1 opacity-85">{quoteText(quoted)}</span>
          </button>
        )}
        {m.via === 'tap' && <p data-tap className="mb-0.5 flex items-center gap-1 text-[12px] font-medium text-tg-sub"><MousePointerClick size={13} aria-hidden />Tapped a button</p>}
        {m.file_id && <div className={clsx(!mediaOnly && 'mb-1')}><Media m={m} /></div>}
        {m.text && <span className="whitespace-pre-wrap break-words">{waFormat(m.text)}</span>}
        <span className={clsx('float-right ml-2 mt-1.5 inline-flex translate-y-1 items-center gap-0.5 text-[11.5px]',
          mediaOnly ? 'absolute bottom-2 right-2 rounded-full bg-black/45 px-1.5 py-0.5 text-white' : mine ? 'text-tg-outsub' : 'text-tg-sub')}>
          {hhmm(m.created_at)}
          {mine && (m.failed ? <AlertCircle size={14} className="text-tg-red" /> : m.pending ? <Clock size={13} /> : (read ? <CheckCheck size={15} className="text-[#5fb8ff]" data-tick="read" /> : delivered ? <CheckCheck size={15} data-tick="delivered" /> : <Check size={15} data-tick="sent" />))}
        </span>
        {m.failed && onRetry && m.text && <button onClick={() => onRetry(m)} className="mt-1 flex w-full items-center justify-center gap-1 rounded-lg bg-tg-red py-1 text-[12.5px] font-semibold text-white"><RotateCw size={13} />Not sent. Tap to send again</button>}
      </div>
    </div>
  );
}

/* ---------------- v167: payment link card (display only — the client still gets the same text) ---------------- */
type PayLinkLite = { code: string; status: string; total: number; url: string; label?: string; paid_usd?: number; due?: number; pay_currency?: string | null; fee?: number };
type PayMsg = { code: string; items: { label: string; amt: string }[]; total?: string; note?: string };
/** "💳 Payment link PL-X (2 items): A $15 + B $25 = $40\nurl" or "💳 Payment link PL-X: label · $25 (incl. $1 fee) · Special price (…)\nurl". */
export function parsePayMsg(text: string | null | undefined): PayMsg | null {
  const t = String(text || '');
  const m = t.match(/Payment link (PL-[0-9A-F]+)(.*)/);
  if (!m || /cancelled/i.test(m[2])) return null;
  const line = m[2];
  const multi = line.match(/^ \((\d+) items\): (.*) = (\$[\d,.]+)\s*$/);
  if (multi) {
    const items: PayMsg['items'] = [];
    const re = /(.+?) (\$[\d,.]+)(?: \+ |$)/g; let x: RegExpExecArray | null;
    while ((x = re.exec(multi[2]))) items.push({ label: x[1], amt: x[2] });
    return { code: m[1], items, total: multi[3] };
  }
  const one = line.match(/^: (.*?) · (\$[\d,.]+)( \(incl\. \$[\d,.]+ fee\))?(?: · (.*))?\s*$/);
  if (one) return { code: m[1], items: [{ label: one[1], amt: one[2] }], total: one[2], note: [one[3]?.trim().replace(/^\(|\)$/g, ''), one[4]].filter(Boolean).join(' · ') || undefined };
  return null;
}
/** v167: chat-list preview — a payment link line reads "Payment link · 2 items · $40" (other texts unchanged). */
export function previewText(t: string | null | undefined) {
  const pm = parsePayMsg(t);
  if (pm) return `Payment link · ${pm.items.length > 1 ? `${pm.items.length} items` : pm.items[0]?.label || pm.code}${pm.total ? ` · ${pm.total}` : ''}`;
  if (t && /Payment link PL-[0-9A-F]+ cancelled/.test(t)) return noEmoji(t);
  return t;
}
const shortCode = (c: string) => c.length > 11 ? `${c.slice(0, 7)}…${c.slice(-4)}` : c;
function PayCard({ m, p, l }: { m: Msg; p: PayMsg; l: PayLinkLite }) {
  const toast = useToast();
  const paid = l.status === 'paid', cancelled = l.status === 'cancelled', part = !paid && !cancelled && (l.paid_usd || 0) > 0;
  const tag = paid ? ['PAID', 'ok'] : cancelled ? ['CANCELLED', 'mute'] : part ? [`PART PAID ${usd(l.paid_usd || 0)}`, 'warn'] : l.status === 'pending_payment' ? ['PAYING', 'acc'] : ['UNPAID', 'warn'];
  const copy = () => { try { void navigator.clipboard.writeText(l.url); toast('Link copied'); } catch { /* ignore */ } };
  return (
    <div className="my-0.5 flex justify-end" data-paycard={l.code} data-pay-status={l.status}>
      <div className={clsx('w-[min(82%,290px)] overflow-hidden rounded-[16px] rounded-br-[5px] bg-tg-out text-tg-outtx wa-shadow', paid && 'ring-1 ring-inset ring-tg-ok/40')}>
        <div className="flex items-center gap-2.5 px-3 pb-2 pt-2.5">
          <span className={clsx('grid h-9 w-9 shrink-0 place-items-center rounded-[10px] text-white', paid ? 'bg-[#34C759]' : 'bg-[#3390EC]')}>{paid ? <CircleCheck size={19} /> : <Link2 size={19} />}</span>
          <span className="min-w-0 flex-1"><b className="block text-[15px] leading-tight">Payment link</b><span className="block truncate text-[12px] text-tg-outsub">{shortCode(l.code)}{l.pay_currency ? ` · ${String(l.pay_currency).toUpperCase()}` : ''}</span></span>
          <span className={clsx('af-tag', tag[1])}>{tag[0]}</span>
        </div>
        <div className="px-3 pb-1.5 text-[13.5px] leading-snug">
          {p.items.map((it, i) => <div key={i} className="flex justify-between gap-3 py-[2px]"><span className="min-w-0">{it.label}</span><span className="shrink-0 af-num">{it.amt}</span></div>)}
          {p.note && <p className="pt-0.5 text-[12px] text-tg-outsub">{p.note}</p>}
        </div>
        <div className="flex justify-between border-t border-tg-outsub/25 px-3 py-1.5 text-[15px] font-bold"><span>Total</span><span className="af-num">{usd(l.total)}</span></div>
        {part && <p className="px-3 pb-1.5 text-[12px] text-tg-outsub">{usd(l.due || 0)} still due</p>}
        <div className="flex border-t border-tg-outsub/25 text-[14px] font-semibold text-tg-link">
          <button type="button" onClick={copy} className="flex flex-1 items-center justify-center gap-1.5 py-2"><Copy size={14} aria-hidden />Copy link</button>
          <button type="button" onClick={() => void openExternal(l.url)} className="flex flex-1 items-center justify-center gap-1.5 border-l border-tg-outsub/25 py-2"><ExternalLink size={14} aria-hidden />Open</button>
        </div>
        <p className="-mt-0.5 px-3 pb-1.5 text-right text-[11px] text-tg-outsub">{hhmm(m.created_at)}</p>
      </div>
    </div>
  );
}

/* ---------------- AI coach (next step + ready replies) ---------------- */
type Coach = { decision?: 'reply_now' | 'wait'; wait_hint?: string; next_step: string; summary: string; warn?: string; suggestions: { label: string; text: string }[] };
// v139: the coach runs ONLY when tapped — the "Coach" chip opens this panel and runs it once; refresh runs it again; X closes.
// Nothing runs on chat open, on new messages or after a restart. No new message since the last advice → the saved one (no AI call).
function CoachBar({ api, leadId, lastInId, onHide }: { api: Api; leadId: number; lastInId: number; onHide: () => void }) {
  const [coach, setCoach] = useState<Coach | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [open, setOpen] = useState(false);
  const [show, setShow] = useState<number | null>(null);
  const [saved, setSaved] = useState(false);
  const [baseIn, setBaseIn] = useState(lastInId); // the newest customer message the advice was made for
  const inRef = useRef(lastInId); inRef.current = lastInId;
  const ran = useRef(false);
  const get = useCallback(async (force = false) => {
    setBusy(true); setErr(''); setBaseIn(inRef.current);
    try { const r = await api<{ coach: Coach | null; off?: string; saved?: boolean }>('ai_coach', { lead_id: leadId, force }); setCoach(r.coach); setSaved(!!r.saved); if (!r.coach) setErr(r.off || 'No messages in this chat yet'); }
    catch (e) { setErr((e as Error).message); }
    finally { setBusy(false); }
  }, [api, leadId]);
  useEffect(() => { if (ran.current) return; ran.current = true; void get(false); }, [get]); // mounted by the tap → one run
  const fresh = lastInId > baseIn && !busy;
  return (
    <div className="border-t border-tg-line bg-tg-panel px-2.5 pb-1 pt-2">
      <div className="flex items-start gap-2">
        <Sparkles size={15} className="mt-0.5 shrink-0 text-tg-link" />
        <button onClick={() => setOpen(o => !o)} className="min-w-0 flex-1 text-left text-[13.5px] leading-snug text-tg-text">
          {coach?.decision && !busy && <span className={clsx('mb-0.5 mr-1 inline-block rounded-full px-2 py-0.5 text-[11.5px] font-semibold', coach.decision === 'wait' ? 'bg-tg-orange/20 text-tg-orange' : 'bg-tg-green/20 text-tg-ok')}>{coach.decision === 'wait' ? 'Abhi wait karo' : 'Abhi reply karo'}</span>}
          {coach?.decision === 'wait' && coach.wait_hint && !busy && <span className="mb-0.5 block text-[12.5px] text-tg-orange">{coach.wait_hint}</span>}
          {busy && !coach ? <span className="text-tg-sub">Coach soch raha hai…</span> : err ? <span className="text-tg-red">{err}</span> : coach?.next_step}
          {coach?.warn && <span className="mt-0.5 block text-[12.5px] text-tg-orange"><AlertTriangle size={13} className="-mt-0.5 mr-1 inline" />{coach.warn}</span>}
          {open && coach?.summary && <span className="mt-1 block whitespace-pre-line text-[12.5px] text-tg-sub">{coach.summary}</span>}
        </button>
        {saved && !busy && coach && <span data-coach-saved className="mt-0.5 shrink-0 rounded-full bg-tg-chip px-2 py-0.5 text-[11px] font-semibold text-tg-sub">saved</span>}
        <button onClick={() => void get(true)} disabled={busy} data-coach-refresh className={clsx('-mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-full text-tg-link', busy && 'animate-spin')} aria-label="Run the coach again"><RotateCw size={15} /></button>
        <button onClick={onHide} data-coach-close className="-mt-0.5 grid h-7 w-7 shrink-0 place-items-center text-tg-sub" aria-label="Close coach"><XIcon size={15} /></button>
      </div>
      {fresh && <button data-coach-new onClick={() => void get(true)} className="mt-1 flex items-center gap-1 text-[12px] font-medium text-tg-orange"><RotateCw size={12} aria-hidden />New message – tap refresh</button>}
      {!!coach?.suggestions?.length && (
        <div className="mt-1.5 flex gap-1.5 overflow-x-auto pb-1">
          {/* ideas only — the agent reads them and writes the message himself (nothing is filled in or sent) */}
          {coach.suggestions.map((sg, i) => (
            <button key={i} onClick={() => setShow(show === i ? null : i)} className={clsx('shrink-0 rounded-2xl border border-white/10 bg-white/[0.04] px-3 py-1.5 text-left text-[13px] leading-snug text-tg-sub', show === i ? 'max-w-[92%]' : 'max-w-[78%]')}>
              <span className="block text-[11.5px] font-semibold text-tg-text/80"><Lightbulb size={12} className="-mt-0.5 mr-1 inline" />Idea · {sg.label}</span>
              <span className={clsx('whitespace-pre-line', show !== i && 'line-clamp-2')}>{sg.text}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

/* ---------------- Chat screen ---------------- */
export function ChatScreen({ role, api, leadId, onBack, onChanged, productMsgs = [], quickReplies: qrA = [], followups: fuA = [], quickRepliesF, followupsF, quickRepliesP, followupsP, agents = [], extraMenu, actionBar, canRetype, barHas = [], onLead, showAgents = false }: {
  role: 'agent' | 'admin'; api: Api; leadId: number; onBack: () => void; onChanged?: () => void;
  productMsgs?: { title: string; text: string }[]; quickReplies?: string[]; followups?: string[]; quickRepliesF?: string[]; followupsF?: string[]; quickRepliesP?: string[]; followupsP?: string[]; agents?: { id: number; name: string }[];
  extraMenu?: (lead: LeadFull, reload: () => void) => { label: string; icon?: React.ReactNode; onClick: () => void; danger?: boolean }[];
  actionBar?: (lead: LeadFull | null, act: { remind: () => void; assign: () => void }) => React.ReactNode;
  canRetype?: boolean; // owner / manager: may change the chat's type (Agency / Premium / Funnel)
  barHas?: string[]; // v136: actions the bar already has ('remind', 'assign') are left out of the ⋮ menu
  onLead?: (lead: LeadFull) => void; // v136: the parent gets the chat (agent, tier) to price its sheets
  showAgents?: boolean; // v141: the manager looking at an agent's chat → every team message shows who sent it
}) {
  const toast = useToast();
  const [lead, setLead] = useState<LeadFull | null>(null);
  // Funnel chats use the funnel quick replies / follow-ups (Admin → Funnel)
  // Premium chats (from /premium) use the texts with the Premium prices
  const prem = lead?.tier === 'premium' && lead?.biz !== 'funnel';
  // v131: WhatsApp chat → WhatsApp light look + the 24-hour reply window
  const wa = lead?.ch === 'wa';
  const coachOk = !!lead?.coach_on && !lead?.ai_active; // admin can switch the coach off for everyone
  const waLeft = wa && lead?.last_in_at ? Math.max(0, Number(lead.last_in_at) + 86400000 - Date.now()) : 0;
  // Retargeting offer chats: the server sends texts with the offer price (lead.texts)
  const quickReplies = lead?.texts?.quick_replies?.length ? lead.texts.quick_replies as string[] : lead?.biz === 'funnel' && quickRepliesF?.length ? quickRepliesF : prem && quickRepliesP?.length ? quickRepliesP : qrA;
  const followups = lead?.texts?.fu?.length ? lead.texts.fu as string[] : lead?.biz === 'funnel' && followupsF?.length ? followupsF : prem && followupsP?.length ? followupsP : fuA;
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const msgsRef = useRef<Msg[]>([]);
  const [deliveredUpto, setDeliveredUpto] = useState(0); // v134: WhatsApp grey double ticks
  const [readUpto, setReadUpto] = useState(0); // our messages up to this id are seen by the client (blue ticks)
  useEffect(() => { void clearChatNotif(leadId); }, [leadId]); // v134: chat opened → its phone notification goes
  msgsRef.current = msgs;
  const [meta, setMeta] = useState<{ sales: any[]; topups: any[]; capi?: any[] }>({ sales: [], topups: [] });
  const [text, setText] = useState('');
  const [replyTo, setReplyTo] = useState<Msg | null>(null);
  // v139: the coach is closed every time a chat opens (nothing remembered) and runs only when "Coach" is tapped
  const [coachOpen, setCoachOpen] = useState(false);
  useEffect(() => { try { localStorage.removeItem('af_coach_hidden'); } catch { /* private mode */ } }, []);
  const picked = useRef(''); // the coach suggestion the agent started from (to learn from their edits)
  const [menu, setMenu] = useState(false);
  const [delMsg, setDelMsg] = useState<Msg | null>(null); // v137: the "Delete message" sheet
  const [meId, setMeId] = useState<number | null>(null);
  const [sheet, setSheet] = useState<null | 'info' | 'call' | 'attach' | 'file' | 'reassign' | 'quick' | 'remind' | 'ltype'>(null);
  const [upload, setUpload] = useState<{ file: File; url: string; asFile: boolean; caption: string } | null>(null);
  const [rec, setRec] = useState<{ mr: MediaRecorder; start: number } | null>(null);
  const [recSec, setRecSec] = useState(0);
  const [atBottom, setAtBottom] = useState(true);
  const [newCount, setNewCount] = useState(0);
  const lastId = useRef(0);
  const box = useRef<HTMLDivElement>(null);
  const ta = useRef<HTMLTextAreaElement>(null);
  const photoIn = useRef<HTMLInputElement>(null);
  const fileIn = useRef<HTMLInputElement>(null);
  const first = useRef(true);
  const onLeadRef = useRef(onLead); onLeadRef.current = onLead;
  const loadedOnce = useRef(false); // v136: bubbles that arrive after the first load slide in
  const seenMsg = useRef<Set<number>>(new Set());

  const load = useCallback(async (reset = false) => {
    if (reset) { lastId.current = 0; first.current = true; }
    try {
      const r = await api<{ cursor?: number; lead: LeadFull; messages: Msg[]; sales: any[]; topups: any[]; capi?: any[]; read_upto?: number; delivered_upto?: number; deleted?: { id: number; deleted_by: string | null }[]; me_id?: number }>(`chat?id=${leadId}&after=${lastId.current}`);
      if (r.me_id) setMeId(r.me_id);
      // v137: messages deleted since (by anyone) → shown as deleted here too
      if (r.deleted?.length && !reset) { const dm = new Map(r.deleted.map(d => [d.id, d.deleted_by])); if (msgsRef.current.some(m => dm.has(m.id) && !m.deleted_at)) setMsgs(prev => prev.map(m => dm.has(m.id) && !m.deleted_at ? { ...m, deleted_at: Date.now(), deleted_by: dm.get(m.id) } : m)); }
      setReadUpto(r.read_upto || 0); setDeliveredUpto(r.delivered_upto || 0);
      setLead(r.lead); setMeta({ sales: r.sales, topups: r.topups, capi: r.capi }); onLeadRef.current?.(r.lead);
      if (reset) setMsgs(byTime(r.messages));
      else if (r.messages.length) {
        // Two loads can overlap (after sending + the 2.5s refresh) and bring the same message — add each id only once.
        const have = new Set(msgsRef.current.filter(m => m.id > 0).map(m => m.id));
        const fresh = r.messages.filter(m => !have.has(m.id));
        setMsgs(prev => {
          const ids = new Set(prev.filter(m => m.id > 0).map(m => m.id));
          return byTime([...prev.filter(m => m.id > 0 || m.failed || m.pending), ...r.messages.filter(m => !ids.has(m.id))]);
        });
        const el = box.current;
        if (el && el.scrollHeight - el.scrollTop - el.clientHeight > 120) setNewCount(c => c + fresh.filter(m => m.dir === 'in').length);
      }
      // v139: the cursor is the highest id seen (rows imported later can be older in time, so not the last one shown)
      lastId.current = Math.max(lastId.current, r.cursor || 0, ...r.messages.map(m => m.id));
    } catch (e) { if (reset) toast((e as Error).message, 'err'); }
  }, [api, leadId, toast]);

  useEffect(() => { setMsgs([]); setLead(null); void load(true); }, [leadId, load]);
  useInterval(() => void load(), 2500);
  // v167: payment link messages show as a card — their live status comes from the chat's links (display only)
  const [pls, setPls] = useState<Map<string, PayLinkLite>>(new Map());
  const plAsked = useRef(0);
  const loadPls = useCallback(async () => {
    plAsked.current = Date.now();
    try { const r = await api<{ links: PayLinkLite[] }>('paylinks?lead_id=' + leadId); setPls(new Map((r.links || []).map(l => [l.code, l]))); } catch { /* the plain line stays */ }
  }, [api, leadId]);
  const plCodes = msgs.filter(m => m.dir === 'sys' && !m.deleted_at).map(m => parsePayMsg(m.text)?.code).filter(Boolean) as string[];
  const plMissing = plCodes.some(c => !pls.has(c));
  const plOpen = plCodes.some(c => { const l = pls.get(c); return !!l && (l.status === 'new' || l.status === 'pending_payment'); });
  // senior-ui: a link made within 4 s of the last fetch was skipped and never fetched again (no new message) → try again when the 4 s are up
  useEffect(() => {
    if (!plMissing) return;
    const wait = 4000 - (Date.now() - plAsked.current);
    if (wait <= 0) { void loadPls(); return; }
    const t = setTimeout(() => void loadPls(), wait + 50);
    return () => clearTimeout(t);
  }, [plMissing, loadPls, msgs.length]);
  useInterval(() => void loadPls(), plOpen ? 15000 : null);
  // cards are taller than the plain line: keep the chat pinned to the newest message when they appear
  useLayoutEffect(() => { const el = box.current; if (el && atBottom) el.scrollTop = el.scrollHeight; }, [pls]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => { msgs.forEach(m => seenMsg.current.add(m.id)); if (msgs.length || lead) loadedOnce.current = true; });
  useLayoutEffect(() => {
    const el = box.current; if (!el) return;
    if (first.current && msgs.length) { el.scrollTop = el.scrollHeight; first.current = false; return; }
    if (atBottom) el.scrollTo({ top: el.scrollHeight, behavior: 'smooth' });
  }, [msgs, atBottom]);
  // v168 F3: the list's own size changes (Coach button / dock / coach panel / keyboard appear) → stay on the newest message,
  // so nothing that floats over the bottom ever covers the last lines (e.g. "Admin marked this chat: no reply needed…")
  const atBottomRef = useRef(true); atBottomRef.current = atBottom;
  useEffect(() => {
    const el = box.current; if (!el || typeof ResizeObserver === 'undefined') return;
    let h = el.clientHeight;
    const ro = new ResizeObserver(() => { if (el.clientHeight !== h) { h = el.clientHeight; if (atBottomRef.current) el.scrollTop = el.scrollHeight; } });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  useEffect(() => {
    if (!rec) return;
    const id = setInterval(() => setRecSec(Math.floor((Date.now() - rec.start) / 1000)), 250);
    return () => clearInterval(id);
  }, [rec]);

  const onScroll = () => {
    const el = box.current!; const b = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
    setAtBottom(b); if (b) setNewCount(0);
  };
  const toBottom = () => { box.current?.scrollTo({ top: box.current.scrollHeight, behavior: 'smooth' }); setNewCount(0); };

  async function send(t = text, retryRt?: number | null, cid = `${leadId}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`) {
    const body = t.trim();
    if (!body) return;
    if (retryRt === undefined) { setText(''); if (ta.current) ta.current.style.height = 'auto'; }
    const rt = retryRt !== undefined ? retryRt : replyTo?.id ?? null; if (retryRt === undefined) setReplyTo(null);
    const tmp: Msg = { id: -Date.now(), dir: 'out', sender: role, text: body, file_id: null, file_type: null, file_name: null, created_at: Date.now(), pending: true, reply_to: rt, cid };
    setMsgs(p => [...p, tmp]); setAtBottom(true);
    if (picked.current) { const sg = picked.current; picked.current = ''; void api('ai_feedback', { lead_id: leadId, suggested: sg, sent: body }).catch(() => {}); }
    // bh2 #8: same cid on "send again" → the server never sends it twice; the pending bubble survives the poll and is removed here on success
    try { await api('send', { lead_id: leadId, text: body, reply_to: rt, cid }); setMsgs(p => p.filter(m => m.id !== tmp.id)); await load(); onChanged?.(); }
    catch (e) { setMsgs(p => p.map(m => (m.id === tmp.id ? { ...m, pending: false, failed: true } : m))); toast((e as Error).message, 'err'); }
  }

  async function doUpload(file: File, kind?: string, caption = '', cid = `${leadId}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`) {
    const fd = new FormData();
    fd.append('lead_id', String(leadId)); fd.append('file', file, file.name || 'file'); fd.append('cid', cid); // v134: same id on "send again" → never sent twice
    if (caption) fd.append('caption', caption);
    if (kind) fd.append('kind', kind);
    const tmp: Msg = { id: -Date.now(), dir: 'out', sender: role, text: caption || `Sending ${file.name || 'file'}…`, file_id: null, file_type: null, file_name: null, created_at: Date.now(), pending: true };
    setMsgs(p => [...p, tmp]); setAtBottom(true);
    try { await api('upload', fd); setMsgs(p => p.filter(m => m.id !== tmp.id)); await load(); onChanged?.(); }
    catch (e) {
      const d = (e as Error & { data?: Record<string, any> }).data || {};
      // voice notes turned off by the customer → no retry (it can never go); their words go to the message box as text
      if (d.voice_off) { setMsgs(p => p.filter(m => m.id !== tmp.id)); if (d.text) { setText(String(d.text)); setTimeout(() => ta.current?.focus(), 30); } toast((e as Error).message, 'err'); return; }
      setMsgs(p => p.map(m => (m.id === tmp.id ? { ...m, pending: false, failed: true, text: 'Not sent: ' + (file.name || 'file'), retryUpload: { file, kind, caption, cid } } : m)));
      toast((e as Error).message, 'err');
    }
  }

  function pick(f: File | undefined) {
    if (!f) return;
    setSheet(null);
    setUpload({ file: f, url: URL.createObjectURL(f), asFile: false, caption: '' });
  }

  async function toggleRec() {
    if (rec) { rec.mr.stop(); return; }
    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === 'undefined') return toast('Voice recording is not supported on this device', 'err');
    try {
      const st = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mt = ['audio/ogg;codecs=opus', 'audio/mp4', 'audio/webm;codecs=opus', 'audio/webm'].find(x => MediaRecorder.isTypeSupported?.(x)) || '';
      const mr = new MediaRecorder(st, mt ? { mimeType: mt } : undefined);
      const chunks: Blob[] = [];
      mr.ondataavailable = e => e.data.size && chunks.push(e.data);
      mr.onstop = () => {
        st.getTracks().forEach(t => t.stop());
        const type = mr.mimeType || 'audio/webm';
        setRec(null); setRecSec(0);
        const blob = new Blob(chunks, { type });
        if (blob.size < 1500) return toast('Hold on a little longer to record', 'err');
        const ext = type.includes('ogg') ? 'ogg' : type.includes('mp4') ? 'm4a' : 'webm';
        void doUpload(new File([blob], `voice.${ext}`, { type }), ext === 'webm' ? 'audio' : 'voice');
      };
      mr.start(); setRec({ mr, start: Date.now() });
    } catch { toast('Allow microphone access to record voice messages', 'err'); }
  }

  async function setStatus(st: 'dead' | 'active') {
    try { await api('lead_status', { lead_id: leadId, status: st }); toast(st === 'dead' ? 'Moved to Dead' : 'Chat reopened'); await load(true); onChanged?.(); }
    catch (e) { toast((e as Error).message, 'err'); }
  }

  const name = lead ? leadName(lead) : '…';
  const fuDue = !!(lead && lead.fu_due && lead.status === 'active');
  const seen = lead ? seenText((lead as { seen_state?: string | null }).seen_state, (lead as { seen_at?: number | null }).seen_at) : '';
  const subline = !lead ? '' : seen && lead.status !== 'sold' && lead.status !== 'dead' ? seen : lead.status === 'sold' ? 'customer · sold' : lead.status === 'dead' ? ((lead as { dead_reason?: string | null }).dead_reason === 'followups' ? 'dead · no reply after follow-ups' : (lead as { dead_reason?: string | null }).dead_reason === 'inactive' ? 'dead · no messages for 7 days' : (lead as { dead_reason?: string | null }).dead_reason === 'deleted' ? 'dead · deleted by admin (records kept)' : 'dead') : lead.tg_username ? '@' + lead.tg_username : lead.phone || 'Telegram';
  const remindDue = !!lead?.remind_due;
  const remindAt = lead?.remind_at && lead.remind_at > Date.now() ? lead.remind_at : 0;
  async function cancelRemind() {
    try { await api('remind', { lead_id: leadId, at: 0 }); toast('Reminder cancelled'); await load(true); onChanged?.(); } catch (e) { toast((e as Error).message, 'err'); }
  }
  const menuItems = lead ? [
    { label: 'Lead details', onClick: () => setSheet('info') },
    ...(barHas.includes('remind') ? [] : [{ label: remindAt ? 'Change reminder' : 'Remind me later', onClick: () => setSheet('remind') }]),
    ...(extraMenu ? extraMenu(lead, () => { void load(true); onChanged?.(); }) : []),
    ...(canRetype || role === 'admin' ? [{ label: 'Change type (Agency / Premium / Funnel)', onClick: () => setSheet('ltype') }] : []),
    ...(role === 'admin' && !barHas.includes('assign') ? [{ label: lead.agent_id ? 'Assign to another agent' : 'Assign to an agent', onClick: () => setSheet('reassign') }] : []),
    // v146: Sold chats can be moved to Dead too (owner / manager); a reopened chat with a sale goes back to Sold
    ...(lead.status === 'dead' ? [{ label: 'Reopen chat', onClick: () => setStatus('active') }] : lead.status === 'sold' && !(canRetype || role === 'admin') ? [] : [{ label: 'Move to Dead', onClick: () => { if (confirm(lead.status === 'sold' ? 'This customer bought from us. Move the chat to Dead? Sales and records stay; automatic messages stop until they write again.' : 'Move this chat to Dead?')) void setStatus('dead'); } }]),
  ] : [];

  const byId = new Map(msgs.map(m => [m.id, m] as const));
  // v136: only bubbles that arrive after the first load animate (incoming, or ours while sending); polling never re-animates
  const newIds = new Set<number>();
  if (loadedOnce.current) for (const m of msgs) if (!seenMsg.current.has(m.id) && (m.dir === 'in' || m.id < 0)) newIds.add(m.id);
  const isNewMsg = (m: Msg) => newIds.has(m.id);
  // a failed file is sent again as the same file — never as the "Not sent: …" text
  const retry = (m: Msg) => { setMsgs(p => p.filter(x => x.id !== m.id)); if (m.retryUpload) void doUpload(m.retryUpload.file, m.retryUpload.kind, m.retryUpload.caption, m.retryUpload.cid); else void send(m.text, m.reply_to ?? null, m.cid); };
  const pickReply = (m: Msg) => { setReplyTo(m); setTimeout(() => ta.current?.focus(), 30); };
  // v137: who may delete which message: an agent only his own (48 h); the manager and the admin any of ours
  const canDel = (m: Msg) => m.dir === 'out' && m.id > 0 && !m.deleted_at && !m.pending && (role === 'admin' || !!canRetype || (m.sender === 'agent' && (meId == null || m.agent_id === meId) && Date.now() - m.created_at < 48 * 3600000));
  const jumpTo = (id: number) => { const el = document.getElementById('m' + id); if (!el) return; el.scrollIntoView({ behavior: 'smooth', block: 'center' }); el.animate?.([{ background: 'rgba(95,184,255,.25)' }, { background: 'transparent' }], { duration: 1400 }); };
  // group by day — each day is its own block, so its sticky date only sticks while that day is on screen (no stacked dates)
  const days: { day: string; rows: { m: Msg; tail: boolean }[] }[] = [];
  msgs.forEach((m, i) => {
    const d = dayLabel(m.created_at);
    if (!days.length || days[days.length - 1].day !== d) days.push({ day: d, rows: [] });
    const next = msgs[i + 1];
    days[days.length - 1].rows.push({ m, tail: !next || next.dir !== m.dir || dayLabel(next.created_at) !== d });
  });

  const phoneDigits = (lead?.phone || '').replace(/\D/g, '');
  // v167: one row of quick chips over the bottom of the chat — a tap fills the box, never sends
  // v168 (owner): only the Coach button stays there (a light ghost button); product info + quick replies are under ⚡ only
  const chips: { k: string; label: React.ReactNode; on: () => void; coach?: boolean }[] = lead?.read_only || rec || sheet === 'quick' ? [] : [
    ...(coachOk && !coachOpen ? [{ k: 'coach', label: <><Sparkles size={14} aria-hidden />Coach</>, on: () => setCoachOpen(true), coach: true }] : []),
  ];
  const chipsOn = chips.length > 0 && !text;
  // v168 F3: the Coach button appearing adds bottom padding → keep the newest message in view
  useLayoutEffect(() => { const el = box.current; if (el && atBottomRef.current) el.scrollTop = el.scrollHeight; }, [chipsOn]);

  return (
    <div className={clsx('af-chat-in flex h-full min-h-0 flex-col bg-tg-bg', wa && 'wa-light text-tg-text')} data-wa={wa ? '1' : undefined}>
      {/* header */}
      <div className="relative z-30 flex items-center gap-2 bg-tg-panel px-2 pb-2 pt-[calc(8px+env(safe-area-inset-top))] shadow-[0_1px_0_rgb(var(--tg-line))]">
        <button onClick={onBack} className="grid h-10 w-10 place-items-center rounded-full text-tg-text hover:bg-tg-hover md:hidden" aria-label="Back"><ArrowLeft size={22} /></button>
        <button onClick={() => setSheet('info')} className="flex min-w-0 flex-1 items-center gap-3 rounded-xl px-1 py-0.5 text-left md:pl-3">
          <Avatar name={name} id={leadId} size={40} />
          <span className="min-w-0 pl-0.5">
            <span className="block truncate text-[16.5px] font-semibold leading-tight text-tg-text">{name}</span>
            {lead?.cover_label && <span data-cover-chip className="mt-0.5 inline-flex max-w-full items-center gap-1 truncate rounded-full bg-tg-orange/15 px-2 py-px text-[11.5px] font-semibold text-tg-orange"><LifeBuoy size={12} aria-hidden />{lead.cover_label}</span>}
            {/* v167: plain line "Agency · Telegram · last seen …" — only the type word is coloured */}
            <span className="block min-w-0 truncate text-[13px] text-tg-sub" data-chat-sub>{lead && <><TierWord l={lead as Parameters<typeof TierWord>[0]["l"]} /><span aria-hidden> · </span>{wa ? 'WhatsApp' : 'Telegram'}{(remindDue || fuDue || (subline && subline !== 'Telegram')) && <span aria-hidden> · </span>}</>}<span className={clsx(fuDue || remindDue ? 'font-medium text-tg-orange' : '')}>{remindDue ? 'reminder due' : fuDue ? `follow-up ${lead!.fu_stage} due` : subline === 'Telegram' ? '' : subline}</span></span>
          </span>
        </button>
        <button onClick={() => setSheet('call')} className="grid h-10 w-10 place-items-center rounded-full text-tg-sub hover:bg-tg-hover hover:text-tg-text" aria-label="Call"><Phone size={20} /></button>
        <div className="relative">
          <button onClick={() => setMenu(v => !v)} className="grid h-10 w-10 place-items-center rounded-full text-tg-sub hover:bg-tg-hover hover:text-tg-text" aria-label="More"><MoreVertical size={20} /></button>
          {menu && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setMenu(false)} />
              <div className="af-menu absolute right-1 top-11 z-50 min-w-[230px] overflow-hidden rounded-xl bg-tg-menu py-1.5 shadow-2xl ring-1 ring-tg-line" role="menu">
                {menuItems.map((it, i) => (
                  <button key={it.label} role="menuitem" onClick={() => { setMenu(false); it.onClick(); }} className={clsx('block w-full px-4 py-3 text-left text-[15px] hover:bg-tg-hover active:bg-tg-hover', it.danger ? 'text-tg-bad' : 'text-tg-text', it.danger && i > 0 && !menuItems[i - 1].danger && 'border-t border-tg-sep')}>{it.label}</button>
                ))}
              </div>
            </>
          )}
        </div>
      </div>


      {/* what to charge in THIS chat — Premium chats have their own prices */}
      {wa && <div data-wa-window className={clsx('flex items-center gap-1.5 px-3 py-1.5 text-[12.5px]', waLeft > 0 ? 'bg-[#d9fdd3] text-[#0a5c45]' : 'bg-[#fdecea] text-[#b3261e]')}>
        <MessageCircle size={13} className="shrink-0" />
        {waLeft > 0 ? <span>WhatsApp · reply window open · {Math.floor(waLeft / 3600000)}h {Math.floor(waLeft % 3600000 / 60000)}m left</span> : <span>WhatsApp · 24-hour window closed. Message them from the WhatsApp Business app on your phone; when they reply, the chat opens here again.</span>}
      </div>}
      {lead && <InfoStrip lead={lead} light={wa} openLinks={[...pls.values()].filter(l => l.status === 'new' || l.status === 'pending_payment').length} />}

      {/* reminder bars */}
      {remindDue && (
        <div className="flex items-center gap-3 border-l-[3px] border-tg-orange bg-tg-panel px-3 py-2">
          <AlarmClock size={16} className="shrink-0 text-tg-orange" />
          <span className="min-w-0 flex-1"><span className="block text-[13px] font-semibold text-tg-orange">Reminder due</span><span className="block truncate text-[13px] text-tg-sub">You asked to be reminded about this chat. Send them a message.</span></span>
        </div>
      )}
      {!!remindAt && (
        <div className="flex items-center gap-3 border-l-[3px] border-tg-acc bg-tg-panel px-3 py-2">
          <AlarmClock size={16} className="shrink-0 text-tg-link" />
          <button onClick={() => setSheet('remind')} className="min-w-0 flex-1 text-left"><span className="block text-[13px] font-semibold text-tg-link">Reminder · {remindLabel(remindAt)}</span><span className="block truncate text-[13px] text-tg-sub">{lead?.remind_note || 'Follow-ups are paused until then.'}</span></button>
          <button onClick={() => void cancelRemind()} className="grid h-8 w-8 place-items-center rounded-full text-tg-sub hover:bg-tg-hover" aria-label="Cancel reminder"><XIcon size={16} /></button>
        </div>
      )}

      {/* pinned follow-up bar */}
      {fuDue && !remindDue && (
        <button onClick={() => { const t = followups[Math.max(0, Math.min(2, lead!.fu_stage - 1))] || ''; setText(t.replace(/\{name\}/g, (lead!.name || lead!.tg_name || 'there').split(' ')[0])); ta.current?.focus(); }}
          className="flex items-center gap-3 border-l-[3px] border-tg-orange bg-tg-panel px-3 py-2 text-left">
          <Pin size={16} className="shrink-0 text-tg-orange" />
          <span className="min-w-0 flex-1"><span className="block text-[13px] font-semibold text-tg-orange">Follow-up #{lead!.fu_stage} due</span><span className="block truncate text-[13px] text-tg-sub">The lead has been quiet. Tap to write a follow-up.</span></span>
        </button>
      )}

      {/* messages */}
      <div className="relative min-h-0 flex-1">
        <div ref={box} onScroll={onScroll} className={clsx('h-full overflow-y-auto px-2.5 pt-3 md:px-[6%]', !wa && 'tg-wall ag-wall', /* v168 F3: ONE padding class — pb-3 + pb-12 together let pb-3 win, so the Coach button covered the last message */ chipsOn ? 'pb-14' : 'pb-3')} style={wa ? { backgroundImage: WA_WALLPAPER } : { ['--wall-d' as string]: WALLPAPER, ['--wall-l' as string]: WALLPAPER_LIGHT } as React.CSSProperties}>
          <div className="mx-auto flex max-w-[760px] flex-col gap-[3px]">
            {!lead && <div className="p-3"><Skeleton rows={3} h={68} /></div>}
            {days.map(g => (
              <div key={g.day} className="flex flex-col gap-[3px]">
                <div className="tg-pill sticky top-1 z-20 my-2 self-center rounded-full px-3 py-1 text-[13px] font-medium" data-day-pill>{g.day}</div>
                {g.rows.map(r => <div key={r.m.id} className={clsx(r.tail && 'mb-1.5', isNewMsg(r.m) && 'af-msg')}><div id={'m' + r.m.id}>{(() => { const pm = r.m.dir === 'sys' && !r.m.deleted_at ? parsePayMsg(r.m.text) : null; const pl = pm ? pls.get(pm.code) : undefined; return pm && pl ? <PayCard m={r.m} p={pm} l={pl} /> : null; })() || <Bubble m={r.m} showAgent={role === 'admin' || showAgents || (r.m.sender === 'agent' && meId != null && r.m.agent_id != null && r.m.agent_id !== meId)} tail={r.tail} read={!!r.m.read_at || (r.m.id > 0 && r.m.id <= readUpto)} delivered={wa && (!!r.m.delivered_at || (r.m.id > 0 && r.m.id <= deliveredUpto))} quoted={r.m.reply_to ? byId.get(r.m.reply_to) : undefined} onReply={pickReply} onQuote={jumpTo} onRetry={retry} onMenu={canDel(r.m) ? setDelMsg : undefined} />}</div></div>)}
              </div>
            ))}
          </div>
        </div>
        {chipsOn && <div className="pointer-events-none absolute inset-x-0 bottom-2 z-10 md:px-[6%]" data-quick-chips>
          <div className="pointer-events-auto flex gap-1.5 overflow-x-auto px-2.5 [mask-image:linear-gradient(to_right,#000_calc(100%-24px),transparent)] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            {chips.map(c => <button key={c.k} type="button" onClick={c.on} {...(c.coach ? { 'data-coach-btn': '', 'aria-label': 'Coach: reply ideas for this chat' } : {})}
              className="af-press af-ghost flex h-8 max-w-[220px] shrink-0 items-center gap-1 truncate rounded-full px-3 text-[13px] font-medium text-tg-link"><span className="flex min-w-0 items-center gap-1 truncate">{c.label}</span></button>)}
          </div>
        </div>}
        {!atBottom && (
          <button onClick={toBottom} className={clsx('absolute right-3 z-20 grid h-11 w-11 place-items-center rounded-full bg-tg-panel text-tg-sub shadow-lg', chipsOn ? 'bottom-12' : 'bottom-3')} aria-label="Scroll to latest">
            <ChevronDown size={22} />
            {newCount > 0 && <span className="absolute -top-1.5 left-1/2 -translate-x-1/2 rounded-full bg-tg-acc px-1.5 text-[11px] font-bold text-white">{newCount}</span>}
          </button>
        )}
      </div>

      {/* quick replies */}
      {sheet === 'quick' && (quickReplies.length > 0 || productMsgs.length > 0) && (
        <div className="max-h-[45vh] overflow-y-auto border-t border-tg-line bg-tg-panel py-1" data-quick>
          {/* v160: "what's included" messages — tap to put the full text in the box, then Send */}
          {productMsgs.length > 0 && <div className="border-b border-tg-line px-3 pb-2.5 pt-1.5" data-product-msgs>
            <p className="mb-1.5 text-[12px] font-semibold uppercase tracking-wide text-tg-sub">Product info</p>
            <div className="flex flex-wrap gap-1.5">{productMsgs.map(m => <button key={m.title} onClick={() => { setText(m.text); setSheet(null); setTimeout(() => ta.current?.focus(), 50); }} className="af-press min-h-[36px] rounded-full bg-tg-acc/10 px-3 text-[13.5px] font-semibold text-tg-link ring-1 ring-inset ring-tg-acc/30">{m.title}</button>)}</div>
          </div>}
          {quickReplies.map((q, i) => (
            <button key={i} onClick={() => { setText(q); setSheet(null); setTimeout(() => ta.current?.focus(), 50); }} className="block w-full px-4 py-2.5 text-left text-[14.5px] text-tg-text hover:bg-tg-hover">{q}</button>
          ))}
        </div>
      )}

      {/* AI: this chat is answered by the AI / paused */}
      {lead?.ai_auto_agent && (
        <div className="flex items-center gap-2 border-t border-tg-line bg-tg-panel px-3 py-1.5 text-[12.5px]">
          <span className={lead.ai_active ? 'text-tg-link' : 'text-tg-sub'}><BotIcon size={14} className="-mt-0.5 mr-1 inline" />{lead.ai_active ? 'AI is answering this chat' : lead.ai_state === 'paused' ? 'AI is paused in this chat' : 'AI auto-reply is off'}</span>
          {(lead.ai_active || lead.ai_state === 'paused') && (
            <button onClick={async () => { try { await api('ai_chat_state', { lead_id: leadId, state: lead.ai_active ? 'paused' : '' }); await load(); } catch (e) { toast((e as Error).message, 'err'); } }}
              className="ml-auto rounded-full bg-tg-input px-3 py-1 font-semibold text-tg-text">{lead.ai_active ? 'Pause AI' : 'Resume AI'}</button>
          )}
        </div>
      )}
      {coachOk && coachOpen && <CoachBar api={api} leadId={leadId} onHide={() => setCoachOpen(false)} lastInId={msgs.reduce((x, m) => (m.dir === 'in' && m.id > x ? m.id : x), 0)} />}
      {/* v167: the action dock sits right above the message box (was under the header) */}
      {!lead?.read_only && actionBar && <div className="border-t border-tg-sep" data-dock><DockCtx.Provider value={{ menu: menuItems }}>{actionBar(lead, { remind: () => setSheet('remind'), assign: () => setSheet('reassign') })}</DockCtx.Provider></div>}
      {replyTo && (
        <div className="flex items-center gap-2 bg-tg-panel px-3 pt-2">
          <span className="text-tg-link"><Reply size={18} /></span>
          <button onClick={() => jumpTo(replyTo.id)} className="min-w-0 flex-1 border-l-[3px] border-tg-link pl-2 text-left">
            <span className="block text-[12.5px] font-semibold text-tg-link">Reply to {replyTo.dir === 'in' ? 'customer' : 'your message'}</span>
            <span className="line-clamp-1 text-[13.5px] text-tg-sub">{quoteText(replyTo)}</span>
          </button>
          <button onClick={() => setReplyTo(null)} className="grid h-8 w-8 place-items-center text-tg-sub" aria-label="Cancel reply"><XIcon size={18} /></button>
        </div>
      )}
      {/* composer — v141: read-only for the owner while a cover agent has the chat */}
      {lead?.read_only ? (
        <div data-readonly className="flex items-center gap-2 bg-tg-panel px-4 pb-[calc(12px+env(safe-area-inset-bottom))] pt-3 text-[13.5px] text-tg-sub"><LifeBuoy size={17} className="shrink-0 text-tg-orange" aria-hidden /><span>{lead.cover_label}. You can read this chat; {lead.covered_by} answers it until it comes back to you.</span></div>
      ) : (
      <div className="flex items-end gap-1.5 bg-tg-panel px-2 pb-[calc(8px+env(safe-area-inset-bottom))] pt-2">
        {rec ? (
          <div className="flex h-11 flex-1 items-center gap-3 rounded-2xl bg-tg-input px-4 text-tg-text">
            <span className="h-2.5 w-2.5 animate-pulse rounded-full bg-tg-red" /> Recording {fmtDur(recSec)}
            <button onClick={() => { rec.mr.onstop = () => { rec.mr.stream.getTracks().forEach(t => t.stop()); setRec(null); setRecSec(0); }; rec.mr.stop(); }} className="ml-auto text-[14px] font-semibold text-tg-red">Cancel</button>
          </div>
        ) : (
          <>
            {coachOk && !coachOpen && !chipsOn && <button onClick={() => setCoachOpen(true)} data-coach-btn className="af-press mb-1.5 grid h-8 w-8 shrink-0 place-items-center rounded-full bg-tg-accsoft text-tg-link" aria-label="Coach: reply ideas for this chat"><Sparkles size={15} aria-hidden /></button>}
            <button onClick={() => setSheet('attach')} className="grid h-11 w-11 shrink-0 place-items-center rounded-full text-tg-sub hover:text-tg-text" aria-label="Attach"><Paperclip size={22} /></button>
            <div className="flex min-h-11 min-w-0 flex-1 items-end rounded-[22px] bg-tg-input">
              <textarea ref={ta} rows={1} value={text} placeholder="Message"
                onChange={e => { setText(e.target.value); e.target.style.height = 'auto'; e.target.style.height = Math.min(e.target.scrollHeight, 140) + 'px'; }}
                onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey && window.innerWidth >= 768) { e.preventDefault(); void send(); } }}
                className="max-h-[140px] min-h-11 w-full min-w-0 flex-1 resize-none bg-transparent px-4 py-[11px] text-[16px] leading-[1.35] text-tg-text outline-none placeholder:text-tg-sub" />
              {(quickReplies.length > 0 || productMsgs.length > 0) && (
                <button onClick={() => setSheet(s => (s === 'quick' ? null : 'quick'))} className={clsx('grid h-11 w-10 place-items-center', sheet === 'quick' ? 'text-tg-link' : 'text-tg-sub hover:text-tg-text')} aria-label="Quick replies"><Zap size={20} /></button>
              )}
            </div>
          </>
        )}
        {text.trim() && !rec ? (
          <button onClick={() => void send()} className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-tg-acc text-white" aria-label="Send"><Send size={20} className="-ml-0.5" /></button>
        ) : (
          <button onClick={() => void toggleRec()} className={clsx('grid h-11 w-11 shrink-0 place-items-center rounded-full', rec ? 'bg-tg-acc text-white' : 'text-tg-sub hover:text-tg-text')} aria-label={rec ? 'Send voice message' : 'Record voice message'}>
            {rec ? <Send size={20} className="-ml-0.5" /> : <Mic size={22} />}
          </button>
        )}
      </div>
      )}

      <input ref={photoIn} type="file" accept="image/*,video/*" hidden onChange={e => { pick(e.target.files?.[0]); e.target.value = ''; }} />
      <input ref={fileIn} type="file" hidden onChange={e => { pick(e.target.files?.[0]); e.target.value = ''; }} />

      <Sheet open={sheet === 'attach'} onClose={() => setSheet(null)} title="Send">
        <div className="grid grid-cols-2 gap-3">
          <button onClick={() => photoIn.current?.click()} className="flex flex-col items-center gap-2 rounded-2xl bg-tg-input py-5 text-tg-text hover:bg-tg-hover"><span className="grid h-12 w-12 place-items-center rounded-full bg-[#3A8BD8] text-white"><ImageIcon size={22} /></span>Photo or video</button>
          <button onClick={() => fileIn.current?.click()} className="flex flex-col items-center gap-2 rounded-2xl bg-tg-input py-5 text-tg-text hover:bg-tg-hover"><span className="grid h-12 w-12 place-items-center rounded-full bg-[#4FAE4E] text-white"><FileText size={22} /></span>File</button>
        </div>
      </Sheet>

      <Sheet open={!!upload} onClose={() => setUpload(null)} title={upload?.file.type.startsWith('image/') ? 'Send photo' : upload?.file.type.startsWith('video/') ? 'Send video' : 'Send file'}>
        {upload && (
          <>
            {upload.file.type.startsWith('image/') ? <img src={upload.url} alt="" className="mx-auto mb-4 max-h-[50vh] rounded-xl" />
              : upload.file.type.startsWith('video/') ? <video src={upload.url} controls playsInline className="mx-auto mb-4 max-h-[50vh] rounded-xl" />
                : <div className="mb-4 flex items-center gap-3 rounded-xl bg-tg-input p-3"><FileText className="text-tg-link" /><span className="min-w-0"><span className="block truncate">{upload.file.name}</span><span className="text-[12px] text-tg-sub">{(upload.file.size / 1048576).toFixed(1)} MB</span></span></div>}
            <input className={inputCls} placeholder="Add a caption" value={upload.caption} onChange={e => setUpload({ ...upload, caption: e.target.value })} />
            {/* v168: WhatsApp photos always go at full quality → the toggle only on Telegram */}
            {!wa && (upload.file.type.startsWith('image/') || upload.file.type.startsWith('video/')) && (
              <label className="mt-3 flex items-center gap-2 text-[14px] text-tg-sub"><input type="checkbox" checked={upload.asFile} onChange={e => setUpload({ ...upload, asFile: e.target.checked })} /> Send without compression</label>
            )}
            <Btn className="mt-4 w-full" onClick={() => { const u = upload; setUpload(null); void doUpload(u.file, u.asFile ? 'document' : undefined, u.caption); }}>Send</Btn>
          </>
        )}
      </Sheet>

      <Sheet open={sheet === 'call'} onClose={() => setSheet(null)} title={`Contact ${name}`}>
        <div className="grid gap-2.5">
          {phoneDigits ? (
            <>
              <a href={`tel:+${phoneDigits}`} className="flex items-center gap-3 rounded-xl bg-tg-input px-4 py-3.5 text-tg-text hover:bg-tg-hover"><Phone size={20} className="text-tg-green" /> Phone call · {lead?.phone}</a>
              <button onClick={() => void openWhatsApp(phoneDigits, lead?.wa_text)} className="flex items-center gap-3 rounded-xl bg-tg-input px-4 py-3.5 text-left text-tg-text hover:bg-tg-hover"><MessageCircle size={20} className="text-[#25D366]" /> WhatsApp chat or call</button>
            </>
          ) : <p className="rounded-xl bg-tg-input px-4 py-3 text-[14px] text-tg-sub">No phone number. This person messaged on Telegram directly.</p>}
          {lead?.tg_username && <button onClick={() => void openExternal(`https://t.me/${lead.tg_username}`)} className="flex items-center gap-3 rounded-xl bg-tg-input px-4 py-3.5 text-left text-tg-text hover:bg-tg-hover"><Send size={18} className="text-tg-link" /> Open @{lead.tg_username} in Telegram</button>}
          <p className="px-1 pt-1 text-[12.5px] leading-relaxed text-tg-sub">Telegram doesn’t allow calls from apps or bots. Call by phone or WhatsApp, or send a voice message.</p>
        </div>
      </Sheet>

      {/* v137: delete one of our messages (Telegram: for everyone; WhatsApp: hidden for us only, the API can't delete it) */}
      <Sheet open={!!delMsg} onClose={() => setDelMsg(null)} title={wa ? 'Delete for us' : 'Delete for everyone'}>
        {delMsg && (
          <div data-del-sheet>
            <p className="mb-3 line-clamp-3 rounded-xl bg-tg-input px-3 py-2 text-[14px] text-tg-text">{delMsg.text || (delMsg.file_type ? `[${delMsg.file_type}]` : '')}</p>
            {wa
              ? <p className="mb-3 flex gap-2 rounded-xl bg-tg-orange/12 px-3 py-2.5 text-[13px] text-tg-text"><Info size={16} className="mt-0.5 shrink-0 text-tg-orange" /><span>WhatsApp doesn’t allow deleting for the customer through the API. This only hides it in our apps. To remove it for the customer, delete it from the WhatsApp Business app on the phone within 2 days.</span></p>
              : <p className="mb-3 text-[13px] text-tg-sub">The message is removed from the customer’s Telegram too. Only messages from the last 48 hours.</p>}
            <div className="grid grid-cols-2 gap-2">
              <Btn kind="ghost" onClick={() => setDelMsg(null)}>Cancel</Btn>
              <Btn kind="danger" onClick={async () => {
                const m = delMsg; setDelMsg(null);
                try {
                  const r = await api<{ ok: boolean; mode: string }>('msg_delete', { id: m.id });
                  setMsgs(p => p.map(x => x.id === m.id ? { ...x, deleted_at: Date.now(), deleted_by: role === 'admin' ? 'Admin' : 'you' } : x));
                  toast(r.mode === 'us' ? 'Hidden in our apps (still on the customer’s WhatsApp)' : 'Deleted for everyone');
                } catch (e) { toast((e as Error).message, 'err'); }
              }}>{wa ? 'Delete for us' : 'Delete for everyone'}</Btn>
            </div>
          </div>
        )}
      </Sheet>
      <RemindSheet open={sheet === 'remind'} onClose={() => setSheet(null)} current={remindAt} note={lead?.remind_note || ''}
        onSave={async (at, note) => { try { await api('remind', { lead_id: leadId, at, note }); toast(at ? `Reminder set: ${remindLabel(at)}` : 'Reminder cancelled'); setSheet(null); await load(true); onChanged?.(); } catch (e) { toast((e as Error).message, 'err'); } }} />
      <Sheet open={sheet === 'info'} onClose={() => setSheet(null)} title="Lead details">
        {lead && (
          <div className="text-[14.5px]">
            <div className="mb-4 flex items-center gap-3"><Avatar name={name} id={leadId} size={56} /><div><p className="text-[18px] font-semibold">{name}</p><p className="text-tg-sub">#{lead.id} · {lead.status === 'active' ? 'talking' : lead.status === 'new' ? 'form only' : lead.status}</p></div></div>
            {([
              ['Phone', lead.phone], ['Email', lead.email], ['Telegram', lead.tg_username ? '@' + lead.tg_username : lead.tg_name],
              ['Wants', lead.service === 'funnel' ? 'Landing page + funnel' : lead.source === 'telegram' ? '—' : 'Ad account'],
              ['Has BM', lead.has_bm], ['Advertises', lead.niche], ['Daily budget', lead.budget],
              ['Came from', lead.source === 'telegram' ? 'Telegram directly' : lead.source === 'channel' ? 'Telegram channel' : `Landing page${lead.theme ? ` (${lead.theme})` : ''}`],
              ['Campaign', lead.camp || (lead.camp === '' ? 'not tagged' : null)], ['Ad set', lead.adset], ['Ad', lead.ad],
              ['First contact', lead.created_at ? new Date(lead.created_at).toLocaleString() : ''],
              ...(role === 'admin' ? [['Agent', lead.agent_name || 'Unassigned'], ['Ad click id (fbc)', lead.fbc ? 'saved ✓' : 'not available']] : []),
              ['Sales', meta.sales.length ? `${meta.sales.length} · ${usd(meta.sales.reduce((a, x) => a + x.amount, 0))}` : 'none'],
              ['Topups', meta.topups.length ? `${meta.topups.length} · ${usd(meta.topups.reduce((a, x) => a + x.amount, 0))}` : 'none'],
              ...(lead.cover_label ? [['Cover', lead.cover_label]] : []),
              // v141: who sold it in a covered chat, and the 50/50 split after a cover
              ...meta.sales.map((x, i) => [`Sale ${i + 1}`, [x.list_price > 0 ? `Special price ($${Math.round(x.amount / Math.max(1, x.qty || 1) * 100) / 100} instead of $${x.list_price})` : '', x.cover_note, x.split_reason].filter(Boolean).join(' · ')]),
            ] as [string, string | null][]).filter(([, v]) => v).map(([k, v]) => (
              <div key={k} className="flex justify-between gap-4 border-b border-tg-line py-2.5"><span className="text-tg-sub">{k}</span><span className="text-right">{v}</span></div>
            ))}
            {role === 'admin' && meta.capi && (
              <div className="pt-3">
                <p className="mb-2 text-[13px] text-tg-sub">Meta events for this lead</p>
                <div className="flex flex-wrap gap-2">{meta.capi.length ? meta.capi.map(c => <span key={c.event_id} className={clsx('rounded-full px-2.5 py-1 text-[12.5px]', c.status === 'sent' ? 'bg-tg-green/15 text-tg-ok' : c.status === 'skipped' ? 'bg-tg-orange/15 text-tg-orange' : 'bg-tg-red/15 text-tg-bad')}>{c.event_name}: {c.status}</span>) : <span className="text-tg-sub">none yet</span>}</div>
              </div>
            )}
          </div>
        )}
      </Sheet>

      <Sheet open={sheet === 'ltype'} onClose={() => setSheet(null)} title="Which ad / type is this chat?">
        <p className="mb-3 text-[14px] text-tg-sub">For chats that came without an ad, or from the wrong one. Changes the badge, the prices and quick replies in this chat, and which line its sales count under in Stats.</p>
        <div className="grid gap-1.5">
          {([['agency', 'Agency', 'Normal ad account chat'], ['premium', 'Premium', 'Premium ad account chat'], ['funnel', 'Funnel', 'Landing page + funnel chat']] as const).map(([k, l, d]) => {
            const cur = lead ? (lead.biz === 'funnel' ? 'funnel' : lead.tier === 'premium' ? 'premium' : 'agency') : '';
            return (
              <button key={k} disabled={k === cur} onClick={async () => { setSheet(null); try { await api('lead_type', { lead_id: leadId, type: k }); toast(`Marked as ${l}`); await load(true); onChanged?.(); } catch (e) { toast((e as Error).message, 'err'); } }}
                className="flex items-center gap-3 rounded-xl bg-tg-input px-4 py-3 text-left text-tg-text hover:bg-tg-hover disabled:opacity-60">
                <span className="min-w-0 flex-1"><span className="block text-[15.5px] font-semibold">{l}</span><span className="block text-[13px] text-tg-sub">{d}</span></span>
                {k === cur && <span className="text-[13px] text-tg-link">current</span>}
              </button>
            );
          })}
        </div>
      </Sheet>
      <Sheet open={sheet === 'reassign'} onClose={() => setSheet(null)} title="Assign chat to">
        <div className="grid gap-1.5">
          {agents.map(a => (
            <button key={a.id} disabled={a.id === lead?.agent_id} onClick={async () => { setSheet(null); try { await api('reassign', { lead_id: leadId, agent_id: a.id }); toast(`Assigned to ${a.name}`); await load(true); onChanged?.(); } catch (e) { toast((e as Error).message, 'err'); } }}
              className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-left text-tg-text hover:bg-tg-hover disabled:opacity-50">
              <Avatar name={a.name} id={a.id} size={38} /> {a.name}{a.id === lead?.agent_id && <span className="ml-auto text-[13px] text-tg-sub">current</span>}
            </button>
          ))}
          {!agents.length && <p className="text-tg-sub">Add agents first.</p>}
        </div>
      </Sheet>
    </div>
  );
}

export { Check };

/* ---------------- v167: chat action dock ---------------- */
/** v167: the chat actions of BOTH apps sit in a compact dock right above the message box (owner: small buttons, ~36px,
 *  icon + label in one line, so nothing is tapped by mistake). 3 main slots (Pay link · Ad account · the green one:
 *  Mark sold / Record sale / Send to manager) + More, which holds every other bar action and the ⋮ menu items. */
export type BarAct = { k: string; label: string; icon: React.ReactNode; onClick: () => void; on?: boolean; tone?: 'link' | 'green' };
type MenuIt = { label: string; icon?: React.ReactNode; onClick: () => void; danger?: boolean };
const DockCtx = createContext<{ menu: MenuIt[] }>({ menu: [] });
const SHORT: Record<string, string> = { paylink: 'Pay link', forward: 'To manager' };
export function ChatActionBar({ items }: { items: BarAct[] }) {
  const { menu } = useContext(DockCtx);
  const [more, setMore] = useState(false);
  if (!items.length && !menu.length) return null;
  const green = items.find(x => x.tone === 'green') || items.find(x => x.k === 'forward');
  const main: BarAct[] = [];
  for (const k of ['paylink', 'acct']) { const x = items.find(i => i.k === k); if (x) main.push(x); }
  if (green && !main.includes(green)) main.push(green);
  for (const x of items) if (main.length < 3 && !main.includes(x)) main.push(x);
  const rest = items.filter(x => !main.includes(x));
  const run = (f: () => void) => { setMore(false); setTimeout(f, 60); };
  return (
    <div className="flex gap-1.5 bg-tg-panel px-2 pb-1 pt-2" data-chat-bar>
      {main.map(x => (
        <button key={x.k} onClick={x.onClick} data-bar={x.k} data-tone={x.tone || ''} title={x.label}
          className={clsx('af-press flex h-9 min-w-0 flex-auto items-center justify-center gap-1 rounded-[10px] px-1 text-[12.5px] font-semibold tracking-[-0.01em]',
            x.tone === 'green' || x === green ? (x.on ? 'bg-tg-oksoft text-tg-ok' : 'bg-[rgb(var(--tg-green-btn))] text-white')
              : x.on ? 'bg-tg-accsoft text-tg-link' : 'bg-tg-input text-tg-text')}>
          <span className={clsx('grid shrink-0 place-items-center [&>svg]:h-[14px] [&>svg]:w-[14px]', !(x.tone === 'green' || x === green) && !x.on && 'text-tg-link')}>{x.icon}</span><span className="truncate">{SHORT[x.k] || x.label}</span>
        </button>
      ))}
      <button onClick={() => setMore(true)} data-bar="more" aria-label="More actions" className="af-press flex h-9 shrink-0 items-center justify-center gap-1 rounded-[10px] bg-tg-input px-2 text-[12.5px] font-semibold text-tg-text">
        <LayoutGrid size={14} className="text-tg-link" aria-hidden />More
      </button>
      <Sheet open={more} onClose={() => setMore(false)} title="More actions">
        <div data-more-sheet>
          {rest.length > 0 && <div className="af-group af-tiles mb-3 !bg-tg-input/60">
            {rest.map(x => (
              <button key={x.k} onClick={() => run(x.onClick)} data-bar={x.k} className="af-row">
                <span className={clsx('af-tile [&>svg]:h-[17px] [&>svg]:w-[17px]', x.tone === 'green' ? 'bg-[#34C759]' : ({ topup: 'bg-[#34C759]', remind: 'bg-[#FF9500]', assign: 'bg-[#5856D6]', forward: 'bg-[#34C759]', acct: 'bg-[#5856D6]' } as Record<string, string>)[x.k] || 'bg-[#3390EC]')}>{x.icon}</span>
                <span className="min-w-0 flex-1 truncate text-[15px]">{x.label}</span>
              </button>
            ))}
          </div>}
          {menu.length > 0 && <div className="af-group mb-1 !bg-tg-input/60">
            {menu.map(it => (
              <button key={it.label} onClick={() => run(it.onClick)} className={clsx('af-row text-[15px]', it.danger && '!text-tg-bad')}>{it.icon}<span className="min-w-0 flex-1">{it.label}</span></button>
            ))}
          </div>}
        </div>
      </Sheet>
    </div>
  );
}

/** v167: one plain status line for a chat row — coloured only when it needs action (the list uses this; StatusPill stays for the admin lists). */
export function rowStatus(l: any): { t: string; tone: '' | 'bad' | 'warn' | 'ok' | 'acc' } {
  if (l.remind_due) return { t: 'Reminder due', tone: 'warn' };
  if (l.remind_at && l.remind_at > Date.now() && l.status !== 'sold') return { t: 'Remind ' + remindLabel(l.remind_at), tone: 'warn' };
  if (l.status === 'active' && l.fu_due) return { t: `Follow-up ${l.fu_stage} due`, tone: 'warn' };
  if (l.status === 'active') {
    const lin = lastInOf(l), last = Math.max(lin, l.last_out_at || 0, l.last_at || 0);
    if (waitingC(l)) return { t: `Needs reply · ${agoShort(lin)}`, tone: 'bad' };
    if (Date.now() - last < 30 * 60000) return { t: 'Talking now', tone: 'acc' };
    return { t: `Waiting for client · ${agoShort(last)}`, tone: '' };
  }
  if (l.status === 'sold' && waitingC(l)) return { t: `Sold · needs reply · ${agoShort(lastInOf(l))}`, tone: 'bad' };
  if (l.status === 'new' && l.call_state && CALL_LABEL[l.call_state]) return { t: CALL_LABEL[l.call_state][0] + (l.call_by ? ` · ${l.call_by}` : ''), tone: '' };
  const m: Record<string, [string, '' | 'ok']> = { new: ['Form only', ''], active: ['Open', ''], sold: ['Sold', 'ok'], dead: ['Dead', ''] };
  const [t, tone] = m[l.status] || [String(l.status), ''];
  return { t, tone };
}

/* ---------------- "Remind me" ---------------- */
export function remindLabel(t: number) {
  const d = new Date(t), n = new Date();
  const time = d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  const day0 = new Date(n.getFullYear(), n.getMonth(), n.getDate()).getTime();
  const diff = Math.round((new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime() - day0) / 86400000);
  if (diff === 0) return `Today ${time}`;
  if (diff === 1) return `Tomorrow ${time}`;
  return `${d.toLocaleDateString([], { weekday: 'short', day: 'numeric', month: 'short' })} ${time}`;
}
function atDay(daysAhead: number, h: number, m = 0) { const d = new Date(); d.setDate(d.getDate() + daysAhead); d.setHours(h, m, 0, 0); return d.getTime(); }
const pad2 = (n: number) => String(n).padStart(2, '0');
const toLocalInput = (t: number) => { const d = new Date(t); return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}T${pad2(d.getHours())}:${pad2(d.getMinutes())}`; };

function RemindSheet({ open, onClose, onSave, current, note: note0 }: { open: boolean; onClose: () => void; onSave: (at: number, note: string) => Promise<void>; current: number; note: string }) {
  const [note, setNote] = useState('');
  const [custom, setCustom] = useState('');
  const [busy, setBusy] = useState(false);
  useEffect(() => { if (open) { setNote(note0); setCustom(toLocalInput(current || atDay(1, 11))); } }, [open, note0, current]);
  const nowT = Date.now();
  const options = ([
    ['In 1 hour', nowT + 3600000],
    ['In 3 hours', nowT + 3 * 3600000],
    ['Today 7:00 PM', atDay(0, 19)],
    ['Tomorrow 11:00 AM', atDay(1, 11)],
    ['Tomorrow 6:00 PM', atDay(1, 18)],
    ['In 2 days, 11:00 AM', atDay(2, 11)],
    ['In 1 week, 11:00 AM', atDay(7, 11)],
  ] as [string, number][]).filter(([, t]) => t > nowT + 60000);
  const save = async (t: number) => { setBusy(true); try { await onSave(t, note); } finally { setBusy(false); } };
  return (
    <Sheet open={open} onClose={onClose} title="Remind me about this chat">
      <p className="mb-3 text-[13.5px] leading-snug text-tg-sub">For “I’ll buy tomorrow” chats. At that time you get a notification and the chat moves to Follow-up. Automatic follow-ups and Dead are paused until then.</p>
      {/* senior-ui: the note stays ABOVE the presets — a preset saves at once, so a note box under them was easy to fill too late */}
      <Field label="Note (optional)"><input className={inputCls} placeholder="Said he will buy 2 accounts tomorrow" value={note} onChange={e => setNote(e.target.value)} maxLength={200} /></Field>
      <div className="grid grid-cols-2 gap-2" data-remind-presets>
        {options.map(([l, t]) => (
          <button key={l} disabled={busy} onClick={() => void save(t)} className="af-press flex min-h-[44px] items-center gap-2 rounded-xl bg-tg-input px-3 py-2 text-left text-[14px] font-medium text-tg-text hover:bg-tg-hover disabled:opacity-50"><AlarmClock size={15} className="shrink-0 text-tg-orange" aria-hidden /><span className="min-w-0">{l}</span></button>
        ))}
      </div>
      <p className="af-h2 !mx-1 !mb-1.5 !mt-4"><span>Custom date and time</span></p>
      <div className="flex gap-2">
        <input type="datetime-local" className={clsx(inputCls, 'min-w-0 flex-1')} value={custom} onChange={e => setCustom(e.target.value)} />
        <Btn busy={busy} disabled={!custom || new Date(custom).getTime() < nowT + 60000} onClick={() => void save(new Date(custom).getTime())}>Set</Btn>
      </div>
      {!!current && <button disabled={busy} onClick={() => void save(0)} className="mt-4 w-full rounded-xl py-2.5 text-[14.5px] font-medium text-tg-bad hover:bg-tg-hover">Cancel reminder</button>}
    </Sheet>
  );
}

/** v130: the Meta campaign (and ad) this chat came from. */
export function CampChip({ camp, ad }: { camp?: string | null; ad?: string | null }) {
  if (!camp) return null;
  return <span data-camp title={`Campaign: ${camp}${ad ? ' · Ad: ' + ad : ''}`} className="inline-flex min-w-0 max-w-full items-center gap-1 rounded-full bg-tg-acc/15 px-2 py-0.5 text-[11px] font-medium text-tg-link"><Megaphone size={11} className="shrink-0" /><span className="truncate">{camp}{ad ? ` · ${ad}` : ''}</span></span>;
}
/** v142: the campaign chip text of a chat row / chat (the server sends camp_label; older payloads → the same helper here). */
export function campOf(l: { ch?: string | null; camp?: string | null; ad?: string | null; camp_kind?: string | null; camp_label?: string | null; camp_ad?: string | null }) {
  return { label: l.camp_label || campLabel(l), ad: l.camp_label ? l.camp_ad ?? null : campAd(l) };
}
/** v142: campaign chip for every chat row (Telegram + WhatsApp): the campaign, else the fallback ("Old non-tracked ads", "Direct WhatsApp", "Community"). */
export function RowCamp({ l }: { l: Parameters<typeof campOf>[0] }) {
  const c = campOf(l);
  return <CampChip camp={c.label} ad={c.ad} />;
}
/** v142: the line badge next to the name: Agency (blue) / Premium (star) / Funnel, grey "Non-tracked" when the line is unknown. */
export function LineBadge({ l }: { l: { line_k?: string | null; line?: string | null; tier?: string | null; biz?: string | null; service?: string | null; menu?: number | null } }) {
  const k = (l.line_k as LineKey) || lineKey(l);
  if (k === 'premium') return <span data-line-badge="premium" className="inline-flex shrink-0"><PremiumChip /></span>;
  if (k === 'funnel') return <span data-line-badge="funnel" className="inline-flex shrink-0"><LineChip k="funnel" size="xs" /></span>;
  if (k === 'agency') return <span data-line-badge="agency" className="inline-flex shrink-0 items-center whitespace-nowrap rounded-full bg-tg-acc px-1.5 py-px text-[10.5px] font-bold text-white"><Briefcase size={10} className="-mt-px mr-0.5 inline" aria-hidden />{LINE_BADGE.agency}</span>;
  return <span data-line-badge="unknown" className="inline-flex shrink-0 items-center whitespace-nowrap rounded-full bg-tg-chip px-1.5 py-px text-[10.5px] font-bold text-tg-sub">{LINE_BADGE.unknown}</span>;
}
/** v167: the chat's type as one coloured word (chat header). */
export function TierWord({ l }: { l: Parameters<typeof LineBadge>[0]['l'] }) {
  const k = (l.line_k as LineKey) || lineKey(l);
  return <span data-tier-word={k} className={clsx('font-semibold', k === 'premium' ? 'text-[#c98a00] dark:text-tg-premium' : k === 'funnel' ? 'text-tg-funnel' : k === 'agency' ? 'text-tg-link' : 'text-tg-sub')}>{LINE_BADGE[k]}</span>;
}
/** v167: a small tier tag after a chat name instead of the filled "Agency" pill. Nothing for non-tracked chats.
 *  v168 F6 (owner): the full word — "Agency" / "Funnel" / "Premium" — in a compact tag, same colours (was A / F / P). */
export function TierLetter({ l }: { l: Parameters<typeof LineBadge>[0]['l'] }) {
  const k = (l.line_k as LineKey) || lineKey(l);
  if (k === 'unknown') return null;
  const word = k === 'premium' ? 'Premium' : k === 'funnel' ? 'Funnel' : 'Agency';
  return <span data-line-badge={k} title={LINE_BADGE[k]} className={clsx('af-cnt h-[17px] shrink-0 rounded-[5px] px-[5px] text-[10.5px] font-semibold tracking-[.01em] text-white', k === 'premium' ? 'bg-[#F5A623]' : k === 'funnel' ? 'bg-[#AF52DE]' : 'bg-[#3390EC]')}><i className="af-n">{word}</i></span>;
}
export function PremiumChip() {
  return <span className="shrink-0 rounded-full bg-gradient-to-r from-[#f5c451] to-[#f59e0b] px-1.5 py-px text-[10.5px] font-bold text-black"><Star size={10} className="-mt-px mr-0.5 inline fill-black" />Premium</span>;
}

type Prices = { tier: string; biz?: string; account: number; web: number; funnel: number; topup_pct: number; delivery: string; offer?: { label: string; until: number; free: number } | null };
/** One line on top of the chat: the price to collect for an ad account here, the website price, the top-up fee. */
function PriceStrip({ p, light }: { p: Prices; light?: boolean }) {
  const prem = p.tier === 'premium';
  return (
    <div className={clsx('flex flex-wrap items-center gap-x-3 gap-y-0.5 px-3 py-1.5 text-[12.5px]', prem ? (light ? 'bg-[#fff4d6] text-[#7a4b00] [&_b]:!text-[#5c3800] [&_svg]:!fill-[#d99100] [&_svg]:!text-[#d99100]' : 'bg-[#f59e0b]/15 text-[#fcd34d]') : 'bg-tg-panel/60 text-tg-sub')}>
      {p.biz === 'funnel' ? <>
        <b className="text-tg-text">Funnel chat</b>
        <span>Collect <b className="text-tg-text">${p.funnel}</b> first month</span>
      </> : <>
        <b className={prem ? 'text-[#fde68a]' : 'text-tg-text'}>{prem ? <><Star size={14} className="-mt-0.5 mr-1 inline fill-[#fde68a]" />Premium chat</> : 'Standard chat'}</b>
        <span>Collect <b className={prem ? 'text-[#fde68a]' : 'text-tg-text'}>${p.account}</b> / account</span>
        {p.web > 0 && <span>Website ${p.web}</span>}
        <span>Top-up fee {p.topup_pct}%</span>
        {prem && <span>Delivery {p.delivery}</span>}
      </>}
      {p.offer && <span className="w-full font-semibold text-[#fbbf24]">{p.offer.label} · until {new Date(p.offer.until).toLocaleDateString(undefined, { weekday: 'short', day: 'numeric', month: 'short' })}</span>}
    </div>
  );
}

/** v147: the customer wrote last and it was not marked 'No reply needed' */
/*  v167 (finding 7): rows whose last_in_at was never stamped (imported / old rows) but whose newest message is the customer's
 *  (last_dir 'in') or that have unread customer messages count as waiting too — before, they showed "Waiting for client" next to an unread badge. */
export const lastInOf = (l: { last_in_at?: number | null; last_out_at?: number | null; last_dir?: string | null; unread?: number | null; last_at?: number | null }) =>
  l.last_in_at || (l.last_dir === 'in' || (!l.last_out_at && Number(l.unread) > 0) ? l.last_at || 0 : 0);
export const waitingC = (l: { last_in_at?: number | null; last_out_at?: number | null; noreply_at?: number | null; last_dir?: string | null; unread?: number | null; last_at?: number | null }) => { const lin = lastInOf(l); return lin > (l.last_out_at || 0) && (l.noreply_at || 0) < lin; };
const agoShort = (t: number) => { const m = Math.max(1, Math.round((Date.now() - t) / 60000)); return m < 60 ? `${m}m` : m < 1440 ? `${Math.round(m / 60)}h` : `${Math.round(m / 1440)}d`; };
/** v136 (moved from the admin app): one status chip for a chat — reminder, follow-up, needs reply, talking, waiting. */
export function StatusPill({ l }: { l: any }) {
  const c = 'shrink-0 whitespace-nowrap rounded-full px-2 py-0.5';
  if (l.remind_due) return <span className={clsx(c, 'bg-tg-orange/15 text-tg-orange')}>Reminder due</span>;
  if (l.remind_at && l.remind_at > Date.now() && l.status !== 'sold') return <span className={clsx(c, 'bg-tg-acc/15 text-tg-link')}>{remindLabel(l.remind_at)}</span>;
  if (l.status === 'active' && l.fu_due) return <span className={clsx(c, 'bg-tg-orange/15 text-tg-orange')}>Follow-up {l.fu_stage}</span>;
  if (l.status === 'active') {
    const lin = lastInOf(l), lout = l.last_out_at || 0, last = Math.max(lin, lout, l.last_at || 0);
    if (waitingC(l)) return <span className={clsx(c, 'bg-tg-red/15 text-tg-bad')}>Needs reply · {agoShort(lin)}</span>;
    if (Date.now() - last < 30 * 60000) return <span className={clsx(c, 'bg-tg-acc/15 text-tg-link')}>Talking now</span>;
    return <span className={clsx(c, 'bg-tg-chip text-tg-sub')}>Waiting for client · {agoShort(last)}</span>;
  }
  // v144: a sold customer who wrote again (repeat buyer, top-up request) keeps "Sold" and also shows that he is waiting
  if (l.status === 'sold' && waitingC(l)) return <><span className={clsx(c, 'bg-tg-green/15 text-tg-ok')}>Sold</span><span data-sold-waiting className={clsx(c, 'bg-tg-red/15 text-tg-bad')}>Needs reply · {agoShort(lastInOf(l))}</span></>;
  if (l.status === 'new' && l.call_state && CALL_LABEL[l.call_state]) return <span className={clsx(c, CALL_LABEL[l.call_state][1])}>{CALL_LABEL[l.call_state][0]}{l.call_by ? ` · ${l.call_by}` : ''}</span>;
  const m: Record<string, [string, string]> = { new: ['Form only', 'bg-tg-chip text-tg-sub'], active: ['Open', 'bg-tg-acc/15 text-tg-link'], sold: ['Sold', 'bg-tg-green/15 text-tg-ok'], dead: ['Dead', 'bg-tg-red/15 text-tg-bad'] };
  const [t, k] = m[l.status] || [l.status, 'bg-tg-chip'];
  return <span className={clsx(c, k)}>{t}</span>;
}

/** v136 / v167: a Telegram-style pinned bar — accent rule, the price line, and campaign · links under it; tap to see all of it. */
function InfoStrip({ lead, light, openLinks = 0 }: { lead: LeadFull; light?: boolean; openLinks?: number }) {
  const [open, setOpen] = useState(false);
  const p = lead.prices as Prices | undefined;
  const showP = !!p && (lead.biz !== 'funnel' || !!p.offer);
  const prem = p?.tier === 'premium';
  const cp = campOf(lead as Parameters<typeof campOf>[0]); // v142: the same campaign chip text as the chat list (fallbacks too)
  const short = !showP || !p ? '' : p.biz === 'funnel' ? `Funnel · $${p.funnel} first month` : `${prem ? 'Premium' : 'Standard'} · $${p.account} / account · fee ${p.topup_pct}%`;
  const subBits = [cp.label, cp.ad, openLinks ? `${openLinks} open link${openLinks === 1 ? '' : 's'}` : ''].filter(Boolean);
  return (
    <div className="relative z-[5] bg-tg-panel shadow-[0_1px_3px_rgba(0,0,0,.08)]">
      <button type="button" onClick={() => setOpen(o => !o)} aria-expanded={open} data-info-strip className="flex w-full min-w-0 items-center gap-2.5 border-t border-tg-sep py-1.5 pl-3 pr-2.5 text-left">
        <span aria-hidden className={clsx('w-[2.5px] self-stretch rounded-full', prem ? 'bg-[#F5A623]' : 'bg-tg-acc')} />
        <span className="min-w-0 flex-1" data-camp-strip={cp.label}>
          <span className={clsx('flex items-center gap-1 truncate text-[13.5px] font-semibold', prem ? (light ? 'text-[#7a4b00]' : 'text-[#c98a00] dark:text-[#fcd34d]') : 'text-tg-link')}>
            {showP && prem && <Star size={12} className="shrink-0 fill-current" aria-hidden />}<span className="truncate">{short || 'Campaign'}</span>
            {p?.offer && !open && <span className="shrink-0 text-[#d97706]"> · Offer</span>}
          </span>
          <span className="block truncate text-[12.5px] text-tg-sub">{subBits.join(' · ') || 'No campaign'}</span>
        </span>
        <ChevronDown size={17} className={clsx('shrink-0 text-tg-sub transition-transform', open && 'rotate-180')} />
      </button>
      {open && <div className="af-sec">
        {showP && p && <PriceStrip p={p} light={light} />}
        <div className="flex min-w-0 items-center gap-1.5 bg-tg-acc/10 px-3 py-1.5 text-[12.5px] text-tg-link"><Megaphone size={13} className="shrink-0" /><span className="break-words"><span className="text-tg-sub">Campaign:</span> {cp.label}{lead.camp && lead.adset ? <><span className="text-tg-sub"> · Ad set:</span> {lead.adset}</> : null}{cp.ad ? <><span className="text-tg-sub"> · Ad:</span> {cp.ad}</> : null}</span></div>
      </div>}
    </div>
  );
}
