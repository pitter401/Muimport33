'use client';

/** Android app: alerts must arrive while the app is closed. Phones (Xiaomi, Oppo, Vivo, Realme, Samsung…) stop closed apps
 *  to save battery, so alerts only come after opening the app. This banner + sheet walks the user through the fix.
 *  v139: "check this phone" ALWAYS opens and shows something — the full check in the new app (battery, notifications,
 *  Autostart, alarm volume, own sound, push registration, Re-register, Test ring), a clear "old app / check failed" message
 *  with the download link, or "open this inside the Android app" in a browser. */
import { useCallback, useEffect, useState } from 'react';
import { BellRing, BatteryCharging, Rocket, Lock, Check, X, ChevronRight, Volume2, Music, Radio, RotateCw, Smartphone, AlertTriangle } from 'lucide-react';
import clsx from 'clsx';
import { notifState, phoneCheck, phoneAction, openExternal, withTimeout, type NotifState, type PhoneCheck } from './native';

const KEY = 'af_notif_fix_later';
const AUTOSTART_MAKERS = /xiaomi|redmi|poco|oppo|realme|oneplus|vivo|iqoo|huawei|honor|asus|samsung/;
const ago = (t: number) => { if (!t) return 'never'; const m = Math.round((Date.now() - t) / 60000); return m < 1 ? 'just now' : m < 60 ? `${m} min ago` : m < 1440 ? `${Math.round(m / 60)} h ago` : `${Math.round(m / 1440)} days ago`; };

type Step = { icon: typeof BellRing; title: string; text: string; done: boolean | null; btn?: string; run?: () => void; k: string };
/** Pure: the rows of the "check this phone" sheet for a check result (tested in e2e/notiffix139.ts). */
export function phoneRows(c: PhoneCheck, autoTapped = false): Step[] {
  if (c.kind !== 'new') return [];
  const s = c.notif, a = c.alarm, p = c.push;
  const needAuto = s.autostart || AUTOSTART_MAKERS.test(s.maker || '');
  const reg = p.ok_at > 0 && (!p.err_at || p.ok_at >= p.err_at);
  return [
    { k: 'notif', icon: BellRing, title: 'Notifications', text: s.notif_on ? 'Allowed for this app.' : 'OFF — App settings → Notifications → ON (all categories).', done: s.notif_on },
    { k: 'battery', icon: BatteryCharging, title: 'Battery: no restrictions', text: s.battery_ok ? 'This app may run in the background.' : 'Tap Open → this app → “Don’t optimise” / “No restrictions”.', done: s.battery_ok },
    ...(needAuto ? [{ k: 'auto', icon: Rocket, title: 'Autostart ON', text: 'Tap Open → Battery (or “Autostart / Background activity”) → Allow / No restrictions.', done: autoTapped ? true : null }] : []),
    { k: 'alarm', icon: Volume2, title: 'Alarm volume', text: a?.volume === undefined ? 'Could not read it.' : `${a.volume} of ${a.max ?? '?'}${a.ringer ? ` · ringer ${a.ringer}` : ''}${a.volume === 0 ? ' — turn it up: new-lead alerts ring on the alarm volume when the phone is silent' : ''}`, done: a?.volume === undefined ? null : a.volume > 0 },
    { k: 'sound', icon: Music, title: 'Own sound on this phone', text: p.snd_ver ? (p.snd_file ? `Saved (version ${p.snd_ver})` : `Version ${p.snd_ver} not saved yet — open the app on Wi-Fi`) : 'Default sound (no own sound chosen)', done: p.snd_ver ? !!p.snd_file : true },
    { k: 'push', icon: Radio, title: 'Registered for alerts', text: reg ? `${p.platform} · ${ago(p.ok_at)}${p.queued ? ` · ${p.queued} report(s) waiting to be sent` : ''}` : `Not registered yet${p.err ? ` — ${p.err}` : ''}`, done: reg },
    { k: 'lock', icon: Lock, title: 'Lock the app in recent apps', text: 'Open recent apps → long-press this app → Lock. Don’t “clear all” it.', done: null },
  ];
}

export function NotifFix({ app = 'agent' }: { app?: 'agent' | 'admin' }) {
  const [st, setSt] = useState<NotifState | 'old' | null>(null);
  const [chk, setChk] = useState<PhoneCheck | null>(null);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState('');
  const [open, setOpen] = useState(false);
  const [later, setLater] = useState(true);
  const [auto, setAuto] = useState(false); // tapped the Autostart step (no way to read it back)
  const check = useCallback(async () => setSt(await notifState()), []);
  // v143: never spins for ever — each native call has ~4 s, the whole check 12 s; then the clear "too old / failed" state
  const full = useCallback(async () => { setBusy(true); try { setChk(await withTimeout(phoneCheck(), 12000, 'the phone check')); } catch (e) { setChk({ kind: 'old', error: String((e as Error)?.message || e) }); } finally { setBusy(false); } }, []);
  useEffect(() => {
    void check();
    try { setLater(Number(localStorage.getItem(KEY) || 0) > Date.now()); setAuto(localStorage.getItem(KEY + '_auto') === '1'); } catch { setLater(false); }
    const vis = () => { if (document.visibilityState === 'visible') void check(); };
    const show = () => { setOpen(true); setMsg(''); void full(); void check(); };
    document.addEventListener('visibilitychange', vis);
    window.addEventListener('af-notif-fix', show);
    return () => { document.removeEventListener('visibilitychange', vis); window.removeEventListener('af-notif-fix', show); };
  }, [check, full]);
  const bad = !!st && (st === 'old' || !st.notif_on || !st.battery_ok);
  const snooze = () => { setLater(true); try { localStorage.setItem(KEY, String(Date.now() + 3 * 86400000)); } catch { /* ignore */ } };
  const dl = typeof location !== 'undefined' ? `${location.origin}/downloads/${app}.apk` : `/downloads/${app}.apk`;
  const act = async (m: Parameters<typeof phoneAction>[0], done: string) => {
    try { await phoneAction(m); setMsg(done); if (m === 'reRegister') setTimeout(() => void full(), 3000); }
    catch (e) { setMsg('Failed: ' + String((e as Error)?.message || e)); }
  };
  const runs: Record<string, () => void> = {
    notif: () => void act('openAppSettings', ''),
    battery: () => void act('requestBattery', ''),
    auto: () => { setAuto(true); try { localStorage.setItem(KEY + '_auto', '1'); } catch { /* ignore */ } void act('openAutostart', ''); },
  };
  const rows = chk ? phoneRows(chk, auto) : [];
  return (
    <>
      {bad && !later && !open && (
        <div className="fixed inset-x-3 bottom-3 z-[70] mx-auto flex max-w-[420px] items-center gap-3 rounded-2xl border border-tg-orange/30 bg-tg-panel px-4 py-3 shadow-2xl">
          <BellRing size={20} className="shrink-0 text-tg-orange" />
          <span className="flex-1 text-[13.5px] leading-snug">{st === 'old' ? 'Update the app so alerts come even when it is closed.' : 'Alerts may only come after you open the app.'}</span>
          <button onClick={() => { setOpen(true); void full(); }} className="rounded-full bg-tg-acc px-3.5 py-1.5 text-[13.5px] font-semibold text-white">{st === 'old' ? 'Why' : 'Fix'}</button>
          <button onClick={snooze} aria-label="Later" className="p-1 text-tg-sub"><X size={18} /></button>
        </div>
      )}
      {open && (
        <div className="fixed inset-0 z-[80] grid place-items-end bg-black/60 sm:place-items-center" onClick={() => setOpen(false)} data-phone-check>
          <div className="max-h-[92dvh] w-full max-w-[440px] overflow-y-auto rounded-t-2xl bg-tg-panel p-5 text-tg-text shadow-2xl sm:rounded-2xl" onClick={e => e.stopPropagation()}>
            <div className="mb-1 flex items-center justify-between"><h2 className="text-[18px] font-semibold">Alerts when the app is closed</h2><button onClick={() => setOpen(false)} aria-label="Close" className="p-1 text-tg-sub"><X size={20} /></button></div>
            {!chk || busy && !rows.length ? <p className="py-6 text-center text-[14px] text-tg-sub" data-check-state="loading">Checking this phone…</p>
              : chk.kind === 'web' ? (
                <div className="mt-2 flex items-start gap-3 rounded-xl bg-tg-input p-3.5 text-[14px]" data-check-state="web"><Smartphone size={20} className="mt-0.5 shrink-0 text-tg-link" /><span>Open this inside the Android app. This browser can't check the phone's alert settings. Get the app: <button className="font-semibold text-tg-link" onClick={() => void openExternal(dl)}>download the {app} app</button>.</span></div>
              ) : chk.kind === 'old' ? (
                <div className="mt-2 rounded-xl bg-tg-input p-3.5 text-[14px]" data-check-state="old">
                  <p className="flex items-start gap-2"><AlertTriangle size={18} className="mt-0.5 shrink-0 text-tg-orange" /><span>This phone’s app is too old for this check (or the check failed: <span className="text-tg-sub" data-check-error>{chk.error || 'unknown error'}</span>). Install the latest APK: <a className="break-all font-semibold text-tg-link" href={dl} onClick={e => { e.preventDefault(); void openExternal(dl); }}>{dl}</a>, then open the app once.</span></p>
                  {chk.version && <p className="mt-1.5 pl-[26px] text-[12.5px] text-tg-sub" data-check-version>App on this phone: {chk.version}</p>}
                </div>
              ) : (
                <>
                  <p className="mb-3 text-[13px] text-tg-sub">App {chk.version || '?'}{chk.notif.maker ? ` on this ${chk.notif.maker.charAt(0).toUpperCase() + chk.notif.maker.slice(1)} phone` : ''}. Fix anything not ticked.</p>
                  <div className="flex flex-col gap-2" data-check-state="new">
                    {rows.map(x => (
                      <div key={x.k} data-check-row={x.k} className="flex items-center gap-3 rounded-xl bg-tg-input px-3.5 py-3">
                        <span className={clsx('grid h-9 w-9 shrink-0 place-items-center rounded-full', x.done ? 'bg-tg-green/20 text-tg-green' : x.done === false ? 'bg-tg-orange/20 text-tg-orange' : 'bg-tg-acc/15 text-tg-acc')}>{x.done ? <Check size={18} /> : <x.icon size={18} />}</span>
                        <span className="min-w-0 flex-1"><span className="block text-[14.5px] font-medium">{x.title}</span><span className="block break-words text-[12.5px] leading-snug text-tg-sub">{x.text}</span></span>
                        {runs[x.k] && !x.done && <button onClick={runs[x.k]} className="inline-flex shrink-0 items-center gap-0.5 rounded-full bg-tg-acc px-3 py-1.5 text-[13px] font-semibold text-white">Open<ChevronRight size={15} /></button>}
                      </div>
                    ))}
                  </div>
                  <div className="mt-3 grid grid-cols-2 gap-2">
                    <button data-check-reregister onClick={() => void act('reRegister', 'Registering this phone again… the status updates in a few seconds.')} className="flex items-center justify-center gap-1.5 rounded-xl bg-tg-input py-2.5 text-[14px] font-semibold"><RotateCw size={16} />Re-register this phone</button>
                    <button data-check-testring onClick={() => void act('testRing', 'Ringing now (own sound if chosen, alarm volume when silent).')} className="flex items-center justify-center gap-1.5 rounded-xl bg-tg-input py-2.5 text-[14px] font-semibold"><Volume2 size={16} />Test ring on this phone</button>
                  </div>
                </>
              )}
            {msg && <p className="mt-2 text-[13px] text-tg-link" data-check-msg>{msg}</p>}
            <button onClick={() => { setOpen(false); snooze(); }} className="mt-4 w-full rounded-xl bg-tg-acc py-3 text-[15px] font-semibold text-white">Done</button>
          </div>
        </div>
      )}
    </>
  );
}
