'use client';

// v141: team helpers shared by the agent app (manager) and the admin app:
//  - presence: the dot is green only when the agent's app made a request in the last 30 minutes (server: online_now)
//  - AgentsList: manager → Agents (tap one → that agent's chat folders)
//  - CashPayouts: record a cash / offline payout (INR or USD), list per agent with this month + lifetime totals, delete
import { useCallback, useEffect, useState } from 'react';
import { Trash2, ChevronRight, Banknote } from 'lucide-react';
import clsx from 'clsx';
import { useToast, Field, inputCls, Btn, usd, Avatar, Seg, Sheet, Skeleton } from './ui';

type Api = <T = any>(path: string, body?: unknown) => Promise<T>;

/** "Online now" · "Last seen 10:42 PM" · "Last seen yesterday 9:15 PM" · "Last seen 3 Nov" · "Never opened the app". */
export function seenLine(a: { online_now?: boolean; last_seen_at?: number | null }) {
  if (a.online_now) return 'Online now';
  const t = a.last_seen_at;
  if (!t) return 'Never opened the app';
  const d = new Date(t), n = new Date();
  const time = d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
  const day = (x: Date) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const diff = Math.round((day(n) - day(d)) / 86400000);
  if (diff === 0) return `Last seen ${time}`;
  if (diff === 1) return `Last seen yesterday ${time}`;
  return `Last seen ${d.getDate()} ${d.toLocaleString('en-US', { month: 'short' })}`;
}
export function PresenceDot({ on, size = 'md' }: { on?: boolean; size?: 'sm' | 'md' }) {
  return <span data-presence={on ? 'on' : 'off'} aria-label={on ? 'online now' : 'not online'} className={clsx('absolute -bottom-0.5 -right-0.5 rounded-full ring-2 ring-tg-panel', size === 'sm' ? 'h-3 w-3' : 'h-3.5 w-3.5', on ? 'bg-[#34C759]' : 'bg-tg-sub/50')} />;
}

export type TeamRow = { id: number; name: string; receive: number; auto_off_at?: number | null; online_now?: boolean; last_seen_at?: number | null; open: number; waiting: number; covering: number };
/** Manager → Agents: the team (not the manager). */
export function AgentsList({ api, onPick }: { api: Api; onPick: (a: TeamRow) => void }) {
  const [rows, setRows] = useState<TeamRow[] | null>(null);
  useEffect(() => { void api<{ agents: TeamRow[] }>('team').then(r => setRows(r.agents)).catch(() => setRows([])); }, [api]);
  if (!rows) return <div className="p-3"><Skeleton rows={3} h={68} /></div>;
  if (!rows.length) return <p className="py-8 text-center text-tg-sub">No agents yet.</p>;
  return (
    <div className="-mx-1" data-agents-list>
      {rows.map(a => (
        <button key={a.id} data-agent-row={a.id} onClick={() => onPick(a)} className="flex w-full items-center gap-3 rounded-xl px-2 py-2.5 text-left hover:bg-tg-hover active:bg-tg-hover">
          <span className="relative shrink-0"><Avatar name={a.name} id={a.id} size={46} /><PresenceDot on={a.online_now} /></span>
          <span className="min-w-0 flex-1">
            <span className="flex items-center gap-2"><span className="truncate text-[16px] font-semibold text-tg-text">{a.name}</span>
              {!a.receive && <span className="shrink-0 rounded-full bg-tg-sub/15 px-2 py-px text-[11px] font-semibold text-tg-sub">{a.auto_off_at ? 'auto-paused' : 'paused'}</span>}</span>
            <span className="block truncate text-[13px] text-tg-sub">{seenLine(a)}</span>
            <span className="block truncate text-[12.5px] text-tg-sub">{a.open} open · <span className={a.waiting ? 'font-semibold text-tg-bad' : ''}>{a.waiting} waiting</span>{a.covering ? ` · covering ${a.covering}` : ''}</span>
          </span>
          <ChevronRight size={18} className="shrink-0 text-tg-sub" />
        </button>
      ))}
    </div>
  );
}

type PayRow = { id: number; agent_id: number; agent_name: string; amount: number; cur: string | null; orig_amount: number | null; note: string | null; by_name: string | null; by_role: string | null; kind: string | null; paid_at: number; created_at: number; method: string | null };
type PayData = { agents: { id: number; name: string; month: { usd: number; inr: number; n: number }; life: { usd: number; inr: number; n: number } }[]; rows: PayRow[]; inr_rate: number | null; truncated?: boolean };
export const payAmt = (p: { cur?: string | null; orig_amount?: number | null; amount: number }) => (p.cur === 'INR' && p.orig_amount ? '₹' + Math.round(p.orig_amount).toLocaleString('en-IN') : usd(p.amount));
export const payLine = (p: { kind?: string | null; by_name?: string | null; by_role?: string | null; note?: string | null; cur?: string | null; orig_amount?: number | null; amount: number; method?: string | null }) =>
  p.kind === 'cash' ? `Cash paid by ${p.by_role === 'manager' ? `${p.by_name} (manager)` : 'Admin'} · ${payAmt(p)}${p.cur === 'INR' ? ` (${usd(p.amount)})` : ''}${p.note && p.note !== 'Cash' ? ' · ' + p.note : ''}` : `${usd(p.amount)} · ${p.method === 'usdt' ? 'USDT' : 'Bank'}`;

/** Record cash payout + the payouts per agent. `role` decides delete: admin any time, manager within 24 h. */
export function CashPayouts({ api, role, agentId }: { api: Api; role: 'admin' | 'manager'; agentId?: number | null }) {
  const toast = useToast();
  const [d, setD] = useState<PayData | null>(null);
  const [who, setWho] = useState<number | null>(agentId ?? null);
  const [cur, setCur] = useState<'INR' | 'USD'>('INR');
  const [amount, setAmount] = useState(''); const [note, setNote] = useState('Cash');
  const today = (() => { const x = new Date(); return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-${String(x.getDate()).padStart(2, '0')}`; })();
  const [date, setDate] = useState(today);
  const [confirm, setConfirm] = useState(false); const [del, setDel] = useState<PayRow | null>(null); const [busy, setBusy] = useState(false);
  const load = useCallback(() => api<PayData>('cash_payouts').then(r => { setD(r); setWho(w => w ?? r.agents[0]?.id ?? null); }).catch(e => toast((e as Error).message, 'err')), [api, toast]);
  useEffect(() => { void load(); }, [load]);
  const amt = Number(amount);
  const usdVal = cur === 'USD' ? amt : d?.inr_rate ? amt / d.inr_rate : 0;
  const agentName = d?.agents.find(a => a.id === who)?.name || '';
  async function save() {
    setBusy(true);
    try { await api('cash_payout_add', { agent_id: who, amount: amt, cur, date, note }); toast(`Saved: ${cur === 'INR' ? '₹' + amt.toLocaleString('en-IN') : usd(amt)} paid to ${agentName}`); setConfirm(false); setAmount(''); await load(); }
    catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); }
  }
  async function remove() {
    if (!del) return; setBusy(true);
    try { await api('cash_payout_del', { id: del.id }); toast('Payout deleted'); setDel(null); await load(); }
    catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); }
  }
  if (!d) return <div className="p-3"><Skeleton rows={3} h={68} /></div>;
  const tot = d.agents.find(a => a.id === who);
  const list = d.rows.filter(r => !who || r.agent_id === who);
  return (
    <div data-cash-payouts>
      <Field label="Agent">
        <div className="flex flex-wrap gap-1.5">{d.agents.map(a => <button key={a.id} data-pay-agent={a.id} onClick={() => setWho(a.id)} aria-pressed={who === a.id} className="af-chip af-press">{a.name}</button>)}</div>
      </Field>
      <div className="mb-3"><Seg value={cur} onChange={setCur} items={[['INR', '₹ INR'], ['USD', '$ USD']]} /></div>
      <Field label={`Amount paid (${cur === 'INR' ? '₹' : '$'})`} hint={cur === 'INR' ? (d.inr_rate ? `= ${usd(usdVal)} at ₹${d.inr_rate} per $` : 'Set the INR rate in Settings first') : undefined}>
        <input className={inputCls} type="number" inputMode="decimal" value={amount} onChange={e => setAmount(e.target.value)} placeholder={cur === 'INR' ? '10000' : '100'} data-pay-amount />
      </Field>
      <div className="grid grid-cols-2 gap-x-3">
        <Field label="Date"><input className={inputCls} type="date" value={date} max={today} onChange={e => setDate(e.target.value)} /></Field>
        <Field label="Note"><input className={inputCls} value={note} onChange={e => setNote(e.target.value)} placeholder="Cash, UPI…" /></Field>
      </div>
      <Btn className="w-full" disabled={!who || !(amt > 0) || (cur === 'INR' && !d.inr_rate)} onClick={() => setConfirm(true)}><Banknote size={17} />Record payout</Btn>
      {tot && (
        <div className="mt-5 grid grid-cols-2 gap-2 text-[13.5px]" data-pay-totals>
          <div className="rounded-xl bg-tg-input px-3 py-2.5"><p className="text-tg-sub">This month</p><p className="mt-0.5 font-semibold">{usd(tot.month.usd)}{tot.month.inr ? <span className="font-normal text-tg-sub"> · ₹{Math.round(tot.month.inr).toLocaleString('en-IN')}</span> : null}</p></div>
          <div className="rounded-xl bg-tg-input px-3 py-2.5"><p className="text-tg-sub">Lifetime</p><p className="mt-0.5 font-semibold">{usd(tot.life.usd)}{tot.life.inr ? <span className="font-normal text-tg-sub"> · ₹{Math.round(tot.life.inr).toLocaleString('en-IN')}</span> : null}</p></div>
        </div>
      )}
      <h4 className="af-h2 !mt-5"><span>Paid to {agentName || 'agents'}</span></h4>
      {list.length ? list.map(p => {
        const canDel = p.kind === 'cash' && (role === 'admin' || Date.now() - p.created_at < 86400000);
        return (
          <div key={p.id} data-pay-row={p.id} className="flex items-center gap-2 border-b border-tg-line py-2.5 text-[14px]">
            <span className="min-w-0 flex-1"><span className="block truncate">{payLine(p)}</span><span className="text-[12.5px] text-tg-sub">{new Date(p.paid_at).toLocaleDateString()}{p.kind !== 'cash' ? ' · payout request' : ''}</span></span>
            {canDel && <button onClick={() => setDel(p)} className="grid h-9 w-9 place-items-center rounded-full text-tg-sub hover:bg-tg-hover hover:text-tg-bad" aria-label="Delete payout"><Trash2 size={17} /></button>}
          </div>
        );
      }) : <p className="text-[14px] text-tg-sub">No payouts yet.</p>}
      {d.truncated && <p className="mt-2 text-[12.5px] text-tg-sub" data-truncated>Showing the latest {d.rows.length}.</p>}
      <Sheet open={confirm} onClose={() => setConfirm(false)} title="Record this payout?">
        <div className="rounded-2xl bg-tg-active p-4 text-[15px]" data-pay-confirm>
          <p><b>{cur === 'INR' ? '₹' + (amt || 0).toLocaleString('en-IN') : usd(amt)}</b>{cur === 'INR' ? <span className="text-tg-sub"> = {usd(usdVal)}</span> : null} paid to <b>{agentName}</b></p>
          <p className="mt-1 text-tg-sub">{date} · {note || 'Cash'}</p>
          <p className="mt-2 text-[13px] text-tg-sub">It comes off {agentName}’s balance (available to withdraw). Earned commission and profit don’t change.</p>
        </div>
        <Btn className="mt-4 w-full" kind="green" busy={busy} onClick={() => void save()}>Save payout</Btn>
      </Sheet>
      <Sheet open={!!del} onClose={() => setDel(null)} title="Delete this payout?">
        <p className="text-[15px]">{del ? payLine(del) : ''}</p>
        <p className="mt-1 text-[13px] text-tg-sub">The amount goes back onto the agent’s balance. This is logged.</p>
        <Btn className="mt-4 w-full" kind="danger" busy={busy} onClick={() => void remove()}>Delete</Btn>
      </Sheet>
    </div>
  );
}
