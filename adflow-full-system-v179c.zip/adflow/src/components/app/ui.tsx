'use client';
import { createPortal } from 'react-dom';

import { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { AnimatePresence, MotionConfig, motion } from 'framer-motion';
import { X, Loader2, ChevronLeft, ChevronRight, ChevronDown, Check, Info, CalendarDays } from 'lucide-react';
import clsx from 'clsx';

/* ---------------- API client ---------------- */
export class ApiError extends Error { constructor(public status: number, msg: string, public data: Record<string, any> = {}) { super(msg); } }
export function makeApi(base: string, onAuth: () => void) {
  return async function api<T = any>(path: string, body?: unknown): Promise<T> {
    const isForm = typeof FormData !== 'undefined' && body instanceof FormData;
    const r = await fetch(`${base}/${path}`, {
      method: body !== undefined ? 'POST' : 'GET', credentials: 'same-origin', cache: 'no-store',
      headers: isForm || body === undefined ? undefined : { 'content-type': 'application/json' },
      body: body === undefined ? undefined : isForm ? (body as FormData) : JSON.stringify(body),
    });
    let j: any = {};
    try { j = await r.json(); } catch { /* non-json */ }
    if (r.status === 401 && j.error === 'login') { onAuth(); throw new ApiError(401, 'Please log in again'); }
    if (!r.ok || j.error) throw new ApiError(r.status, j.error || `Request failed (${r.status})`, j);
    return j as T;
  };
}

/* ---------------- Toast ---------------- */
const ToastCtx = createContext<(m: string, kind?: 'ok' | 'err') => void>(() => {});
export const useToast = () => useContext(ToastCtx);
export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [t, setT] = useState<{ id: number; m: string; kind: string } | null>(null);
  const show = useCallback((m: string, kind: 'ok' | 'err' = 'ok') => setT({ id: Date.now(), m, kind }), []);
  useEffect(() => { if (!t) return; const x = setTimeout(() => setT(null), 2800); return () => clearTimeout(x); }, [t]);
  return (
    <MotionConfig reducedMotion="user">
      <ToastCtx.Provider value={show}>
        <BannerProvider>{children}</BannerProvider>
        <AnimatePresence>
          {t && (
            <motion.div key={t.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0, transition: { duration: 0.22, ease: [0.2, 0.8, 0.2, 1] } }} exit={{ opacity: 0, y: 6, transition: { duration: 0.16, ease: [0.4, 0, 1, 1] } }}
              role="status" className={clsx('fixed bottom-[calc(88px+env(safe-area-inset-bottom))] left-1/2 z-[300] max-w-[90vw] -translate-x-1/2 rounded-2xl px-4 py-2.5 text-center text-[14px] font-medium shadow-2xl',
                t.kind === 'err' ? 'bg-tg-red text-white' : 'bg-tg-toast text-white')}>
              {t.m}
            </motion.div>
          )}
        </AnimatePresence>
      </ToastCtx.Provider>
    </MotionConfig>
  );
}

/* ---------------- v136: Android Back (one stack for chats, sheets and pages) ---------------- */
type BackEntry = { id: number; fn: () => void };
const backStack: BackEntry[] = [];
let backSeq = 0, backSkip = 0, backListen = false;
const backDeferred: number[] = [];
function onBackPop() {
  if (backSkip > 0) { backSkip--; if (!backSkip) backDeferred.splice(0).forEach(id => history.pushState({ af: id }, '')); return; }
  const e = backStack.pop(); e?.fn();
}
/** Adds a history entry: Android / browser Back runs fn (only the top-most entry). */
export function backPush(fn: () => void) {
  if (!backListen) { window.addEventListener('popstate', onBackPop); backListen = true; }
  const id = ++backSeq; backStack.push({ id, fn });
  if (backSkip > 0) backDeferred.push(id); else history.pushState({ af: id }, '');
  return id;
}
/** The thing closed by itself (X, Back arrow, tab change): drop its entry (and any above it) without running them. */
export function backRelease(id: number) {
  const i = backStack.findIndex(e => e.id === id); if (i < 0) return;
  const n = backStack.length - i; backStack.splice(i);
  const d = backDeferred.filter(x => x >= id).length; if (d) backDeferred.splice(0, backDeferred.length, ...backDeferred.filter(x => x < id));
  if (n - d > 0) { backSkip++; history.go(-(n - d)); }
}
/** While `active`, Back calls onBack (phones only unless `always`). */
export function useBackEntry(active: boolean, onBack: () => void, always = false) {
  const ref = useRef(onBack); ref.current = onBack;
  useEffect(() => {
    if (!active || (!always && window.innerWidth >= 768)) return;
    let popped = false;
    const id = backPush(() => { popped = true; ref.current(); });
    return () => { if (!popped) backRelease(id); };
  }, [active, always]);
}

/* ---------------- v136: rows that appear (only new ids animate; polling never re-animates) ---------------- */
export function useAppear(ids: (number | string)[], initial = true) {
  const seen = useRef<Set<number | string> | null>(null);
  const out = new Map<number | string, number>();
  if (seen.current === null) { if (initial) ids.slice(0, 8).forEach((id, i) => out.set(id, i * 24)); seen.current = new Set(ids); }
  else for (const id of ids) if (!seen.current.has(id)) out.set(id, 0);
  useEffect(() => { ids.forEach(id => seen.current!.add(id)); });
  return (id: number | string) => (out.has(id) ? { className: 'af-item', style: { animationDelay: out.get(id) + 'ms' } as React.CSSProperties } : { className: '', style: undefined });
}

/* ---------------- v136: in-app notification banner ---------------- */
type BannerT = { id: number; key: string; name: string; text: string; avatarId: number; onOpen?: () => void };
const BannerCtx = createContext<(b: Omit<BannerT, 'id'>) => void>(() => {});
export const useBanner = () => useContext(BannerCtx);
function BannerProvider({ children }: { children: React.ReactNode }) {
  const [b, setB] = useState<BannerT | null>(null);
  const show = useCallback((x: Omit<BannerT, 'id'>) => setB({ ...x, id: Date.now() }), []);
  useEffect(() => { if (!b) return; const t = setTimeout(() => setB(null), 4000); return () => clearTimeout(t); }, [b]);
  const start = useRef<number | null>(null);
  const [dy, setDy] = useState(0);
  return (
    <BannerCtx.Provider value={show}>
      {children}
      <AnimatePresence>
        {b && (
          <motion.div key={b.id} data-banner initial={{ y: '-120%' }} animate={{ y: 0, transition: { duration: 0.26, ease: [0.32, 0.72, 0, 1] } }} exit={{ y: '-120%', transition: { duration: 0.2, ease: [0.4, 0, 1, 1] } }}
            className="fixed inset-x-2 top-[calc(8px+env(safe-area-inset-top))] z-[320] mx-auto max-w-[460px]">
            <button type="button" style={dy ? { transform: `translateY(${dy}px)` } : undefined}
              onPointerDown={e => { start.current = e.clientY; }} onPointerMove={e => { if (start.current != null) setDy(Math.min(0, e.clientY - start.current)); }}
              onPointerUp={() => { const d = dy; start.current = null; setDy(0); if (d < -30) setB(null); }}
              onClick={() => { if (Math.abs(dy) > 4) return; const o = b.onOpen; setB(null); o?.(); }}
              className="flex w-full touch-none items-center gap-3 rounded-2xl bg-tg-menu px-3 py-2.5 text-left text-tg-text shadow-2xl ring-1 ring-tg-line">
              <Avatar name={b.name} id={b.avatarId} size={38} />
              <span className="min-w-0 flex-1"><span className="block truncate text-[14.5px] font-semibold">{b.name}</span><span className="block truncate text-[13.5px] text-tg-sub">{b.text}</span></span>
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </BannerCtx.Provider>
  );
}

/* ---------------- Bottom sheet ---------------- */
const isWide = () => typeof window !== 'undefined' && window.innerWidth >= 768;
// v155: Escape closes only the top sheet (open sheets stack up)
const SHEETS: number[] = [];
let sheetSeq = 0;
export function Sheet({ open, onClose, title, children, wide, full, noBack }: { open: boolean; onClose: () => void; title?: string; children: React.ReactNode; wide?: boolean; full?: boolean; noBack?: boolean }) {
  const myId = useRef(0);
  useEffect(() => {
    if (!open) return;
    const id = ++sheetSeq; myId.current = id; SHEETS.push(id);
    return () => { const i = SHEETS.indexOf(id); if (i >= 0) SHEETS.splice(i, 1); };
  }, [open]);
  useEffect(() => {
    if (!open) return;
    const k = (e: KeyboardEvent) => { if (e.key === 'Escape' && SHEETS[SHEETS.length - 1] === myId.current) onClose(); };
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, [open, onClose]);
  useBackEntry(open && !noBack, onClose); // v136: Android Back closes the sheet only
  const md = isWide();
  // v153: Android WebView can leave the page pushed up after the keyboard closes → the sheet's top is cut off and won't scroll back.
  //   The app never scrolls the window itself, so put it back to 0 whenever the keyboard goes away.
  useEffect(() => {
    if (!open) return;
    const fix = () => { if (!(document.activeElement instanceof HTMLInputElement || document.activeElement instanceof HTMLTextAreaElement)) { if (window.scrollY) window.scrollTo(0, 0); } };
    const out = () => setTimeout(fix, 120);
    window.addEventListener('focusout', out);
    window.visualViewport?.addEventListener('resize', out);
    return () => { window.removeEventListener('focusout', out); window.visualViewport?.removeEventListener('resize', out); };
  }, [open]);
  // v153: rendered on <body> — inside a page with a transform (page animation) a fixed sheet opened at the bottom of the long page instead of on screen
  if (typeof document === 'undefined') return null;
  // v155: on <body> the sheet is outside the page's light / dark wrapper → carry the same look
  const theme = (document.querySelector('.tg-auto') ? 'tg-auto contents' : 'contents') + (document.querySelector('.af-admin') ? ' af-admin' : '');
  return createPortal(
    <div className={theme}>
    <AnimatePresence>
      {open && (
        // v160: only the dark backdrop fades; the sheet itself is never see-through while it slides
        <motion.div className="fixed inset-0 z-[200] flex items-end justify-center md:items-center md:p-6" initial={{ opacity: 1 }} animate={{ opacity: 1 }} exit={{ opacity: 1, transition: { duration: 0.2 } }}>
          <motion.div aria-hidden className="absolute inset-0 bg-black/55" initial={{ opacity: 0 }} animate={{ opacity: 1, transition: { duration: 0.18, ease: 'linear' } }} exit={{ opacity: 0, transition: { duration: 0.18, ease: 'linear' } }} onMouseDown={onClose} />
          <motion.div role="dialog" aria-modal="true" aria-label={title}
            className={clsx('relative w-full overflow-y-auto overscroll-contain rounded-t-[22px] bg-tg-panel px-5 pb-[calc(20px+env(safe-area-inset-bottom))] pt-3 text-tg-text shadow-2xl md:rounded-[22px] md:pt-5', full ? 'af-sheet-full md:h-auto' : 'af-sheet-max', wide ? 'md:max-w-[640px]' : 'md:max-w-[460px]')}
            initial={md ? { opacity: 0, scale: 0.98 } : { y: '100%' }}
            animate={md ? { opacity: 1, scale: 1, transition: { duration: 0.18, ease: [0.2, 0.8, 0.2, 1] } } : { y: 0, transition: { type: 'tween', duration: 0.26, ease: [0.32, 0.72, 0, 1] } }}
            exit={md ? { opacity: 0, scale: 0.98, transition: { duration: 0.15 } } : { y: '100%', transition: { type: 'tween', duration: 0.2, ease: [0.4, 0, 1, 1] } }}>
            <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-tg-sub/30 md:hidden" />
            {title && (
              <div className="sticky -top-3 z-10 -mx-5 mb-3 flex items-center justify-between gap-3 bg-tg-panel px-5 py-2">
                <h3 className="min-w-0 truncate text-[18px] font-semibold">{title}</h3>
                <button onClick={onClose} aria-label="Close" className="grid h-9 w-9 place-items-center rounded-full text-tg-sub hover:bg-tg-hover"><X size={18} /></button>
              </div>
            )}
            {children}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
    </div>,
    document.body,
  );
}

/* ---------------- Inputs ---------------- */
export function Field({ label, hint, children }: { label: React.ReactNode; hint?: React.ReactNode; children: React.ReactNode }) {
  return (
    // v155: a <div>, not a <label> — tapping the label of a row of buttons pressed the first button. Tapping it still focuses a text box.
    <div className="mb-3.5 block">
      <span className="mb-1.5 block text-[13px] font-medium text-tg-sub" onClick={e => { const el = (e.currentTarget.parentElement as HTMLElement).querySelector<HTMLElement>('input:not([type=checkbox]):not([type=radio]),textarea,select'); el?.focus(); }}>{label}</span>
      {children}
      {hint && <span className="mt-1.5 block text-[12px] leading-relaxed text-tg-sub/80">{hint}</span>}
    </div>
  );
}
export const inputCls = 'w-full rounded-xl border border-transparent bg-tg-input px-3.5 py-2.5 text-[15px] text-tg-text outline-none transition-colors placeholder:text-tg-sub/70 focus:border-tg-acc';
/** v167: compact buttons (36 px) — the owner asked for no oversized action buttons. kind 'soft' = tinted accent, 'plain' = text only. */
export function Btn({ children, onClick, kind = 'primary', busy, disabled, className, type = 'button', size = 'md' }: { children: React.ReactNode; onClick?: () => void; kind?: 'primary' | 'ghost' | 'danger' | 'green' | 'soft' | 'plain'; busy?: boolean; disabled?: boolean; className?: string; type?: 'button' | 'submit'; size?: 'sm' | 'md' }) {
  return (
    <button type={type} onClick={onClick} disabled={busy || disabled}
      className={clsx('af-press inline-flex items-center justify-center gap-1.5 whitespace-nowrap font-semibold transition-colors disabled:opacity-50',
        size === 'sm' ? 'min-h-[30px] rounded-[9px] px-3 py-1 text-[13px]' : 'min-h-[36px] rounded-[10px] px-3.5 py-1.5 text-[14.5px]',
        kind === 'primary' && 'bg-tg-acc text-white hover:bg-tg-acc/90', kind === 'ghost' && 'bg-tg-sub/[0.12] text-tg-text hover:bg-tg-sub/20',
        kind === 'danger' && 'bg-tg-badsoft text-tg-bad hover:bg-tg-red/25', kind === 'green' && 'bg-[rgb(var(--tg-green-btn,var(--tg-green)))] text-white hover:opacity-90',
        kind === 'soft' && 'bg-tg-accsoft text-tg-link hover:opacity-90', kind === 'plain' && 'px-1 text-tg-link hover:opacity-80', className)}>
      {busy && <Loader2 size={15} className="animate-spin" />}{children}
    </button>
  );
}
export function Toggle({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label?: string }) {
  return (
    <button type="button" role="switch" aria-checked={on} aria-label={label} onClick={() => onChange(!on)}
      className={clsx("relative h-[26px] w-[44px] shrink-0 rounded-full transition-colors after:absolute after:-inset-2 after:content-['']", on ? 'bg-[#34C759]' : 'bg-tg-sub/35')}>
      <span className={clsx('absolute left-[2px] top-[2px] h-[22px] w-[22px] rounded-full bg-white shadow-[0_2px_4px_rgba(0,0,0,0.2)] transition-transform duration-[180ms] ease-[var(--ease-out)]', on ? 'translate-x-[18px]' : 'translate-x-0')} />
    </button>
  );
}
/** v167: iOS segmented control (light track, raised thumb). `full` stretches it to the row. */
export function Seg<T extends string>({ value, onChange, items, full, className }: { value: T; onChange: (v: T) => void; items: [T, React.ReactNode][]; full?: boolean; className?: string }) {
  return (
    <div className={clsx('af-seg', !full && 'af-seg-inline', className)}>
      {items.map(([v, l]) => (
        <button key={v} type="button" aria-pressed={value === v} onClick={() => onChange(v)} className="af-press">{l}</button>
      ))}
    </div>
  );
}

/* ---------------- Avatar ---------------- */
const AV = ['#E17076', '#FAA774', '#A695E7', '#7BC862', '#6EC9CB', '#65AADD', '#EE7AAE'];
export function Avatar({ name, id, size = 52 }: { name: string; id: number; size?: number }) {
  const parts = String(name || '?').replace(/[@#]/g, '').trim().split(/\s+/);
  // v167: numbered clients ("Client 9007") get the last 2 digits, not "C9" for all of them
  const ini = parts.length >= 2 && /^\d{2,}$/.test(parts[1]) ? parts[1].slice(-2) : ((parts[0]?.[0] || '?') + (parts[1]?.[0] || '')).toUpperCase();
  const c = AV[Math.abs(id) % AV.length];
  return (
    <div className="grid shrink-0 place-items-center rounded-full font-semibold text-white" style={{ width: size, height: size, fontSize: size * 0.38, background: `linear-gradient(180deg, ${c}, ${c}CC)` }}>{ini}</div>
  );
}

/* ---------------- v136: shared pieces ---------------- */
const LINE_CHIPS: Record<string, [string, string]> = {
  agency: ['Agency', 'bg-tg-acc/85 text-white'], premium: ['Premium', 'bg-tg-premium text-black'], full: ['Full access', 'bg-tg-ok/20 text-tg-ok'],
  funnel: ['Funnel', 'bg-tg-funnel text-black'], wa: ['WhatsApp', 'bg-tg-wa text-black'], tg: ['Telegram', 'bg-tg-tgblue text-white'],
  other: ['Other', 'bg-tg-chip text-tg-sub'], fb: ['FB account', 'bg-tg-tgblue/20 text-tg-link'], manager: ['Manager', 'bg-tg-orange text-black'], agent: ['Agent', 'bg-tg-chip text-tg-sub'],
};
/** Agency / Premium / Full / Funnel / WhatsApp / Telegram chip. */
export function LineChip({ k, size = 'sm', children }: { k: string; size?: 'xs' | 'sm'; children?: React.ReactNode }) {
  const [l, c] = LINE_CHIPS[k] || [k, 'bg-tg-chip text-tg-sub'];
  return <span className={clsx('inline-flex shrink-0 items-center gap-1 whitespace-nowrap rounded-full font-bold', size === 'xs' ? 'px-1.5 py-px text-[10.5px]' : 'px-2 py-0.5 text-[11px]', c)}>{children ?? l}</span>;
}
/** A setting with a switch. `k` keeps the key for the Settings search. */
export function ToggleRow({ k, title, sub, on, onChange, tone, strong, className }: { k?: string; title: React.ReactNode; sub?: React.ReactNode; on: boolean; onChange: (v: boolean) => void; tone?: 'warn'; strong?: boolean; className?: string }) {
  return (
    <div className={clsx('mb-2.5 flex items-center justify-between gap-3 rounded-xl px-4 py-2.5', tone === 'warn' ? 'bg-tg-badsoft' : 'bg-tg-input', className)}>
      <span className="min-w-0"><span className={clsx('block text-[15px]', strong && 'font-semibold')} data-k={k}>{title}</span>{sub && <span className="mt-0.5 block text-[12.5px] leading-snug text-tg-sub">{sub}</span>}</span>
      <Toggle on={on} onChange={onChange} label={typeof title === 'string' ? title : undefined} />
    </div>
  );
}
type Tone = 'green' | 'orange' | 'red' | 'blue' | 'muted';
const toneCls = (t?: Tone) => (t === 'green' ? 'text-tg-ok' : t === 'orange' ? 'text-tg-orange' : t === 'red' ? 'text-tg-bad' : t === 'blue' ? 'text-tg-link' : t === 'muted' ? 'text-tg-sub' : '');
/** A number tile. */
export function Stat({ label, value, sub, tone, small, onClick, className }: { label: React.ReactNode; value: React.ReactNode; sub?: React.ReactNode; tone?: Tone; small?: boolean; onClick?: () => void; className?: string }) {
  const In = (
    <>
      <p className={clsx('font-medium text-tg-sub', small ? 'text-[11.5px]' : 'text-[12.5px]')}>{label}</p>
      <p className={clsx('af-num font-semibold', small ? 'mt-0.5 text-[16px]' : 'mt-0.5 text-[21px] leading-tight', toneCls(tone))}>{value}</p>
      {sub && <p className={clsx('mt-0.5 leading-snug text-tg-sub', small ? 'text-[11px]' : 'text-[12px]')}>{sub}</p>}
    </>
  );
  const cls = clsx(small ? 'rounded-xl bg-tg-input px-2.5 py-2' : 'af-card min-w-0 px-4 py-3', className);
  return onClick ? <button type="button" onClick={onClick} className={clsx(cls, 'af-press block w-full text-left hover:bg-tg-hover')}>{In}</button> : <div className={cls}>{In}</div>;
}
/** v167: `title` + `icon` give the centred "All clear" look; plain `text` keeps the old one-paragraph look. */
export function EmptyState({ text, action, title, icon }: { text: React.ReactNode; action?: React.ReactNode; title?: React.ReactNode; icon?: React.ReactNode }) {
  return (
    <div className="af-card px-6 py-9 text-center text-[14px] leading-relaxed text-tg-sub">
      {icon && <div className="mx-auto mb-3 grid h-12 w-12 place-items-center rounded-full bg-tg-oksoft text-tg-ok">{icon}</div>}
      {title && <p className="mb-1 text-[17px] font-semibold text-tg-text">{title}</p>}
      {text}{action && <div className="mt-4 flex justify-center">{action}</div>}
    </div>
  );
}
/** Static loading blocks (no shimmer). */
export function Skeleton({ rows = 3, h = 64 }: { rows?: number; h?: number }) {
  return <div className="grid gap-2.5" aria-busy="true" aria-label="Loading">{Array.from({ length: rows }, (_, i) => <div key={i} className="af-skel rounded-[14px] bg-tg-panel" style={{ height: h }} />)}</div>;
}
/** A row that scrolls sideways with soft edges. */
export function ScrollRow({ children, className }: { children: React.ReactNode; className?: string }) {
  return <div className={clsx('-mx-4 overflow-x-auto px-4 [mask-image:linear-gradient(to_right,transparent,#000_14px,#000_calc(100%-14px),transparent)] [scrollbar-width:none] md:mx-0 md:px-0', className)}>{children}</div>;
}
/** v167: the label next to "‹" on pushed pages (the shell sets it to the page we came from). */
export const PageBackLabel = createContext('Back');
/** Page frame of the admin app.
 *  Root pages (no `back`): kicker + large title, `action` = round icon buttons on the right.
 *  Pushed pages (`back`): a compact nav bar "‹ More | Title | action" on phones.
 *  `right` = the filter row under the title (date / line pills…), `below` = anything after it. */
export function Page({ title, right, back, children, below, kicker, action }: { title: string; right?: React.ReactNode; back?: () => void; children: React.ReactNode; below?: React.ReactNode; kicker?: React.ReactNode; action?: React.ReactNode }) {
  const backLabel = useContext(PageBackLabel);
  return (
    <div className={clsx('mx-auto max-w-[1100px] px-4 pb-8 md:px-8 md:pt-8', back ? 'pt-[env(safe-area-inset-top)]' : 'pt-[calc(12px+env(safe-area-inset-top))]')} data-page={title}>
      {back && (
        <div className="sticky top-[env(safe-area-inset-top)] z-30 -mx-4 mb-2 grid h-[50px] grid-cols-[minmax(72px,1fr)_minmax(0,auto)_minmax(72px,1fr)] items-center gap-1 bg-tg-bg px-2 md:hidden" data-navbar>
          <button onClick={back} aria-label="Back" className="flex h-10 min-w-0 items-center gap-0.5 justify-self-start rounded-full pr-2 text-[16px] text-tg-link"><ChevronLeft size={26} strokeWidth={2.2} className="-mr-0.5 shrink-0" /><span className="truncate">{backLabel}</span></button>
          <h1 className="truncate text-center text-[17px] font-semibold">{title}</h1>
          <div className="flex items-center justify-self-end gap-2">{action}</div>
        </div>
      )}
      <div className={clsx('mb-3 flex items-end justify-between gap-3', back && 'hidden md:flex')}>
        <div className="min-w-0">
          {kicker && <p className="af-kicker mb-0.5 truncate">{kicker}</p>}
          <h1 className="af-title truncate">{title}</h1>
        </div>
        {action && <div className="flex shrink-0 items-center gap-2 pb-0.5">{action}</div>}
      </div>
      {right && <div className="mb-3 flex flex-wrap items-center gap-2" data-page-tools>{right}</div>}
      {below}
      {children}
    </div>
  );
}
/** Small chip filter row (single choice). v167: active = dark fill, count shown muted inside the chip. */
export function Chips<T extends string>({ value, onChange, items, className }: { value: T; onChange: (v: T) => void; items: [T, React.ReactNode, number?][]; className?: string }) {
  return (
    <div className={clsx('flex gap-2 overflow-x-auto pb-0.5 [scrollbar-width:none]', className)}>
      {items.map(([v, l, n]) => (
        <button key={v} type="button" aria-pressed={value === v} onClick={() => onChange(v)} className="af-chip af-press">
          {l}{!!n && <span key={n} className="af-c af-pop af-num">{n}</span>}
        </button>
      ))}
    </div>
  );
}

/* ---------------- v167: premium design system primitives (doc: review166/build/design-system.md) ---------------- */
/** Money with a true minus: −$50, $1,240. */
export const money = (n: number | null | undefined) => (n == null || Number.isNaN(Number(n)) ? '—' : (Number(n) < 0 && Math.round(Math.abs(Number(n)) * 100) > 0 ? '−' : '') + usd(Math.abs(Number(n)))); // senior-ui: no "−$0" for −0.004
/** Inset grouped list. `tiles` = rows start with a 30px icon tile (divider starts after it), `avs` = rows start with a 40px avatar. */
export function Group({ children, tiles, avs, className, ...rest }: { children: React.ReactNode; tiles?: boolean; avs?: boolean; className?: string } & React.HTMLAttributes<HTMLDivElement>) {
  return <div {...rest} className={clsx('af-group', tiles && 'af-tiles', avs && 'af-avs', className)}>{children}</div>;
}
/** Section header above a group: "NEEDS YOU ········ Inbox". */
export function SectionHead({ title, action, onAction, className }: { title: React.ReactNode; action?: React.ReactNode; onAction?: () => void; className?: string }) {
  return <div className={clsx('af-h2', className)}><span>{title}</span>{action && (onAction ? <button type="button" onClick={onAction}>{action}</button> : <span className="text-[13px] font-medium normal-case tracking-normal text-tg-sub">{action}</span>)}</div>;
}
/** Coloured icon tile. */
export function IconTile({ icon: I, color, size = 'md' }: { icon: any; color: string; size?: 'md' | 'lg' }) {
  return <span className={clsx('af-tile', size === 'lg' && 'lg')} style={{ background: color }}><I size={size === 'lg' ? 19 : 17} strokeWidth={2.1} /></span>;
}
/** Tile colours (Telegram-settings hues). */
export const TILE = { blue: '#3390EC', green: '#34C759', orange: '#FF9500', red: '#FF3B30', purple: '#AF52DE', indigo: '#5856D6', teal: '#30B0C7', pink: '#FF2D55', grey: '#8E8E93', yellow: '#F2B200', cyan: '#32ADE6', brown: '#A2845E' } as const;
type TagTone = 'ok' | 'bad' | 'warn' | 'acc' | 'prem' | 'fun' | 'mute';
export function Tag({ tone = 'mute', children, className }: { tone?: TagTone; children: React.ReactNode; className?: string }) {
  return <span className={clsx('af-tag', tone, className)}>{children}</span>;
}
/** Count badge: red = needs action (default), blue = unread, orange = waiting. Hidden at 0. */
export function Badge({ n, tone, className }: { n: number; tone?: 'red' | 'blue' | 'orange'; className?: string }) {
  if (!n) return null;
  return <span key={n} className={clsx('af-badge af-pop', tone === 'blue' && 'blue', tone === 'orange' && 'orange', className)}><i className="af-n">{n > 99 ? '99+' : n}</i></span>; // v168 F1: centred digit
}
/** A list row: [tile/avatar] title + 1-line sub · value · badge · chevron. A button when onClick is set. */
export function Row({ icon, title, sub, value, badge, chevron, onClick, right, className, danger, center, ...rest }: { icon?: React.ReactNode; title: React.ReactNode; sub?: React.ReactNode; value?: React.ReactNode; badge?: React.ReactNode; chevron?: boolean; onClick?: () => void; right?: React.ReactNode; className?: string; danger?: boolean; center?: boolean } & Omit<React.HTMLAttributes<HTMLElement>, 'title'>) {
  const In = (
    <>
      {icon}
      <span className={clsx('min-w-0 flex-1', center && 'text-center')}>
        <span className={clsx('block truncate text-[15.5px]', danger ? 'text-tg-bad' : '')}>{title}</span>
        {sub && <span className="mt-px block truncate text-[13px] text-tg-sub">{sub}</span>}
      </span>
      {value != null && value !== '' && <span className="max-w-[55%] shrink-0 truncate text-right text-[14.5px] text-tg-sub af-num">{value}</span>}
      {badge}
      {right}
      {(chevron ?? !!onClick) && !center && <ChevronRight size={18} className="-mr-1 shrink-0 text-tg-faint" />}
    </>
  );
  return onClick ? <button type="button" {...(rest as any)} onClick={onClick} className={clsx('af-row', className)}>{In}</button> : <div {...(rest as any)} className={clsx('af-row', className)}>{In}</div>;
}
/** Tiny line chart (real data only — hidden when there are fewer than 2 points or all are 0). */
export function Spark({ values, className, color = 'rgb(var(--tg-acc))', height = 56 }: { values: number[]; className?: string; color?: string; height?: number }) {
  const v = values.map(Number).filter(x => Number.isFinite(x));
  if (v.length < 2 || v.every(x => x === 0)) return null;
  const W = 300, H = height, min = Math.min(...v), max = Math.max(...v), span = max - min || 1;
  const pts = v.map((x, i) => [(i / (v.length - 1)) * W, H - 4 - ((x - min) / span) * (H - 10)]);
  const line = pts.map(([x, y], i) => `${i ? 'L' : 'M'}${x.toFixed(1)} ${y.toFixed(1)}`).join(' ');
  const gid = 'sp' + Math.round(min * 13 + max * 7 + v.length);
  return (
    <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" className={clsx('block w-full', className)} style={{ height: H }} aria-hidden>
      <defs><linearGradient id={gid} x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor={color} stopOpacity=".22" /><stop offset="1" stopColor={color} stopOpacity="0" /></linearGradient></defs>
      <path d={`${line} L${W} ${H} L0 ${H} Z`} fill={`url(#${gid})`} />
      <path d={line} fill="none" stroke={color} strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" vectorEffect="non-scaling-stroke" />
    </svg>
  );
}
/** Small bar chart (real data only). The last bar can be highlighted. */
export function MiniBars({ values, labels, className, highlightLast }: { values: number[]; labels?: string[]; className?: string; highlightLast?: boolean }) {
  const v = values.map(x => Math.max(0, Number(x) || 0));
  if (v.length < 2 || v.every(x => x === 0)) return null;
  const max = Math.max(...v);
  return (
    <div className={clsx('flex h-[52px] items-end gap-[5px]', className)} aria-hidden>
      {v.map((x, i) => <span key={i} title={labels?.[i]} className={clsx('min-w-0 flex-1 rounded-[4px]', highlightLast && i === v.length - 1 ? 'bg-tg-green' : 'bg-tg-acc')} style={{ height: `${Math.max(6, (x / max) * 100)}%`, opacity: x ? 1 : 0.3 }} />)}
    </div>
  );
}
/** (i) button: the long explanation lives in a small sheet instead of under every title. */
export function InfoTip({ title, children, className, label = 'More info' }: { title: string; children: React.ReactNode; className?: string; label?: string }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button type="button" aria-label={label} onClick={e => { e.stopPropagation(); setOpen(true); }} className={clsx('relative inline-grid h-[22px] w-[22px] shrink-0 place-items-center rounded-full text-tg-sub after:absolute after:-inset-2 after:content-[""] hover:text-tg-link', className)}><Info size={17} /></button>
      <Sheet open={open} onClose={() => setOpen(false)} title={title}><div className="pb-2 text-[14.5px] leading-relaxed text-tg-sub">{children}</div></Sheet>
    </>
  );
}
/** Dropdown pill (date / line / person): opens a small menu. Items: [value, label, extra?]. */
export function DropPill<T extends string>({ value, onChange, items, label, icon, className, dot, menuTitle }: { value: T; onChange: (v: T) => void; items: [T, React.ReactNode, React.ReactNode?][]; label?: React.ReactNode; icon?: React.ReactNode; className?: string; dot?: string; menuTitle?: string }) {
  const [open, setOpen] = useState(false);
  const btn = useRef<HTMLButtonElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState<{ left: number; top: number; up: boolean }>({ left: 0, top: 0, up: false });
  const cur = items.find(i => i[0] === value);
  useEffect(() => {
    if (!open) return;
    const r = btn.current?.getBoundingClientRect(); if (!r) return;
    const W = Math.min(260, window.innerWidth - 24);
    const left = Math.max(12, Math.min(r.left, window.innerWidth - W - 12));
    const up = r.bottom + 320 > window.innerHeight && r.top > 340;
    setPos({ left, top: up ? r.top - 6 : r.bottom + 6, up });
    // senior-ui: scrolling inside the menu itself (a long agent list) must not close it
    const close = (e: Event) => { if (e.type === 'keydown' && (e as KeyboardEvent).key !== 'Escape') return; if (e.type === 'scroll' && e.target instanceof Node && menuRef.current?.contains(e.target)) return; setOpen(false); };
    window.addEventListener('scroll', close, true); window.addEventListener('resize', close); window.addEventListener('keydown', close);
    return () => { window.removeEventListener('scroll', close, true); window.removeEventListener('resize', close); window.removeEventListener('keydown', close); };
  }, [open]);
  useBackEntry(open, () => setOpen(false));
  const theme = typeof document !== 'undefined' && document.querySelector('.tg-auto') ? 'tg-auto contents' : 'contents';
  return (
    <>
      <button ref={btn} type="button" aria-haspopup="listbox" aria-expanded={open} onClick={() => setOpen(o => !o)} className={clsx('af-pill af-press', className)} data-drop-pill>
        {dot && <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: dot }} />}{icon}
        <span className="min-w-0 truncate">{label ?? cur?.[1] ?? value}</span><ChevronDown size={15} strokeWidth={2.2} />
      </button>
      {open && typeof document !== 'undefined' && createPortal(
        <div className={theme}>
          {/* senior-ui: close on click, not on touchstart — removing the overlay at touchstart let the tap "fall through" to the button under it */}
          <div className="fixed inset-0 z-[255]" onClick={e => { e.preventDefault(); e.stopPropagation(); setOpen(false); }} />
          <div ref={menuRef} role="listbox" aria-label={menuTitle} className="af-menu fixed z-[260] max-h-[min(60vh,420px)] w-[min(260px,calc(100vw-24px))] overflow-y-auto rounded-[14px] bg-tg-menu py-1 text-tg-text shadow-[0_12px_40px_rgba(0,0,0,0.28)] ring-1 ring-tg-sep"
            style={{ left: pos.left, top: pos.up ? undefined : pos.top, bottom: pos.up ? window.innerHeight - pos.top : undefined, transformOrigin: pos.up ? 'bottom left' : 'top left' }}>
            {menuTitle && <p className="px-4 pb-1 pt-2 text-[12px] font-semibold uppercase tracking-wide text-tg-sub">{menuTitle}</p>}
            {items.map(([v, l, x]) => (
              <button key={v} role="option" aria-selected={v === value} type="button" onClick={() => { setOpen(false); onChange(v); }} className="flex w-full items-center gap-2.5 px-4 py-2.5 text-left text-[15px] hover:bg-tg-hover active:bg-tg-hover">
                <span className="min-w-0 flex-1 truncate">{l}</span>{x && <span className="shrink-0 text-[13px] text-tg-sub af-num">{x}</span>}
                <Check size={17} className={clsx('shrink-0 text-tg-link', v !== value && 'invisible')} />
              </button>
            ))}
          </div>
        </div>, document.body)}
    </>
  );
}
/** "● Live · 2m" — when the numbers were last loaded. */
export function LivePill({ at }: { at: number | null }) {
  const [, tick] = useState(0);
  useEffect(() => { const t = setInterval(() => tick(x => x + 1), 30000); return () => clearInterval(t); }, []);
  if (!at) return null;
  const m = Math.floor((Date.now() - at) / 60000);
  return <span className="af-pill !gap-1.5 !font-medium text-tg-sub" data-live><span className="h-2 w-2 rounded-full bg-[#34C759]" />{m < 1 ? 'Live' : `Live · ${m}m`}</span>;
}
/** A stacked bar with a legend: parts [label, value, colour]. Hidden when the total is 0. */
export function SplitBar({ parts, fmt = String, className }: { parts: [string, number, string][]; fmt?: (n: number) => string; className?: string }) {
  const p = parts.filter(x => Number(x[1]) > 0); const tot = p.reduce((a, x) => a + Number(x[1]), 0);
  if (!tot) return null;
  return (
    <div className={className}>
      <div className="af-bar !h-2 gap-[2px] !bg-transparent">{p.map(([l, v, c]) => <i key={l} style={{ width: `${(v / tot) * 100}%`, background: c }} className="rounded-[3px]" />)}</div>
      <div className="mt-2 flex flex-wrap gap-x-3.5 gap-y-1 text-[12.5px] text-tg-sub">{p.map(([l, v, c]) => <span key={l} className="inline-flex items-center gap-1.5"><span className="h-2 w-2 rounded-full" style={{ background: c }} />{l} <span className="af-num">{fmt(v)}</span><span className="af-num opacity-70">{Math.round((v / tot) * 100)}%</span></span>)}</div>
    </div>
  );
}

/* ---------------- time helpers ---------------- */
export const hhmm = (ms: number) => new Date(ms).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
export function listTime(ms?: number | null) {
  if (!ms) return '';
  const d = new Date(ms), n = new Date();
  if (d.toDateString() === n.toDateString()) return hhmm(ms);
  if (n.getTime() - ms < 6 * 86400000) return d.toLocaleDateString([], { weekday: 'short' });
  return d.toLocaleDateString([], { day: 'numeric', month: 'short' });
}
export function dayLabel(ms: number) {
  const d = new Date(ms), n = new Date();
  if (d.toDateString() === n.toDateString()) return 'Today';
  if (d.toDateString() === new Date(n.getTime() - 86400000).toDateString()) return 'Yesterday';
  return d.toLocaleDateString([], { day: 'numeric', month: 'long', year: d.getFullYear() === n.getFullYear() ? undefined : 'numeric' });
}
export const usd = (n: number | null | undefined) => (n == null ? '—' : '$' + (Math.round(Number(n) * 100) / 100).toLocaleString());

/* ---------------- polling hook ---------------- */
export function useInterval(fn: () => void, ms: number | null) {
  const ref = useRef(fn);
  ref.current = fn;
  useEffect(() => {
    if (ms == null) return;
    const id = setInterval(() => { if (document.visibilityState === 'visible') ref.current(); }, ms);
    const vis = () => { if (document.visibilityState === 'visible') ref.current(); };
    document.addEventListener('visibilitychange', vis);
    return () => { clearInterval(id); document.removeEventListener('visibilitychange', vis); };
  }, [ms]);
}

/** Loud “ding-ding-DING” + vibration for a new lead / message while the app is open. */
let alertAudio: HTMLAudioElement | null = null;
/** v134: the team sound the admin uploaded ('' = built-in). */
let beepSrc = '/sounds/alert.mp3';
export function setBeepSound(ver: string | null | undefined) {
  const src = ver && ver !== '0' ? '/api/notif-sound?v=' + encodeURIComponent(ver) : '/sounds/alert.mp3';
  if (src !== beepSrc) { beepSrc = src; alertAudio = null; }
}
/** v144: an in-app alert for a LIVE event — gated by beepgate (visible only; the phone's ringer + ring-on-silent for this person). */
export function beep() {
  void import('./beepgate').then(g => g.beepAction()).then(a => {
    if (a === 'sound') playAlert();
    else if (a === 'vibrate') { try { navigator.vibrate?.([400, 200, 400]); } catch { /* ignore */ } }
  }).catch(() => { /* never ring when the gate fails */ });
}
/** The sound itself (media stream) + vibration. Only through beep(), except the "test sound" buttons. */
export function playAlert() {
  try {
    if (!alertAudio) { alertAudio = new Audio(beepSrc); alertAudio.preload = 'auto'; }
    alertAudio.currentTime = 0; alertAudio.volume = 1;
    void alertAudio.play().catch(() => synthBeep());
  } catch { synthBeep(); }
  try { navigator.vibrate?.([400, 200, 400, 200, 600]); } catch { /* ignore */ }
}
function synthBeep() {
  try {
    const C = window.AudioContext || (window as any).webkitAudioContext; const c = new C();
    [[988, 0], [1319, 0.12], [1760, 0.24]].forEach(([f, t]) => {
      const o = c.createOscillator(), g = c.createGain(); o.type = 'triangle'; o.frequency.value = f; o.connect(g); g.connect(c.destination);
      g.gain.setValueAtTime(0.0001, c.currentTime + t); g.gain.exponentialRampToValueAtTime(0.5, c.currentTime + t + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + t + 0.5);
      o.start(c.currentTime + t); o.stop(c.currentTime + t + 0.55);
    });
  } catch { /* ignore */ }
}

/** v124: our own UI shows no phone-style emojis (system notes, task notes…). Customer messages keep theirs. */
const EMO_RE = /[\u{1F000}-\u{1FAFF}\u{2600}-\u{26FF}\u2705\u2728\u274C\u274E\u2753-\u2757\u2795-\u2797\u27B0\u27BF\u2B50\u2B55\u23E9-\u23FA\u231A\u231B\u2709\u270F\u2702\u261D\u21A9\u21AA\u2139\u2194-\u2199]\uFE0F?[ \u00a0]?/gu;
export const noEmoji = (t: string | null | undefined) => String(t ?? '').replace(EMO_RE, '').replace(/[ \t]{2,}/g, ' ').trim();

/** v160: "Same day" / "1 day" / "4.5 days" / — */
export const daysTxt = (n: number | null | undefined) => n == null ? '—' : n < 1 ? 'Same day' : `${n % 1 ? n.toFixed(1) : n} day${n === 1 ? '' : 's'}`;
/** v135: Today / Yesterday / 7 / 30 days / Lifetime + "Date": one day or a from–to. */
export function RangePick({ value, onChange, months }: { value: string; onChange: (v: string) => void; months?: boolean }) {
  const custom = value.startsWith('d:');
  const [open, setOpen] = useState(custom);
  const today = new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10);
  const [a, b] = custom ? [value.split(':')[1], value.split(':')[2] || value.split(':')[1]] : [today, today];
  const set = (x: string, y: string) => onChange(`d:${x}${y && y !== x ? ':' + y : ''}`);
  // v167: one "Today ▾" dropdown pill instead of a sideways-scrolling row (the dates row appears under it for "Pick dates")
  const items = (months ? [['today', 'Today'], ['yesterday', 'Yesterday'], ['month', 'This month'], ['lastmonth', 'Last month'], ['all', 'Lifetime'], ['custom', 'Pick dates…']] : [['today', 'Today'], ['yesterday', 'Yesterday'], ['7d', 'Last 7 days'], ['30d', 'Last 30 days'], ['all', 'Lifetime'], ['custom', 'Pick dates…']]) as [string, string][];
  const short: Record<string, string> = { '7d': '7 days', '30d': '30 days' };
  const fmtD = (s: string) => new Date(s + 'T00:00:00').toLocaleDateString([], { day: 'numeric', month: 'short' });
  const label = open || custom ? (a === b ? fmtD(a) : `${fmtD(a)} – ${fmtD(b)}`) : short[value] || items.find(i => i[0] === value)?.[1] || value;
  return (
    <div className="contents" data-range-pick>
      <DropPill value={open ? 'custom' : value} label={label} icon={open || custom ? <CalendarDays size={14} /> : undefined} menuTitle="Period" items={items as any}
        onChange={v => { if (v === 'custom') { setOpen(true); if (!custom) set(today, today); } else { setOpen(false); onChange(v); } }} />
      {open && <div className="flex w-full basis-full items-center gap-1.5 text-[13px]" data-range-dates>
        <input type="date" max={today} value={a} onChange={e => e.target.value && set(e.target.value, b < e.target.value ? e.target.value : b)} className="min-w-0 flex-1 rounded-[10px] bg-tg-panel px-2 py-1.5 text-tg-text" aria-label="From" />
        <span className="text-tg-sub">to</span>
        <input type="date" max={today} value={b} min={a} onChange={e => e.target.value && set(a, e.target.value)} className="min-w-0 flex-1 rounded-[10px] bg-tg-panel px-2 py-1.5 text-tg-text" aria-label="To" />
      </div>}
    </div>
  );
}

/* v137: Telegram / WhatsApp switch at the top of the chat lists — a slim segmented control: neutral track, a sliding
   elevated thumb, the brand colour only on the small icon, the unread count as a small pill. */
export function TgGlyph({ size = 15, className }: { size?: number; className?: string }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden className={className}><circle cx="12" cy="12" r="12" fill="#229ED9" /><path fill="#fff" d="M5.4 11.7l10.9-4.2c.5-.2 1 .1.8.9l-1.9 8.8c-.1.6-.5.8-1 .5l-2.8-2.1-1.4 1.3c-.2.2-.3.3-.6.3l.2-2.9 5.3-4.8c.2-.2 0-.3-.3-.1l-6.6 4.1-2.8-.9c-.6-.2-.6-.6.2-.9z" /></svg>;
}
export function WaGlyph({ size = 15, className }: { size?: number; className?: string }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden className={className}><path fill="#25D366" d="M12 1.5A10.4 10.4 0 0 0 3.1 17.3L1.6 22.5l5.4-1.4A10.4 10.4 0 1 0 12 1.5z" /><path fill="#fff" d="M17.2 14.5c-.3-.1-1.7-.8-1.9-.9-.3-.1-.5-.1-.6.1l-.9 1.1c-.2.2-.3.2-.6.1a7.1 7.1 0 0 1-3.5-3.1c-.3-.5.3-.4.8-1.4.1-.2 0-.3 0-.5l-.9-2c-.2-.5-.4-.5-.6-.5h-.5a1 1 0 0 0-.7.3 3 3 0 0 0-.9 2.2 5.2 5.2 0 0 0 1.1 2.8 11.9 11.9 0 0 0 4.6 4c1.7.7 2.3.8 3.2.7a2.7 2.7 0 0 0 1.8-1.3 2.2 2.2 0 0 0 .2-1.3c-.1-.1-.3-.2-.6-.3z" /></svg>;
}
export function ChanSwitch({ value, onChange, unread, className, id = 'chsw' }: { value: 'tg' | 'wa'; onChange: (v: 'tg' | 'wa') => void; unread: (k: 'tg' | 'wa') => number; className?: string; id?: string }) {
  return (
    <div role="tablist" aria-label="Chats on" data-chan-switch data-id={id} className={clsx('relative grid h-9 grid-cols-2 rounded-[11px] bg-tg-line p-[3px]', className)}>
      {/* v160: plain CSS thumb (a framer layoutId re-slid from nowhere every time the list came back after a chat) */}
      <span aria-hidden className="absolute inset-y-[3px] left-[3px] w-[calc(50%-3px)] rounded-[8px] bg-tg-panel shadow-[0_1px_2px_rgba(0,0,0,0.14),0_0_0_0.5px_rgba(0,0,0,0.06)] transition-transform duration-200 ease-[var(--ease-out)]" style={{ transform: value === 'wa' ? 'translateX(100%)' : 'none' }}>
        <span className={clsx('absolute inset-x-0 bottom-0 mx-auto h-[2px] w-5 rounded-full transition-colors duration-200', value === 'wa' ? 'bg-[#25D366]' : 'bg-[#229ED9]')} />
      </span>
      {([['tg', 'Telegram'], ['wa', 'WhatsApp']] as const).map(([k, l]) => {
        const on = value === k, n = unread(k);
        return (
          <button key={k} role="tab" aria-selected={on} data-chan-btn={k} onClick={() => onChange(k)}
            className={clsx('relative flex min-w-0 items-center justify-center gap-1.5 rounded-[8px] text-[13.5px] font-semibold transition-colors', on ? 'text-tg-text' : 'text-tg-sub hover:text-tg-text')}>
            <span className="relative flex items-center gap-1.5">
              {k === 'tg' ? <TgGlyph className={on ? '' : 'opacity-60 grayscale-[35%]'} /> : <WaGlyph className={on ? '' : 'opacity-60 grayscale-[35%]'} />}
              <span className="truncate">{l}</span>
              {n > 0 && <span key={n} className={clsx('af-pop af-cnt h-[18px] min-w-[18px] rounded-full px-1 text-[11px] font-bold', on ? 'bg-tg-acc text-white' : 'bg-tg-sub/25 text-tg-text')}><i className="af-n">{n > 99 ? '99+' : n}</i></span>}
            </span>
          </button>
        );
      })}
    </div>
  );
}

/** v161: "What sold" — one row per product that sold in the period (+ top-ups / website / replacements rows passed in `extra`). */
export type ProductRow = { k: string; label: string; n: number; units: number; rev: number; comm?: number; wa_n?: number; wa_rev?: number };
export function WhatSold({ rows, extra = [], showComm, className }: { rows: ProductRow[]; extra?: { label: string; main: string; sub?: string }[]; showComm?: boolean; className?: string }) {
  const sold = rows.filter(r => r.n > 0);
  const unit = (r: ProductRow) => r.k === 'funnel' ? `${r.units} month${r.units === 1 ? '' : 's'}` : ['agency', 'premium', 'full'].includes(r.k) ? `${r.units} account${r.units === 1 ? '' : 's'}` : `${r.units} sold`;
  return (
    <div className={clsx('overflow-hidden rounded-2xl bg-tg-panel', className)} data-what-sold>
      {!sold.length && !extra.length && <p className="px-4 py-4 text-[14px] text-tg-sub">Nothing sold in this period.</p>}
      {sold.map(r => (
        <div key={r.k} className="flex items-center gap-3 border-b border-tg-line px-4 py-2.5 last:border-0" data-product={r.k}>
          <span className="min-w-0 flex-1"><span className="block truncate text-[14.5px] font-medium">{r.label}</span>
            <span className="block text-[12px] text-tg-sub">{unit(r)} · {r.n} sale{r.n === 1 ? '' : 's'}{r.wa_n ? ` · WhatsApp ${r.wa_n} (${usd(r.wa_rev || 0)})` : ''}{showComm && r.comm ? ` · commission ${usd(r.comm)}` : ''}</span></span>
          <b className="shrink-0 text-[15px] tabular-nums text-tg-ok">{usd(r.rev)}</b>
        </div>
      ))}
      {extra.map(x => (
        <div key={x.label} className="flex items-center gap-3 border-b border-tg-line px-4 py-2.5 last:border-0">
          <span className="min-w-0 flex-1"><span className="block truncate text-[14.5px] font-medium">{x.label}</span>{x.sub && <span className="block text-[12px] text-tg-sub">{x.sub}</span>}</span>
          <b className="shrink-0 text-[15px] tabular-nums">{x.main}</b>
        </div>
      ))}
    </div>
  );
}

/** v161: chats and sales by where the person came from (WhatsApp page, Telegram channel, lead ads, products page, client badge…). */
export function SourceTable({ rows }: { rows: { k: string; label: string; chats: number; wrote: number; sales: number; buyers: number; rev: number }[] }) {
  const tot = rows.reduce((a, r) => ({ chats: a.chats + r.chats, sales: a.sales + r.sales, rev: a.rev + r.rev }), { chats: 0, sales: 0, rev: 0 });
  const pct = (r: { wrote: number; buyers: number }) => { const b = Math.max(r.wrote, r.buyers); return b ? Math.round(r.buyers / b * 100) : 0; };
  return (
    <div className="overflow-hidden rounded-2xl bg-tg-panel" data-sources>
      {rows.map(r => (
        <div key={r.k} data-source={r.k} className="flex items-center gap-3 border-b border-tg-line px-4 py-2.5">
          <span className="min-w-0 flex-1"><span className="block text-[14.5px] font-medium leading-snug">{r.label}</span>
            <span className="block text-[12px] text-tg-sub">{[r.chats ? `${r.chats} new chat${r.chats === 1 ? '' : 's'}` : '', r.wrote ? `${r.wrote} wrote` : '', r.buyers ? `${r.buyers} bought${r.wrote ? ` (${pct(r)}%)` : ''}` : ''].filter(Boolean).join(' · ') || 'No chats'}</span></span>
          <span className="shrink-0 text-right"><b className={clsx('block text-[15px] tabular-nums', r.rev ? 'text-tg-ok' : 'text-tg-sub')}>{usd(r.rev)}</b><span className="block text-[12px] tabular-nums text-tg-sub">{r.sales} sale{r.sales === 1 ? '' : 's'}</span></span>
        </div>
      ))}
      <div className="flex items-center gap-3 bg-tg-input/50 px-4 py-2.5 text-[14px] font-semibold">
        <span className="flex-1">Total <span className="font-normal text-tg-sub">· {tot.chats} new chat{tot.chats === 1 ? '' : 's'} · {tot.sales} sale{tot.sales === 1 ? '' : 's'}</span></span><span className="tabular-nums">{usd(tot.rev)}</span>
      </div>
      <p className="px-4 pb-3 pt-1.5 text-[11.5px] leading-relaxed text-tg-sub">Sales are counted by where that person first came from, also when they buy again.</p>
    </div>
  );
}
