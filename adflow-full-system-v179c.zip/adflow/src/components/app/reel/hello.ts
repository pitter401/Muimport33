// v167: "Good morning" / the agent's first name as Allura glyph outlines (stroke-drawn like handwriting).
// The outlines are pre-baked (allura.ts); here we only lay the glyphs out with their advance widths.
import { ALLURA } from './allura';

export type Glyphs = { w: number; asc: number; desc: number; glyphs: { x: number; d: string }[] };

/** Can this text be written with the baked glyphs? (Latin letters, digits, basic punctuation.) */
export const canWrite = (s: string) => !!s && [...s].every(ch => ch in ALLURA.g);

export function layout(text: string): Glyphs {
  let x = 0;
  const glyphs: { x: number; d: string }[] = [];
  for (const ch of text) {
    const g = ALLURA.g[ch];
    if (!g) continue;
    if (g[1]) glyphs.push({ x, d: g[1] });
    x += g[0];
  }
  return { w: x, asc: ALLURA.asc, desc: ALLURA.desc, glyphs };
}

/** Business-neutral greeting by the phone's local hour (same split as the agent splash). */
export const greeting = (d = new Date()) => { const h = d.getHours(); return h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening'; };
export const partOfDay = (d = new Date()) => { const h = d.getHours(); return h < 12 ? 'Morning' : h < 17 ? 'Afternoon' : 'Evening'; };
