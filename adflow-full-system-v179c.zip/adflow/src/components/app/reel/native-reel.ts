'use client';
/* v168: bridge to the app's native Daily-reel downloader (Android app 1.7+, the "ReelCache" plugin). The app downloads
 * today's / tomorrow's reels in the BACKGROUND, also while it is closed (WorkManager, completely silent), into its own
 * storage and serves them to this page at https://<site>/__reelcache/<id>.mp4 (same origin, HTTP Range).
 * In a browser, the PWA or an older app (1.6 and below) every function here is a quick no-op (false / null), and the
 * web download into Cache Storage (cache.ts) is used as before. Nothing here ever shows anything to the user. */
import { noThen, withTimeout } from '../native';

type ReelCacheP = {
  has(o: { id: string; sha256?: string }): Promise<{ ok: boolean }>;
  url(o: { id: string }): Promise<{ url: string | null }>;
  queue(o: { list?: { id: number; url: string; size: number; sha256: string }[] }): Promise<{ ok: boolean }>;
  status(): Promise<Record<string, unknown>>;
};
let cached: Promise<ReelCacheP | null> | null = null;
const BAD = 'af_reel_native_bad';
const lsGet = (k: string) => { try { return localStorage.getItem(k); } catch { return null; } };

async function plugin(): Promise<ReelCacheP | null> {
  if (typeof window === 'undefined') return null;
  return (cached ||= (async () => {
    try {
      const { Capacitor, registerPlugin } = await import('@capacitor/core');
      if (!Capacitor.isNativePlatform() || !Capacitor.isPluginAvailable('ReelCache')) return null;
      return noThen(registerPlugin<ReelCacheP>('ReelCache'));
    } catch { return null; }
  })());
}
/** Native playback failed on this phone (e.g. the video element could not play the native URL) → use the web path from now on. */
export function markNativeBad() { try { localStorage.setItem(BAD, String(Date.now())); } catch { /* private mode */ } }
const bad = () => !!lsGet(BAD);

/** Is the app's native downloader there (app 1.7+, not marked bad)? */
export async function nativeAvailable() { return !bad() && !!(await plugin()); }

/** true = this reel (this sha256 version) is complete and verified in the app's own storage. false in browsers / old apps. */
export async function nativeHas(id: number | string, sha?: string | null): Promise<boolean> {
  if (bad()) return false;
  const p = await plugin(); if (!p) return false;
  try { return !!(await withTimeout(p.has({ id: String(id), sha256: sha || '' }), 1500, 'ReelCache.has')).ok; } catch { return false; }
}
/** A URL the page's <video> can play (same origin, Range), or null (not native / not downloaded). Call nativeHas first. */
export async function nativeUrl(id: number | string): Promise<string | null> {
  if (bad()) return null;
  const p = await plugin(); if (!p) return null;
  try { return (await withTimeout(p.url({ id: String(id) }), 1500, 'ReelCache.url')).url || null; } catch { return null; }
}
/** { src, revoke } like cache.ts readySrc, from the native copy — or null. */
export async function nativeSrc(f: { id: number; sha256?: string | null }): Promise<{ src: string; revoke: () => void } | null> {
  if (!(await nativeHas(f.id, f.sha256))) return null;
  const u = await nativeUrl(f.id);
  return u ? { src: u, revoke: () => { /* nothing to free */ } } : null;
}
/** Ask the app to download these now (it also asks the server itself). `api` = '/api/agent/reel' or '/api/admin/reel/view'.
 *  Returns true when the native downloader is in charge (healthy: its last server list call worked in the last 12 h) — then
 *  the web skips its own Cache Storage download, so a file is never downloaded twice. */
export async function nativeQueue(api: string, files: { id: number; file: string; size: number; sha256: string | null; url?: string }[]): Promise<boolean> {
  if (bad()) return false;
  const p = await plugin(); if (!p) return false;
  try {
    const list = files.filter(f => f.sha256).map(f => ({ id: f.id, url: f.url || `${api}/media/${encodeURIComponent(f.file)}`, size: f.size, sha256: f.sha256 as string }));
    await withTimeout(p.queue({ list }), 1500, 'ReelCache.queue');
    const st = await withTimeout(p.status(), 1500, 'ReelCache.status');
    return Date.now() - Number(st.list_ok_at || 0) < 12 * 3600000;
  } catch { return false; }
}
/** Waits up to `ms` for the native copy (polls every 500 ms). */
export async function nativeWait(id: number, sha: string | null | undefined, ms: number) {
  const t = Date.now();
  for (;;) {
    if (await nativeHas(id, sha)) return true;
    if (Date.now() - t >= ms) return false;
    await new Promise(r => setTimeout(r, 500));
  }
}
/** Debugging only (no UI): what the native downloader has and did. */
export async function nativeStatus(): Promise<Record<string, unknown> | null> {
  const p = await plugin(); if (!p) return null;
  try { return await withTimeout(p.status(), 1500, 'ReelCache.status'); } catch { return null; }
}
