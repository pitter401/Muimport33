'use client';
/* v168: in-app player for the agent daily-reel formats E–T (public/reel-tpl/<ID>/index.html, see _shared/live.js).
 *  Same props / callbacks as ReelPlayer (A–D), so ReelGate picks one by style id.
 *  - The template runs in a same-origin <iframe> in LIVE mode: its one <video> plays the gate's verified copy (a blob: URL
 *    from Cache Storage or the app's /__reelcache/<id>.mp4) in real time WITH its song from frame 0; the template's timeline
 *    follows video.currentTime (no seeking). Data goes in the URL fragment (#r=…), read before the template's runtime runs.
 *  - The iframe takes no input at all (pointer-events: none): no tap controls, no mute, no download. This parent owns the
 *    only hit areas: "Skip & open chats" (showings 2+ when skipping is allowed, over the template's own pill), "I'm ready"
 *    (over the end card's button) and, only when the WebView blocks sound, "Tap for sound" (a tap anywhere unlocks it).
 *  - Completion is recorded on `ended` with ≥ 90% really watched (as ReelPlayer); "I'm ready" closes once 90% is watched.
 *  - The 375 x 812 design is scaled to the screen (contain; cover when that crops ≤ 3.5% of the width). */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { ReelNext } from './ReelPlayer';
import { greeting } from './hello';
import { posterUrl } from './cache';
import { markNativeBad } from './native-reel';

export const TEMPLATE_STYLES = ['E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'AA', 'AB', 'AC', 'AD'] as const;
export type TemplateStyle = (typeof TEMPLATE_STYLES)[number];
export const isTemplateStyle = (s: unknown): s is TemplateStyle => typeof s === 'string' && (TEMPLATE_STYLES as readonly string[]).includes(s);
const RUNTIME = (s: string) => (s.length === 1 && s <= 'L' ? 'agentA' : 'agentB'); // v174: U–AD are agentB
export const templateUrl = (s: string) => `/reel-tpl/${s}/index.html`;

/** Warms the HTTP cache with the template's page, runtime, styles and fonts (call during the gate's decision time). */
const warmed = new Set<string>();
export function preloadTemplate(style: string) {
  if (typeof window === 'undefined' || !isTemplateStyle(style) || warmed.has(style)) return;
  warmed.add(style);
  const rt = RUNTIME(style), get = (u: string) => fetch(u, { credentials: 'same-origin' }).then(r => (r.ok ? r.text() : '')).catch(() => '');
  void get(templateUrl(style)); void get('/reel-tpl/_shared/live.js'); void get(`/reel-tpl/_shared/${rt}/core.js`);
  if (rt === 'agentA') void get('/reel-tpl/_shared/agentA/base.css');
  void get(`/reel-tpl/_shared/${rt}/fonts.css`).then(css => {
    const base = new URL(`/reel-tpl/_shared/${rt}/fonts.css`, location.href);
    const urls = new Set([...css.matchAll(/url\(([^)]+)\)/g)].map(m => new URL(m[1], base).href));
    urls.forEach(u => { void fetch(u, { credentials: 'same-origin' }).catch(() => {}); });
  });
}

type Props = { api: string; data: ReelNext; src: string; onSrcFail?: () => void; onExit: (r: { splash: boolean }) => void; post: (path: string, body: Record<string, unknown>) => Promise<any>; testSpeed?: number;
  /** the template could not start (page / fonts did not load in time) → the gate shows ReelPlayer instead */
  onFail?: () => void };
type Rect = { x: number; y: number; w: number; h: number };
type Msg = { src: 'reeltpl'; type: string; [k: string]: any };

const STALL_MS = 9000; // v179: after the page is up, the video must be playing by then
const BOOT_MS = 7000; // the page + its fonts must be up by then (they are preloaded and cached; normally < 1 s)

/* the 5-colour palette the agentB formats tint with — same method as their runtime, taken from the reel's poster */
async function posterPalette(url: string, ms: number): Promise<string[] | null> {
  if (!url) return null;
  const im = new Image(); im.crossOrigin = 'anonymous';
  const ok = await new Promise<boolean>(res => { const t = setTimeout(() => res(false), ms); im.onload = () => { clearTimeout(t); res(true); }; im.onerror = () => { clearTimeout(t); res(false); }; im.src = url; });
  if (!ok) return null;
  try {
    const c = document.createElement('canvas'); c.width = 48; c.height = 27;
    const x = c.getContext('2d', { willReadFrequently: true }); if (!x) return null;
    x.drawImage(im, 0, 0, 48, 27);
    const d = x.getImageData(0, 0, 48, 27).data, bins: Record<number, number[]> = {};
    for (let i = 0; i < d.length; i += 4) {
      const r = d[i] / 255, g = d[i + 1] / 255, b = d[i + 2] / 255, mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, dd = mx - mn;
      if (!dd) continue;
      const s = dd / (1 - Math.abs(2 * l - 1)); if (s < .25 || l < .12 || l > .93) continue;
      let H = mx === r ? ((g - b) / dd) % 6 : mx === g ? (b - r) / dd + 2 : (r - g) / dd + 4; H = ((H * 60) + 360) % 360;
      const k = Math.floor(H / 30), w = s * (1 - Math.abs(l - .5) * 1.2), a = bins[k] || (bins[k] = [0, 0, 0, 0]);
      a[0] += w; a[1] += d[i] * w; a[2] += d[i + 1] * w; a[3] += d[i + 2] * w;
    }
    const top = Object.values(bins).sort((a, b) => b[0] - a[0]).slice(0, 5).map(a => '#' + [a[1], a[2], a[3]].map(v => Math.round(v / a[0]).toString(16).padStart(2, '0')).join(''));
    if (!top.length) return null;
    while (top.length < 5) top.push(top[top.length - 1]);
    return top;
  } catch { return null; }
}

export function TemplatePlayer({ api, data, src, onSrcFail, onExit, post, onFail }: Props) {
  const d = data;
  const style = String(d.style);
  const theme = d.reel.theme === 'light' ? 'light' : 'dark';
  const canSkip = d.showing > 1 && !!d.skip; // showing 1 can never be skipped
  const frame = useRef<HTMLIFrameElement>(null);
  const [url, setUrl] = useState<string | null>(null);
  const [booted, setBooted] = useState(false);
  const [bg, setBg] = useState(theme === 'light' ? '#f4f1ec' : '#050608');
  const [ph, setPh] = useState<'intro' | 'stage' | 'end' | 'out'>('intro');
  const [muted, setMuted] = useState(false);
  const [skipR, setSkipR] = useState<Rect | null>(null);
  const [readyR, setReadyR] = useState<Rect | null>(null);
  const [hasPill, setHasPill] = useState(true);
  const [fit, setFit] = useState({ k: 1, W: 375, H: 812 });
  const viewId = useRef<number | null>(null);
  const prog = useRef({ t: 0, d: d.reel.duration || 1, watched: 0 });
  const started = useRef(false), endedRef = useRef(false), exitRef = useRef(false), wantExit = useRef(false), bootRef = useRef(false);
  const onExitRef = useRef(onExit); onExitRef.current = onExit;
  const onFailRef = useRef(onFail); onFailRef.current = onFail;

  /* ---------- the data the template gets (window.__REEL) ---------- */
  const reel = useMemo(() => {
    const now = new Date();
    const wd = now.toLocaleDateString('en-GB', { weekday: 'long' }), wds = now.toLocaleDateString('en-GB', { weekday: 'short' });
    const day = now.getDate(), mon = now.toLocaleDateString('en-GB', { month: 'long' }), mons = now.toLocaleDateString('en-GB', { month: 'short' });
    const qs = (d.quotes && d.quotes.length ? d.quotes : [d.quote]).map(q => String(q || '').trim()).filter(Boolean);
    const endQ = d.showing === 1 && qs.length >= 3 ? qs[qs.length - 1] : null; // as ReelPlayer: the end card's own quote
    const quotes = endQ ? qs.slice(0, -1) : qs;
    const y = d.yesterday, st = (d.streak_prev || 0) + 1;
    return {
      live: true, name: String(d.name || '').trim().split(/\s+/)[0] || '', greeting: greeting(now),
      date_long: `${wd}, ${day} ${mon}`, date_short: `${wds}, ${day} ${mons}`,
      quotes, line_of_day: d.reel.line || endQ || '',
      yesterday: y ? { earned: Math.max(0, Number(y.earned) || 0), sales: Math.max(0, Number(y.sales) || 0), ...(y.label ? { label: y.label } : {}) } : {},
      streak: st >= 2 ? st : 0, // positive only; a streak starts to count at 2 days (as ReelPlayer)
      video_url: src, video_duration: d.reel.duration || 0, theme, logo_url: '/reel/logo.png', showing: d.showing, skip: canSkip,
    } as Record<string, unknown>;
  }, [d, src, theme, canSkip]);

  /* ---------- build the page URL (palette from the poster: ≤ 350 ms, else the template picks its own) ---------- */
  const urlOnce = useRef(false);
  useEffect(() => {
    if (urlOnce.current) return; // the page loads once per showing, whatever the parent re-renders
    let on = true;
    preloadTemplate(style);
    void posterPalette(posterUrl(api, d.reel.poster), 350).then(pal => {
      if (!on || urlOnce.current) return;
      urlOnce.current = true;
      const r = pal ? { ...reel, palette: pal } : reel;
      setUrl(`${templateUrl(style)}#r=${encodeURIComponent(JSON.stringify(r))}`);
    });
    return () => { on = false; };
  }, [api, d.reel.poster, reel, style]);

  /* ---------- fit ---------- */
  useEffect(() => {
    const f = () => {
      const W = window.innerWidth, H = window.innerHeight, kc = Math.min(W / 375, H / 812), kv = Math.max(W / 375, H / 812);
      const crop = (375 * kv - W) / (375 * kv); // share of the width lost if it covers
      setFit({ k: H / 812 >= W / 375 || crop > 0.035 ? kc : kv, W, H });
    };
    f(); window.addEventListener('resize', f);
    return () => window.removeEventListener('resize', f);
  }, []);

  const send = useCallback((type: string) => { try { frame.current?.contentWindow?.postMessage({ src: 'reelhost', type }, location.origin); } catch { /* */ } }, []);

  /* ---------- exit ---------- */
  const exit = useCallback((splash: boolean, natural = false) => {
    if (exitRef.current) return;
    exitRef.current = true;
    setPh('out');
    if (!natural) send('pause'); // at the natural end the song has already faded with the last second
    setTimeout(() => onExitRef.current({ splash }), 480);
  }, [send]);
  const finish = useCallback((natural: boolean) => {
    if (endedRef.current) return;
    endedRef.current = true;
    const full = prog.current.watched >= (prog.current.d || d.reel.duration || 1) * 0.9;
    if (full) void (async () => {
      for (let i = 0; i < 6 && viewId.current === null; i++) await new Promise(r => setTimeout(r, 300)); // start may still be on its way
      for (let i = 0; i < 2; i++) {
        try { await post('done', { view_id: viewId.current, watched: Math.ceil(prog.current.watched * 10) / 10 }); break; } // up: a 90.0x% watch must not round below the server's 90% check
        catch { await new Promise(r => setTimeout(r, 600)); }
      }
    })();
    exit(d.showing === 1, natural);
  }, [d, post, exit]);

  /* ---------- messages from the template ---------- */
  useEffect(() => {
    const onMsg = (e: MessageEvent) => {
      const m = e.data as Msg;
      if (!m || m.src !== 'reeltpl' || e.source !== frame.current?.contentWindow) return;
      switch (m.type) {
        case 'boot': bootRef.current = true; setBooted(true); if (m.bg) setBg(m.bg); setHasPill(!!m.hasPill); break;
        case 'playing':
          if (!started.current) {
            started.current = true;
            void post('start', { showing: d.showing, reel_id: d.reel.id, style, q_at: d.q_at }).then(r => { viewId.current = r?.view_id ?? null; }).catch(() => {});
          }
          break;
        case 'sound': setMuted(!!m.muted); break;
        case 'progress':
          prog.current = { t: +m.t || 0, d: +m.d || prog.current.d, watched: +m.watched || 0 };
          if (wantExit.current && !endedRef.current && prog.current.watched >= prog.current.d * 0.9) finish(false);
          break;
        case 'phase': if (!exitRef.current) setPh(m.phase); break;
        case 'skip': setSkipR(m.on ? m.rect : null); break;
        case 'ready': setReadyR(m.on ? m.rect : null); break;
        case 'tap': if (m.what === 'skip') skipRef.current(); else if (m.what === 'ready') readyRef.current(); break;
        case 'ended': prog.current = { t: +m.t || 0, d: +m.d || prog.current.d, watched: +m.watched || prog.current.watched }; finish(true); break;
        case 'error': {
          diagRef.current('video-error', `code=${m.code}`);
          const native = !src.startsWith('blob:');
          if (native) markNativeBad();
          if (!started.current) { if (native && onSrcFail) onSrcFail(); else exit(true); }
          break;
        }
        case 'jserror': diagRef.current('jserror', String(m.msg || '').slice(0, 200)); try { frame.current?.parentElement?.setAttribute('data-tpl-error', String(m.msg || '').slice(0, 200)); } catch { /* */ } break;
      }
    };
    window.addEventListener('message', onMsg);
    return () => window.removeEventListener('message', onMsg);
  }, [d, style, post, finish, exit, src, onSrcFail]);

  /* ---------- v179: diagnostics to the server log + the video must really start ---------- */
  const srcKind = src.startsWith('blob:') ? 'blob' : src.includes('/__reelcache/') ? 'native' : 'url';
  const diag = useCallback((what: string, info = '') => {
    void post('diag', { what, info: `${info} ua=${navigator.userAgent.replace(/^.*?(Android [\d.]+|iPhone OS [\d_]+).*?(Chrome\/[\d.]+)?.*$/, '$1 $2')}`, style, showing: d.showing, reel_id: d.reel.id, src: srcKind }).catch(() => {});
  }, [post, style, d.showing, d.reel.id, srcKind]);
  const diagRef = useRef(diag); diagRef.current = diag;
  const onSrcFailRef = useRef(onSrcFail); onSrcFailRef.current = onSrcFail;
  // booted but the video never starts (seen on phones: intro drawn, then frozen) → native copy: mark it bad and use the web
  // copy; already the web copy: the gate plays this showing in ReelPlayer (A). Never a frozen screen.
  useEffect(() => {
    if (!booted) return;
    const t = setTimeout(() => {
      if (started.current || exitRef.current) return;
      diagRef.current('stall', `t=${prog.current.t.toFixed(1)} d=${prog.current.d}`);
      exitRef.current = true;
      if (srcKind === 'native') { markNativeBad(); if (onSrcFailRef.current) { onSrcFailRef.current(); return; } }
      if (onFailRef.current) onFailRef.current(); else onExitRef.current({ splash: true });
    }, STALL_MS);
    return () => clearTimeout(t);
  }, [booted, srcKind]); // refs only: the parent re-renders often and must not restart this timer

  /* ---------- the page must come up in time, else the gate falls back ---------- */
  useEffect(() => {
    const t = setTimeout(() => {
      if (bootRef.current || exitRef.current) return;
      diagRef.current('boot-timeout');
      exitRef.current = true;
      if (onFailRef.current) onFailRef.current(); else onExitRef.current({ splash: true });
    }, BOOT_MS);
    return () => clearTimeout(t);
  }, []);

  /* ---------- app hidden mid-reel: pause + report how far; back → go on ---------- */
  useEffect(() => {
    const vis = () => {
      if (document.visibilityState === 'hidden') {
        send('pause');
        if (viewId.current !== null && !endedRef.current) {
          const body = JSON.stringify({ view_id: viewId.current, pos: Math.round(prog.current.t) });
          try { navigator.sendBeacon?.(`${api}/pos`, new Blob([body], { type: 'application/json' })) || void post('pos', JSON.parse(body)).catch(() => {}); } catch { /* */ }
        }
      } else if (started.current && !endedRef.current && !exitRef.current) send('play');
    };
    document.addEventListener('visibilitychange', vis);
    return () => document.removeEventListener('visibilitychange', vis);
  }, [api, post, send]);

  /* ---------- a push notification tap leaves the reel (the chat opens) ---------- */
  useEffect(() => {
    const f = () => {
      if (started.current && canSkip && viewId.current !== null && !endedRef.current) void post('skip', { view_id: viewId.current, watched: Math.round(prog.current.watched) }).catch(() => {});
      exit(false);
    };
    window.addEventListener('af-push-open', f);
    return () => window.removeEventListener('af-push-open', f);
  }, [canSkip, post, exit]);

  const skip = () => {
    if (!canSkip || exitRef.current) return;
    if (viewId.current !== null) void post('skip', { view_id: viewId.current, watched: Math.round(prog.current.watched) }).catch(() => {});
    exit(false);
  };
  const ready = () => { wantExit.current = true; if (prog.current.watched >= prog.current.d * 0.9) finish(false); };
  const skipRef = useRef(skip); skipRef.current = skip;
  const readyRef = useRef(ready); readyRef.current = ready;
  // the sound unlock runs inside this tap (this page then has the user activation the iframe's video checks for)
  const unmute = () => {
    try { const v = frame.current?.contentDocument?.querySelector('video'); if (v) { v.muted = false; void v.play().catch(() => {}); } } catch { /* */ }
    send('unmute'); setMuted(false);
  };

  /* ---------- layout ---------- */
  const k = fit.k, ox = (fit.W - 375 * k) / 2, oy = (fit.H - 812 * k) / 2;
  const at = (r: Rect, pad = 6): React.CSSProperties => ({ position: 'absolute', left: ox + (r.x - pad) * k, top: oy + (r.y - pad) * k, width: (r.w + pad * 2) * k, height: (r.h + pad * 2) * k });
  const light = theme === 'light';
  const showSkip = canSkip && ph === 'stage' && booted;

  return (
    <div className="rlt" data-reel-tpl={style} data-style={style} data-phase={ph} data-showing={d.showing} data-reel={d.reel.id} data-tone={theme} data-booted={booted ? '1' : '0'}
      role="dialog" aria-modal="true" aria-label="Daily reel" onContextMenu={e => e.preventDefault()}
      style={{ position: 'fixed', inset: 0, zIndex: 9991, overflow: 'hidden', background: bg, userSelect: 'none', WebkitUserSelect: 'none', touchAction: 'none', overscrollBehavior: 'none',
        WebkitTapHighlightColor: 'transparent', opacity: ph === 'out' ? 0 : 1, transition: 'opacity 450ms ease' }}>
      {url && <iframe ref={frame} src={url} title="Daily reel" allow="autoplay; fullscreen 'none'" tabIndex={-1} aria-hidden
        style={{ position: 'absolute', left: ox, top: oy, width: 375, height: 812, border: 0, transform: `scale(${k})`, transformOrigin: '0 0', pointerEvents: 'none',
          background: 'transparent', opacity: booted ? 1 : 0, transition: 'opacity 260ms ease' }} />}
      {showSkip && skipR && hasPill && (
        <button type="button" data-reel-skip onClick={skip} aria-label="Skip & open chats"
          style={{ ...at(skipR), background: 'transparent', border: 0, padding: 0, color: 'transparent', fontSize: 1, cursor: 'pointer', zIndex: 3 }}>Skip &amp; open chats</button>
      )}
      {showSkip && !hasPill && (
        <div style={{ position: 'absolute', left: 0, right: 0, bottom: `calc(${Math.round(40 * k)}px + env(safe-area-inset-bottom))`, display: 'flex', justifyContent: 'center', zIndex: 3 }}>
          <button type="button" data-reel-skip onClick={skip} style={{ height: 40, padding: '0 18px', borderRadius: 20, border: light ? '.5px solid rgba(0,0,0,.08)' : '.5px solid rgba(255,255,255,.22)',
            background: light ? 'rgba(255,255,255,.75)' : 'rgba(20,20,24,.5)', color: light ? '#1B1A1F' : '#fff', font: '600 14px system-ui, sans-serif', backdropFilter: 'blur(14px)', WebkitBackdropFilter: 'blur(14px)' }}>Skip &amp; open chats</button>
        </div>
      )}
      {ph === 'end' && <div data-reel-endcard hidden />}
      {ph === 'end' && readyR && (
        <button type="button" data-reel-ready onClick={ready} aria-label="I'm ready"
          style={{ ...at(readyR, 8), background: 'transparent', border: 0, padding: 0, color: 'transparent', fontSize: 1, cursor: 'pointer', zIndex: 3 }}>I&rsquo;m ready</button>
      )}
      {muted && booted && <>
        <div data-reel-tapsound style={{ position: 'absolute', left: '50%', top: 'calc(14px + env(safe-area-inset-top))', transform: 'translateX(-50%)', zIndex: 6, height: 30, display: 'flex', alignItems: 'center', gap: 7,
          padding: '0 13px 0 11px', borderRadius: 15, background: light ? 'rgba(255,255,255,.7)' : 'rgba(20,20,24,.45)', border: light ? '.5px solid rgba(0,0,0,.06)' : '.5px solid rgba(255,255,255,.18)',
          backdropFilter: 'blur(14px)', WebkitBackdropFilter: 'blur(14px)', font: '500 12.5px system-ui, sans-serif', color: light ? '#1B1A1F' : '#fff', pointerEvents: 'none' }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden><path d="M11 5 6 9H3v6h3l5 4z" /><path d="M15.5 8.5a5 5 0 0 1 0 7" /></svg>Tap for sound</div>
        <div onClick={unmute} onTouchEnd={unmute} style={{ position: 'absolute', inset: 0, zIndex: 4 }} />
      </>}
    </div>
  );
}
