'use client';
/* v168: compact style / format picker (owner): ONE row "Player styles · N of M on ›" that opens a sheet with
 * "Select all / None", Dark / Light preview stills and a 2-column grid of small thumbnail cards (still + id + name + tick).
 * Data-driven: pass any registry of StyleDef. Used by Daily reel → Player styles (A–D now; E–T get registered by the
 * integration engineer) and reusable for the admin Status video formats (S01–S20). Changes are saved with "Save". */
import { useEffect, useMemo, useState } from 'react';
import { Check } from 'lucide-react';
import clsx from 'clsx';
import { Row, IconTile, Sheet, Seg, useToast } from '../ui';

export type StyleDef = {
  id: string;            // 'A', 'E', 'S01' …
  name: string;          // 'Ambient'
  desc?: string;         // one short line
  thumb?: string;        // dark still (≈240 px wide), e.g. /reel/styles/A-dark.webp
  thumbLight?: string;   // light still
  kind: 'react' | 'template'; // react = in-app player (A–D); template = server-rendered HTML timeline (E–T, S01–S20)
};

/** The Daily reel's player styles. Add E–T here (kind 'template') once the in-app port is registered on the server too:
 *  reel.ts ALL_STYLES must accept the same ids, or the server drops them on save. Stills: public/reel/styles/<id>-dark|light.webp. */
export const REEL_STYLES: StyleDef[] = [
  { id: 'A', name: 'Ambient', desc: 'Blurred glow around the video', thumb: '/reel/styles/A-dark.webp', thumbLight: '/reel/styles/A-light.webp', kind: 'react' },
  { id: 'B', name: 'Cinema', desc: 'Projector, light on the seats', thumb: '/reel/styles/B-dark.webp', thumbLight: '/reel/styles/B-light.webp', kind: 'react' },
  { id: 'C', name: 'Story', desc: 'Story bars, colour card from the video', thumb: '/reel/styles/C-dark.webp', thumbLight: '/reel/styles/C-light.webp', kind: 'react' },
  { id: 'D', name: 'Widescreen', desc: 'Whole frame edge to edge, caption below', thumb: '/reel/styles/D-dark.webp', thumbLight: '/reel/styles/D-light.webp', kind: 'react' },
  // v168: the agent formats E–T (in-app: TemplatePlayer, public/reel-tpl/<ID>); the server's ALL_STYLES has the same ids
  { id: 'E', name: 'Polaroid', desc: 'Taped photo on a desk, sticky note', thumb: '/reel/styles/E-dark.webp', thumbLight: '/reel/styles/E-light.webp', kind: 'template' },
  { id: 'F', name: 'Neon', desc: 'Neon sign and a glowing screen', thumb: '/reel/styles/F-dark.webp', thumbLight: '/reel/styles/F-light.webp', kind: 'template' },
  { id: 'G', name: 'Music player', desc: 'Now playing card, waveform progress', thumb: '/reel/styles/G-dark.webp', thumbLight: '/reel/styles/G-light.webp', kind: 'template' },
  { id: 'H', name: 'Magazine', desc: 'HUSTLE cover with the video strip', thumb: '/reel/styles/H-dark.webp', thumbLight: '/reel/styles/H-light.webp', kind: 'template' },
  { id: 'I', name: 'Duotone', desc: 'Two colours, big marquee type', thumb: '/reel/styles/I-dark.webp', thumbLight: '/reel/styles/I-light.webp', kind: 'template' },
  { id: 'J', name: 'Glass stack', desc: 'Frosted cards fanned around the video', thumb: '/reel/styles/J-dark.webp', thumbLight: '/reel/styles/J-light.webp', kind: 'template' },
  { id: 'K', name: 'Boarding pass', desc: 'Today’s journey on a ticket', thumb: '/reel/styles/K-dark.webp', thumbLight: '/reel/styles/K-light.webp', kind: 'template' },
  { id: 'L', name: 'Film strip', desc: 'Moving film gate with frames', thumb: '/reel/styles/L-dark.webp', thumbLight: '/reel/styles/L-light.webp', kind: 'template' },
  { id: 'M', name: 'Aurora', desc: 'Soft colour blobs, glass panel', thumb: '/reel/styles/M-dark.webp', thumbLight: '/reel/styles/M-light.webp', kind: 'template' },
  { id: 'N', name: 'Terminal', desc: 'Shell windows that type', thumb: '/reel/styles/N-dark.webp', thumbLight: '/reel/styles/N-light.webp', kind: 'template' },
  { id: 'O', name: 'Gold & Black', desc: 'Gold foil frame, serif type', thumb: '/reel/styles/O-dark.webp', thumbLight: '/reel/styles/O-light.webp', kind: 'template' },
  { id: 'P', name: 'Bento', desc: 'Tiles around the video', thumb: '/reel/styles/P-dark.webp', thumbLight: '/reel/styles/P-light.webp', kind: 'template' },
  { id: 'Q', name: 'Pop art', desc: 'Comic panels and speech bubbles', thumb: '/reel/styles/Q-dark.webp', thumbLight: '/reel/styles/Q-light.webp', kind: 'template' },
  { id: 'R', name: 'Swiss minimal', desc: 'Grid, bold type, red accents', thumb: '/reel/styles/R-dark.webp', thumbLight: '/reel/styles/R-light.webp', kind: 'template' },
  { id: 'S', name: 'Spotlight', desc: 'A beam of light on stage', thumb: '/reel/styles/S-dark.webp', thumbLight: '/reel/styles/S-light.webp', kind: 'template' },
  { id: 'T', name: 'Paper cut', desc: 'Layered paper waves', thumb: '/reel/styles/T-dark.webp', thumbLight: '/reel/styles/T-light.webp', kind: 'template' },
  // v174: 10 more agent formats
  ...([['U', 'Night sky', 'A star for every streak day'], ['V', 'Chalkboard', 'Quotes written in chalk'], ['W', 'Departures', 'Split-flap station board'],
    ['X', 'Gallery', 'The video as framed art'], ['Y', 'Day calendar', 'Yesterday tears away'], ['Z', 'Postcard', 'Stamp, postmark, a flip at the end'],
    ['AA', 'Blueprint', 'Technical drawing and title block'], ['AB', 'Enso', 'A brush circle and a red seal'], ['AC', 'Chronograph', 'A watch dial window'],
    ['AD', 'Kinetic type', 'Big poster type, video edge to edge']] as const).map(([id, name, desc]) => ({ id, name, desc, thumb: `/reel/styles/${id}-dark.webp`, thumbLight: `/reel/styles/${id}-light.webp`, kind: 'template' as const })),
];

/** The one compact settings row. */
export function StyleRow({ styles, selected, onOpen, title = 'Player styles', icon }: { styles: StyleDef[]; selected: string[]; onOpen: () => void; title?: string; icon?: React.ReactNode }) {
  const n = styles.filter(s => selected.includes(s.id)).length;
  const firsts = styles.filter(s => selected.includes(s.id) && s.thumb).slice(0, 3);
  return (
    <Row icon={icon ?? <IconTile icon={StackIc} color="#8E7CC3" />} title={title} sub={`${n} of ${styles.length} on`} onClick={onOpen} data-style-row
      right={firsts.length > 0 && <span className="mr-1 flex -space-x-2" aria-hidden>{firsts.map(s => <img key={s.id} src={s.thumb} alt="" className="h-8 w-[15px] rounded-[4px] object-cover ring-2 ring-tg-panel" />)}</span>} />
  );
}
function StackIc({ size = 18 }: { size?: number; className?: string; strokeWidth?: number }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden><rect x="3" y="3" width="7" height="9" rx="1.5" /><rect x="14" y="3" width="7" height="5" rx="1.5" /><rect x="14" y="12" width="7" height="9" rx="1.5" /><rect x="3" y="16" width="7" height="5" rx="1.5" /></svg>;
}

/** The picker sheet. `onSave` gets the new list (in registry order); return a promise to keep the sheet busy while saving. */
export function StylePicker({ open, onClose, styles, selected, onSave, title = 'Player styles', min = 1, note }: {
  open: boolean; onClose: () => void; styles: StyleDef[]; selected: string[]; onSave: (ids: string[]) => Promise<unknown> | void; title?: string; min?: number; note?: string;
}) {
  const toast = useToast();
  const [draft, setDraft] = useState<string[]>(selected);
  const [tone, setTone] = useState<'dark' | 'light'>('dark');
  const [busy, setBusy] = useState(false);
  useEffect(() => { if (open) setDraft(selected); }, [open, selected]);
  const ids = useMemo(() => styles.map(s => s.id), [styles]);
  const sel = draft.filter(x => ids.includes(x));
  const changed = sel.length !== selected.filter(x => ids.includes(x)).length || sel.some(x => !selected.includes(x));
  const hasLight = styles.some(s => s.thumbLight);
  const toggle = (id: string) => setDraft(d => (d.includes(id) ? d.filter(x => x !== id) : [...d, id]));
  const save = async () => {
    if (sel.length < min) return toast(min === 1 ? 'Pick at least one style' : `Pick at least ${min}`, 'err');
    setBusy(true);
    try { await onSave(ids.filter(x => sel.includes(x))); onClose(); } catch (e) { toast((e as Error).message || 'Could not save', 'err'); } finally { setBusy(false); }
  };
  return (
    <Sheet open={open} onClose={onClose} title={title} full>
      <div data-style-picker>
        <div className="mb-3 flex items-center gap-2">
          <span className="text-[13.5px] text-tg-sub af-num" data-style-count>{sel.length} of {styles.length} on</span>
          <span className="flex-1" />
          <button type="button" className="af-pill" onClick={() => setDraft(ids)} data-style-all>Select all</button>
          <button type="button" className="af-pill" onClick={() => setDraft([])} data-style-none>None</button>
        </div>
        {hasLight && <Seg full value={tone} onChange={v => setTone(v)} items={[['dark', 'Dark'], ['light', 'Light']]} className="mb-3" />}
        <div className="grid grid-cols-2 gap-2.5">
          {styles.map(s => {
            const on = sel.includes(s.id);
            const img = tone === 'light' ? s.thumbLight || s.thumb : s.thumb;
            return (
              <button key={s.id} type="button" onClick={() => toggle(s.id)} aria-pressed={on} data-style-card={s.id}
                className={clsx('relative overflow-hidden rounded-[14px] bg-tg-panel text-left ring-inset transition-[box-shadow,transform] active:scale-[.98]', on ? 'ring-2 ring-tg-acc' : 'ring-1 ring-tg-line')}>
                <span className="block aspect-[3/4] w-full overflow-hidden bg-tg-hover">
                  {img ? <img src={img} alt="" loading="lazy" className={clsx('h-full w-full object-cover object-center transition-opacity', !on && 'opacity-70')} /> /* eslint-disable-line @next/next/no-img-element */
                    : <span className="grid h-full w-full place-items-center text-[28px] font-bold text-tg-sub">{s.id}</span>}
                </span>
                <span className="flex items-center gap-2 px-2.5 py-2">
                  <span className="grid h-[22px] min-w-[22px] shrink-0 place-items-center rounded-[6px] bg-tg-hover px-1 text-[11.5px] font-bold tabular-nums">{s.id}</span>
                  <span className="min-w-0 flex-1"><span className="block truncate text-[14px] font-semibold leading-tight">{s.name}</span>{s.desc && <span className="block truncate text-[11.5px] leading-tight text-tg-sub">{s.desc}</span>}</span>
                </span>
                <span className={clsx('absolute right-2 top-2 grid h-[24px] w-[24px] place-items-center rounded-full shadow', on ? 'bg-tg-acc text-white' : 'bg-black/35 ring-[1.5px] ring-inset ring-white/80')} aria-hidden>{on && <Check size={15} strokeWidth={3} />}</span>
              </button>
            );
          })}
        </div>
        {note && <p className="mt-3 text-[13px] text-tg-sub">{note}</p>}
        <div className="sticky bottom-0 -mx-4 mt-3 bg-tg-panel/95 px-4 pb-[calc(10px+env(safe-area-inset-bottom))] pt-2.5 backdrop-blur">
          <button type="button" onClick={save} disabled={busy || !changed || sel.length < min} data-style-save
            className="h-12 w-full rounded-[14px] bg-tg-acc text-[15.5px] font-semibold text-white disabled:opacity-45">
            {sel.length < min ? 'Pick at least one' : changed ? `Save · ${sel.length} on` : 'No changes'}
          </button>
        </div>
      </div>
    </Sheet>
  );
}
