'use client';
// v167: a "fresh open" = a cold start / reload, or coming back to the app after it was hidden for 30+ minutes.
// Same rule as the agent greeting splash (AgentApp). Someone using the app is never interrupted: nothing else counts.
import { useEffect, useState } from 'react';

export const FRESH_AWAY_MS = 30 * 60000;

/** Returns a number that starts at 1 and goes up on every fresh open (use it as a React key). 0 when `off`. */
export function useFreshOpen(off = false) {
  const [k, setK] = useState(off ? 0 : 1);
  useEffect(() => {
    if (off) return;
    let hiddenAt = 0;
    const vis = () => {
      if (document.visibilityState === 'hidden') { hiddenAt = Date.now(); return; }
      if (hiddenAt && Date.now() - hiddenAt >= FRESH_AWAY_MS) setK(x => x + 1);
      hiddenAt = 0;
    };
    document.addEventListener('visibilitychange', vis);
    return () => document.removeEventListener('visibilitychange', vis);
  }, [off]);
  return k;
}
