'use client';
/* v168: Admin → More → Status video. The automatic daily status video (yesterday's numbers on a stock video, DARK + LIGHT),
 *  made at night when the server is quiet, or now. Stock upload (many at once, chunked), formats (compact row → picker),
 *  renderer status (+ retry install), today's videos with preview + Download, history (14 days), and the agents' reel
 *  download switch. All changes are POST; reads are GET. */
import { useCallback, useEffect, useRef, useState } from 'react';
import { Clapperboard, Film, Upload, Download, Trash2, Loader2, AlertTriangle, LayoutGrid, Users, Wand2, Moon, Sun, CalendarDays, Smartphone } from 'lucide-react';
import clsx from 'clsx';
import { Page, Group, Row, IconTile, TILE, Toggle, SectionHead, Tag, Btn, Skeleton, useToast, makeApi } from '../ui';
import { isNative, openExternal } from '../native';
import { StyleRow, StylePicker, type StyleDef } from './StylePicker'; // v168: the shared picker (also Daily reel → Player styles)

type Api = ReturnType<typeof makeApi>;
type Job = { id: number; day: string; theme: 'dark' | 'light'; fmt: string; state: 'queued' | 'running' | 'done' | 'failed'; progress: number; size: number | null; duration: number | null; error: string | null; note: string | null; trig: string | null; done_at: number | null; ms: number | null; same_as_dark: boolean };
type Stock = { id: number; name: string; size: number; duration: number; width: number | null; height: number | null; audio: boolean; state: 'ready' | 'used'; used_day: string | null; note: string | null };
type Fmt = { id: string; name: string; themes: string[]; on: boolean; thumb: string | null };
type State = { today: string; yday: string; cfg: { on: boolean; agent_dl: boolean; tall?: boolean; formats: string[] }; formats: Fmt[];
  renderer: { ready: boolean; installing: boolean }; // v168: no technical details on screen (owner); they are in the server log
  stock: { left: number; items: Stock[] }; days: { day: string; dark: Job | null; light: Job | null }[]; active: number;
  problem: { text: string; action: 'install' | 'make' | null } | null }; // v168: only when he must do something (else retries run on their own)

const mmss = (s: number) => { s = Math.max(0, Math.round(s)); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; };
const mb = (b: number | null) => (b ? `${(b / 1048576).toFixed(1)} MB` : '');
const nice = (d: string) => new Date(d + 'T00:00:00Z').toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short', timeZone: 'UTC' });
const fileUrl = (id: number) => `/api/admin/svid/file/${id}`;

/** Download: a signed 10-minute link (works in the Android app too, which opens it in the phone's browser). */
async function download(api: Api, id: number) {
  const { url } = await api<{ url: string }>('svid/link', { id });
  if (await isNative()) await openExternal(location.origin + url);
  else location.assign(url);
}

export function StatusVideoAdmin({ api, back }: { api: Api; back?: () => void }) {
  const toast = useToast();
  const [d, setD] = useState<State | null>(null);
  const [picker, setPicker] = useState(false);
  const [makeDay, setMakeDay] = useState('');
  const [busy, setBusy] = useState(false);
  const load = useCallback(async () => { try { setD(await api<State>('svid/state')); } catch (e) { toast((e as Error).message, 'err'); } }, [api, toast]);
  useEffect(() => { void load(); }, [load]);
  const live = !!d && (d.active > 0 || d.renderer.installing);
  useEffect(() => { if (!live) return; const t = setInterval(() => void load(), 3000); return () => clearInterval(t); }, [live, load]);
  const save = async (patch: Record<string, unknown>) => {
    try { await api('svid/settings', patch); await load(); } catch (e) { toast((e as Error).message, 'err'); }
  };
  const make = async (day = makeDay) => {
    setBusy(true);
    try { await api('svid/make', day ? { day } : {}); toast('Making it now'); await load(); }
    catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); }
  };
  if (!d) return <Page title="Status video" back={back} kicker="Admin"><Skeleton rows={5} h={56} /></Page>;
  const r = d.renderer;
  const top = d.days.find(x => x.day === d.yday) || null;
  return (
    <Page title="Status video" back={back} kicker="Admin">
      <div data-svid-admin>
        <Group tiles>
          <Row icon={<IconTile icon={Clapperboard} color="#8B5CF6" />} title={<b className="font-semibold">Daily status video</b>} chevron={false}
            sub={d.cfg.on ? 'On. Made every night after 01:00 IST, when the server is quiet.' : 'Off. Use Make now any time.'}
            right={<Toggle on={d.cfg.on} onChange={v => void save({ on: v })} label="Daily status video" />} data-svid-on />
        </Group>
        <Problem api={api} p={d.problem} busy={r.installing} reload={load} onRemake={() => void make(d.yday)} />

        <SectionHead title={`Yesterday · ${nice(d.yday)}`} />
        <div className="grid grid-cols-2 gap-2.5" data-svid-today>
          <VideoCard api={api} job={top?.dark || null} theme="dark" />
          <VideoCard api={api} job={top?.light || null} theme="light" />
        </div>
        <div className="af-card mt-2.5 px-3.5 py-3" data-svid-make>
          <div className="flex items-center gap-2">
            <CalendarDays size={18} className="shrink-0 text-tg-sub" />
            <span className="min-w-0 flex-1 text-[14.5px]">Day</span>
            <input type="date" value={makeDay || d.yday} max={d.yday} onChange={e => setMakeDay(e.target.value)} className="rounded-lg bg-tg-panel2 px-2 py-1 text-[14.5px] text-tg-text" aria-label="Day to make" data-svid-day />
          </div>
          <Btn className="mt-2.5 w-full" onClick={() => void make()} busy={busy || d.active > 0} disabled={d.stock.left === 0 && !top} data-svid-makenow><Wand2 size={16} />Make now</Btn>
          <p className="mt-1.5 text-[12px] leading-snug text-tg-sub">{d.active > 0 ? 'Making it in the background. You can leave this page.' : 'Makes that day’s video in dark and light, in the background. A new one replaces the old one of that day.'}</p>
        </div>

        <SectionHead title="Video stock" action={<span className="af-num">{d.stock.left} left</span>} />
        <StockList api={api} d={d} reload={load} />

        <SectionHead title="Look" />
        <Group tiles>
          <div data-svid-formats><StyleRow styles={fmtDefs(d.formats)} selected={d.cfg.formats} onOpen={() => setPicker(true)} title="Formats" icon={<IconTile icon={LayoutGrid} color={TILE.indigo} />} /></div>{/* v168: shared StylePicker row */}
          <Row icon={<IconTile icon={Smartphone} color={TILE.blue} />} title="Full screen" sub={d.cfg.tall !== false ? 'Tall 9:20 · fills new phones, no black bars' : 'Normal 9:16'} chevron={false}
            right={<Toggle on={d.cfg.tall !== false} onChange={v => void save({ tall: v })} label="Full screen" />} data-svid-tall />{/* v169 */}
        </Group>
        <p className="mx-4 mt-2 text-[12.5px] text-tg-sub">A different format each day, in turn. Dark and light use the same format when it has a light design.</p>

        <SectionHead title="Agents" />
        <Group tiles>
          <Row icon={<IconTile icon={Users} color={TILE.green} />} title="Agents can download their reel" sub="A “Today’s reel” card on their Dashboard. Only their own video." chevron={false}
            right={<Toggle on={d.cfg.agent_dl} onChange={v => void save({ agent_dl: v })} label="Agents can download their reel" />} data-svid-agentdl />
        </Group>

        <SectionHead title="Last 14 days" />
        {d.days.length ? <Group data-svid-history>
          {d.days.map(x => <Row key={x.day} chevron={false} title={nice(x.day)} sub={[x.dark, x.light].some(j => j && j.state !== 'done') ? ([x.dark, x.light].some(j => j && (j.state === 'queued' || j.state === 'running')) ? 'Making…' : 'Could not be made') : undefined}
            right={<span className="flex gap-1.5">{[x.dark, x.light].map(j => j && j.state === 'done' && !(j.same_as_dark && j.theme === 'light') ? <button key={j.id} type="button" className="af-iconbtn" aria-label={`Download ${j.theme}`} onClick={() => void download(api, j.id).catch(e => toast((e as Error).message, 'err'))}>{j.theme === 'dark' ? <Moon size={16} /> : <Sun size={16} />}</button> : null)}</span>} />)}
        </Group> : <p className="px-1 py-4 text-center text-[13.5px] text-tg-sub">No status videos yet.</p>}
        <p className="mx-4 mt-2 text-[12.5px] text-tg-sub">Videos are deleted after 14 days. A stock video is deleted once its status video is made.</p>
      </div>
      <StylePicker open={picker} onClose={() => setPicker(false)} styles={fmtDefs(d.formats)} selected={d.cfg.formats} title="Formats" onSave={f => save({ formats: f })} /> {/* v168: shared picker */}
    </Page>
  );
}

/** Shown ONLY when automatic recovery can't fix it without him (owner): one plain sentence, and Retry when it can help. */
function Problem({ api, p, busy, reload, onRemake }: { api: Api; p: State['problem']; busy: boolean; reload: () => void; onRemake: () => void }) {
  if (!p) return null;
  const retry = async () => {
    if (p.action === 'install') { try { await api('svid/install', {}); } catch { /* it says so on the next load */ } reload(); return; }
    onRemake();
  };
  return (
    <div className="af-note warn mt-3 flex items-center gap-3 text-[13.5px]" data-svid-problem={p.action || 'info'}>
      <span className="min-w-0 flex-1 font-semibold leading-snug">{p.text}</span>
      {p.action && <Btn size="sm" onClick={() => void retry()} busy={busy} data-svid-retry>Retry</Btn>}
    </div>
  );
}

function VideoCard({ api, job, theme }: { api: Api; job: Job | null; theme: 'dark' | 'light' }) {
  const toast = useToast();
  const label = theme === 'dark' ? 'Dark' : 'Light';
  return (
    <div className="af-card overflow-hidden" data-svid-card={theme} data-state={job?.state || 'none'}>
      <div className="relative aspect-[9/16] w-full bg-tg-panel2">
        {job?.state === 'done' ? <video src={fileUrl(job.id) + '#t=4'} controls playsInline preload="metadata" className="h-full w-full object-cover" />
          : <div className="absolute inset-0 grid place-items-center px-3 text-center text-[12.5px] text-tg-sub">
            {!job ? 'Not made yet' : job.state === 'failed' ? <span className="flex flex-col items-center gap-1 text-tg-bad"><AlertTriangle size={18} />Could not be made</span>
              : <span className="flex flex-col items-center gap-1.5"><Loader2 size={18} className="animate-spin" />{job.state === 'queued' ? 'Waiting…' : `Making… ${job.progress}%`}</span>}
          </div>}
        <span className={clsx('absolute left-1.5 top-1.5 rounded-[5px] px-1.5 py-[1px] text-[9.5px] font-bold tracking-[.06em]', theme === 'dark' ? 'bg-black/70 text-white' : 'bg-white/85 text-black')}>{label.toUpperCase()}</span>
      </div>
      <div className="px-2.5 py-2">
        <p className="truncate text-[12.5px] text-tg-sub">{job?.state === 'done' ? `${job.duration ? mmss(job.duration) : ''}${job.size ? ' · ' + mb(job.size) : ''}` : ' '}</p>
        {job?.same_as_dark && <p className="text-[11.5px] leading-tight text-tg-sub">Light not available for this format</p>}
        {job?.state === 'done' && <Btn size="sm" kind="soft" className="mt-1.5 w-full" onClick={() => void download(api, job.id).catch(e => toast((e as Error).message, 'err'))}><Download size={14} />Download</Btn>}
      </div>
    </div>
  );
}

function StockList({ api, d, reload }: { api: Api; d: State; reload: () => void }) {
  const toast = useToast();
  const [up, setUp] = useState<{ name: string; pct: number; i: number; n: number } | null>(null);
  const cancel = useRef(false);
  useEffect(() => () => { cancel.current = true; }, []);
  const uploadAll = async (files: File[]) => {
    let ok = 0;
    for (let i = 0; i < files.length; i++) {
      const f = files[i];
      if (cancel.current) break;
      setUp({ name: f.name, pct: 0, i: i + 1, n: files.length });
      try {
        if (f.size > 200 * 1024 * 1024) throw new Error('larger than 200 MB');
        const dur = await videoLength(f);
        if (dur > 45.5) throw new Error(`${Math.round(dur)} s (the limit is 45 s)`);
        const init = await api<{ upload_id: string; chunk: number }>('svid/upload_init', { name: f.name, size: f.size, mime: f.type, duration: dur });
        let off = 0, fails = 0;
        while (off < f.size) {
          if (cancel.current) { void api('svid/upload_cancel', { upload_id: init.upload_id }).catch(() => {}); return; }
          try {
            const r = await fetch(`/api/admin/svid/upload_chunk?id=${init.upload_id}&off=${off}`, { method: 'POST', credentials: 'same-origin', headers: { 'content-type': 'application/octet-stream' }, body: f.slice(off, off + init.chunk) });
            const j = await r.json().catch(() => ({}));
            if (r.status === 409 && typeof j.got === 'number') { off = j.got; continue; }
            if (!r.ok) throw new Error(j.error || `Upload failed (${r.status})`);
            off = j.got; fails = 0; setUp({ name: f.name, pct: Math.round(off / f.size * 100), i: i + 1, n: files.length });
          } catch (e) { if (++fails > 8) throw e; await new Promise(r => setTimeout(r, Math.min(8000, 800 * fails))); }
        }
        await api('svid/upload_done', { upload_id: init.upload_id, duration: dur });
        ok++;
      } catch (e) { toast(`${f.name}: ${(e as Error).message}`, 'err'); }
    }
    setUp(null);
    if (ok) toast(`${ok} video${ok === 1 ? '' : 's'} added to the stock`);
    reload();
  };
  const del = async (s: Stock) => { if (!confirm(`Delete “${s.name}” from the stock?`)) return; try { await api('svid/stock_delete', { id: s.id }); reload(); } catch (e) { toast((e as Error).message, 'err'); } };
  const items = d.stock.items;
  return (
    <>
      <label className={clsx('af-press flex h-[56px] w-full items-center justify-center gap-2 rounded-[14px] border border-dashed border-tg-sub/35 text-[14.5px] font-semibold text-tg-link', up && 'pointer-events-none opacity-60')} data-svid-upload>
        <input type="file" multiple accept="video/mp4,video/quicktime,video/webm,video/*" className="sr-only" onChange={e => { const fs = [...(e.target.files || [])]; e.target.value = ''; if (fs.length) void uploadAll(fs); }} data-svid-file />
        <Upload size={18} />Upload videos
      </label>
      {up && <div className="mt-2"><div className="af-bar"><i style={{ width: `${up.pct}%`, background: 'rgb(var(--tg-acc))' }} /></div><p className="mt-1 truncate text-[12.5px] text-tg-sub af-num">Uploading {up.i} of {up.n}: {up.name} · {up.pct}%</p></div>}
      <p className="mx-1 mt-2 text-[12.5px] leading-snug text-tg-sub">16:9 videos with a song, up to 45 s each. Pick many at once. Each day uses one at random. No stock means no video that day.</p>
      {items.length > 0 && <Group className="mt-2" data-svid-stock>
        {items.map(s => <Row key={s.id} chevron={false} icon={<IconTile icon={Film} color={s.state === 'used' ? TILE.grey : TILE.pink} />}
          title={<span className="flex items-center gap-2"><span className="truncate">{s.name}</span>{s.state === 'used' ? <Tag>Used {s.used_day ? nice(s.used_day) : ''}</Tag> : <Tag tone="ok">Ready</Tag>}</span>}
          sub={[mmss(s.duration), mb(s.size), s.note].filter(Boolean).join(' · ')}
          right={s.state !== 'used' ? <button type="button" className="af-iconbtn" aria-label="Delete" onClick={() => void del(s)}><Trash2 size={16} /></button> : null} data-svid-stock-row={s.id} />)}
      </Group>}
    </>
  );
}

/** Length of a local video file (seconds; 0 when the browser can't read it — the server checks again). */
function videoLength(f: File) {
  return new Promise<number>(res => {
    const v = document.createElement('video'), u = URL.createObjectURL(f);
    const done = (x: number) => { URL.revokeObjectURL(u); res(Number.isFinite(x) ? x : 0); };
    const t = setTimeout(() => done(0), 8000);
    v.preload = 'metadata'; v.muted = true;
    v.onloadedmetadata = () => { clearTimeout(t); done(v.duration); };
    v.onerror = () => { clearTimeout(t); done(0); };
    v.src = u;
  });
}

/** v168: the status-video formats as entries of the shared StylePicker (stills: public/reel/status/<ID>.jpg). */
function fmtDefs(formats: Fmt[]): StyleDef[] {
  return formats.map(f => ({ id: f.id, name: f.name, desc: f.themes.includes('light') ? 'Dark + light' : 'Dark only', thumb: f.thumb || `/reel/status/${f.id}.jpg`, kind: 'template' as const }));
}

