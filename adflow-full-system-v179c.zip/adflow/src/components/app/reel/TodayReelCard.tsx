'use client';
/* v168: agent Dashboard → "Today's reel" card: makes a 9:16 video of the agent's own day-start reel (on the server, in the
 *  background) and downloads it. Shown only when the admin switched "Agents can download their reel" ON (the server says so;
 *  it also refuses every call when it is OFF). Only the agent's own video; no business numbers. */
import { useCallback, useEffect, useState } from 'react';
import { Clapperboard, Download, Loader2, RotateCw } from 'lucide-react';
import { Btn, makeApi, useToast } from '../ui';
import { isNative, openExternal } from '../native';

type Api = ReturnType<typeof makeApi>;
type J = { id: number; day: string; state: 'queued' | 'running' | 'done' | 'failed'; progress: number; size: number | null; duration: number | null; error: string | null };
type St = { on: false } | { on: true; today: string; watched: boolean; can_make: boolean; today_job: J | null; recent: J[] };
const nice = (d: string) => new Date(d + 'T00:00:00Z').toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short', timeZone: 'UTC' });

export function TodayReelCard({ api }: { api: Api }) {
  const toast = useToast();
  const [s, setS] = useState<St | null>(null);
  const [busy, setBusy] = useState(false);
  const load = useCallback(async () => { try { setS(await api<St>('reeldl/state')); } catch { setS({ on: false }); } }, [api]);
  useEffect(() => { void load(); }, [load]);
  const job = s && s.on ? s.today_job : null;
  const working = !!job && (job.state === 'queued' || job.state === 'running');
  useEffect(() => { if (!working) return; const t = setInterval(() => void load(), 3000); return () => clearInterval(t); }, [working, load]);
  if (!s || !s.on) return null;
  const make = async () => { setBusy(true); try { await api('reeldl/make', {}); await load(); } catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); } };
  const dl = async (id: number) => {
    try {
      const { url } = await api<{ url: string }>('reeldl/link', { id });
      if (await isNative()) await openExternal(location.origin + url); else location.assign(url);
    } catch (e) { toast((e as Error).message, 'err'); }
  };
  return (
    <section className="af-card mb-3 px-4 py-3.5" data-reel-dl data-state={job?.state || 'ready'}>
      <div className="flex items-center gap-3">
        <span className="grid h-[38px] w-[38px] shrink-0 place-items-center rounded-[11px] text-white" style={{ background: '#C9A866' }}><Clapperboard size={19} /></span>
        <span className="min-w-0 flex-1">
          <b className="block text-[15.5px] font-semibold">Today’s reel</b>
          <span className="block text-[13px] leading-snug text-tg-sub">
            {!job ? 'Get it as a video for your WhatsApp status.'
              : job.state === 'done' ? `Ready${job.duration ? ` · ${Math.round(job.duration)} s` : ''}${job.size ? ` · ${(job.size / 1048576).toFixed(1)} MB` : ''}`
              : job.state === 'failed' ? 'Could not make the video. Try again.'
              : job.state === 'queued' ? 'Waiting to start…' : `Making your video… ${job.progress}%`}
          </span>
        </span>
      </div>
      {working && <div className="af-bar mt-2.5"><i style={{ width: `${Math.max(3, job!.progress)}%`, background: '#C9A866' }} /></div>}
      {(!job || job.state === 'failed') && <Btn className="mt-3 w-full" onClick={make} busy={busy} disabled={!s.can_make} data-reel-dl-make>{job ? <><RotateCw size={15} />Try again</> : 'Make my video'}</Btn>}
      {working && <p className="mt-2 flex items-center gap-1.5 text-[12.5px] text-tg-sub"><Loader2 size={13} className="animate-spin" />Takes a few minutes. You can keep working.</p>}
      {job?.state === 'done' && <Btn className="mt-3 w-full" onClick={() => void dl(job.id)} data-reel-dl-get><Download size={16} />Download</Btn>}
      {s.recent.length > 0 && <div className="af-sepabove mt-3 flex flex-wrap gap-2 pt-2.5">
        {s.recent.map(r => <button key={r.id} type="button" onClick={() => void dl(r.id)} className="af-chip"><Download size={13} />{nice(r.day)}</button>)}
      </div>}
    </section>
  );
}
