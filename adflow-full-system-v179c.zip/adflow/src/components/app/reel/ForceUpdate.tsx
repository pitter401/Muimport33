'use client';

/* v167: "Update required" — a full-screen block for Android apps older than the minimum build (Admin → System → Force update).
 *  Rendered at the very top of the Admin / Agent app, outside login and outside the Daily reel, so it can never lock anyone out:
 *   - only in the native app (a browser / PWA is never blocked);
 *   - only when the app's own build number could be read (same way as appupdate.tsx: @capacitor/app App.getInfo().build);
 *   - only when the server says the new APK is really there (/api/app-version → min_<app> > 0).
 *  The button uses the existing update flow: open /downloads/<app>.apk in the phone's browser → tap the file → Update. */
import { useEffect, useState } from 'react';
import { isNative, openExternal } from '../native';

export function ForceUpdate({ app }: { app: 'agent' | 'admin' }) {
  const [need, setNeed] = useState<{ min: number; name: string } | null>(null);
  const [started, setStarted] = useState(false);
  useEffect(() => {
    let stop = false;
    const check = async () => {
      if (!(await isNative())) return;
      let mine = 0;
      try {
        const { App } = await import('@capacitor/app');
        const info = await Promise.race([App.getInfo(), new Promise<null>(r => setTimeout(() => r(null), 4000))]);
        mine = Number(info?.build) || 0;
      } catch { /* very old app: can't tell → don't block */ }
      if (!mine) return;
      try {
        const v = await (await fetch('/api/app-version', { cache: 'no-store' })).json();
        const min = Number(app === 'agent' ? v.min_agent : v.min_admin) || 0;
        if (!stop) setNeed(v.force !== false && min > 0 && mine < min ? { min, name: String(v.name || '') } : null);
      } catch { /* offline: don't block */ }
    };
    void check();
    const vis = () => { if (document.visibilityState === 'visible') void check(); };
    document.addEventListener('visibilitychange', vis);
    return () => { stop = true; document.removeEventListener('visibilitychange', vis); };
  }, [app]);

  if (!need) return null;
  const url = `${location.origin}/downloads/${app}.apk?v=${need.min}`;
  return (
    <div role="alertdialog" aria-modal="true" aria-labelledby="af-fu-t" data-force-update
      className="fixed inset-0 z-[2147483000] flex flex-col items-center justify-center bg-tg-bg px-8 text-center text-tg-text">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src="/reel/logo.png" alt="AdsBhai" width={76} height={76} className="h-[76px] w-[76px] rounded-[20px] shadow-[0_14px_36px_rgba(124,58,237,.35)]" />
      <h1 id="af-fu-t" className="mt-6 text-[24px] font-bold tracking-[-0.02em]">Update required</h1>
      <p className="mt-2 max-w-[300px] text-[15.5px] leading-snug text-tg-sub">A new version is ready. Update to continue.</p>
      <button type="button" onClick={() => { setStarted(true); void openExternal(url); }}
        className="af-press mt-8 h-[50px] w-full max-w-[300px] rounded-[14px] bg-tg-acc text-[16px] font-semibold text-white shadow-[0_10px_26px_rgb(var(--tg-acc)/0.3)]">
        {started ? 'Download again' : 'Update'}
      </button>
      {started && <p className="mt-4 max-w-[300px] text-[13px] leading-snug text-tg-sub">When the download finishes, tap the file (or the notification), then <b className="text-tg-text">Update</b>. If Android asks, allow installing from the browser.</p>}
      {need.name && <p className="absolute bottom-[calc(20px+env(safe-area-inset-bottom))] text-[12px] text-tg-sub">Version {need.name}</p>}
    </div>
  );
}
