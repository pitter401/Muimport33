'use client';
/* v167: Admin → More → Daily reel. Settings (master switch, rules, player styles, who sees it), Schedule (per day, thumbnails,
 *  DARK / LIGHT, "+ Add", edit / delete), Upload sheet (checks in this browser: length, playable, poster, brightness; then a
 *  chunked upload; the server optimises it in the background) and the Report (per person, any day). */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Play, Repeat2, Clock, Eye, SkipForward, CalendarDays, BarChart3, Info, Plus, Check, Moon, Sun, Trash2, Loader2, AlertTriangle, Smartphone } from 'lucide-react';
import clsx from 'clsx';
import './reel.css'; // the reel fonts (line-of-the-day preview)
import { StyleRow, StylePicker, REEL_STYLES } from './StylePicker'; // v168
import { Page, Group, Row, IconTile, TILE, Toggle, Seg, Sheet, SectionHead, Tag, Avatar, Btn, Field, inputCls, Skeleton, useToast, useBackEntry, makeApi } from '../ui';

type Api = ReturnType<typeof makeApi>;
type Cfg = { on: boolean; max: number; gap_h: number; first_full: boolean; skip_later: boolean; styles: string[]; who: 'agents' | 'pick'; people: string[] };
type Person = { key: string; name: string; role: 'admin' | 'manager' | 'agent'; username: string };
type Vid = { id: number; day: string; title: string; title_raw: string; line_raw: string; title_is_quote: boolean; duration: number; theme: 'dark' | 'light'; theme_override: string; theme_auto: string | null; luma: number | null;
  poster: string | null; state: string; progress: number; note: string | null; width: number | null; height: number | null; size: number; orig_size: number | null; seed: boolean; past: boolean };
type Day = { day: string; past: boolean; videos: Vid[] };

const ROLE_TAG: Record<string, ['acc' | 'prem' | 'warn', string]> = { agent: ['acc', 'Agent'], manager: ['prem', 'Manager'], admin: ['warn', 'Admin'] };
const mmss = (s: number) => { s = Math.max(0, Math.round(s)); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; };
const media = (f: string | null) => (f ? `/api/admin/reel/media/${encodeURIComponent(f)}` : '');
const dayName = (d: string, today: string) => {
  const t = Date.parse(today + 'T00:00:00Z'), x = Date.parse(d + 'T00:00:00Z'), diff = Math.round((x - t) / 86400000);
  const nice = new Date(x).toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short', timeZone: 'UTC' });
  return { main: diff === 0 ? 'Today' : diff === 1 ? 'Tomorrow' : diff === -1 ? 'Yesterday' : new Date(x).toLocaleDateString('en-GB', { weekday: 'long', timeZone: 'UTC' }), sub: diff === 0 || diff === 1 || diff === -1 ? nice : nice.replace(/^\w+ /, '') };
};
const timeOf = (ms: number | null) => (ms ? new Date(ms).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) : '');

export function ReelAdmin({ api, back }: { api: Api; back?: () => void }) {
  const [view, setView] = useState<'home' | 'schedule' | 'report'>('home');
  useBackEntry(view !== 'home', () => setView('home'));
  const sub = () => history.back();
  if (view === 'schedule') return <Schedule api={api} back={sub} />;
  if (view === 'report') return <Report api={api} back={sub} />;
  return <SettingsPage api={api} back={back} go={setView} />;
}

/* ---------------- Settings ---------------- */
function SettingsPage({ api, back, go }: { api: Api; back?: () => void; go: (v: 'schedule' | 'report') => void }) {
  const toast = useToast();
  const [d, setD] = useState<{ cfg: Cfg; people: Person[]; today: string; ffmpeg: boolean; today_videos: number } | null>(null);
  const [sum, setSum] = useState<{ first_done: number; total: number; tomorrow: number } | null>(null);
  const [pick, setPick] = useState<null | 'max' | 'gap'>(null);
  const [stylesOpen, setStylesOpen] = useState(false); // v168: the compact style picker
  const load = useCallback(async () => {
    try {
      const r = await api<any>('reel/settings'); setD(r);
      const [rep, sch] = await Promise.all([api<any>('reel/report'), api<any>('reel/schedule')]);
      const tm = (sch.days as Day[]).find(x => x.day > sch.today);
      setSum({ first_done: rep.first_done, total: rep.total, tomorrow: tm ? tm.videos.length : 0 });
    } catch (e) { toast((e as Error).message, 'err'); }
  }, [api, toast]);
  useEffect(() => { void load(); }, [load]);
  const save = async (patch: Partial<Cfg>) => {
    if (!d) return;
    const prev = d.cfg; setD({ ...d, cfg: { ...d.cfg, ...patch } });
    try { await api('reel/settings_save', patch); } catch (e) { setD({ ...d, cfg: prev }); toast((e as Error).message, 'err'); }
  };
  if (!d) return <Page title="Daily reel" back={back} kicker="Agent app"><Skeleton rows={5} h={56} /></Page>;
  const c = d.cfg, off = !c.on;
  const selected = c.people.length;
  return (
    <Page title="Daily reel" back={back} kicker="Agent app">
      <div data-reel-admin="settings">
        <Group tiles>
          <Row icon={<IconTile icon={Play} color="#C9A866" />} title={<b className="font-semibold">Daily reel</b>} sub={c.on ? 'On. Plays when people open the app.' : 'Off. Nothing reel-related runs.'} chevron={false}
            right={<Toggle on={c.on} onChange={v => save({ on: v })} label="Daily reel" />} />
        </Group>
        <div className={clsx('transition-[opacity,filter]', off && 'pointer-events-none opacity-[.38] grayscale')} aria-disabled={off}>
          <SectionHead title="Rules" />
          <Group tiles>
            <Row icon={<IconTile icon={Repeat2} color={TILE.blue} />} title="Times per day" value={String(c.max)} onClick={() => setPick('max')} data-reel-max />
            <Row icon={<IconTile icon={Clock} color={TILE.teal} />} title="Gap between showings" value={`${c.gap_h} h`} onClick={() => setPick('gap')} />
            <Row icon={<IconTile icon={Eye} color={TILE.green} />} title="First one: watch fully" sub="No skip. Leaving halfway replays it." chevron={false} right={<Toggle on={c.first_full} onChange={v => save({ first_full: v })} label="First one: watch fully" />} />
            <Row icon={<IconTile icon={SkipForward} color={TILE.orange} />} title={`Skip button on 2 to ${c.max}`} sub="“Skip & open chats”" chevron={false} right={<Toggle on={c.skip_later} onChange={v => save({ skip_later: v })} label="Skip button" />} />
          </Group>
          <p className="mx-4 mt-2 text-[13px] leading-snug text-tg-sub">Plays only on a fresh open of the app (a cold start, or coming back after closing it), at least {c.gap_h} h after the last one. It never interrupts someone who is using the app.</p>

          {/* v168: one compact row → the picker sheet (data-driven registry; 20+ styles stay tidy) */}
          <SectionHead title="Player style" />
          <Group tiles>
            <StyleRow styles={REEL_STYLES} selected={c.styles} onOpen={() => setStylesOpen(true)} />
          </Group>
          <p className="mx-4 mt-2 text-[13px] text-tg-sub">Each person gets one of the styles that are on, at random.</p>

          <SectionHead title="Who sees it" action={c.who === 'pick' ? `${selected} selected` : undefined} />
          <Seg full value={c.who} onChange={v => save({ who: v })} items={[['agents', 'All agents'], ['pick', 'Pick people']]} className="mb-2" />
          {c.who === 'pick' && <Group avs>
            {d.people.map((p, i) => {
              const on = c.people.includes(p.key);
              const [tone, lbl] = ROLE_TAG[p.role];
              return <Row key={p.key} onClick={() => save({ people: on ? c.people.filter(x => x !== p.key) : [...c.people, p.key] })} chevron={false} data-reel-person={p.key}
                icon={<Avatar name={p.role === 'admin' ? 'A B' : p.name} id={i + 3} size={40} />} title={<span className="flex items-center gap-2"><span className="truncate">{p.role === 'admin' ? 'You' : p.name}</span><Tag tone={tone}>{lbl}</Tag></span>} right={<CheckDot on={on} />} aria-pressed={on} />;
            })}
          </Group>}
          <p className="mx-4 mt-2 text-[13px] text-tg-sub">{c.who === 'pick' ? 'Test with yourself and your manager first. Switch to All agents when ready.' : 'Every agent sees it. The manager and you only when picked. Their online / offline switch does not matter.'}</p>

          <SectionHead title="Videos" />
          <Group tiles>
            <Row icon={<IconTile icon={CalendarDays} color={TILE.pink} />} title="Schedule" sub={`Today ${d.today_videos} video${d.today_videos === 1 ? '' : 's'}${sum ? ` · Next day ${sum.tomorrow}` : ''}`} onClick={() => go('schedule')} data-reel-go="schedule" />
            <Row icon={<IconTile icon={BarChart3} color={TILE.blue} />} title="Today’s report" sub={sum ? `${sum.first_done} of ${sum.total} watched the first one` : ' '} onClick={() => go('report')} data-reel-go="report" />
            <Row icon={<IconTile icon={Info} color={TILE.grey} />} title="No video for a day" sub="No reel that day. The app opens normally." chevron={false} />
          </Group>
          {!d.ffmpeg && <p className="af-note warn mt-3 text-[13px]">ffmpeg is not on the server, so videos are kept as uploaded. Upload MP4 H.264 files. (scripts/update.sh installs ffmpeg.)</p>}
        </div>
      </div>
      <StylePicker open={stylesOpen} onClose={() => setStylesOpen(false)} styles={REEL_STYLES} selected={c.styles} onSave={ids => save({ styles: ids })} note="Each showing picks one of the styles that are on, at random." />
      <Sheet open={pick !== null} onClose={() => setPick(null)} title={pick === 'max' ? 'Times per day' : 'Gap between showings'}>
        <Group>
          {(pick === 'max' ? [1, 2, 3, 4, 5, 6] : [1, 2, 3, 4, 5, 6, 8, 12]).map(n => {
            const on = pick === 'max' ? c.max === n : c.gap_h === n;
            return <Row key={n} chevron={false} onClick={() => { void save(pick === 'max' ? { max: n } : { gap_h: n }); setPick(null); }} title={pick === 'max' ? `${n} time${n === 1 ? '' : 's'}` : `${n} hour${n === 1 ? '' : 's'}`} right={on ? <Check size={18} className="text-tg-link" /> : null} />;
          })}
        </Group>
      </Sheet>
    </Page>
  );
}
const CheckDot = ({ on }: { on: boolean }) => <span className={clsx('grid h-[22px] w-[22px] shrink-0 place-items-center rounded-full', on ? 'bg-tg-acc text-white' : 'ring-[1.5px] ring-inset ring-tg-sub/50')} aria-hidden>{on && <Check size={14} strokeWidth={3} />}</span>;

/* ---------------- Schedule ---------------- */
function Schedule({ api, back }: { api: Api; back: () => void }) {
  const toast = useToast();
  const [d, setD] = useState<{ today: string; ffmpeg: boolean; days: Day[] } | null>(null);
  const [tab, setTab] = useState<'up' | 'past'>('up');
  const [add, setAdd] = useState<string | null>(null);
  const [edit, setEdit] = useState<Vid | null>(null);
  const load = useCallback(async () => { try { setD(await api('reel/schedule')); } catch (e) { toast((e as Error).message, 'err'); } }, [api, toast]);
  useEffect(() => { void load(); }, [load]);
  const busy = !!d?.days.some(x => x.videos.some(v => v.state === 'processing'));
  useEffect(() => { if (!busy) return; const t = setInterval(() => void load(), 2000); return () => clearInterval(t); }, [busy, load]);
  const days = (d?.days || []).filter(x => (tab === 'up' ? !x.past : x.past));
  return (
    <Page title="Schedule" back={back} action={<button type="button" onClick={() => setAdd(d?.today || '')} aria-label="Add video" className="af-iconbtn acc" data-reel-add><Plus size={20} /></button>}>
      <Seg full value={tab} onChange={setTab} items={[['up', 'Upcoming'], ['past', 'Past']]} className="mb-3" />
      {!d ? <Skeleton rows={3} h={150} /> : !days.length ? <p className="px-1 py-8 text-center text-[14px] text-tg-sub">Nothing here yet.</p> : days.map(x => {
        const n = dayName(x.day, d.today);
        const live = x.day === d.today && x.videos.some(v => v.state === 'ready');
        return (
          <section key={x.day} className="af-card mb-3 px-3.5 py-3" data-reel-day={x.day}>
            <div className="mb-2 flex items-center gap-2"><b className="text-[16px] font-semibold">{n.main}</b><span className="text-[13px] text-tg-sub">{n.sub}</span><span className="flex-1" />
              {live && <Tag tone="ok">Live</Tag>}{x.videos.length ? <Tag>{x.videos.length} video{x.videos.length === 1 ? '' : 's'}</Tag> : !x.past && <Tag tone="warn">No reel</Tag>}</div>
            {x.videos.length ? (
              <div className="-mx-3.5 flex gap-2.5 overflow-x-auto px-3.5 pb-1 [scrollbar-width:none]">
                {x.videos.map(v => <Thumb key={v.id} v={v} onClick={() => setEdit(v)} />)}
                {!x.past && <button type="button" onClick={() => setAdd(x.day)} className="af-press grid h-[63px] w-[112px] shrink-0 place-items-center rounded-[10px] border border-dashed border-tg-sub/40 text-[13px] font-semibold text-tg-link"><span className="flex flex-col items-center gap-0.5"><Plus size={18} />Add</span></button>}
              </div>
            ) : !x.past ? <>
              <button type="button" onClick={() => setAdd(x.day)} className="af-press flex h-[64px] w-full items-center justify-center gap-2 rounded-[12px] border border-dashed border-tg-sub/35 text-[14.5px] font-semibold text-tg-link"><Plus size={18} />Add video</button>
              <p className="mt-2 text-[12.5px] text-tg-sub">No video: the app opens normally that day.</p>
            </> : null}
          </section>
        );
      })}
      <p className="mx-1 mt-1 text-[12.5px] leading-snug text-tg-sub">A day’s video files are deleted from the server after that day ends (00:00 IST). The title, poster and the report stay.</p>
      {add !== null && d && <UploadSheet api={api} day={add} today={d.today} ffmpeg={d.ffmpeg} onClose={() => setAdd(null)} onDone={() => { setAdd(null); void load(); }} />}
      {edit && d && <EditSheet api={api} v={edit} today={d.today} onClose={() => setEdit(null)} onDone={() => { setEdit(null); void load(); }} />}
    </Page>
  );
}

function Thumb({ v, onClick }: { v: Vid; onClick: () => void }) {
  return (
    <button type="button" onClick={onClick} className="af-press w-[112px] shrink-0 text-left" data-reel-thumb={v.id} data-state={v.state}>
      <span className="relative block h-[63px] w-[112px] overflow-hidden rounded-[10px] bg-tg-panel2">
        {v.poster && <img src={media(v.poster)} alt="" className={clsx('h-full w-full object-cover', v.state === 'processing' && 'opacity-50')} />}{/* eslint-disable-line @next/next/no-img-element */}
        <span className={clsx('absolute left-1.5 top-1.5 rounded-[5px] px-1.5 py-[1px] text-[9.5px] font-bold tracking-[.06em]', v.theme === 'dark' ? 'bg-black/70 text-white' : 'bg-white/85 text-black')}>{v.theme === 'dark' ? 'DARK' : 'LIGHT'}</span>
        {v.state === 'ready' && <span className="absolute bottom-1.5 right-1.5 rounded-[5px] bg-black/65 px-1.5 text-[11px] font-semibold text-white af-num">{mmss(v.duration)}</span>}
        {v.state === 'processing' && <span className="absolute inset-0 grid place-items-center text-[11px] font-semibold text-white"><span className="flex items-center gap-1 rounded-full bg-black/60 px-2 py-0.5"><Loader2 size={11} className="animate-spin" />{v.progress > 1 ? `${v.progress}%` : 'Optimising'}</span></span>}
        {v.state === 'failed' && <span className="absolute inset-0 grid place-items-center bg-black/55 text-[11px] font-semibold text-white">Failed</span>}
        {v.state === 'purged' && <span className="absolute bottom-1.5 right-1.5 rounded-[5px] bg-black/65 px-1.5 text-[10px] text-white">Removed</span>}
      </span>
      <span className="mt-1 block truncate text-[13px]">{v.title_raw || <span className="text-tg-sub">Quote of the day</span>}</span>
      <span className="block truncate text-[11.5px] text-tg-sub">{v.state === 'processing' ? 'Optimising video…' : v.line_raw ? 'Line of the day' : v.note ? 'Check this video' : ' '}</span>
    </button>
  );
}

/* ---------------- Upload (checks in this browser, then chunks) ---------------- */
type Probe = { duration: number; width: number; height: number; playable: boolean; poster: string | null; luma: number | null };
async function probeVideo(file: File, onStep: (s: string) => void): Promise<Probe> {
  const url = URL.createObjectURL(file);
  const v = document.createElement('video');
  v.muted = true; v.preload = 'auto'; v.playsInline = true; v.src = url;
  try {
    const meta = await new Promise<boolean>(res => { const t = setTimeout(() => res(false), 10000); v.onloadedmetadata = () => { clearTimeout(t); res(true); }; v.onerror = () => { clearTimeout(t); res(false); }; });
    if (!meta || !Number.isFinite(v.duration)) return { duration: 0, width: 0, height: 0, playable: false, poster: null, luma: null };
    const seek = (t: number) => new Promise<boolean>(res => { const to = setTimeout(() => res(false), 4000); v.onseeked = () => { clearTimeout(to); res(true); }; v.currentTime = t; });
    const can = document.createElement('canvas');
    // frames decode? (HEVC on many browsers: metadata yes, picture no)
    const ok = await seek(Math.min(v.duration * 0.25, Math.max(0, v.duration - 0.1))) && v.videoWidth > 0;
    let poster: string | null = null, luma: number | null = null;
    if (ok) {
      can.width = 640; can.height = Math.round(640 * v.videoHeight / v.videoWidth) || 360;
      const ctx = can.getContext('2d', { willReadFrequently: true })!;
      ctx.drawImage(v, 0, 0, can.width, can.height);
      const px = ctx.getImageData(0, 0, 8, 8).data; const blank = px.every((x, i) => i % 4 === 3 || x === 0);
      poster = blank && v.duration > 1 ? null : can.toDataURL('image/jpeg', 0.82);
      // brightness: ~1 frame per second at 64 px
      onStep('Checking brightness…');
      const s = document.createElement('canvas'); s.width = 64; s.height = Math.max(1, Math.round(64 * v.videoHeight / v.videoWidth));
      const sc = s.getContext('2d', { willReadFrequently: true })!;
      let sum = 0, n = 0;
      for (let t = 0.5; t < v.duration && n < 46; t += 1) {
        if (!(await seek(t))) continue;
        sc.drawImage(v, 0, 0, s.width, s.height);
        const d = sc.getImageData(0, 0, s.width, s.height).data;
        // v168: a frame that is pure black everywhere was not decoded yet (seen on busy machines) → not counted; no frame
        // counted at all → luma null and the server measures it with ffmpeg instead
        let fs = 0, any = false;
        for (let i = 0; i < d.length; i += 4) { if (d[i] | d[i + 1] | d[i + 2]) any = true; fs += (0.2126 * d[i] + 0.7152 * d[i + 1] + 0.0722 * d[i + 2]) / 255; }
        if (!any) continue;
        sum += fs; n += d.length / 4;
      }
      luma = n ? Math.round(sum / n * 1000) / 1000 : null;
    }
    return { duration: v.duration, width: v.videoWidth, height: v.videoHeight, playable: ok, poster, luma };
  } finally { v.removeAttribute('src'); v.load(); URL.revokeObjectURL(url); }
}

function UploadSheet({ api, day: day0, today, ffmpeg, onClose, onDone }: { api: Api; day: string; today: string; ffmpeg: boolean; onClose: () => void; onDone: () => void }) {
  const toast = useToast();
  const [file, setFile] = useState<File | null>(null);
  const [pr, setPr] = useState<Probe | null>(null);
  const [step, setStep] = useState('');
  const [day, setDay] = useState(day0 || today);
  const [title, setTitle] = useState(''), [line, setLine] = useState('');
  const [theme, setTheme] = useState<'auto' | 'dark' | 'light'>('auto');
  const [pct, setPct] = useState<number | null>(null);
  const [err, setErr] = useState('');
  const prevUrl = useMemo(() => (file ? URL.createObjectURL(file) : ''), [file]);
  useEffect(() => () => { if (prevUrl) URL.revokeObjectURL(prevUrl); }, [prevUrl]);
  const cancelRef = useRef(false);
  useEffect(() => () => { cancelRef.current = true; }, []);
  const pickFile = async (f: File | null) => {
    setErr(''); setPr(null); setFile(f);
    if (!f) return;
    if (f.size > 200 * 1024 * 1024) { setErr('The video is larger than 200 MB.'); return; }
    setStep('Reading the video…');
    const p = await probeVideo(f, setStep);
    setStep(''); setPr(p);
    if (!p.duration) setErr('This file can’t be read as a video. Export it as MP4 H.264 (720p or 1080p).');
    else if (p.duration > 45.5) setErr(`The video is ${Math.round(p.duration)} s. The limit is 45 s.`);
  };
  const detected = pr?.luma == null ? null : pr.luma < 0.40 ? 'dark' : 'light';
  const canAdd = !!file && !!pr && pr.duration > 0 && pr.duration <= 45.5 && (pr.playable || ffmpeg) && day >= today && pct === null;
  const upload = async () => {
    if (!file || !pr) return;
    setErr(''); setPct(0);
    try {
      const init = await api<{ upload_id: string; chunk: number }>('reel/upload_init', { day, title, line, theme, size: file.size, duration: pr.duration, luma: pr.luma, mime: file.type, name: file.name, playable: pr.playable, width: pr.width, height: pr.height });
      let off = 0, fails = 0;
      while (off < file.size) {
        if (cancelRef.current) { void api('reel/upload_cancel', { upload_id: init.upload_id }).catch(() => {}); return; }
        const part = file.slice(off, off + init.chunk);
        try {
          const r = await fetch(`/api/admin/reel/upload_chunk?id=${init.upload_id}&off=${off}`, { method: 'POST', credentials: 'same-origin', headers: { 'content-type': 'application/octet-stream' }, body: part });
          const j = await r.json().catch(() => ({}));
          if (r.status === 409 && typeof j.got === 'number') { off = j.got; continue; }
          if (!r.ok) throw new Error(j.error || `Upload failed (${r.status})`);
          off = j.got; fails = 0; setPct(Math.round(off / file.size * 100));
        } catch (e) {
          if (++fails > 8) throw e;
          await new Promise(r => setTimeout(r, Math.min(8000, 800 * fails)));
        }
      }
      await api('reel/upload_done', { upload_id: init.upload_id, poster: pr.poster });
      toast(ffmpeg ? 'Uploaded. Optimising the video…' : 'Video added');
      onDone();
    } catch (e) { setPct(null); setErr((e as Error).message); }
  };
  return (
    <Sheet open onClose={onClose} title="Add video" wide>
      <div data-reel-upload>
        <label className={clsx('af-press relative mb-3 block aspect-video w-full overflow-hidden rounded-[14px] bg-tg-panel2', !file && 'grid place-items-center border border-dashed border-tg-sub/40')}>
          <input type="file" accept="video/mp4,video/quicktime,video/webm,video/*" className="sr-only" onChange={e => void pickFile(e.target.files?.[0] || null)} data-reel-file />
          {file && prevUrl ? <video src={prevUrl} muted playsInline className="h-full w-full object-cover" /> : <span className="flex flex-col items-center gap-1.5 text-[14.5px] font-semibold text-tg-link"><Plus size={22} />Choose a video<span className="text-[12px] font-normal text-tg-sub">Up to 45 s · MP4 or MOV · max 200 MB</span></span>}
          {pr && pr.duration > 0 && <span className={clsx('absolute bottom-2 left-2 flex items-center gap-1 rounded-full px-2 py-0.5 text-[12px] font-semibold', pr.duration <= 45.5 ? 'bg-black/60 text-[#7CE38B]' : 'bg-black/60 text-[#FF8A80]')}>{pr.duration <= 45.5 ? <Check size={12} strokeWidth={3} /> : <AlertTriangle size={12} />}{mmss(pr.duration)} · {pr.duration <= 45.5 ? 'under 45 s' : 'too long'}</span>}
          {pr && pr.width > 0 && <span className="absolute bottom-2 right-2 rounded-full bg-black/60 px-2 py-0.5 text-[12px] text-white af-num">{pr.width}×{pr.height}</span>}
        </label>
        {step && <p className="mb-3 flex items-center gap-2 text-[13px] text-tg-sub"><Loader2 size={14} className="animate-spin" />{step}</p>}
        {pr && !pr.playable && pr.duration > 0 && <p className="af-note warn mb-3 text-[13px]" data-reel-unplayable>This video format won’t play on many phones. Export it as MP4 H.264 (720p or 1080p).{ffmpeg ? ' The server will convert this one.' : ''}</p>}
        <Group tiles className="mb-3">
          <Row icon={<IconTile icon={CalendarDays} color={TILE.pink} />} title="Day" chevron={false} right={<input type="date" value={day} min={today} onChange={e => setDay(e.target.value)} className="rounded-lg bg-tg-panel2 px-2 py-1 text-[14.5px] text-tg-text" data-reel-day-input />} />
          <div className="af-rowwrap px-4 py-3">
            <div className="flex items-center gap-3"><span className="grid h-[30px] w-[30px] place-items-center text-tg-sub">{(theme === 'auto' ? detected : theme) === 'light' ? <Sun size={18} /> : <Moon size={18} />}</span>
              <span className="min-w-0 flex-1"><span className="block text-[15.5px]">Player look</span><span className="block text-[13px] text-tg-sub">{pr?.luma != null ? `Detected: ${detected} video (brightness ${Math.round(pr.luma * 100)}%)` : 'Detected after you choose a video'}</span></span></div>
            <Seg full value={theme} onChange={setTheme} items={[['auto', 'Auto'], ['dark', 'Dark'], ['light', 'Light']]} className="mt-2.5" />
          </div>
        </Group>
        <Field label="Title (optional)" hint="Empty = a motivational quote is shown instead."><input className={inputCls} value={title} maxLength={80} onChange={e => setTitle(e.target.value)} placeholder="Ab thak chuke?" data-reel-title-input /></Field>
        <Field label={<span className="flex justify-between"><span>Line of the day (optional)</span><span className="af-num text-tg-sub">{line.length}/90</span></span>} hint="Shown on the end card after the first reel of the day.">
          <input className={clsx(inputCls, 'font-[RlFraunces,Georgia,serif] italic')} value={line} maxLength={90} onChange={e => setLine(e.target.value)} placeholder="Aaj 3 sale ka target. Tum kar sakte ho." />
        </Field>
        <p className="mb-3 text-[12.5px] leading-snug text-tg-sub">Landscape 16:9 is best. Up to 45 s, MP4 or MOV.{ffmpeg ? ' The server makes it ready for phones without quality loss (it shows to people when that is done).' : ' Upload MP4 H.264 (ffmpeg is not on the server).'}</p>
        {err && <p role="alert" className="af-note bad mb-3 text-[13px]" data-reel-err>{err}</p>}
        {pct !== null && <div className="mb-3"><div className="af-bar"><i style={{ width: `${pct}%`, background: 'rgb(var(--tg-acc))' }} /></div><p className="mt-1 text-[12.5px] text-tg-sub af-num">Uploading… {pct}%</p></div>}
        <div className="flex gap-2"><Btn kind="ghost" className="flex-1" onClick={onClose}>Cancel</Btn><Btn className="flex-1" onClick={upload} disabled={!canAdd} busy={pct !== null} data-reel-submit>Add</Btn></div>
      </div>
    </Sheet>
  );
}

function EditSheet({ api, v, today, onClose, onDone }: { api: Api; v: Vid; today: string; onClose: () => void; onDone: () => void }) {
  const toast = useToast();
  const [title, setTitle] = useState(v.title_raw), [line, setLine] = useState(v.line_raw);
  const [theme, setTheme] = useState<'auto' | 'dark' | 'light'>((v.theme_override as 'auto') || 'auto');
  const [day, setDay] = useState(v.day);
  const [busy, setBusy] = useState(false);
  const save = async () => { setBusy(true); try { await api('reel/update', { id: v.id, title, line, theme, day }); onDone(); } catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); } };
  const del = async () => { if (!confirm('Delete this video?')) return; setBusy(true); try { await api('reel/delete', { id: v.id }); toast('Deleted'); onDone(); } catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); } };
  return (
    <Sheet open onClose={onClose} title="Video" wide>
      <div className="relative mb-3 aspect-video w-full overflow-hidden rounded-[14px] bg-tg-panel2">{v.poster && <img src={media(v.poster)} alt="" className="h-full w-full object-cover" />}{/* eslint-disable-line @next/next/no-img-element */}
        <span className="absolute bottom-2 left-2 rounded-full bg-black/60 px-2 py-0.5 text-[12px] text-white af-num">{mmss(v.duration)}{v.width ? ` · ${v.width}×${v.height}` : ''}{v.size ? ` · ${(v.size / 1048576).toFixed(1)} MB` : ''}</span></div>
      {v.note && <p className="af-note warn mb-3 text-[13px]">{v.note}</p>}
      {v.state === 'processing' && <p className="af-note acc mb-3 text-[13px]">Optimising video… {v.progress}%. It shows to people when this is done.</p>}
      {v.seed && <p className="mb-3 text-[12.5px] text-tg-sub">This is the video that came with the update.</p>}
      {!v.past && <>
        <Group tiles className="mb-3">
          <Row icon={<IconTile icon={CalendarDays} color={TILE.pink} />} title="Day" chevron={false} right={<input type="date" value={day} min={today} onChange={e => setDay(e.target.value)} className="rounded-lg bg-tg-panel2 px-2 py-1 text-[14.5px] text-tg-text" />} />
          <div className="af-rowwrap px-4 py-3"><span className="block text-[15.5px]">Player look</span><span className="block text-[13px] text-tg-sub">{v.luma != null ? `Detected: ${v.theme_auto} (brightness ${Math.round(v.luma * 100)}%)` : 'Auto'}</span>
            <Seg full value={theme} onChange={setTheme} items={[['auto', 'Auto'], ['dark', 'Dark'], ['light', 'Light']]} className="mt-2.5" /></div>
        </Group>
        <Field label="Title (optional)" hint="Empty = a motivational quote."><input className={inputCls} value={title} maxLength={80} onChange={e => setTitle(e.target.value)} /></Field>
        <Field label="Line of the day (optional)"><input className={inputCls} value={line} maxLength={90} onChange={e => setLine(e.target.value)} /></Field>
      </>}
      <div className="flex gap-2"><Btn kind="danger" onClick={del} busy={busy}><Trash2 size={15} />Delete</Btn><span className="flex-1" />{!v.past && <Btn onClick={save} busy={busy}>Save</Btn>}</div>
    </Sheet>
  );
}

/* ---------------- Report ---------------- */
type RRow = { ready_on_phone?: boolean; via?: 'native' | 'web'; app_build?: string | number | null; // v168: from reel/cached (hidden when missing)
  key: string; role: string; id: number; name: string; showings: { n: number; state: string; at: number; watched: number; duration: number }[]; watched: number; skipped: number; first_done: boolean; first_at: number | null; first_left: number | null; opened: boolean };
function Report({ api, back }: { api: Api; back: () => void }) {
  const toast = useToast();
  const [day, setDay] = useState('');
  const [r, setR] = useState<{ today: string; day: string; max: number; total: number; first_done: number; watched: number; skipped: number; not_yet: number; rows: RRow[]; videos: number } | null>(null);
  useEffect(() => { void api<any>('reel/report' + (day ? `?day=${day}` : '')).then(setR).catch(e => toast((e as Error).message, 'err')); }, [api, day, toast]);
  const isToday = !r || r.day === r.today;
  const done = (r?.rows || []).filter(x => x.opened).sort((a, b) => (a.first_at || 9e15) - (b.first_at || 9e15));
  const notYet = (r?.rows || []).filter(x => !x.first_done);
  // v168: "Ready on 3 of 4 phones" — only people whose app reported its cache (the field is missing otherwise)
  const phones = (() => { const rs = (r?.rows || []).filter(x => typeof x.ready_on_phone === 'boolean'); return { n: rs.length, ready: rs.filter(x => x.ready_on_phone).length }; })();
  const nice = r ? new Date(Date.parse(r.day + 'T00:00:00Z')).toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short', timeZone: 'UTC' }) : '';
  return (
    <Page title={isToday ? 'Today’s report' : 'Report'} back={back} kicker={nice} right={<input type="date" value={day || r?.day || ''} max={r?.today} onChange={e => setDay(e.target.value)} className="af-pill" aria-label="Day" data-reel-report-day />}>
      {!r ? <Skeleton rows={4} h={64} /> : <div data-reel-admin="report">
        <div className="af-card px-4 pb-3 pt-3.5">
          <p className="text-[13px] text-tg-sub">Watched the first reel fully</p>
          <p className="mt-0.5 text-[34px] font-bold leading-none af-num" data-reel-first-done>{r.first_done} <span className="text-[20px] font-medium text-tg-sub">of {r.total}</span></p>
          <div className="af-bar mt-3"><i style={{ width: `${r.total ? r.first_done / r.total * 100 : 0}%`, background: '#34C759' }} /></div>
          <div className="af-grid3 mt-3 border-t border-tg-sep pt-3">
            <div><p className="truncate text-[12.5px] text-tg-sub">Watched fully</p><p className="af-mid-num">{r.watched}</p></div>
            <div><p className="truncate text-[12.5px] text-tg-sub">Skipped later</p><p className="af-mid-num">{r.skipped}</p></div>
            <div><p className="text-[12.5px] text-tg-sub">Not yet</p><p className="af-mid-num">{r.not_yet}</p></div>
          </div>
        </div>
        {phones.n > 0 && <p className="mx-1 mt-2.5 flex items-center gap-1.5 text-[13px] text-tg-sub" data-reel-ready-sum><Smartphone size={14} />Ready on <b className="font-semibold text-tg-text af-num">{phones.ready} of {phones.n}</b> phone{phones.n === 1 ? '' : 's'}</p>}
        <div className="mx-1 mt-2 flex gap-4 text-[12.5px] text-tg-sub"><Lg c="#34C759" t="Watched" /><Lg c="#F2B200" t="Skipped" /><Lg c="rgb(var(--tg-sub) / .35)" t="Not yet" /></div>
        {!r.videos && <p className="af-note mt-3 text-[13px]">No video that day, so no reel was shown.</p>}
        {done.length > 0 && <><SectionHead title={isToday ? 'Watched today' : 'Watched'} action="first at" />
          <Group avs>{done.map((x, i) => <Row key={x.key} chevron={false} data-reel-row={x.key}
            icon={<Avatar name={x.role === 'admin' ? 'A B' : x.name} id={i + 3} size={40} />}
            title={<span className="flex items-center gap-2"><span className="truncate">{x.role === 'admin' ? 'You' : x.name}</span><Tag tone={ROLE_TAG[x.role]?.[0] || 'acc'}>{ROLE_TAG[x.role]?.[1] || 'Agent'}</Tag></span>}
            sub={<span className="block"><PhoneSt x={x} /><span className="block truncate">{[x.watched && `${x.watched} watched fully`, x.skipped && `${x.skipped} skipped`, r.max - x.showings.length > 0 && `${r.max - x.showings.length} not yet`].filter(Boolean).join(' · ') || 'Started'}</span><Bars x={x} max={r.max} /></span>}
            value={x.first_at ? timeOf(x.first_at) : x.first_left != null ? `left at ${mmss(x.first_left)}` : ''} />)}</Group></>}
        {notYet.length > 0 && <><SectionHead title="Not yet" />
          <Group avs>{notYet.map((x, i) => <Row key={x.key} chevron={false} data-reel-notyet={x.key}
            icon={<Avatar name={x.role === 'admin' ? 'A B' : x.name} id={i + 7} size={40} />}
            title={<span className="flex items-center gap-2"><span className="truncate">{x.role === 'admin' ? 'You' : x.name}</span><Tag tone={ROLE_TAG[x.role]?.[0] || 'acc'}>{ROLE_TAG[x.role]?.[1] || 'Agent'}</Tag></span>}
            sub={<span className="block"><PhoneSt x={x} /><span className="block">{x.opened ? `Started at ${timeOf(x.showings[0]?.at)}, left at ${mmss(x.first_left || 0)}. Replays next open.` : `Hasn’t opened the app${isToday ? ' today' : ''}`}</span></span>} />)}</Group></>}
      </div>}
    </Page>
  );
}
/** v168: "Ready on phone" (green) / "Not downloaded yet" (grey) + the app version — admin only, hidden without data. */
function PhoneSt({ x }: { x: RRow }) {
  if (typeof x.ready_on_phone !== 'boolean') return null;
  const b = x.app_build != null && String(x.app_build).trim() ? String(x.app_build).trim() : '';
  return (
    <span className="mb-0.5 flex items-center gap-1.5 text-[12px]" data-reel-phone={x.ready_on_phone ? 'ready' : 'no'}>
      <i className="block h-[7px] w-[7px] rounded-full" style={{ background: x.ready_on_phone ? '#34C759' : 'rgb(var(--tg-sub) / .45)' }} />
      <span className={x.ready_on_phone ? 'font-medium text-tg-green' : 'text-tg-sub'}>{x.ready_on_phone ? 'Ready on phone' : 'Not downloaded yet'}</span>
      {b && <span className="text-[11px] text-tg-sub">· App {b}</span>}
    </span>
  );
}
const Lg = ({ c, t }: { c: string; t: string }) => <span className="flex items-center gap-1.5"><i className="block h-[3px] w-3.5 rounded-full" style={{ background: c }} />{t}</span>;
function Bars({ x, max }: { x: RRow; max: number }) {
  return <span className="mt-1.5 flex gap-1" aria-hidden>{Array.from({ length: max }, (_, i) => { const s = x.showings.find(v => v.n === i + 1); const c = !s ? 'rgb(var(--tg-sub) / .3)' : s.state === 'watched' ? '#34C759' : s.state === 'skipped' ? '#F2B200' : 'rgb(var(--tg-sub) / .55)'; return <i key={i} className="block h-[3px] w-4 rounded-full" style={{ background: c }} />; })}</span>;
}

/* ---------------- System → Force update (v167) ---------------- */
export function ForceUpdateCard({ api }: { api: Api }) {
  const toast = useToast();
  const [s, setS] = useState<{ on: boolean; min_agent: number; min_admin: number; built: boolean; code: number; name: string; apk_agent: boolean; apk_admin: boolean } | null>(null);
  useEffect(() => { void api<any>('app_force').then(setS).catch(() => {}); }, [api]);
  if (!s) return null;
  const set = async (on: boolean) => { try { setS(await api('app_force_set', { on })); } catch (e) { toast((e as Error).message, 'err'); } };
  return (
    <section className="mb-4" data-force-update-card>
      <SectionHead title="Android apps" />
      <Group tiles>
        <Row icon={<IconTile icon={Smartphone} color={TILE.indigo} />} title="Force update" chevron={false}
          sub={!s.built ? 'Waits for the new APK build' : s.min_agent || s.min_admin ? `Apps older than ${s.name || 'build ' + Math.max(s.min_agent, s.min_admin)} must update` : 'Nothing to force right now'}
          right={<Toggle on={s.on} onChange={v => void set(v)} label="Force update" />} />
      </Group>
      <p className="mx-4 mt-2 text-[12.5px] leading-snug text-tg-sub">An app older than the newest build shows “Update required” and opens only after updating. Browsers are never blocked, and nothing is blocked until the new APK is on the server.</p>
    </section>
  );
}
