'use client';
/* v167: Daily reel gate — mounted on every fresh open (cold start / reload, or back after 30+ min away; see useFreshOpen).
 *  Asks the server what to show (it decides showing number, gap, max, skip), makes sure the video is fully downloaded and
 *  verified (download-first: never a partial / streamed file), then plays it. Anything missing → the app opens normally
 *  at once and the download goes on in the background for the next fresh open. Never blocks the app for long:
 *  the decision has 2.5 s, a not-yet-downloaded reel gets 3 s, then the app opens.
 *  A push-notification tap skips the reel for that open (the chat opens instead).
 *  v168: showing 1 not downloaded yet → a calm hello screen (greeting, name, date — NEVER any download text or progress) while
 *  the download silently goes on, for up to 20 s but only while it is fast enough to finish in time; otherwise the app
 *  opens normally with no message and the reel plays on the next fresh open. A finished download never interrupts. */
import { lazy, Suspense, useCallback, useEffect, useRef, useState } from 'react';
import type { ReelNext } from './ReelPlayer';
import { prefetchReels, whenReady, whenReadySoon, readySrc } from './cache';

const PUSH_KEY = '__afPushAt';
/** Call when the app was opened by tapping a push notification (the reel and the greeting splash skip this open). */
export function markPushOpen() {
  try { (window as unknown as Record<string, number>)[PUSH_KEY] = Date.now(); window.dispatchEvent(new Event('af-push-open')); } catch { /* */ }
}
export const pushOpenedRecently = (ms = 8000) => { try { return Date.now() - ((window as unknown as Record<string, number>)[PUSH_KEY] || 0) < ms; } catch { return false; } };

// the player (fonts CSS + glyph outlines) loads only when there is a reel to show
const loadPlayer = () => import('./ReelPlayer');
const ReelPlayer = lazy(() => loadPlayer().then(m => ({ default: m.ReelPlayer })));
// v168: the agent formats E–T play in TemplatePlayer (a same-origin iframe of public/reel-tpl/<ID>); A–D in ReelPlayer
const loadTpl = () => import('./TemplatePlayer');
const TemplatePlayer = lazy(() => loadTpl().then(m => ({ default: m.TemplatePlayer })));
// v179: U–AD (v174 agent formats) are templates too — before this they fell into ReelPlayer and showed a black stage
const isTpl = (s: unknown) => typeof s === 'string' && /^([E-Z]|A[A-D])$/.test(s);

export type GateResult = { splash: boolean; shown: boolean };

export function ReelGate({ api, onDone, cover }: { api: string; onDone: (r: GateResult) => void; cover?: boolean }) {
  const [st, setSt] = useState<{ data: ReelNext; src: string; revoke: () => void } | null>(null);
  const [deciding, setDeciding] = useState(true);
  const [tplFail, setTplFail] = useState(false); // v168: the template page did not come up → this showing plays in ReelPlayer (A)
  const [hello, setHello] = useState<string | null>(null); // v168: the waiting hello screen (first name or '')
  const doneRef = useRef(onDone); doneRef.current = onDone; // the parent's callback may change every render
  // v179 test hook (tests only): ?af_crash_test=1 throws here once so the app's crash screen (AppCrash) can be checked
  if (typeof location !== 'undefined' && /[?&]af_crash_test=1/.test(location.search) && !/af_crash_reloads/.test(document.cookie + (() => { try { return sessionStorage.getItem('af_crash_reloads') || ''; } catch { return ''; } })() ? 'af_crash_reloads' : '')) throw new Error('af crash test');
  const speed = (() => { try { return Math.min(1, Math.max(0.05, Number(new URLSearchParams(location.search).get('af_reel_speed')) || 1)); } catch { return 1; } })(); // test hook (screens / tests only)

  useEffect(() => {
    let on = true;
    const finish = (r: GateResult) => { if (on) { on = false; setDeciding(false); doneRef.current(r); } };
    const onPush = () => finish({ splash: false, shown: false });
    window.addEventListener('af-push-open', onPush);
    (async () => {
      if (pushOpenedRecently()) return finish({ splash: false, shown: false });
      void prefetchReels(api, true); // fresh open: refresh the list + keep downloading
      let d: (ReelNext | { show: false }) | null = null;
      try {
        const ac = new AbortController(); const t = setTimeout(() => ac.abort(), 2500);
        const r = await fetch(`${api}/next`, { credentials: 'same-origin', cache: 'no-store', signal: ac.signal });
        clearTimeout(t);
        d = r.ok ? await r.json() : null;
      } catch { d = null; }
      if (!on) return;
      if (!d || !d.show) return finish({ splash: true, shown: false });
      const data = d as ReelNext;
      // v168: a template style warms its page, runtime and fonts now (during the decision / download check)
      const chunk = (isTpl(data.style) ? loadTpl().then(m => { m.preloadTemplate(data.style); return m; }) : loadPlayer()).catch(() => null);
      const f = { id: data.reel.id, file: data.reel.file, size: data.reel.size, sha256: data.reel.sha256, mime: data.reel.mime };
      // download-first: play only a complete, verified copy (native app cache first, then Cache Storage)
      let ok = await whenReady(api, f, data.showing === 1 ? 600 : 3000);
      // v177 (owner): showings 2+ — the new video is not on the phone yet → play another of today's videos that is (never skip silently)
      if (!ok && on && data.showing > 1) {
        for (const alt of (data as ReelNext & { alts?: ReelNext['reel'][] }).alts || []) {
          const g = { id: alt.id, file: alt.file, size: alt.size, sha256: alt.sha256, mime: alt.mime };
          if (await whenReady(api, g, 600)) { data.reel = { ...alt, title: alt.title || data.reel.title }; Object.assign(f, g); ok = true; break; }
        }
      }
      if (!ok && on && data.showing === 1 && !pushOpenedRecently()) {
        // v168: showing 1 is due → hello screen while it silently finishes, only if it can within 20 s
        setHello(String(data.name || '').trim()); setDeciding(false);
        ok = await whenReadySoon(api, f, 20000, () => on && !pushOpenedRecently());
      }
      if (!on) return;
      let src = ok ? await readySrc(api, f.file, f) : null;
      // v179: a template plays the video inside an iframe, often in more than one <video> at once; on phones the app's
      // native file URL could freeze there (intro drawn, video never starts). Read the native copy into memory once and
      // give the template a blob: URL instead (same bytes, no network). Falls back to the native URL if that fails.
      if (src && isTpl(data.style) && !src.src.startsWith('blob:')) {
        try {
          const ac = new AbortController(); const t = setTimeout(() => ac.abort(), 8000);
          const r = await fetch(src.src, { signal: ac.signal, cache: 'no-store' });
          const blob = r.ok ? await r.blob() : null; clearTimeout(t);
          if (blob && blob.size > 0 && (!f.size || blob.size === f.size)) { const o = URL.createObjectURL(blob); src = { src: o, revoke: () => URL.revokeObjectURL(o) }; }
        } catch { /* keep the native URL */ }
      }
      if (!on) { src?.revoke(); return; }
      if (!src || pushOpenedRecently() || !(await chunk)) { src?.revoke(); return finish({ splash: !pushOpenedRecently(), shown: false }); }
      window.removeEventListener('af-push-open', onPush);
      setDeciding(false);
      setSt({ data, src: src.src, revoke: src.revoke });
    })();
    return () => { on = false; window.removeEventListener('af-push-open', onPush); };
  }, [api]);
  useEffect(() => () => st?.revoke(), [st]);
  // v168: the hello screen stays under the player until its wipe-in has covered the screen, then goes
  useEffect(() => { if (!st || hello === null) return; const t = setTimeout(() => setHello(null), 1400); return () => clearTimeout(t); }, [st, hello]);

  const post = useCallback(async (path: string, body: Record<string, unknown>) => {
    const r = await fetch(`${api}/${path}`, { method: 'POST', credentials: 'same-origin', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok || j.error) throw new Error(j.error || 'Request failed');
    return j;
  }, []);

  // v168: the native copy failed to play (markNativeBad is already set) → the verified Cache Storage copy, else the app opens
  // normally (the web download goes on for the next fresh open; never a streamed / partial file)
  const srcFail = async () => {
    const cur = st; if (!cur) return;
    const f = { id: cur.data.reel.id, sha256: cur.data.reel.sha256 };
    const c = await readySrc(api, cur.data.reel.file, f).catch(() => null);
    if (c && c.src.startsWith('blob:')) { cur.revoke(); setSt({ ...cur, src: c.src, revoke: c.revoke }); return; }
    c?.revoke();
    void prefetchReels(api, true);
    doneRef.current({ splash: true, shown: false });
  };
  if (st && isTpl(st.data.style) && !tplFail) return <>{hello !== null && <HelloWait name={hello} />}<Suspense fallback={null}><TemplatePlayer key={st.src} api={api} data={st.data} src={st.src} post={post} testSpeed={speed} onSrcFail={srcFail} onFail={() => setTplFail(true)} onExit={r => doneRef.current({ splash: r.splash, shown: true })} /></Suspense></>; // v168
  if (st) return <>{hello !== null && <HelloWait name={hello} />}<Suspense fallback={null}><ReelPlayer key={st.src} api={api} data={tplFail ? { ...st.data, style: 'A' } : st.data} src={st.src} post={post} testSpeed={speed} onSrcFail={srcFail} onExit={r => doneRef.current({ splash: r.splash, shown: true })} /></Suspense></>;
  if (hello !== null) return <HelloWait name={hello} />;
  // while deciding: a plain cover in the app's colour (the greeting splash follows for agents), else nothing
  return deciding && cover ? <div className="fixed inset-0 z-[299] bg-tg-bg" aria-hidden data-reel-deciding /> : null;
}

/** v168: the calm screen shown while today's first reel silently finishes downloading. Greeting + name + date only:
 *  agents never see anything about downloads (owner's rule). Light / dark follows the phone. */
function HelloWait({ name }: { name: string }) {
  const d = new Date(), h = d.getHours();
  const greet = h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
  const date = d.toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' });
  return (
    <div className="fixed inset-0 z-[9989] flex flex-col items-center justify-center bg-tg-bg px-8 text-center text-tg-text" data-reel-hello-wait aria-live="polite"
      style={{ animation: 'afHelloIn 500ms cubic-bezier(.33,1,.68,1) both' }}>
      <style>{'@keyframes afHelloIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}@keyframes afHelloGlow{0%,100%{opacity:.35;transform:scale(.92)}50%{opacity:.7;transform:scale(1.06)}}'}</style>
      <div className="relative mb-7 grid h-16 w-16 place-items-center">
        <span className="absolute inset-[-14px] rounded-full bg-tg-acc/25 blur-xl" style={{ animation: 'afHelloGlow 2.6s ease-in-out infinite' }} />
        <img src="/reel/logo.png" alt="" width={64} height={64} className="relative h-16 w-16 rounded-[24%] object-cover" />{/* eslint-disable-line @next/next/no-img-element */}
      </div>
      <div className="text-[12px] font-semibold uppercase tracking-[.22em] text-tg-sub">{date}</div>
      <div className="mt-3 text-[30px] font-semibold leading-tight tracking-[-.01em]">{greet}{name ? ',' : ''}</div>
      {name && <div className="mt-1 text-[30px] font-semibold leading-tight text-tg-acc">{name.split(/\s+/)[0]}</div>}
      <div className="mt-5 text-[15px] text-tg-sub">Your day is starting.</div>
    </div>
  );
}

/** v168: called as soon as the app page loads, before the login check finishes: with a saved session the reel files start
 *  downloading at once (without one the list call is a quiet 401). */
export function earlyReelPrefetch(api: string) { void prefetchReels(api, true).catch(() => {}); }

/** Keeps the reel files of today / tomorrow downloading while the app is open (asks for the list at most every 30 min). */
export function ReelBackground({ api, on = true }: { api: string; on?: boolean }) {
  useEffect(() => {
    if (!on) return;
    // v168: start at once (not only on the next fresh open), every 2 min while open (the list itself is asked at most
    // every 10 min), and whenever the app comes back to the screen
    void prefetchReels(api);
    const id = setInterval(() => { void prefetchReels(api); }, 2 * 60000);
    const vis = () => { if (document.visibilityState === 'visible') void prefetchReels(api); };
    document.addEventListener('visibilitychange', vis);
    return () => { clearInterval(id); document.removeEventListener('visibilitychange', vis); };
  }, [api, on]);
  return null;
}
