'use client';
/* v167: Daily reel player — the full-screen experience for one showing.
 *  Flow (showing 1): radial wipe in → hello intro (stroke-drawn greeting + name + quote) → "Yesterday you earned" (agents who
 *  earned) → the reel → "Let's go" → end card (line of the day, streak, "I'm ready", auto-continue 4 s) → wipe out.
 *  Showings 2+: short intro (1.5 s) → the reel with "Skip & open chats" → wipe out straight to the app.
 *  No controls on the video (no pause / mute / close). If the WebView blocks sound, it plays muted with a small
 *  "Tap for sound" hint; a tap anywhere unlocks the sound (not a mute control). Completion is recorded only on `ended` with
 *  ≥ 90% really watched. Styles: A Ambient, B Cinema, C Story, D Widescreen; tones dark / light / dim.
 *  v168: video + song from frame 0 under an even full-screen blur ("veil") that carries the intro text; text and blur clear
 *  together; quotes cycle during playback with positive chips around the video; the end card overlaps the last ~2.5 s
 *  while the song fades out; no silent end. */
import './reel.css';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { layout, canWrite, greeting, partOfDay } from './hello';
import { posterUrl } from './cache';
import { markNativeBad } from './native-reel';

export type ReelNext = {
  show: true; day: string; showing: number; of: number; resume: boolean; skip: boolean; must_finish: boolean; style: string; // A–D play here; E–T and U–AD play in TemplatePlayer
  reel: { id: number; day: string; title: string; title_is_quote: boolean; line: string | null; duration: number; theme: 'dark' | 'light'; file: string; poster: string | null; mime: string; size: number; sha256: string | null; width: number | null; height: number | null };
  quote: string; quotes?: string[]; q_at?: number; // v168: quotes[] from the person's rotation (see reel.ts takeQuotes)
  yesterday: { earned: number; sales: number; weekday: string; label?: string; kind?: 'sales' } | null; streak_prev: number; chips: { today_sales?: number; wallet?: number } | null; name: string;
};
type Props = { api: string; data: ReelNext; src: string; onSrcFail?: () => void; onExit: (r: { splash: boolean }) => void; post: (path: string, body: Record<string, unknown>) => Promise<any>; testSpeed?: number };

const LOGO = '/reel/logo.png';
const mmss = (s: number) => { s = Math.max(0, Math.ceil(s - 1e-6)); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; };
const usd = (n: number) => '$' + (Math.round(n * 100) % 100 ? n.toFixed(2) : String(Math.round(n)));
const sizeCls = (t: string, a: number, b: number) => (t.length > b ? 's3' : t.length > a ? 's2' : '');
const Arrow = ({ s = 14 }: { s?: number }) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden><path d="M5 12h14M13 6l6 6-6 6" /></svg>;
const Chev = () => <svg width="14" height="14" viewBox="0 0 14 14" aria-hidden><path d="M5 2.5 9.5 7 5 11.5" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" /></svg>;
const Logo = ({ s }: { s: number }) => <img src={LOGO} alt="" width={s} height={s} className="rl-logo" style={{ width: s, height: s }} />; // eslint-disable-line @next/next/no-img-element
const RotateIc = () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden><rect x="3" y="9" width="15" height="11" rx="2" /><path d="M14 3.5a7 7 0 0 1 6.5 6.5" /><path d="m18.3 8.2 2.2 1.9 1.9-2.2" /></svg>;

/* ---------- colour picking from a 64 x 36 frame (styles B and C) ---------- */
type RGB = [number, number, number];
function rgb2hsl([r, g, b]: RGB): [number, number, number] {
  r /= 255; g /= 255; b /= 255;
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2;
  if (mx === mn) return [0, 0, l];
  const d = mx - mn, s = l > .5 ? d / (2 - mx - mn) : d / (mx + mn);
  const h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
  return [h * 60, s, l];
}
const hsl = (h: number, s: number, l: number) => `hsl(${((h % 360) + 360) % 360} ${Math.round(s * 100)}% ${Math.round(l * 100)}%)`;
const clamp = (x: number, a: number, b: number) => Math.max(a, Math.min(b, x));
const mix = (a: RGB, hex: string, t: number) => { const b = [1, 3, 5].map(i => parseInt(hex.slice(i, i + 2), 16)); return `rgb(${a.map((v, i) => Math.round(v + (b[i] - v) * t)).join(',')})`; };
function pickColours(d: Uint8ClampedArray): { vib: RGB; mid: RGB } {
  const px: { c: RGB; sv: number; l: number }[] = [];
  for (let i = 0; i < d.length; i += 4) {
    const c: RGB = [d[i], d[i + 1], d[i + 2]];
    const mx = Math.max(...c) / 255, mn = Math.min(...c) / 255;
    px.push({ c, sv: (mx ? (mx - mn) / mx : 0) * mx, l: .2126 * c[0] + .7152 * c[1] + .0722 * c[2] });
  }
  const avg = (xs: { c: RGB }[]): RGB => { const n = xs.length || 1; return [0, 1, 2].map(k => xs.reduce((a, x) => a + x.c[k], 0) / n) as RGB; };
  const vib = avg([...px].sort((a, b) => b.sv - a.sv).slice(0, 200));
  const byL = [...px].sort((a, b) => a.l - b.l);
  const a = Math.floor(byL.length * 900 / 2304), b = Math.floor(byL.length * 1900 / 2304);
  return { vib, mid: avg(byL.slice(a, b)) };
}

/* ---------- the stroke-drawn script ---------- */
function Script({ text, size, gold, stroke, t0, stagger, dur, className }: { text: string; size: number; gold?: boolean; stroke: number; t0: number; stagger: number; dur: number; className?: string }) {
  const g = useMemo(() => layout(text), [text]);
  const s = size / 1000, pad = 40;
  const id = useMemo(() => 'rlg' + Math.random().toString(36).slice(2, 8), []);
  const n = g.glyphs.length;
  return (
    <svg className={className} width={(g.w + pad * 2) * s} height={(g.asc - g.desc + pad * 2) * s} viewBox={`${-pad} ${-g.asc - pad} ${g.w + pad * 2} ${g.asc - g.desc + pad * 2}`} aria-label={text} role="img">
      {gold && <defs><linearGradient id={id} x1="0" x2="1"><stop offset="0" stopColor="#F3DDAE" /><stop offset=".55" stopColor="#FFF7E8" /><stop offset="1" stopColor="#E6C98F" /></linearGradient></defs>}
      {g.glyphs.map((p, i) => (
        <path key={i} d={p.d} transform={`translate(${p.x} 0)`} pathLength={1} strokeWidth={stroke}
          style={{ ['--d' as string]: `${Math.round(t0 + (stagger >= 0 ? i * stagger : (i / n) * 0.78 * -stagger))}ms`, ['--sd' as string]: `${dur}ms`, ...(gold ? { fill: `url(#${id})`, stroke: `url(#${id})` } : {}) }} />
      ))}
    </svg>
  );
}

/* ---------- timings (ms from mount) ----------
 * v168 (owner): the video and its song play from frame 0. During the intro the WHOLE screen is one even blur of the
 * playing video (the "veil") with the greeting / quote / "Yesterday you earned" on it — no card edge ever shows through.
 * At `clear` the text and the blur go away together (~1.1 s) and the style's layout is there. The end card comes back on
 * the same veil over the last ~2.5 s of the video, the song fades out with it, and the reel closes as the video ends. */
const VEIL_MS = 1100;
function plan(d: ReelNext, speed: number) {
  const k = speed;
  if (d.showing > 1) return { short: true, clear: 1500 * k, yd: false };
  if (d.style === 'A') { const yd = !!d.yesterday; return { short: false, ydAt: 3300 * k, clear: (yd ? 6100 : 3500) * k, yd }; }
  return { short: false, clear: 3500 * k, yd: !!d.yesterday };
}
/** Seconds before the end where "Let's go" comes (the end card follows 0.6 s later) — overlaps the playing video. */
const endLead = (du: number) => clamp(du * 0.1, 3.0, 3.4); // → the end card is readable for ~2.1–2.5 s, then the wipe
const FADE_S = 2.4; // the song fades out over the last 2.4 s (with the end card)

export function ReelPlayer({ api, data, src, onSrcFail, onExit, post, testSpeed = 1 }: Props) {
  // v179: this player only has layouts A–D; any other style (a template that could not play) falls back to A, never a black stage
  const d: ReelNext = /^[A-D]$/.test(String(data.style)) ? data : { ...data, style: 'A' };
  const S = d.style;
  const phoneDark = typeof window !== 'undefined' && !!window.matchMedia?.('(prefers-color-scheme: dark)').matches;
  const tone = d.reel.theme === 'dark' ? 'dark' : phoneDark ? 'dim' : 'light';
  const P = useMemo(() => plan(d, testSpeed), [d, testSpeed]);
  const root = useRef<HTMLDivElement>(null);
  const vid = useRef<HTMLVideoElement>(null);
  const [inOn, setInOn] = useState(false);       // wipe in
  const [maskOff, setMaskOff] = useState(false);
  const [ph, setPh] = useState<'intro' | 'stage' | 'end' | 'card' | 'out'>('intro');
  const phRef = useRef(ph); phRef.current = ph;
  const [leaving, setLeaving] = useState(false);  // A: hello → yesterday (inside the veil)
  const [ydOn, setYdOn] = useState(false);
  const [introGone, setIntroGone] = useState(false); // v168: intro text unmounted once the veil has cleared
  const [lit, setLit] = useState(false);          // stage lights (B/D)
  const [muted, setMuted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [skipOn, setSkipOn] = useState(false);
  const [streakN, setStreakN] = useState(0);
  const [qi, setQi] = useState(0);                // v168: which playback quote is showing
  const [cardLeft, setCardLeft] = useState(2);    // v168: seconds of video left when the end card came (its fill bar)
  const [fit, setFit] = useState({ k: 1, land: false });
  const viewId = useRef<number | null>(null);
  const watched = useRef(0), lastT = useRef(0), endedRef = useRef(false), exitRef = useRef(false), started = useRef(false);
  const clearAt = useRef<number | null>(null), qiRef = useRef(0), wantExit = useRef(false);
  const fills = useRef<HTMLElement[]>([]), times = useRef<{ el: HTMLElement; kind: 'left' | 'el' | 'rem' | 'a' }[]>([]);
  const canv = useRef<HTMLCanvasElement[]>([]);
  const posterImg = useRef<HTMLImageElement | null>(null);
  const reg = (el: HTMLCanvasElement | null) => { if (el && !canv.current.includes(el)) canv.current.push(el); };
  const regFill = (el: HTMLElement | null) => { if (el && !fills.current.includes(el)) fills.current.push(el); };
  const regTime = (kind: 'left' | 'el' | 'rem' | 'a') => (el: HTMLElement | null) => { if (el && !times.current.some(x => x.el === el)) times.current.push({ el, kind }); };
  const dur = d.reel.duration || 1;
  const poster = posterUrl(api, d.reel.poster);
  const first = String(d.name || '').trim();
  const now = new Date();
  const [wkday, dayMonth] = [now.toLocaleDateString('en-GB', { weekday: 'long' }), now.toLocaleDateString('en-GB', { day: 'numeric', month: 'long' })];
  const dayShort = now.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
  const hm = now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
  const greet = greeting(now);
  const title = d.reel.title;
  const wide = !d.reel.width || !d.reel.height || Math.abs(d.reel.width / d.reel.height - 16 / 9) < 0.18; // 16:9-ish → cover, else contain
  const later = d.showing > 1;
  const label = later ? `Reel ${d.showing} of ${d.of} today` : '';

  /* ---------- v168: the quotes of this showing (from the person's rotation on the server) ----------
   * quotes[0] = intro, then the playback ones (a reel without a title shows the first of them as its title, so the
   * cycling slot starts at the next one), then the end card's (showing 1). */
  const Q = useMemo(() => {
    const qs = (d.quotes && d.quotes.length ? d.quotes : [d.quote]).filter(Boolean);
    const endQ = d.showing === 1 && qs.length >= 3 ? qs[qs.length - 1] : null;
    const play = qs.slice(1, endQ ? -1 : undefined);
    let slot = d.reel.title_is_quote ? play.filter(q => q !== title) : play;
    if (!slot.length && d.reel.line) slot = [d.reel.line];
    return { intro: qs[0] || d.quote, slot, end: endQ };
  }, [d, title]);
  const chips = useMemo(() => chipList(d), [d]);

  /* ---------- exit (wipe out) ---------- */
  // the parent's callback may change on every render (the app polls every few seconds) — kept in a ref so timers don't restart
  const onExitRef = useRef(onExit); onExitRef.current = onExit;
  const exit = useCallback((splash: boolean, natural = false) => {
    if (exitRef.current) return;
    exitRef.current = true;
    setPh('out');
    if (!natural) try { vid.current?.pause(); } catch { /* */ } // v168: at the natural end the song keeps fading out under the wipe
    setTimeout(() => onExitRef.current({ splash }), 720 * Math.min(1, testSpeed));
  }, [testSpeed]);

  /** v168: the reel has (nearly) played out → record it and close while the last second and the song fade together. */
  const finishRef = useRef<() => void>(() => {});
  finishRef.current = () => {
    if (endedRef.current) return;
    endedRef.current = true;
    const v = vid.current;
    const full = watched.current >= ((v && v.duration) || dur) * 0.9;
    if (full) void (async () => {
      for (let i = 0; i < 6 && viewId.current === null; i++) await new Promise(r => setTimeout(r, 300)); // start may still be on its way
      for (let i = 0; i < 2; i++) {
        try { const r = await post('done', { view_id: viewId.current, watched: Math.ceil(watched.current * 10) / 10 /* v168: round up so 90.0x% never falls below the server check */ }); if (typeof r?.streak === 'number') setStreakN(r.streak); break; }
        catch { await new Promise(r => setTimeout(r, 600)); }
      }
    })();
    exit(d.showing === 1, true);
  };

  /** v168: the end of the reel, from the video clock: "Let's go" → end card over the last ~2.5 s, the song fading, close
   *  0.3 s before the end. Run by the frame loop AND a 100 ms timer (frames can be starved on a busy phone). */
  const endCheck = useRef<() => void>(() => {});
  endCheck.current = () => {
    const v = vid.current;
    if (!v || !v.duration || endedRef.current || !started.current) return;
    const ct = v.currentTime, du = v.duration, lead = endLead(du), cur = phRef.current;
    if (d.showing === 1 && ct >= du - lead && (cur === 'intro' || cur === 'stage')) { phRef.current = 'end'; setPh('end'); }
    if (d.showing === 1 && ct >= du - lead + 0.6 && phRef.current === 'end') { phRef.current = 'card'; setCardLeft(Math.max(0.5, du - ct)); setStreakN(n => n || d.streak_prev + 1); setPh('card'); }
    if (!v.muted) v.volume = ct > du - FADE_S ? clamp((du - ct) / FADE_S, 0, 1) : 1;
    if (ct >= du - 0.3 || (wantExit.current && watched.current >= du * 0.9)) finishRef.current();
  };
  useEffect(() => { const id = window.setInterval(() => endCheck.current(), 100); return () => clearInterval(id); }, []);

  /* ---------- fit to the screen ---------- */
  useEffect(() => {
    const f = () => { const W = window.innerWidth, H = window.innerHeight; setFit({ k: Math.min(W / 375, H / 812), land: W > H * 1.1 }); };
    f(); window.addEventListener('resize', f);
    return () => window.removeEventListener('resize', f);
  }, []);

  /* ---------- the timeline ---------- */
  useEffect(() => {
    const T: number[] = [];
    const at = (ms: number, f: () => void) => T.push(window.setTimeout(f, ms));
    requestAnimationFrame(() => requestAnimationFrame(() => setInOn(true)));
    at(800, () => setMaskOff(true));
    // A: the hello text leaves first (450 ms), THEN "Yesterday you earned" comes — never on top of each other
    if (!P.short && S === 'A' && P.yd) { at(P.ydAt!, () => setLeaving(true)); at(P.ydAt! + 500 * testSpeed, () => setYdOn(true)); }
    at(P.clear, () => {
      clearAt.current = vid.current?.currentTime ?? P.clear / 1000;
      setLit(true);
      setPh(p => (p === 'intro' ? 'stage' : p));
    });
    at(P.clear + VEIL_MS + 150, () => setIntroGone(true));
    return () => T.forEach(clearTimeout);
  }, [P, S, testSpeed]);

  /* ---------- poster for the copies before the video runs ---------- */
  useEffect(() => { if (!poster) return; const im = new Image(); im.onload = () => { posterImg.current = im; }; im.src = poster; }, [poster]);

  /* ---------- copies (veil / ambient / glow / reflections) + colours + progress + quotes + the end, fed from the video ---------- */
  useEffect(() => {
    let raf = 0, lastDraw = 0, lastPick = 0;
    const pick = document.createElement('canvas'); pick.width = 64; pick.height = 36;
    const pctx = pick.getContext('2d', { willReadFrequently: true });
    const loop = (t: number) => {
      raf = requestAnimationFrame(loop);
      const v = vid.current;
      const srcEl: CanvasImageSource | null = v && v.readyState >= 2 && !v.paused ? v : v && v.readyState >= 2 && v.currentTime > 0 ? v : posterImg.current;
      // progress + times (the video plays from frame 0 now, so this runs in every phase)
      if (v && v.duration) {
        const ct = v.currentTime, du = v.duration || dur;
        const dt = ct - lastT.current;
        if (dt > 0 && dt < 1.5 && !v.paused) watched.current += dt;
        lastT.current = ct;
        const p = Math.min(1, ct / du);
        for (const el of fills.current) { if (el.tagName === 'U') el.style.left = p * 100 + '%'; else el.style.width = p * 100 + '%'; }
        for (const x of times.current) x.el.textContent = x.kind === 'el' ? `${Math.floor(ct / 60)}:${String(Math.floor(ct % 60)).padStart(2, '0')}` : x.kind === 'rem' ? '-' + mmss(du - ct) : mmss(du - ct);
        endCheck.current();
        // the cycling quote: the playback time between the intro and the end card, split evenly (~8–10 s each)
        const n = Q.slot.length, t0 = clearAt.current;
        if (n > 1 && t0 !== null) {
          const tEnd = d.showing === 1 ? du - endLead(du) : du;
          const iv = Math.max(4, (tEnd - t0) / n);
          const i = clamp(Math.floor((ct - t0) / iv), 0, n - 1);
          if (i !== qiRef.current) { qiRef.current = i; setQi(i); }
        }
      }
      if (!srcEl || t - lastDraw < 70) return;
      lastDraw = t;
      // v168: while the veil covers everything (intro / end card) only the veil's own copy is drawn — the glows and
      // reflections underneath are hidden anyway, and skipping them keeps the veil's fades smooth on a busy phone
      const covered = phRef.current === 'intro' || phRef.current === 'card' || phRef.current === 'out';
      for (const c of canv.current) { if (covered && !c.classList.contains('vc')) continue; const ctx = c.getContext('2d'); if (ctx) try { ctx.drawImage(srcEl, 0, 0, c.width, c.height); } catch { /* not ready */ } }
      if ((S === 'B' || S === 'C') && pctx && t - lastPick > 250) {
        lastPick = t;
        try {
          pctx.drawImage(srcEl, 0, 0, 64, 36);
          const { vib, mid } = pickColours(pctx.getImageData(0, 0, 64, 36).data);
          const r = root.current; if (!r) return;
          const L = tone === 'light';
          if (S === 'C') {
            const [hv, sv] = rgb2hsl(vib), [hm2, sm] = rgb2hsl(mid);
            r.style.setProperty('--rl-ca', L ? hsl(hv, Math.max(sv, .5), .84) : hsl(hv, clamp(sv, .5, .75), .36));
            r.style.setProperty('--rl-cb', L ? hsl(hm2, Math.max(sm, .35), .90) : hsl(hm2, clamp(sm, .35, .6), .14));
            r.style.setProperty('--rl-cc', L ? hsl(hv + 25, Math.max(sv, .55), .80) : hsl(hv - 30, .6, .30));
          } else {
            r.style.setProperty('--rl-pool', L ? mix(vib, '#e2c79a', .5) : mix(vib, '#c08a55', .35));
            r.style.setProperty('--rl-rim', L ? mix(vib, '#b8a17c', .5) : mix(vib, '#ffd9a8', .25));
          }
        } catch { /* tainted / not ready */ }
      }
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [S, tone, dur, d, Q]);

  /* ---------- v168: play from frame 0 (with the song); sound blocked → muted + "Tap for sound" ---------- */
  useEffect(() => {
    const v = vid.current;
    if (!v) return;
    const t = window.setTimeout(async () => {
      if (v.readyState < 3) setLoading(true);
      v.muted = false;
      try { await v.play(); }
      catch {
        v.muted = true; setMuted(true);
        try { await v.play(); } catch { setLoading(true); }
      }
    }, 40);
    return () => clearTimeout(t);
  }, []);
  useEffect(() => {
    if (ph !== 'stage' || !d.skip) return;
    const sk = window.setTimeout(() => setSkipOn(true), (S === 'A' ? 2000 : 1000) * testSpeed);
    return () => clearTimeout(sk);
  }, [ph, S, d.skip, testSpeed]);

  /* ---------- video events ---------- */
  useEffect(() => {
    const v = vid.current;
    if (!v) return;
    const onPlaying = () => {
      setLoading(false);
      if (!started.current) {
        started.current = true;
        void post('start', { showing: d.showing, reel_id: d.reel.id, style: S, q_at: d.q_at }).then(r => { viewId.current = r?.view_id ?? null; }).catch(() => {});
      }
    };
    const onWaiting = () => setLoading(true);
    const onEnded = () => finishRef.current(); // normally already closing (0.3 s before the end); a safety net
    // v168: the app's native URL won't play → never use it again on this phone; before it started, the gate swaps in the
    // Cache Storage copy (or opens the app normally)
    const onError = () => {
      const native = !src.startsWith('blob:');
      if (native) markNativeBad();
      if (!started.current) { if (native && onSrcFail) onSrcFail(); else exit(true); }
    };
    v.addEventListener('playing', onPlaying); v.addEventListener('waiting', onWaiting); v.addEventListener('ended', onEnded); v.addEventListener('error', onError);
    return () => { v.removeEventListener('playing', onPlaying); v.removeEventListener('waiting', onWaiting); v.removeEventListener('ended', onEnded); v.removeEventListener('error', onError); };
  }, [d, S, post, exit, src, onSrcFail]);

  /* ---------- app hidden mid-reel: pause + report how far; back → go on ---------- */
  useEffect(() => {
    const vis = () => {
      const v = vid.current;
      if (!v) return;
      if (document.visibilityState === 'hidden') {
        if (!v.paused) v.pause();
        if (viewId.current !== null && !endedRef.current) {
          const body = JSON.stringify({ view_id: viewId.current, pos: Math.round(v.currentTime) });
          try { navigator.sendBeacon?.(`${api}/pos`, new Blob([body], { type: 'application/json' })) || void post('pos', JSON.parse(body)).catch(() => {}); } catch { /* */ }
        }
      } else if (started.current && !endedRef.current && !exitRef.current) void v.play().catch(() => {});
    };
    document.addEventListener('visibilitychange', vis);
    return () => document.removeEventListener('visibilitychange', vis);
  }, [api, post]);

  /* ---------- a push notification tap leaves the reel (the chat opens) ---------- */
  useEffect(() => {
    const f = () => {
      if (started.current && d.showing > 1 && d.skip && viewId.current !== null && !endedRef.current) void post('skip', { view_id: viewId.current, watched: Math.round(watched.current) }).catch(() => {});
      exit(false);
    };
    window.addEventListener('af-push-open', f);
    return () => window.removeEventListener('af-push-open', f);
  }, [d, post, exit]);

  const skip = () => {
    if (viewId.current !== null) void post('skip', { view_id: viewId.current, watched: Math.round(watched.current) }).catch(() => {});
    exit(false);
  };
  // "I'm ready" on the end card: closes as soon as the reel counts as watched (90%), at once when it already does
  const ready = () => { wantExit.current = true; const v = vid.current; if (watched.current >= ((v && v.duration) || dur) * 0.9) finishRef.current(); };
  const unmute = () => { const v = vid.current; if (v) { v.muted = false; void v.play().catch(() => {}); } setMuted(false); };

  /* ---------- pieces ---------- */
  const card = (cls = '') => (
    <div className={`rl-card ${cls} ${ph !== 'intro' ? 'open' : ''}`}>
      {poster && <img className="poster" src={poster} alt="" />}{/* eslint-disable-line @next/next/no-img-element */}
      <video ref={vid} src={src} className={wide ? '' : 'contain'} playsInline preload="auto" disablePictureInPicture controls={false} aria-label={title}
        webkit-playsinline="true" x5-playsinline="true" style={{ pointerEvents: 'none' }} />
      <div className="shim" />
      {S === 'B' && <div className="beam" />}
      {d.showing === 1 && <div className="lg" aria-hidden={ph !== 'end' && ph !== 'card'}><b>Let&rsquo;s go</b><i /></div>}
    </div>
  );
  const skipBtn = (cls: string, text = 'Skip & open chats', icon: 'arrow' | 'chev' | 'circle' = 'chev') => skipOn && d.skip && (
    <div className={cls}><button type="button" onClick={skip} data-reel-skip>{text}{icon === 'circle' ? <span className="c"><Arrow /></span> : icon === 'arrow' ? <Arrow /> : <Chev />}</button></div>
  );
  // v168: the cycling quote (gentle crossfade; all stacked in one grid cell, so the height never jumps)
  const cyc = (cls: string, style?: React.CSSProperties) => Q.slot.length > 0 && <Cycle items={Q.slot} i={qi} className={cls} style={style} />;
  const chipRow = (cls: string, style?: React.CSSProperties) => (
    <div className={`rl-xc ${cls}`} style={style} data-reel-chips>
      {chips.length ? chips.map(c => <span key={c.k} className="x" data-chip={c.k}>{c.ic}{c.t}</span>)
        : <span className="x" data-chip="day"><Spark />{wkday}<i>&middot;</i>{dayMonth}</span>}
    </div>
  );

  // ---- intros (all on the veil)
  const helloA = !later && S === 'A' && (
    <div className={`rl-l rlA-intro ${leaving ? 'rl-leave' : ''}`} data-reel-intro>
      <div className="rl-kick date rl-fade" style={{ ['--d' as string]: `${300 * testSpeed}ms`, ['--t' as string]: '600ms' }}>{wkday}<span className="dot" />{dayMonth}</div>
      <div className="gm rl-hello"><Script text={greet} size={327 / ((layout(greet).w + 80) / 1000)} gold={tone !== 'light'} stroke={9} t0={250 * testSpeed} stagger={-1450 * testSpeed} dur={520 * testSpeed} /></div>
      {first && <div className="name rl-up" style={{ ['--d' as string]: `${1650 * testSpeed}ms` }}>{first}</div>}
      <div className="low rl-up" style={{ ['--d' as string]: `${2050 * testSpeed}ms` }}><div className="hair" /><div className="rl-kick">Your day is starting</div><div className="q">{Q.intro}</div></div>
    </div>
  );
  const ydA = !later && S === 'A' && P.yd && ydOn && d.yesterday && <YesterdayA y={d.yesterday} out={false} speed={testSpeed} />;
  const helloBCD = !later && S !== 'A' && (
    <div className="rl-hello2 rl-hello" data-reel-intro>
      <div className="l1"><Script text={greet + ','} size={S === 'B' ? 60 : 58} stroke={16} t0={400 * testSpeed} stagger={90 * testSpeed} dur={330 * testSpeed} /></div>
      {first && (canWrite(first)
        ? <div className="l2"><Script text={first} size={(S === 'B' ? 60 : 58) * 1.18} stroke={16} t0={(400 + 1100) * testSpeed} stagger={95 * testSpeed} dur={340 * testSpeed} /></div>
        : <div className="l2txt rl-up" style={{ ['--d' as string]: `${1500 * testSpeed}ms` }}>{first}</div>)}
      <div className="q rl-up" style={{ ['--d' as string]: `${1900 * testSpeed}ms` }}>{Q.intro}</div>
      {d.yesterday && <div className="e rl-up" style={{ ['--d' as string]: `${2250 * testSpeed}ms` }}><span>{d.yesterday.label || 'Yesterday you earned'}</span> <CountUp v={d.yesterday.earned} delay={2300 * testSpeed} ms={700 * testSpeed} fmt={usd} /></div>}
    </div>
  );
  const sintro = later && (
    <div className="rl-sintro" style={{ ['--sfont' as string]: S === 'B' ? 'var(--cor)' : S === 'A' ? 'var(--disp)' : 'var(--ins)' }} data-reel-intro>
      <div className="rl-kick rl-fade" style={{ ['--d' as string]: '200ms' }}>{wkday}<span className="dot" />{hm}</div>
      <h2 className="rl-up" style={{ ['--d' as string]: '200ms', ['--t' as string]: '500ms' }}>{greet}{first ? ',' : ''}{first && <><br /><em>{first}</em></>}</h2>
      <p className="rl-up" style={{ ['--d' as string]: '500ms', ['--t' as string]: '500ms' }}>{Q.intro}</p>
    </div>
  );

  const stageOn = ph !== 'intro';
  const T = (ms: number) => ({ ['--d' as string]: `${ms}ms` });
  const veilOn = ph === 'intro' || ph === 'card' || ph === 'out';
  const fitStyle = fit.land && stageOn && ph !== 'card' ? { transform: 'none', left: 0, top: 0, width: '100%', height: '100%' } : { transform: `translate(-50%,-50%) scale(${fit.k})` };

  return (
    <>
      <div className={`rl-scrim ${inOn && ph !== 'out' ? 'on' : ''}`} style={{ ['--rl-scrim' as string]: tone === 'light' ? '.12' : '.45' }} />
      <div ref={root} className={`rl rl${S} ${inOn ? 'in' : ''} ${maskOff && ph !== 'out' ? 'done-in' : ''} ${ph === 'out' ? 'out' : ''} ${loading && stageOn ? 'loading' : ''} ${ph === 'end' || ph === 'card' ? 'ending' : ''} ${lit ? 'lit' : ''} ${fit.land && stageOn && ph !== 'card' ? 'land' : ''}`}
        data-tone={tone} data-style={S} data-phase={ph} data-showing={d.showing} data-reel={d.reel.id} role="dialog" aria-modal="true" aria-label="Daily reel"
        onContextMenu={e => e.preventDefault()}>
        {/* ---------- full-screen backgrounds ---------- */}
        <div className="rl-bleed">
          {S === 'A' && <><canvas ref={reg} className="rl-amb" width={96} height={54} style={{ opacity: stageOn ? 1 : 0, transition: 'opacity 600ms ease' }} /><div className="vign" /></>}
          {S === 'C' && <div className="wash" />}
          {S === 'D' && <><canvas ref={reg} className="rl-amb" width={96} height={54} style={{ opacity: stageOn ? undefined : 0, transition: 'opacity 900ms ease' }} /><div className="ovt ov" /><div className="ovb ov" /></>}
          {S === 'B' && <><div className="room-vig" /></>}
          <div className="rl-grain" />
        </div>

        {/* ---------- the design canvas ---------- */}
        <div className="rl-fit" style={fitStyle}>
          {/* --- A · Ambient --- */}
          {S === 'A' && <div className="rl-l" style={{ opacity: stageOn ? 1 : 0, transform: stageOn ? 'none' : 'scale(1.03)', transition: `opacity ${VEIL_MS}ms cubic-bezier(.33,1,.68,1), transform ${VEIL_MS}ms cubic-bezier(.33,1,.68,1)` }}>
            <div className="brand rl-up" style={T(100)}><Logo s={22} />Daily reel</div>
            <div className="hdr rl-up" style={{ ...T(150), ['--y' as string]: '10px' }}>
              <div className="rl-kick">{later ? `${partOfDay(now)} motivation` : 'Today’s motivation'}<span className="dot" />{dayShort}</div>
              <h1 className={sizeCls(title, 22, 40)} data-reel-title>{title}</h1>
            </div>
            <div className="cardwrap">
              <canvas ref={reg} className="glow" width={96} height={54} />
              <canvas ref={reg} className="reflect" width={160} height={90} />
              {card()}
            </div>
            <div className="below rl-up" style={T(150)}>
              <div className="track"><i ref={regFill} /></div>
              <div className="brow"><span><b className="num" ref={regTime('left')}>{mmss(dur)}</b> left</span><span>{label}</span></div>
            </div>
            {stageOn && <>{cyc('xq')}{chipRow('xcA')}</>}
            {!later && stageOn && <div className="rotate go"><div><RotateIc />Rotate for full screen</div></div>}
            {skipBtn('skip', 'Skip & open chats', 'circle')}
            <div className="mark"><Logo s={18} />AdsBhai</div>
          </div>}

          {/* --- B · Cinema --- */}
          {S === 'B' && <div className="rl-l" style={{ visibility: stageOn ? 'visible' : 'hidden' }}>
            <div className="pool" /><canvas ref={reg} className="spill" width={96} height={54} /><canvas ref={reg} className="floor" width={128} height={72} /><canvas ref={reg} className="refl" width={320} height={180} />
            {card()}
            {stageOn && <>
              <div className="hdr">
                <div className="date rl-up" style={T(350 * testSpeed)}>{wkday} &middot; {dayMonth}</div>
                <div className={`title rl-up ${sizeCls(title, 22, 40)}`} style={{ ...T(450 * testSpeed), ['--t' as string]: '700ms' }} data-reel-title>{title}</div>
                <div className="byline rl-up" style={{ ...T(600 * testSpeed), ['--t' as string]: '700ms' }}><i />{first ? `A daily screening for ${first}` : 'A daily screening'}<i /></div>
              </div>
              <div className="prog rl-up" style={T(800 * testSpeed)}><div className="track"><i ref={regFill} /><u ref={regFill} /></div><div className="times"><span ref={regTime('el')}>0:00</span><span ref={regTime('rem')}>-{mmss(dur)}</span></div></div>
              {Q.slot.length > 0 && <div className="quote rl-up" style={{ ...T(900 * testSpeed), ['--t' as string]: '800ms' }}><span className="qmark" />{cyc('')}</div>}
              <Seats light={tone === 'light'} />
              {chipRow('xcB rl-up', T(1100 * testSpeed))}
              {!d.skip && <div className="foot rl-up" style={T(1150 * testSpeed)}><span>AdsBhai &middot; Daily screening</span></div>}
              {skipBtn('skip rl-up')}
            </>}
          </div>}

          {/* --- C · Story --- */}
          {S === 'C' && <div className="rl-l">
            <canvas ref={reg} className="amb2" width={96} height={54} style={{ opacity: stageOn ? undefined : 0, transition: 'opacity 900ms ease' }} />
            <div className="bars rl-fade" style={T(100)}>
              <span><i style={stageOn ? { width: '100%' } : { animation: `rl-segfill ${P.clear}ms linear forwards` }} /></span>
              <span><i ref={regFill} /></span>
              <span><i style={{ width: ph === 'card' ? '100%' : '0%', transition: `width ${Math.round(cardLeft * 1000)}ms linear` }} /></span>
            </div>
            {card()}
            {stageOn && <>
              <div className="head rl-up" style={{ ...T(50), ['--t' as string]: '550ms' }}>
                <Logo s={30} /><span className="who">AdsBhai Daily</span><span className="when">{dayShort}</span>
                <span className="rt">{d.skip ? (skipOn ? <button type="button" onClick={skip} data-reel-skip>Skip &amp; open chats<Chev /></button> : null) : <span ref={regTime('a')}>{mmss(dur)}</span>}</span>
              </div>
              <div className="card open">
                <div className="rl-grain" />
                <div className="eyebrow rl-up" style={T(350)}>Today&rsquo;s reel<span className="dot" />{first ? `For ${first}` : dayShort}</div>
                <div className={`title ${sizeCls(title, 16, 30)}`} data-reel-title>{title.split(/\s+/).map((w, i) => <span key={i}><span className="w"><span style={{ ['--d' as string]: `${450 + i * 90}ms` }}>{w}</span></span>{' '}</span>)}</div>
                {Q.slot.length > 0 && <div className={`quote ${Q.slot.some(q => q.length > 40) ? 's2' : ''}`}><span className="rl-up" style={T(800)}>{cyc('')}</span></div>}
                <div className="sofar rl-fade" style={T(1000)}>Your day so far</div>
                <div className="chips">
                  {chips.map((c, i) => <span key={c.k} className="chip" style={T(1100 + i * 100)} data-chip={c.k}>{c.k === 't' ? <span className="live" /> : c.ic}<span className="v">{c.t}</span></span>)}
                  {d.chips?.wallet ? <span className="chip" style={T(1100 + chips.length * 100)}><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden><rect x="3" y="6" width="18" height="13" rx="2.5" /><path d="M16 12.5h2M3 9.5h18" /></svg><span className="l">Wallet</span><span className="v">{usd(d.chips.wallet)}</span></span> : null}
                  {!chips.length && !d.chips?.wallet && <span className="chip" style={T(1100)}><Spark /><span className="v">{wkday}</span></span>}
                </div>
                <div className="fnote rl-fade" style={T(1450)}>{d.reel.line || 'Live from your dashboard'}</div>
              </div>
            </>}
          </div>}

          {/* --- D · Widescreen --- */}
          {S === 'D' && <div className="rl-l">
            {stageOn && <div className="prog"><i ref={regFill} /></div>}
            <canvas ref={reg} className="refl" width={320} height={180} />
            {card()}
            {stageOn && <>
              {!later && <RotD speed={testSpeed} />}
              {chipRow('xcD rl-up', { ...T(700), ['--t' as string]: '700ms' })}
              <div className="cap">
                <div className="who rl-up" style={{ ...T(450), ['--t' as string]: '700ms' }}><Logo s={28} /><b>AdsBhai</b><span>&middot; Today&rsquo;s reel &middot; {dayShort}</span></div>
                <div className={`ttl rl-up ${sizeCls(title, 22, 38)}`} style={{ ...T(550), ['--t' as string]: '800ms' }} data-reel-title>{title}</div>
                {Q.slot.length > 0 && <div className="qt rl-up" style={{ ...T(700), ['--t' as string]: '800ms' }}>{cyc('')}</div>}
                <div className="brow rl-up" style={{ ...T(850), ['--t' as string]: '700ms' }}>
                  <span className="meter" aria-hidden><i /><i /><i /><i /></span><span className="t">{d.skip ? 'Original audio' : first ? `Original audio · For ${first}` : 'Original audio'}</span>
                  {skipOn && d.skip && <button type="button" onClick={skip} data-reel-skip>Skip &amp; open chats<Chev /></button>}
                </div>
              </div>
            </>}
          </div>}

          {d.resume && stageOn && ph === 'stage' && (
            <div className="rl-toast" data-reel-resume><div className="ic"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden><path d="M3 12a9 9 0 1 0 3-6.7" /><path d="M3 4v5h5" /></svg></div>
              <div><b>Finish today&rsquo;s reel to continue</b><span>Starting again from the top. Just <span className="num">{mmss(dur)}</span>.</span></div></div>
          )}
        </div>

        {/* ---------- v168: the veil — one even full-screen blur of the playing video, under the intro and the end card ---------- */}
        <div className={`rl-veil ${veilOn ? '' : 'off'} ${ph === 'card' ? 'back' : ''}`} data-reel-veil={veilOn ? 'on' : 'off'} aria-hidden={!veilOn && introGone}>
          <canvas ref={reg} className="vc" width={54} height={96} />
          <div className="dim" />
          <div className="rl-fit" style={{ transform: `translate(-50%,-50%) scale(${fit.k})` }}>
            {!introGone && <>{helloA}{helloBCD}{sintro}{ydA}</>}
            {ph === 'card' && <EndCard d={d} line={d.reel.line || Q.end || Q.intro} streak={streakN} left={cardLeft} onReady={ready} />}
          </div>
        </div>

        {/* landscape: the title and the progress over the full-height video */}
        {fit.land && stageOn && ph !== 'card' && <div className="rl-landv" style={{ zIndex: 3, pointerEvents: 'none' }}>
          <div className="sh" /><div className="tt"><div className="rl-kick">Today&rsquo;s motivation<span className="dot" />{dayShort}</div><b>{title}</b></div>
          <div className="pb"><i ref={regFill} /></div>
          {skipOn && d.skip && <div className="sk" style={{ pointerEvents: 'auto' }}><button type="button" onClick={skip} data-reel-skip>Skip &amp; open chats</button></div>}
        </div>}

        {muted && <><div className="rl-sound" data-reel-tapsound><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden><path d="M11 5 6 9H3v6h3l5 4z" /><path d="M15.5 8.5a5 5 0 0 1 0 7" /></svg>Tap for sound</div>
          <div className="rl-tapcatch" onClick={unmute} onTouchEnd={unmute} /></>}
      </div>
    </>
  );
}

/* ---------- v168: playback extras ---------- */
function Cycle({ items, i, className, style }: { items: string[]; i: number; className?: string; style?: React.CSSProperties }) {
  return <span className={`rl-cyc ${className || ''}`} style={style} data-reel-quote={i}>{items.map((q, k) => <span key={k} className={k === i ? 'on' : ''} aria-hidden={k !== i}>{q}</span>)}</span>;
}
const Spark = () => <svg width="12" height="12" viewBox="0 0 24 24" aria-hidden><path d="M12 1c.7 6 5 10.3 11 11-6 .7-10.3 5-11 11-.7-6-5-10.3-11-11 6-.7 10.3-5 11-11Z" fill="currentColor" /></svg>;
const Flame = () => <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor" aria-hidden><path d="M12 2c.6 3.2-1.2 5-2.6 6.6C8 10.2 7 11.7 7 14a5 5 0 0 0 10 0c0-1.6-.6-2.9-1.5-3.9.1 1.3-.5 2.4-1.5 2.6.6-3.6-.6-7.8-2-10.7Z" /></svg>;
const Up = () => <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden><path d="M3 17l6-6 4 4 8-8" /><path d="M15 7h6v6" /></svg>;
/** Small positive chips shown around the video while it plays: yesterday (earned / sales), today's sales, the streak.
 *  Zero or missing values are never shown. */
function chipList(d: ReelNext) {
  const out: { k: string; ic: React.ReactNode; t: React.ReactNode }[] = [];
  const y = d.yesterday;
  if (y && y.earned > 0) out.push({ k: 'y', ic: <Up />, t: <>Yesterday <b className="num">{usd(y.earned)}</b>{y.sales > 0 ? <> &middot; {y.sales} sale{y.sales === 1 ? '' : 's'}</> : null}</> });
  const ts = d.chips?.today_sales || 0;
  if (ts > 0) out.push({ k: 't', ic: <Spark />, t: <>Today <b className="num">{ts} sale{ts === 1 ? '' : 's'}</b></> });
  const st = (d.streak_prev || 0) + 1; // today counts (showing 1 is being watched / was watched for showings 2+)
  if (st >= 2) out.push({ k: 's', ic: <Flame />, t: <><b className="num">{st} days</b> in a row</> });
  return out;
}

/* ---------- pieces ---------- */
function CountUp({ v, delay, ms, fmt }: { v: number; delay: number; ms: number; fmt: (n: number) => string }) {
  const ref = useRef<HTMLElement>(null);
  useEffect(() => {
    let raf = 0; const t0 = performance.now() + delay;
    const f = (t: number) => {
      const p = Math.max(0, Math.min(1, (t - t0) / ms));
      const e = p >= 1 ? 1 : 1 - Math.pow(2, -10 * p);
      if (ref.current) ref.current.textContent = fmt(Math.round(v * e * 100) / 100);
      if (p < 1) raf = requestAnimationFrame(f);
    };
    raf = requestAnimationFrame(f);
    return () => cancelAnimationFrame(raf);
  }, [v, delay, ms, fmt]);
  return <b ref={ref} className="num">{fmt(0)}</b>;
}

function YesterdayA({ y, out, speed }: { y: { earned: number; sales: number; weekday: string; label?: string }; out: boolean; speed: number }) {
  const num = useRef<HTMLDivElement>(null);
  const [burst, setBurst] = useState(false);
  useEffect(() => {
    let raf = 0; const t0 = performance.now() + 300 * speed, ms = 1200 * speed;
    const f = (t: number) => {
      const p = Math.max(0, Math.min(1, (t - t0) / ms));
      const e = 1 - Math.pow(1 - p, 5), val = y.earned * e;
      if (num.current) num.current.innerHTML = `$${Math.floor(val)}<small>.${String(Math.floor(Math.round(val * 100) % 100)).padStart(2, '0')}</small>`;
      if (p < 1) raf = requestAnimationFrame(f); else setBurst(true);
    };
    raf = requestAnimationFrame(f);
    return () => cancelAnimationFrame(raf);
  }, [y.earned, speed]);
  const spk = useMemo(() => Array.from({ length: 14 }, (_, i) => { const a = i / 14 * Math.PI * 2 + (i % 2 ? .18 : -.1), r = 95 + ((i * 37) % 60); return { dx: Math.cos(a) * r * 1.35, dy: Math.sin(a) * r * .85, s: .55 + ((i * 53) % 50) / 70, w: i % 3 ? '#F3DDAE' : '#fff' }; }), []);
  return (
    <div className="rl-l rlA-yd" style={{ animation: out ? 'rl-out-up 450ms cubic-bezier(.65,0,.35,1) forwards' : undefined }} data-reel-yesterday>
      <div className={`glow ${burst ? 'burst' : ''}`} /><div className={`ring ${burst ? 'burst' : ''}`} />
      {spk.map((p, i) => <svg key={i} className={`spk ${burst ? 'burst' : ''}`} viewBox="0 0 24 24" style={{ ['--dx' as string]: `${p.dx}px`, ['--dy' as string]: `${p.dy}px`, ['--s' as string]: p.s }} aria-hidden><path d="M12 0c.6 6.5 5.5 11.4 12 12-6.5.6-11.4 5.5-12 12-.6-6.5-5.5-11.4-12-12C6.5 11.4 11.4 6.5 12 0Z" fill={p.w} /></svg>)}
      <div className="rl-kick k rl-fade" style={{ ['--t' as string]: '450ms' }}>{y.label || 'Yesterday you earned'}</div>
      <div ref={num} className={`v num rl-up ${burst ? 'bump' : ''}`} style={{ ['--t' as string]: '450ms' }}>$0<small>.00</small></div>
      {burst && <div className="chip rl-up" style={{ ['--t' as string]: '500ms' }}><div><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#E6C98F" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden><path d="M3 17l6-6 4 4 8-8" /><path d="M15 7h6v6" /></svg>{y.sales > 0 && <><span className="num">{y.sales} sale{y.sales === 1 ? '' : 's'}</span><span style={{ opacity: .45 }}>&middot;</span></>}<span>{y.weekday}</span></div></div>}
      {burst && <div className="line rl-up" style={{ ['--d' as string]: '300ms', ['--t' as string]: '550ms' }}><b>That&rsquo;s how it&rsquo;s done.</b><span>Let&rsquo;s beat it today.</span></div>}
    </div>
  );
}

function Seats({ light }: { light: boolean }) {
  const row = (n: number, w: number, h: number, gap: number, y0: number, curve: number) => {
    const tot = n * (w + gap), x0 = (375 - tot) / 2; let body = '', rim = '';
    for (let i = 0; i < n; i++) {
      const x = x0 + i * (w + gap), cx = x + w / 2, y = y0 + curve * Math.pow((cx - 187.5) / 187.5, 2);
      body += `M${x} ${y + h} V${y + h * .22} Q${x} ${y} ${x + w * .3} ${y} H${x + w * .7} Q${x + w} ${y} ${x + w} ${y + h * .22} V${y + h} Z `;
      rim += `M${x + 2} ${y + h * .2} Q${x + 2.2} ${y + 1.4} ${x + w * .26} ${y + 1.4} H${x + w * .74} Q${x + w - 2.2} ${y + 1.4} ${x + w - 2} ${y + h * .2} `;
    }
    return { body, rim };
  };
  const r1 = row(8, 44, 120, 5, 92, -12), r2 = row(6, 60, 110, 6, 140, -16);
  return (
    <svg className="seats rl-up" viewBox="0 0 375 200" preserveAspectRatio="none" style={{ ['--d' as string]: '50ms' }} aria-hidden>
      <defs>
        <linearGradient id="rls-b" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={light ? '#e9e0d0' : '#151416'} /><stop offset=".5" stopColor={light ? '#e2d8c6' : '#09090a'} /></linearGradient>
        <linearGradient id="rls-r" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="375" y2="0"><stop offset="0" style={{ stopColor: 'var(--rl-rim)' }} stopOpacity="0" /><stop offset=".5" style={{ stopColor: 'var(--rl-rim)' }} stopOpacity="1" /><stop offset="1" style={{ stopColor: 'var(--rl-rim)' }} stopOpacity="0" /></linearGradient>
        <linearGradient id="rls-f" x1="0" y1="0" x2="0" y2="1"><stop offset=".5" stopColor={light ? '#e9dfcd' : '#000'} stopOpacity="0" /><stop offset="1" stopColor={light ? '#e4d9c6' : '#000'} stopOpacity={light ? .7 : .9} /></linearGradient>
      </defs>
      {[r1, r2].map((r, i) => <g key={i}><path d={r.body} fill="url(#rls-b)" stroke={light ? 'rgba(120,90,50,.16)' : 'none'} strokeWidth=".7" /><path d={r.rim} fill="none" stroke="url(#rls-r)" strokeWidth={light ? 1 : 1.3} strokeLinecap="round" opacity={light ? .6 : .8} /></g>)}
      <rect x="0" y="0" width="375" height="200" fill="url(#rls-f)" />
    </svg>
  );
}

function RotD({ speed }: { speed: number }) {
  const [small, setSmall] = useState(false);
  useEffect(() => { const t = setTimeout(() => setSmall(true), 5200 * speed); return () => clearTimeout(t); }, [speed]);
  return <div className={`rot rl-up ${small ? 'small' : ''}`} style={{ ['--d' as string]: '1000ms' }}><RotateIc /><span>Rotate for full view</span></div>;
}

function EndCard({ d, line: text, streak, left, onReady }: { d: ReelNext; line: string; streak: number; left: number; onReady: () => void }) {
  const line = d.reel.line;
  const parts = useMemo(() => { const s = text.split(/(?<=[.!?])\s+/); return s.length > 1 ? [s.slice(0, -1).join(' '), s[s.length - 1]] : [s[0], '']; }, [text]);
  // this week Mon..Sun; the last `streak` days up to today are lit
  const today = new Date(); const dow = (today.getDay() + 6) % 7;
  const week = ['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((l, i) => ({ l, on: i <= dow && i > dow - streak, today: i === dow }));
  return (
    <div className="rl-end" data-reel-endcard>
      <div className="bgc" />
      <div className="body rl-up" style={{ ['--d' as string]: '100ms' }}>
        <div className="rl-kick">{line ? 'Line of the day' : 'Your day is starting'}</div>
        <div className="lq">{parts[0]}{parts[1] && <><br /><em>{parts[1]}</em></>}</div>
        {streak >= 2 && <>
          <div className="rule" />
          <div className="streak" data-reel-streak={streak}><svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor" aria-hidden><path d="M12 2c.6 3.2-1.2 5-2.6 6.6C8 10.2 7 11.7 7 14a5 5 0 0 0 10 0c0-1.6-.6-2.9-1.5-3.9.1 1.3-.5 2.4-1.5 2.6.6-3.6-.6-7.8-2-10.7Z" /></svg><span className="num">{streak} days in a row</span></div>
          <div className="week">{week.map((x, i) => <div key={i} className={`${x.on ? 'on' : ''} ${x.today ? 'today' : ''}`}><i />{x.l}</div>)}</div>
        </>}
      </div>
      <button type="button" className="ready rl-up" style={{ ['--d' as string]: '250ms' }} onClick={onReady} data-reel-ready><span className="fill" style={{ animationDuration: `${Math.round(left * 1000)}ms`, animationDelay: '0ms' }} /><span>I&rsquo;m ready</span><Arrow s={18} /></button>
      <div className="hint rl-fade" style={{ ['--d' as string]: '600ms' }}>Moves on by itself</div>
    </div>
  );
}
