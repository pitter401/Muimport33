'use client';
// v167: Daily reel downloads — download first, play only a complete, verified local copy (never stream a partial file).
//
//  - While the app is open, today's and tomorrow's reel files for this person are downloaded in the background into
//    Cache Storage ('adflow-reel'), in ~1.5 MB HTTP Range chunks. Each finished chunk is stored right away, so a failure,
//    an app restart or a reload resumes from the last finished chunk.
//  - It never gives up: every failure retries with backoff 2 s, 4 s, 8 s … capped at 60 s, and at once on `online` and when
//    the app comes back to the screen.
//  - One downloader per file: navigator.locks when there is one, else an in-memory flag + a localStorage heartbeat.
//  - When all chunks are there the file is assembled, its size and sha256 (from the server) are checked, and only then is it
//    stored as ready (the chunks are dropped). A wrong checksum throws the chunks away and starts again.
//  - Files (and partial chunks) that are no longer scheduled for today / tomorrow are deleted.
//  - The list is asked for on every fresh open and then at most every 30 minutes (not on every poll). Same-origin fetches
//    carry the login cookie.

import { nativeHas, nativeSrc, nativeQueue, nativeAvailable } from './native-reel';

const CACHE = 'adflow-reel';
const PART = 1536 * 1024;
const PART_MS = 90000; // v168 (reel debug): one 1.5 MB part may take at most 90 s (≈ 140 kbit/s), else abort + retry
const EVERY = 10 * 60000; // v168: the list is refreshed more often (was 30 min)
export type ReelFile = { id: number; file: string; size: number; sha256: string | null; poster?: string | null; mime?: string };

export const mediaUrl = (api: string, file: string) => `${api}/media/${encodeURIComponent(file)}`;
const partKey = (api: string, file: string, off: number) => `${mediaUrl(api, file)}?part=${off}`;
const hasCache = () => typeof window !== 'undefined' && 'caches' in window && window.isSecureContext !== false;
const lsGet = (k: string) => { try { return localStorage.getItem(k); } catch { return null; } };
const lsSet = (k: string, v: string) => { try { localStorage.setItem(k, v); } catch { /* private mode */ } };
const sleep = (ms: number) => new Promise<void>(r => setTimeout(r, ms));

/* v168: the Android app's native downloader (native-reel.ts) is always asked first; Cache Storage is the fallback
 * (browser / PWA / app 1.6 and below). When the native one is in charge, the web never downloads the same file again. */
let nativeInCharge = false;
// v168: settles once the current list call knows whether the native downloader is in charge (so a fresh open never starts
// a web download for a file the app is already fetching natively)
let nativeDecided: Promise<void> | null = null, nativeDecide: (() => void) | null = null;
async function nativeFirst() {
  if (!(await nativeAvailable().catch(() => false))) return false; // browser / old app: a quick no
  if (nativeDecided) await Promise.race([nativeDecided, sleep(2500)]);
  return nativeInCharge;
}
const hasAny = async (api: string, f: ReelFile) => (await nativeHas(f.id, f.sha256)) || (await isReady(api, f.file));

/* ---------- wake-ups: retry at once when the network / the screen comes back ---------- */
let wakers: (() => void)[] = [];
let wired = false;
function wire() {
  if (wired || typeof window === 'undefined') return;
  wired = true;
  const wake = () => { const w = wakers; wakers = []; w.forEach(f => f()); };
  window.addEventListener('online', wake);
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') wake(); });
}
/** Waits `ms`, or less when the network / the app comes back. */
const backoff = (ms: number) => new Promise<void>(r => { const t = setTimeout(done, ms); function done() { clearTimeout(t); wakers = wakers.filter(x => x !== done); r(); } wakers.push(done); });

/* ---------- status (also read by the tests) ---------- */
type St = { state: 'idle' | 'down' | 'ready' | 'retry'; got: number; size: number; tries: number; err?: string };
const status = new Map<string, St>();
const setSt = (file: string, s: Partial<St>) => { const o = { ...(status.get(file) || { state: 'idle', got: 0, size: 0, tries: 0 }), ...s } as St; status.set(file, o); if (typeof window !== 'undefined') (window as unknown as { __afReel?: Record<string, St> }).__afReel = Object.fromEntries(status); };
export const reelStatus = (file: string) => status.get(file);

async function sha256Hex(buf: ArrayBuffer) {
  if (!crypto?.subtle) return null; // very old WebView: size check only
  const h = await crypto.subtle.digest('SHA-256', buf);
  return [...new Uint8Array(h)].map(b => b.toString(16).padStart(2, '0')).join('');
}

/** Is the complete, verified file already here? */
export async function isReady(api: string, file: string) {
  if (!hasCache()) return false;
  try { return !!(await (await caches.open(CACHE)).match(mediaUrl(api, file))); } catch { return false; }
}

/* ---------- one file ---------- */
const running = new Map<string, Promise<boolean>>();

/** Download one file until it is complete (retries for ever while the app is open). Resolves true when ready,
 *  false when it is no longer wanted (deleted on the server / taken off the schedule). Only one per file. */
export function download(api: string, f: ReelFile): Promise<boolean> {
  if (!hasCache()) return Promise.resolve(false);
  const cur = running.get(f.file);
  if (cur) return cur;
  const run = (async () => {
    const locks = (navigator as Navigator & { locks?: { request: (n: string, o: { ifAvailable: boolean }, cb: (l: unknown) => Promise<boolean>) => Promise<boolean> } }).locks;
    if (locks?.request) {
      // another tab / window has it → wait for it to finish (then we find the ready file)
      for (;;) {
        const r = await locks.request('adflow-reel-' + f.file, { ifAvailable: true }, async l => (l ? await fetchAll(api, f) : (null as unknown as boolean)));
        if (r !== null) return r;
        if (await isReady(api, f.file)) return true;
        await backoff(3000);
      }
    }
    // no Web Locks: heartbeat in localStorage (another tab with a fresh heartbeat has it)
    const hb = 'af_reel_dl_' + f.file;
    for (;;) {
      const last = Number(lsGet(hb)) || 0;
      if (Date.now() - last > 15000) break;
      if (await isReady(api, f.file)) return true;
      await backoff(5000);
    }
    return fetchAll(api, f, () => lsSet(hb, String(Date.now())));
  })().finally(() => running.delete(f.file));
  running.set(f.file, run);
  return run;
}

/** v168: tells the server once per reel version that this phone / browser has it complete + verified (silent, best effort;
 *  POST <api>/cached → Admin → Daily reel → report "Ready on phone"). The native app reports its own copies itself. */
function reportCached(api: string, f: ReelFile) {
  if (!f.sha256) return;
  const k = `af_reel_rep_${f.id}_${f.sha256.slice(0, 12)}`;
  if (lsGet(k)) return;
  void (async () => {
    let build = 0;
    try { const { Capacitor } = await import('@capacitor/core'); if (Capacitor.isNativePlatform()) { const { App } = await import('@capacitor/app'); build = Number((await Promise.race([App.getInfo(), sleep(2000).then(() => ({ build: '0' }))])).build) || 0; } } catch { /* browser */ }
    const r = await fetch(`${api}/cached`, { method: 'POST', credentials: 'same-origin', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ reel_id: f.id, sha256: f.sha256, via: 'web', app_build: build }) }).catch(() => null);
    if (r?.ok) lsSet(k, String(Date.now()));
  })();
}

async function fetchAll(api: string, f: ReelFile, beat?: () => void): Promise<boolean> {
  wire();
  const c = await caches.open(CACHE);
  const url = mediaUrl(api, f.file);
  if (await c.match(url)) {
    // v168 (reel debug): a part that a page put just before it was reloaded can land after the file was finished → drop it
    for (const k of await c.keys()) if (k.url.includes(`/media/${encodeURIComponent(f.file)}?part=`)) await c.delete(k);
    setSt(f.file, { state: 'ready', got: f.size, size: f.size }); reportCached(api, f); return true;
  }
  let wait = 2000, tries = 0;
  for (;;) {
    try {
      // which parts are already stored (from an earlier open / before a failure)
      const have = new Set((await c.keys()).map(r => r.url).filter(u => u.includes(`/media/${encodeURIComponent(f.file)}?part=`)).map(u => Number(new URL(u).searchParams.get('part'))));
      let got = [...have].reduce((a, off) => a + Math.min(PART, f.size - off), 0);
      setSt(f.file, { state: 'down', got, size: f.size, tries });
      let whole: Blob | null = null; // v168 (reel debug): a proxy / CDN that ignores Range answered with the whole file (200)
      for (let off = 0; off < f.size; off += PART) {
        if (have.has(off)) continue;
        beat?.();
        const end = Math.min(f.size, off + PART) - 1;
        // v168 (reel debug): each part has a time limit — a stalled phone connection retries instead of hanging the download for ever
        const ac = new AbortController(); const tm = setTimeout(() => ac.abort(), PART_MS);
        let buf: ArrayBuffer;
        try {
          const r = await fetch(url, { credentials: 'same-origin', cache: 'no-store', headers: { Range: `bytes=${off}-${end}` }, signal: ac.signal });
          if (r.status === 404 || r.status === 401 || r.status === 403) { void r.body?.cancel().catch(() => {}); setSt(f.file, { state: 'idle', err: 'gone ' + r.status }); return false; }
          if (r.status === 200) { // Range ignored → this one answer is the complete file (was: thrown away + retried for ever)
            const all = await r.arrayBuffer();
            if (all.byteLength !== f.size) throw new Error('HTTP 200, ' + all.byteLength + ' bytes');
            whole = new Blob([all], { type: f.mime || 'video/mp4' }); got = f.size; setSt(f.file, { state: 'down', got });
            break;
          }
          const cr = r.headers.get('content-range') || '';
          if (r.status !== 206 || (cr && !cr.startsWith(`bytes ${off}-`))) { void r.body?.cancel().catch(() => {}); throw new Error('HTTP ' + r.status + ' ' + cr); }
          buf = await r.arrayBuffer();
        } finally { clearTimeout(tm); }
        if (buf.byteLength !== end - off + 1) throw new Error('short part');
        await c.put(partKey(api, f.file, off), new Response(buf, { headers: { 'content-type': 'application/octet-stream' } }));
        got += buf.byteLength; wait = 2000;
        setSt(f.file, { state: 'down', got });
      }
      // all parts → one file, checked
      let blob = whole;
      if (!blob) {
        const parts: Blob[] = [];
        for (let off = 0; off < f.size; off += PART) {
          const p = await c.match(partKey(api, f.file, off));
          if (!p) throw new Error('part missing');
          parts.push(await p.blob());
        }
        blob = new Blob(parts, { type: f.mime || 'video/mp4' });
      }
      const sum = f.sha256 ? await sha256Hex(await blob.arrayBuffer()) : null;
      if (blob.size !== f.size || (f.sha256 && sum !== null && sum !== f.sha256)) {
        // damaged → throw the parts away and start again
        for (let off = 0; off < f.size; off += PART) await c.delete(partKey(api, f.file, off));
        throw new Error('checksum mismatch');
      }
      await c.put(url, new Response(blob, { headers: { 'content-type': f.mime || 'video/mp4', 'content-length': String(f.size) } }));
      for (let off = 0; off < f.size; off += PART) await c.delete(partKey(api, f.file, off));
      setSt(f.file, { state: 'ready', got: f.size, err: undefined });
      reportCached(api, f); // v168: Admin → report "Ready on phone"
      return true;
    } catch (e) {
      tries++;
      setSt(f.file, { state: 'retry', tries, err: (e as Error).message });
      await backoff(wait);
      wait = Math.min(60000, wait * 2);
    }
  }
}

/* ---------- the list: what this person may see today / tomorrow ---------- */
let listing: Promise<void> | null = null;
let lastFiles: ReelFile[] = [];

/** Ask the server which files to keep, delete old ones, and download the rest (today's first). `force` = fresh open. */
export function prefetchReels(api: string, force = false): Promise<void> {
  if (!hasCache()) return Promise.resolve();
  if (listing) return listing;
  const key = 'af_reel_pf' + api;
  if (!force && Date.now() - (Number(lsGet(key)) || 0) < EVERY) return Promise.resolve();
  nativeDecided = new Promise<void>(r => { nativeDecide = r; });
  listing = (async () => {
    wire();
    let wait = 2000;
    let files: ReelFile[] | null = null;
    while (!files) {
      try {
        const r = await fetch(`${api}/prefetch`, { credentials: 'same-origin', cache: 'no-store' });
        if (r.status === 401 || r.status === 403) return;
        if (!r.ok) throw new Error('HTTP ' + r.status);
        files = ((await r.json()).files || []) as ReelFile[];
      } catch { await backoff(wait); wait = Math.min(60000, wait * 2); }
    }
    lastFiles = files;
    lsSet(key, String(Date.now()));
    nativeInCharge = await nativeQueue(api, files).catch(() => false); // v168: the app downloads them natively (also while closed)
    nativeDecide?.();
    const c = await caches.open(CACHE);
    const want = new Set<string>();
    for (const f of files) { want.add(f.file); if (f.poster) want.add(f.poster); }
    // anything of this app that is not scheduled any more (complete files and partial chunks) goes
    for (const req of await c.keys()) {
      const u = new URL(req.url);
      const pre = `${api}/media/`;
      if (!u.pathname.startsWith(pre)) continue;
      const name = decodeURIComponent(u.pathname.slice(pre.length));
      if (!want.has(name)) await c.delete(req);
    }
    // posters (tiny) — best effort
    for (const f of files) if (f.poster && !(await c.match(mediaUrl(api, f.poster)))) {
      try { const r = await fetch(mediaUrl(api, f.poster), { credentials: 'same-origin', cache: 'no-store' }); if (r.ok && r.status === 200) await c.put(mediaUrl(api, f.poster), r); } catch { /* next time */ }
    }
    // videos one after the other (never two at once from this app), in the background
    if (!nativeInCharge) void (async () => { for (const f of files!) if (!(await nativeHas(f.id, f.sha256))) await download(api, f); })();
  })().finally(() => { listing = null; nativeDecide?.(); });
  return listing;
}

/** Waits up to `ms` for this file to be complete (starting its download if needed). */
export async function whenReady(api: string, f: ReelFile, ms: number) {
  if (await hasAny(api, f)) return true; // v168: native cache first
  if (await nativeFirst()) return Promise.race([(async () => { for (;;) { await sleep(500); if (await hasAny(api, f)) return true; } })(), sleep(ms).then(() => false)]);
  const d = download(api, f);
  return Promise.race([d, sleep(ms).then(() => false)]);
}

/** The complete local copy as an object URL, or null (never a partial / streamed file). */
export async function readySrc(api: string, file: string, f?: Pick<ReelFile, 'id' | 'sha256'>): Promise<{ src: string; revoke: () => void } | null> {
  if (f) { const n = await nativeSrc(f); if (n) return n; } // v168: the native copy first
  if (!hasCache()) return null;
  try {
    const hit = await (await caches.open(CACHE)).match(mediaUrl(api, file));
    if (!hit) return null;
    const blob = await hit.blob();
    if (!blob.size) return null;
    const o = URL.createObjectURL(blob);
    return { src: o, revoke: () => URL.revokeObjectURL(o) };
  } catch { return null; }
}
export const posterUrl = (api: string, poster: string | null | undefined) => (poster ? mediaUrl(api, poster) : '');
export const knownFiles = () => lastFiles;

/** v168: waits (silently) for a file that is downloading right now, but only while it is going fast enough to finish
 *  within `ms` in total. Gives up early when it is clearly too slow or stalls. Resolves true when it is ready. */
export async function whenReadySoon(api: string, f: ReelFile, ms: number, isOn: () => boolean = () => true): Promise<boolean> {
  if (await hasAny(api, f)) return true;
  const t0 = Date.now();
  let done = false;
  if (await nativeFirst()) { // the app's own downloader: no progress numbers → just its normal short wait
    for (;;) { await sleep(500); if (await hasAny(api, f)) return true; if (!isOn() || Date.now() - t0 >= Math.min(ms, 6000)) return false; }
  }
  void download(api, f).then(r => { done = r; });
  // v168 (reel debug): the speed is measured BETWEEN finished parts (was: bytes / time since we began). `got` only grows in
  // whole 1.5 MB parts and the first part also carries the request start-up, so the old estimate was ~20–40 % too slow and
  // gave up at ~3 s on a 12 Mbit/s line that finishes 22.9 MB in ~18 s (reproduced) → the hello screen vanished, no reel.
  let g0 = -1, lastGot = -1, lastMove = t0, g1 = -1, t1 = 0;
  for (;;) {
    await sleep(300);
    if (done) return true;
    if (!isOn()) return false;
    const now = Date.now(), el = now - t0, s = status.get(f.file);
    if (el >= ms) return false;
    const got = s?.got || 0, size = s?.size || f.size || 1;
    if (g0 < 0 && s) g0 = got; // what was there already when we began (resumed parts)
    if (got !== lastGot) { if (lastGot >= 0 && got > g0 && g1 < 0) { g1 = got; t1 = now; } lastGot = got; lastMove = now; }
    if (now - lastMove > 4500) return false;                    // stalled
    if (el >= 3000 && g0 >= 0) {
      if (g1 < 0) { if (el >= 4500) return false; continue; }   // no part done yet (a 1.5 MB part not done in 4.5 s → too slow)
      if (lastMove === t1) continue;                            // one part so far: wait for the next to measure the speed
      const rate = (got - g1) / (lastMove - t1);                // bytes per ms, part to part
      if (lastMove + (size - got) / rate - t0 > ms) return false; // won't make it in time
    }
  }
}
