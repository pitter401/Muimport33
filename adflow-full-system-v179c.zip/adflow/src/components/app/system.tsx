'use client';

import { Package } from 'lucide-react';

/* Admin → System: upload the new version zip → update the server; build the Android apps. Output shows live. */
import { useCallback, useEffect, useRef, useState } from 'react';
import clsx from 'clsx';
import { Btn, Field, inputCls, useToast, listTime, Page } from './ui';

type Api = <T = any>(path: string, body?: unknown) => Promise<T>;
type Job = { id: string; kind: 'update' | 'apk'; started: number; file?: string; status: 'running' | 'ok' | 'failed'; code: number | null; ended: number | null };
const KIND = { update: 'Server update', apk: 'Android apps build' };

export function SystemView({ api, back, top }: { api: Api; back?: () => void; top?: React.ReactNode }) {
  const toast = useToast();
  const [jobs, setJobs] = useState<Job[]>([]);
  const [open, setOpen] = useState<string | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [pw, setPw] = useState('');
  const [busy, setBusy] = useState<'' | 'update' | 'apk'>('');
  const load = useCallback(() => api<{ jobs: Job[] }>('sys_jobs').then(r => { setJobs(r.jobs); return r.jobs; }).catch(() => null), [api]);
  useEffect(() => { void load().then(j => { if (j?.[0]) setOpen(o => o || j[0].id); }); }, [load]);
  const running = jobs.find(j => j.status === 'running');

  const update = async () => {
    if (!file) return toast('Choose the zip file first', 'err');
    if (!pw) return toast('Type the admin password', 'err');
    setBusy('update');
    try {
      const fd = new FormData(); fd.append('file', file); fd.append('password', pw);
      const r = await fetch('/api/admin/sys_update', { method: 'POST', body: fd, credentials: 'include' });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(j.error || 'Upload failed');
      toast('Uploaded — update started'); setFile(null); setPw('');
      setOpen(j.job.id); void load();
    } catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(''); }
  };
  const apk = async () => {
    if (!pw) return toast('Type the admin password', 'err');
    setBusy('apk');
    try { const r = await api<{ job: Job }>('sys_apk', { password: pw }); toast('Build started'); setPw(''); setOpen(r.job.id); void load(); }
    catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(''); }
  };

  return (
    <Page title="System" back={back}>
      {top && <div className="mb-4">{top}</div>}
      <section className="mb-4 af-card p-4">
        <h2 className="text-[17px] font-semibold">Update the server</h2>
        <p className="mt-0.5 text-[13px] text-tg-sub">Upload the adflow-full-system-vNN.zip. It unzips, installs, builds and restarts — same as the update command. Your data and .env are never touched.</p>
        <label className={clsx('mt-3 flex cursor-pointer items-center gap-3 rounded-xl border border-dashed border-white/15 px-4 py-4', file && 'border-tg-acc')}>
          <Package size={26} className="text-tg-sub" />
          <span className="min-w-0 flex-1"><span className="block truncate text-[15px]">{file ? file.name : 'Choose zip file'}</span>{file && <span className="text-[12.5px] text-tg-sub">{(file.size / 1024 / 1024).toFixed(1)} MB</span>}</span>
          <input type="file" accept=".zip,application/zip" className="hidden" onChange={e => setFile(e.target.files?.[0] || null)} />
        </label>
      </section>
      <section className="mb-4 af-card p-4">
        <h2 className="text-[17px] font-semibold">Android apps</h2>
        <p className="mt-0.5 text-[13px] text-tg-sub">Builds the Agent + Admin apps with a new version number. Open apps then show the Update popup.</p>
      </section>
      <section className="mb-4 af-card p-4">
        <Field label="Admin password (needed for both)"><input type="password" className={inputCls} value={pw} onChange={e => setPw(e.target.value)} autoComplete="current-password" /></Field>
        <div className="mt-3 flex flex-wrap gap-2">
          <Btn busy={busy === 'update'} disabled={!!running || !file} onClick={() => void update()}>Upload &amp; update server</Btn>
          <Btn kind="ghost" busy={busy === 'apk'} disabled={!!running} onClick={() => void apk()}>Build Android apps</Btn>
        </div>
        {running && <p className="mt-2 text-[13px] text-tg-orange">{KIND[running.kind]} is running — the next one can start when it finishes.</p>}
      </section>
      <Watchdog api={api} />
      <section className="af-card p-4">
        <h2 className="mb-2 text-[17px] font-semibold">History</h2>
        {!jobs.length && <p className="text-[13px] text-tg-sub">Nothing yet.</p>}
        {jobs.map(j => (
          <div key={j.id} className="border-b border-tg-line last:border-0">
            <button onClick={() => setOpen(open === j.id ? null : j.id)} className="flex w-full items-center gap-3 py-2.5 text-left">
              <span className={clsx('grid h-7 w-7 shrink-0 place-items-center rounded-full text-[13px] font-bold', j.status === 'ok' ? 'bg-tg-green/20 text-tg-ok' : j.status === 'failed' ? 'bg-tg-red/20 text-tg-bad' : 'bg-tg-acc/25 text-white')}>{j.status === 'ok' ? '✓' : j.status === 'failed' ? '✗' : '…'}</span>
              <span className="min-w-0 flex-1"><span className="block text-[15px]">{KIND[j.kind]}{j.file ? ` · ${j.file}` : ''}</span>
                <span className="text-[12.5px] text-tg-sub">{listTime(j.started)}{j.ended ? ` · ${Math.max(1, Math.round((j.ended - j.started) / 60000))} min` : ''} · {j.status === 'running' ? 'Running…' : j.status === 'ok' ? 'Done' : 'Failed'}</span></span>
            </button>
            {open === j.id && <JobLog api={api} id={j.id} onDone={load} />}
          </div>
        ))}
      </section>
    </Page>
  );
}

/** Live output of one job (polls every 2 s; keeps trying while the server restarts during an update). */
function JobLog({ api, id, onDone }: { api: Api; id: string; onDone: () => void }) {
  const [text, setText] = useState('');
  const [st, setSt] = useState<Job['status']>('running');
  const [offline, setOffline] = useState(false);
  const from = useRef(0);
  const box = useRef<HTMLPreElement>(null);
  useEffect(() => {
    let stop = false, t: ReturnType<typeof setTimeout>;
    from.current = 0; setText('');
    const tick = async () => {
      try {
        const r = await api<{ text: string; next: number; job: Job | null }>(`sys_log?id=${id}&from=${from.current}`);
        if (stop) return;
        setOffline(false);
        if (r.text) { setText(x => (x + r.text).slice(-300_000)); from.current = r.next; }
        const s = r.job?.status || 'failed';
        setSt(s);
        if (s !== 'running') { onDone(); return; }
      } catch { setOffline(true); } // the server is restarting
      t = setTimeout(tick, 2000);
    };
    void tick();
    return () => { stop = true; clearTimeout(t); };
  }, [api, id, onDone]);
  useEffect(() => { const b = box.current; if (b) b.scrollTop = b.scrollHeight; }, [text]);
  const toast = useToast();
  const copy = async (t: string) => {
    try { await navigator.clipboard.writeText(t); toast('Copied — paste it anywhere'); return; } catch { /* older WebView */ }
    const ta = document.createElement('textarea');
    ta.value = t; ta.setAttribute('readonly', ''); ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); toast('Copied — paste it anywhere'); } catch { toast('Could not copy — long-press the text to select it', 'err'); }
    ta.remove();
  };
  return (
    <div className="mb-3">
      <pre ref={box} className="max-h-[420px] select-text overflow-auto whitespace-pre-wrap break-all rounded-xl bg-black/50 p-3 font-mono text-[11.5px] leading-relaxed text-[#cfe3d0]">{text || '…'}</pre>
      <p className={clsx('mt-1.5 text-[13px]', st === 'ok' ? 'text-tg-ok' : st === 'failed' ? 'text-tg-bad' : 'text-tg-sub')}>
        {st === 'running' ? (offline ? 'Server is restarting… (this is normal during an update)' : 'Running…') : st === 'ok' ? 'Finished without errors' : 'Failed — see the last lines above'}
      </p>
      {!!text && (
        <div className="mt-2 flex flex-wrap gap-2">
          <button onClick={() => void copy(text.trimEnd().split('\n').slice(-80).join('\n'))} className="rounded-xl bg-tg-input px-3 py-2 text-[13.5px] font-semibold">Copy last 80 lines</button>
          <button onClick={() => void copy(text.trimEnd())} className="rounded-xl bg-tg-input px-3 py-2 text-[13.5px] font-semibold">Copy full output</button>
        </div>
      )}
    </div>
  );
}

type WdEvent = { at: number; kind: 'restarted' | 'restart_failed' | 'gave_up'; why?: string; report?: string };
const WD_TEXT = { restarted: 'Website was stuck → restarted, working again', restart_failed: 'Restarted, but it still did not answer', gave_up: 'Stuck again — already restarted 3× this hour, left as is' };
/** The watchdog restarts the website when it stops answering (2 failed checks a minute apart). Each time it saves a report. */
function Watchdog({ api }: { api: Api }) {
  const [ev, setEv] = useState<WdEvent[] | null>(null);
  const [rep, setRep] = useState<{ name: string; text: string } | null>(null);
  useEffect(() => { api<{ events: WdEvent[] }>('sys_watchdog').then(r => setEv(r.events)).catch(() => setEv([])); }, [api]);
  const open = async (name: string) => {
    if (rep?.name === name) return setRep(null);
    try { const r = await api<{ report: string }>(`sys_watchdog?report=${encodeURIComponent(name)}`); setRep({ name, text: r.report }); } catch (e) { setRep({ name, text: (e as Error).message }); }
  };
  return (
    <section className="mb-4 af-card p-4">
      <h2 className="text-[17px] font-semibold">Watchdog</h2>
      <p className="mt-0.5 text-[13px] text-tg-sub">Checks the website every minute. If it does not answer twice in a row, it restarts it and notifies you. Never during an update or an apps build.</p>
      {ev === null ? <p className="mt-2 text-[13px] text-tg-sub">Loading…</p> : !ev.length ? <p className="mt-2 text-[13px] text-tg-ok">No problems so far.</p> : (
        <div className="mt-2">
          {ev.map(e => (
            <div key={e.at} className="border-b border-tg-line py-2 last:border-0">
              <div className="flex items-start gap-3">
                <span className={clsx('mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full text-[12px] font-bold', e.kind === 'restarted' ? 'bg-tg-orange/20 text-tg-orange' : 'bg-tg-red/20 text-tg-bad')}>!</span>
                <span className="min-w-0 flex-1"><span className="block text-[14.5px]">{WD_TEXT[e.kind] || e.kind}</span><span className="text-[12.5px] text-tg-sub">{listTime(e.at)}{e.why ? ` · ${e.why}` : ''}</span></span>
                {e.report && <button onClick={() => void open(e.report!)} className="shrink-0 rounded-lg bg-tg-input px-2.5 py-1 text-[12.5px] font-semibold">{rep?.name === e.report ? 'Hide' : 'Report'}</button>}
              </div>
              {rep && rep.name === e.report && <pre className="mt-2 max-h-[360px] select-text overflow-auto whitespace-pre-wrap break-all rounded-xl bg-black/50 p-3 font-mono text-[11px] leading-relaxed text-[#cfe3d0]">{rep.text}</pre>}
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
