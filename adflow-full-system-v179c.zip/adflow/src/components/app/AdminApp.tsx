'use client';

import { WaSales } from './WaSales';
import { LiveCounter, onResume, setRingOnSilent } from './beepgate';
import { Campaigns, TopCamps } from './Campaigns';
import { OfferImgPreview } from './OfferImgPreview';
import { RingPeople } from './RingPeople';
import { WaChatsSettings } from './WaChatsSettings';
import { SalesHistory } from './SalesHistory';
import { CallActions, CALL_LABEL } from './calls';
import { CashPayouts, PresenceDot, seenLine, payLine } from './TeamTools';
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { Megaphone, Home, MessagesSquare, Users, Trophy, MoreHorizontal, DollarSign, CreditCard, Radar, Download, Settings, LogOut, Sparkles, Server, ShieldCheck, ChevronRight, ChevronLeft, Search, Plus, Reply, Info, ExternalLink, Crown, ChevronDown, Bell, ShoppingBag, Wallet, Repeat2, X, Gift, BellRing, MessageCircle, Power, Bot, Receipt, Trash2, BarChart3, Inbox as InboxIcon, Link2, CircleDollarSign, UserRoundCog, Medal, Zap, Clock, Activity, KeyRound, CheckCircle2, AlarmClock, RotateCw, Circle, CheckCheck } from 'lucide-react';
import { MetaPanel, MetaRequests, ChatAccountSheet } from './meta';
import clsx from 'clsx';
import { WhatSold, SourceTable, daysTxt, makeApi, ToastProvider, useToast, Sheet, Field, inputCls, Btn, Toggle, Avatar, Seg, listTime, usd, useInterval, beep, setBeepSound, RangePick, Page, Stat, ToggleRow, LineChip, EmptyState, Skeleton, ScrollRow, Chips, useBackEntry, useAppear, useBanner, ChanSwitch, TgGlyph, WaGlyph, PageBackLabel, Group, Row, SectionHead, IconTile, TILE, Tag, Badge, Spark, InfoTip, DropPill, LivePill, SplitBar, money } from './ui';
import { ChatScreen, ChatActionBar, leadName, remindLabel, PremiumChip, CampChip, StatusPill, LineBadge, RowCamp, waitingC, type LeadFull, type BarAct } from './chat';
import { StatusBarSync } from './statusbar';
import { setupPush, openExternal, setAlarm, watchSound, watchPush, nativeConfig, appSeen } from './native';
import { AppUpdate } from './appupdate';
import { NotifFix } from './notiffix';
import { TasksList, StatusChip } from './tasks';
import { AiAdmin } from './ai';
import { SystemView } from './system';
import { CommentsView } from './comments';
import { SoldSheet, TopupSheet, PayLinkSheet, priceCtxFor, type SalesCtx } from './sales-sheets';
import { Clapperboard } from 'lucide-react';
import { ReelGate, ReelBackground, markPushOpen, earlyReelPrefetch } from './reel/ReelGate'; // v167: Daily reel (the admin sees it when picked)
import { ReelAdmin, ForceUpdateCard } from './reel/ReelAdmin';
import { StatusVideoAdmin } from './reel/StatusVideoAdmin'; // v168: More → Status video
import { Film as FilmIcon } from 'lucide-react';
import { ForceUpdate } from './reel/ForceUpdate'; // v167: forced app update
import { LandingFunnel } from './funnel'; // v168: Home → Landing page funnel
import { useFreshOpen } from './reel/useFreshOpen';

type Api = ReturnType<typeof makeApi>;
type Tab = 'svid' | 'reel' |'comments' | 'compare' | 'camps' | 'saleshist' | 'running' | 'wasales' | 'meta' | 'web' | 'home' | 'chats' | 'inbox' | 'leads' | 'team' | 'more' | 'spend' | 'payouts' | 'capi' | 'export' | 'settings' | 'ai' | 'system';
type Agent = { ring_off?: number; chans?: string; mgr_lines?: string; comm_premium?: number | string | null; comm_funnel?: number | string | null; auto_off_at?: number | null; auto_acct?: number; auto_topup?: number; lines?: string; role?: string; id: number; name: string; username: string; tg_chat_id: string | null; comm_per_sale: number; receive: number; online: number; last_seen: number | null; wallet: any; chats: number };
/** v160: "1 sale" / "2 sales" */
const pS = (n: number, w: string) => `${n} ${w}${n === 1 ? '' : 's'}`;
type Range = string; // 'today' | 'yesterday' | '7d' | '30d' | 'all' | 'd:YYYY-MM-DD[:YYYY-MM-DD]' (v135: chosen date)
type Badges = { unread: number; payouts: number; tasks: number; dels: number; short: number; meta_req: number; last_in: { id: number; lead_id: number; name: string; text: string; at: number } | null };
type InboxF = 'all' | 'tasks' | 'acct' | 'payouts' | 'dels' | 'short';
/** Where a page should open: a chat, a Chats filter, an Inbox chip, a Settings section. */
type GoOpts = { chat?: number | null; agent?: number | string; status?: string; inbox?: InboxF; sec?: string; chan?: 'tg' | 'wa'; pick?: 'unread' };
type Go = (t: Tab, o?: GoOpts) => void;

const PRICE_TAGS = '{price_account} = Telegram price in $, {price_account_inr} = same in INR. Also {price_funnel} {price_funnel_inr}, {topup_min} {topup_min_inr}, {topup_fee}, {delivery}, {brand}. INR uses the "1 USD = ? INR" rate (Payments).';
const Card = Stat; // v136: one number tile everywhere
const usdS = (v: number) => (v < 0 ? '−' + usd(-v) : usd(v)); // v167: true minus −$3, not $-3
const ls = { get: (k: string) => { try { return localStorage.getItem(k); } catch { return null; } }, set: (k: string, v: string) => { try { localStorage.setItem(k, v); } catch { /* private mode */ } } };

export default function AdminApp() { return <ToastProvider><StatusBarSync /><AppUpdate app="admin" /><ForceUpdate app="admin" /><NotifFix app="admin" /><Inner /></ToastProvider>; }

function Inner() {
  const [authed, setAuthed] = useState<boolean | null>(null);
  const api = useMemo(() => makeApi('/api/admin', () => setAuthed(false)), []);
  const [brand, setBrand] = useState('');
  useEffect(() => { api<{ brand: string }>('me').then(r => { setBrand(r.brand); setAuthed(true); }).catch(() => setAuthed(false)); }, [api]);
  useEffect(() => { earlyReelPrefetch('/api/admin/reel/view'); }, []); // v168: reel files start downloading before the login check ends
  if (authed === null) return <div className="grid h-[100dvh] place-items-center bg-tg-bg"><div className="h-10 w-10 animate-spin rounded-full border-2 border-tg-acc border-t-transparent" /></div>;
  if (!authed) return <Login onDone={() => api<{ brand: string }>('me').then(r => { setBrand(r.brand); setAuthed(true); })} />;
  return <Shell api={api} brand={brand} onLogout={async () => { await fetch('/api/admin/logout', { method: 'POST' }); try { localStorage.removeItem('af_admin_t'); } catch { } setAuthed(false); }} />;
}

function Login({ onDone }: { onDone: () => void }) {
  const [u, setU] = useState('admin'); const [p, setP] = useState(''); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setErr(''); setBusy(true);
    try {
      const r = await fetch('/api/admin/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ username: u, password: p }) });
      const j = await r.json(); if (!r.ok) throw new Error(j.error || 'Could not log in');
      try { localStorage.setItem('af_admin_t', j.token); } catch { }
      onDone();
    } catch (e) { setErr((e as Error).message); } finally { setBusy(false); }
  }
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-tg-bg px-6 text-tg-text">
      <form onSubmit={submit} className="af-page w-full max-w-[360px]">
        <div className="mx-auto mb-6 grid h-20 w-20 place-items-center rounded-full bg-tg-orange"><ShieldCheck size={36} className="text-white" /></div>
        <h1 className="text-center text-[24px] font-semibold">Admin</h1>
        <p className="mb-7 mt-1.5 text-center text-[14.5px] text-tg-sub">Log in to manage leads, agents and settings.</p>
        <Field label="Username"><input className={inputCls} autoCapitalize="none" value={u} onChange={e => setU(e.target.value)} /></Field>
        <Field label="Password"><input className={inputCls} type="password" autoComplete="current-password" value={p} onChange={e => setP(e.target.value)} /></Field>
        {err && <p role="alert" className="mb-3 text-[14px] text-tg-bad">{err}</p>}
        <Btn type="submit" busy={busy} className="w-full">Log in</Btn>
      </form>
    </div>
  );
}

/* ---------------- v136: navigation — one list for the sidebar and More ---------------- */
type NavItem = [Tab, string, any, string];
const MAIN_NAV: NavItem[] = [['home', 'Home', Home, ''], ['chats', 'Chats', MessageCircle, ''], ['inbox', 'Inbox', InboxIcon, ''], ['team', 'Team', Users, '']];
const NAV_GROUPS: [string, NavItem[]][] = [
  ['Sales', [
    ['leads', 'Leads', Users, 'Everyone who filled the form or messaged, and who to call'],
    ['saleshist', 'Sale history', Receipt, 'Every sale and top-up, and who sold it. Add WhatsApp sales here'],
    ['web', 'Website orders', ShoppingBag, 'Orders and top-ups paid on the website'],
    ['payouts', 'Payouts', CreditCard, 'Agent payout requests'],
  ]],
  ['Ads & reports', [
    ['meta', 'Ad accounts', Wallet, 'Our BMs, accounts, shares, top-ups, credits, cards'],
    ['camps', 'Campaigns', Megaphone, 'Which campaign and ad brings chats and sales'],
    ['spend', 'Ad spend & ROI', DollarSign, 'Daily spend, cost per lead, cost per sale'],
    ['compare', 'Telegram vs WhatsApp', BarChart3, 'What is happening on each app, and which line and app earns the most'],
    ['comments', 'Comments', MessageCircle, 'Facebook + Instagram comments on our ads and Page — delete scam / fake ones'],
    ['capi', 'Meta events', Radar, 'ViewContent, Lead and Purchase log'],
    ['running', "What's running", Power, 'Which ad systems are on. Keeps Home clean'],
    ['export', 'Export', Download, 'Leads and Meta audience files'],
  ]],
  ['Setup', [
    ['ai', 'AI', Sparkles, 'Agent coach, AI replies, Test Lab, voice'],
    ['settings', 'Settings', Settings, 'Landing pages, prices, Telegram, Meta'],
    ['system', 'System', Server, 'Update the server from a zip, build the Android apps, follow-up check'],
    ['reel', 'Daily reel', Clapperboard, 'Short motivation video when agents open the app'], // v167
    ['svid', 'Status video', FilmIcon, 'Your daily sales status video, made automatically at night'], // v168
  ]],
];
/** v167: icon tile colour per More row. */
const NAV_TILE: Partial<Record<Tab, string>> = { leads: TILE.blue, saleshist: TILE.green, web: TILE.orange, payouts: TILE.purple, meta: TILE.indigo, camps: TILE.pink, spend: TILE.teal, compare: TILE.cyan, comments: TILE.orange, capi: TILE.grey, running: TILE.green, export: TILE.brown, ai: TILE.purple, settings: TILE.grey, system: TILE.blue, reel: '#C9A866', svid: '#8B5CF6' };
const PARENT_L: Partial<Record<Tab, string>> = { home: 'Home', chats: 'Chats', inbox: 'Inbox', team: 'Team', more: 'More' };
const MOBILE_TABS: Tab[] = ['home', 'chats', 'inbox', 'team', 'more'];
const MOBILE_NAV: NavItem[] = [...MAIN_NAV, ['more', 'More', MoreHorizontal, '']];
const inboxSum = (b: Badges) => b.tasks + b.meta_req + b.payouts + b.dels + b.short;
const navBadge = (t: Tab, b: Badges) => (t === 'chats' ? b.unread : t === 'inbox' ? inboxSum(b) : t === 'payouts' ? b.payouts : 0);

function Shell({ api, brand, onLogout }: { api: Api; brand: string; onLogout: () => void }) {
  const banner = useBanner();
  const [tab, setTab] = useState<Tab>('home');
  const [badge, setBadge] = useState<Badges>({ unread: 0, payouts: 0, tasks: 0, dels: 0, short: 0, meta_req: 0, last_in: null });
  const [openChat, setOpenChat] = useState<number | null>(null);
  const [opts, setOpts] = useState<GoOpts>({});
  const dir = useRef<'fwd' | 'back'>('fwd');
  const parent = useRef<Tab>('more');
  const stateRef = useRef({ tab, openChat }); stateRef.current = { tab, openChat };
  const go: Go = useCallback((t, o = {}) => {
    dir.current = 'fwd';
    const cur = stateRef.current.tab;
    if (!MOBILE_TABS.includes(t) && MOBILE_TABS.includes(cur)) parent.current = cur === 'home' ? 'more' : cur;
    setOpts(o); setTab(t); setOpenChat(o.chat ?? null); window.scrollTo(0, 0);
  }, []);
  const isSub = !MOBILE_TABS.includes(tab);
  // v167: Daily reel for the admin (only when picked in Daily reel → Who sees it), on a fresh open like the agent app
  const freshKey = useFreshOpen();
  const [reelOn, setReelOn] = useState(true);
  useEffect(() => { if (freshKey > 1) setReelOn(true); }, [freshKey]);
  // v136: Android Back — a More page → its parent, a tab → Home (chats and sheets keep their own entries above these)
  useBackEntry(tab !== 'home', () => { dir.current = 'back'; setTab('home'); setOpenChat(null); window.scrollTo(0, 0); });
  useBackEntry(isSub, () => { dir.current = 'back'; setTab(parent.current); window.scrollTo(0, 0); });
  const back = isSub ? () => history.back() : undefined;
  const lastIn = useRef<number | null>(null);
  // v144: the first badges load and the first one after open / resume set the baseline — never a sound or banner for catch-up
  const unreadLive = useRef(new LiveCounter());
  useEffect(() => onResume(() => { unreadLive.current.reset(); lastIn.current = null; }), []);
  const refreshBadges = useCallback(async () => {
    try {
      const b = await api<Badges>('badges');
      const catchUp = unreadLive.current.rebasing;
      if (unreadLive.current.next(b.unread)) beep();
      setBadge(b);
      // v136: a new customer message (not in the chat that is open) → banner
      const li = b.last_in;
      if (catchUp) lastIn.current = null;
      if (li && lastIn.current !== null && li.id > lastIn.current && !(stateRef.current.tab === 'chats' && stateRef.current.openChat === li.lead_id))
        banner({ key: 'm' + li.id, name: li.name, text: li.text || 'New message', avatarId: li.lead_id, onOpen: () => go('chats', { chat: li.lead_id }) });
      if (li) lastIn.current = Math.max(lastIn.current ?? 0, li.id); else if (lastIn.current === null) lastIn.current = 0;
    } catch { }
  }, [api, banner, go]);
  useEffect(() => { void refreshBadges(); }, [refreshBadges]);
  useInterval(() => void refreshBadges(), 8000);
  useEffect(() => { void api<any>('settings').then(r => { setBeepSound(r.settings?.notif_sound === 'own' && r.settings?.notif_sound_file ? r.settings.notif_sound_ver : ''); setRingOnSilent(r.settings?.alarm_on !== '0' && r.settings?.admin_ring_off !== '1'); /* v144 */ }).catch(() => {}); }, [api]);
  useEffect(() => {
    void setAlarm(true);
    // v139: the phone registers itself (native token + platform, Capacitor as the fallback); failed steps go to push_debug
    const reg = (t: string, platform: string, extra?: { app_version?: string; build?: string }) => api('push_register', { token: t, platform, ...(extra || {}) }); // v143: + app version
    const dbg = (d: Record<string, unknown>) => api('push_debug', d);
    void nativeConfig('/api/admin/', () => api('native_auth', {}));
    void appSeen().then(i => api('push_seen', i)).catch(() => null); // v143: "app opened" (shown apart from "registered")
    void setupPush(reg, d => { if (d.lead_id) { markPushOpen(); setReelOn(false); go('chats', { chat: Number(d.lead_id) }); } }, dbg); // v167: a push tap skips the reel
    return watchPush(reg, dbg);
  }, [api, go]);
  useEffect(() => watchSound('/api/admin/', () => api<{ snd?: string }>('me').then(r => r.snd || '')), [api]); // v137: own sound kept on the phone

  const chatFull = tab === 'chats' && openChat;
  const anim = dir.current === 'back' ? 'af-pop-back' : isSub ? 'af-push' : 'af-page';
  const onOpenChat = (id: number) => go('chats', { chat: id });
  const NavBtn = ({ it }: { it: NavItem }) => {
    const [t, l, I] = it; const n = navBadge(t, badge);
    return (
      <button key={t} onClick={() => go(t)} aria-current={tab === t ? 'page' : undefined} className={clsx('mb-0.5 flex w-full items-center gap-3 rounded-xl px-3 py-2 text-[14.5px]', tab === t ? 'bg-tg-active text-tg-link' : 'text-tg-sub hover:bg-tg-hover hover:text-tg-text')}>
        <I size={18} /><span className="flex-1 text-left">{l}</span>
        {n > 0 && <span key={n} className={clsx('af-pop rounded-full px-1.5 text-[12px] font-semibold', t === 'chats' ? 'bg-tg-acc text-white' : 'bg-tg-orange text-black')}>{n}</span>}
      </button>
    );
  };
  return (
    <div className="af-admin min-h-[100dvh] bg-tg-bg text-tg-text md:flex">
      <aside className="sticky top-0 hidden h-[100dvh] w-[240px] shrink-0 flex-col overflow-y-auto border-r border-tg-line bg-tg-panel md:flex">
        <div className="flex items-center gap-3 px-5 py-5">{/* eslint-disable-next-line @next/next/no-img-element */}<img src={`/brand/logo.png?size=96&v=${encodeURIComponent(brand)}`} alt="" className="h-9 w-9 rounded-xl" /><div><p className="font-semibold">{brand}</p><p className="text-[12px] text-tg-sub">Admin</p></div></div>
        <nav className="flex-1 px-2 pb-2">
          {MAIN_NAV.map(it => <NavBtn key={it[0]} it={it} />)}
          {NAV_GROUPS.map(([g, items]) => (
            <div key={g} className="mt-3">
              <p className="px-3 pb-1 text-[11px] font-semibold uppercase tracking-wide text-tg-sub/80">{g}</p>
              {items.map(it => <NavBtn key={it[0]} it={it} />)}
            </div>
          ))}
        </nav>
        <button onClick={onLogout} className="m-2 flex items-center gap-3 rounded-xl px-3 py-2.5 text-[15px] text-tg-bad hover:bg-tg-hover"><LogOut size={19} />Log out</button>
      </aside>

      <main className={clsx('min-w-0 flex-1', !chatFull && 'pb-[calc(76px+env(safe-area-inset-bottom))] md:pb-0')}>
        <PageBackLabel.Provider value={PARENT_L[parent.current] || 'Back'}>
        <div key={tab} className={anim}>
        {tab === 'home' && <Dashboard api={api} go={go} badge={badge} />}
        {tab === 'chats' && <Chats api={api} open={openChat} setOpen={setOpenChat} onChanged={refreshBadges} go={go} delN={badge.dels} initAgent={opts.agent} initStatus={opts.status} initChan={opts.chan} pick={opts.pick} />}
        {tab === 'inbox' && <Inbox api={api} badge={badge} onOpenChat={onOpenChat} onChanged={refreshBadges} init={opts.inbox} />}
        {tab === 'leads' && <Leads api={api} onOpen={onOpenChat} back={back} />}
        {tab === 'team' && <Team api={api} go={go} />}
        {tab === 'more' && <More go={go} badge={badge} onLogout={onLogout} brand={brand} />}
        {tab === 'web' && <WebOrders api={api} go={go} back={back} />}
        {tab === 'wasales' && <Page title="WhatsApp sales" back={back}><WaSales api={api} /></Page>}
        {tab === 'camps' && <CampsPage api={api} back={back} />}
        {tab === 'compare' && <Compare api={api} back={back} />}
        {tab === 'saleshist' && <SaleHist api={api} onOpenChat={onOpenChat} back={back} />}
        {tab === 'running' && <Running api={api} back={back} />}
        {tab === 'spend' && <Spend api={api} go={go} back={back} />}
        {tab === 'meta' && <Page title="Ad accounts" back={back}><MetaPanel api={api} isAdmin /></Page>}
        {tab === 'payouts' && <Payouts api={api} onChanged={refreshBadges} back={back} />}
        {tab === 'comments' && <CommentsView api={api} back={back} />}
        {tab === 'capi' && <Capi api={api} go={go} back={back} />}
        {tab === 'export' && <Export api={api} back={back} />}
        {tab === 'settings' && <SettingsView api={api} back={back} initialSec={opts.sec} />}
        {tab === 'ai' && <AiAdmin api={api} back={back} />}
        {tab === 'system' && <SystemView api={api} back={back} top={<><FuHealth api={api} /><ForceUpdateCard api={api} /></>} />}
        {tab === 'reel' && <ReelAdmin api={api} back={back} />}
        {tab === 'svid' && <StatusVideoAdmin api={api} back={back} />}
        </div>
        </PageBackLabel.Provider>
      </main>

      {reelOn && <ReelGate key={'reel' + freshKey} api="/api/admin/reel/view" onDone={() => setReelOn(false)} />}
      <ReelBackground api="/api/admin/reel/view" />
      {!chatFull && (
        <nav className="af-tabbar fixed inset-x-0 bottom-0 z-40 flex px-1 pb-[env(safe-area-inset-bottom)] md:hidden" aria-label="Main">
          {MOBILE_NAV.map(([t, l, I]) => {
            const on = tab === t || (t === 'more' && isSub);
            const n = navBadge(t, badge);
            const dot = t === 'more' && badge.payouts > 0;
            return (
              <button key={t} onClick={() => go(t)} aria-current={on ? 'page' : undefined} className={clsx('af-press relative flex flex-1 flex-col items-center gap-[3px] pb-1.5 pt-[7px] text-[10.5px] font-semibold', on ? 'text-tg-link' : 'text-tg-faint')}>
                <I size={25} strokeWidth={on ? 2.1 : 1.8} />{l}
                {n > 0 && <span key={n} className={clsx('af-tbadge af-pop', t === 'chats' && 'blue')}><i className="af-n">{n > 99 ? '99+' : n}</i></span>}
                {dot && <span className="absolute left-1/2 top-1.5 ml-2 h-2.5 w-2.5 rounded-full bg-tg-badge ring-2 ring-tg-panel" />}
              </button>
            );
          })}
        </nav>
      )}
    </div>
  );
}

/* ---------------- More (mobile) — v167: profile card, search, single-line rows with colour tiles ---------------- */
function More({ go, badge, onLogout, brand }: { go: Go; badge: Badges; onLogout: () => void; brand: string }) {
  const [q, setQ] = useState('');
  const ql = q.trim().toLowerCase();
  const host = typeof window !== 'undefined' ? window.location.host : '';
  const groups = NAV_GROUPS.map(([g, items]) => [g, ql ? items.filter(([, l, , d]) => (l + ' ' + d).toLowerCase().includes(ql)) : items] as [string, NavItem[]]).filter(([, it]) => it.length);
  return (
    <Page title="More">
      <div className="af-card mb-3 flex items-center gap-3 px-4 py-3" data-more-profile>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={`/brand/logo.png?size=96&v=${encodeURIComponent(brand)}`} alt="" className="h-12 w-12 shrink-0 rounded-[14px] bg-tg-panel2 object-cover" />
        <span className="min-w-0 flex-1"><span className="block truncate text-[17px] font-semibold">{brand || 'Admin'}</span><span className="block truncate text-[13px] text-tg-sub">Admin{host ? ` · ${host}` : ''}</span></span>
      </div>
      <label className="mb-1 flex h-[38px] items-center gap-2 rounded-xl bg-tg-panel px-3 text-tg-faint shadow-[var(--tg-card-shadow)] dark:bg-tg-panel2">
        <Search size={17} className="shrink-0" />
        <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search pages" className="min-w-0 flex-1 bg-transparent text-[15px] text-tg-text outline-none placeholder:text-tg-faint" aria-label="Search pages" />
        {q && <button onClick={() => setQ('')} aria-label="Clear" className="text-tg-sub"><X size={16} /></button>}
      </label>
      {groups.map(([g, items]) => (
        <section key={g}>
          <SectionHead title={g} />
          <Group tiles>
            {items.map(([t, l, I]) => (
              <Row key={t} data-more={t} onClick={() => go(t)} icon={<IconTile icon={I} color={NAV_TILE[t] || TILE.blue} />} title={l} badge={<Badge n={navBadge(t, badge)} tone="orange" />} />
            ))}
          </Group>
        </section>
      ))}
      {!groups.length && <p className="px-1 py-6 text-center text-[14px] text-tg-sub">No page matches “{q}”. Settings has its own search.</p>}
      <Group className="mt-6"><Row center onClick={onLogout} title={<span className="font-medium text-tg-bad">Log out</span>} /></Group>
    </Page>
  );
}

/* ---------------- v136: Inbox — every queue that waits for the owner ---------------- */
function Inbox({ api, badge, onOpenChat, onChanged, init }: { api: Api; badge: Badges; onOpenChat: (id: number) => void; onChanged: () => void; init?: InboxF }) {
  const [f, setF] = useState<InboxF>(init || 'all');
  const groups: [Exclude<InboxF, 'all'>, string, number][] = [['tasks', 'Tasks', badge.tasks], ['acct', 'Accounts', badge.meta_req], ['payouts', 'Payouts', badge.payouts], ['dels', 'Deletes', badge.dels], ['short', 'Short pays', badge.short]];
  const body = (k: Exclude<InboxF, 'all'>) => k === 'tasks' ? <TasksList api={api} onOpenChat={onOpenChat} />
    : k === 'acct' ? <MetaRequests api={api} changed={onChanged} />
    : k === 'payouts' ? <PayoutList api={api} onChanged={onChanged} mode="pending" />
    : k === 'dels' ? <DelRequests api={api} onOpenChat={onOpenChat} onChanged={onChanged} />
    : <ShortPays api={api} onOpenChat={onOpenChat} />;
  const shown = groups.filter(([, , n]) => n > 0);
  return (
    <Page title="Inbox" below={<Chips value={f} onChange={setF} className="-mx-4 mb-3 px-4 md:mx-0 md:px-0" items={[['all', 'All', inboxSum(badge)], ...groups.filter(([k, , n]) => n > 0 || k === f).map(([k, l, n]) => [k, l, n] as [InboxF, string, number])]} />}>
      <div data-inbox={f}>
        {f !== 'all' ? body(f) : !shown.length ? <div className="pt-[12vh]"><EmptyState icon={<CheckCheck size={26} />} title="All clear" text="Tasks, ad account requests, payouts, delete requests and short pays show up here." /></div>
          : shown.map(([k, l, n]) => (
            <section key={k} className="mb-5">
              <button onClick={() => setF(k)} className="af-h2 !mt-3 w-full text-left"><span>{l}</span><span className="flex items-center gap-1"><Badge n={n} /><ChevronRight size={17} className="text-tg-faint" /></span></button>
              {body(k)}
            </section>
          ))}
      </div>
    </Page>
  );
}

/** v136 (was in Chats): chats the team asked to delete (junk / time-wasters). */
function DelRequests({ api, onOpenChat, onChanged }: { api: Api; onOpenChat: (id: number) => void; onChanged: () => void }) {
  const toast = useToast();
  const [dels, setDels] = useState<any[] | null>(null);
  const load = useCallback(() => api<{ list: any[] }>('del_requests').then(r => setDels(r.list)).catch(() => {}), [api]);
  useEffect(() => { void load(); }, [load]);
  useInterval(() => void load(), 20000);
  async function delChat(r: any) {
    if (!confirm(`Delete the chat with ${r.who} completely? All its messages are removed from the apps. This can't be undone. (Nothing is deleted in Telegram / WhatsApp.)`)) return;
    try { const x = await api<{ moved?: string; why?: string }>('lead_delete', { lead_id: r.id }); toast(x.moved ? `Has ${x.why} — records kept, moved to Dead` : 'Chat deleted'); void load(); onChanged(); } catch (e) { toast((e as Error).message, 'err'); }
  }
  async function keep(r: any) { try { await api('del_keep', { lead_id: r.id }); toast('Kept'); void load(); onChanged(); } catch (e) { toast((e as Error).message, 'err'); } }
  if (!dels) return <Skeleton rows={2} />;
  if (!dels.length) return <EmptyState text="No delete requests." />;
  return (
    <div className="space-y-2.5" data-del-list>
      {dels.map(r => (
        <div key={r.id} className="af-card p-4">
          <div className="flex items-center gap-2"><b className="min-w-0 flex-1 truncate text-[15px]">{r.who}</b><LineChip k={r.ch === 'wa' ? 'wa' : 'tg'} /><span className="text-[12px] text-tg-sub">{listTime(r.del_req_at)}</span></div>
          <p className="mt-1 text-[13.5px]"><span className="text-tg-sub">{r.del_req_by}:</span> {r.del_req_note}</p>
          <div className="mt-3 flex flex-wrap gap-2">
            <Btn kind="ghost" className="!py-2 text-[14px]" onClick={() => onOpenChat(r.id)}>Open chat</Btn>
            <Btn kind="danger" className="!py-2 text-[14px]" onClick={() => void delChat(r)}><Trash2 size={16} />Delete chat</Btn>
            <Btn kind="ghost" className="!py-2 text-[14px]" onClick={() => void keep(r)}>Keep</Btn>
          </div>
        </div>
      ))}
    </div>
  );
}

/** A section you open with a tap (Home). Remembered on this phone. */
function Fold({ id, title, sub, children }: { id: string; title: string; sub?: string; children: React.ReactNode }) {
  const [open, setOpen] = useState(() => ls.get('af_fold_' + id) === '1');
  return (
    <section className="af-group mt-2.5" data-fold={id}>
      <button onClick={() => { setOpen(o => { ls.set('af_fold_' + id, o ? '0' : '1'); return !o; }); }} aria-expanded={open} className="af-row">
        <span className="min-w-0 flex-1"><span className="block truncate text-[15.5px] font-medium">{title}</span>{sub && <span className="mt-px block truncate text-[13px] text-tg-sub">{sub}</span>}</span>
        <ChevronDown size={18} className={clsx('shrink-0 text-tg-faint transition-transform', open && 'rotate-180')} />
      </button>
      {open && <div className="af-sec af-sepabove relative px-3 pb-3 pt-1 md:px-4">{children}</div>}
    </section>
  );
}

/* ---------------- Dashboard ---------------- */
function Dashboard({ api, go, badge }: { api: Api; go: Go; badge: Badges }) {
  const [range, setRange] = useState<Range>('today');
  const [tab, setTab] = useState<'all' | 'agency' | 'funnel' | 'premium' | 'rt' | 'bot'>('all');
  // Retargeting tab: people from retargeting ads (link with ?rt=1) — all of them, or only Agency / Premium / Funnel
  const [rtLine, setRtLine] = useState<'all' | 'agency' | 'premium' | 'funnel'>('all');
  const rtOn = tab === 'rt';
  const botOn = tab === 'bot';
  const line = rtOn ? rtLine : botOn ? 'all' : tab;
  const lineName = (rtOn ? 'retargeting · ' : '') + (line === 'funnel' ? 'Funnel' : line === 'premium' ? 'Premium (/premium)' : line === 'all' ? 'all' : 'Agency');
  const [s, setS] = useState<any>(null);
  const [loadedAt, setLoadedAt] = useState<number | null>(null);
  const [showAll, setShowAll] = useState(() => ls.get('af_home_all') === '1');
  const [team, setTeam] = useState<any[] | null>(null);
  const load = useCallback(() => api(`stats?range=${range}${line === 'all' ? '' : '&line=' + line}${rtOn ? '&rt=1' : ''}`).then(r => { if ((r.line || 'all') === line && !!r.rt === rtOn) { setS(r); setLoadedAt(Date.now()); } }).catch(() => {}), [api, range, line, rtOn]);
  const loadTeam = useCallback(() => api(`leaderboard?range=${range}`).then(r => setTeam(r.rows)).catch(() => {}), [api, range]);
  useEffect(() => { void load(); }, [load]);
  useEffect(() => { void loadTeam(); }, [loadTeam]);
  useInterval(() => void load(), 15000);
  useInterval(() => void loadTeam(), 30000);
  const st: Record<string, number> = {}; (s?.status || []).forEach((x: any) => (st[x.status] = x.n));
  const todo = s ? [
    !s.setup.bot && ['Connect your Telegram bot', 'settings'], s.setup.mode === 'business' && s.setup.bot && !s.setup.business && ['Connect your personal Telegram (Business → Chatbots)', 'settings'],
    !(s.setup.pixel && s.setup.capi) && ['Add Meta Pixel ID and Conversions API token', 'settings'], !s.setup.agents && ['Add your agents', 'team'], !s.setup.push && ['Add Firebase key for phone notifications', 'settings'],
  ].filter(Boolean) as [string, Tab][] : [];
  // v167 "Needs you": an inset list — icon tile, title, one detail line, count badge (tap → the place to act)
  type Need = { k: string; title: string; sub?: string; n: number; fn: () => void; tile: string; icon: any; tone?: 'red' | 'blue' | 'orange' };
  const needs: Need[] = ([
    // v137: open the app (Telegram / WhatsApp) that has the waiting chats; both → one row each
    ...(() => {
      const tg = Number(s?.needs_reply_ch?.tg || 0), wa = Number(s?.needs_reply_ch?.wa || 0);
      if (tg && wa) return [{ k: 'reply-tg', title: 'Waiting for a reply', sub: 'Telegram chats', n: tg, fn: () => go('chats', { status: 'reply', chan: 'tg' }), tile: TILE.red, icon: Reply }, { k: 'reply-wa', title: 'Waiting for a reply', sub: 'WhatsApp chats', n: wa, fn: () => go('chats', { status: 'reply', chan: 'wa' }), tile: TILE.red, icon: Reply }];
      return [{ k: 'reply', title: 'Chats waiting for a reply', sub: wa ? 'WhatsApp' : tg ? 'Telegram' : undefined, n: s?.needs_reply ?? 0, fn: () => go('chats', { status: 'reply', ...(wa ? { chan: 'wa' as const } : tg ? { chan: 'tg' as const } : {}) }), tile: TILE.red, icon: Reply }];
    })(),
    { k: 'unread', title: 'Unread messages', n: badge.unread, fn: () => go('chats', { pick: 'unread' }), tile: TILE.blue, icon: MessageCircle, tone: 'blue' },
    { k: 'unassigned', title: 'Unassigned chats', sub: 'Not on any agent yet', n: s?.unassigned ?? 0, fn: () => go('chats', { agent: 'none' }), tile: TILE.orange, icon: UserRoundCog, tone: 'orange' },
    { k: 'tasks', title: 'Tasks', sub: 'Deliver, top up, confirm payments', n: badge.tasks, fn: () => go('inbox', { inbox: 'tasks' }), tile: TILE.purple, icon: CheckCircle2, tone: 'orange' },
    { k: 'acct', title: 'Ad account requests', n: badge.meta_req, fn: () => go('inbox', { inbox: 'acct' }), tile: TILE.indigo, icon: Wallet, tone: 'orange' },
    { k: 'payouts', title: 'Payouts', sub: 'Agents asked to be paid', n: badge.payouts, fn: () => go('inbox', { inbox: 'payouts' }), tile: TILE.green, icon: CreditCard, tone: 'orange' },
    { k: 'dels', title: 'Delete requests', n: badge.dels, fn: () => go('inbox', { inbox: 'dels' }), tile: TILE.grey, icon: Trash2, tone: 'orange' },
    { k: 'short', title: 'Short pays', n: badge.short, fn: () => go('inbox', { inbox: 'short' }), tile: TILE.yellow, icon: CircleDollarSign, tone: 'orange' },
  ] as Need[]).filter(x => x.n > 0);
  const split = (k: 'n' | 'rev', money?: boolean) => s?.split ? `Telegram ${money ? usd(s.split.tg[k]) : s.split.tg[k]} · WhatsApp ${money ? usd(s.split.wa[k]) : s.split.wa[k]}` : undefined;
  const roiNoSales = s && s.roi != null && s.roi < 0 && !(s.revenue > 0) && !(s.topup_fees > 0);
  const delayTxt = (d: number) => (d >= 60 && d % 60 === 0 ? d / 60 + ' h' : d + ' min');
  const RL: Record<string, string> = { today: 'today', yesterday: 'yesterday', '7d': '· 7 days', '30d': '· 30 days', all: '· lifetime' };
  const period = RL[range] || '· chosen dates';
  const LINE_DOT: Record<string, string> = { agency: '#3390EC', funnel: '#7C5CE0', premium: '#D98A00', rt: '#30B0C7', bot: '#8E8E93' };
  const lineItems: [string, React.ReactNode][] = [['all', 'All lines'], ...(s?.lead_ads !== false ? [['agency', 'Agency'], ['funnel', 'Funnel'], ['premium', 'Premium'], ['rt', 'Retargeting']] as [string, string][] : []), ['bot', 'Bot']];
  const PROD_C: Record<string, string> = { agency: '#3390EC', premium: '#D98A00', full: '#34C759', funnel: '#7C5CE0', fb: '#32ADE6', other: '#8E8E93' };
  const kicker = new Date().toLocaleDateString([], { weekday: 'long', day: 'numeric', month: 'short' });
  return (
    <Page title="Home" kicker={kicker} right={<>
      <RangePick value={range} onChange={setRange} />
      <DropPill value={tab} onChange={v => setTab(v as typeof tab)} items={lineItems as any} dot={LINE_DOT[tab]} menuTitle="Line" />
      {rtOn && <DropPill value={rtLine} onChange={v => setRtLine(v as typeof rtLine)} items={[['all', 'All retargeting'], ['agency', 'Agency'], ['premium', 'Premium'], ['funnel', 'Funnel']]} menuTitle="Retargeting line" />}
      {rtOn ? <InfoTip title="Retargeting">Counts people who came from a retargeting ad: put <b className="text-tg-text">?rt=1</b> at the end of the retargeting ad’s link (e.g. adsbhai.com/premium?rt=1). Ad spend = the retargeting budgets × days.</InfoTip>
        : line !== 'all' && !botOn ? <InfoTip title={`${lineName} line`}>Only people who came from the {lineName} page, and the {lineName} ads spend.{line === 'agency' ? ' Premium (/premium) is not counted here; it has its own tab. Website orders count here.' : ''}</InfoTip> : null}
      {!botOn && <LivePill at={s ? loadedAt : null} />}
    </>}>
      {botOn ? <><BotHome api={api} range={range} /><Fold id="chanadstats" title="Channel ads results" sub="Join requests, bot messages, contacts, sales"><ChanAdStats api={api} range={range} /></Fold></> : !s ? <Skeleton rows={4} h={84} /> : (
        <div className="af-sec">
          {/* hero: net profit + revenue / ad spend / commission */}
          <div className="af-card overflow-hidden" data-money data-hero>
            <div className="px-4 pb-3.5 pt-3.5">
              <p className="text-[13.5px] font-medium text-tg-sub">Net profit {period}</p>
              <p className={clsx('af-hero-num mt-0.5', roiNoSales ? 'text-tg-text' : s.profit >= 0 ? 'text-tg-text' : 'text-tg-bad')} data-profit>{money(s.profit)}</p>
              <p className="mt-1 text-[13px] text-tg-sub">{s.spend > 0 ? (roiNoSales ? 'No sales yet' : <>ROI <b className={clsx('font-semibold', s.roi >= 0 ? 'text-tg-ok' : 'text-tg-bad')}>{s.roi}%</b> · revenue {s.roas ?? '—'}x ad spend</>) : 'No ad spend in this period'}</p>
            </div>
            <div className="af-grid3">
              <div><p className="text-[12.5px] font-medium text-tg-sub">Revenue</p><p className="af-mid-num text-tg-ok">{usd(s.revenue)}</p></div>
              <div><p className="text-[12.5px] font-medium text-tg-sub">Ad spend</p><p className="af-mid-num">{usd(s.spend)}</p></div>
              <div><p className="text-[12.5px] font-medium text-tg-sub">Commission</p><p className="af-mid-num">{usd(s.sale_comm)}</p></div>
            </div>
          </div>
          {rtOn && <OfferStats api={api} range={range} />}
          {tab === 'premium' && <PremiumStats api={api} range={range} />}
          <section data-needs-you>
            <SectionHead title="Needs you" action="Inbox" onAction={() => go('inbox')} />
            <Group tiles>
              {needs.length ? needs.map(x => <Row key={x.k} data-need={x.k} onClick={x.fn} icon={<IconTile icon={x.icon} color={x.tile} />} title={x.title} sub={x.sub} badge={<Badge n={x.n} tone={x.tone} />} />)
                : <Row icon={<IconTile icon={CheckCheck} color={TILE.green} />} title="All clear" sub="Nobody is waiting" />}
            </Group>
          </section>
          <SectionHead title={range === 'today' ? 'Today' : 'This period'} action={showAll ? 'Hide numbers' : 'All numbers'} onAction={() => setShowAll(v => { ls.set('af_home_all', v ? '0' : '1'); return !v; })} />
          <div className="af-card overflow-hidden" data-kpis>
            <div className="af-grid2">
              <div><p className="text-[12.5px] font-medium text-tg-sub">Sales</p><p className="af-mid-num">{s.sales}</p>{s.split && <p className="truncate text-[12px] text-tg-sub">TG {s.split.tg.n} · WA {s.split.wa.n}</p>}</div>
              <div><p className="text-[12.5px] font-medium text-tg-sub">Conversion</p><p className="af-mid-num">{s.conv?.conv_pct == null ? '—' : s.conv.conv_pct + '%'}</p>{s.conv && <p className="truncate text-[12px] text-tg-sub">{s.conv.buyers} of {s.conv.active} people</p>}</div>
              <div><p className="text-[12.5px] font-medium text-tg-sub">{s.lead_ads !== false ? 'Cost per message' : 'Cost per sale'}</p><p className="af-mid-num">{usd(s.lead_ads !== false ? s.cpl : s.cpa)}</p><p className="truncate text-[12px] text-tg-sub">{s.lead_ads !== false ? `${s.started} new chats` : `${s.sales} sales`}</p></div>
              <div><p className="text-[12.5px] font-medium text-tg-sub">Top-up fees</p><p className="af-mid-num">{usd(s.topup_fees + (s.web_topup_fees || 0))}</p><p className="truncate text-[12px] text-tg-sub">on {usd(s.topup_vol + (s.web_topup_vol || 0))}</p></div>
            </div>
            {s.what && s.what.products.some((r: any) => r.rev > 0) && (
              <div className="af-sepabove relative px-4 pb-3.5 pt-3" data-sales-split>
                <div className="mb-2 flex items-baseline justify-between text-[13px]"><span className="text-tg-sub">What sold</span><b className="af-num font-semibold">{usd(s.what.products.reduce((x: number, r: any) => x + Number(r.rev || 0), 0))}</b></div>
                <SplitBar parts={s.what.products.filter((r: any) => r.rev > 0).map((r: any) => [r.label, Number(r.rev), PROD_C[r.k] || '#8E8E93'])} fmt={usd} />
              </div>
            )}
          </div>
          {/* v168: Landing page funnel — per landing page / ad type, this period + line (not for Retargeting / Bot) */}
          {!rtOn && <LandingFunnel api={api} range={range} line={line} conv={s.conv} />}
          {showAll && <div className="af-sec">
            {s.mine && <MyIncome m={s.mine} />}
            {s.what && <>
              <SectionHead title="What sold" action={<>Total income <b className="text-tg-ok">{usd(s.what.income)}</b></>} />
              <WhatSold rows={s.what.products} showComm extra={[
                ...(s.what.topups.n || s.what.topups.v ? [{ label: 'Top-ups', main: usd(s.what.topups.fee), sub: `${pS(s.what.topups.n, 'top-up')} · ${usd(s.what.topups.v)} added · our fee` }] : []),
                ...s.what.web.map((w: any) => ({ label: `Website: ${w.kind === 'funnel' ? 'funnel' : w.kind === 'account' ? 'ad accounts' : w.kind}`, main: usd(w.v), sub: `${pS(w.n, 'order')}${w.kind === 'account' ? ` · ${w.q} account${w.q === 1 ? '' : 's'}` : ''}` })),
                ...(s.what.repl.n ? [{ label: 'Replacement accounts', main: '−' + usd(s.what.repl.cost), sub: `${s.what.repl.n} given free · our account cost` }] : []),
              ]} />
              {s.what.no_agent.n > 0 && <p className="mx-1 mt-1.5 text-[12px] text-tg-sub">{pS(s.what.no_agent.n, 'sale')} ({usd(s.what.no_agent.v)}) {s.what.no_agent.n === 1 ? 'is' : 'are'} not on any agent (WhatsApp sale added by the admin), so the agents together show {s.sales - s.what.no_agent.n}. <button onClick={() => go('wasales')} className="font-medium text-tg-link">Set who sold it</button></p>}
              {!!s.what.sources?.length && <>
                <SectionHead title="Where sales came from" />
                <SourceTable rows={s.what.sources} />
              </>}
            </>}
            {s.conv && <>
              <SectionHead title="Conversion" />
              <div className="grid grid-cols-2 gap-2.5 lg:grid-cols-4" data-conv>
                <Card label="People who messaged" value={s.conv.people} sub={`${s.started} new chats`} tone="blue" />
                <Card label="Bought" value={s.conv.buyers} sub="People who bought" tone="green" />
                <Card label="Buying rate" value={s.conv.conv_pct == null ? '—' : s.conv.conv_pct + '%'} sub={`${s.conv.buyers} of ${s.conv.active} people bought${s.conv.active > s.conv.people ? ` (${s.conv.people} wrote + ${s.conv.active - s.conv.people} bought without a chat)` : ''}`} tone={s.conv.conv_pct ? 'green' : undefined} />
                <Card label="New chats that bought" value={s.conv.new_conv_pct == null ? '—' : s.conv.new_conv_pct + '%'} sub={`${s.conv.new_bought} of ${s.started} new chats`} />
                <Card label="Bought from old chats" value={s.conv.old_buyers} sub={`First message 7+ days before${s.conv.repeat_buyers ? ` · ${s.conv.repeat_buyers} bought again` : ''}`} />
                <Card label="Average time to buy" value={daysTxt(s.conv.avg_days_to_buy)} sub="First message → buying" />
              </div>
            </>}
            <SectionHead title="More numbers" />
            <div className="grid grid-cols-2 gap-2.5 lg:grid-cols-4">
              <Card label="Sales" value={s.sales} sub={split('n')} tone="green" />
              <Card label="Revenue" value={usd(s.revenue)} sub={split('rev', true)} tone="green" />
              {s.lead_ads !== false && <>
                <Card label="Visitors" value={s.visitors ?? '—'} sub={rtOn ? 'Not split for retargeting' : line === 'all' ? 'Unique landing visits' : `Visited the ${lineName} page`} />
                <Card label="Form leads" value={s.forms} sub="Filled the form" tone="blue" />
                <Card label="Messaged on Telegram" value={s.started} sub="Lead event sent" />
              </>}
              <Card label="Ad spend" value={usd(s.spend)} sub={s.meta ? `From Meta since ${s.meta.since}` : rtOn ? 'Retargeting budgets × days' : line === 'all' ? 'Daily budget, or what you entered' : line === 'premium' ? 'Premium ads' : `${lineName} ads only`} tone="orange" />
              {s.lead_ads !== false && <Card label="Cost per message" value={usd(s.cpl)} sub={`Ad spend ÷ messaged on Telegram${s.cpf != null ? ` · per form ${usd(s.cpf)}` : ''}`} />}
              <Card label="Cost per sale" value={usd(s.cpa)} />
              <Card label="ROI" value={s.roi == null ? '—' : s.roi + '%'} sub={s.spend > 0 ? (roiNoSales ? 'No sales yet' : `Profit ÷ ad spend · revenue is ${(s.revenue / s.spend).toFixed(2)}x ad spend`) : undefined} tone={s.roi == null || roiNoSales ? 'muted' : s.roi >= 0 ? 'green' : 'red'} />
              <Card label="Agent commission" value={usd(s.sale_comm)} sub="Per-sale commission" />
              <Card label="Account cost" value={usd(s.acct_cost)} sub="Ad accounts sold × cost" />
              <Card label="Follow-ups due" value={s.followups} tone={s.followups ? 'orange' : undefined} onClick={() => go('chats')} />
            </div>
            <SectionHead title="All time" />
            <div className="grid grid-cols-2 gap-2.5 lg:grid-cols-4">
              <Card label="Open chats" value={st.active || 0} sub="Not sold or dead yet" tone="blue" />
              <Card label="Sold (all time)" value={st.sold || 0} tone="green" />
              <Card label="Dead (all time)" value={st.dead || 0} />
              {s.lead_ads !== false && <Card label="Form only (all time)" value={st.new || 0} sub="Never opened Telegram" />}
            </div>
          </div>}
          {s.meta && <MetaHome m={s.meta} />}
          {line === 'all' && !rtOn && team && team.length > 0 && (
            <section data-team-today>
              <SectionHead title={range === 'today' ? 'Team today' : 'Team'} action="Leaderboard" onAction={() => go('team')} />
              <Group avs>
                {team.map(a => { const w = Number(s.needs_reply_by?.[a.id] || 0); const wc = s.needs_reply_by_ch?.[a.id] || {}; return (
                  <button key={a.id} data-team-agent={a.id} onClick={() => go('chats', w ? { agent: a.id, status: 'reply', chan: Number(wc.wa || 0) > Number(wc.tg || 0) ? 'wa' : 'tg' } : { agent: a.id })} className="af-row">
                    <span className="relative"><Avatar name={a.name} id={a.id} size={40} /><PresenceDot on={a.online_now} size="sm" /></span>
                    <span className="min-w-0 flex-1">
                      <span className="flex min-w-0 items-center gap-1.5 text-[15.5px]"><span className="truncate">{a.name}</span>{a.role === 'manager' && <Tag tone="prem">Manager</Tag>}{!a.receive && <Tag>paused</Tag>}</span>
                      <span className="block truncate text-[13px] text-tg-sub" data-seen={a.id}>{pS(a.sales, 'sale')} · {seenLine(a)}</span>
                    </span>
                    <span className={clsx('shrink-0 text-right text-[13px] af-num', w ? 'font-semibold text-tg-bad' : 'text-tg-sub')}>{w} waiting</span>
                  </button>
                ); })}
                {s.what?.no_agent?.n > 0 && (
                  <button data-team-noagent onClick={() => go('wasales')} className="af-row">
                    <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-tg-warnsoft text-[16px] font-bold text-tg-warn">?</span>
                    <span className="min-w-0 flex-1"><span className="block truncate text-[15.5px]">Not on any agent</span><span className="block truncate text-[13px] text-tg-sub">WhatsApp sale added by the admin · tap to set who sold it</span></span>
                    <span className="shrink-0 text-right text-[13px] af-num text-tg-sub"><b className="block text-tg-text">{usd(s.what.no_agent.v)}</b>{pS(s.what.no_agent.n, 'sale')}</span>
                  </button>
                )}
              </Group>
            </section>
          )}
          <SectionHead title="Reports" />
          {line === 'all' && s.chan && (s.chan.on || s.chan.total > 0 || s.chan.chat > 0) && (
            <Fold id="chan" title="Telegram channel" sub={`${s.chan.total} join requests · ${usd(s.chan.spend)} ads`}>
              <p className="mb-3 mt-2 text-[12.5px] text-tg-sub">Join requests in this period. A Subscribe event goes to Meta for every website join.</p>
              <div className="grid grid-cols-2 gap-2.5 lg:grid-cols-4">
                <Card label="Join requests" value={s.chan.total} sub={s.chan_delay ? `From the website · Subscribe after ${s.chan_delay} min in the channel` : 'From the website · Subscribe sent'} tone="blue" />
                <Card label="From Agency page" value={s.chan.agency} sub="Top bar · free (Agency ads)" tone="green" />
                <Card label="From Funnel page" value={s.chan.funnel} sub="Top bar · free (Funnel ads)" tone="green" />
                <Card label="From /telegram page" value={s.chan.page} sub="Channel ads" />
                <Card label="Telegram ads spend" value={usd(s.chan.spend)} sub="Set in Settings → Ads & tracking" tone="orange" />
                <Card label="Cost per subscribe" value={s.chan.cps == null ? '—' : usd(s.chan.cps)} sub="Telegram ads ÷ /telegram joins" />
                <Card label="Free subscribes" value={s.chan.agency + s.chan.funnel} sub="Came with Agency & Funnel ads" tone="green" />
                <Card label="Joined from chat link" value={s.chan.chat} sub="Welcome message link · no Subscribe" />
              </div>
              {s.chan.page_ads && (s.chan.page_ads.joins > 0 || s.chan.page_ads.spend > 0) && <TgPageAds p={s.chan.page_ads} delay={s.chan_delay} />}
            </Fold>
          )}
          {line === 'all' && !rtOn && s.waads && <Fold id="waads" title="WhatsApp ads" sub="The /…/whatsapp chat pages and the /…/community pages"><WaAdsHome w={s.waads} /></Fold>}
          {line === 'all' && !rtOn && s.chanads && <Fold id="chanads" title="Channel ads" sub={`People who asked to join from the channel pages${s.chan_delay ? ` · Subscribe after ${delayTxt(s.chan_delay)}` : ''}`}><ChanAdsHome c={s.chanads} delay={s.chan_delay} /></Fold>}
          {line !== 'funnel' && (s.web_on || s.web_sales > 0 || s.tasks_open > 0) && (
            <Fold id="web" title="Website orders" sub={`${pS(s.web_sales, 'sale')} · ${usd(s.web_revenue)}${s.tasks_open ? ` · ${s.tasks_open} tasks` : ''}`}>
              <div className="mt-2 grid grid-cols-2 gap-2.5 lg:grid-cols-4">
                <Card label="Website sales" value={s.web_sales} sub="Delivered orders" tone="green" />
                <Card label="Website revenue" value={usd(s.web_revenue)} tone="green" />
                <Card label="Website top-up fees" value={usd(s.web_topup_fees)} sub={`On ${usd(s.web_topup_vol)} of top-ups`} tone="green" />
                <Card label="Tasks to do" value={s.tasks_open} sub="Deliver, top up, confirm INR" tone={s.tasks_open ? 'orange' : undefined} onClick={() => go('inbox', { inbox: 'tasks' })} />
              </div>
            </Fold>
          )}
          <Fold id="camps" title="Campaigns" sub="Which campaign and ad brings chats and sales"><TopCamps api={api} range={range} line={line} onMore={() => go('camps')} /></Fold>
          {s.lead_ads !== false && s.by_theme.length > 0 && (
            <Fold id="themes" title="Form leads by landing page" sub={s.by_theme.map((x: any) => `${x.theme} ${x.n}`).join(' · ')}>
              <div className="mt-2 flex flex-wrap gap-2">{s.by_theme.map((x: any) => <span key={x.theme} className="rounded-full bg-tg-input px-3.5 py-2 text-[14px]">{x.theme} <b className="ml-1">{x.n}</b></span>)}</div>
            </Fold>
          )}
          {todo.length > 0 && <SetupRow todo={todo} go={go} />}
        </div>
      )}
    </Page>
  );
}

/** v167: "Finish setup · 2 left" — one row at the bottom of Home; tap opens the list. */
function SetupRow({ todo, go }: { todo: [string, Tab][]; go: Go }) {
  const [open, setOpen] = useState(false);
  return (
    <section className="mt-5" data-setup>
      <Group tiles>
        <Row onClick={() => setOpen(o => !o)} icon={<IconTile icon={CheckCircle2} color={TILE.purple} />} title="Finish setup" sub={`${todo.length} thing${todo.length === 1 ? '' : 's'} left · ${todo.map(t => t[0].split(' (')[0]).join(' · ')}`} chevron={false} right={<ChevronDown size={18} className={clsx('shrink-0 text-tg-faint transition-transform', open && 'rotate-180')} />} />
        {open && todo.map(([t, tab]) => <Row key={t} onClick={() => go(tab)} icon={<span className="w-[30px]" />} title={<span className="text-[14.5px]">{t}</span>} />)}
      </Group>
    </section>
  );
}

/** v120 Home → /telegram page ads: people who asked to join from /telegram in this period and what they did since. */
function TgPageAds({ p, delay }: { p: any; delay: number }) {
  const c = (v: number | null) => (v == null ? '—' : usd(v));
  return (
    <>
      <h3 className="mb-1 mt-5 text-[15.5px] font-semibold">/telegram page ads</h3>
      <p className="mb-3 text-[12.5px] text-tg-sub">People who asked to join from the /telegram page in this period, and what they did since.{delay ? ` Subscribe goes to Meta only if they are still in after ${delay >= 60 && delay % 60 === 0 ? delay / 60 + ' h' : delay + ' min'}.` : ''}</p>
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Card label="Join requests" value={p.joins} tone="blue" />
        <Card label="Joined the channel" value={p.joined} />
        <Card label="Left the channel" value={p.left} tone={p.left ? 'red' : undefined} />
        <Card label="Still in the channel" value={p.stayed} tone="green" />
        <Card label="Subscribe sent" value={p.subs} sub={p.waiting ? `${p.waiting} waiting for the stay check` : undefined} />
        <Card label="Started the bot" value={p.bot_starts} />
        <Card label="Messaged support" value={p.messaged} tone="blue" />
        <Card label="Sales" value={p.sales} sub={p.revenue ? usd(p.revenue) : undefined} tone="green" />
        <Card label="Ad spend" value={usd(p.spend)} sub="Ad spend → Telegram line" tone="orange" />
        <Card label="Cost per join" value={c(p.cpj)} sub={`Per Subscribe ${c(p.cps_sub)}`} />
        <Card label="Cost per message" value={c(p.cpm)} />
        <Card label="Cost per sale" value={c(p.cpsale)} />
      </div>
    </>
  );
}

/** v120 Home → Bot tab: everyone who came through the bot — organic, channel-ad pages, /telegram ads. */
function BotHome({ api, range }: { api: Api; range: string }) {
  const [d, setD] = useState<any>(null);
  const load = useCallback(() => api<any>(`bot_stats?range=${range}`).then(r => setD({ ...r, _r: range })).catch(() => {}), [api, range]);
  useEffect(() => { void load(); }, [load]);
  useInterval(() => void load(), 20000);
  if (!d) return <Skeleton rows={3} h={84} />;
  const O = [['organic', 'Organic'], ['ads', 'Channel ads'], ['tg', '/telegram']] as const;
  const sum = (o: Record<string, number>) => O.reduce((a, [k]) => a + (Number(o[k]) || 0), 0);
  const rows: [string, string, boolean?][] = [['starts', 'Started the bot'], ['messaged', 'Messaged support'], ['sales', 'Sales'], ['revenue', 'Revenue', true]];
  const cell = 'px-2 py-2 text-right tabular-nums';
  return (
    <>
      <p className="mb-3 text-[12.5px] text-tg-sub">People who came through the bot (its buttons with the code). They are not counted in the Agency / Funnel / Premium ad tabs. Organic = no ad behind them (channel posts, shares, search).</p>
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Card label="Started the bot" value={sum(d.starts)} sub={`Organic ${d.starts.organic} · ${d.starts_total} in total`} tone="blue" />
        <Card label="Messaged support" value={sum(d.messaged)} sub={`Organic ${d.messaged.organic}`} tone="blue" />
        <Card label="Sales" value={sum(d.sales)} sub={`Organic ${d.sales.organic}`} tone="green" />
        <Card label="Revenue" value={usd(sum(d.revenue))} sub={`Organic ${usd(d.revenue.organic)}`} tone="green" />
      </div>
      <div className="mt-4 overflow-x-auto af-card p-3">
        <table className="w-full min-w-[340px] text-[13px]">
          <thead><tr className="text-tg-sub"><th className="py-1 text-left font-normal" />{O.map(([k, l]) => <th key={k} className={cell}>{l}</th>)}<th className={cell}>Total</th></tr></thead>
          <tbody>{rows.map(([k, label, isMoney]) => (
            <tr key={k} className="border-t border-tg-line">
              <td className="py-2 pr-2 text-tg-sub">{label}</td>
              {O.map(([o]) => <td key={o} className={cell}>{isMoney ? usd(d[k][o]) : d[k][o]}</td>)}
              <td className={clsx(cell, 'font-semibold')}>{isMoney ? usd(sum(d[k])) : sum(d[k])}</td>
            </tr>
          ))}</tbody>
        </table>
      </div>
      <h2 className="mb-3 mt-7 text-[17px] font-semibold">What they asked for</h2>
      <div className="grid grid-cols-3 gap-3">
        <Card label="Agency" value={d.products.agency} />
        <Card label="Premium" value={d.products.premium} />
        <Card label="Funnel" value={d.products.funnel} />
      </div>
      <h2 className="mb-3 mt-7 text-[17px] font-semibold">Bot reminders</h2>
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Card label="Reminders sent" value={d.reminders} sub={`To ${d.reminded_people} people`} />
        <Card label="Messaged after a reminder" value={d.after_reminder} tone="green" />
        <Card label="Not messaged yet" value={d.not_messaged_yet} sub="Started the bot, reminders still running" tone="orange" />
      </div>
    </>
  );
}

/** Home: channel ads (/agency|premium|funnel/telegram) — what happened to the people who asked to join in this period. */
/** v137: Home → WhatsApp ads (per line: visitors → chat taps → chats → sold → revenue → spend → profit; community numbers → messaged → sold). */
function WaAdsHome({ w }: { w: any }) {
  const L: [string, string][] = [['agency', 'Agency'], ['premium', 'Premium'], ['funnel', 'Funnel']];
  const rows: [string, string, boolean, (v: number) => string][] = [
    ...(w.chat_on ? [['Visitors', 'visitors', false, String], ['Chat taps', 'chat_taps', false, String], ['Chats', 'chats', false, String], ['Sold', 'sold', false, String], ['Revenue', 'revenue', true, usd], ['Spend', 'spend', true, usd], ['Profit', 'profit', true, usd]] as [string, string, boolean, (v: number) => string][] : []),
    ...(w.comm_on ? [['Community numbers', 'community_numbers', false, String], ['…messaged', 'messaged', false, String], ['…sold', 'community_sold', false, String]] as [string, string, boolean, (v: number) => string][] : []),
  ];
  return (
    <div className="min-w-0 overflow-x-auto af-card p-4" data-wa-ads-home>
      <table className="w-full min-w-[300px] text-[13.5px]"><thead><tr className="text-tg-sub"><th className="text-left font-normal" />{L.map(([, n]) => <th key={n} className="text-right font-medium">{n}</th>)}</tr></thead>
        <tbody>{rows.map(([label, k, money, fmt]) => <tr key={k} className="border-t border-tg-line"><td className="py-1.5 pr-2 text-tg-sub">{label}</td>{L.map(([l]) => { const v = Number(w.lines[l][k] || 0); return <td key={l} className={clsx('text-right tabular-nums', k === 'profit' && (v >= 0 ? 'text-tg-ok' : 'text-tg-bad'), money && 'font-medium')}>{fmt(v)}</td>; })}</tr>)}</tbody></table>
    </div>
  );
}
function ChanAdsHome({ c, delay }: { c: any; delay: number }) {
  const L = ['agency', 'premium', 'funnel'] as const;
  const tot = (k: string) => L.reduce((a, l) => a + (Number(c.lines[l]?.[k]) || 0), 0);
  const rows: [string, string, string?][] = [
    ['visitors', 'Visitors (channel page)', 'blue'], ['joins', 'Join requests'], ['joined', 'Joined the channel'], ['left', 'Left the channel', 'red'], ['stayed', 'Still in the channel', 'green'],
    ['subs', delay ? `Subscribe sent (stayed ${delay >= 60 && delay % 60 === 0 ? delay / 60 + ' h' : delay + ' min'})` : 'Subscribe sent'], ['waiting', 'Waiting for the stay check'],
    ['bot_info', 'Saw pricing in bot'], ['bot_info_support', 'Went to support', 'blue'],
    ['leads', 'Contacts (messaged us)', 'blue'], ['sales', 'Sales (chats)', 'green'], ['revenue', 'Revenue (chats)', 'green'], ['orders', 'Website orders'],
    ['spend', 'Ad spend', 'red'], ['cpj', 'Cost per join'], ['cpc', 'Cost per contact'], ['cps', 'Cost per sale'],
  ];
  // cost rows: per line from the API, Total worked out from the totals
  const COST: Record<string, string> = { cpj: 'joins', cpc: 'leads', cps: 'sold' };
  const totOf = (k: string) => { if (!COST[k]) return tot(k); const sp = tot('spend'); const n = COST[k] === 'sold' ? tot('sales') + tot('orders') : tot(COST[k]); return sp && n ? sp / n : null; };
  const cell = 'px-2 py-2 text-right tabular-nums';
  const fmt = (k: string, v: number | null) => (v == null ? '—' : ['revenue', 'spend', 'cpj', 'cpc', 'cps'].includes(k) ? usd(v) : String(v));
  const val = (l: string, k: string) => { const v = c.lines[l]?.[k]; return COST[k] ? (v == null ? null : Number(v)) : Number(v) || 0; };
  return (
    <>
      <p className="mb-3 mt-2 text-[12.5px] text-tg-sub">People who asked to join from the Agency / Premium / Funnel channel pages in this period, and what they did since.{delay ? ` Meta gets Subscribe only if they are still in the channel after ${delay} minutes.` : ''}</p>
      <div className="overflow-x-auto af-card">
        <table className="w-full min-w-[460px] text-[13.5px]">
          <thead><tr className="text-tg-sub"><th className="sticky left-0 z-[1] bg-tg-panel py-1 text-left font-normal" /><th className={cell}>Agency</th><th className={clsx(cell, 'text-tg-warn')}>Premium</th><th className={cell}>Funnel</th><th className={cell}>Total</th></tr></thead>
          <tbody>{rows.map(([k, label, tone]) => (
            <tr key={k} className="border-t border-tg-line">
              <td className={clsx('sticky left-0 z-[1] bg-tg-panel py-2 pr-2', tone === 'green' ? 'text-tg-ok' : tone === 'red' ? 'text-tg-bad' : tone === 'blue' ? 'text-tg-link' : 'text-tg-sub')}>{label}</td>
              {L.map(l => <td key={l} className={cell}>{fmt(k, val(l, k))}</td>)}
              <td className={clsx(cell, 'font-semibold')}>{fmt(k, totOf(k))}</td>
            </tr>
          ))}</tbody>
        </table>
        <p className="mt-2 text-[12px] text-tg-sub">Started the bot: {c.bot_starts} in this period · {c.bot_subs_total} in total. Ad spend comes from Ad spend (channel lines). Turn this off in More → What's running.</p>
      </div>
    </>
  );
}

/** v116: approve everyone still waiting in the channel (done by the worker through the chat account, within a minute). */
function ApproveAll({ api, status }: { api: Api; status?: string }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  return (
    <div className="mb-3 flex items-center justify-between gap-3 rounded-xl bg-tg-input px-4 py-3">
      <span><span className="block">Approve everyone waiting now</span><span className="text-[12.5px] text-tg-sub">{status || 'Old requests that are still waiting in the channel. Done by your chat account (must be a channel admin), within a minute.'}</span></span>
      <Btn busy={busy} onClick={async () => { setBusy(true); try { await api('chan_approve_all', {}); toast('Starting. Check back in a minute.'); } catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); } }}>Approve all</Btn>
    </div>
  );
}

/** v117: Follow-ups check — why automatic follow-ups are (not) going out, with example chats. */
function FuHealth({ api }: { api: Api }) {
  const [d, setD] = useState<any>(null);
  const load = useCallback(() => api<any>('fu_health').then(setD).catch(() => {}), [api]);
  useEffect(() => { void load(); }, [load]);
  if (!d) return null;
  const ago = (t: number | null) => (!t ? 'never' : Date.now() - t < 120000 ? 'just now' : Math.round((Date.now() - t) / 60000) + ' min ago');
  return (
    <div className="af-card px-4 py-4">
      <div className="mb-2 flex items-center justify-between"><span className="text-[15.5px] font-semibold">Follow-ups check</span><button onClick={() => void load()} className="text-[13px] text-tg-link">Refresh</button></div>
      <p className="mb-3 text-[13px] text-tg-sub">
        Automatic follow-ups: <b className={d.auto ? 'text-tg-ok' : 'text-tg-bad'}>{d.auto ? 'ON' : 'OFF (agents only get a reminder)'}</b> · after {d.gaps.join(' / ')} h · quiet hours {d.quiet || 'none'}{d.quiet_now ? ' (now — they wait till morning)' : ''}<br />
        Checker last ran: <b className={!d.last_run || Date.now() - d.last_run > 10 * 60000 ? 'text-tg-bad' : 'text-tg-text'}>{ago(d.last_run)}</b>{!d.last_run || Date.now() - d.last_run > 10 * 60000 ? ' — the worker is not running, nothing automatic goes out' : ''}<br />
        Sent in the last 3 days: <b className="text-tg-text">{d.sent_3d}</b> · could not be sent: <b className={d.failed_3d ? 'text-tg-bad' : 'text-tg-text'}>{d.failed_3d}</b><br />
        Waiting in the chat-account queue: <b className={d.outbox.queued ? 'text-tg-bad' : 'text-tg-text'}>{d.outbox.queued}</b>{d.outbox.queued ? ` (oldest ${ago(d.outbox.oldest)})` : ''} · chat account: {d.ub_ready ? (d.ub_paused ? 'paused by Telegram' : 'connected') : 'not connected'}
      </p>
      {d.pace && <PaceLines p={d.pace} />}
      <div className="grid gap-2">{d.rows.map((r: any) => (
        <div key={r.k} className="rounded-xl bg-tg-input px-3 py-2.5 text-[13px]">
          <div className="flex justify-between gap-3"><span>{r.label}</span><b className={r.bad && r.n ? 'text-tg-bad' : ''}>{r.n}</b></div>
          {r.n > 0 && r.ex.length > 0 && <p className="mt-1 text-[12px] text-tg-sub">e.g. {r.ex.join(' · ')}</p>}
        </div>
      ))}</div>
      {d.stops.length > 0 && <p className="mt-2 text-[12px] text-tg-sub">Why stopped: {d.stops.map((x: any) => `${x.auto_stop} (${x.n})`).join(' · ')}</p>}
    </div>
  );
}

/** v143: the send queue, one line per channel: "N waiting in the send queue · next at HH:MM · rate 20/h". */
function PaceLines({ p }: { p: any }) {
  const hm = (t: number) => new Date(t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  return (
    <div className="mb-3 grid gap-1.5" data-pace>
      {!p.on && <p className="rounded-xl bg-tg-orange/15 px-3 py-2 text-[13px] text-tg-orange">Sending speed limits are OFF — automatic messages go out as soon as they are due.</p>}
      {p.tga_stop_until > 0 && <p className="rounded-xl bg-tg-red/15 px-3 py-2 text-[13px] text-tg-red">Telegram chat account: spam limit ({p.tga_stop_why || 'PEER_FLOOD'}) — its automatic messages wait until {new Date(p.tga_stop_until).toLocaleString([], { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}. WhatsApp and the bot keep sending.</p>}
      {p.ch.filter((c: any) => c.ch === 'tga' || c.waiting || c.sent_1h).map((c: any) => (
        <p key={c.ch} data-pace-ch={c.ch} className="rounded-xl bg-tg-input px-3 py-2 text-[13px]">
          <b>{c.name}:</b> <b className={c.waiting ? 'text-tg-text' : 'text-tg-sub'}>{c.waiting}</b> waiting in the send queue{c.waiting ? <> · next at <b>{hm(c.next_at)}</b></> : ''} · rate {c.rate}
          <span className="block text-[12px] text-tg-sub">Sent automatically: {c.sent_1h} in the last hour · {c.sent_24h} in 24 h{c.waiting && c.why ? ` · waiting for: ${c.why}` : ''}</span>
        </p>
      ))}
    </div>
  );
}

/** More → What's running: switch whole ad systems on / off, so Home only shows what is running now. */
function Running({ api, back }: { api: Api; back?: () => void }) {
  const toast = useToast();
  const [s, setS] = useState<Record<string, string> | null>(null);
  useEffect(() => { api<any>('settings').then(r => setS(r.settings)).catch(() => {}); }, [api]);
  const flip = async (k: string, v: boolean) => {
    setS(x => (x ? { ...x, [k]: v ? '1' : '0' } : x));
    try { await api('settings_save', { [k]: v ? '1' : '0' }); toast(v ? 'ON' : 'OFF'); } catch (e) { toast((e as Error).message, 'err'); }
  };
  return (
    <Page title="What's running" back={back}>
      {!s ? <Skeleton rows={2} h={90} /> : (() => {
        // v167: one row per system — title, 1-line effect, (i) for the full text, switch
        const R = (k: string, on: boolean, title: string, line: string, full: string, icon: any, c: string) => (
          <div className="af-row" data-k={k} key={k}>
            <IconTile icon={icon} color={c} />
            <span className="min-w-0 flex-1"><span className="flex items-center gap-1 text-[15.5px]"><span className="truncate">{title}</span><InfoTip title={title}>{full}</InfoTip></span><span className="block truncate text-[13px] text-tg-sub">{line}</span></span>
            <Toggle on={on} onChange={v => void flip(k, v)} label={title} />
          </div>
        );
        return <>
          <Group tiles>
            {R('lead_ads_on', s.lead_ads_on !== '0', 'Lead ads', 'Landing page → Telegram', 'Agency / Premium / Funnel landing pages with the form. OFF = Home hides visitors, form leads, messaged, cost per message and the line tabs. Sales, revenue, ad spend and profit always stay. The pages keep working.', Megaphone, TILE.blue)}
            {R('wa_ads_on', s.wa_ads_on === '1', 'WhatsApp ads', 'Chat button pages', '/agency, /premium, /funnel whatsapp pages. OFF = Home hides the WhatsApp ads table, and the WhatsApp spend lines and campaign cards fold away under Not running. Sales, revenue, ad spend and profit always stay. The pages and the webhook keep working.', MessageCircle, TILE.green)}
            {R('wa_comm_ads_on', s.wa_comm_ads_on === '1', 'WhatsApp community ads', 'Join with your number', '/agency, /premium, /funnel community pages (join with your number). OFF = Home hides the community numbers. The pages keep working for anyone who still comes.', Users, TILE.teal)}
            {R('chan_ads_on', s.chan_ads_on !== '0', 'Channel ads', 'Subscribe · Telegram pages', '/agency, /premium, /funnel telegram pages. OFF = their table is hidden on Home. The pages and the bot keep working for anyone who still comes.', Radar, TILE.indigo)}
          </Group>
          <p className="mx-1 mt-2 text-[12.5px] leading-snug text-tg-sub">OFF only hides things on Home; the pages keep working. Settings for each system are in More → Settings. The follow-ups check is in More → System.</p>
        </>;
      })()}
    </Page>
  );
}


/* ---------------- Chats ---------------- */
type SalesMe = Omit<SalesCtx, 'agent'> & { paylinks?: boolean; quick_replies: string[]; fu: string[]; quick_replies_f?: string[]; fu_f?: string[]; premium?: { price_account: number; topup_pct: number; quick_replies: string[]; fu: string[] } };
const CHAT_ST: [string, string][] = [['', 'All'], ['active', 'Open'], ['reply', 'Needs reply'], ['sold', 'Sold'], ['dead', 'Dead']];
function Chats({ api, open, setOpen, onChanged, go, delN, initAgent, initStatus, initChan, pick }: { api: Api; open: number | null; setOpen: (id: number | null) => void; onChanged: () => void; go: Go; delN: number; initAgent?: number | string; initStatus?: string; initChan?: 'tg' | 'wa'; pick?: 'unread' }) {
  const toast = useToast();
  const [rows, setRows] = useState<any[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [agents, setAgents] = useState<Agent[]>([]);
  const [agent, setAgent] = useState(initAgent != null ? String(initAgent) : ''); const [status, setStatus] = useState(initStatus || ''); const [q, setQ] = useState('');
  // v131: Telegram / WhatsApp folders, and in each the manager's + every agent's folder
  const [waOn, setWaOn] = useState(false);
  const [chan, setChanS] = useState<'tg' | 'wa'>(() => initChan || (ls.get('af_achan') === 'wa' ? 'wa' : 'tg'));
  // v137: opened from Home / a notification with a filter → never land on an empty app tab when the other app has chats
  const autoPick = useRef(!initChan && (!!initStatus || initAgent != null || !!pick || open != null));
  const setChan = (c: 'tg' | 'wa') => { setChanS(c); ls.set('af_achan', c); };
  const srvStatus = status; // v144: "Needs reply" = open AND sold chats where the customer wrote last (the server filters it)
  const load = useCallback(() => api(`leads?range=all&chats=1&agent=${agent}&status=${srvStatus}&q=${encodeURIComponent(q)}`).then(r => { setRows(r.leads); setWaOn(!!r.wa_on); setLoaded(true); }).catch(() => {}), [api, agent, srvStatus, q]);
  useEffect(() => { void load(); }, [load]);
  useEffect(() => { api('agents').then(r => setAgents(r.agents)).catch(() => {}); }, [api]);
  useInterval(() => void load(), 5000);
  // v136: sell from the chat — prices + texts once, the chat's agent from the chat itself
  const [sm, setSm] = useState<SalesMe | null>(null);
  useEffect(() => { api<SalesMe>('sales_me').then(setSm).catch(() => {}); }, [api]);
  const [cur0, setCurLead] = useState<LeadFull | null>(null);
  const [sheet, setSheet] = useState<null | 'sold' | 'topup' | 'paylink' | 'acct'>(null);
  const reloadChat = useRef<(() => void) | null>(null);
  useBackEntry(!!open, () => setOpen(null)); // v136: Android Back closes the chat (one stack with the sheets)
  const cur: 'tg' | 'wa' = waOn ? chan : 'tg';
  const chOf = (c: { ch?: string | null }) => (c.ch === 'wa' ? 'wa' : 'tg');
  const match = (c: any) => status !== 'reply' || ((c.status === 'active' || c.status === 'sold') && waitingC(c));
  // v147: select many chats in Needs reply → "No reply needed" (nothing is sent; they come back when the customer writes again)
  const [sel, setSel] = useState<Set<number> | null>(null);
  useEffect(() => { if (status !== 'reply') setSel(null); }, [status]);
  const noReply = async (ids: number[]) => {
    if (!ids.length) return;
    try { const r = await api<{ n: number }>('noreply', { lead_ids: ids }); toast(`${r.n} chat${r.n === 1 ? '' : 's'}: no reply needed`); setSel(null); void load(); onChanged(); } catch (e) { toast((e as Error).message, 'err'); }
  };
  const shown = rows.filter(c => chOf(c) === cur && match(c));
  const other: 'tg' | 'wa' = cur === 'wa' ? 'tg' : 'wa';
  const otherN = waOn ? rows.filter(c => chOf(c) === other && match(c) && (pick !== 'unread' || c.unread > 0)).length : 0;
  useEffect(() => {
    if (!loaded || !autoPick.current || !waOn) return;
    autoPick.current = false;
    const want = open != null ? rows.find(c => c.id === open) : null; // a chat opened from a notification → its app
    if (want) { if (chOf(want) !== cur) setChan(chOf(want)); return; }
    const mine = rows.filter(c => chOf(c) === cur && match(c) && (pick !== 'unread' || c.unread > 0)).length;
    if (!mine && otherN) setChan(other);
  }, [loaded, waOn]); // eslint-disable-line react-hooks/exhaustive-deps
  const unreadOf = (k: 'tg' | 'wa') => rows.filter(c => chOf(c) === k && c.unread > 0).length;
  const folderAgents = [...agents].filter(a => cur === 'tg' || a.role === 'manager' || (',' + (a.chans || 'tg') + ',').includes(',wa,'))
    .sort((a, b) => (a.role === 'manager' ? 0 : 1) - (b.role === 'manager' ? 0 : 1));
  const appear = useAppear(rows.map(r => r.id));
  const lead = cur0 && cur0.id === open ? cur0 : null;
  const own = lead ? agents.find(a => a.id === lead.agent_id) || agents.find(a => a.role === 'manager') : undefined;
  const ctx: SalesCtx | null = sm ? priceCtxFor({ ...sm, agent: own ? { role: own.role, name: own.name, comm_per_sale: own.comm_per_sale, comm_premium: own.comm_premium == null || own.comm_premium === '' ? null : Number(own.comm_premium) } : { role: 'manager', comm_per_sale: 0 } }, lead) : null;
  const prem = lead?.tier === 'premium';
  const done = () => { reloadChat.current?.(); void load(); onChanged(); };
  const needOwner = () => { if (!own) { toast('Assign the chat to an agent first', 'err'); return false; } return true; };

  return (
    <div className="flex h-[100dvh] md:h-[100dvh]">
      <div className={clsx('flex w-full flex-col border-r border-tg-line bg-tg-panel text-tg-text md:w-[380px] md:shrink-0', open && 'hidden md:flex')} data-chan={cur}>
        <div className="px-3 pb-2 pt-[calc(14px+env(safe-area-inset-top))]">
          <div className="mb-2.5 flex items-center px-1"><h1 className="af-title flex-1">Chats</h1></div>
          {delN > 0 && <button data-del-reqs onClick={() => go('inbox', { inbox: 'dels' })} className="af-press mb-2 flex w-full items-center gap-2 rounded-xl bg-tg-red/10 px-3 py-2.5 text-left text-[14px] font-medium text-tg-bad"><Trash2 size={17} /><span className="flex-1">{delN} chat delete request{delN === 1 ? '' : 's'} in Inbox</span><ChevronRight size={17} /></button>}
          {waOn && <ChanSwitch className="mb-2" value={cur} onChange={setChan} unread={unreadOf} id="chsw_admin" />}
          <div className="flex h-[38px] items-center gap-2 rounded-xl bg-tg-panel px-3 shadow-[var(--tg-card-shadow)]"><Search size={17} className="text-tg-faint" /><input value={q} onChange={e => setQ(e.target.value)} placeholder="Search name, number, #id" aria-label="Search chats" className="h-full min-w-0 flex-1 bg-transparent text-[15px] outline-none placeholder:text-tg-faint" /></div>
          {/* one folder per person: manager first, then the agents (only those who take this channel) */}
          {/* v167: one row — the agent filter is an "Everyone ▾" pill, then the status chips */}
          <div className="-mx-3 mt-2 flex items-center gap-2 overflow-x-auto px-3 pb-0.5 [scrollbar-width:none]" data-agent-folders>
            <DropPill value={agent} onChange={setAgent} menuTitle="Agent" items={[['', 'Everyone'], ['none', 'Unassigned'], ...folderAgents.map(a => [String(a.id), a.name] as [string, string])] as any} />
            <Chips className="!overflow-visible" value={status} onChange={setStatus} items={CHAT_ST.map(([v, l]) => [v, l] as [string, string])} />
          </div>
          {status === 'reply' && shown.length > 0 && (sel ? (
            <div data-noreply-bar className="mt-2 flex items-center gap-2">
              <button onClick={() => setSel(sel.size === shown.length ? new Set() : new Set(shown.map(c => c.id)))} className="af-press rounded-full bg-tg-chip px-3 py-1.5 text-[13.5px] font-medium">{sel.size === shown.length ? 'Clear' : `Select all ${shown.length}`}</button>
              <button data-noreply-go disabled={!sel.size} onClick={() => void noReply([...sel])} className="af-press flex-1 rounded-full bg-tg-acc px-3 py-1.5 text-[13.5px] font-semibold text-white disabled:opacity-50">No reply needed{sel.size ? ` (${sel.size})` : ''}</button>
              <button onClick={() => setSel(null)} aria-label="Cancel" className="af-press grid h-8 w-8 place-items-center rounded-full bg-tg-chip"><X size={16} /></button>
            </div>
          ) : (
            <button data-noreply-select onClick={() => setSel(new Set())} className="af-press mt-2 inline-flex items-center gap-1.5 rounded-full bg-tg-chip px-3 py-1.5 text-[13.5px] font-medium text-tg-link"><CheckCheck size={15} />Select · No reply needed</button>
          ))}
        </div>
        <div className="flex-1 overflow-y-auto pb-[calc(76px+env(safe-area-inset-bottom))] md:pb-2">
          {!loaded ? <div className="space-y-1 p-2">{Array.from({ length: 6 }, (_, i) => <div key={i} className="af-skel flex items-center gap-3 px-1 py-2"><span className="h-[52px] w-[52px] rounded-full bg-tg-input" /><span className="flex-1 space-y-2"><span className="block h-3.5 w-2/5 rounded bg-tg-input" /><span className="block h-3 w-4/5 rounded bg-tg-input" /></span></div>)}</div>
            : !shown.length && <div className="p-10 text-center text-[14.5px] leading-relaxed text-tg-sub">{otherN > 0 && <button data-other-app onClick={() => setChan(other)} className="af-press mb-3 inline-flex items-center gap-1.5 rounded-full bg-tg-acc/15 px-3.5 py-2 text-[14px] font-semibold text-tg-link">{otherN} {status === 'reply' ? 'waiting' : 'chats'} on {other === 'wa' ? 'WhatsApp' : 'Telegram'} → open</button>}<br />{status === 'reply' ? 'Nobody is waiting for a reply.' : cur === 'wa' ? <>No WhatsApp chats here yet. WhatsApp chats come in when WATI is connected: <button className="font-medium text-tg-link" onClick={() => go('settings', { sec: 'wati' })}>Settings → WhatsApp</button>.</> : 'No chats yet. They appear when someone messages on Telegram.'}</div>}
          {loaded && shown.map(c => {
            const name = leadName(c); const ap = appear(c.id);
            return (
              <button key={c.id} data-sel={sel ? (sel.has(c.id) ? 1 : 0) : undefined} onClick={() => { if (sel) { const n = new Set(sel); if (n.has(c.id)) n.delete(c.id); else n.add(c.id); setSel(n); } else setOpen(c.id); }} style={ap.style} className={clsx('flex w-full items-center gap-3 px-2.5 py-2 text-left', open === c.id ? 'bg-tg-active' : 'hover:bg-tg-hover active:bg-tg-hover', ap.className)}>
                {sel && (sel.has(c.id) ? <CheckCircle2 size={24} className="shrink-0 text-tg-acc" /> : <Circle size={24} className="shrink-0 text-tg-sub" />)}
                <Avatar name={name} id={c.id} size={52} />
                <span className="min-w-0 flex-1 py-1">
                  <span className="flex items-center gap-2"><span className={clsx('min-w-0 flex-1 truncate text-[15.5px]', c.unread ? 'font-semibold text-tg-strong' : 'font-medium')}>{name}</span><LineBadge l={c} /><span className="shrink-0 text-[12px] text-tg-sub">{listTime(c.last_at)}</span></span>
                  <span className="mt-0.5 flex items-center gap-2"><span className="min-w-0 flex-1 truncate text-[14px] text-tg-sub">{c.last_text}</span>{c.unread > 0 && <span key={c.unread} className="af-pop af-cnt h-5 min-w-5 rounded-full bg-tg-acc px-1.5 text-[12px] font-semibold text-white"><i className="af-n">{c.unread}</i></span>}</span>
                  <span className="mt-1 flex min-w-0 items-center gap-1.5 overflow-hidden whitespace-nowrap text-[11.5px]"><StatusPill l={c} />{c.welcome_due && <span className="shrink-0 rounded-[6px] bg-tg-warnsoft px-1.5 py-px font-semibold text-tg-warn">Welcome in {Math.max(1, Math.ceil((c.welcome_due - Date.now()) / 60000))} min</span>}<span className="shrink-0 text-[12.5px] text-tg-sub">{c.agent_name || 'Unassigned'}</span><span className="flex min-w-0 shrink overflow-hidden"><RowCamp l={c} /></span></span>
                </span>
              </button>
            );
          })}
        </div>
      </div>
      <div className={clsx('min-w-0 flex-1', !open && 'hidden md:block')}>
        {open ? <ChatScreen key={open} role="admin" api={api} leadId={open} agents={agents} onBack={() => (window.innerWidth < 768 ? history.back() : setOpen(null))} onChanged={() => { void load(); onChanged(); }} onLead={l => setCurLead(p => (p && p.id === l.id && p.agent_id === l.agent_id && p.tier === l.tier && p.offer_until === l.offer_until && p.biz === l.biz && p.status === l.status ? p : l))}
          productMsgs={(sm as any)?.product_msgs} quickReplies={sm?.quick_replies} followups={sm?.fu} quickRepliesF={sm?.quick_replies_f} followupsF={sm?.fu_f} quickRepliesP={sm?.premium?.quick_replies} followupsP={sm?.premium?.fu}
          barHas={['assign', 'remind']}
          extraMenu={(l, reload) => { reloadChat.current = reload; return [
            ...(l && (l.status === 'active' || l.status === 'sold') && waitingC(l as any) ? [{ label: 'No reply needed', onClick: async () => { await noReply([l.id]); reload(); } }] : []),
            { label: 'Delete chat (admin)', danger: true, onClick: async () => {
              if (!confirm(`Delete the chat with ${l.name || l.tg_name || 'this customer'} completely? All its messages are removed from the apps. This can't be undone. (Nothing is deleted in Telegram.)`)) return;
              try { const x = await api<{ moved?: string; why?: string }>('lead_delete', { lead_id: l.id }); toast(x.moved ? `Has ${x.why} — records kept, moved to Dead` : 'Chat deleted'); if (x.moved) reload(); else setOpen(null); void load(); onChanged(); } catch (e) { toast((e as Error).message, 'err'); }
            } }]; }}
          actionBar={(l, act) => {
            // v139: the same compact chip row as the agent app — everything primary is a chip, the rest stays in the ⋮ menu
            const rOn = !!l?.remind_at && l.remind_at > Date.now();
            const items: BarAct[] = [
              ...(sm?.paylinks ? [{ k: 'paylink', label: 'Payment link', icon: <Link2 size={15} />, onClick: () => { if (needOwner()) setSheet('paylink'); }, tone: 'link' as const }] : []),
              ...(sm?.meta_on || (sm as any)?.meta_acct ? [{ k: 'acct', label: 'Ad account', icon: <CreditCard size={15} />, onClick: () => setSheet('acct') }] : []),
              { k: 'sold', label: l?.status === 'sold' ? 'Sell again' : 'Record sale', icon: <CircleDollarSign size={15} />, onClick: () => { if (needOwner()) setSheet('sold'); }, tone: 'green', on: l?.status === 'sold' },
              { k: 'topup', label: 'Add topup', icon: <Plus size={15} />, onClick: () => { if (needOwner()) setSheet('topup'); } },
              { k: 'assign', label: l?.agent_id ? 'Assign' : 'Assign agent', icon: <UserRoundCog size={15} />, onClick: act.assign },
              { k: 'remind', label: rOn ? remindLabel(l!.remind_at!) : 'Remind', icon: <AlarmClock size={15} />, onClick: act.remind, on: rOn },
            ];
            return <ChatActionBar items={items} />;
          }} />
          : <div className="grid h-full place-items-center text-tg-sub">Select a chat to read it</div>}
      </div>
      {ctx && <>
        <SoldSheet open={sheet === 'sold'} onClose={() => setSheet(null)} api={api} me={ctx} premium={prem} stdPrice={sm?.price_account} leadId={open} who={own?.name} admin onDone={done} />
        <TopupSheet open={sheet === 'topup'} onClose={() => setSheet(null)} api={api} me={ctx} leadId={open} onDone={done} />
        <PayLinkSheet open={sheet === 'paylink'} onClose={() => setSheet(null)} api={api} me={ctx} premium={prem} stdPrice={sm?.price_account} leadId={open} noMin who={own?.name} onDone={done} />
        <ChatAccountSheet open={sheet === 'acct'} onClose={() => setSheet(null)} api={api} leadId={open} pct={ctx.topup_pct} autoAcct autoTopup manager admin onDone={done} />
      </>}
    </div>
  );
}

/* ---------------- Leads ---------------- */
const LEAD_ST: [string, string][] = [['', 'All'], ['new', 'Form only'], ['call_todo', 'To call'], ['call_done', 'Called'], ['call_no', 'No answer'], ['call_int', 'Interested'], ['call_conv', 'Converted'], ['call_ni', 'Not interested'], ['hot', 'Hot'], ['active', 'Open chats'], ['sold', 'Sold'], ['dead', 'Dead']];
function Leads({ api, onOpen, back }: { api: Api; onOpen: (id: number) => void; back?: () => void }) {
  const toast = useToast();
  const [range, setRange] = useState<Range>('7d'); const [status, setStatus] = useState(''); const [q, setQ] = useState(''); const [biz, setBiz] = useState(''); const [agent, setAgent] = useState('');
  const [agents, setAgents] = useState<Agent[]>([]);
  useEffect(() => { api('agents').then(r => setAgents(r.agents)).catch(() => {}); }, [api]);
  const [rows, setRows] = useState<any[] | null>(null); const [info, setInfo] = useState<any>(null);
  const bizQ = biz === 'premium' ? 'tier=premium' : `biz=${biz}`;
  const reload = useCallback(() => api(`leads?range=${range}&status=${status}&${bizQ}&agent=${agent}&q=${encodeURIComponent(q)}`).then(r => { setRows(r.leads); setInfo((x: any) => (x ? r.leads.find((l: any) => l.id === x.id) || x : x)); }).catch(() => setRows([])), [api, range, status, bizQ, agent, q]);
  useEffect(() => { void reload(); }, [reload]);
  return (
    <Page title="Leads" back={back} right={<>
      <RangePick value={range} onChange={setRange} />
      <DropPill value={biz} onChange={setBiz} menuTitle="Line" items={[['', 'All lines'], ['agency', 'Agency'], ['premium', 'Premium'], ['funnel', 'Funnel']]} />
      {agents.length > 0 && <DropPill value={agent} onChange={setAgent} menuTitle="Agent" items={[['', 'Everyone'], ['none', 'Unassigned'], ...agents.map(a => [String(a.id), a.name] as [string, string])] as any} />}
    </>}>
      <label className="mb-2.5 flex h-[38px] items-center gap-2 rounded-xl bg-tg-panel px-3 text-tg-faint shadow-[var(--tg-card-shadow)]"><Search size={17} className="shrink-0" /><input value={q} onChange={e => setQ(e.target.value)} placeholder="Search name or number" aria-label="Search leads" className="h-full min-w-0 flex-1 bg-transparent text-[15px] text-tg-text outline-none placeholder:text-tg-faint" /></label>
      <div className="mb-3" data-lead-filters>
        <ScrollRow><Chips value={status} onChange={setStatus} items={LEAD_ST.map(([v, l]) => [v, l] as [string, string])} /></ScrollRow>
      </div>
      {!rows ? <Skeleton rows={5} h={60} /> : !rows.length ? <EmptyState text="No leads in this period." /> : (
        <div className="overflow-hidden af-card">
          {rows.map(l => (
            <button key={l.id} onClick={() => (l.status === 'new' ? setInfo(l) : onOpen(l.id))} className="flex w-full items-start gap-3 border-b border-tg-line px-4 py-3 text-left last:border-0 hover:bg-tg-hover active:bg-tg-hover">
              <Avatar name={leadName(l)} id={l.id} size={42} />
              <span className="min-w-0 flex-1">
                <span className="flex items-center gap-2"><span className="min-w-0 flex-1 truncate text-[15.5px] font-medium">{leadName(l)} <span className="text-[12px] font-normal text-tg-sub">#{l.id}</span></span>{l.revenue > 0 ? <span className="shrink-0 text-[13px] font-semibold text-tg-ok af-num">{usd(l.revenue)}</span> : <span className="shrink-0 text-[12px] text-tg-sub">{listTime(l.created_at)}</span>}</span>
                <span className="block truncate text-[13px] text-tg-sub">{[l.phone, l.niche, l.budget, l.theme && `${l.line === 'funnel' ? 'funnel/' : ''}${l.theme} page`].filter(Boolean).join(' · ') || 'Telegram'}</span>
                <span className="mt-1 flex min-w-0 items-center gap-1.5 overflow-hidden whitespace-nowrap text-[11.5px]"><StatusPill l={l} /><LineBadge l={l} />{l.camp && <span className="flex min-w-0 shrink overflow-hidden"><CampChip camp={l.camp} ad={l.ad} /></span>}</span>
              </span>
            </button>
          ))}
        </div>
      )}
      <Sheet open={!!info} onClose={() => setInfo(null)} title="Form only">
        {info && <>
          <p className="mb-3 text-[14.5px] text-tg-sub">{leadName(info)} filled the form but hasn’t messaged on Telegram yet. You can contact them directly:</p>
          {[['Phone', info.phone], ['Email', info.email], ['Wants', info.service === 'funnel' ? 'Funnel' : 'Ad account'], ['Has BM', info.has_bm], ['Advertises', info.niche], ['Budget', info.budget], ['Landing page', info.theme], ['Came', new Date(info.created_at).toLocaleString()]].filter(x => x[1]).map(([k, v]) => <div key={k} className="flex justify-between border-b border-tg-line py-2.5"><span className="text-tg-sub">{k}</span><span>{v}</span></div>)}
          <div className="flex justify-between border-b border-tg-line py-2.5"><span className="text-tg-sub">Call list</span><span>{info.call_agent_name || (Date.now() - info.created_at < 10 * 60000 ? 'After 10 min' : '—')}</span></div>
          {info.call_state && <p className="mt-2 text-[13px] text-tg-sub">{CALL_LABEL[info.call_state]?.[0]} by {info.call_by}{info.call_at ? ' · ' + new Date(info.call_at).toLocaleString() : ''}{info.call_note ? ` — “${info.call_note}”` : ''}</p>}
          <div className="mt-4"><CallActions key={info.id + (info.call_state || '')} l={info} onMark={async (state, note) => { await api('call_mark', { lead_id: info.id, state, note }); toast(state ? 'Marked' : 'Undone'); await reload(); }} /></div>
        </>}
      </Sheet>
    </Page>
  );
}

/* ---------------- Team: leaderboard + agents ---------------- */
const dur = (m: number) => (m >= 60 ? `${Math.floor(m / 60)}h ${m % 60}m` : `${m}m`);
const tm = (ms: number) => new Date(ms).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
const replyTxt = (ms: number | null | undefined) => (ms == null ? '—' : ms < 60000 ? '<1m' : Math.round(ms / 60000) + 'm');
const singleDay = (r: Range) => r === 'today' || r === 'yesterday' || (/^d:\d{4}-\d{2}-\d{2}$/.test(r));
const KIND_L: [string, string][] = [['agency', 'Agency'], ['premium', 'Premium'], ['full', 'Full access'], ['fb', 'FB account'], ['funnel', 'Funnel'], ['other', 'Other']];
const commTxt = (a: { role?: string; comm_per_sale: number; comm_premium?: number | string | null; comm_funnel?: number | string | null }) => (a.role === 'manager' ? 'no commission' : `$${a.comm_per_sale}/sale${a.comm_premium != null && a.comm_premium !== '' ? ` · Premium $${a.comm_premium}` : ''}${Number(a.comm_funnel) > 0 ? ` · Funnel $${a.comm_funnel}` : ''}`);

function Team({ api, go }: { api: Api; go: Go }) {
  const toast = useToast();
  const [view, setView] = useState<'board' | 'agents'>('board');
  const [range, setRange] = useState<Range>('today');
  const [sort, setSort] = useState<'profit' | 'sales' | 'conv' | 'reply' | 'active'>('profit');
  const [sum, setSum] = useState<any>(null);
  const [agents, setAgents] = useState<Agent[]>([]);
  const [edit, setEdit] = useState<Partial<Agent> & { password?: string } | null>(null);
  const [payFor, setPayFor] = useState<number | null>(null); // v141: cash / offline payout for this agent
  const [bonusOpen, setBonusOpen] = useState(false); // v159: incentive to the agents
  const [pwFocus, setPwFocus] = useState(false);
  const [busy, setBusy] = useState(false);
  const loadAgents = useCallback(() => api('agents').then(r => setAgents(r.agents)).catch(() => {}), [api]);
  useEffect(() => { api(`leaderboard?range=${range}`).then(r => setSum({ ...r, _r: range })).catch(() => setSum({ rows: [], _r: range })); }, [api, range]); // v160: old numbers stay (dimmed) while loading
  useEffect(() => { void loadAgents(); }, [loadAgents]);
  async function save() {
    if (!edit) return; setBusy(true);
    try { await api('agent_save', { ...edit, receive: edit.receive ?? 1 }); toast(edit.id ? 'Agent updated' : 'Agent added. Share the username and password with them.'); setEdit(null); await loadAgents(); }
    catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); }
  }
  async function act(path: string, body: any, msg: string) { try { await api(path, body); toast(msg); await loadAgents(); } catch (e) { toast((e as Error).message, 'err'); } }
  const board: any[] | null = sum?.rows ? [...sum.rows].sort((a, b) => sort === 'sales' ? b.sales - a.sales || b.profit - a.profit : sort === 'conv' ? (b.conv_pct ?? -1) - (a.conv_pct ?? -1) : sort === 'reply' ? (a.avg_resp ?? 9e15) - (b.avg_resp ?? 9e15) : sort === 'active' ? (b.active_min || 0) - (a.active_min || 0) : 0) : null;
  const rank = new Map<number, number>((sum?.rows || []).map((r: any, i: number) => [r.id, i]));
  // "Best at": from the server's awards (or worked out here if missing)
  const aw = sum?.awards || {};
  const best: [string, any, (v: any) => string, any][] = ([
    ['Most profitable', aw.most_profitable, (v: number) => usd(v), Trophy],
    ['Best conversion', aw.best_converter, (v: number) => v + '%', Medal],
    ['Fastest reply', aw.fastest_reply, (v: number) => replyTxt(v), Zap],
    ['Most Premium', aw.most_premium, (v: number) => `${v} account${v === 1 ? '' : 's'}`, Crown],
    ['Most active', aw.most_active, (v: number) => dur(v), Activity],
    ['Cheapest closer', aw.cheapest_closer, (v: number) => `${usd(v)} per sale`, CircleDollarSign],
    ['Best profit per chat', aw.best_profit_per_chat, (v: number) => `${usd(v)} a chat`, BarChart3],
  ] as [string, any, (v: any) => string, any][]).filter(([, w]) => w && w.value != null && Number(w.value) !== 0);
  const pwRef = useRef<HTMLInputElement>(null);
  useEffect(() => { if (edit && pwFocus) { const t = setTimeout(() => pwRef.current?.focus(), 300); setPwFocus(false); return () => clearTimeout(t); } }, [edit, pwFocus]);
  return (
    <Page title="Team" action={<button type="button" aria-label="Add agent" className="af-iconbtn af-press" onClick={() => { setView('agents'); setEdit({ name: '', username: '', password: '', comm_per_sale: 2, receive: 1, role: 'agent', lines: 'agency' }); }}><Plus size={20} /></button>}
      right={<>{view === 'board' && <RangePick value={range} onChange={setRange} />}<Seg full className="w-full basis-full" value={view} onChange={setView} items={[['board', 'Leaderboard'], ['agents', `Agents${agents.length ? ` · ${agents.length}` : ''}`]]} /></>}>
      {view === 'board' ? (
        <>
          {!board ? <Skeleton rows={3} h={140} /> : !board.length ? <EmptyState text="Add agents to see the leaderboard." /> : (
            <div className={clsx('af-sec transition-opacity duration-150', sum._r !== range && 'opacity-60')}>
              {sum?.total && (
                <div className="af-card mb-3 overflow-hidden" data-team-total>
                  <div className="px-4 pb-3.5 pt-3.5">
                    <p className="flex items-center gap-1 text-[13.5px] font-medium text-tg-sub">Team net profit<InfoTip title="How profit is counted">
                      <p>{usd(sum.total.revenue)} sales{sum.total.web?.n ? ' (incl. website orders)' : ''} + {usd(sum.total.topup_fees)} fees − {usd(sum.total.spend)} ads − {usd(sum.total.acct_cost)} accounts − {usd(sum.total.sale_comm)} commission{sum.total.bonus ? <> · incentive {usd(sum.total.bonus)} not taken off</> : null}.</p>
                      {(sum.total.wa?.n > 0 || sum.total.web?.n > 0 || sum.off?.profit) ? <p className="mt-2">Not on any agent: {[sum.total.wa?.n > 0 && `${sum.total.wa.n} sale${sum.total.wa.n === 1 ? '' : 's'} added by the admin (${usd(sum.total.wa.revenue)})`, sum.total.web?.n > 0 && `${sum.total.web.n} website order${sum.total.web.n === 1 ? '' : 's'} (${usd(sum.total.web.revenue)})`, sum.off && `team costs ${usd(sum.off.spend)} ads`].filter(Boolean).join(' · ')}. Same total as Home → Net profit.</p> : null}
                      <p className="mt-2">Profit = revenue + top-up fees − ad cost − account cost (${sum?.acct_cost ?? 3} each) − commission. {sum?.meta_on ? 'Ad cost (from Meta): each chat costs what its campaign spent that day ÷ that campaign’s chats that day; chats with no campaign share the rest of the page’s spend. Per sale counts new buyers only.' : 'Ad cost: each page’s spend split by the leads each person got from it.'} Reply time counts working hours only.</p>
                    </InfoTip></p>
                    <p className={clsx('af-hero-num mt-0.5', sum.total.profit >= 0 ? 'text-tg-text' : 'text-tg-bad')} data-team-profit>{money(sum.total.profit)}</p>
                    <SplitBar className="mt-3" fmt={usd} parts={[['Sales', Number(sum.total.revenue) + Number(sum.total.topup_fees || 0), '#34C759'], ['Ads', Number(sum.total.spend), '#FF6B5E'], ['Accounts', Number(sum.total.acct_cost), '#8E8E93'], ['Comm.', Number(sum.total.sale_comm), '#E8902A']]} />
                  </div>
                  {sum.lines?.length > 0 && <div className="af-grid2 border-t border-tg-sep">
                    {sum.lines.map((l: any) => (
                      <div key={l.line}>
                        <Tag tone={l.line === 'funnel' ? 'fun' : 'acc'}>{l.line === 'funnel' ? 'Funnel ads' : 'Agency ads'}</Tag>
                        <p className="mt-1.5 text-[14px] af-num"><b className="font-semibold">{usd(l.spend)}</b> <span className="text-tg-sub">· {pS(l.leads, 'lead')}</span></p>
                        <p className="text-[12.5px] text-tg-sub af-num">{usd(l.cpl)} lead · {usd(l.cpa)} sale</p>
                      </div>
                    ))}
                  </div>}
                </div>
              )}
              {best.length > 0 && (
                <div className="mb-3 grid grid-cols-2 gap-2" data-best-at>
                  {best.map(([l, w, f, I]) => (
                    <div key={l} className="af-card flex min-w-0 items-center gap-2.5 px-3 py-2.5">
                      <Avatar name={w.name} id={w.id} size={32} />
                      <span className="min-w-0"><span className="flex items-center gap-1 text-[11.5px] text-tg-sub"><I size={12} className="shrink-0 text-tg-gold" /><span className="truncate">{l}</span></span><span className="block truncate text-[13.5px] font-semibold">{w.name} · <span className="tabular-nums">{f(w.value)}</span></span></span>
                    </div>
                  ))}
                </div>
              )}
              <Chips className="-mx-4 mb-2.5 px-4 md:mx-0 md:px-0" value={sort} onChange={setSort} items={[['profit', 'Profit'], ['sales', 'Sales'], ['conv', 'Conversion'], ['reply', 'Reply time'], ['active', 'Active']]} />
              <Group avs data-board>
                {board.map(a => <AgentCard key={a.id} a={a} i={rank.get(a.id) ?? 0} range={range} maxP={Math.max(1, ...board.map(x => Math.abs(Number(x.profit) || 0)))} onOpen={() => go('chats', { agent: a.id })} />)}
              </Group>
            </div>
          )}
        </>
      ) : (
        <>
          <div className="mb-3 flex flex-wrap gap-2"><Btn onClick={() => setEdit({ name: '', username: '', password: '', comm_per_sale: 2, receive: 1, role: 'agent', lines: 'agency' })}><Plus size={17} />Add agent</Btn><Btn kind="green" onClick={() => setBonusOpen(true)}><Gift size={17} />Give incentive</Btn></div>
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            {agents.map(a => (
              <div key={a.id} className="af-card p-4" data-agent-row={a.id}>
                <div className="flex items-center gap-3">
                  <span className="relative shrink-0"><Avatar name={a.name} id={a.id} size={42} /><PresenceDot on={(a as any).online_now} /></span>
                  <div className="min-w-0 flex-1"><p className="flex flex-wrap items-center gap-1.5 text-[16px] font-semibold">{a.name}{a.role === 'manager' ? <LineChip k="manager" /> : String(a.lines || 'agency').split(',').map((l: string) => <LineChip key={l} k={l === 'funnel' ? 'funnel' : l === 'premium' ? 'premium' : 'agency'} />)}{a.role !== 'manager' && String(a.chans || 'tg').includes('wa') && <LineChip k="wa" />}</p><p className="truncate text-[13px] text-tg-sub" data-seen={a.id}>@{a.username} · {seenLine(a as any)}</p><p className="truncate text-[12px] text-tg-sub">{a.receive ? 'Receiving leads' : a.auto_off_at ? 'Paused automatically (3 missed chats)' : 'Paused'}</p></div>
                  <Toggle on={!!a.receive} onChange={v => void act('agent_toggle', { id: a.id, receive: v }, v ? `${a.name} will receive new leads` : `${a.name} paused`)} label="Receive leads" />
                </div>
                <div className="mt-3 grid grid-cols-3 gap-2 text-center text-[13px]">
                  <div className="rounded-[10px] bg-tg-panel2 px-1 py-2"><p className="text-tg-sub">Commission</p><b className="block truncate">{a.role === 'manager' ? 'none' : `$${a.comm_per_sale}${a.comm_premium != null && a.comm_premium !== '' ? ` · P $${a.comm_premium}` : ''}${Number(a.comm_funnel) > 0 ? ` · F $${a.comm_funnel}` : ''}`}</b></div>
                  <div className="rounded-[10px] bg-tg-panel2 py-2"><p className="text-tg-sub">Open chats</p><b>{a.chats}</b></div>
                  <div className="rounded-[10px] bg-tg-panel2 py-2"><p className="text-tg-sub">Balance</p><b className="text-tg-ok">{usd(a.wallet.available)}</b></div>
                </div>
                <p className="mt-2 text-[12.5px] text-tg-sub">{commTxt(a)} · Telegram alerts: {a.tg_chat_id ? 'connected' : 'not connected (agent can connect from the app menu)'}</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  <Btn kind="ghost" size="sm" onClick={() => setEdit({ ...a, password: '' })}>Edit</Btn>
                  <Btn kind="ghost" size="sm" onClick={() => { setEdit({ ...a, password: '' }); setPwFocus(true); }}><KeyRound size={15} />Reset password</Btn>
                  {a.role !== 'manager' && <Btn kind="ghost" size="sm" onClick={() => setPayFor(a.id)}>Record payout</Btn>}
                  <Btn kind="ghost" size="sm" onClick={() => { if (confirm(`Log ${a.name} out on all phones? They need the password to log in again.`)) void act('agent_logout', { id: a.id }, `${a.name} was logged out on all phones`); }}>Log out phones</Btn>
                  <Btn kind="danger" size="sm" onClick={() => { if (confirm(`Remove ${a.name}? Their chats stay in the system.`)) void act('agent_delete', { id: a.id }, 'Agent removed'); }}>Remove</Btn>
                </div>
              </div>
            ))}
          </div>
          {!agents.length && <EmptyState text="No agents yet. Add your agents and share their username and password." />}
        </>
      )}
      <Sheet open={bonusOpen} onClose={() => { setBonusOpen(false); void loadAgents(); }} title="Give incentive">{bonusOpen && <BonusPanel api={api} onDone={() => void loadAgents()} />}</Sheet>
      <Sheet open={payFor != null} onClose={() => { setPayFor(null); void loadAgents(); }} title="Record payout" wide>{payFor != null && <CashPayouts api={api} role="admin" agentId={payFor} />}</Sheet>
      <Sheet open={!!edit} onClose={() => setEdit(null)} title={edit?.id ? 'Edit agent' : 'Add agent'}>
        {edit && <>
          <Field label="Name"><input className={inputCls} value={edit.name || ''} onChange={e => setEdit({ ...edit, name: e.target.value })} /></Field>
          <Field label="Username (for login)" hint="Letters, numbers, dot, dash or underscore."><input className={inputCls} autoCapitalize="none" value={edit.username || ''} onChange={e => setEdit({ ...edit, username: e.target.value.toLowerCase() })} /></Field>
          <Field label={edit.id ? 'New password (leave empty to keep)' : 'Password'} hint="At least 6 characters. Changing it logs the agent out everywhere."><input ref={pwRef} className={inputCls} value={edit.password || ''} onChange={e => setEdit({ ...edit, password: e.target.value })} /></Field>
          <Field label="Role" hint={edit.role === 'manager' ? 'Manager gets website orders, top-ups, funnel leads and requests agents send, and approves everything directly. With “Receive new leads” ON the manager also takes ad account chats in turn with the agents (4 chats → 3 agents + manager). No commission: the manager’s sales count as the business’s earnings.' : 'Agent chats with leads and earns commission per sale.'}>
            <select className={inputCls} value={edit.role || 'agent'} onChange={e => setEdit({ ...edit, role: e.target.value })}>
              <option value="agent">Agent</option><option value="manager">Manager</option>
            </select>
          </Field>
          {edit.role !== 'manager' && (
            <Field label="Takes chats from" hint="Agency = ad account chats (main page). Funnel = funnel chats, only used when Settings → Team & messages → 'Funnel leads to agents' is ON. Premium = chats from /premium. OFF for everyone by default, so the manager handles them.">
              <div className="grid grid-cols-3 gap-2">
                {(['agency', 'funnel', 'premium'] as const).map(l => {
                  const cur = String(edit.lines || 'agency').split(',').filter(Boolean);
                  const on = cur.includes(l);
                  return <button key={l} type="button" aria-pressed={on} onClick={() => { const next = on ? cur.filter(x => x !== l) : [...cur, l]; setEdit({ ...edit, lines: (next.some(x => x !== 'premium') ? next : [...next.filter(x => x !== 'agency'), l === 'agency' ? 'funnel' : 'agency']).join(',') }); }}
                    className={clsx('af-press flex items-center justify-center gap-1 rounded-xl border-2 px-2 py-2.5 text-[14px] font-medium', on ? 'border-tg-acc bg-tg-acc/10' : 'border-transparent bg-tg-input text-tg-sub')}>{on && <CheckCircle2 size={15} className="text-tg-link" />}{l === 'agency' ? 'Agency' : l === 'funnel' ? 'Funnel' : 'Premium'}</button>;
                })}
              </div>
            </Field>
          )}
          {edit.role !== 'manager' && (
            <Field label="Chats on" hint="Telegram, WhatsApp or both. WhatsApp chats go only to agents with WhatsApp ticked (nobody → the manager). The manager always sees both.">
              <div className="grid grid-cols-2 gap-2" data-chans>
                {(['tg', 'wa'] as const).map(c => {
                  const cur = String(edit.chans || 'tg').split(',').filter(Boolean);
                  const on = cur.includes(c);
                  return <button key={c} type="button" data-chan-opt={c} aria-pressed={on} onClick={() => { const next = on ? cur.filter(x => x !== c) : [...cur, c]; setEdit({ ...edit, chans: (next.length ? next : [c === 'tg' ? 'wa' : 'tg']).join(',') }); }}
                    className={clsx('af-press flex items-center justify-center gap-1 rounded-xl border-2 px-3 py-2.5 text-[14px] font-medium', on ? 'border-tg-acc bg-tg-acc/10' : 'border-transparent bg-tg-input text-tg-sub')}>{on && <CheckCircle2 size={15} className="text-tg-link" />}{c === 'tg' ? 'Telegram' : 'WhatsApp'}</button>;
                })}
              </div>
            </Field>
          )}
          {edit.role !== 'manager' && (
            <Field label="Commission per sale (USD)" hint="Agent earns this per account sold. Top-ups give no agent commission."><input className={inputCls} type="number" step="0.5" value={edit.comm_per_sale ?? 2} onChange={e => setEdit({ ...edit, comm_per_sale: Number(e.target.value) })} /></Field>
          )}
          {edit.role !== 'manager' && String(edit.lines || '').split(',').includes('premium') && (
            <Field label="Premium commission per account (USD)" hint="For Premium ad account sales. Empty = same as the normal commission."><input className={inputCls} type="number" step="0.5" value={edit.comm_premium ?? ''} placeholder={String(edit.comm_per_sale ?? 2)} onChange={e => setEdit({ ...edit, comm_premium: e.target.value === '' ? '' : Number(e.target.value) })} /></Field>
          )}
          {edit.role !== 'manager' && (
            <Field label="Funnel commission per sale ($)" hint="For landing page + funnel sales (per month sold). Empty or 0 = no commission on funnel sales."><input className={inputCls} type="number" step="0.5" min="0" data-comm-funnel value={edit.comm_funnel ?? ''} placeholder="0" onChange={e => setEdit({ ...edit, comm_funnel: e.target.value === '' ? '' : Number(e.target.value) })} /></Field>
          )}
          {edit.id ? (
            <Field label="Phone alerts" hint="OFF = this person's phone does not ring when it is on silent / vibrate (normal notifications with the team sound still come). Also in Settings → Phone notifications.">
              <ToggleRow k="ring_off" title="Ring on silent / vibrate" on={!edit.ring_off} onChange={v => setEdit({ ...edit, ring_off: v ? 0 : 1 })} className="!mb-0" />
            </Field>
          ) : null}
          {edit.role !== 'manager' && (
            <Field label="Ad accounts (our BMs)" hint="ON = paid by crypto link (or from the client’s credit) → done at once, no manager step. OFF = the manager approves. UPI always needs the manager.">
              <ToggleRow title="Auto-approve ad accounts" on={!!edit.auto_acct} onChange={v => setEdit({ ...edit, auto_acct: v ? 1 : 0 })} className="!mb-2" />
              <ToggleRow title="Auto-approve top-ups" on={!!edit.auto_topup} onChange={v => setEdit({ ...edit, auto_topup: v ? 1 : 0 })} className="!mb-0" />
            </Field>
          )}
          {edit.role === 'manager' && (
            <Field label="Manager takes these chats" hint="Agency = normal ad account chats in turn with the agents (same as “Receive new leads”). Funnel / Premium = those chats come to you. Switch one OFF and it goes to the agents tagged for it (nobody tagged → still you, so no chat is lost).">
              <div className="grid grid-cols-3 gap-2">
                {(['agency', 'funnel', 'premium'] as const).map(l => {
                  const ml = String(edit.mgr_lines ?? 'funnel,premium').split(',').filter(Boolean);
                  const on = l === 'agency' ? !!(edit.receive ?? 1) : ml.includes(l);
                  const flip = () => l === 'agency' ? setEdit({ ...edit, receive: on ? 0 : 1 }) : setEdit({ ...edit, mgr_lines: (on ? ml.filter(x => x !== l) : [...ml, l]).join(',') });
                  return <button key={l} type="button" aria-pressed={on} onClick={flip} className={clsx('af-press flex items-center justify-center gap-1 rounded-xl border-2 px-2 py-2.5 text-[14px] font-medium', on ? 'border-tg-acc bg-tg-acc/10' : 'border-transparent bg-tg-input text-tg-sub')}>{on && <CheckCircle2 size={15} className="text-tg-link" />}{l === 'agency' ? 'Agency' : l === 'funnel' ? 'Funnel' : 'Premium'}</button>;
                })}
              </div>
            </Field>
          )}
          <ToggleRow title="Receive new leads" on={!!(edit.receive ?? 1)} onChange={v => setEdit({ ...edit, receive: v ? 1 : 0 })} className="!mb-4" />
          <Btn busy={busy} onClick={() => void save()} className="w-full">{edit.id ? 'Save changes' : 'Add agent'}</Btn>
        </>}
      </Sheet>
    </Page>
  );
}

/** v136: one agent on the leaderboard. Missing fields hide their block. */
/** v159: incentive / bonus — the total is shared equally by the agents with receiving leads ON (not the manager). */
function BonusPanel({ api, onDone }: { api: Api; onDone: () => void }) {
  const toast = useToast();
  const [d, setD] = useState<{ agents: { id: number; name: string }[]; history: any[] } | null>(null);
  const [amt, setAmt] = useState(''); const [note, setNote] = useState(''); const [busy, setBusy] = useState(false);
  const load = useCallback(() => api('bonus_info').then(setD).catch(e => toast((e as Error).message, 'err')), [api, toast]);
  useEffect(() => { void load(); }, [load]);
  const n = d?.agents.length || 0; const total = Number(amt) || 0;
  const each = n && total > 0 ? Math.floor(Math.round(total * 100) / n) / 100 : 0;
  const odd = n && total > 0 && Math.round(each * 100) * n !== Math.round(total * 100);
  async function give() {
    if (!d || !(total > 0) || !n) return;
    if (!confirm(`Give ${usd(total)} incentive?\n${d.agents.map(a => a.name).join(', ')} ${n === 1 ? 'gets' : 'get'} ${usd(each)}${odd ? ' (a cent more for the first)' : ''}${n === 1 ? '' : ' each'}.`)) return;
    setBusy(true);
    try { const r = await api('bonus_give', { amount: total, note, ids: d.agents.map(a => a.id) }); toast(`${usd(r.total)} incentive added · ${r.agents.length} agents notified`); setAmt(''); setNote(''); await load(); onDone(); }
    catch (e) { toast((e as Error).message, 'err'); await load(); } finally { setBusy(false); }
  }
  async function del(batch: number) {
    if (!confirm('Remove this incentive from every agent it went to?')) return;
    try { await api('bonus_delete', { batch }); toast('Incentive removed'); await load(); onDone(); } catch (e) { toast((e as Error).message, 'err'); }
  }
  if (!d) return <Skeleton rows={2} h={60} />;
  return (
    <div data-bonus>
      <p className="mb-3 text-[13px] leading-relaxed text-tg-sub">Shared equally by the agents with <b>Receiving leads ON</b> (the manager gets none). It goes into their earnings and wallet and they get a notification. It is your separate account: net profit does not take it off (Home → My income shows profit after incentive too).</p>
      <Field label="Total incentive (USD)"><input className={inputCls} type="number" inputMode="decimal" placeholder="e.g. 30" value={amt} onChange={e => setAmt(e.target.value)} /></Field>
      <Field label="Note (optional, the agents see it)"><input className={inputCls} maxLength={120} placeholder="e.g. Great sales today" value={note} onChange={e => setNote(e.target.value)} /></Field>
      <div className="mb-3 rounded-xl bg-tg-input px-4 py-3 text-[14px]">
        {!n ? <span className="text-tg-orange">No agent has receiving leads ON.</span> : <>
          <div className="flex justify-between"><span className="text-tg-sub">Agents ({n})</span><span className="text-right">{d.agents.map(a => a.name).join(', ')}</span></div>
          <div className="mt-1 flex justify-between"><span className="text-tg-sub">Each gets</span><b className="text-tg-ok">{total > 0 ? usd(each) + (odd ? ' +1¢ for the first' : '') : '—'}</b></div>
        </>}
      </div>
      <Btn kind="green" className="w-full" busy={busy} disabled={!(total > 0) || !n} onClick={() => void give()}><Gift size={17} />Give incentive</Btn>
      {d.history.length > 0 && <>
        <h4 className="mb-1 mt-5 text-[13px] font-semibold uppercase tracking-wide text-tg-sub">History</h4>
        {d.history.map(h => <div key={h.batch} className="border-b border-tg-line py-2 text-[13.5px]" data-bonus-row>
          <div className="flex items-center gap-2"><b className="flex-1">{usd(h.total)} · {h.n} agent{h.n === 1 ? '' : 's'}</b><span className="text-[12px] text-tg-sub">{listTime(h.at)}</span>{h.can_delete && <button className="text-[12.5px] text-tg-bad" onClick={() => void del(h.batch)}>Remove</button>}</div>
          <p className="text-[12px] text-tg-sub">{h.agents.map((x: any) => `${x.name || 'removed'} ${usd(x.amount)}`).join(' · ')}{h.note ? ` · ${h.note}` : ''}</p>
        </div>)}
      </>}
    </div>
  );
}

function AgentCard({ a, i, range, onOpen, maxP = 1 }: { a: any; i: number; range: Range; onOpen: () => void; maxP?: number }) {
  const [more, setMore] = useState(false);
  const top = i === 0 && a.sales > 0;
  const mgr = a.role === 'manager';
  const medal = i < 3 ? ['text-tg-medal1', 'text-tg-medal2', 'text-tg-medal3'][i] : 'text-tg-sub';
  const kinds = a.by_kind ? KIND_L.filter(([k]) => a.by_kind[k] && (a.by_kind[k].n || a.by_kind[k].accts)) : [];
  const formula = kinds.filter(([k]) => a.by_kind[k].comm > 0).map(([k, l]) => { const x = a.by_kind[k]; const q = x.accts || x.n; return `${q} × ${usd(x.comm / q)} ${l}`; });
  const act = a.active_min > 0 ? (singleDay(range)
    ? `In app ${dur(a.active_min)}${a.first_at ? ` · ${tm(a.first_at)} – ${tm(a.last_at)}` : ''}`
    : `In app ${dur(a.active_min)}${a.active_days ? ` · ${a.active_days} day${a.active_days === 1 ? '' : 's'} active` : ''}${a.first_at ? ` · first ${tm(a.first_at)}, last ${tm(a.last_at)}` : ''}`) : 'Not in the app';
  const cell = (k: string, v: React.ReactNode, sub?: React.ReactNode) => <div key={k} className="min-w-0 rounded-[10px] bg-tg-panel2 px-2 py-2"><p className="truncate text-[11px] text-tg-sub">{k}</p><p className="truncate font-semibold tabular-nums">{v}</p>{sub && <p className="truncate text-[10.5px] text-tg-sub">{sub}</p>}</div>;
  const pct = Math.min(100, Math.round((Math.abs(Number(a.profit) || 0) / maxP) * 100));
  return (
    <div data-agent-card={a.id} className="af-rowwrap relative">
      {/* v167: a compact ranked row; tap = details inline (Open chats is inside) */}
      <button type="button" onClick={() => setMore(m => !m)} aria-expanded={more} className="af-row !items-start !py-3">
        <span className={clsx('mt-[11px] w-4 shrink-0 text-center text-[14px] font-semibold af-num', medal)}>{i + 1}</span>
        <span className="relative shrink-0"><Avatar name={a.name} id={a.id} size={40} /><PresenceDot on={a.online_now} size="sm" /></span>
        <span className="min-w-0 flex-1">
          <span className="flex items-center gap-2">
            <span className="flex min-w-0 flex-1 items-center gap-1.5"><span className="truncate text-[15.5px] font-semibold">{a.name}</span>{mgr && <Tag tone="prem">Manager</Tag>}{top && <Crown size={14} className="shrink-0 text-tg-gold" />}</span>
            <span className={clsx('shrink-0 text-[16px] font-bold af-num', a.profit >= 0 ? 'text-tg-ok' : 'text-tg-bad')}>{usdS(a.profit)}</span>
          </span>
          <span className="mt-0.5 block truncate text-[13px] text-tg-sub af-num"><b className="font-semibold text-tg-text">{a.sales}</b> sale{a.sales === 1 ? '' : 's'} · <b className="font-semibold text-tg-text">{a.conv_pct == null ? '—' : a.conv_pct + '%'}</b> conv · <b className="font-semibold text-tg-text">{replyTxt(a.avg_resp)}</b> reply</span>
          <span className="af-bar mt-2 !h-[5px]"><i style={{ width: pct + '%', background: a.profit >= 0 ? 'rgb(var(--tg-acc))' : 'rgb(var(--tg-red))' }} /></span>
        </span>
      </button>
      {more && (
        <div className="af-sec px-4 pb-3.5" onClick={e => e.stopPropagation()}>
          <div className="grid grid-cols-4 gap-1.5 text-center" data-agent-ads>
            {cell('Chats', a.leads, a.low_data ? <span className="text-tg-orange">low data</span> : a.tagged_pct != null && a.tagged_pct < 100 ? `${a.tagged_pct}% ads` : undefined)}
            {cell('Ad cost', usd(a.ad_cost), a.roas != null ? `ROAS ${a.roas}x` : undefined)}
            {cell('Per chat', a.cost_per_chat == null ? '—' : usd(a.cost_per_chat))}
            {cell('ROI', <span className={a.roi == null ? 'text-tg-sub' : a.roi >= 0 ? 'text-tg-ok' : 'text-tg-bad'}>{a.roi == null ? '—' : a.roi + '%'}</span>)}
          </div>
          <p className="mt-2 text-[12.5px] text-tg-sub">{seenLine(a)} · {a.receive ? 'receiving leads' : 'paused'} · {commTxt(a)}</p>
          <p className="mt-1 flex items-center gap-1.5 text-[12.5px] text-tg-sub"><Clock size={13} className="shrink-0" /><span className="truncate">{act}</span></p>
          <p className="mt-1 text-[12.5px] text-tg-sub">Conversion: {a.period_chats != null ? `${a.period_buyers} bought of ${a.period_chats} active chats` : `${a.converted ?? a.sales} of ${a.leads} chats`} · Per sale {a.cpa_new == null ? '—' : usd(a.cpa_new)} ({a.buyers_new ?? 0} new buyer{a.buyers_new === 1 ? '' : 's'})</p>
          {kinds.length > 0 && (
            <div className="mt-2.5 rounded-[10px] bg-tg-panel2 px-3 py-2" data-acct-table>
              <table className="w-full text-[12.5px]">
                <thead><tr className="text-tg-sub"><th className="pb-1 text-left font-normal">Sold</th><th className="pb-1 text-right font-normal">Qty</th><th className="pb-1 text-right font-normal">Revenue</th><th className="pb-1 text-right font-normal">Comm.</th></tr></thead>
                <tbody>{kinds.map(([k]) => { const x = a.by_kind[k]; return <tr key={k} className="border-t border-tg-line"><td className="py-1"><LineChip k={k} size="xs" /></td><td className="text-right tabular-nums">{x.accts || x.n}</td><td className="text-right tabular-nums">{usd(x.rev)}</td><td className="text-right tabular-nums">{usd(x.comm)}</td></tr>; })}</tbody>
              </table>
              {formula.length > 0 && <p className="mt-1 text-[11.5px] text-tg-sub">{formula.join(' + ')} = {usd(a.sale_comm)}</p>}
              {a.by_ch && (a.by_ch.tg.n > 0 || a.by_ch.wa.n > 0) && <p className="mt-1.5 flex flex-wrap items-center gap-2 text-[12px]">{a.by_ch.tg.n > 0 && <span className="inline-flex items-center gap-1"><LineChip k="tg" size="xs" />{a.by_ch.tg.n} · {usd(a.by_ch.tg.rev)}</span>}{a.by_ch.wa.n > 0 && <span className="inline-flex items-center gap-1"><LineChip k="wa" size="xs" />{a.by_ch.wa.n} · {usd(a.by_ch.wa.rev)}</span>}</p>}
            </div>
          )}
          <div className="mt-2 grid grid-cols-3 gap-1.5 text-center">
            {cell('Leads', a.leads)}
            {cell('Top-ups', usd(a.topup_vol), `${a.topups_n ?? 0} · fees ${usd(a.topup_fees)}`)}
            {cell('Avg reply', replyTxt(a.avg_resp), a.replies_n ? `${a.replies_n} chats` : undefined)}
            {cell('Follow-ups', a.fu_sent != null ? `${a.fu_won}/${a.fu_sent}` : a.fu_pending, a.fu_sent != null ? 'won / sent' : 'due')}
            {cell('Ad cost', usd(a.ad_cost), a.cpa != null ? `${usd(a.cpa)} / sale` : undefined)}
            {cell('Account cost', usd(a.acct_cost))}
            {cell('Profit / chat', a.profit_per_chat == null ? '—' : usdS(a.profit_per_chat), 'fair compare')}
            {cell('New / repeat', `${a.sales_new ?? 0} / ${a.sales_repeat ?? 0}`, 'sales')}
            {cell('Premium', a.by_kind?.premium ? (a.by_kind.premium.accts || a.by_kind.premium.n) : 0, 'accounts sold')}
            {a.camps?.length > 0 && <div className="col-span-3 rounded-[10px] bg-tg-panel2 px-3 py-2 text-left" data-agent-camps>
              <table className="w-full text-[12px]"><thead><tr className="text-tg-sub"><th className="pb-1 text-left font-normal">Campaign</th><th className="pb-1 text-right font-normal">Chats</th><th className="pb-1 text-right font-normal">Cost</th><th className="pb-1 text-right font-normal">Buyers</th><th className="pb-1 text-right font-normal">Per sale</th></tr></thead>
                <tbody>{a.camps.map((c: any) => <tr key={c.camp} className="border-t border-tg-line"><td className="max-w-[9rem] truncate py-1">{c.camp || '(no campaign)'}</td><td className="text-right tabular-nums">{c.chats}</td><td className="text-right tabular-nums">{usd(c.cost)}</td><td className="text-right tabular-nums">{c.buyers}</td><td className="text-right tabular-nums">{c.cpa == null ? '—' : usd(c.cpa)}</td></tr>)}</tbody></table>
            </div>}
          </div>
          <Btn kind="soft" size="sm" className="mt-2.5" onClick={onOpen}><MessagesSquare size={15} />Open {a.name}’s chats</Btn>
        </div>
      )}
    </div>
  );
}

/* ---------------- v135: Telegram vs WhatsApp — activity + profit by line and app ---------------- */
function Compare({ api, back }: { api: Api; back?: () => void }) {
  const [range, setRange] = useState<Range>('today');
  const [d, setD] = useState<any>(null);
  const load = useCallback(() => api<any>(`ch_report?range=${range}`).then(setD).catch(() => setD({ err: true })), [api, range]);
  useEffect(() => { void load(); }, [load]);
  useInterval(() => void load(), 30000);
  const LNS = [['agency', 'Agency'], ['premium', 'Premium'], ['funnel', 'Funnel']] as const;
  const CHN = { tg: 'Telegram', wa: 'WhatsApp' } as const;
  const chip = (c: 'tg' | 'wa') => <LineChip k={c} />;
  const money$ = (v: number) => <span className={v < 0 ? 'text-tg-bad' : v > 0 ? 'text-tg-ok' : ''}>{v < 0 ? '−' + usd(-v) : usd(v)}</span>;
  return (
    <Page title="Telegram vs WhatsApp" back={back} right={<RangePick value={range} onChange={setRange} />}>
      {!d ? <Skeleton rows={3} h={120} /> : d.err ? <p className="text-tg-sub">Could not load.</p> : (<div data-compare>
        {/* v167: profit hero per app, then one side-by-side table (TG | WA) with the better value bold */}
        <div className="af-card af-grid2 mb-3 overflow-hidden" data-ch-heroes>
          {(['tg', 'wa'] as const).map(c => { const t = d.total[c]; return (
            <div key={c} data-ch-card={c}>
              <p className="flex items-center gap-1.5 text-[13px] font-medium text-tg-sub">{c === 'tg' ? <TgGlyph size={14} /> : <WaGlyph size={14} />}{CHN[c]} profit</p>
              <p className="af-mid-num mt-0.5">{money$(t.profit)}</p>
              <p className="text-[12px] text-tg-sub af-num">{pS(t.sales, 'sale')} · {usd(t.revenue)}</p>
            </div>
          ); })}
        </div>
        {d.best && <div className="af-note warn mb-3 items-center"><Trophy size={18} className="shrink-0 text-tg-gold" /><p className="text-[14px]">Most profitable: <b>{LNS.find(x => x[0] === d.best.line)?.[1]} on {CHN[d.best.ch as 'tg']}</b> · {money$(d.best.profit)}</p></div>}
        {(() => {
          const a = d.activity, t = d.total;
          // [label, tg, wa, shown, higher is better?]
          const R: [string, number | null, number | null, (v: number | null, c: 'tg' | 'wa') => React.ReactNode, boolean | null][] = [
            ['New chats', t.tg.leads, t.wa.leads, v => v, true], ['Chats talking', a.tg.chats_active, a.wa.chats_active, v => v, true],
            ['Messages in / out', a.tg.msgs_in, a.wa.msgs_in, (_v, c) => `${a[c].msgs_in} / ${a[c].msgs_out}`, null], ['Waiting for reply', a.tg.unanswered, a.wa.unanswered, v => v, false],
            ['Open chats', a.tg.open, a.wa.open, v => v, null], ['Avg first reply', a.tg.avg_reply_min, a.wa.avg_reply_min, v => (v == null ? '—' : v + 'm'), false],
            ['Sales', t.tg.sales, t.wa.sales, v => v, true], ['Revenue', t.tg.revenue, t.wa.revenue, v => usd(v), true], ['Top-up fees', t.tg.fees, t.wa.fees, v => usd(v), true],
            ['Ad spend', t.tg.spend, t.wa.spend, v => usd(v), null], ['Account cost', t.tg.acct, t.wa.acct, v => usd(v), null], ['Commission', t.tg.comm, t.wa.comm, v => usd(v), null],
          ];
          const win = (x: number | null, y: number | null, hi: boolean | null) => hi == null || x == null || y == null || x === y ? false : hi ? x > y : x < y;
          return (
            <div className="af-card mb-3 overflow-hidden" data-ch-table>
              <div className="grid grid-cols-[minmax(0,1fr)_84px_84px] px-4 py-2 text-[12.5px] font-semibold text-tg-sub"><span /><span className="flex items-center justify-end gap-1"><TgGlyph size={13} />TG</span><span className="flex items-center justify-end gap-1"><WaGlyph size={13} />WA</span></div>
              {R.map(([k, x, y, f, hi]) => (
                <div key={k} className="af-sepabove relative grid grid-cols-[minmax(0,1fr)_84px_84px] items-center px-4 py-2 text-[14px]">
                  <span className="truncate text-tg-sub">{k}</span>
                  <span className={clsx('text-right af-num', win(x, y, hi) ? 'font-semibold text-tg-text' : 'text-tg-text/80')}>{f(x, 'tg')}</span>
                  <span className={clsx('text-right af-num', win(y, x, hi) ? 'font-semibold text-tg-text' : 'text-tg-text/80')}>{f(y, 'wa')}</span>
                </div>
              ))}
            </div>
          );
        })()}
        <div className="af-card mb-3 p-4">
          <p className="mb-2 flex items-center gap-1 font-semibold">Which line earns the most<InfoTip title="How profit is counted">Profit = sales + top-up fees − ad spend − account cost − commission. Ad spend comes from Ad spend (Agency / Premium / Funnel pages + channel pages → Telegram, WhatsApp pages → WhatsApp).</InfoTip></p>
          <div className="-mx-4 md:hidden" data-profit-rows>
            {LNS.flatMap(([l, ln]) => (['tg', 'wa'] as const).map(c => { const g = d.grid[c][l]; const top = d.best && d.best.ch === c && d.best.line === l; return (
              <div key={l + c} className={clsx('af-sepabove relative flex items-center gap-3 px-4 py-2.5', top && 'bg-tg-gold/10')}>
                {c === 'tg' ? <TgGlyph size={18} /> : <WaGlyph size={18} />}
                <span className="min-w-0 flex-1"><span className="block text-[14.5px] font-medium">{ln} <span className="font-normal text-tg-sub">· {CHN[c]}</span></span><span className="block truncate text-[12px] text-tg-sub af-num">{g.leads} chats · {g.sales} sales · {usd(g.revenue)} · fees {usd(g.fees)} · spend {usd(g.spend)}</span></span>
                <b className="shrink-0 text-[15px] af-num">{money$(g.profit)}</b>
              </div>
            ); }))}
          </div>
          <div className="hidden overflow-x-auto md:block"><table className="w-full min-w-[520px] text-[13px]" data-profit-table>
            <thead><tr className="text-tg-sub"><th className="sticky left-0 z-[1] bg-tg-panel py-1.5 text-left font-normal">Line</th><th className="text-left font-normal">App</th><th className="text-right font-normal">Chats</th><th className="text-right font-normal">Sales</th><th className="text-right font-normal">Revenue</th><th className="text-right font-normal">Fees</th><th className="text-right font-normal">Spend</th><th className="text-right font-normal">Profit</th></tr></thead>
            <tbody>{LNS.flatMap(([l, ln]) => (['tg', 'wa'] as const).map(c => { const g = d.grid[c][l]; const top = d.best && d.best.ch === c && d.best.line === l; return (
              <tr key={l + c} className={clsx('border-t border-tg-line', top && 'bg-tg-gold/10')}><td className="sticky left-0 z-[1] bg-tg-panel py-2 pr-2 font-medium">{ln}</td><td>{chip(c)}</td><td className="text-right tabular-nums">{g.leads}</td><td className="text-right tabular-nums">{g.sales}</td><td className="text-right tabular-nums">{usd(g.revenue)}</td><td className="text-right tabular-nums">{usd(g.fees)}</td><td className="text-right tabular-nums">{usd(g.spend)}</td><td className="text-right font-semibold tabular-nums">{money$(g.profit)}</td></tr>
            ); }))}</tbody>
          </table></div>
        </div>
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          {d.wa_ads_on !== false && <div className="af-card p-4" data-wa-pages>
            <p className="mb-2 flex items-center gap-2 font-semibold">{chip('wa')} ad pages</p>
            <div className="overflow-x-auto"><table className="w-full min-w-[320px] text-[13px]"><thead><tr className="text-tg-sub"><th className="text-left font-normal" />{LNS.map(([, n]) => <th key={n} className="text-right font-normal">{n}</th>)}</tr></thead>
              <tbody>{([['Visitors', 'visitors'], ['Tapped chat', 'chat_taps'], ['Started a chat', 'chats'], ['Community: numbers', 'community_numbers'], ['…messaged us', 'messaged'], ['…subscribed', 'subscribed']] as const).map(([k, f]) => <tr key={k} className="border-t border-tg-line"><td className="py-1.5 pr-2 text-tg-sub">{k}</td>{LNS.map(([l]) => <td key={l} className="text-right tabular-nums">{d.wa_pages[l][f]}</td>)}</tr>)}</tbody></table></div>
          </div>}
          <div className="af-card p-4">
            <p className="mb-2 flex items-center gap-2 font-semibold">{chip('tg')} channel pages</p>
            <div className="overflow-x-auto"><table className="w-full min-w-[320px] text-[13px]"><thead><tr className="text-tg-sub"><th className="text-left font-normal" />{LNS.map(([, n]) => <th key={n} className="text-right font-normal">{n}</th>)}</tr></thead>
              <tbody>{([['Visitors', 'visitors'], ['Join requests', 'join_requests'], ['Joined', 'joined']] as const).map(([k, f]) => <tr key={k} className="border-t border-tg-line"><td className="py-1.5 pr-2 text-tg-sub">{k}</td>{LNS.map(([l]) => <td key={l} className="text-right tabular-nums">{d.tg_pages[l][f]}</td>)}</tr>)}</tbody></table></div>
          </div>
        </div>
      </div>)}
    </Page>
  );
}

/* ---------------- Sale history (+ add a WhatsApp sale) ---------------- */
function SaleHist({ api, onOpenChat, back }: { api: Api; onOpenChat: (id: number) => void; back?: () => void }) {
  const [wa, setWa] = useState(false);
  const [ver, setVer] = useState(0);
  return (
    <Page title="Sale history" back={back} action={<button type="button" data-add-wa aria-label="Add WhatsApp sale" onClick={() => setWa(true)} className="af-iconbtn acc af-press"><Plus size={20} /></button>}>
      <SalesHistory api={api} onOpenChat={onOpenChat} reloadKey={ver} />
      <Sheet open={wa} onClose={() => { setWa(false); setVer(v => v + 1); }} title="WhatsApp sales" wide><WaSales api={api} /></Sheet>
    </Page>
  );
}

/* ---------------- Payouts ---------------- */
function PayoutList({ api, onChanged, mode = 'all', agent = '', onRows }: { api: Api; onChanged: () => void; mode?: 'pending' | 'paid' | 'all'; agent?: string; onRows?: (rows: any[]) => void }) {
  const toast = useToast();
  const [rows, setRows] = useState<any[] | null>(null);
  const [act, setAct] = useState<{ p: any; status: 'paid' | 'rejected' } | null>(null); const [note, setNote] = useState(''); const [busy, setBusy] = useState(false);
  const onRowsRef = useRef(onRows); onRowsRef.current = onRows;
  const load = useCallback(() => api('payouts').then(r => { setRows(r.rows); onRowsRef.current?.(r.rows); }).catch(() => {}), [api]);
  useEffect(() => { void load(); }, [load]);
  async function done() {
    if (!act) return; setBusy(true);
    try { await api('payout_update', { id: act.p.id, status: act.status, note }); toast(act.status === 'paid' ? 'Marked as paid. Agent notified.' : 'Request rejected. Agent notified.'); setAct(null); setNote(''); await load(); onChanged(); }
    catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); }
  }
  const list = (rows || []).filter(p => (mode === 'all' || (mode === 'pending' ? p.status === 'pending' : p.status === 'paid')) && (!agent || String(p.agent_id) === agent));
  return (
    <>
      {!rows ? <Skeleton rows={2} h={110} /> : !list.length ? <EmptyState text={mode === 'pending' ? 'No payout requests waiting.' : 'No payouts here.'} /> : (
        <div className="grid grid-cols-1 gap-3">
          {list.map(p => (
            <div key={p.id} className={clsx('af-card p-4', p.status === 'pending' && 'ring-1 ring-tg-orange/40')}>
              <div className="flex items-center gap-3"><Avatar name={p.agent_name || '?'} id={p.agent_id} size={42} />
                <div className="min-w-0 flex-1"><p className="font-semibold">{p.agent_name} <span className="ml-1 text-[18px] tabular-nums">{usd(p.amount)}</span></p><p className="truncate text-[13px] text-tg-sub">{p.kind === 'cash' ? payLine(p) : p.method === 'usdt' ? 'USDT BEP20' : 'Bank / UPI'} · {new Date(p.pay_date || p.created_at).toLocaleString()}</p></div>
                <span className={clsx('shrink-0 rounded-full px-2 py-0.5 text-[12px] font-semibold', p.status === 'paid' ? 'bg-tg-green/15 text-tg-ok' : p.status === 'pending' ? 'bg-tg-orange/15 text-tg-orange' : 'bg-tg-red/15 text-tg-bad')}>{p.status === 'paid' ? 'Paid' : p.status === 'pending' ? 'Pending' : 'Rejected'}</span>
              </div>
              {p.kind !== 'cash' && <button onClick={() => { void navigator.clipboard?.writeText(p.details); toast('Copied'); }} className="mt-3 block w-full break-all rounded-xl bg-tg-input px-3 py-2.5 text-left font-mono text-[13px]">{p.details}<span className="ml-2 font-sans text-[12px] text-tg-link">tap to copy</span></button>}
              {p.note && <p className="mt-2 text-[13px] text-tg-sub">Note: {p.note}</p>}
              {p.status === 'pending' && <div className="mt-3 flex gap-2"><Btn kind="green" className="flex-1" onClick={() => setAct({ p, status: 'paid' })}>Mark paid</Btn><Btn kind="danger" onClick={() => setAct({ p, status: 'rejected' })}>Reject</Btn></div>}
            </div>
          ))}
        </div>
      )}
      <Sheet open={!!act} onClose={() => setAct(null)} title={act?.status === 'paid' ? `Pay ${usd(act?.p.amount)} to ${act?.p.agent_name}` : 'Reject request'}>
        <Field label={act?.status === 'paid' ? 'Transaction ID or note (optional)' : 'Reason (optional)'}><input className={inputCls} value={note} onChange={e => setNote(e.target.value)} /></Field>
        <Btn kind={act?.status === 'paid' ? 'green' : 'danger'} busy={busy} className="w-full" onClick={() => void done()}>{act?.status === 'paid' ? 'Mark as paid' : 'Reject'}</Btn>
      </Sheet>
    </>
  );
}
function Payouts({ api, onChanged, back }: { api: Api; onChanged: () => void; back?: () => void }) {
  const [mode, setMode] = useState<'pending' | 'paid' | 'all'>('pending');
  const [cash, setCash] = useState(false); // v141
  const [agent, setAgent] = useState('');
  const [rows, setRows] = useState<any[]>([]);
  const pend = rows.filter(p => p.status === 'pending');
  const people = [...new Map(rows.map(p => [String(p.agent_id), p.agent_name || '?'])).entries()];
  return (
    <Page title="Payouts" back={back} below={<>
      <div className="mb-3 flex items-center gap-3"><p className="flex-1 text-[14px] text-tg-sub" data-payout-head><b className="text-tg-text">{pend.length} pending</b> · {usd(pend.reduce((a, p) => a + Number(p.amount || 0), 0))}</p><Btn kind="ghost" className="!py-2 text-[14px]" onClick={() => setCash(true)}>Record cash payout</Btn></div>
      <Sheet open={cash} onClose={() => { setCash(false); onChanged(); }} title="Record cash payout" wide>{cash && <CashPayouts api={api} role="admin" />}</Sheet>
      <div className="mb-3"><Seg value={mode} onChange={setMode} items={[['pending', 'Pending'], ['paid', 'Paid'], ['all', 'All']]} /></div>
      {people.length > 1 && <ScrollRow className="mb-4"><Chips value={agent} onChange={setAgent} items={[['', 'Everyone'], ...people.map(([id, n]) => [id, n] as [string, string])]} /></ScrollRow>}
    </>}>
      <PayoutList api={api} onChanged={onChanged} mode={mode} agent={agent} onRows={setRows} />
    </Page>
  );
}

/* ---------------- Ad spend ---------------- */
const SPEND_L: [string, string][] = [['agency', 'Agency'], ['premium', 'Premium'], ['funnel', 'Funnel'], ['telegram', 'Telegram'], ['ch_agency', 'Agency ch.'], ['ch_premium', 'Premium ch.'], ['ch_funnel', 'Funnel ch.'], ['wa_agency', 'Agency WA'], ['wa_premium', 'Premium WA'], ['wa_funnel', 'Funnel WA']];
function Spend({ api, go, back }: { api: Api; go: Go; back?: () => void }) {
  const toast = useToast();
  const [d, setD] = useState<any>(null);
  const [date, setDate] = useState(''); const [line, setLine] = useState<string>('agency'); const [amount, setAmount] = useState(''); const [note, setNote] = useState(''); const [busy, setBusy] = useState(false);
  const [filt, setFilt] = useState('all'); const [delBusy, setDelBusy] = useState('');
  // v137: range picker (same as Home); the top cards are Home's own numbers for that range and line
  const [range, setRange] = useState<Range>('30d');
  const homeLine = ['agency', 'premium', 'funnel'].includes(filt) ? filt : filt === 'all' ? 'all' : null;
  const [st, setSt] = useState<any>(null);
  const [showDays, setShowDays] = useState(30); const [showRows, setShowRows] = useState(30);
  const load = useCallback(() => Promise.all([
    api(`spend?range=${range}&line=${homeLine || 'all'}`).then(r => { setD(r); setDate(x => x || r.today); }),
    homeLine ? api(`stats?range=${range}${homeLine !== 'all' ? '&line=' + homeLine : ''}`).then(setSt) : Promise.resolve(setSt(null)),
  ]).catch(() => {}), [api, range, homeLine]);
  useEffect(() => { void load(); }, [load]);
  async function save() { setBusy(true); try { await api('spend_save', { date, line, amount, note }); toast('Spend saved'); setAmount(''); setNote(''); await load(); } catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); } }
  const rowsAll: any[] = d?.rows || [];
  const rows = rowsAll.filter(x => filt === 'all' || x.line === filt);
  const tot = rows.reduce((a: any, x: any) => ({ s: a.s + x.amount, ls: a.ls + (x.line === 'telegram' || String(x.line).startsWith('ch_') ? 0 : x.amount), l: a.l + (x.leads || 0), n: a.n + (x.sales || 0), r: a.r + (x.revenue || 0) }), { s: 0, ls: 0, l: 0, n: 0, r: 0 });
  const days: any[] = homeLine ? d?.days || [] : [];
  const lineName = (l: string) => (l === 'wa_agency' ? 'Agency WhatsApp' : l === 'wa_premium' ? 'Premium WhatsApp' : l === 'wa_funnel' ? 'Funnel WhatsApp' : l === 'ch_agency' ? 'Agency channel' : l === 'ch_premium' ? 'Premium channel' : l === 'ch_funnel' ? 'Funnel channel' : l === 'funnel' ? 'Funnel' : l === 'telegram' ? 'Telegram' : l === 'premium' ? 'Premium' : 'Agency');
  const LN = ({ l }: { l: string }) => <LineChip k={l.startsWith('wa_') ? 'wa' : l === 'funnel' ? 'funnel' : l === 'telegram' || l.startsWith('ch_') ? 'tg' : l === 'premium' ? 'premium' : 'agency'}>{lineName(l)}</LineChip>;
  const budget = d ? ['budget_agency', 'budget_funnel', 'budget_premium', 'budget_telegram', 'budget_ch_agency', 'budget_ch_premium', 'budget_ch_funnel', 'budget_wa_agency', 'budget_wa_premium', 'budget_wa_funnel'].reduce((a, k) => a + (Number(d[k]) || 0), 0) : 0;
  async function del(x: any) {
    if (!confirm(`Remove ${lineName(x.line)} spend for ${x.date}?`)) return;
    setDelBusy(x.date + x.line);
    try { await api('spend_delete', { date: x.date, line: x.line }); toast('Removed'); await load(); } catch (e) { toast((e as Error).message, 'err'); } finally { setDelBusy(''); }
  }
  return (
    <Page title="Ad spend & ROI" back={back} right={<RangePick value={range} onChange={setRange} />}>
      <MetaSwitch api={api} go={go} onChanged={() => void load()} />
      {d && <button onClick={() => go('settings', { sec: 'budgets' })} data-budget-line className="mb-4 flex w-full items-center gap-3 af-card px-4 py-3 text-left hover:bg-tg-hover">
        <span className="min-w-0 flex-1 text-[14px]">{d.meta_since ? <>Budgets: <b>not used</b> (Meta data ON)</> : <>Budgets: <b>{usd(budget)}/day</b></>} · account cost <b>{usd(Number(d.acct_cost) || 0)}</b></span>
        <span className="shrink-0 text-[13.5px] font-medium text-tg-link">Edit budgets</span><ChevronRight size={17} className="shrink-0 text-tg-sub" />
      </button>}
      <div className="mb-5 af-card p-4">
        <p className="mb-3 font-semibold">Change a day’s spend (USD)</p>
        <div className="mb-2"><DropPill value={line} onChange={setLine} menuTitle="Line" className="!bg-tg-input !shadow-none" items={SPEND_L.filter(([k]) => d?.wa_ads_on !== false || !k.startsWith('wa_')) as any} /></div>
        <div className="grid gap-2 sm:grid-cols-[auto_140px_1fr_auto]">
          <input type="date" className={inputCls} value={date} onChange={e => setDate(e.target.value)} aria-label="Date" />
          <input type="number" inputMode="decimal" className={inputCls} placeholder="Amount $" value={amount} onChange={e => setAmount(e.target.value)} aria-label="Amount" />
          <input className={inputCls} placeholder="Note (campaign)" value={note} onChange={e => setNote(e.target.value)} aria-label="Note" />
          <Btn busy={busy} onClick={() => void save()}>Save</Btn>
        </div>
        <p className="mt-2 text-[12.5px] text-tg-sub">{d?.meta_since ? <>Days from {d.meta_since} come from Meta: what you save here is <b className="text-tg-text">added</b> as another ad account’s spend. Older days: saving replaces the day.</> : 'Copy the day’s spend from Meta Ads Manager. Saving the same date again replaces it. Each day’s budget is added by itself.'}</p>
      </div>
      <ScrollRow className="mb-3"><Chips value={filt} onChange={v => { setFilt(v); setShowDays(30); setShowRows(30); }} items={[['all', 'Every line'], ...SPEND_L.filter(([k]) => d?.wa_ads_on !== false || !k.startsWith('wa_') || rowsAll.some(x => x.line === k))]} /></ScrollRow>
      {d?.wa_ads_on === false && <p className="-mt-1 mb-3 px-1 text-[12px] text-tg-sub">WhatsApp ad lines are hidden (Not running, see More → What’s running). Their spend and sales are still in every total.</p>}
      {st ? (
        <div className="mb-5 grid grid-cols-2 gap-3 lg:grid-cols-4" data-spend-cards>
          <Card label="Total spend" value={usd(st.spend)} tone="orange" />
          <Card label="Revenue" value={usd(st.revenue + (st.web_revenue || 0))} sub={`${pS(st.sales + (st.web_sales || 0), 'sale')}${st.wa_revenue ? ` · WA ${usd(st.wa_revenue)}` : ''}`} tone="green" />
          <Card label="Top-up fees" value={usd(st.topup_fees + (st.web_topup_fees || 0))} tone="green" />
          <Card label="Account cost" value={usd(st.acct_cost)} sub={`Commission ${usd(st.sale_comm)}`} />
          <Card label="Net profit" value={usd(st.profit)} tone={st.profit >= 0 ? 'green' : 'red'} />
          <Card label="ROI" value={st.roi == null ? '—' : st.roi + '%'} sub="Net profit ÷ spend (same as Home)" tone={st.roi == null ? 'muted' : st.roi >= 0 ? 'green' : 'red'} />
          <Card label="Cost per message" value={st.cpl == null ? '—' : usd(st.cpl)} sub={`${st.started} messaged`} />
        </div>
      ) : (
        <div className="mb-5 grid grid-cols-2 gap-3 lg:grid-cols-4" data-spend-cards>
          <Card label="Total spend" value={usd(tot.s)} tone="orange" /><Card label="Revenue" value={usd(tot.r)} sub={`${pS(tot.n, 'sale')} from this line's chats`} tone="green" />
          <Card label="Cost per message" value={tot.l ? usd(tot.ls / tot.l) : '—'} /><Card label="ROI" value={tot.s ? Math.round((tot.r - tot.s) / tot.s * 100) + '%' : '—'} tone={!tot.s || !tot.r ? 'muted' : tot.r >= tot.s ? 'green' : 'red'} />
        </div>
      )}
      {homeLine && (
        <>
          <p className="mb-2 px-1 text-[13px] font-semibold text-tg-sub">Day by day</p>
          <div className="mb-5 overflow-hidden af-card" data-spend-days>
            {!days.length && <p className="p-6 text-center text-tg-sub">No spend and no sales in this period.</p>}
            {days.slice(0, showDays).map(x => (
              <div key={x.date} className="flex items-center gap-3 border-b border-tg-line px-4 py-3 last:border-0">
                <div className="min-w-0 flex-1">
                  <p className="flex flex-wrap items-center gap-2 font-medium">{x.date} {x.no_spend ? <span className="text-[12px] font-normal text-tg-sub">no spend entered</span> : <span className="font-semibold tabular-nums text-tg-orange">{usd(x.spend)}</span>}</p>
                  <p className="text-[13px] text-tg-sub">{x.messaged} messaged · {pS(x.sales, 'sale')} · {usd(x.revenue + x.web)} revenue · {usd(x.fees + x.web_fee)} fees · profit <span className={x.profit >= 0 ? 'text-tg-ok' : 'text-tg-bad'}>{usd(x.profit)}</span>{x.unattributed > 0 ? ` · ${usd(x.unattributed)} unattributed` : ''}</p>
                </div>
                <span className={clsx('rounded-full px-2 py-0.5 text-[12.5px] font-semibold tabular-nums', x.roi == null ? 'bg-tg-input text-tg-sub' : x.roi >= 0 ? 'bg-tg-green/15 text-tg-ok' : 'bg-tg-red/15 text-tg-bad')}>{x.roi == null ? 'no spend' : x.roi + '%'}</span>
              </div>
            ))}
            {days.length > showDays && <button onClick={() => setShowDays(n => n + 30)} className="w-full py-3 text-[14px] font-medium text-tg-link">Show more days</button>}
          </div>
          <p className="mb-2 px-1 text-[13px] font-semibold text-tg-sub">Spend entries by line</p>
        </>
      )}
      <div className="overflow-hidden af-card">
        {!rows.length && <p className="p-8 text-center text-tg-sub">No spend yet. Set a daily budget (Edit budgets above), or add a day.</p>}
        {rows.slice(0, showRows).map((x: any) => (
          <div key={x.date + x.line} className="flex items-center gap-3 border-b border-tg-line px-4 py-3 last:border-0">
            <div className="min-w-0 flex-1"><p className="flex flex-wrap items-center gap-2 font-medium">{x.date} <LN l={x.line} /> <span className="font-semibold tabular-nums text-tg-orange">{usd(x.amount)}</span>{x.auto === 1 && <span className="text-[11.5px] text-tg-sub">daily budget</span>}</p><p className="text-[13px] text-tg-sub">{String(x.line).startsWith('ch_') ? `${x.joins} join requests · ${x.cpj == null ? '—' : usd(x.cpj)} per join · ${x.contacts} contacts · ${x.cpc == null ? '—' : usd(x.cpc)} per contact · ${pS(x.sales, 'sale')} · ${usd(x.revenue)} revenue` : x.line === 'telegram' ? `${x.subs} subscribes from /telegram · ${x.cps == null ? '—' : usd(x.cps)} per subscribe` : `${x.leads} messaged · ${usd(x.cpl)} per message · ${pS(x.sales, 'sale')} · CPA ${usd(x.cpa)} · ${usd(x.revenue)} revenue`}{x.note && x.auto !== 1 ? ` · ${x.note}` : ''}</p></div>
            <span className={clsx('font-semibold tabular-nums', x.roi == null ? 'text-tg-sub' : x.roi >= 0 ? 'text-tg-ok' : 'text-tg-bad')}>{x.roi == null ? '—' : x.roi + '%'}</span>
            <button disabled={delBusy === x.date + x.line} onClick={() => void del(x)} aria-label={`Delete ${lineName(x.line)} ${x.date}`} className="grid h-9 w-9 place-items-center rounded-full text-tg-sub hover:bg-tg-hover hover:text-tg-bad disabled:opacity-50">{delBusy === x.date + x.line ? <span className="h-4 w-4 animate-spin rounded-full border-2 border-tg-sub border-t-transparent" /> : <Trash2 size={16} />}</button>
          </div>
        ))}
        {rows.length > showRows && <button onClick={() => setShowRows(n => n + 30)} className="w-full py-3 text-[14px] font-medium text-tg-link">Show more</button>}
      </div>
    </Page>
  );
}

/* ---------------- Meta events ---------------- */
const EVS = ['PageView', 'ViewContent', 'Lead', 'Contact', 'Subscribe', 'Purchase'];
function CapiSummary({ sum, pixel, setPixel, go, onCell }: { sum: { sources: [string, string][]; grid: { source: string; ev: string; status: string; n: number }[]; reasons: { reason: string; source: string; pixel: string; sec: string | null; status: string; n: number; last: number }[] } | null; pixel: string; setPixel: (v: string) => void; go: Go; onCell: (src: string, ev: string) => void }) {
  if (!sum) return null;
  const evs = [...EVS, ...[...new Set(sum.grid.map(g => g.ev))].filter(e => !EVS.includes(e)).sort()];
  const srcs = sum.sources.filter(([k]) => sum.grid.some(g => g.source === k));
  const cell = (src: string | null, ev: string | null, st: string) => sum.grid.filter(g => (src == null || g.source === src) && (ev == null || g.ev === ev) && (st === 'failed' ? g.status === 'error' || g.status === 'failed' : g.status === st)).reduce((a, g) => a + g.n, 0);
  const C = ({ src, ev }: { src: string | null; ev: string | null }) => { const ok = cell(src, ev, 'sent'), bad = cell(src, ev, 'failed'), sk = cell(src, ev, 'skipped'); return (
    <td className={clsx('px-2 py-1.5 text-center tabular-nums', !ok && !bad && !sk && 'text-tg-sub/50')}>
      <button disabled={!ok && !bad && !sk} onClick={() => onCell(src || '', ev || '')} className="inline-grid min-h-[36px] min-w-[40px] place-items-center leading-tight"><span className={clsx(ok ? 'font-semibold text-tg-text' : '')}>{ok || (bad || sk ? 0 : '·')}</span>{bad > 0 && <span className="ml-1 text-[11px] font-semibold text-tg-bad">{bad}✕</span>}{sk > 0 && <span className="ml-1 text-[11px] font-semibold text-tg-orange">{sk}↷</span>}</button>
    </td>); };
  return (
    <div className="mb-4 grid gap-3" data-capi-summary>
      <ScrollRow><Chips value={pixel} onChange={setPixel} items={[['', 'Every pixel'], ['agency', 'Agency pixel'], ['funnel', 'Funnel pixel'], ['wa', 'WhatsApp pixels']]} /></ScrollRow>
      <div className="min-w-0 overflow-x-auto af-card" data-capi-grid>
        {!srcs.length ? <p className="p-6 text-center text-tg-sub">No events in this period.</p> : (
          <table className="min-w-full text-[12.5px]">
            <thead><tr className="text-tg-sub"><th className="sticky left-0 bg-tg-panel px-3 py-2 text-left font-medium">Source</th>{evs.map(e => <th key={e} className="whitespace-nowrap px-2 py-2 font-medium">{e}</th>)}<th className="px-2 py-2 font-semibold">Total</th></tr></thead>
            <tbody>
              {srcs.map(([k, l]) => <tr key={k} className="border-t border-tg-line"><td className="sticky left-0 whitespace-nowrap bg-tg-panel px-3 py-1.5 font-medium">{l}</td>{evs.map(e => <C key={e} src={k} ev={e} />)}<C src={k} ev={null} /></tr>)}
              <tr className="border-t-2 border-tg-line font-semibold"><td className="sticky left-0 bg-tg-panel px-3 py-1.5">Total</td>{evs.map(e => <C key={e} src={null} ev={e} />)}<C src={null} ev={null} /></tr>
            </tbody>
          </table>
        )}
        <p className="px-3 pb-2 pt-1 text-[11.5px] text-tg-sub">Sent count · <span className="text-tg-bad">✕ failed</span> · <span className="text-tg-orange">↷ skipped</span>. Tap a number to see those events below.</p>
      </div>
      {sum.reasons.length > 0 && (
        <div className="af-card p-4" data-capi-reasons>
          <p className="mb-2 font-semibold">Why skipped / failed</p>
          {sum.reasons.map((r, i) => (
            <div key={i} className="flex items-start gap-2 border-t border-tg-line py-2 text-[13px] first:border-t-0">
              <span className={clsx('mt-0.5 shrink-0 rounded-full px-2 py-0.5 text-[11.5px] font-semibold', r.status === 'skipped' ? 'bg-tg-orange/15 text-tg-orange' : r.status === 'dup' ? 'bg-tg-chip text-tg-sub' : 'bg-tg-red/15 text-tg-bad')}>{r.n}</span>
              <span className="min-w-0 flex-1"><span className="block text-tg-text">{r.reason}</span><span className="text-tg-sub">{(sum.sources.find(x => x[0] === r.source) || [r.source, r.source])[1]} · {r.pixel}</span></span>
              {r.sec && <button onClick={() => go('settings', { sec: r.sec! })} className="shrink-0 text-[13px] font-medium text-tg-link">Fix</button>}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
function Capi({ api, back, go }: { api: Api; back?: () => void; go: Go }) {
  const toast = useToast();
  const [rows, setRows] = useState<any[] | null>(null);
  const [codes, setCodes] = useState<{ agency: string; funnel: string } | null>(null);
  // v137: range, pixel filter, summary grid (source × event), reasons for skipped / failed, list filters
  const [range, setRange] = useState<Range>('today');
  const [pixel, setPixel] = useState(''); const [fSrc, setFSrc] = useState(''); const [fEv, setFEv] = useState(''); const [fSt, setFSt] = useState('');
  const [sum, setSum] = useState<{ sources: [string, string][]; grid: { source: string; ev: string; status: string; n: number }[]; reasons: { reason: string; source: string; pixel: string; sec: string | null; status: string; n: number; last: number }[] } | null>(null);
  const load = useCallback(() => api(`capi?range=${range}&pixel=${pixel}&source=${fSrc}&event=${encodeURIComponent(fEv)}&status=${fSt}`).then(r => { setRows(r.rows); setSum({ sources: r.sources, grid: r.grid, reasons: r.reasons }); setCodes(c => c ?? { agency: r.test_code || '', funnel: r.f_test_code || '' }); }).catch(() => {}), [api, range, pixel, fSrc, fEv, fSt]);
  useEffect(() => { void load(); }, [load]);
  const [busy, setBusy] = useState('');
  async function test(line: 'agency' | 'funnel', event: string) {
    setBusy(line + event);
    try { const r = await api('capi_test', { line, event, test_code: codes?.[line] ?? '' }); toast(r.ok ? `${event} test sent to the ${line === 'funnel' ? 'Funnel' : 'Agency'} pixel.` : 'Not sent: ' + JSON.stringify(r.result).slice(0, 140), r.ok ? 'ok' : 'err'); await load(); }
    catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(''); }
  }
  return (
    <Page title="Meta events" back={back} right={<RangePick value={range} onChange={setRange} />}>
      <CapiSummary sum={sum} pixel={pixel} setPixel={setPixel} go={go} onCell={(src, ev) => { setFSrc(src); setFEv(ev); }} />
      <div className="mb-4 af-card p-4">
        <p className="font-semibold">Send a test event</p>
        <p className="mb-3 mt-0.5 flex items-center gap-1 text-[12.5px] text-tg-sub">Once per event, so Meta knows it.<InfoTip title="Send a test event">Send each event once so Meta knows it, then you can pick Lead, Purchase or Subscribe when you make the ad or a custom audience. The test event code box is only for these test buttons (from Events Manager → Test events); leave it empty to send a real event. With a test event code in Settings it shows in Events Manager → Test events right away; without it, it shows in Overview in about 20–30 minutes.</InfoTip></p>
        {(['agency', 'funnel'] as const).map(l => (
          <div key={l} className="mb-3 last:mb-0">
            <span className="mb-1.5 inline-block"><LineChip k={l}>{l === 'funnel' ? 'Funnel pixel' : 'Agency pixel'}</LineChip></span>
            <input className={clsx(inputCls, 'mb-2 sm:max-w-[420px]')} placeholder="Test event code (empty = real event)" value={codes?.[l] ?? ''} onChange={e => setCodes(c => ({ agency: c?.agency ?? '', funnel: c?.funnel ?? '', [l]: e.target.value }))} />
            <div className="grid grid-cols-2 gap-2 sm:max-w-[420px] sm:grid-cols-4">{['ViewContent', 'Lead', 'Purchase', 'Subscribe'].map(ev => <Btn key={ev} kind="ghost" busy={busy === l + ev} onClick={() => void test(l, ev)} className="!px-1 !text-[13.5px]">{ev}</Btn>)}</div>
          </div>
        ))}
      </div>
      <p className="mb-3 flex items-center gap-1 px-1 text-[13px] text-tg-sub">Each event is sent once, with its own ID.<InfoTip title="How events are sent">
        Every event has a unique ID and is never sent twice. <b className="text-tg-text">ViewContent</b>: once per visitor. <b className="text-tg-text">Lead</b>: once per lead, only when they message on Telegram. <b className="text-tg-text">Purchase</b>: only when an agent marks the sale. Failed events are retried automatically.
      </InfoTip></p>
      <div className="mb-2.5 flex flex-wrap gap-2" data-capi-filters>
        <DropPill value={fSrc} onChange={setFSrc} menuTitle="Source" items={[['', 'Every source'], ...(sum?.sources || []).filter(([k]) => sum?.grid.some(g => g.source === k))] as any} />
        <DropPill value={fEv} onChange={setFEv} menuTitle="Event" items={[['', 'Every event'], ...[...new Set((sum?.grid || []).map(g => g.ev))].map(e => [e, e] as [string, string])] as any} />
        <DropPill value={fSt} onChange={setFSt} menuTitle="Status" items={[['', 'Any status'], ['sent', 'Sent'], ['error', 'Failed'], ['skipped', 'Skipped'], ['dup', 'Not sent (same person)'], ['pending', 'Pending']]} />
      </div>
      <div className="overflow-hidden af-card">
        {rows && !rows.length && <p className="p-8 text-center text-tg-sub">No events for this filter.</p>}
        {(rows || []).map(x => (
          <div key={x.event_id} className="border-b border-tg-line px-4 py-3">
            <div className="flex items-center gap-2"><b>{x.event_name}</b>{x.line === 'funnel' && <LineChip k="funnel" size="xs" />}{x.lead_id && <span className="text-[13px] text-tg-sub">lead #{x.lead_id}</span>}<span className="ml-auto text-[12.5px] text-tg-sub">{listTime(x.created_at)}</span>
              <span className={clsx('rounded-full px-2 py-0.5 text-[12px] font-semibold', x.status === 'sent' ? 'bg-tg-green/15 text-tg-ok' : x.status === 'skipped' || x.status === 'dup' ? 'bg-tg-orange/15 text-tg-orange' : x.status === 'pending' ? 'bg-tg-chip text-tg-sub' : 'bg-tg-red/15 text-tg-bad')}>{x.status === 'dup' ? 'not sent (same person)' : x.status}</span></div>
            {x.status !== 'sent' && x.status !== 'dup' && x.response && <p className="mt-1 break-all font-mono text-[12px] text-tg-sub">{String(x.response).slice(0, 220)}</p>}
          </div>
        ))}
      </div>
    </Page>
  );
}

/* ---------------- Export ---------------- */
function Export({ api, back }: { api: Api; back?: () => void }) {
  const [range, setRange] = useState<Range | 'all'>('all');
  const [line, setLine] = useState<'all' | 'agency' | 'premium' | 'funnel'>('all');
  // v127: a fresh 5-minute download token (the login token never goes in a URL)
  const open = async (path: string) => { let t = ''; try { t = (await api<{ token: string }>('export_token')).token; } catch { } void openExternal(`${location.origin}/api/admin/export/${path}${path.includes('?') ? '&' : '?'}range=${range}${line !== 'all' ? `&line=${line}` : ''}${t ? `&t=${encodeURIComponent(t)}` : ''}`); };
  const lineName = line === 'all' ? '' : line === 'agency' ? 'Agency' : line === 'premium' ? 'Premium' : 'Funnel';
  // v137: row counts on every card + a preview sheet (first 20 rows, same columns as the file)
  const qs = `range=${range}${line !== 'all' ? `&line=${line}` : ''}`;
  const [counts, setCounts] = useState<Record<string, number> | null>(null);
  useEffect(() => { setCounts(null); api<{ counts: Record<string, number> }>(`export_counts?${qs}`).then(r => setCounts(r.counts)).catch(() => {}); }, [api, qs]);
  const [pv, setPv] = useState<{ title: string; kind: string; cols: string[]; rows: string[][]; total: number; hashed: boolean } | null>(null);
  const [pvBusy, setPvBusy] = useState('');
  const toast = useToast();
  async function preview(p: string, title: string) {
    const [kind, query] = p.split('?');
    setPvBusy(p);
    try { const r = await api<any>(`export_preview?kind=${encodeURIComponent(kind)}&${qs}${query ? '&' + query : ''}`); setPv({ ...r, title }); }
    catch (e) { toast((e as Error).message, 'err'); } finally { setPvBusy(''); }
  }
  // v137: Meta-ready files by app (hashed customer lists + offline purchases), with match quality
  type MCard = { kind: string; title: string; use: string; total: number; keys: { phone: number; email: number; external_id: number } };
  const [app, setApp] = useState<'all' | 'tg_chat' | 'tg_channel' | 'wa' | 'web'>('all');
  const [mc, setMc] = useState<{ guide: string; cards: MCard[] } | null>(null);
  useEffect(() => { setMc(null); api<{ guide: string; cards: MCard[] }>(`export_meta_cards?app=${app}&${qs}`).then(setMc).catch(() => {}); }, [api, app, qs]);
  async function previewMeta(c: MCard) {
    setPvBusy('m' + c.kind);
    try { const r = await api<any>(`export_meta_preview?app=${app}&kind=${c.kind}&${qs}`); setPv({ ...r, title: c.title }); }
    catch (e) { toast((e as Error).message, 'err'); } finally { setPvBusy(''); }
  }
  const items: [string, string, string][] = [
    ['leads.csv', 'All leads', 'Name, phone, email, answers, landing page, agent, status, revenue, dates.'],
    ['meta_purchases.csv', 'Meta offline purchases', 'Purchases in Meta’s format. Email, phone and name are SHA-256 hashed.'],
    ['audience.csv?type=buyers', 'Lookalike audience: buyers', 'Hashed customer list with purchase value. Upload in Audiences → Custom audience → Customer list.'],
    ['audience.csv?type=all', 'Audience: all leads', 'Hashed list of every lead, for retargeting and lookalikes.'],
    ['channel_people.csv', 'Channel ad people', 'Everyone who asked to join the channel: Telegram ID, page, joined / left, Subscribe sent, messaged us, sales, and the data sent to Meta (IP, browser, fbc, fbp).'],
    ['channel_audience.csv', 'Channel audience for Meta', 'The same people as a Meta customer list (hashed ID, the one Meta got with Subscribe). Upload in Audiences → Custom audience → Customer list.'],
  ];
  return (
    <Page title="Export" back={back} right={<RangePick value={range as Range} onChange={setRange} />}>
      <div className="mb-4 af-card p-4">
        <p className="mb-2 text-[14px] text-tg-sub">Which business</p>
        <Seg value={line} onChange={setLine} items={[['all', 'All'], ['agency', 'Agency'], ['premium', 'Premium'], ['funnel', 'Funnel']]} />
        <p className="mt-2 text-[12.5px] text-tg-sub">{line === 'all' ? 'Every file has everyone.' : line === 'agency' ? 'Only normal ad account chats (not Premium, not Funnel).' : line === 'premium' ? 'Only Premium ad account chats.' : 'Only landing page + funnel chats.'}</p>
      </div>
      <div className="mb-3 min-w-0"><ScrollRow><Chips value={app} onChange={v => setApp(v as typeof app)} items={[['all', 'All'], ['tg_chat', 'Telegram chats'], ['tg_channel', 'Telegram channel'], ['wa', 'WhatsApp'], ['web', 'Website forms']]} /></ScrollRow></div>
      {mc && <p className="mb-3 rounded-2xl bg-tg-acc/10 px-4 py-3 text-[13.5px] leading-relaxed text-tg-text" data-export-guide>{mc.guide}</p>}
      <div className="mb-6 grid grid-cols-1 gap-3 md:grid-cols-2" data-meta-files>
        {!mc && <div className="p-3"><Skeleton rows={3} h={68} /></div>}
        {mc?.cards.map(c => (
          <div key={c.kind} className="min-w-0 af-card p-5" data-meta-card={c.kind}>
            <p className="text-[16.5px] font-semibold">{c.title}{lineName && <span className="ml-2 rounded-full bg-tg-input px-2 py-0.5 align-middle text-[12px] font-semibold text-tg-link">{lineName}</span>}</p>
            <p className="mt-0.5 text-[13px] font-medium text-tg-link" data-export-count>{c.total.toLocaleString()} row{c.total === 1 ? '' : 's'}</p>
            <p className="mt-1 text-[12.5px] text-tg-sub" data-keys>Match keys: phone {c.keys.phone}% · email {c.keys.email}% · external_id {c.keys.external_id}%</p>
            <p className="mb-3 mt-1 text-[13px] leading-relaxed text-tg-sub"><b className="text-tg-text">Use for:</b> {c.use}</p>
            <div className="flex flex-wrap gap-2"><Btn onClick={() => open(`meta/${app}/${c.kind}.csv`)}><Download size={17} />Download CSV</Btn><Btn kind="ghost" busy={pvBusy === 'm' + c.kind} onClick={() => void previewMeta(c)}>Preview</Btn></div>
          </div>
        ))}
      </div>
      <p className="mb-2 px-1 text-[13px] font-semibold text-tg-sub">Raw data files</p>
      <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
        {items.map(([p, t, d]) => (
          <div key={p} className="min-w-0 af-card p-5" data-export-card={p}><p className="text-[17px] font-semibold">{t}{lineName && <span className="ml-2 rounded-full bg-tg-input px-2 py-0.5 align-middle text-[12px] font-semibold text-tg-link">{lineName}</span>}</p>
            <p className="mt-0.5 text-[13px] font-medium text-tg-link" data-export-count>{counts ? `${(counts[p] ?? 0).toLocaleString()} row${counts[p] === 1 ? '' : 's'}` : '…'}</p>
            <p className="mb-4 mt-1 text-[14px] leading-relaxed text-tg-sub">{d}</p>
            <div className="flex flex-wrap gap-2"><Btn onClick={() => open(p)}><Download size={17} />Download CSV</Btn><Btn kind="ghost" busy={pvBusy === p} onClick={() => void preview(p, t)}>Preview</Btn></div></div>
        ))}
      </div>
      <Sheet open={!!pv} onClose={() => setPv(null)} title={pv ? `${pv.title} · ${pv.total.toLocaleString()} rows` : ''} wide>
        {pv && (
          <div data-export-preview className="min-w-0">
            <p className="mb-2 text-[13px] text-tg-sub">{pv.total > pv.rows.length ? `First ${pv.rows.length} of ${pv.total.toLocaleString()} rows` : `${pv.total} row${pv.total === 1 ? '' : 's'}`} · same columns as the file{lineName ? ` · ${lineName}` : ''}.</p>
            {pv.hashed && <p className="mb-2 rounded-xl bg-tg-input px-3 py-2 text-[12.5px] text-tg-sub">Email, phone and names are SHA-256 hashed, exactly as Meta gets them. That is why they look like long codes.</p>}
            {!pv.rows.length ? <p className="py-6 text-center text-tg-sub">No rows for this period.</p> : (
              <div className="max-h-[60vh] overflow-auto rounded-xl ring-1 ring-tg-line">
                <table className="min-w-full text-left text-[12.5px]">
                  <thead className="sticky top-0 bg-tg-input"><tr>{pv.cols.map(c => <th key={c} className="whitespace-nowrap px-2.5 py-2 font-semibold">{c}</th>)}</tr></thead>
                  <tbody>{pv.rows.map((r, i) => <tr key={i} className="border-t border-tg-line">{r.map((v, j) => <td key={j} className="max-w-[220px] truncate whitespace-nowrap px-2.5 py-1.5" title={v}>{v}</td>)}</tr>)}</tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </Sheet>
    </Page>
  );
}

/* ---------------- Settings ---------------- */
const SettingsSearch = createContext('');
/** v167: Settings is a hub of one-line rows; a row opens its section as its own page. '' = hub. */
const SettingsOpen = createContext<{ open: string; value: (id: string) => React.ReactNode }>({ open: '', value: () => null });
const SEC_ICON: Record<string, [any, string]> = {
  prices: [CircleDollarSign, TILE.green], offers: [Repeat2, TILE.orange], web: [ShoppingBag, TILE.purple], tg: [Bot, TILE.cyan], welcome: [MessageCircle, TILE.blue], automsg: [Zap, TILE.yellow],
  channel: [Megaphone, TILE.indigo], chanads: [Radar, TILE.pink], wamaster: [Power, TILE.green], wati: [MessagesSquare, TILE.green], wa: [Link2, TILE.teal], routing: [Clock, TILE.indigo],
  agents: [Reply, TILE.teal], fmsgs: [Repeat2, TILE.purple], push: [BellRing, TILE.red], brand: [Sparkles, TILE.pink], hero: [Home, TILE.blue], cards: [CreditCard, TILE.orange], more: [MoreHorizontal, TILE.grey],
  premium: [Crown, TILE.yellow], funnel: [BarChart3, TILE.purple], proof: [Medal, TILE.orange], meta: [Radar, TILE.blue], budgets: [DollarSign, TILE.teal], pw: [KeyRound, TILE.grey],
};
function Section({ id, title, desc, children, open, onToggle }: { id: string; title: string; desc: string; children: React.ReactNode; open: boolean; onToggle: () => void }) {
  const q = useContext(SettingsSearch);
  const hub = useContext(SettingsOpen);
  if (!q && !hub.open) {
    const [I, c] = SEC_ICON[id] || [Settings, TILE.grey];
    return (
      <button type="button" data-sec data-sec-id={id} onClick={onToggle} className="af-row af-hub-row" title={desc}>
        <IconTile icon={I} color={c} />
        <span data-sec-head className="min-w-0 flex-1 truncate text-[15.5px]">{title}</span>
        <span className="max-w-[45%] shrink-0 truncate text-right text-[14.5px] text-tg-sub af-num">{hub.value(id)}</span>
        <ChevronRight size={18} className="-mr-1 shrink-0 text-tg-faint" />
      </button>
    );
  }
  if (!q) {
    if (hub.open !== id) return null;
    return (
      <div data-sec data-sec-id={id}>
        <span data-sec-head className="hidden">{title}</span>
        <button type="button" onClick={onToggle} className="mb-2 hidden items-center gap-0.5 text-[15px] text-tg-link md:flex"><ChevronLeft size={20} />All settings</button>
        {desc && <p className="mx-1 mb-2.5 text-[13px] leading-snug text-tg-sub">{desc}</p>}
        <div data-sec-body className="af-card af-sec px-4 pb-3 pt-4">{children}</div>
      </div>
    );
  }
  open = true; // searching: every section open, the search hides what doesn't match
  return (
    <div data-sec data-sec-id={id} className="af-card mb-2.5 scroll-mt-[124px] overflow-hidden">
      <button data-sec-head onClick={onToggle} aria-expanded={open} className="flex w-full items-center gap-3 px-4 py-3 text-left">
        <span className="flex-1"><span className="block text-[15.5px] font-semibold">{title}</span><span className="text-[12.5px] text-tg-sub">{desc}</span></span>
      </button>
      {open && <div data-sec-body className="af-sec border-t border-tg-line px-4 pb-4 pt-4">{children}</div>}
    </div>
  );
}

/** v134: team notification sound — the built-in alert or our own uploaded sound (all phones + app tabs). */
function SoundPanel({ api, s, set, onDone }: { api: Api; s: Record<string, string>; set: (k: string, v: string) => void; onDone: () => void }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const own = s.notif_sound === 'own' && !!s.notif_sound_file;
  async function up(f: File | null, remove = false) {
    const fd = new FormData();
    if (remove) fd.append('remove', '1'); else if (f) fd.append('file', f); else return;
    setBusy(true);
    try { await api('notif_sound', fd); toast(remove ? 'Back to the default sound' : 'Sound saved. Phones use it from the next notification.'); onDone(); }
    catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); }
  }
  const play = (src: string) => { try { const a = new Audio(src); void a.play(); } catch { /* ignore */ } };
  return (
    <div className="mb-3 rounded-xl bg-tg-input px-4 py-3" data-sound-panel>
      <p className="text-[14.5px]">Notification sound</p>
      <p className="mb-2.5 text-[12.5px] text-tg-sub">{own ? 'Our own sound — every team phone (Android app 1.8+) and open app tab uses it, also for the ring on silent.' : 'Default sound. Upload a short MP3 / OGG / M4A / WAV (1–3 seconds, under 1 MB) to use our own.'}</p>
      <div className="mb-2.5 grid grid-cols-2 gap-2">
        {([['default', 'Default'], ['own', 'Our own sound']] as const).map(([v, l]) => (
          <button key={v} type="button" disabled={v === 'own' && !s.notif_sound_file} onClick={() => set('notif_sound', v)} className={clsx('rounded-xl border-2 px-2 py-2 text-[13.5px] font-medium disabled:opacity-40', (v === 'own') === own ? 'border-tg-acc bg-tg-acc/10' : 'border-transparent bg-black/20')}>{l}</button>
        ))}
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <button type="button" onClick={() => play('/sounds/alert.mp3')} className="rounded-lg bg-black/20 px-3 py-1.5 text-[13px] text-tg-link">Play default</button>
        {s.notif_sound_file && <button type="button" onClick={() => play(`/api/notif-sound?v=${s.notif_sound_ver}`)} className="rounded-lg bg-black/20 px-3 py-1.5 text-[13px] text-tg-link">Play ours</button>}
        <label className={clsx('cursor-pointer rounded-lg bg-tg-acc px-3 py-1.5 text-[13px] font-medium text-white', busy && 'opacity-60')}>
          {busy ? 'Uploading…' : s.notif_sound_file ? 'Change sound' : 'Upload sound'}
          <input type="file" accept="audio/*,.mp3,.ogg,.m4a,.aac,.wav" className="hidden" data-sound-input onChange={e => { const f = e.target.files?.[0] || null; e.target.value = ''; void up(f); }} />
        </label>
        {s.notif_sound_file && <button type="button" onClick={() => void up(null, true)} className="px-2 py-1.5 text-[13px] text-tg-red">Remove</button>}
        {own && <button type="button" data-sound-sync onClick={() => void api<{ ok: boolean; sent: number; phones: number; error?: string }>('notif_sound_sync', { to: 'all' }).then(r => toast(r.ok ? `Sound sent to ${r.sent} of ${r.phones} phone${r.phones === 1 ? '' : 's'}` : r.error || 'Not sent', r.ok ? undefined : 'err')).catch(e => toast((e as Error).message, 'err'))} className="rounded-lg bg-black/20 px-3 py-1.5 text-[13px] text-tg-link">Send sound to all phones</button>}
      </div>
      {s.notif_sound_file && <p className="mt-2 text-[12px] text-tg-sub">Switch between Default and ours here, then tap Save at the bottom.</p>}
      <TestPush api={api} />
    </div>
  );
}
/** v135: test notification to every phone with the app logged in (agents even when paused, manager, admins).
 *  v137: optional own text and who gets it; optional new sound → uploaded, sent to the phones (silent sync push), a live
 *  "Saving sound…" list, then the test (phones that saved first, the rest at the end); and what each phone played. */
type Person = { name: string; role?: string; user_id?: number; phones: number; got: number; snd?: 'saved' | 'late'; ring_off?: boolean };
type SyncP = { key: string; name: string; phones: number; saved: number; failed: number; error: string; state: 'saved' | 'waiting' | 'error' };
type Ring = { role: string; user_id: number; device: string; at: number; kind: string; played: string; reason: string; name: string | null; data: Record<string, unknown> };
const PLAYED: Record<string, string> = { own: 'played our sound', builtin: 'played the built-in sound', channel: 'normal notification sound', none: 'no sound' };
const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));
function TestPush({ api }: { api: Api }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const [text, setText] = useState('');
  const [to, setTo] = useState<string>('all'); // all · agents · admins · agent:<id> (v139: one person)
  const [team, setTeam] = useState<{ id: number; name: string }[]>([]);
  useEffect(() => { void api<{ phones: { role: string; user_id: number; name: string }[] }>('push_phones').then(r => {
    const m = new Map<number, string>(); for (const p of r.phones) if (p.role === 'agent' && !m.has(p.user_id)) m.set(p.user_id, p.name);
    setTeam([...m].map(([id, name]) => ({ id, name })).sort((a, b) => a.name.localeCompare(b.name)));
  }).catch(() => {}); }, [api]);
  const toName = to.startsWith('agent:') ? team.find(t => 'agent:' + t.id === to)?.name || 'this person' : '';
  const [file, setFile] = useState<File | null>(null);
  const [stage, setStage] = useState('');
  const [sync, setSync] = useState<SyncP[] | null>(null);
  const [res, setRes] = useState<Person[] | null>(null);
  const [rings, setRings] = useState<Ring[]>([]);
  const [t0, setT0] = useState(0);
  const [last, setLast] = useState<Ring[]>([]);
  const [lastBusy, setLastBusy] = useState(false);
  // v139: Refresh shows that it did something (spinner + toast), and errors are no longer swallowed
  const loadLast = useCallback((manual = false) => {
    setLastBusy(true);
    void api<{ reports: Ring[] }>('ring_reports').then(r => { setLast(r.reports); if (manual) toast(r.reports.length ? `Updated · ${r.reports.length} phone${r.reports.length === 1 ? '' : 's'}` : 'Updated · no report yet'); })
      .catch(e => { if (manual) toast((e as Error).message, 'err'); }).finally(() => setLastBusy(false));
  }, [api, toast]);
  useEffect(() => { loadLast(); }, [loadLast]);
  // after a test: what each phone played (reports come a few seconds later)
  useEffect(() => {
    if (!t0) return;
    let n = 0;
    const id = setInterval(() => { n++; void api<{ reports: Ring[] }>('ring_reports?since=' + t0).then(r => setRings(r.reports.filter(x => x.kind !== 'sync'))).catch(() => {}); if (n > 15) { clearInterval(id); loadLast(); } }, 3000);
    return () => clearInterval(id);
  }, [t0, api, loadLast]);
  type TestRes = { ok: boolean; error?: string; people: Person[]; at: number };
  const test = (only?: string[]) => api<TestRes>('push_test', { text, to, ...(only ? { only } : {}) });
  async function go() {
    setBusy(true); setRes(null); setSync(null); setRings([]); setStage('');
    try {
      let out: Person[] = [];
      let start = Date.now();
      if (file) {
        setStage('Uploading the sound…');
        const fd = new FormData(); fd.append('file', file); fd.append('nosync', '1');
        await api('notif_sound', fd);
        const sy = await api<{ ok: boolean; error?: string; ver: string; at: number; phones: number }>('notif_sound_sync', { to });
        if (!sy.ok) throw new Error(sy.error || 'Could not send the sound to the phones');
        setStage('Saving sound on the phones…');
        start = Date.now();
        const sent = new Set<string>();
        for (let k = 0; k < 30; k++) {
          const st = await api<{ people: SyncP[]; done: boolean }>(`sound_sync_status?since=${sy.at - 2000}&ver=${encodeURIComponent(sy.ver)}&to=${to}`);
          setSync(st.people);
          const ready = st.people.filter(p => p.state === 'saved' && !sent.has(p.key)).map(p => p.key);
          if (ready.length) { ready.forEach(x => sent.add(x)); const r = await test(ready); out = [...out, ...r.people.map(p => ({ ...p, snd: 'saved' as const }))]; setRes(out); }
          if (st.done || st.people.every(p => sent.has(p.key))) break;
          await sleep(2000);
        }
        const st = await api<{ people: SyncP[] }>(`sound_sync_status?since=${sy.at - 2000}&ver=${encodeURIComponent(sy.ver)}&to=${to}`);
        setSync(st.people);
        const late = st.people.filter(p => !sent.has(p.key)).map(p => p.key);
        if (late.length) { const r = await test(late); out = [...out, ...r.people.map(p => ({ ...p, snd: 'late' as const }))]; }
        setFile(null);
      } else {
        const r = await test();
        if (!r.ok) throw new Error(r.error || 'Could not send');
        out = r.people;
      }
      setRes(out); setT0(start - 1000); setStage('');
      toast(out.length ? (text.trim() ? 'Message sent' : 'Test sent') : 'No phone has the app logged in yet');
    } catch (e) { toast((e as Error).message, 'err'); setStage(''); } finally { setBusy(false); }
  }
  const ringOf = (p: Person) => rings.filter(r => r.role === (p.role || 'agent') && r.user_id === (p.user_id ?? 0));
  const chip = (on: boolean) => clsx('h-8 rounded-full px-3 text-[13px] font-medium', on ? 'bg-tg-acc text-white' : 'bg-tg-panel text-tg-text ring-1 ring-tg-line');
  return (
    <div className="mt-3 border-t border-tg-line pt-3" data-test-push>
      <label className="mb-1 block text-[13px] text-tg-sub" htmlFor="tp-text">Your message (optional)</label>
      <textarea id="tp-text" data-test-text value={text} maxLength={300} rows={2} onChange={e => setText(e.target.value)} placeholder="Empty = the normal test text" className={inputCls + ' resize-none'} />
      <div className="mt-2 flex flex-wrap items-center gap-1.5" data-test-to>
        {([['all', 'All'], ['agents', 'Only agents'], ['admins', 'Only admin phones']] as const).map(([k, l]) => <button key={k} type="button" data-to={k} onClick={() => setTo(k)} className={chip(to === k)}>{l}</button>)}
        {team.map(t => <button key={t.id} type="button" data-to={'agent:' + t.id} onClick={() => setTo('agent:' + t.id)} className={chip(to === 'agent:' + t.id)}>{t.name}</button>)}
      </div>
      <div className="mt-2 flex flex-wrap items-center gap-2">
        <label className="cursor-pointer rounded-lg bg-tg-panel px-3 py-1.5 text-[13px] text-tg-link ring-1 ring-tg-line">
          {file ? 'Change new sound' : 'New sound (optional)'}
          <input type="file" accept="audio/*,.mp3,.ogg,.m4a,.aac,.wav" className="hidden" data-test-sound onChange={e => { setFile(e.target.files?.[0] || null); e.target.value = ''; }} />
        </label>
        {file && <span className="min-w-0 truncate text-[12.5px] text-tg-sub">{file.name} <button type="button" onClick={() => setFile(null)} className="ml-1 text-tg-red">Remove</button></span>}
      </div>
      <button type="button" data-test-send onClick={() => void go()} disabled={busy} className="mt-2.5 rounded-lg bg-tg-acc px-3 py-1.5 text-[13px] font-medium text-white disabled:opacity-60">{busy ? (stage || 'Sending…') : text.trim() ? 'Send message' : 'Send test notification'}{to === 'all' ? ' to all phones' : to === 'agents' ? ' to agents' : to === 'admins' ? ' to admin phones' : ` to ${toName}`}</button>
      <p className="mt-1.5 text-[12px] text-tg-sub">Goes to every phone where the app is installed and logged in, also agents who are paused. Rings even on silent / vibrate. With a new sound: the phones save it first, then the test plays it.</p>
      {sync && (
        <div className="mt-2 rounded-lg bg-tg-panel p-2.5 text-[13px]" data-sync-list>
          <p className="mb-1 font-medium">Saving sound…</p>
          {sync.map(p => <p key={p.key} className="flex justify-between gap-2"><span className="truncate">{p.name}</span><span className={p.state === 'saved' ? 'text-tg-ok' : p.state === 'error' ? 'text-tg-bad' : 'text-tg-sub'}>{p.state === 'saved' ? `saved${p.phones > 1 ? ` ${p.saved}/${p.phones}` : ''}` : p.state === 'error' ? `error: ${p.error}` : 'waiting'}</span></p>)}
        </div>
      )}
      {res && <div className="mt-2 space-y-1.5 text-[13px]" data-test-result>{!res.length ? <p className="text-tg-sub">No phone has the app logged in yet.</p> : res.map(p => (
        <div key={p.name}>
          <p className="flex justify-between gap-2"><span>{p.name}</span><span className={p.got ? 'text-tg-ok' : 'text-tg-bad'}>{p.got}/{p.phones} phone{p.phones === 1 ? '' : 's'} {p.got ? 'sent' : 'failed'}{p.ring_off ? <span data-ring-off-note className="text-tg-sub"> · ring off for this person</span> : null}</span></p>
          {p.snd === 'late' && <p className="text-[12px] text-tg-orange">sound not saved yet, will use it once saved</p>}
          {ringOf(p).map(r => <p key={r.device} className="text-[12px] text-tg-sub" data-ring-row>{r.device}: <span className={r.played === 'none' ? 'text-tg-bad' : 'text-tg-ok'}>{PLAYED[r.played] || r.played}</span>{r.reason ? ` · ${r.reason}` : ''}</p>)}
        </div>
      ))}</div>}
      <div className="mt-3 rounded-lg bg-tg-panel p-2.5" data-last-ring>
        <div className="mb-1 flex items-center justify-between"><p className="text-[13px] font-medium">Last ring on each phone</p><button type="button" data-ring-refresh onClick={() => loadLast(true)} disabled={lastBusy} className="inline-flex items-center gap-1 text-[12.5px] text-tg-link disabled:opacity-60"><RotateCw size={13} className={lastBusy ? 'animate-spin' : ''} />{lastBusy ? 'Refreshing…' : 'Refresh'}</button></div>
        {!last.length ? <p className="text-[12.5px] text-tg-sub">No report yet. Phones with the new app send one after each alert (app 1.4+ keeps it and sends it later when it can't right away).</p> : last.map(r => (
          <p key={r.role + r.user_id + r.device} className="border-t border-tg-line py-1.5 text-[12.5px] first-of-type:border-t-0">
            <span className="font-medium">{r.name || (r.role === 'admin' ? 'Admin' : 'Agent')}</span> <span className="text-tg-sub">· {r.device} · {new Date(r.at).toLocaleString()}</span><br />
            <span className={r.played === 'none' ? 'text-tg-bad' : 'text-tg-ok'}>{r.kind === 'sync' ? (r.data.own_downloaded ? 'sound saved' : 'sound not saved') : PLAYED[r.played] || r.played}</span>
            <span className="text-tg-sub">{r.data.ringer_mode ? ` · ringer ${String(r.data.ringer_mode)}` : ''}{r.data.alarm_volume !== undefined ? ` · alarm vol ${String(r.data.alarm_volume)}/${String(r.data.alarm_volume_max ?? '')}` : ''}{r.reason ? ` · ${r.reason}` : ''}</span>
          </p>
        ))}
      </div>
      <PhonesRegistered api={api} />
    </div>
  );
}
/** v139: every phone's push registration — who, which app (android4 = the new app with our own push receiver), when it last
 *  registered, and the last setup error the phone reported. Old rows say "old app – open the new app". */
type Phone = { key: string; role: string; name: string; platform: string; app_version: string | null; device: string | null; via: string | null; at: number; old: boolean; old_why: string; last_error: string; seen_at?: number | null; seen_version?: string | null; not_reaching?: boolean; reg_hint?: string };
function PhonesRegistered({ api }: { api: Api }) {
  const toast = useToast();
  const [rows, setRows] = useState<Phone[] | null>(null);
  const [busy, setBusy] = useState(false);
  const load = useCallback((manual = false) => {
    setBusy(true);
    void api<{ phones: Phone[] }>('push_phones').then(r => { setRows(r.phones); if (manual) toast('Updated'); }).catch(e => { setRows([]); if (manual) toast((e as Error).message, 'err'); }).finally(() => setBusy(false));
  }, [api, toast]);
  useEffect(() => { load(); }, [load]);
  return (
    <div className="mt-3 rounded-lg bg-tg-panel p-2.5" data-phones>
      <div className="mb-1 flex items-center justify-between"><p className="text-[13px] font-medium">Phones registered</p><button type="button" onClick={() => load(true)} disabled={busy} className="inline-flex items-center gap-1 text-[12.5px] text-tg-link disabled:opacity-60"><RotateCw size={13} className={busy ? 'animate-spin' : ''} />Refresh</button></div>
      {!rows ? <p className="text-[12.5px] text-tg-sub">Loading…</p> : !rows.length ? <p className="text-[12.5px] text-tg-sub">No phone is registered yet. Open the Android app on each phone.</p> : rows.map(r => (
        <div key={r.key} data-phone-row={r.platform} className="border-t border-tg-line py-1.5 text-[12.5px] first-of-type:border-t-0">
          <p className="flex flex-wrap items-center gap-x-1.5"><span className="font-medium">{r.name}</span><span className="text-tg-sub">· {r.role}</span>
            <span className={clsx('rounded-full px-1.5 py-px text-[11px] font-semibold', r.old ? 'bg-tg-orange/20 text-tg-orange' : 'bg-tg-green/15 text-tg-ok')}>{r.platform}</span>
            <span className="text-tg-sub" data-phone-ver>app {r.app_version || r.seen_version || 'version unknown'}</span></p>
          <p className="text-tg-sub">{r.device ? r.device + ' · ' : ''}<span data-phone-reg>registered {new Date(r.at).toLocaleString()}</span>{r.via ? ` · ${r.via === 'native' ? 'by the app (native)' : 'by the app'}` : ''}</p>
          <p className="text-tg-sub" data-phone-seen>last seen (app opened): {r.seen_at ? new Date(r.seen_at).toLocaleString() : 'not since v143'}{r.seen_version && r.seen_version !== r.app_version ? ` · app ${r.seen_version}` : ''}</p>
          {r.not_reaching && <p className="text-tg-orange" data-phone-notreach>{r.reg_hint}</p>}
          {r.old && <p className="text-tg-orange" data-phone-old>{r.old_why}</p>}
          {r.last_error && <p className="text-tg-bad">Last setup error: {r.last_error}</p>}
        </div>
      ))}
    </div>
  );
}

function LogoPanel({ api, s, set, onDone }: { api: Api; s: Record<string, string>; set: (k: string, v: string) => void; onDone: () => void }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  async function up(f: File | null, remove = false) {
    const fd = new FormData();
    if (remove) fd.append('remove', '1'); else if (f) fd.append('file', f); else return;
    setBusy(true);
    try { await api('logo', fd); toast(remove ? 'Logo removed' : 'Logo saved. It shows on all landing pages.'); onDone(); }
    catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); }
  }
  return (
    <div className="mb-4 flex items-center gap-4 rounded-xl bg-tg-input p-3">
      <div className="grid h-16 w-16 shrink-0 place-items-center overflow-hidden rounded-2xl bg-black/30">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        {s.logo_file && s.logo_mode === 'upload' ? <img src={`/api/logo?v=${s.logo_ver}`} alt="Logo" className="h-full w-full object-contain" /> : <img src={`/brand/logo.png?size=256&v=${encodeURIComponent((s.brand_name || '') + s.theme)}`} alt="Auto logo" title="Auto logo (no logo uploaded)" className="h-full w-full object-cover" />}
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-[14.5px] font-medium">Logo</p>
        <p className="text-[12.5px] text-tg-sub">Square PNG, at least 512×512. Shown in the top bar, footer and browser tab.</p>
        <div className="mt-2 flex flex-wrap gap-2">
          <label className={clsx('cursor-pointer rounded-lg bg-tg-acc px-3 py-1.5 text-[13.5px] font-medium text-white', busy && 'opacity-60')}>
            {busy ? 'Uploading…' : s.logo_file ? 'Change logo' : 'Upload logo'}
            <input type="file" accept="image/png,image/jpeg,image/webp,image/svg+xml" className="hidden" onChange={e => { void up(e.target.files?.[0] || null); e.target.value = ''; }} />
          </label>
          {s.logo_file && <button onClick={() => void up(null, true)} className="rounded-lg px-3 py-1.5 text-[13.5px] text-tg-red hover:bg-white/5">Remove</button>}
        </div>
        {s.logo_file && (
          <div className="mt-3 flex items-center justify-between gap-3">
            <span className="text-[12.5px] text-tg-sub">Use auto logo (first letter in each landing page's colours) instead of the uploaded one. Press Save after changing.</span>
            <Toggle on={s.logo_mode !== 'upload'} onChange={v => set('logo_mode', v ? 'auto' : 'upload')} />
          </div>
        )}
      </div>
    </div>
  );
}

function AutoMsgPanel({ api, s, set }: { api: Api; s: Record<string, string>; set: (k: string, v: string) => void }) {
  const toast = useToast();
  const [info, setInfo] = useState<any>(null);
  const [f, setF] = useState({ api_id: '', api_hash: '', phone: '', code: '', password: '' });
  const [step, setStep] = useState<'idle' | 'code' | 'password'>('idle');
  const [busy, setBusy] = useState(false);
  const load = useCallback(() => api('ub_info').then(setInfo).catch(() => {}), [api]);
  useEffect(() => { void load(); }, [load]);
  useInterval(() => { void load(); }, 15000);
  const go = async (fn: () => Promise<void>) => { setBusy(true); try { await fn(); } catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); } };
  const sendCode = () => go(async () => { await api('ub_send_code', { api_id: f.api_id || s.ub_api_id, api_hash: f.api_hash, phone: f.phone }); setStep('code'); toast('Code sent to the Telegram app of that account'); });
  const signIn = () => go(async () => {
    const r = await api('ub_sign_in', { code: f.code, password: f.password });
    if (r.need_password) { setStep('password'); toast('This account has 2-step verification. Enter its password.'); return; }
    setStep('idle'); setF({ ...f, code: '', password: '' }); toast(`Logged in as ${r.me}`); await load();
  });
  return (
    <>
      <div className="mb-3 flex items-center justify-between rounded-xl bg-tg-input px-4 py-3">
        <span><span className="block">Send the first message automatically</span><span className="text-[12.5px] text-tg-sub">{s.auto_msg_on === '1' ? 'ON — people who don’t write get a message from your chat account' : 'OFF — nobody gets an automatic first message'}</span></span>
        <Toggle on={s.auto_msg_on === '1'} onChange={v => set('auto_msg_on', v ? '1' : '0')} />
      </div>
      <p className="mb-3 rounded-xl bg-tg-input p-3 text-[13px] leading-relaxed text-tg-sub">
        Someone fills the form but doesn’t write on Telegram (for example their account can’t message strangers). After the wait time below, your chat account sends them the first message using their phone number. When they reply, the chat goes to an agent like any other lead. Telegram bots can’t write first, so the chat account has to be logged in here once.
      </p>
      <div className="mb-3 rounded-xl border border-white/10 p-3">
        {info?.logged_in ? (
          <>
            <p className="text-[14.5px]">Chat account: <b className="text-tg-ok">{info.me || 'logged in'}</b></p>
            <p className="mt-1 text-[12.5px] text-tg-sub">Status: {info.status || '—'}</p>
            {info.pace?.tga_stop_until > 0 && (
              <p className="mt-2 rounded-lg bg-tg-red/15 px-3 py-2 text-[13px] text-tg-red" data-spam-stop>Telegram put a spam limit on this account ({info.pace.tga_stop_why || 'PEER_FLOOD'}). Automatic messages from it are paused until {new Date(info.pace.tga_stop_until).toLocaleString()}; sending by hand still works (replies to people who wrote first). WhatsApp and the bot are not affected. Open @SpamBot in that Telegram account, fix the limit, then press <button className="font-semibold underline" onClick={() => go(async () => { await api('ub_resume', {}); await load(); })}>Resume</button> — the waiting messages then go out slowly at the normal sending speed, never all at once.</p>
            )}
            {info.pace?.first_until > 0 && <p className="mt-2 rounded-lg bg-tg-orange/15 px-3 py-2 text-[13px] text-tg-orange">First messages to new people are paused until {new Date(info.pace.first_until).toLocaleString()} (48 h after a Telegram limit).</p>}
            {info.paused_until > 0 && (
              info.paused_until > 8e15
                ? <p className="mt-2 rounded-lg bg-tg-red/15 px-3 py-2 text-[13px] text-tg-red">Stopped: Telegram put a spam limit on this account, so nothing is being sent from it (no retries). Open @SpamBot in that Telegram account, fix the limit, then press <button className="font-semibold underline" onClick={() => go(async () => { await api('ub_resume', {}); await load(); })}>Resume</button>.</p>
                : <p className="mt-2 rounded-lg bg-tg-orange/15 px-3 py-2 text-[13px] text-tg-orange">Paused until {new Date(info.paused_until).toLocaleString()} because Telegram asked to slow down. It restarts by itself. <button className="underline" onClick={() => go(async () => { await api('ub_resume', {}); await load(); })}>Resume now</button></p>
            )}
            <div className="mt-3 grid grid-cols-2 gap-2 text-center text-[13px] sm:grid-cols-5">
              {[['Waiting', info.waiting], ['Messaged (24h)', info.last24.sent], ['Replied', info.last24.replied], ['Not on Telegram', info.last24.not_found], ['Failed', info.last24.failed]].map(([k, v]) => (
                <div key={k} className="rounded-lg bg-black/20 px-2 py-2"><p className="text-[11.5px] text-tg-sub">{k}</p><p className="font-semibold">{v}</p></div>
              ))}
            </div>
            <div className="mt-3 flex items-center justify-between gap-3 rounded-lg bg-black/20 px-3 py-2.5">
              <span><span className="block text-[14px]">Chat folders per agent</span><span className="text-[12px] text-tg-sub">{s.folders_on === '1' ? 'Your Telegram app shows a folder for each agent (Rahul, Avik…) with the chats they handle. Updates every 2 min.' : 'OFF — agent folders are removed from your Telegram app.'}</span>{info.folders_status && <span className="mt-0.5 block text-[12px] text-tg-link">{info.folders_status}</span>}</span>
              <Toggle on={s.folders_on === '1'} onChange={v => set('folders_on', v ? '1' : '0')} />
            </div>
            {s.folders_on === '1' && <div className="mt-2 flex items-center justify-between gap-3 rounded-lg bg-black/20 px-3 py-2.5">
              <span><span className="block text-[14px]">“Sold” folder per person</span><span className="text-[12px] text-tg-sub">{s.folders_sold_on !== '0' ? 'Next to each folder: “Sold Akash”, “Sold Babai”… with the chats where that person made a sale. Telegram allows 10 folders (20 with Premium) in total.' : 'OFF — no Sold folders.'}</span></span>
              <Toggle on={s.folders_sold_on !== '0'} onChange={v => set('folders_sold_on', v ? '1' : '0')} />
            </div>}
            <div className="mt-2 flex items-center justify-between gap-3 rounded-lg bg-black/20 px-3 py-2.5">
              <span><span className="block text-[14px]">Save leads as contacts</span><span className="text-[12px] text-tg-sub">{s.save_contacts === '1' ? `Every lead is saved as “${s.brand_name} Lead 12”, renamed to the customer’s name when sold, and deleted when the chat goes dead.` : 'OFF — leads are not saved as contacts.'}</span>{s.save_contacts === '1' && <span className="mt-1 block text-[12px] text-tg-orange">Important: in Telegram → Settings → Business → Chatbots, the bot must NOT exclude Contacts, otherwise it stops getting messages from saved leads.</span>}</span>
              <Toggle on={s.save_contacts === '1'} onChange={v => set('save_contacts', v ? '1' : '0')} />
            </div>
            <div className="mt-2 flex items-center justify-between gap-3 rounded-lg bg-black/20 px-3 py-2.5">
              <span><span className="block text-[14px]">Mute agents’ chats</span><span className="text-[12px] text-tg-sub">{s.mute_agent_chats === '1' ? 'Only the Manager’s chats notify you. All other agents’ chats are muted on the chat account.' : 'OFF — chats are unmuted again.'}</span></span>
              <Toggle on={s.mute_agent_chats === '1'} onChange={v => set('mute_agent_chats', v ? '1' : '0')} />
            </div>
            <div className="mt-2 flex items-center justify-between gap-3 rounded-lg bg-black/20 px-3 py-2.5">
              <span><span className="block text-[14px]">Block calls</span><span className="text-[12px] text-tg-sub">{s.calls_contacts_only === '1' ? 'Nobody can call the chat account (leads are saved as contacts, so “contacts only” would still let them call).' : 'OFF — everyone can call the chat account.'}</span></span>
              <Toggle on={s.calls_contacts_only === '1'} onChange={v => set('calls_contacts_only', v ? '1' : '0')} />
            </div>
            <button onClick={() => go(async () => { await api('ub_logout', {}); await load(); toast('Logged out'); })} className="mt-3 text-[13px] text-tg-red">Log out chat account</button>
          </>
        ) : (
          <>
            <p className="mb-2 text-[14.5px] font-medium">Log in the chat account (one time)</p>
            <ol className="mb-3 list-decimal pl-5 text-[12.5px] leading-relaxed text-tg-sub">
              <li>On a computer or phone browser open <b className="text-tg-text">my.telegram.org</b> and log in with the chat account’s number.</li>
              <li>Open <b className="text-tg-text">API development tools</b>, create an app (any name), copy <b className="text-tg-text">api_id</b> and <b className="text-tg-text">api_hash</b>.</li>
              <li>Paste them below with the chat account’s number, tap Send code, then type the code Telegram sends to that account.</li>
            </ol>
            {info?.status && <p className="mb-2 text-[12.5px] text-tg-orange">{info.status}</p>}
            <div className="grid gap-x-3 sm:grid-cols-2">
              <Field label="api_id"><input className={inputCls} inputMode="numeric" placeholder={s.ub_api_id || '1234567'} value={f.api_id} onChange={e => setF({ ...f, api_id: e.target.value })} /></Field>
              <Field label="api_hash"><input className={inputCls} placeholder={s.ub_api_hash || 'a1b2c3…'} value={f.api_hash} onChange={e => setF({ ...f, api_hash: e.target.value })} /></Field>
            </div>
            <Field label="Chat account phone number"><input className={inputCls} type="tel" placeholder="+91 98765 43210" value={f.phone} onChange={e => setF({ ...f, phone: e.target.value })} /></Field>
            {step !== 'idle' && <Field label="Login code from Telegram" hint="Type it here only. Never send this code to anyone in a chat — Telegram blocks the login if you do."><input className={inputCls} inputMode="numeric" autoComplete="one-time-code" value={f.code} onChange={e => setF({ ...f, code: e.target.value })} /></Field>}
            {step === 'password' && <Field label="2-step verification password"><input className={inputCls} type="password" value={f.password} onChange={e => setF({ ...f, password: e.target.value })} /></Field>}
            <div className="flex gap-2">
              <Btn busy={busy} onClick={() => void sendCode()} kind={step === 'idle' ? undefined : 'ghost'}>{step === 'idle' ? 'Send code' : 'Send again'}</Btn>
              {step !== 'idle' && <Btn busy={busy} onClick={() => void signIn()}>Log in</Btn>}
            </div>
          </>
        )}
      </div>
    </>
  );
}

const THEME_INFO: Record<string, [string, string[]]> = {
  purple: ['Magenta gradient', ['#1D0A4A', '#8A2FD0', '#F6A77B']], green: ['Green & white (chat)', ['#ECFBF0', '#14532D', '#C6F36B']],
  blue: ['Blue & white (card)', ['#F5F9FF', '#1663E6', '#38BDF8']], gold: ['Sunset orange', ['#0B0D1E', '#F43F5E', '#FB923C']],
};

/** Auto-made logo + Facebook cover from the brand name and the main theme (preview + download). */
function BrandKit({ base, s }: { base: string; s: Record<string, string> }) {
  const v = encodeURIComponent([s.brand_name, s.theme, s.headline, s.headline_accent, s.price_account, s.logo_ver].join('|'));
  const items: [string, string, string][] = [
    ['Logo / profile picture (1024 x 1024)', `/brand/logo.png?size=1024&v=${v}`, 'aspect-square w-24'],
    ['Wide logo (for white backgrounds)', `/brand/logo-wide.png?on=light&v=${v}`, 'h-12 bg-white px-2'],
    ['Wide logo (for dark backgrounds)', `/brand/logo-wide.png?on=dark&v=${v}`, 'h-12 bg-black px-2'],
    ['Facebook cover (1640 x 624)', `/brand/facebook-cover.png?v=${v}`, 'w-full'],
  ];
  return (
    <div className="mb-4 rounded-xl bg-tg-input p-3">
      <p className="text-[14px] font-semibold">Brand kit (made automatically)</p>
      <p className="mb-3 mt-1 text-[12.5px] leading-relaxed text-tg-sub">Made from your brand name (first letter = logo) and the main theme colours. Change the name or theme, press Save, and these update. An uploaded logo is used inside the cover.</p>
      <div className="grid grid-cols-1 gap-3">
        {items.map(([label, src, cls]) => (
          <div key={label} className="rounded-lg bg-tg-panel p-2.5">
            <p className="mb-2 text-[12.5px] text-tg-sub">{label}</p>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={base + src} alt={label} className={clsx('rounded-md object-contain', cls)} loading="lazy" />
            <a href={`${base}${src}&download=1`} download className="mt-2 inline-flex items-center gap-1 text-[13px] font-medium text-tg-link">Download PNG</a>
          </div>
        ))}
      </div>
    </div>
  );
}

/** Saves the settings, then checks the bot can make join links for the channel. */
function ChanCheck({ api, save }: { api: Api; save: () => Promise<void> }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const [res, setRes] = useState<{ ok: boolean; title?: string; chat?: string; error?: string } | null>(null);
  async function run() {
    setBusy(true);
    try { await save(); const r = await api<any>('chan_check', {}); setRes(r); toast(r.ok ? 'Channel connected' : 'Channel not ready', r.ok ? 'ok' : 'err'); }
    catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); }
  }
  return (
    <div className="mb-2">
      <Btn kind="ghost" busy={busy} onClick={() => void run()}>Save & check channel</Btn>
      {res && <p className={clsx('mt-2 rounded-xl px-3 py-2 text-[13.5px]', res.ok ? 'bg-tg-ok/15 text-tg-ok' : 'bg-tg-red/15 text-tg-red')}>{res.ok ? `Ready: ${res.title} (${res.chat}). The bot can make join links.` : res.error}</p>}
    </div>
  );
}

/** v136: Settings → Ads & tracking → Daily budgets & costs (moved from Ad spend; saved with the normal Save bar). */
function BudgetPanel({ s, T }: { s: Record<string, string>; T: (k: string, label: string, hint?: React.ReactNode, rows?: number, type?: string) => React.ReactNode }) {
  const total = ['ad_budget_agency', 'ad_budget_funnel', 'premium_ad_budget', 'ad_budget_telegram', 'ad_budget_ch_agency', 'ad_budget_ch_premium', 'ad_budget_ch_funnel', 'ad_budget_wa_agency', 'ad_budget_wa_premium', 'ad_budget_wa_funnel'].reduce((a, k) => a + (Number(s[k]) || 0), 0);
  return (
    <>
      <p className="mb-3 rounded-xl bg-tg-input p-3 text-[13px] leading-relaxed text-tg-sub">Each day’s budget is added to Ad spend by itself. If Meta spent a different amount on a day, change that day in More → Ad spend. Put 0 when an ad is off. Each line is its own ads only: Agency = the normal page, Premium = the /premium ad set, Funnel = /funnel, Telegram = the old /telegram ads, channel = the /agency/telegram, /premium/telegram and /funnel/telegram ads. Retargeting budgets are part of their line; they are only for the Home Retargeting tab. Now: <b className="text-tg-text">{usd(total)}/day</b>.</p>
      <p className="mb-2 text-[13px] font-semibold">Landing page ads</p>
      <div className="grid grid-cols-2 gap-x-3 sm:grid-cols-4">
        {T('ad_budget_agency', 'Agency ads / day', undefined, undefined, 'number')}
        {T('premium_ad_budget', 'Premium ads / day', undefined, undefined, 'number')}
        {T('ad_budget_funnel', 'Funnel ads / day', undefined, undefined, 'number')}
        {T('ad_budget_telegram', 'Telegram ads / day', undefined, undefined, 'number')}
      </div>
      <p className="mb-2 text-[13px] font-semibold">Channel ads</p>
      <div className="grid grid-cols-2 gap-x-3 sm:grid-cols-3">
        {T('ad_budget_ch_agency', 'Agency channel / day', undefined, undefined, 'number')}
        {T('ad_budget_ch_premium', 'Premium channel / day', undefined, undefined, 'number')}
        {T('ad_budget_ch_funnel', 'Funnel channel / day', undefined, undefined, 'number')}
      </div>
      <p className="mb-2 text-[13px] font-semibold">WhatsApp ads</p>
      <div className="grid grid-cols-2 gap-x-3 sm:grid-cols-3">
        {T('ad_budget_wa_agency', 'Agency WhatsApp / day', undefined, undefined, 'number')}
        {T('ad_budget_wa_premium', 'Premium WhatsApp / day', undefined, undefined, 'number')}
        {T('ad_budget_wa_funnel', 'Funnel WhatsApp / day', undefined, undefined, 'number')}
      </div>
      <p className="mb-2 text-[13px] font-semibold">Retargeting (part of the lines above)</p>
      <div className="grid grid-cols-2 gap-x-3 sm:grid-cols-3">
        {T('rt_budget_agency', 'Agency retargeting / day', undefined, undefined, 'number')}
        {T('rt_budget_premium', 'Premium retargeting / day', undefined, undefined, 'number')}
        {T('rt_budget_funnel', 'Funnel retargeting / day', undefined, undefined, 'number')}
      </div>
      {T('acct_cost', 'What one ad account costs us (USD)', 'Taken off the profit for every account sold.', undefined, 'number')}
      {T('max_discount_pct', 'Special price: how much lower an agent may go (%)', 'In Mark as sold and payment links an agent can change the price per account. They can go at most this % below the normal price (40 = $25 → lowest $15). The manager and you can set any price above $0.', undefined, 'number')}
    </>
  );
}

const SET_GROUPS: [string, string][] = [['sales', 'Sales & prices'], ['pay', 'Payments & website'], ['tg', 'Telegram'], ['wa', 'WhatsApp'], ['team', 'Team & messages'], ['alerts', 'Phone alerts'], ['landing', 'Landing pages'], ['ads', 'Ads & tracking'], ['account', 'Account']];

function SettingsView({ api, back, initialSec }: { api: Api; back?: () => void; initialSec?: string }) {
  const toast = useToast();
  const [s, setS] = useState<Record<string, string> | null>(null);
  const [orig, setOrig] = useState<Record<string, string>>({});
  const [meta, setMeta] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const [openSec, setOpenSec] = useState<string>(initialSec || '');
  const [pw, setPw] = useState({ current: '', next: '' });
  // search: opens every section and shows only the settings whose name / help / key match
  const [sq, setSq] = useState('');
  const [found, setFound] = useState(-1);
  const box = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const root = box.current; if (!root) return;
    const q = sq.trim().toLowerCase().replace(/\s+/g, ' ');
    const words = q.split(' ').filter(Boolean);
    const hit = (el: Element) => { const t = ((el.textContent || '') + ' ' + Array.from(el.querySelectorAll('[data-k]')).map(x => x.getAttribute('data-k')).join(' ')).toLowerCase().replace(/_/g, ' '); return words.every(w => t.includes(w)); };
    let total = 0;
    root.querySelectorAll<HTMLElement>('[data-sec]').forEach(sec => {
      const body = sec.querySelector<HTMLElement>('[data-sec-body]');
      const kids = (el: HTMLElement): HTMLElement[] => Array.from(el.children).flatMap(c => (c as HTMLElement).classList.contains('grid') && c.children.length > 1 && !c.querySelector('button') ? kids(c as HTMLElement) : [c as HTMLElement]);
      if (!q) { sec.style.display = ''; if (body) kids(body).forEach(c => (c.style.display = '')); return; }
      const headHit = hit(sec.querySelector('[data-sec-head]')!);
      let any = 0;
      if (body) for (const c of kids(body)) { const ok = headHit || hit(c); c.style.display = ok ? '' : 'none'; if (ok) any++; }
      sec.style.display = headHit || any ? '' : 'none';
      total += headHit || any ? 1 : 0;
    });
    setFound(q ? total : -1);
  });
  const load = useCallback(() => api('settings').then(r => { setS(r.settings); setOrig(r.settings); setMeta(r); }).catch(() => {}), [api]);
  useEffect(() => { void load(); }, [load]);
  // v136: deep link (e.g. Ad spend → Edit budgets): open that section and scroll to it
  const jumped = useRef(false);
  useEffect(() => {
    if (!s || !initialSec || jumped.current) return; jumped.current = true;
    setTimeout(() => box.current?.querySelector(`[data-sec-id="${initialSec}"]`)?.scrollIntoView({ block: 'start' }), 60);
  }, [s, initialSec]);
  const backLabel = useContext(PageBackLabel);
  // v167: Android Back / ‹ closes the open section (back to the hub)
  useBackEntry(!!openSec && !sq.trim(), () => { setOpenSec(''); window.scrollTo(0, 0); });
  const SEC_T: Record<string, string> = { prices: 'Prices & delivery', offers: 'Retargeting offers', web: 'Website orders', tg: 'Bot & chat account', welcome: 'Welcome & menu', automsg: 'Auto first message', channel: 'Telegram channel', chanads: 'Channel ads', wamaster: 'WhatsApp on / off', wati: 'WATI (WhatsApp chats)', wa: 'Community & buttons', routing: 'Routing & hours', agents: 'Quick replies & follow-ups', fmsgs: 'Funnel messages', push: 'Phone notifications', brand: 'Brand & theme', hero: 'Top of page', cards: 'Service cards', more: 'Other sections', premium: 'Premium page', funnel: 'Funnel page text', proof: 'Social proof', meta: 'Meta pixels', budgets: 'Daily budgets & costs', pw: 'Admin password' };
  if (!s) return <Page title="Settings" back={back}><Skeleton rows={6} h={64} /></Page>;
  const changed = Object.keys(s).filter(k => s[k] !== orig[k]);
  const set = (k: string, v: string) => setS(p => ({ ...(p || s), [k]: v })); // functional: two set() calls in a row both stick
  async function save(extra: Record<string, unknown> = {}) {
    setBusy(true);
    try {
      const body: Record<string, unknown> = { ...extra };
      changed.forEach(k => (body[k] = s![k]));
      const r = await api('settings_save', body);
      if (r.webhook) toast(r.webhook.ok ? `Saved. Bot @${r.webhook.bot_username} connected.` : `Saved, but Telegram: ${r.webhook.error}`, r.webhook.ok ? 'ok' : 'err');
      else toast('Settings saved. The landing pages are updated.');
      await load();
    } catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); }
  }
  const T = (k: string, label: string, hint?: React.ReactNode, rows?: number, type?: string) => type === 'number' && !rows ? (
    // v167: iOS form row — label left, value right; the help line under it
    <div key={k} className="mb-3 block" data-num-row>
      <label className="flex items-center gap-3 rounded-xl bg-tg-input py-1 pl-3.5 pr-1">
        <span className="min-w-0 flex-1 py-1.5 text-[14.5px] leading-snug" data-k={k}>{label}</span>
        <input className="af-numin h-9 w-[92px] shrink-0 rounded-lg bg-transparent px-2 text-right text-[16px] font-semibold text-tg-text outline-none af-num focus:bg-tg-panel" type="number" inputMode="decimal" value={s[k] ?? ''} onChange={e => set(k, e.target.value)} />
      </label>
      {hint && <span className="mt-1 block px-1 text-[12px] leading-relaxed text-tg-sub/80">{hint}</span>}
    </div>
  ) : (
    <Field key={k} label={<span data-k={k}>{label}</span>} hint={hint}>
      {rows ? <textarea className={inputCls} rows={rows} value={s[k] ?? ''} onChange={e => set(k, e.target.value)} />
        : <input className={inputCls} type={type} inputMode={type === 'number' ? 'decimal' : undefined} value={s[k] ?? ''} onChange={e => set(k, e.target.value)} />}
    </Field>
  );
  /** a switch stored as '1' / '0'. def1 = ON unless it is '0'. */
  const Tg = (k: string, title: React.ReactNode, sub?: React.ReactNode, def1 = false, strong = false) => <ToggleRow key={k} k={k} strong={strong} title={title} sub={sub} on={def1 ? s[k] !== '0' : s[k] === '1'} onChange={v => set(k, v ? '1' : '0')} />;
  const tog = (id: string) => { if (sq.trim()) return; setOpenSec(o => (o === id ? '' : id)); window.scrollTo(0, 0); };
  const S = (id: string, title: string, desc: string, children: React.ReactNode) => <Section key={id} id={id} open={openSec === id} onToggle={() => tog(id)} title={title} desc={desc}>{children}</Section>;
  const G = (id: string) => !sq.trim() && !openSec && <h2 data-grp={id} className="af-h2 scroll-mt-[124px]"><span>{SET_GROUPS.find(g => g[0] === id)?.[1]}</span></h2>;
  const n0 = (k: string) => (s[k] ? `$${s[k]}` : '');
  const hubValue = (id: string): React.ReactNode => {
    if (id === 'prices') return [n0('price_account'), n0('price_premium'), n0('price_funnel')].filter(Boolean).join(' · ');
    if (id === 'offers') return s.offer_on === '1' ? 'On' : 'Off';
    if (id === 'wamaster') return s.wati_on === '1' ? (s.wa_on === '1' ? 'On' : 'Chats on') : <span className="text-tg-bad">Chats off</span>;
    if (id === 'automsg' && 'auto_msg_on' in s) return s.auto_msg_on === '1' ? 'On' : 'Off';
    return null;
  };
  const secTitle = openSec && !sq.trim() ? SEC_T[openSec] || 'Settings' : 'Settings';
  return (
    <PageBackLabel.Provider value={openSec && !sq.trim() ? 'Settings' : backLabel}>
    <Page title={secTitle} back={openSec && !sq.trim() ? () => history.back() : back}>
      {(!openSec || sq.trim()) && <div className="sticky top-[calc(50px+env(safe-area-inset-top))] z-10 -mx-4 mb-1 bg-tg-bg px-4 pb-2 md:top-0 md:-mx-8 md:px-8">
        <div className="flex h-[38px] items-center gap-2 rounded-xl bg-tg-panel px-3 shadow-[var(--tg-card-shadow)]">
          <Search size={17} className="shrink-0 text-tg-faint" />
          <input value={sq} onChange={e => setSq(e.target.value)} placeholder="Search: price, pixel, WhatsApp…" aria-label="Search settings" className="h-full min-w-0 flex-1 bg-transparent text-[15px] outline-none placeholder:text-tg-faint" />
          {sq && <button onClick={() => setSq('')} aria-label="Clear search" className="grid h-8 w-8 place-items-center rounded-full text-tg-sub hover:bg-tg-hover"><X size={17} /></button>}
        </div>
        {sq.trim() && <p className="mt-1.5 px-1 text-[12.5px] text-tg-sub">{found === 0 ? 'Nothing found. Try another word (e.g. “budget”, “telegram”, “fee”).' : `${found} section${found === 1 ? '' : 's'} match. Clear the search to see everything.`}</p>}
      </div>}
      <SettingsOpen.Provider value={{ open: sq.trim() ? '' : openSec, value: hubValue }}>
      <SettingsSearch.Provider value={sq.trim()}>
      <div ref={box}>
      {G('sales')}
      {S('prices', 'Prices & delivery', 'Ad account, Premium and funnel prices, delivery time, top-up fee', <>
        <div className="grid gap-x-3 sm:grid-cols-2">
          {T('price_account', 'Ad account price (USD)', 'Telegram price, what agents collect in a normal chat.', undefined, 'number')}
          {T('price_account_full', 'Full-access ad account price (USD)', 'Customer does top-ups himself, no fee; 1 account + 2 replacements. Used by the AI, payment links and the website.', undefined, 'number')}
          {T('price_premium_full', 'Full-access PREMIUM ad account price (USD)', 'Same, for a Premium account. Used by the AI, payment links and the website.', undefined, 'number')}
          {T('price_fb_old', 'Facebook account + Business Manager price (USD)', 'For people with no Facebook account or Business Manager: we create both. Shown on /products (ordered on Telegram). 0 = hidden.', undefined, 'number')}
          {T('price_funnel', 'Landing + funnel price (USD per month)', undefined, undefined, 'number')}
          {T('delivery_time', 'Delivery time', 'e.g. “1 hour”. Used everywhere as {delivery}.')}
          {T('payment_text', 'Payment methods', 'e.g. “USDT or UPI”.')}
          {T('topup_comm_pct', 'Top-up fee charged to client (%)', 'Our fee on every top-up, e.g. 3 → client adds $100 to the ad account and pays $103.', undefined, 'number')}
        </div>
        <p className="mb-2 mt-2 flex items-center gap-1.5 font-semibold"><Crown size={15} className="text-tg-gold" />Premium prices</p>
        <div className="grid gap-x-3 sm:grid-cols-2">
          {T('price_premium', 'Premium Telegram price (USD)', 'What agents collect in a Premium chat.', undefined, 'number')}
          {T('price_premium_web', 'Premium website price (USD)', 'Order on website from /premium.', undefined, 'number')}
          {T('premium_topup_pct', 'Top-up fee for Premium clients (%)', undefined, undefined, 'number')}
          {T('premium_delivery', 'Premium delivery time', 'e.g. “30 minutes”.')}
        </div>
      </>)}
      {S('offers', 'Retargeting offers', 'This week’s offer for people from retargeting ads (link ends with ?rt=1). Results are on Home → Retargeting', <>
        {Tg('offer_on', 'Offers ON', <>Only visitors from an ad link with <b className="text-tg-text">?rt=1</b> see it (top bar on the page, welcome message, prices in their chat, website order). Everyone else sees normal prices.</>, false, true)}
        <div className="grid gap-x-3 sm:grid-cols-2">
          {T('offer_agency_price', 'Agency — offer price per account (USD)', `Normal is $${s.price_account}. Must be lower, else no offer.`, undefined, 'number')}
          {T('offer_funnel_price', 'Funnel — first month price (USD)', `Normal is $${s.price_funnel}. Second month is normal.`, undefined, 'number')}
          {T('offer_premium_free', 'Premium — first top-up with 0% fee, up to (USD)', 'Premium price stays the same. 0 = no Premium offer.', undefined, 'number')}
          {T('offer_days', 'Chat keeps the offer for (days)', 'From the day they fill the form. 7 = one week.', undefined, 'number')}
        </div>
        {T('offer_agency_text', 'Agency offer text', '{offer_price} = offer, {normal_price} = normal price. Shown on the top bar and in the welcome message.', 2)}
        {T('offer_premium_text', 'Premium offer text', '{offer_max} = the 0% fee limit.', 2)}
        {T('offer_funnel_text', 'Funnel offer text', '{offer_price}, {normal_price}.', 2)}
      </>)}

      {G('pay')}
      {S('web', 'Website orders', 'Order & pay on the website, crypto (NOWPayments), payment links, INR / UPI, emails', <WebSettings s={s} set={set} T={T} baseUrl={meta?.base_url || ''} api={api} />)}

      {G('tg')}
      {S('tg', 'Bot & chat account', 'Bot token, who leads chat with, the chat account, Archived chats', <>
        {T('bot_token', 'Bot token', 'From @BotFather. Saving connects the webhook automatically.')}
        <div className="mb-4 flex flex-wrap items-center gap-3 rounded-xl bg-tg-input p-3 text-[14px]">
          <span className="flex-1">Bot: {s.bot_username ? <b className="text-tg-ok">@{s.bot_username}</b> : <span className="text-tg-orange">not connected</span>}</span>
          <Btn kind="ghost" className="!py-2 text-[14px]" onClick={async () => { try { const r = await api('webhook', {}); toast(r.ok ? `Webhook OK: ${r.webhook}` : r.error, r.ok ? 'ok' : 'err'); } catch (e) { toast((e as Error).message, 'err'); } }}>Check connection</Btn>
        </div>
        <Field label={<span data-k="tg_mode">Who do leads chat with?</span>}>
          <select className={inputCls} value={s.tg_mode} onChange={e => set('tg_mode', e.target.value)}>
            <option value="business">My personal Telegram account (Telegram Business), recommended</option>
            <option value="bot">The bot</option>
          </select>
        </Field>
        <p className="mb-4 rounded-xl bg-tg-input p-3 text-[13px] leading-relaxed text-tg-sub">
          Personal account: {meta?.business.connected ? <b className="text-tg-ok">connected to {meta.business.owner_name}{meta.business.owner_username ? ` (@${meta.business.owner_username})` : ''}</b> : <b className="text-tg-orange">not connected</b>}.<br />
          To connect: on the chat account open Telegram → Settings → Telegram Business → Chatbots (Chat Automation) → add @{s.bot_username || 'yourbot'} and allow it to reply. Set access to exclude your contacts so personal chats stay private. Needs Telegram Premium, a public username, and Secretary Mode (Business Mode) turned on for the bot in @BotFather. After connecting, send that account one message from another account. It connects on the first message too.
        </p>
        {T('owner_username', 'Chat account username', 'The Telegram username leads chat with, e.g. adsbhaisupport (without @). Fills itself when the account connects; you can also type it here.')}
        {T('proxy_chat_ids', 'Proxy checker — allowed Telegram chat IDs', 'Send a proxy list (.txt file or pasted, one login:password:host:port per line) to the bot from one of these chats and it tells you which ports are mobile, home WiFi or datacenter. Comma separated. The chat account owner can always use it.')}
        {T('prefill_text', 'Pre-typed first message (personal account mode)', 'Keep {code}. It links the chat to the form so the Lead event can be sent.')}
        {Tg('ub_unarchive', 'Keep lead chats out of “Archived”', `Telegram can put a customer who writes again (after you deleted the chat) into Archived, muted, so you never see it. This turns Telegram’s “Archive and mute new chats” OFF and moves lead chats back every minute.${s.unarchive_status ? ` Last: ${s.unarchive_status}` : ''}`, true)}
      </>)}
      {S('welcome', 'Welcome & menu', 'Welcome message, menu for people with no link, chat button, Telegram-didn’t-open', <>
        {Tg('welcome_on', 'Send automatic welcome message', undefined, true)}
        {T('welcome_msg', 'Welcome message (Telegram + WhatsApp)', '{name} = first name. Same message and same delay for WhatsApp chats. ' + PRICE_TAGS, 3)}
        <div data-menu-switch>{Tg('menu_on', 'Menu for people with no link (Telegram + WhatsApp)', s.menu_on !== '0' ? 'Someone who writes to us directly (no ad page, no channel, no community page) gets this 1/2/3/4 menu instead of the welcome above. Their answer sets the chat: 1 Agency, 2 Premium, 3 Funnel, 4 to the manager.' : 'OFF: they get the normal welcome above.', true)}</div>
        {s.menu_on !== '0' && T('menu_msg', 'Menu message (no link)', '{name} = first name, {price_account} Agency price, {price_premium} Premium price, {price_funnel} Funnel price, {delivery} Agency delivery, {delivery_premium} Premium delivery, {brand}. *bold* and _italic_ show on WhatsApp; on Telegram they are sent as plain text. Voice note text: AI → Voice notes → Welcome voice note.', 8)}
        {T('welcome_delay_sec', 'Send the welcome message after (seconds)', 'About this many seconds after their first message (±5s) so it feels human. 0 = instantly. Skipped if an agent already replied. Agents get the new-lead alert right AFTER the welcome is sent (not before). The same delay is used for website delivery messages on Telegram.', undefined, 'number')}
        <p className="mb-2 mt-4 font-semibold">“Chat with agent” button</p>
        {Tg('chat_btn_on', 'Show the button on landing pages', 'Small blue button bottom-right. Name + number → Telegram opens with the message below → goes to agents like any lead.')}
        {T('chat_btn_text', 'Button text', 'e.g. “Chat with agent”')}
        {T('chat_prefill_text', 'Pre-typed message for chat (keep {code})', 'Example: Hi! I have a question. My code: {code}')}
        {T('wa_msg', 'WhatsApp button message (Agency)', 'Typed for you when you tap WhatsApp on a lead. {name} = first name, {brand}, {tg_link} = that person’s own Telegram link (when they write there, the Lead event is sent). You can edit it in WhatsApp before sending.', 5)}
        {T('chat_welcome_msg', 'Welcome message for chat people', 'Sent instead of the normal welcome, after the same delay. {name} = first name. ' + PRICE_TAGS, 3)}
        <p className="mb-2 mt-4 font-semibold">Telegram didn’t open → website order</p>
        {Tg('tg_fallback_on', 'Offer the website order if the Telegram chat doesn’t start', 'After the form, the page checks if the person really started the chat. If not (no Telegram, Facebook/Instagram browser blocked it…), it shows “Order on website” with their name and number already filled in. Needs Website orders switched on.')}
        {T('tg_fallback_sec', 'Show it after (seconds)', 'If the chat hasn’t started by then. Inside the Facebook/Instagram app it shows after max 10 s. If the Telegram app clearly didn’t open on the phone, it shows right away.', undefined, 'number')}
        {T('tg_fallback_text', 'Text on that screen', undefined, 2)}
      </>)}
      {S('automsg', 'Auto first message', 'Message people who filled the form but didn’t write', <>
        <AutoMsgPanel api={api} s={s} set={set} />
        <div className="grid gap-x-3 sm:grid-cols-2">
          {T('auto_msg_delay_min', 'Wait before messaging (minutes)', 'Time after the form to give them a chance to write first.', undefined, 'number')}
          {T('auto_msg_hour_cap', 'Max first messages per hour', 'Keeps the chat account safe from Telegram spam limits. The lower of this and “Sending speed → first messages per hour” (5) applies.', undefined, 'number')}
        </div>
        {T('auto_msg_text', 'First message', '{name} = first name. ' + PRICE_TAGS, 3)}
        <p className="text-[12.5px] text-tg-sub">Tap “Save” at the bottom after changing the switch or these fields.</p>
      </>)}
      {S('channel', 'Telegram channel', 'Top bar on the landing pages, Subscribe event when someone joins, bot welcome and reminders', <>
        <p className="mb-3 rounded-xl bg-tg-input p-3 text-[13px] leading-relaxed text-tg-sub">
          Setup: 1) In the channel turn on <b className="text-tg-text">Approve new members</b>. 2) Add <b className="text-tg-text">@{s.bot_username || 'yourbot'}</b> to the channel as an <b className="text-tg-text">admin</b> with “Invite users via link”. 3) Fill the link below, Save, then tap <b className="text-tg-text">Check channel</b>.<br />
          Each visitor who taps the top bar gets their own join link. When they tap “Request to join”, a <b className="text-tg-text">Subscribe</b> event goes to Meta (Agency or Funnel pixel, once per person) and the request is approved.
        </p>
        {T('channel_link', 'Channel link', 'e.g. https://t.me/adsbhai (public) or your private invite link.')}
        {T('chan_sub_delay_min', 'Send Subscribe only if they stay (minutes)', 'Meta gets Subscribe only for people still in the channel after this time, so it finds people who stay. 60 = 1 hour. 0 = at once.', undefined, 'number')}
        {T('channel_chat', 'Channel @username or ID (only for a private channel)', 'Public channel: leave empty (taken from the link). Private channel: the -100… ID.')}
        <ChanCheck api={api} save={save} />
        <p className="mb-3 mt-3 rounded-xl bg-tg-input p-3 text-[13px] leading-relaxed text-tg-sub">Channel page for Subscribe ads: <b className="text-tg-text">{(typeof location !== 'undefined' ? location.origin : '') + '/telegram'}</b> (same design as your site; designs: /telegram/purple, /telegram/blue, /telegram/green, /telegram/gold). Joins from this page go to the Agency pixel. Top bar: Agency page → Agency pixel, Funnel page → Funnel pixel.</p>
        {Tg('chan_bar_on', 'Channel top bar on the landing pages', 'Agency and Funnel pages. Replaces the “Trusted by…” bar while ON.')}
        {T('channel_name', 'Channel name in the bar', 'Empty = your brand name. Used as {channel_name}.')}
        {T('chan_bar_text', 'Top bar text', '{channel_name} = the name above. Keep it short (one line on phones).')}
        {T('f_chan_bar_text', 'Top bar text on the Funnel page (optional)', 'Empty = same as above.')}
        {T('chan_bar_cta', 'Button text in the bar', 'e.g. “Join”.')}
        {Tg('chan_auto_approve', 'Auto join: approve every join request', 'ONE switch for all: channel-ad pages, website top bar, /telegram page, any link. OFF = you approve them yourself in Telegram (Subscribe is still sent). While ON, people still waiting are approved too (needs the chat account as a channel admin).')}
        <ApproveAll api={api} status={s.chan_approve_status} />
        {Tg('chan_info_btns', 'Info buttons in bot welcome', 'See pricing and What\'s included are answered right in the bot chat (same reply texts as the WhatsApp buttons, prices from these settings). Only Get account / Buy Premium / Start my funnel / Talk to agent open your support chat with the message typed, so the lead and the Contact event come only from people who really write. OFF = the welcome as before.', true)}
        {Tg('chan_btn_img', 'Send the offer image with buttons', 'The bot welcome goes as ONE photo message: the image of that line (Agency / Premium / Funnel), a short caption (product + price, one next step) and the buttons. No image for a line, or Telegram refuses it → the text with the buttons, as before.', true)}
        <OfferImgPreview api={api} on={s.chan_btn_img !== '0'} />
        {Tg('img_on_replies', 'Also put the image on See pricing / What\'s included replies', 'Same switch for Telegram and WhatsApp. OFF (recommended) = those replies are text with the follow-up buttons only.')}
        {Tg('chan_join_dm_on', 'Bot sends a welcome message on the join request', 'Image + your services with a button each (opens the chat with your support account with the message typed, given to an agent), Order on website, WhatsApp. Once per person; not to people already chatting with you. Channel-ad pages send their own offer instead.', true)}
        {s.chan_join_dm_on !== '0' && <>
          {T('chan_join_dm_text', 'Welcome message', 'Use {brand}, {price_agency}, {price_premium}, {price_funnel}, {fee}. The Premium line is left out while Premium is off. Max 1024 characters (goes with the image).', 8)}
          {T('chan_back_text', 'Message for people who already chat with your support', 'When someone who already has a chat with your support account opens the bot: this + the image + a button straight to that chat. {name} = their first name, {support} = your support @username.', 5)}
          {T('chan_img_welcome', 'Own image for the welcome message (optional)', 'https link to a picture. Empty = the built-in AdsBhai image with all 3 services.')}
        </>}
        {Tg('bfu_on', 'Bot reminders: started the bot but never messaged support', `Up to 3 messages from the bot, same gaps as your follow-ups (${s.fu_hours || '12,24,24'} hours) and never in quiet hours. Each has a button to your support account (with their code) and your other products. Stops when they message support, block the bot, or after the 3rd.`, true)}
        {s.bfu_on !== '0' && <>
          {T('bfu1', 'Bot reminder 1', '{name} = first name, {support} = your support @username, {delivery}, {brand}.', 3)}
          {T('bfu2', 'Bot reminder 2', 'Sent after the 2nd follow-up gap.', 3)}
          {T('bfu3', 'Bot reminder 3 (last)', 'Sent after the 3rd gap. Then nothing more.', 3)}
        </>}
        {Tg('welcome_channel_on', 'Add the channel to the Telegram welcome message', 'OFF for now. Turn ON once the channel has some members.')}
        {s.welcome_channel_on === '1' && T('welcome_channel_line', 'Channel line in the welcome message', '{channel} = the channel link.')}
      </>)}
      {S('chanads', 'Channel ads (Agency / Premium / Funnel)', 'Subscribe ads → join → the bot sends the offer → button opens the chat with your support account. Results are on Home → Bot', <>
        <p className="mb-3 rounded-xl bg-tg-input p-3 text-[13px] leading-relaxed text-tg-sub">
          Run each as its own ad set (Website → Subscribe). When someone taps <b className="text-tg-text">Request to join</b>, the bot sends them the offer of that page (image + buttons) and the other services, then approves them at once and Meta gets <b className="text-tg-text">Subscribe</b>. A button opens the chat with your support account (@{s.owner_username || 'support'}) with the message typed; their first message makes a lead for that service, given to an agent like any other (Premium → Premium agents, Funnel → manager). Channel posts: link to the bot below, it shows all services first.
        </p>
        <div className="mb-3 grid gap-1.5 rounded-xl bg-tg-input p-3 text-[13px]">
          {(['agency', 'premium', 'funnel'] as const).map(l => <p key={l} className="break-all text-tg-sub"><b className="text-tg-text">{l === 'agency' ? 'Agency' : l === 'premium' ? 'Premium' : 'Funnel'}:</b> {meta?.base_url}/{l}/telegram <span className="text-[12px]">(designs: /{l}/telegram/purple · blue · green · gold)</span></p>)}
          <p className="break-all text-tg-sub"><b className="text-tg-text">Link for channel posts:</b> {s.bot_username ? `https://t.me/${s.bot_username}?start=ch` : 'set the bot first'}</p>
        </div>
        {s.bot_send_error && <p className="mb-3 rounded-xl bg-tg-red/10 p-3 text-[13px] text-tg-bad">Last problem sending a bot message: {s.bot_send_error}</p>}
        {Tg('chan_ad_dm_on', 'Bot sends the offer on the join request', 'Image + offer of that page, then the other services. Telegram allows it only before the request is approved, so it goes first.', true)}
        {Tg('chan_menu_on', 'Bot shows the services menu on /start', 'From the channel post link, or anyone who opens the bot. Picking a service starts the chat.', true)}
        {T('chan_dm_agency', 'Bot message — Agency page', 'Use {price_agency}, {fee}, {brand}. Sent with the image, in one message with the other services (max 1024 characters in all).', 7)}
        {T('chan_dm_premium', 'Bot message — Premium page', 'Use {price_premium}, {fee}, {brand}.', 7)}
        {T('chan_dm_funnel', 'Bot message — Funnel page', 'Use {price_funnel}, {brand}.', 7)}
        {T('chan_dm_upsell', 'Line before the other services', 'Same message, at the end: e.g. “We also do:” + the other services and prices (added automatically, with a button each). Empty = no line. The whole message must stay under 1024 characters to go with the image.')}
        <div className="mb-3 rounded-xl bg-tg-input px-4 py-3">
          <p data-k="chan_pick_event">Meta event when they message you from the channel</p>
          <p className="mb-2 text-[12.5px] text-tg-sub">For later: optimize the channel ad sets on it (phase 2), between Subscribe and Purchase. Contact keeps it apart from the Lead event of your DM-lead ads. Once per person, only for people who came from a channel ad.</p>
          <Seg value={s.chan_pick_event || 'Contact'} onChange={v => set('chan_pick_event', v)} items={[['Contact', 'Contact'], ['Lead', 'Lead'], ['off', 'Off']]} />
        </div>
        {T('chan_menu_text', 'Services menu text (/start)', 'Buttons: Agency, Premium, Funnel, Order on website, WhatsApp.', 3)}
        <div className="grid gap-x-3 sm:grid-cols-3">
          {T('chan_img_agency', 'Image — Agency (https link)', 'Empty = built-in image.')}
          {T('chan_img_premium', 'Image — Premium (https link)', 'Empty = built-in image.')}
          {T('chan_img_funnel', 'Image — Funnel (https link)', 'Empty = built-in image.')}
        </div>
      </>)}

      {G('wa')}
{S('wamaster', 'WhatsApp on / off', 'Master switches for WhatsApp chats in the apps and WhatsApp on the website', <>
      <ToggleRow k="wati_on" strong tone={s.wati_on === '1' ? undefined : 'warn'} title="WhatsApp chats in the apps (WATI)" sub="WhatsApp chats come into the agent and admin apps. OFF = no chats from the webhook, no sending, the WhatsApp pages go to your home page, no WhatsApp follow-ups or events." on={s.wati_on === '1'} onChange={v => set('wati_on', v ? '1' : '0')} />
      <ToggleRow k="wa_on" strong tone={s.wa_on === '1' ? undefined : 'warn'} title="WhatsApp on the website" sub="Community link, WhatsApp button, the Telegram-didn’t-open box, welcome line, agent number. OFF = all of it is hidden at once; the switches below stay as they are." on={s.wa_on === '1'} onChange={v => set('wa_on', v ? '1' : '0')} />
      </>)}
      {S('wati', 'WATI (WhatsApp chats)', 'API key, webhook, test message, pixels, follow-ups, WhatsApp ad pages', <WaChatsSettings api={api} s={s} set={set} T={T} noMaster />)}
      {S('wa', 'Community & website buttons', 'Community link (also used by the WhatsApp community ad pages), the WhatsApp button on the landing pages', <>
        {T('wa_comm_link', 'Community link', 'e.g. https://chat.whatsapp.com/… Empty = WhatsApp hidden everywhere.')}
        {T('wa_members', 'Members to show', 'e.g. 1.4K+, shown on the “Telegram didn’t open?” box. Empty = hidden.')}
        {Tg('wa_fab_on', 'WhatsApp button on the landing pages', 'Round green button bottom-right, above the chat button.')}
        {Tg('wa_fallback_on', 'Offer WhatsApp when Telegram doesn’t open', 'After the form, if the Telegram chat hasn’t started, the box shows “Join on WhatsApp”.')}
        {s.wa_fallback_on === '1' && T('wa_fallback_sec', 'Show the box after (seconds)', 'Inside the Facebook/Instagram app max 10 s.', undefined, 'number')}
        {s.wa_fallback_on === '1' && T('wa_fallback_text', 'Text in the box', undefined, 2)}
        {Tg('welcome_wa_on', 'Add WhatsApp to the Telegram welcome message', 'One extra line under the welcome (and under the channel line if that is ON).')}
        {s.welcome_wa_on === '1' && T('welcome_wa_line', 'WhatsApp line in the welcome message', '{wa_link} = the community link.')}
        {Tg('wa_agent_on', '“Chat with an agent on WhatsApp” in the box', 'OFF by default. These chats don’t come into the app.')}
        {T('wa_agent_number', 'Agent WhatsApp number', 'With country code, any format: +1 646 270 7080 or +91 98765 43210.')}
        {T('wa_agent_text', 'Pre-typed message', undefined, 2)}
      </>)}

      {G('team')}
      {S('routing', 'Routing & hours', 'No reply → next agent, working hours, quiet hours, time zone, funnel chats', <>
        {Tg('reassign_on', 'Move unanswered leads', s.reassign_on === '1' ? `If the agent doesn’t reply within ${s.reassign_min || 30} min (working hours only), the lead goes to the next agent. After every agent tried, it goes to the Manager; if the Manager doesn't reply either, it goes round the agents again until someone replies.` : 'OFF: leads stay with the first agent.')}
        <div className="grid gap-x-3 sm:grid-cols-2">
          {T('reassign_min', 'Reply within (minutes)', 'Default 30. Only working-hours minutes count.', undefined, 'number')}
          {T('cover_quiet_h', 'Cover: give back after quiet (hours)', 'Default 72. A chat the cover agent is still working on goes back to its owner after this many hours with no customer message.', undefined, 'number')}
          {T('cover_credit_days', 'Cover: credit window (days)', 'Default 7. A sale within this many days after the cover’s last message counts for the cover, unless the owner talked with the customer since.', undefined, 'number')}
          {T('cover_max_days', 'Cover: longest cover (days)', 'Default 7. A covered chat always goes back to its owner after this many days, with a summary of what the cover did.', undefined, 'number')}
          {T('work_hours', 'Working hours', 'e.g. 9-22 = 9 AM to 10 PM (your timezone). Outside these hours leads are not moved.')}
          {T('quiet_hours', 'Quiet hours (no alerts)', 'e.g. 22-9 = 10 PM to 9 AM. Empty = never quiet.')}
          {T('tz_offset_min', 'Timezone offset in minutes', 'India = 330. Used for Today / Yesterday.', undefined, 'number')}
          {T('default_cc', 'Default phone country code', 'Added to 10-digit numbers before hashing for Meta.')}
        </div>
        {Tg('funnel_to_agents', 'Funnel leads to agents', s.funnel_to_agents === '1' ? 'ON: funnel chats rotate between agents tagged “Funnel” (Agents → Edit), then the manager.' : (s.mgr_lines ?? 'funnel,premium').split(',').includes('funnel') ? 'OFF: every funnel chat goes to the manager.' : 'OFF, but the manager does not take Funnel (Agents → manager): funnel chats still go to agents tagged “Funnel”.')}
      </>)}
      {S('agents', 'Quick replies & follow-ups', 'Quick replies, follow-up messages and gaps, Dead-chat messages', <>
        {T('quick_replies', 'Quick replies (one per line)', PRICE_TAGS, 6)}
        <p className="mb-3 rounded-xl bg-tg-input p-3 text-[13px] leading-relaxed text-tg-sub">How follow-ups work: the clock starts from the agent’s last message that the client didn’t answer. Follow-up 1 is due after the first number of hours, follow-up 2 that many hours after follow-up 1 is sent, follow-up 3 the same. The chat goes to Dead only after follow-up 3 was sent and there is still no answer. Any message from the client resets everything. Agents can also set “Remind me” on a chat, which pauses follow-ups until then.</p>
        {Tg('fu_auto', 'Send follow-ups automatically', s.fu_auto === '1' ? 'ON: if the client doesn’t reply, follow-up 1, 2 and 3 go out by themselves through Telegram Business (after the gaps below, never in quiet hours). Any reply stops them.' : 'OFF: the agent gets a reminder and sends each follow-up himself.')}
        <div className="grid gap-x-3 sm:grid-cols-2">
          {T('fu_hours', 'Follow-up gaps (hours)', 'Three numbers, e.g. 12,24,24')}
          {T('dead_hours', 'Dead after follow-up 3 (hours)', undefined, undefined, 'number')}
        </div>
        {T('fu1', 'Follow-up 1 message', PRICE_TAGS + ' Tip: write 2–3 versions separated by || and each chat gets one of them.', 2)}{T('fu2', 'Follow-up 2 message', undefined, 2)}{T('fu3', 'Follow-up 3 message', undefined, 2)}
        {Tg('fu_vary', 'Vary the wording a little', 'ON: each automatic follow-up, bot reminder, dead-chat and first message picks one of your versions (||) and swaps a few words (Hi / Hello, “just checking in” / “just following up” …), so 30 chats never get the very same text. Your text stays the base; nothing is added.', true)}
        <div data-pace-settings className="mb-3 mt-4 rounded-xl border border-white/10 p-3">
          <p className="font-semibold">Sending speed (all automatic messages)</p>
          <p className="mb-3 mt-1 text-[12.5px] leading-relaxed text-tg-sub">Follow-ups, welcomes, welcome voice notes, AI replies, reminders, dead-chat and first messages wait in a send queue and go out one by one at these speeds — so after quiet hours they are spread out instead of all at 9:00. Replies to people who wrote to us go first, then follow-up 1, 2, 3; first messages to new people last. Messages your team types are never delayed. Each channel has its own queue: a Telegram limit never holds WhatsApp back.</p>
          {Tg('pace_on', 'Limit the sending speed', 'Recommended ON. OFF = every automatic message goes the moment it is due (this is what caused the spam limit).', true)}
          <p className="mb-1 mt-2 text-[13px] font-semibold">Telegram chat account</p>
          <div className="grid gap-x-3 sm:grid-cols-2">
            {T('pace_tga_gap', 'Gap between messages (seconds)', 'At least this long between two automatic messages. Default 90.', undefined, 'number')}
            {T('pace_tga_jitter', 'Plus a random extra (seconds)', '0 to this many seconds more, so it doesn’t look like a robot. Default 60.', undefined, 'number')}
            {T('pace_tga_hour', 'Max per hour', 'Default 20. 0 = no cap.', undefined, 'number')}
            {T('pace_tga_day', 'Max per 24 hours', 'Default 120.', undefined, 'number')}
            {T('pace_first_hour', 'First messages to new people per hour', 'People who never wrote to us — the riskiest message. Default 5.', undefined, 'number')}
            {T('pace_first_day', 'First messages to new people per day', 'Default 30.', undefined, 'number')}
            {T('pace_flood_h', 'Pause after a spam limit (hours)', 'Telegram says PEER_FLOOD → automatic messages from the account stop this long (or until Resume). Default 24.', undefined, 'number')}
            {T('pace_first_flood_h', 'First messages pause after any limit (hours)', 'Default 48.', undefined, 'number')}
            {T('pace_fw_margin', 'Extra wait after “slow down” (seconds)', 'Telegram says wait X seconds → we wait X + this. Default 30.', undefined, 'number')}
          </div>
          <p className="mb-1 mt-2 text-[13px] font-semibold">Telegram bot · WhatsApp</p>
          <div className="grid gap-x-3 sm:grid-cols-2">
            {T('pace_tgb_gap', 'Bot: gap (seconds)', 'Bot reminders. Default 3.', undefined, 'number')}
            {T('pace_tgb_min', 'Bot: max per minute', 'Default 30.', undefined, 'number')}
            {T('pace_wa_gap', 'WhatsApp: gap (seconds)', 'Default 20, plus the random extra below.', undefined, 'number')}
            {T('pace_wa_jitter', 'WhatsApp: random extra (seconds)', 'Default 15.', undefined, 'number')}
            {T('pace_wa_hour', 'WhatsApp: max per hour', 'Default 60.', undefined, 'number')}
          </div>
        </div>
        {Tg('revive_on', 'Messages to Dead chats', s.revive_on === '1' ? `Sent automatically ${String(s.revive_days || '7,15').split(',').map(x => x.trim()).join(' and ')} days after a chat goes Dead. The chat stays in Dead; if they reply it comes back to Leads.` : 'OFF')}
        {s.revive_on === '1' && (<>
          {T('revive_days', 'Days after Dead', 'Two numbers, e.g. 7,15')}
          {T('revive1', 'Dead-chat message 1', '{name} = first name. ' + PRICE_TAGS, 3)}{T('revive2', 'Dead-chat message 2', undefined, 3)}
        </>)}
      </>)}
      {S('fmsgs', 'Funnel messages', 'The funnel’s own welcome, quick replies, follow-ups and Dead-chat messages', <>
        <p className="mb-3 text-[12.5px] text-tg-sub">Same timing as the agency ones (welcome delay, auto first message, follow-up hours, dead-chat days). Leave a field empty to use the agency text. {'{name}'} = first name. {PRICE_TAGS}</p>
        {T('f_prefill_text', 'Pre-typed first message (keep {code})')}
        {T('f_wa_msg', 'WhatsApp button message', 'Typed for you when you tap WhatsApp on a funnel lead. {tg_link} = their own Telegram link.', 5)}
        {T('f_welcome_msg', 'Welcome message', undefined, 3)}
        {T('f_chat_welcome_msg', 'Welcome for "Chat with agent" on the funnel page', undefined, 3)}
        {T('f_auto_msg_text', 'Auto first message', undefined, 3)}
        {T('f_quick_replies', 'Quick replies (one per line)', undefined, 5)}
        {T('f_fu1', 'Follow-up 1', undefined, 2)}{T('f_fu2', 'Follow-up 2', undefined, 2)}{T('f_fu3', 'Follow-up 3', undefined, 2)}
        {T('f_revive1', 'Dead-chat message 1', undefined, 3)}{T('f_revive2', 'Dead-chat message 2', undefined, 3)}
      </>)}

      {G('alerts')}
      {S('push', 'Phone notifications', 'Firebase key, ring on silent, notification sound, test', <>
        {T('fcm_service_account', 'Firebase service account key (JSON)', 'Firebase console → Project settings → Service accounts → Generate new private key. Paste the whole file content here.', 6)}
        <div data-alarm-switch>{Tg('alarm_on', 'Ring on silent / vibrate', s.alarm_on !== '0' ? 'Team phones ring even on silent / vibrate, only inside working hours. Agents can\u2019t turn it off.' : 'OFF: phones on silent / vibrate stay quiet.', true)}</div>
        {s.alarm_on !== '0' && <div className="mb-3 rounded-xl bg-tg-input px-4 py-3" data-alarm-scope>
          <p className="mb-2 text-[14px]" data-k="alarm_scope">Rings for</p>
          <Seg value={s.alarm_scope === 'leads' ? 'leads' : 'all'} onChange={v => set('alarm_scope', v)} items={[['all', 'Every new message'], ['leads', 'New leads only']]} />
        </div>}
        <RingPeople api={api} globalOn={s.alarm_on !== '0'} />
        <SoundPanel api={api} s={s} set={set} onDone={() => void load()} />
        <Btn kind="ghost" onClick={() => window.dispatchEvent(new Event('af-notif-fix'))}><BellRing size={17} />Alerts when the app is closed: check this phone</Btn>
      </>)}

      {G('landing')}
      {S('brand', 'Brand & theme', 'Name, logo, theme and page title', <>
        {T('brand_name', 'Brand name', 'Shown on the landing pages, in the apps and in Telegram messages.')}
        <LogoPanel api={api} s={s} set={set} onDone={() => void load()} />
        <p className="mb-2 text-[13px] font-medium text-tg-sub" data-k="theme">Landing page theme (used on your main link)</p>
        <div className="mb-4 grid grid-cols-2 gap-2 lg:grid-cols-4">
          {(meta?.themes || []).map((t: string) => (
            <div key={t} className={clsx('rounded-xl border-2 p-3', s.theme === t ? 'border-tg-acc bg-tg-acc/10' : 'border-transparent bg-tg-input')}>
              <button onClick={() => set('theme', t)} className="w-full text-left">
                <span className="mb-2 flex gap-1">{THEME_INFO[t]?.[1].map(c => <span key={c} className="h-6 flex-1 rounded-md" style={{ background: c }} />)}</span>
                <span className="text-[14px] font-medium">{THEME_INFO[t]?.[0] || t}</span>
              </button>
              <button onClick={() => void openExternal(`${meta.base_url}/p/${t}`)} className="mt-1 flex items-center gap-1 text-[12.5px] text-tg-link">Preview <ExternalLink size={12} /></button>
            </div>
          ))}
        </div>
        <p className="mb-4 rounded-xl bg-tg-input p-3 text-[13px] leading-relaxed text-tg-sub">Main link: <b className="text-tg-text">{meta?.base_url}/</b> shows the selected theme. Every theme also has its own link (e.g. <b className="text-tg-text">{meta?.base_url}/p/green</b>) so you can test different pages in different ad sets. Leads show which page they came from.</p>
        <BrandKit base={meta?.base_url || ''} s={s} />
        {T('seo_title', 'Browser tab title', 'Use {brand}, {delivery}, {price_account} to insert values.')}
        {T('seo_description', 'Search / share description', undefined, 2)}
        {T('gsc_verify', 'Google Search Console verification', 'In Search Console choose "HTML tag", copy the tag and paste it here. Leave empty if you verify by DNS.')}
      </>)}
      {S('hero', 'Top of page', 'Badge, headline, description, Telegram box', <>
        {T('stock_badge', 'Small badge above headline')}
        {Tg('brand_verified', 'Verified tick after the brand name', 'Blue tick next to your name in the top bar of all 4 landing pages.')}
        {Tg('partner_on', 'Partner badge', "Shows a verified partner badge at the top of all 4 landing pages. Keep it ON only while your business is listed in Meta's partner directory.")}
        {s.partner_on === '1' && T('partner_text', 'Partner badge text', 'e.g. "Meta Business Partner".')}
        {T('headline', 'Headline')}
        {T('headline_accent', 'Headline ending (shown in colour)')}
        {T('subheadline', 'Description', undefined, 3)}
        <p className="mb-2 mt-4 font-semibold">Telegram explainer</p>
        {T('tg_note', 'Telegram box — main line', 'e.g. “Order on Telegram”. Shown with the Telegram logo under the description.')}
        {T('tg_note_sub', 'Telegram box — small line', 'e.g. “A real agent replies in minutes”.')}
      </>)}
      {S('cards', 'Service cards', 'Ad account and funnel cards', <>
        <p className="mb-2 font-semibold">Ad account card</p>
        {T('account_badge', 'Badge')}{T('account_title', 'Title')}{T('account_sub', 'Subtitle')}{T('account_bullets', 'Bullet points (one per line)', 'You can use {topup_fee} (your top-up %), {delivery}, {price_account}.', 5)}{T('account_cta', 'Button text')}
        <p className="mb-2 mt-4 font-semibold">Funnel card</p>
        {T('funnel_badge', 'Badge')}{T('funnel_title', 'Title')}{T('funnel_sub', 'Subtitle')}{T('funnel_bullets', 'Bullet points (one per line)', undefined, 4)}{T('funnel_cta', 'Button text')}
      </>)}
      {S('more', 'Other sections', 'Chat section, FAQ, final call to action, footer', <>
        {T('chat_title', 'Chat section title')}{T('chat_text', 'Chat section text', undefined, 2)}{T('demo_agent_name', 'Agent name in the demo chat')}
        {T('why_title', '“Why us” title')}
        {T('faq', 'FAQ (one per line: Question | Answer)', 'You can use {delivery}, {payment}, {price_account}.', 8)}
        {T('cta_title', 'Final section title')}{T('cta_text', 'Final section text', undefined, 2)}
        {T('footer_note', 'Footer note')}
      </>)}
      {S('premium', 'Premium page (/premium)', 'Price test: same page, Premium offer. Prices are in Sales & prices, results on Home → Premium', <>
        {Tg('premium_on', 'Premium page ON', `${meta?.base_url}/premium (your selected theme). Run it as its own ad set (same creative, same audience, only this link). Each theme too: /premium/purple · /premium/blue · /premium/green · /premium/gold.`, false, true)}
        {T('premium_badge', 'Badge')}
        {T('premium_headline', 'Headline')}{T('premium_accent', 'Headline — coloured part')}
        {T('premium_text', 'Text under the headline', 'Use {delivery}, {price_account}.', 2)}
        {T('premium_title', 'Card title')}{T('premium_sub', 'Card subtitle')}
        {T('premium_bullets', 'What Premium includes (one per line)', 'Write only what you really give. Customers and Meta check it.', 5)}
        {T('premium_seo_title', 'Google title for /premium')}
        {T('premium_seo_description', 'Google description for /premium', 'Use {brand}, {price_account}, {delivery}.', 2)}
      </>)}
      {S('funnel', 'Funnel page text', 'adsbhai.com/funnel: headline, FAQ, Google title', <>
        <p className="mb-3 rounded-xl bg-tg-input p-3 text-[13px] leading-relaxed text-tg-sub">Run your FUNNEL ads to <b className="text-tg-strong">{(typeof location !== 'undefined' ? location.origin : '') + '/funnel'}</b> (designs: /funnel/purple, /funnel/blue, /funnel/green, /funnel/gold). Run your ad account ads to the main link as before. Everyone who comes from the Funnel page is tracked on the funnel pixel (Ads & tracking), even if they order an ad account there.</p>
        {T('f_badge', 'Small badge above headline')}
        {T('f_headline', 'Headline')}{T('f_accent', 'Headline, coloured part')}
        {T('f_sub', 'Description', undefined, 3)}
        {T('f_why_title', '"Why us" title')}
        {T('f_faq', 'FAQ (one per line: Question | Answer)', PRICE_TAGS, 6)}
        {T('f_cta_title', 'Final call to action title')}{T('f_cta_text', 'Final call to action text', undefined, 2)}
        {T('f_seo_title', 'Google title (funnel page)')}{T('f_seo_description', 'Google description (funnel page)', undefined, 2)}
      </>)}
      {S('proof', 'Social proof', 'Top bar text, recent purchases ticker, viewer badge', <>
        <p className="mb-3 rounded-xl bg-tg-orange/10 p-3 text-[13px] leading-relaxed text-tg-orange" data-owner-note>Check before using: the activity filler and the viewer number are not real visitors. Pages that run paid ads must follow Meta’s ad rules.</p>
        {T('proof_text', 'Top bar text', 'e.g. “Trusted by 1,000+ advertisers”. Leave empty to hide the bar.')}
        {Tg('recent_on', 'Recent purchases ticker', 'Shows REAL sales and top-ups from the last 30 days above the headline, e.g. “Rahul S. bought an ad account on the website · $20 · 2h ago”. First name + initial only. Hidden until there is a real sale.')}
        {Tg('ticker_fill_on', 'Ticker - activity from across India', 'When ON, the ticker shows purchase activity with Indian names and cities. Rotates automatically. Keeps the ticker lively even before your first sale.')}
        <ToggleRow k="viewer_floor" title={'"X+ people are viewing this" badge'} sub="The number moves slowly and randomly between the two numbers below, plus real visitors on the page right now." on={Number(s.viewer_floor) > 0} onChange={v => set('viewer_floor', v ? '72' : '0')} />
        {Number(s.viewer_floor) > 0 && <div className="grid grid-cols-2 gap-x-3">{T('viewer_min', 'Lowest number', undefined, undefined, 'number')}{T('viewer_max', 'Highest number', undefined, undefined, 'number')}</div>}
      </>)}

      {G('ads')}
      {S('meta', 'Meta pixels', 'Agency pixel (main page) and Funnel pixel. Server-side events only', <>
        <p className="mb-3 rounded-xl bg-tg-input p-3 text-[13px] leading-relaxed text-tg-sub">Events from the main page (ad accounts) go to the Agency pixel: PageView, ViewContent, AddToCart, InitiateCheckout, Lead (only when the person actually messages on Telegram) and Purchase (first sale only). The Funnel page has its own pixel below. WhatsApp chats have their pixels in WhatsApp → WATI.</p>
        <p className="mb-2 font-semibold">Agency pixel</p>
        {T('pixel_id', 'Pixel / dataset ID')}
        {T('capi_token', 'Conversions API access token', 'Events Manager → your dataset → Settings → Generate access token.')}
        {T('test_event_code', 'Test event code (optional)', 'From Events Manager → Test events. Clear it before running real ads.')}
        {T('vc_delay_sec', 'PageView / ViewContent after (seconds on the page)', 'Sent only when the visitor really looked at the landing for this long (tab open and visible). Use these events for retargeting audiences. 0 = right away. The dashboard “visits” count uses the same rule.', undefined, 'number')}
        {T('graph_version', 'Graph API version', 'Leave as is unless Meta says otherwise.')}
        <p className="mb-2 mt-4 font-semibold">Funnel pixel</p>
        {T('f_pixel_id', 'Pixel / dataset ID (funnel)', 'Empty = funnel page events go to the agency pixel.')}
        {T('f_capi_token', 'Conversions API access token (funnel)')}
        {T('f_test_event_code', 'Test event code (funnel, optional)', 'Clear it before running real ads.')}
      </>)}
      {S('budgets', 'Daily budgets & costs', 'Ad budget per line and day, retargeting budgets, what an ad account costs us', <BudgetPanel s={s} T={T} />)}

      {G('account')}
      {S('pw', 'Admin password', 'Change the password for this admin app', <>
        <Field label="Current password"><input className={inputCls} type="password" value={pw.current} onChange={e => setPw({ ...pw, current: e.target.value })} /></Field>
        <Field label="New password" hint="At least 8 characters. Other admin devices will be logged out."><input className={inputCls} type="password" value={pw.next} onChange={e => setPw({ ...pw, next: e.target.value })} /></Field>
        <Btn onClick={async () => { try { const r = await api('password', pw); try { localStorage.setItem('af_admin_t', r.token); } catch { } setPw({ current: '', next: '' }); toast('Password changed'); } catch (e) { toast((e as Error).message, 'err'); } }}>Change password</Btn>
      </>)}

      {changed.length > 0 && (
        <div className="af-page af-savebar mt-4 text-tg-text" data-save-bar>
          <span className="min-w-0 flex-1 truncate text-[14px] font-medium">{changed.length} change{changed.length > 1 ? 's' : ''}</span>
          <Btn kind="plain" onClick={() => setS(orig)}>Discard</Btn>
          <Btn busy={busy} onClick={() => void save()}>Save</Btn>
        </div>
      )}
    </div>
      </SettingsSearch.Provider>
      </SettingsOpen.Provider>
    </Page>
    </PageBackLabel.Provider>
  );
}

/* ---------------- Crypto coins customers can pick (v128) ---------------- */
type NpCoin = { id: string; name: string; network: string; ticker: string; on_np: boolean | null; memo: boolean };
const BASE_COINS: Record<string, string> = { usdtbsc: 'USDT · BEP20', trx: 'TRX · Tron' };
const OLD_COINS: Record<string, string> = { usdttrc20: 'USDT · TRC20', btc: 'Bitcoin', eth: 'Ethereum', ltc: 'Litecoin', bnbbsc: 'BNB · BEP20', sol: 'Solana' };
function CoinPicker({ s, set, api }: { s: Record<string, string>; set: (k: string, v: string) => void; api: Api }) {
  const toast = useToast();
  const coins = (s.np_currencies || '').split(/[,\s]+/).filter(Boolean);
  let meta: Record<string, { name: string; network: string; ticker: string }> = {};
  try { meta = s.np_coin_meta ? JSON.parse(s.np_coin_meta) : {}; } catch { meta = {}; }
  const label = (id: string) => BASE_COINS[id] || (meta[id] ? `${meta[id].name}${meta[id].network ? ' · ' + meta[id].network : ''}` : OLD_COINS[id] || id.toUpperCase());
  const shown = [...new Set([...Object.keys(BASE_COINS), ...coins, ...Object.keys(meta)])];
  const [open, setOpen] = useState(false);
  const [all, setAll] = useState<NpCoin[] | null>(null);
  const [q, setQ] = useState('');
  const [busy, setBusy] = useState(false);
  async function load() {
    setOpen(true); if (all) return;
    setBusy(true);
    try { setAll((await api<{ coins: NpCoin[] }>('np_coins')).coins); } catch (e) { toast((e as Error).message, 'err'); setOpen(false); } finally { setBusy(false); }
  }
  const add = (c: NpCoin) => {
    set('np_coin_meta', JSON.stringify({ ...meta, [c.id]: { name: c.name, network: c.network, ticker: c.ticker } }));
    if (!coins.includes(c.id)) set('np_currencies', [...coins, c.id].join(','));
    toast(`${c.name} added. Tap Save.`);
  };
  const remove = (id: string) => {
    const m = { ...meta }; delete m[id];
    set('np_coin_meta', Object.keys(m).length ? JSON.stringify(m) : '');
    set('np_currencies', coins.filter(c => c !== id).join(','));
  };
  const ql = q.trim().toLowerCase();
  const list = (all || []).filter(c => !ql || c.id.includes(ql) || c.name.toLowerCase().includes(ql) || c.network.toLowerCase().includes(ql) || c.ticker.toLowerCase().includes(ql)).slice(0, 60);
  return (
    <div className="mb-4" data-coins>
      <p className="mb-2 text-[13px] font-medium text-tg-sub">Coins customers can pick (tap to turn on / off)</p>
      <div className="mb-2 flex flex-wrap gap-2">
        {shown.map(v => {
          const on = coins.includes(v);
          const extra = !BASE_COINS[v];
          return (
            <span key={v} className={clsx('flex items-center rounded-full border text-[13.5px]', on ? 'border-tg-acc bg-tg-acc/15 text-tg-link' : 'border-white/10 text-tg-sub')}>
              <button data-coin={v} onClick={() => set('np_currencies', (on ? coins.filter(c => c !== v) : [...coins, v]).join(','))} className="py-1.5 pl-3 pr-3">{on ? '✓ ' : ''}{label(v)}</button>
              {extra && <button aria-label="Remove coin" onClick={() => remove(v)} className="-ml-1.5 pr-2.5 text-tg-sub hover:text-tg-red"><X size={14} /></button>}
            </span>
          );
        })}
      </div>
      {!coins.length && <p className="mb-2 text-[12.5px] text-tg-red">No coin is on, so customers can’t pay by crypto.</p>}
      {!open ? (
        <button onClick={() => void load()} className="flex items-center gap-1.5 text-[13.5px] text-tg-link"><Plus size={15} /> Add a coin from NOWPayments</button>
      ) : (
        <div className="rounded-xl bg-tg-input p-3">
          <div className="mb-2 flex items-center gap-2">
            <input className={clsx(inputCls, 'flex-1')} placeholder="Search: usdt, trc20, solana, btc…" value={q} onChange={e => setQ(e.target.value)} />
            <button onClick={() => setOpen(false)} className="px-2 text-[13.5px] text-tg-sub">Close</button>
          </div>
          {busy ? <p className="py-3 text-center text-[13px] text-tg-sub">Loading coins from NOWPayments…</p> : (
            <div className="max-h-[320px] overflow-y-auto" data-coin-list>
              {list.map(c => {
                const have = shown.includes(c.id);
                return (
                  <div key={c.id} className="flex items-center gap-2 border-b border-tg-line py-2 text-[13.5px] last:border-0">
                    <span className="min-w-0 flex-1"><b className="block truncate">{c.name}</b><span className="text-[12px] text-tg-sub">{c.network || '—'} · {c.id}{c.memo ? ' · needs memo' : ''}{c.on_np === false ? ' · turn it on in NOWPayments too' : ''}</span></span>
                    {have ? <span className="text-[12.5px] text-tg-sub">Added</span> : <button onClick={() => add(c)} className="rounded-full bg-tg-acc/15 px-3 py-1 text-[13px] text-tg-link">Add</button>}
                  </div>
                );
              })}
              {!list.length && <p className="py-3 text-center text-[13px] text-tg-sub">No coin found</p>}
            </div>
          )}
          <p className="mt-2 text-[12px] text-tg-sub">The coin must also be on in NOWPayments → Settings → Payments → Coins. Tap Save after adding.</p>
        </div>
      )}
    </div>
  );
}

/* ---------------- Website orders: settings ---------------- */
function WebSettings({ s, set, T, baseUrl, api }: { s: Record<string, string>; set: (k: string, v: string) => void; T: (k: string, label: string, hint?: React.ReactNode, rows?: number, type?: string) => React.ReactNode; baseUrl: string; api: Api }) {
  const toast = useToast();
  let host = 'yourdomain.com'; try { host = new URL(baseUrl).hostname.replace(/^www\./, ''); } catch { /* ignore */ }
  const ipn = `${baseUrl}/api/np/ipn`;
  const Sw = ({ k, title, sub }: { k: string; title: string; sub: string }) => <ToggleRow k={k} title={title} sub={sub} on={s[k] === '1'} onChange={v => set(k, v ? '1' : '0')} />;
  return (
    <>
      <Sw k="web_orders_on" title="Website orders" sub={s.web_orders_on === '1' ? 'ON — landing pages show “Order on website” with the lower price, plus /order and /account' : 'OFF — everything works through Telegram only, like before'} />
      <p className="mb-3 rounded-xl bg-tg-input px-3 py-2.5 text-[13px] text-tg-sub">Telegram price: <b className="text-tg-text">${s.price_account}</b> (Sales & prices)</p>
      <div className="grid gap-x-3 sm:grid-cols-2">
        {T('price_account_web', 'Website price per ad account (USD)', s.price_account && s.price_account_web && Number(s.price_account) > Number(s.price_account_web) ? `Landing shows “Save $${Math.round((Number(s.price_account) - Number(s.price_account_web)) * 100) / 100}”.` : 'Keep it lower than the Telegram price to show a “Save $” badge.', undefined, 'number')}
        {T('price_funnel_web', 'Website price for funnel (USD)', undefined, undefined, 'number')}
        {T('topup_min', 'Minimum website top-up (USD)', `Plus the ${s.topup_comm_pct}% top-up fee.`, undefined, 'number')}
      </div>
      {T('manager_tg', 'Manager Telegram (for customers)', 'Username or t.me link. Shown as “Contact your account manager”. Empty = your chat account.')}

      <p className="mb-2 mt-5 font-semibold">Crypto — NOWPayments</p>
      <ol className="mb-3 list-decimal rounded-xl bg-tg-input p-3 pl-8 text-[12.5px] leading-relaxed text-tg-sub">
        <li>nowpayments.io → sign up → add your payout wallet (USDT BEP20 recommended).</li>
        <li>Settings → Payments → API keys → create key → paste below.</li>
        <li>Settings → Payments → Instant payment notifications → create IPN secret → paste below, and set the callback URL to the link below.</li>
        <li>Settings → Payments → Coins: turn on the same coins you pick here. Payment address, QR and timer are shown inside your own page (no NOWPayments page).</li>
      </ol>
      <div className="mb-3 flex items-center gap-2 rounded-xl border border-white/10 px-3 py-2.5 text-[13.5px]"><span className="text-tg-sub">IPN URL</span><b className="min-w-0 flex-1 truncate">{ipn}</b><button className="text-tg-link" onClick={() => { try { void navigator.clipboard.writeText(ipn); toast('Copied'); } catch { } }}>Copy</button></div>
      {T('np_api_key', 'NOWPayments API key')}
      {T('np_ipn_secret', 'NOWPayments IPN secret', 'Used to check that “paid” messages really come from NOWPayments.')}
      <Sw k="agent_paylinks_on" title="Agents can send crypto payment links" sub="Agent app → chat → Payment link. Ad account at the Telegram price, top-up plus the top-up fee. The client pays on your website page; when paid, the sale or top-up is recorded for the agent and the manager gets a task." />
      <p className="mb-3 text-[12.5px] text-tg-sub">Paid less than the link: NOT confirmed. The client gets a Telegram / WhatsApp message with what came and what is left, and pays the rest on the same link. It confirms only when the full amount has come (Inbox → Short pays shows them).</p>
      {T('pay_window_min', 'Payment timer (minutes)', 'Countdown shown with the crypto address. Default 60. Late payments are still detected.', undefined, 'number')}
      <CoinPicker s={s} set={set} api={api} />

      <p className="mb-2 mt-5 font-semibold">INR payment</p>
      {T('inr_rate', '1 USD = ? INR', 'Used for INR prices in Telegram messages ({price_account_inr} etc.) and for INR payments on the website. Rounded up.', undefined, 'number')}
      <Sw k="inr_on" title="Allow paying in INR" sub="Customer sees the ₹ amount, pays, and enters the UTR. You confirm with “Mark as paid”." />
      {s.inr_on === '1' && (
        <>
          <Sw k="upi_on" title="Show UPI QR and app button" sub="Opens Paytm / PhonePe / GPay with the amount filled. OFF = customer contacts the manager to pay." />
          {s.upi_on === '1' && <div className="grid gap-x-3 sm:grid-cols-2">{T('upi_id', 'UPI ID', 'e.g. yourname@okaxis')}{T('upi_name', 'Payee name', 'Shown in the UPI app. Empty = brand name.')}</div>}
        </>
      )}

      <p className="mb-2 mt-5 font-semibold">Emails — Resend</p>
      <ol className="mb-3 list-decimal rounded-xl bg-tg-input p-3 pl-8 text-[12.5px] leading-relaxed text-tg-sub">
        <li>resend.com → sign up → Domains → Add <b className="text-tg-text">{host}</b> → add the DNS records it shows at your domain provider → Verify.</li>
        <li>API keys → Create (Sending access) → paste below.</li>
      </ol>
      {T('resend_api_key', 'Resend API key')}
      <div className="grid gap-x-3 sm:grid-cols-2">
        {T('email_from_name', 'Sender name', `Empty = “${s.brand_name}”.`)}
        {T('email_from', 'Sender email', `Empty = noreply@${host}`)}
      </div>
      <p className="text-[12.5px] text-tg-sub">Login codes, payment received, account delivered and top-up emails are sent from here. Tap “Save” at the bottom after changes.</p>
    </>
  );
}

/* v134: payment links paid short (not confirmed). The client was asked to pay the rest on the same link; it confirms when the rest arrives. */
function ShortPays({ api, onOpenChat }: { api: Api; onOpenChat: (id: number) => void }) {
  const [rows, setRows] = useState<any[] | null>(null);
  const load = useCallback(() => api<{ links: any[] }>('short_links').then(r => setRows(r.links)).catch(() => {}), [api]);
  useEffect(() => { void load(); }, [load]);
  useInterval(() => void load(), 20000);
  if (!rows) return <Skeleton rows={2} />;
  if (!rows.length) return <EmptyState text="No short payments. When a client pays less than a payment link, it shows here. It is not confirmed until the rest is paid on the same link." />;
  return (
    <div className="grid grid-cols-1 gap-2.5" data-short-pays>
      {rows.map(r => (
        <div key={r.id} className="af-card p-4">
          <div className="flex flex-wrap items-center gap-2"><b className="text-[15.5px]">{r.code}</b><span className="rounded-full bg-tg-warn/15 px-2 py-0.5 text-[12px] font-medium text-tg-warn">{usd(r.due)} due</span><span className="ml-auto text-[12.5px] text-tg-sub">{listTime(r.created_at)}</span></div>
          <p className="mt-1.5 text-[14px]">{r.label} · got <b>{usd(r.paid_usd)}</b> of {usd(r.total)}</p>
          <p className="mt-0.5 text-[13px] text-tg-sub">{[r.wa ? [r.cust_name, r.cust_phone].filter(Boolean).join(' · ') || 'WhatsApp customer' : '', r.agent_name].filter(Boolean).join(' · ')}</p>
          <div className="mt-3 flex flex-wrap gap-2">
            {r.lead_id && !r.wa && <Btn kind="ghost" className="py-2 text-[14px]" onClick={() => onOpenChat(r.lead_id)}>Open chat</Btn>}
          </div>
        </div>
      ))}
    </div>
  );
}

/* ---------------- Website orders: list ---------------- */
function WebOrders({ api, go, back }: { api: Api; go: Go; back?: () => void }) {
  const toast = useToast();
  const [view, setView] = useState<'orders' | 'topups'>('orders'); // v136: tasks + short pays are in Inbox
  const [d, setD] = useState<{ orders: any[]; topups: any[] } | null>(null);
  const load = useCallback(() => api('web_orders').then(setD).catch(() => {}), [api]);
  useEffect(() => { void load(); }, [view, load]);
  useInterval(() => void load(), 15000);
  async function act(path: string, body: object, msg: string) { try { await api(path, body); toast(msg); await load(); } catch (e) { toast((e as Error).message, 'err'); } }
  const rows = view === 'orders' ? d?.orders : d?.topups;
  return (
    <Page title="Website orders" back={back} right={<Seg value={view} onChange={setView} items={[['orders', 'Orders'], ['topups', 'Top-ups']]} />}>
      <button onClick={() => go('inbox', { inbox: 'tasks' })} className="mb-3 flex w-full items-center gap-2 rounded-xl bg-tg-panel px-4 py-3 text-left text-[14px] hover:bg-tg-hover"><InboxIcon size={17} className="text-tg-link" /><span className="flex-1">Tasks and short pays are in Inbox</span><ChevronRight size={17} className="text-tg-sub" /></button>
      {!rows ? <Skeleton rows={3} h={100} /> : !rows.length ? (
        <EmptyState text={view === 'orders' ? 'No website orders yet.' : 'No website top-ups yet.'} />
      ) : (
        <div className="grid grid-cols-1 gap-2.5">
          {rows.map((r: any) => {
            const t = view === 'orders' ? 'order' : 'topup';
            const unpaid = ['new', 'pending_payment', 'awaiting_inr', 'inr_review'].includes(r.status);
            return (
              <div key={r.id} className="af-card p-4">
                <div className="flex flex-wrap items-center gap-2">
                  <b className="text-[15.5px]">{r.code}</b><StatusChip s={r.status} />
                  <span className="ml-auto text-[12.5px] text-tg-sub">{listTime(r.created_at)}</span>
                </div>
                <p className="mt-1.5 text-[14px]">
                  {view === 'orders' ? (r.kind === 'funnel' ? 'Landing + funnel' : `${r.full ? 'Full access · ' : ''}${r.qty} ad account${r.qty > 1 ? 's' : ''} · BM ${r.bm_id}`) : `Top-up ${usd(r.amount)} → act_${r.act_id}`}
                  {' · '}<b>{usd(view === 'orders' ? r.amount : r.total)}</b>
                  {r.pay_method && <span className="text-tg-sub"> · {r.pay_method === 'inr' ? `INR ₹${r.inr_amount}${r.utr ? ' UTR ' + r.utr : ''}` : `crypto${r.pay_currency ? ' ' + String(r.pay_currency).toUpperCase() : ''}`}</span>}
                </p>
                <p className="mt-0.5 truncate text-[13px] text-tg-sub">{r.name || '—'} · {r.email}{r.phone ? ' · ' + r.phone : ''}</p>
                {r.accounts && <p className="mt-0.5 text-[13px] text-tg-ok">{String(r.accounts).split(',').map((a: string) => 'act_' + a).join(', ')}</p>}
                {(unpaid || r.task_id) && (
                  <div className="mt-3 flex flex-wrap gap-2">
                    {r.task_id && <Btn className="!py-2 text-[14px]" onClick={() => go('inbox', { inbox: 'tasks' })}>Open task</Btn>}
                    {unpaid && <Btn kind="ghost" className="py-2 text-[14px]" onClick={() => { if (confirm(`Mark ${r.code} as paid? Only do this if you received the money.`)) void act('mark_paid', { type: t, id: r.id }, 'Marked as paid — now deliver it from Tasks'); }}>Mark as paid</Btn>}
                    {unpaid && <Btn kind="danger" className="py-2 text-[14px]" onClick={() => { if (confirm(`Cancel ${r.code}?`)) void act('cancel_item', { type: t, id: r.id }, 'Cancelled'); }}>Cancel</Btn>}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </Page>
  );
}

/** Premium vs Standard (agency page) — leads, chats, sales, revenue, revenue per $ of ads. */
/** Retargeting offers: how many offer chats per line, sales, and what the offer cost (discount / waived fee). */
function OfferStats({ api, range }: { api: Api; range: Range }) {
  const [r, setR] = useState<any>(null);
  useEffect(() => { setR(null); api<any>(`offer_stats?range=${range}`).then(setR).catch(() => setR({ err: true })); }, [api, range]); // v136: the Home range
  const cell = 'px-2 py-1.5 text-right tabular-nums';
  const cols: [string, React.ReactNode][] = [['agency', 'Agency'], ['premium', <span key="p" className="inline-flex items-center gap-1 text-tg-warn"><Crown size={13} />Premium</span>], ['funnel', 'Funnel']];
  const lines: [string, (x: any) => string][] = [
    ['Offer chats (form leads)', x => String(x.leads)],
    ['Started Telegram chat', x => `${x.chats}${x.leads ? ` (${Math.round(x.chats / x.leads * 100)}%)` : ''}`],
    ['Bought', x => `${x.sales}${x.leads ? ` (${(x.sales / x.leads * 100).toFixed(1)}%)` : ''}`],
    ['Revenue', x => `$${x.revenue}`],
    ['Offer cost', x => `$${x.cost}`],
  ];
  return (
    <div className="mb-4 overflow-x-auto rounded-xl bg-tg-panel p-3 md:bg-tg-panel">
      <div className="mb-2 flex items-center justify-between gap-2"><b className="inline-flex items-center gap-1.5 text-[14px]"><Gift size={15} className="text-tg-gold" />Offer results</b>
      </div>
      {!r ? <p className="af-skel text-[13px] text-tg-sub">Loading</p> : r.err ? <p className="text-[13px] text-tg-sub">Could not load.</p> : (
        <>
          {!r.on && <p className="mb-2 text-[12.5px] text-tg-orange">Offers are OFF. Settings → Sales & prices → Retargeting offers.</p>}
          <table className="w-full text-[13px]">
            <thead><tr className="text-tg-sub"><th className="py-1 text-left font-normal" />{cols.map(([k, l]) => <th key={k} className={cell}>{l}</th>)}</tr></thead>
            <tbody>{lines.map(([l, f]) => <tr key={l} className="border-t border-tg-line"><td className="py-1.5 pr-2 text-tg-sub">{l}</td>{cols.map(([k]) => <td key={k} className={cell}>{f(r.rows[k])}</td>)}</tr>)}</tbody>
          </table>
          {r.web.orders > 0 && <p className="mt-2 text-[12.5px] text-tg-sub">Website orders with the offer: {r.web.orders} · ${r.web.revenue}</p>}
        </>
      )}
      <p className="mt-2 text-[12px] text-tg-sub">Offer cost = discount given on offer sales (Agency, Funnel) or the Premium top-up fee not charged.</p>
    </div>
  );
}

function ChanAdStats({ api, range }: { api: Api; range: Range }) {
  const [r, setR] = useState<any>(null);
  useEffect(() => { setR(null); api<any>(`chan_stats?range=${range}`).then(setR).catch(() => setR({ err: true })); }, [api, range]); // v136: the Home range
  const cell = 'px-2 py-1.5 text-right tabular-nums';
  const L = ['agency', 'premium', 'funnel'] as const;
  const rows: [string, (x: any) => string][] = [
    ['Join requests', x => String(x.joins)], ['Bot message delivered', x => String(x.dms)], ['Contacts (messaged us)', x => String(x.leads)],
    ['Sales (chats)', x => `${x.sales} · $${x.revenue}`], ['Website orders (paid)', x => `${x.orders} · $${x.order_rev}`],
  ];
  return (
    <div className="mb-4 overflow-x-auto rounded-xl bg-tg-panel p-3 md:bg-tg-panel">
      <div className="mb-2 flex items-center justify-between"><b className="text-[14px]">Results</b>
      </div>
      {!r ? <p className="af-skel text-[13px] text-tg-sub">Loading</p> : r.err ? <p className="text-[13px] text-tg-sub">Could not load.</p> : (<>
        <div className="overflow-x-auto"><table className="w-full min-w-[420px] text-[13px]">
          <thead><tr className="text-tg-sub"><th className="py-1 text-left font-normal" /><th className={cell}>Agency</th><th className={clsx(cell, 'text-tg-warn')}>Premium</th><th className={cell}>Funnel</th></tr></thead>
          <tbody>{rows.map(([l, f]) => <tr key={l} className="border-t border-tg-line"><td className="py-1.5 pr-2 text-tg-sub">{l}</td>{L.map(k => <td key={k} className={cell}>{f(r.lines[k])}</td>)}</tr>)}</tbody>
        </table></div>
        <p className="mt-2 text-[12.5px] text-tg-sub">Bot started: {r.bot_starts} in this time · {r.bot_subs_total} people in total have started the bot.</p>
      </>)}
    </div>
  );
}

function PremiumStats({ api, range }: { api: Api; range: Range }) {
  const [r, setR] = useState<any>(null);
  useEffect(() => { setR(null); api<any>(`premium_stats?range=${range}`).then(setR).catch(() => setR({ err: true })); }, [api, range]); // v136: the Home range
  const row = (k: 'standard' | 'premium') => r?.[k];
  const cell = 'px-2 py-1.5 text-right tabular-nums';
  const lines: [string, (x: any) => string][] = [
    ['Price (Telegram / website)', x => `$${x.price} / $${x.price_web}`],
    ['Form leads', x => String(x.leads)],
    ['Started Telegram chat', x => `${x.chats}${x.leads ? ` (${Math.round(x.chats / x.leads * 100)}%)` : ''}`],
    ['Sales (chats + website)', x => `${x.sales}${x.leads ? ` (${(x.sales / x.leads * 100).toFixed(1)}%)` : ''}`],
    ['Revenue', x => `$${x.revenue}`],
    ['Revenue per lead', x => (x.leads ? `$${(x.revenue / x.leads).toFixed(2)}` : '—')],
    ['Ad spend (budget × days)', x => (x.spend ? `$${x.spend}` : '—')],
    ['Revenue per $1 of ads', x => (x.spend ? `$${(x.revenue / x.spend).toFixed(2)}` : '—')],
  ];
  return (
    <div className="mb-4 overflow-x-auto rounded-xl bg-tg-panel p-3 md:bg-tg-panel">
      <div className="mb-2 flex items-center justify-between"><b className="text-[14px]">Test results</b>
      </div>
      {!r ? <p className="af-skel text-[13px] text-tg-sub">Loading</p> : r.err ? <p className="text-[13px] text-tg-sub">Could not load.</p> : (
        <table className="w-full text-[13px]">
          <thead><tr className="text-tg-sub"><th className="py-1 text-left font-normal" /><th className={cell}>Standard</th><th className={clsx(cell, 'text-tg-warn')}>Premium</th></tr></thead>
          <tbody>{lines.map(([l, f]) => <tr key={l} className="border-t border-tg-line"><td className="py-1.5 pr-2 text-tg-sub">{l}</td><td className={cell}>{f(row('standard'))}</td><td className={cell}>{f(row('premium'))}</td></tr>)}</tbody>
        </table>
      )}
      <p className="mt-2 text-[12px] text-tg-sub">Judge by “Revenue per $1 of ads” after 5–7 days with equal budgets. Fewer sales at a higher price can still win.</p>
    </div>
  );
}

/** v130: Campaigns (Meta campaign / ad → joins, chats, sales). */
function CampsPage({ api, back }: { api: Api; back?: () => void }) {
  const [range, setRange] = useState<Range>('7d');
  return <Page title="Campaigns" back={back} right={<RangePick value={range} onChange={setRange} />}><Campaigns api={api} range={range} /></Page>;
}

/* ---------------- v151: Ads data from Meta — master switch (Ad spend page) + numbers block (Home) ---------------- */
function MetaSwitch({ api, go, onChanged }: { api: Api; go: Go; onChanged: () => void }) {
  const toast = useToast();
  const [m, setM] = useState<any>(null);
  const [since, setSince] = useState('');
  const [busy, setBusy] = useState(false);
  const [open, setOpen] = useState(false);
  const load = useCallback(() => api('mads_status').then(r => { setM(r); setSince(s => s || r.since || new Date().toISOString().slice(0, 10)); }).catch(() => {}), [api]);
  useEffect(() => { void load(); }, [load]);
  const set = async (b: any, msg: string) => { setBusy(true); try { setM(await api('mads_set', b)); toast(msg); onChanged(); } catch (e) { toast((e as Error).message, 'err'); } finally { setBusy(false); } };
  const sync = async () => { setBusy(true); try { const r = await api('mads_sync', {}); toast(`Meta: ${r.rows} rows · ${r.days} day${r.days === 1 ? '' : 's'} · ${usd(r.spend)}`); await load(); onChanged(); } catch (e) { toast((e as Error).message, 'err'); await load(); } finally { setBusy(false); } };
  if (!m) return null;
  return (
    <div className="mb-4 af-card p-4" data-mads>
      <div className="flex items-center justify-between gap-3">
        <span className="min-w-0"><span className="block font-semibold">Ads data from Meta</span><span className="block text-[12.5px] text-tg-sub">{m.on ? `ON since ${m.since} · every number comes from Meta · checked ${m.last_sync ? listTime(m.last_sync) : '—'} (every ${m.every} min, same as Comments)` : 'OFF · daily budgets + what you type (as before)'}</span></span>
        <Toggle on={m.on} onChange={v => { if (!m.connected) { toast('Connect Meta first in Admin → Comments (same app, token and proxy)', 'err'); return; } void set(v ? { on: true, since } : { on: false }, v ? 'Meta data ON — first sync starts now' : 'Meta data OFF — daily budgets again from today'); if (v) setTimeout(() => void sync(), 300); }} label="Ads data from Meta" />
      </div>
      {!m.connected && <button onClick={() => go('comments')} className="mt-2 text-[13px] text-tg-link">Connect Meta in Comments (token + proxy) →</button>}
      {!m.on && m.connected && <div className="mt-3 flex flex-wrap items-center gap-2 text-[13px]"><span className="text-tg-sub">Start from</span><input type="date" className={clsx(inputCls, '!w-auto !py-2')} value={since} max={new Date().toISOString().slice(0, 10)} onChange={e => setSince(e.target.value)} /><span className="text-tg-sub">(days before keep their old numbers; max 90 days back)</span></div>}
      {m.on && <>
        {m.last_err && <p className="mt-2 rounded-lg bg-tg-red/15 px-3 py-2 text-[13px] text-tg-bad">{m.last_err}</p>}
        <div className="mt-3 flex flex-wrap gap-2">
          <Btn kind="ghost" busy={busy} className="!py-2 text-[14px]" onClick={() => void sync()}><RotateCw size={15} />Sync now</Btn>
          <Btn kind="ghost" className="!py-2 text-[14px]" onClick={() => setOpen(o => !o)}>Campaigns → lines ({m.camps.length})<ChevronDown size={15} className={clsx('transition-transform', open && 'rotate-180')} /></Btn>
        </div>
        <p className="mt-2 text-[12.5px] text-tg-sub">While ON the daily budgets are not used. A spend you type below for a Meta day is <b className="text-tg-text">added</b> as another ad account’s money (not in this token).</p>
        {open && <div className="mt-3 space-y-2" data-camp-map>
          {m.camps.map((c: any) => (
            <div key={c.camp} className="flex flex-wrap items-center gap-2 rounded-xl bg-tg-input px-3 py-2 text-[13px]">
              <span className="min-w-0 flex-1"><b className="block truncate">{c.camp || '(no name)'}</b><span className="text-tg-sub">{usd(c.spend)} · {c.msgs} messages · {c.days} day{c.days === 1 ? '' : 's'}{c.how !== 'set' ? ` · auto (${c.how === 'name' ? 'from the name' : c.how === 'chats' ? 'from its chats' : 'default'})` : ''}</span></span>
              <select className={clsx(inputCls, '!w-auto !py-1.5 text-[13px]')} value={c.how === 'set' ? c.line : 'auto'} onChange={e => void set({ line_map: { [c.camp]: e.target.value } }, 'Saved')}>
                <option value="auto">Auto: {m.lines[c.line]}</option>
                {Object.entries(m.lines).map(([k, l]) => <option key={k} value={k}>{l as string}</option>)}
              </select>
            </div>
          ))}
          {!m.camps.length && <p className="text-[13px] text-tg-sub">No campaigns yet — press Sync now.</p>}
        </div>}
      </>}
    </div>
  );
}

function MetaHome({ m }: { m: any }) {
  const n = (v: number | null | undefined) => (v == null ? '—' : Number(v).toLocaleString('en-IN'));
  return (
    <section className="mt-5" data-meta-home>
      <h2 className="mb-2 flex items-center gap-2 text-[15px] font-semibold">Meta ads<span className="rounded-full bg-tg-acc/15 px-2 py-0.5 text-[11px] font-semibold text-tg-link">live from Meta</span></h2>
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Card label="Spend (Meta)" value={usd(m.spend)} tone="orange" />
        <Card label="Messages started" value={n(m.msgs)} sub={m.cost_per_msg != null ? `${usd(m.cost_per_msg)} per message` : undefined} tone="blue" />
        <Card label="Cost per message" value={m.cost_per_msg == null ? '—' : usd(m.cost_per_msg)} sub="Meta’s own count" />
        <Card label="Link clicks" value={n(m.link_clicks)} sub={`CTR ${m.ctr ?? '—'}% · CPC ${m.cpc == null ? '—' : usd(m.cpc)}`} />
        <Card label="Impressions" value={n(m.impr)} sub={`CPM ${m.cpm == null ? '—' : usd(m.cpm)}`} />
        <Card label="Reach" value={n(m.reach)} sub={m.freq ? `Frequency ${m.freq}` : undefined} />
        {m.leads > 0 && <Card label="Leads (Meta)" value={n(m.leads)} sub={m.cost_per_lead != null ? `${usd(m.cost_per_lead)} each` : undefined} />}
        {m.subs > 0 && <Card label="Subscribes (Meta)" value={n(m.subs)} sub={m.cost_per_sub != null ? `${usd(m.cost_per_sub)} each` : undefined} />}
      </div>
    </section>
  );
}


/** v162: the owner's income — from the agents' work, own (manager) work, website / other; incentive is a separate account. Agents' earnings. */
function MyIncome({ m }: { m: { total: number; from_agents: number; from_me: number; other: number; me_names: string[]; other_parts: { web: number; no_agent: number; spend: number }; agents: { id: number; name: string; sales: number; comm: number; bonus: number; earn: number }[]; comm: number; bonus: number; after_bonus: number } }) {
  const tone = (v: number) => v >= 0 ? 'text-tg-ok' : 'text-tg-bad';
  const Row = ({ label, sub, v, k }: { label: string; sub?: string; v: number; k: string }) => (
    <div className="flex items-center gap-3 border-b border-tg-line px-4 py-2.5" data-mine={k}>
      <span className="min-w-0 flex-1"><span className="block text-[14.5px] font-medium">{label}</span>{sub && <span className="block text-[12px] text-tg-sub">{sub}</span>}</span>
      <b className={clsx('shrink-0 text-[15px] tabular-nums', tone(v))}>{usd(v)}</b>
    </div>
  );
  const otherSub = 'Website orders and website top-ups, sales and top-ups not on an agent (after their cost), minus ads not on anyone (e.g. Telegram channel ads)';
  const earnT = m.agents.reduce((x, a) => x + a.earn, 0);
  return (
    <section className="mt-5" data-my-income>
      <div className="mb-2 flex items-baseline justify-between gap-3"><h2 className="text-[15px] font-semibold">My income</h2><span className="text-[13px] text-tg-sub">Total <b className={tone(m.total)}>{usd(m.total)}</b></span></div>
      <div className="overflow-hidden af-card">
        <Row k="agents" label="From the agents' work" sub="Their sales − their commission, ads and account cost" v={m.from_agents} />
        <Row k="me" label={`From your own work${m.me_names.length ? ` (${m.me_names.join(', ')} · Manager)` : ''}`} sub="Manager sales: no commission, all yours" v={m.from_me} />
        {(m.other || otherSub) ? <Row k="other" label="Website and other" sub={otherSub || undefined} v={m.other} /> : null}
        <div className="flex items-center gap-3 bg-tg-input/50 px-4 py-2.5"><span className="flex-1 text-[14.5px] font-semibold">My income</span><b className={clsx('text-[16px] tabular-nums', tone(m.total))}>{usd(m.total)}</b></div>
        {m.bonus > 0 && <div className="flex items-center gap-3 px-4 py-2.5 text-[13px] text-tg-sub" data-mine="bonus"><span className="flex-1">Incentive given {usd(m.bonus)} (your separate account) → after incentive</span><b className={clsx('tabular-nums', tone(m.after_bonus))}>{usd(m.after_bonus)}</b></div>}
      </div>
      {m.agents.length > 0 && <>
        <h3 className="mb-2 mt-4 text-[13px] font-semibold uppercase tracking-wide text-tg-sub">Agents' earnings</h3>
        <div className="overflow-hidden af-card" data-agent-earn>
          {m.agents.map(a => (
            <div key={a.id} className="flex items-center gap-3 border-b border-tg-line px-4 py-2.5" data-earn={a.id}>
              <span className="min-w-0 flex-1"><span className="block truncate text-[14.5px] font-medium">{a.name}</span><span className="block text-[12px] text-tg-sub">{a.sales} sale{a.sales === 1 ? '' : 's'} · commission {usd(a.comm)}{a.bonus ? ` · incentive ${usd(a.bonus)}` : ''}</span></span>
              <b className="shrink-0 text-[15px] tabular-nums">{usd(a.earn)}</b>
            </div>
          ))}
          <div className="flex items-center gap-3 bg-tg-input/50 px-4 py-2.5 text-[14px] font-semibold"><span className="flex-1">Agents earned</span><span className="tabular-nums">{usd(earnT)}</span></div>
        </div>
      </>}
    </section>
  );
}
