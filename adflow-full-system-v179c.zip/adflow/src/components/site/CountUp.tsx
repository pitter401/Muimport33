'use client';

import { useEffect, useRef, useState } from 'react';
import { useInView, useReducedMotion } from 'framer-motion';

/**
 * Shows a number counting up from 0 the first time it scrolls into view (ease-out, ~1.6s).
 * People with "reduce motion" switched on see the final number straight away.
 * Non-numeric values (e.g. "20-25") are shown as they are.
 */
export function CountUp({ value, decimals, prefix = '', suffix = '', ms = 1600, delay = 0 }: {
  value: string | number; decimals?: number; prefix?: string; suffix?: string; ms?: number; delay?: number;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: '0px 0px -40px 0px' });
  const reduce = useReducedMotion();
  const target = typeof value === 'number' ? value : Number(String(value).replace(/,/g, ''));
  const numeric = Number.isFinite(target);
  const dec = decimals ?? (numeric && !Number.isInteger(target) ? 2 : 0);
  const [n, setN] = useState(0);
  useEffect(() => {
    if (!numeric || !inView) return;
    if (reduce) { setN(target); return; }
    let raf = 0;
    const t = setTimeout(() => {
      const start = performance.now();
      const step = (now: number) => {
        const k = Math.min(1, (now - start) / ms);
        setN(target * (1 - Math.pow(1 - k, 3)));
        if (k < 1) raf = requestAnimationFrame(step);
      };
      raf = requestAnimationFrame(step);
    }, delay);
    return () => { clearTimeout(t); cancelAnimationFrame(raf); };
  }, [numeric, inView, reduce, target, ms, delay]);
  if (!numeric) return <span>{prefix}{value}{suffix}</span>;
  return <span ref={ref} className="tabular-nums">{prefix}{n.toLocaleString('en-US', { minimumFractionDigits: dec, maximumFractionDigits: dec })}{suffix}</span>;
}
