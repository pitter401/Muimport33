/* Landing colours per theme (page-level CSS variables). Plain module so server pages can use it too. */
import type { CSSProperties } from 'react';

/* ---------------- colours (page-level CSS variables) ---------------- */
type Pal = { page: Record<string, string>; hero?: Record<string, string> };
const P: Record<string, Pal> = {
  purple: {
    page: {
      '--m-hero': 'linear-gradient(180deg,#000 0%,#07021a 12%,#1d0a4a 26%,#4a17a3 40%,#8a2fd0 54%,#c446c9 68%,#e8619b 82%,#f6a77b 100%)',
      '--m-band': 'linear-gradient(120deg,#1d0a4a 0%,#5a1db5 30%,#a73ad2 58%,#e45f9f 82%,#f6a77b 100%)',
      '--m-ink': '#1d1660', '--m-btn': 'linear-gradient(100deg,#5b21b6,#9333ea 55%,#d946ef)', '--m-deep': '#0f0628', '--m-accent': '#ffd8c8',
      '--m-grad': 'linear-gradient(135deg,#7c3aed,#d946ef)', '--m-board': 'linear-gradient(160deg,#c084fc 0%,#e879f9 35%,#f472b6 70%,#fb923c 100%)',
      '--m-card': 'linear-gradient(160deg,#1d0a4a,#4a17a3 55%,#8a2fd0)', '--m-step': 'linear-gradient(135deg,#5b21b6,#c446c9 60%,#f6a77b)',
      '--m-glow': 'radial-gradient(ellipse 70% 60% at 15% 100%,rgba(255,170,120,.35),transparent),radial-gradient(ellipse 60% 60% at 95% 80%,rgba(217,70,239,.35),transparent)',
      '--m-cardglow': 'rgba(246,167,123,.55)', '--m-foot': '#07021a', '--m-shadow': 'rgba(124,58,237,.6)',
    },
    hero: { '--s1': '36 16 78', '--s2': '50 22 102', '--s3': '66 30 126', '--p': '124 92 255', '--pd': '91 61 240', '--ps': '206 190 255', '--pt': '236 220 255', '--a': '232 121 249' },
  },
  blue: {
    page: {
      '--m-hero': 'radial-gradient(55% 55% at 90% 5%,#c7dcff 0%,transparent 70%),radial-gradient(45% 45% at 0% 35%,#dbeeff 0%,transparent 70%),radial-gradient(40% 35% at 60% 100%,#e6f0ff 0%,transparent 70%),linear-gradient(180deg,#f5f9ff,#ffffff)',
      '--m-band': 'linear-gradient(120deg,#061a4d 0%,#0b3aa8 35%,#1663e6 70%,#38bdf8 100%)',
      '--m-ink': '#071a4a', '--m-btn': 'linear-gradient(100deg,#0b3aa8,#1663e6)', '--m-deep': '#071a4a', '--m-accent': '#1663e6',
      '--m-grad': 'linear-gradient(135deg,#1663e6,#38bdf8)', '--m-board': 'linear-gradient(135deg,#0b3aa8 0%,#1663e6 55%,#2f86f5 100%)',
      '--m-card': 'linear-gradient(160deg,#061a4d,#0b3aa8 60%,#1663e6)', '--m-step': 'linear-gradient(135deg,#0b3aa8,#38bdf8)',
      '--m-glow': 'none', '--m-cardglow': 'rgba(125,211,252,.45)', '--m-foot': '#f2f6fd', '--m-shadow': 'rgba(22,99,230,.35)',
    },
  },
  green: {
    page: {
      '--m-hero': 'linear-gradient(180deg,#ecfbf0 0%,#f5fde9 100%)',
      '--m-band': '#c6f36b',
      '--m-ink': '#052e16', '--m-btn': 'linear-gradient(100deg,#14532d,#166534)', '--m-deep': '#052e16', '--m-accent': '#bef264',
      '--m-grad': 'linear-gradient(135deg,#15803d,#65a30d)', '--m-board': 'linear-gradient(135deg,#065f3a 0%,#15803d 55%,#4d7c0f 100%)',
      '--m-card': 'linear-gradient(160deg,#052e16,#14532d 60%,#166534)', '--m-step': 'linear-gradient(135deg,#15803d,#65a30d)',
      '--m-glow': 'none', '--m-cardglow': 'rgba(190,242,100,.35)', '--m-foot': '#052e16', '--m-shadow': 'rgba(21,128,61,.4)',
    },
  },
  // replaces the old gold page
  gold: {
    page: {
      '--m-hero': 'radial-gradient(130% 34% at 50% 52%,rgba(251,146,60,.55) 0%,rgba(244,63,94,.38) 35%,rgba(124,45,90,.25) 60%,transparent 80%),radial-gradient(95% 40% at 50% 104%,#fdba74 0%,#fb923c 16%,#f43f5e 36%,#7c2d5a 58%,transparent 80%),linear-gradient(180deg,#04050c 0%,#0b0d1e 45%,#1a1030 100%)',
      '--m-band': 'linear-gradient(120deg,#1a1030 0%,#7c2d5a 35%,#f43f5e 68%,#fb923c 100%)',
      '--m-ink': '#0b0d1e', '--m-btn': 'linear-gradient(100deg,#ea580c,#f97316 50%,#fb7185)', '--m-deep': '#090b19', '--m-accent': '#fdba74',
      '--m-grad': 'linear-gradient(135deg,#f97316,#f43f5e)', '--m-board': 'linear-gradient(160deg,#fdba74 0%,#fb923c 40%,#f43f5e 80%,#e11d48 100%)',
      '--m-card': 'linear-gradient(160deg,#1a1030,#5b1f4a 55%,#c2410c)', '--m-step': 'linear-gradient(135deg,#ea580c,#f43f5e)',
      '--m-glow': 'none', '--m-cardglow': 'rgba(251,146,60,.45)', '--m-foot': '#04050c', '--m-shadow': 'rgba(249,115,22,.5)',
    },
  },
};
export const pal = (t: string) => P[t] || P.purple;

/** Dark-on-gradient colours for the shared parts (order cards, badge, ticker) inside a dark hero. */
export const DARK = { '--bg': '6 4 14', '--fg': '255 255 255', '--fg2': '236 232 248', '--fg3': '204 198 226', '--ov': '255 255 255', '--edge': 'rgba(255,255,255,.18)' } as CSSProperties;


/** Themes whose landing top is dark (white text on the hero gradient). */
export const darkTop = (t: string) => t === 'purple' || t === 'gold';

/** CSS for the small pages (order, account, info pages): landing colours + hero gradient. */
export function pageThemeCss(t: string) {
  const v = Object.entries(pal(t).page).map(([k, x]) => `${k}:${x};`).join('');
  return `:root{${v}--top-fg:${darkTop(t) ? '255 255 255' : 'var(--fg)'}}`;
}

/** Order / account / pay pages: themes with a dark landing top become dark pages (hero colours for the cards). */
export function shopThemeCss(t: string) {
  let css = pageThemeCss(t);
  if (t === 'purple') {
    const v = { ...(DARK as Record<string, string>), ...(pal(t).hero || {}) };
    css += `:root{${Object.entries(v).map(([k, x]) => `${k}:${x};`).join('')}color-scheme:dark}html,body{background:rgb(var(--bg))}`;
  }
  return css;
}
