'use client';

/* Design 3 — "Console": light, product-led. Split hero with service rows on the left and a live
   ads-dashboard window on the right, a scroll-filled stepper, a feature grid and a comparison table. */

import { useEffect, useRef, useState } from 'react';
import { motion, useInView, useReducedMotion, useScroll, useSpring, AnimatePresence } from 'framer-motion';
import { Check, Minus, ArrowRight, Plus, ClipboardList, Send, CreditCard, Rocket, Clock, MessageCircle, Wallet, Building2, Radar, ShieldCheck, BarChart3, Users, Settings2, Bell, LayoutGrid } from 'lucide-react';
import clsx from 'clsx';
import { TgIcon, TgPill } from '../Telegram';
import { OrderChoice } from '../OrderChoice';
import { LeadButton } from '../LeadModal';
import { RecentTicker } from '../RecentTicker';
import { Reveal, Logo } from '../Sections';
import type { LandingContent, Offer } from '@/server/content';

const ease = [0.16, 1, 0.3, 1] as const;

export function BlueLanding({ c }: { c: LandingContent }) {
  return (
    <>
      <BNav c={c} />
      <main className="pt-[var(--bar-h)]">
        <BHero c={c} />
        <Stepper c={c} />
        <Features c={c} />
        <Compare c={c} />
        <BFaq c={c} />
      </main>
      <BCta c={c} />
    </>
  );
}

function BNav({ c }: { c: LandingContent }) {
  return (
    <header className="fixed inset-x-0 top-[var(--bar-h)] z-50 border-b border-edge bg-white/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-[1240px] items-center gap-8 px-5 sm:px-8">
        <a href="#" className="flex items-center gap-2.5 text-[18px] font-semibold tracking-[-0.02em]"><Logo brand={c.brand} src={c.logo} />{c.brand}</a>
        <nav className="hidden gap-7 text-[14.5px] text-fg-2 md:flex">
          <a href="#steps" className="hover:text-violet">How it works</a><a href="#compare" className="hover:text-violet">Pricing</a><a href="#faq" className="hover:text-violet">FAQ</a>
        </nav>
        <div className="ml-auto flex items-center gap-2">
          <LeadButton service="funnel" className="hidden rounded-lg px-4 py-2 text-[14px] font-medium text-fg-2 hover:bg-violet/5 hover:text-violet sm:block">Funnel setup</LeadButton>
          <LeadButton className="inline-flex items-center gap-2 rounded-lg bg-violet px-4 py-2.5 text-[14px] font-semibold text-white shadow-[0_6px_16px_-6px_rgb(var(--p)/.7)] hover:bg-violet-deep"><TgIcon size={17} className="[&>circle]:fill-white/25" />Get an account</LeadButton>
        </div>
      </div>
    </header>
  );
}

function BHero({ c }: { c: LandingContent }) {
  const reduce = useReducedMotion();
  const anim = (d: number) => (reduce ? {} : { initial: { opacity: 0, y: 16 }, animate: { opacity: 1, y: 0 }, transition: { duration: 0.7, delay: d, ease } });
  return (
    <section className="relative isolate overflow-hidden pb-16 pt-24 sm:pb-24 sm:pt-32">
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_80%_60%_at_80%_0%,rgb(var(--ps)/.18),transparent),radial-gradient(ellipse_50%_40%_at_0%_30%,rgb(var(--a)/.12),transparent)]" />
      <div className="absolute inset-0 -z-10 bg-[linear-gradient(to_right,rgb(var(--p)/.05)_1px,transparent_1px),linear-gradient(to_bottom,rgb(var(--p)/.05)_1px,transparent_1px)] bg-[size:44px_44px] [mask-image:linear-gradient(to_bottom,#000,transparent_75%)]" />
      <div className="mx-auto grid max-w-[1240px] items-center gap-12 px-5 sm:px-8 lg:grid-cols-[1fr_1.1fr]">
        <div className="relative min-w-0">
          {c.recentOn && <RecentTicker align="left" inline />}
          <motion.p {...anim(0)} className="inline-flex items-center gap-2 rounded-full border border-edge bg-white px-3 py-1 text-[13px] font-medium text-fg-2 shadow-sm">
            <span className="h-2 w-2 rounded-full bg-mint" />{c.badge}
          </motion.p>
          <motion.h1 {...anim(0.05)} className="mt-5 text-[36px] font-semibold leading-[1.05] tracking-[-0.035em] text-fg sm:text-[56px]">
            {c.headline} <span className="bg-gradient-to-r from-violet to-orchid bg-clip-text text-transparent">{c.accent}</span>
          </motion.h1>
          {c.webOn && <OrderChoice c={c} tone="blue" className="mt-6" />}
          <motion.p {...anim(0.12)} className="mt-5 max-w-[50ch] text-[17px] leading-relaxed text-fg-2">{c.sub}</motion.p>
          {!c.webOn && <TgPill c={c} className="mt-4" />}
          <div className="mt-7 grid min-w-0 gap-3">
            <ServiceRow o={c.account} service="account" icon={<ShieldCheck size={22} />} d={0.2} primary />
            <ServiceRow o={c.funnel} service="funnel" icon={<LayoutGrid size={22} />} d={0.28} />
          </div>
          <motion.div {...anim(0.35)} className="mt-6 flex flex-wrap gap-2 text-[13px] text-fg-2">
            {c.payment.split(/,| or /).map(x => x.trim()).filter(Boolean).map(p => <span key={p} className="rounded-md border border-edge bg-white px-2.5 py-1">{p}</span>)}
            <span className="rounded-md border border-edge bg-white px-2.5 py-1">Delivered within {c.delivery}</span>
          </motion.div>
        </div>
        <motion.div initial={reduce ? false : { opacity: 0, y: 30, rotateX: 8 }} animate={{ opacity: 1, y: 0, rotateX: 0 }} transition={{ duration: 1, delay: 0.25, ease }} style={{ transformPerspective: 1200 }} className="min-w-0">
          <Dashboard c={c} />
        </motion.div>
      </div>
    </section>
  );
}

function ServiceRow({ o, service, icon, d, primary }: { o: Offer; service: 'account' | 'funnel'; icon: React.ReactNode; d: number; primary?: boolean }) {
  const reduce = useReducedMotion();
  return (
    <motion.div className="min-w-0" initial={reduce ? false : { opacity: 0, x: -16 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6, delay: d, ease }}>
      <LeadButton service={service} className={clsx('group flex w-full items-center gap-4 rounded-2xl border p-4 text-left transition-all hover:-translate-y-0.5',
        primary ? 'border-violet/30 bg-white shadow-[0_12px_32px_-14px_rgb(var(--p)/.45)] hover:border-violet' : 'border-edge bg-white/70 hover:border-violet/40 hover:bg-white')}>
        <span className={clsx('grid h-12 w-12 shrink-0 place-items-center rounded-xl', primary ? 'bg-violet text-white' : 'bg-violet/10 text-violet')}>{icon}</span>
        <span className="min-w-0 flex-1">
          <span className="flex flex-wrap items-center gap-2"><span className="text-[16px] font-semibold text-fg">{o.title}</span>{o.badge && <span className="rounded-full bg-violet/10 px-2 py-0.5 text-[11.5px] font-semibold text-violet">{o.badge}</span>}</span>
          <span className="block truncate text-[13.5px] text-fg-3">{o.sub}</span>
        </span>
        <span className="text-right">
          <span className="block text-[24px] font-semibold tracking-[-0.03em] text-fg">${o.price}</span>
          <span className="block text-[12px] text-fg-3">{o.unit}</span>
        </span>
        <ArrowRight size={18} className="hidden shrink-0 text-violet transition-transform group-hover:translate-x-1 sm:block" />
      </LeadButton>
    </motion.div>
  );
}

function Dashboard({ c }: { c: LandingContent }) {
  const reduce = useReducedMotion();
  const [live, setLive] = useState(!!reduce);
  const [spend, setSpend] = useState(reduce ? 1284 : 0);
  useEffect(() => {
    if (reduce) return;
    const t = setTimeout(() => setLive(true), 2200);
    let v = 0; const id = setInterval(() => { v = Math.min(1284, v + 37); setSpend(v); if (v >= 1284) clearInterval(id); }, 40);
    return () => { clearTimeout(t); clearInterval(id); };
  }, [reduce]);
  const pts = [8, 22, 18, 34, 30, 46, 41, 58, 55, 70, 66, 84];
  const path = pts.map((y, i) => `${i === 0 ? 'M' : 'L'} ${i * (300 / (pts.length - 1))} ${100 - y}`).join(' ');
  return (
    <div className="relative pb-6">
      <div className="overflow-hidden rounded-2xl border border-edge bg-white shadow-[0_40px_80px_-30px_rgba(8,40,110,.35),0_0_0_1px_rgba(8,40,110,.04)]">
        <div className="flex items-center gap-2 border-b border-edge bg-plum-2/60 px-4 py-3">
          <Logo brand={c.brand} src={c.logo} />
          <span className="flex-1 truncate text-[13px] font-semibold text-fg">Ad accounts</span>
          <span className="inline-flex items-center gap-1.5 text-[12px] text-fg-3"><span className="h-1.5 w-1.5 rounded-full bg-mint" />Today</span>
        </div>
        <div className="flex">
          <div className="hidden w-14 flex-col items-center gap-4 border-r border-edge py-4 text-fg-3 sm:flex">
            <BarChart3 size={18} className="text-violet" /><Users size={18} /><Bell size={18} /><Settings2 size={18} />
          </div>
          <div className="min-w-0 flex-1 p-4 sm:p-5">
            <div className="grid grid-cols-3 gap-2 sm:gap-3">
              {[['Spend today', `$${spend.toLocaleString()}`], ['Results', Math.round(spend / 9.4).toString()], ['Cost / result', '$9.40']].map(([k, v]) => (
                <div key={k} className="rounded-xl border border-edge p-2.5 sm:p-3"><p className="text-[11px] text-fg-3 sm:text-[12px]">{k}</p><p className="mt-0.5 text-[16px] font-semibold tabular-nums tracking-tight sm:text-[20px]">{v}</p></div>
              ))}
            </div>
            <div className="mt-3 rounded-xl border border-edge p-3">
              <div className="mb-2 flex items-center justify-between text-[12px] text-fg-3"><span>Last 12 days</span><span className="font-medium text-mint">▲ 38%</span></div>
              <svg viewBox="0 0 300 100" className="h-[90px] w-full" preserveAspectRatio="none">
                <defs><linearGradient id="bfill" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="rgb(var(--p))" stopOpacity=".25" /><stop offset="1" stopColor="rgb(var(--p))" stopOpacity="0" /></linearGradient></defs>
                <motion.path d={`${path} L 300 100 L 0 100 Z`} fill="url(#bfill)" initial={reduce ? false : { opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.4, duration: 0.8 }} />
                <motion.path d={path} fill="none" stroke="rgb(var(--p))" strokeWidth="2.5" strokeLinejoin="round" strokeLinecap="round"
                  initial={reduce ? false : { pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 1.8, delay: 0.4, ease }} />
              </svg>
            </div>
            <div className="mt-3 overflow-hidden rounded-xl border border-edge">
              {[{ n: 'Your new account', id: 'act_221890477742', s: live, v: `$${(spend * 0.18).toFixed(2)}` }, { n: 'Main store', id: 'act_221890471163', s: true, v: '$842.10' }].map((r, i) => (
                <div key={r.id} className={clsx('flex items-center gap-3 px-3 py-2.5 text-[13px]', i && 'border-t border-edge', i === 0 && live && 'bg-mint/[0.06]')}>
                  <span className="min-w-0 flex-1"><span className="block truncate font-medium">{r.n}</span><span className="font-mono text-[11px] text-fg-3">{r.id}</span></span>
                  <span className={clsx('inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[11.5px] font-medium transition-colors duration-500', r.s ? 'bg-mint/10 text-mint' : 'bg-amber-100 text-amber-700')}>
                    <span className={clsx('h-1.5 w-1.5 rounded-full', r.s ? 'bg-mint' : 'animate-pulse bg-amber-500')} />{r.s ? 'Active' : 'In review'}
                  </span>
                  <span className="w-[68px] text-right font-mono tabular-nums text-fg-2">{r.v}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      <AnimatePresence>
        {live && (
          <motion.div initial={reduce ? false : { opacity: 0, y: 16, scale: 0.96 }} animate={{ opacity: 1, y: 0, scale: 1 }} transition={{ type: 'spring', damping: 20, stiffness: 240, delay: 0.2 }}
            className="absolute -bottom-12 left-2 flex items-center gap-3 rounded-xl border border-edge bg-white px-4 py-3 shadow-[0_20px_40px_-16px_rgba(8,40,110,.35)] sm:-left-8">
            <span className="grid h-9 w-9 place-items-center rounded-full bg-mint/15 text-mint"><Check size={18} strokeWidth={3} /></span>
            <span><span className="block text-[13.5px] font-semibold text-fg">Account shared to your BM</span><span className="block text-[12px] text-fg-3">Delivered in under {c.delivery}</span></span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function Stepper({ c }: { c: LandingContent }) {
  const steps = [
    { icon: ClipboardList, t: 'Answer three questions', d: 'Business Manager, niche and daily budget.' },
    { icon: Send, t: 'Message us on Telegram', d: 'Your message is pre-typed. Just press Send.' },
    { icon: CreditCard, t: 'Pay and share your BM ID', d: `${c.payment}.` },
    { icon: Rocket, t: 'Start spending', d: `Account live within ${c.delivery}.` },
  ];
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start 85%', 'end 60%'] });
  const w = useSpring(scrollYProgress, { stiffness: 120, damping: 25 });
  return (
    <section id="steps" className="scroll-mt-20 border-y border-edge bg-white py-16 sm:py-24">
      <div className="mx-auto max-w-[1240px] px-5 sm:px-8">
        <Reveal className="mx-auto max-w-[640px] text-center">
          <p className="text-[14px] font-semibold text-violet">How it works</p>
          <h2 className="mt-2 text-[32px] font-semibold tracking-[-0.03em] sm:text-[44px]">Four steps. About {c.delivery}.</h2>
        </Reveal>
        <div ref={ref} className="relative mt-14">
          <div className="absolute left-[12.5%] right-[12.5%] top-7 hidden h-[2px] bg-edge md:block" />
          <motion.div className="absolute left-[12.5%] top-7 hidden h-[2px] origin-left bg-gradient-to-r from-violet to-orchid md:block" style={{ scaleX: w, right: '12.5%' }} />
          <div className="grid gap-8 md:grid-cols-4">
            {steps.map(({ icon: I, t, d }, i) => (
              <Reveal key={t} delay={i * 0.08} className="relative flex gap-4 md:flex-col md:items-center md:text-center">
                <span className="relative z-10 grid h-14 w-14 shrink-0 place-items-center rounded-2xl border border-edge bg-white text-violet shadow-[0_8px_20px_-10px_rgb(var(--p)/.5)]"><I size={24} /></span>
                <span><span className="text-[13px] font-semibold text-violet">Step {i + 1}</span><span className="mt-1 block text-[17px] font-semibold">{t}</span><span className="mt-1 block text-[14.5px] text-fg-2">{d}</span></span>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function Features({ c }: { c: LandingContent }) {
  const f = [
    { icon: Clock, t: `Delivered within ${c.delivery}`, d: 'Counted from confirmed payment, shared straight to your Business Manager.' },
    { icon: MessageCircle, t: 'A dedicated agent', d: 'One person on Telegram from your first question to every top-up.' },
    { icon: Wallet, t: 'Top-ups without new orders', d: 'Add funds through the same chat whenever your campaigns need it.' },
    { icon: Building2, t: 'Business Manager help', d: 'No BM yet? We guide you through creating one for free.' },
    { icon: Radar, t: 'Server-side tracking', d: 'With the funnel plan, leads and sales are sent to Meta from our server.' },
    { icon: ShieldCheck, t: 'Simple pricing', d: `$${c.priceAccount} per account. Top-ups go through us${Number(c.topupFee) ? ` for a ${c.topupFee}% fee` : ''}, so you save the 18% GST.` },
  ];
  return (
    <section className="py-16 sm:py-24">
      <div className="mx-auto max-w-[1240px] px-5 sm:px-8">
        <Reveal className="max-w-[640px]"><h2 className="text-[32px] font-semibold tracking-[-0.03em] sm:text-[44px]">{c.whyTitle}</h2></Reveal>
        <div className="mt-12 grid gap-px overflow-hidden rounded-2xl border border-edge bg-edge sm:grid-cols-2 lg:grid-cols-3">
          {f.map(({ icon: I, t, d }, i) => (
            <Reveal key={t} delay={i * 0.04} className="bg-white p-6 sm:p-7">
              <h3 className="flex items-center gap-2.5 text-[17px] font-semibold"><I size={19} className="shrink-0 text-violet" />{t}</h3>
              <p className="mt-2 text-[15px] leading-relaxed text-fg-2">{d}</p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function Compare({ c }: { c: LandingContent }) {
  const rows: [string, boolean, boolean][] = [
    ['Agency ad account shared to your BM', true, false], [`Delivery within ${c.delivery}`, true, true], ['Dedicated agent on Telegram', true, true],
    ['Top-ups through your agent', true, false], ['Landing page with lead form', false, true], ['Leads routed to your agents', false, true],
    ['Admin app and agent app', false, true], ['Server-side Meta Conversions API', false, true],
  ];
  return (
    <section id="compare" className="scroll-mt-20 pb-20 sm:pb-28">
      <div className="mx-auto max-w-[960px] px-5 sm:px-8">
        <Reveal className="text-center"><h2 className="text-[32px] font-semibold tracking-[-0.03em] sm:text-[44px]">What&apos;s included</h2></Reveal>
        <Reveal delay={0.1} className="mt-10 overflow-hidden rounded-2xl border border-edge bg-white shadow-[0_30px_60px_-30px_rgba(8,40,110,.25)]">
          <div className="grid grid-cols-[1fr_92px_92px] sm:grid-cols-[1fr_180px_180px]">
            <div className="border-b border-edge p-4 sm:p-6" />
            {[c.account, c.funnel].map((o, i) => (
              <div key={o.title} className={clsx('border-b border-l border-edge p-3 text-center sm:p-6', i === 0 && 'bg-violet/[0.04]')}>
                <p className="text-[12.5px] font-semibold leading-tight sm:text-[15px]">{o.title}</p>
                <p className="mt-1 text-[22px] font-semibold tracking-tight sm:text-[32px]">${o.price}</p>
                <p className="text-[11.5px] text-fg-3 sm:text-[13px]">{o.unit}</p>
              </div>
            ))}
            {rows.map(([t, a, f]) => (
              <div key={t} className="contents">
                <div className="border-b border-edge px-4 py-3.5 text-[14px] text-fg-2 sm:px-6 sm:text-[15px]">{t}</div>
                {[a, f].map((v, i) => (
                  <div key={i} className={clsx('grid place-items-center border-b border-l border-edge', i === 0 && 'bg-violet/[0.04]')}>
                    {v ? <span className="grid h-6 w-6 place-items-center rounded-full bg-violet text-white"><Check size={14} strokeWidth={3} /></span> : <Minus size={16} className="text-fg-3/60" />}
                  </div>
                ))}
              </div>
            ))}
            <div className="p-4 sm:p-6" />
            <div className="border-l border-edge bg-violet/[0.04] p-2 sm:p-5"><LeadButton className="w-full rounded-lg bg-violet px-2 py-2.5 text-[13px] font-semibold text-white hover:bg-violet-deep sm:text-[14px]">Choose</LeadButton></div>
            <div className="border-l border-edge p-2 sm:p-5"><LeadButton service="funnel" className="w-full rounded-lg border border-violet/40 px-2 py-2.5 text-[13px] font-semibold text-violet hover:bg-violet/5 sm:text-[14px]">Choose</LeadButton></div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function BFaq({ c }: { c: LandingContent }) {
  if (!c.faq.length) return null;
  return (
    <section id="faq" className="scroll-mt-20 border-t border-edge bg-white py-16 sm:py-24">
      <div className="mx-auto max-w-[760px] px-5 sm:px-8">
        <Reveal className="text-center"><h2 className="text-[32px] font-semibold tracking-[-0.03em] sm:text-[44px]">Frequently asked questions</h2></Reveal>
        <div className="mt-10 divide-y divide-edge rounded-2xl border border-edge">
          {c.faq.map(([q, a], i) => (
            <details key={q + i} className="group px-5 sm:px-6">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-4 py-5 text-[16px] font-medium [&::-webkit-details-marker]:hidden">
                {q}<span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-violet/10 text-violet transition-transform group-open:rotate-45"><Plus size={16} /></span>
              </summary>
              <p className="pb-5 text-[15px] leading-relaxed text-fg-2">{a}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}

function BCta({ c }: { c: LandingContent }) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true });
  return (
    <section className="px-3 pb-3 pt-16 sm:px-5 sm:pb-5">
      <div ref={ref} className="relative overflow-hidden rounded-3xl bg-[linear-gradient(135deg,rgb(var(--p)),rgb(var(--band2)))] px-6 py-16 text-center text-white sm:py-24">
        <motion.div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_20%,rgba(255,255,255,.25),transparent_40%)]" animate={inView ? { opacity: [0.4, 1, 0.4] } : {}} transition={{ duration: 6, repeat: Infinity }} />
        <h2 className="relative mx-auto max-w-[18ch] text-[34px] font-semibold leading-[1.08] tracking-[-0.03em] sm:text-[52px]">{c.ctaTitle}</h2>
        <p className="relative mx-auto mt-4 max-w-[46ch] text-[17px] text-white/80">{c.ctaText}</p>
        <div className="relative mt-8 flex flex-col justify-center gap-3 sm:flex-row">
          <LeadButton className="rounded-xl bg-white px-7 py-3.5 text-[16px] font-semibold text-violet-deep hover:bg-white/90">{c.account.cta} for ${c.priceAccount}</LeadButton>
          <LeadButton service="funnel" className="rounded-xl border border-white/40 px-7 py-3.5 text-[16px] font-semibold text-white hover:bg-white/10">{c.funnel.cta} for ${c.priceFunnel}/mo</LeadButton>
        </div>
      </div>
      <footer className="mx-auto flex max-w-[1240px] flex-col gap-3 px-5 py-8 text-[13.5px] text-fg-3 sm:flex-row sm:items-center sm:justify-between sm:px-8">
        <p className="flex items-center gap-2.5 text-[16px] font-semibold text-fg"><Logo brand={c.brand} src={c.logo} />{c.brand}</p>
        <p className="flex flex-wrap gap-x-4">{c.webOn && <a href="/account" className="font-medium text-fg-2 hover:text-fg">My account · Top up</a>}{c.channel && <a href={c.channel} target="_blank" rel="noopener" className="hover:text-fg">Telegram channel</a>}<span>© {new Date().getFullYear()} {c.brand}. {c.footer}</span></p>
      </footer>
    </section>
  );
}
