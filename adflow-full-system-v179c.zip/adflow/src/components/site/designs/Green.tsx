'use client';

/* Design 2 — "Studio": Spotify-inspired. Left-aligned giant type, album-cover service tiles,
   a tracklist for the process (with an auto-playing row), and a sideways-scrolling shelf. */

import { useEffect, useRef, useState } from 'react';
import { motion, useReducedMotion } from 'framer-motion';
import { ArrowRight, Check, ChevronLeft, ChevronRight, Plus, Clock, MessageCircle, Wallet, Building2, Radar, LayoutTemplate, Send, ShieldCheck } from 'lucide-react';
import clsx from 'clsx';
import { TgIcon, TgPill } from '../Telegram';
import { OrderChoice } from '../OrderChoice';
import { LeadButton } from '../LeadModal';
import { RecentTicker } from '../RecentTicker';
import { Reveal, Logo } from '../Sections';
import type { LandingContent, Offer } from '@/server/content';

const ease = [0.16, 1, 0.3, 1] as const;

function Bars({ playing = true, className }: { playing?: boolean; className?: string }) {
  const reduce = useReducedMotion();
  return (
    <span className={clsx('inline-flex h-3.5 items-end gap-[2px]', className)} aria-hidden>
      {[0, 1, 2, 3].map(i => (
        <motion.span key={i} className="w-[3px] rounded-full bg-violet"
          animate={playing && !reduce ? { height: ['30%', '100%', '45%', '80%', '30%'] } : { height: '50%' }}
          transition={{ duration: 1 + i * 0.15, repeat: Infinity, ease: 'easeInOut', delay: i * 0.12 }} />
      ))}
    </span>
  );
}

export function GreenLanding({ c }: { c: LandingContent }) {
  return (
    <>
      <GNav c={c} />
      <main className="pt-[var(--bar-h)]">
        <GHero c={c} />
        <Tracklist c={c} />
        <Shelf c={c} />
        <GFaq c={c} />
      </main>
      <GCta c={c} />
    </>
  );
}

function GNav({ c }: { c: LandingContent }) {
  return (
    <header className="fixed inset-x-0 top-[var(--bar-h)] z-50 border-b border-ov/[0.06] bg-void/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-[1320px] items-center gap-6 px-5 sm:px-8">
        <a href="#" className="flex items-center gap-2.5 font-display text-[20px] font-bold tracking-[-0.03em]"><Logo brand={c.brand} src={c.logo} />{c.brand}</a>
        <nav className="ml-6 hidden gap-1 text-[14px] font-semibold text-fg-3 md:flex">
          <a href="#tracks" className="rounded-full px-3 py-1.5 hover:bg-ov/[0.07] hover:text-fg">How it works</a>
          <a href="#shelf" className="rounded-full px-3 py-1.5 hover:bg-ov/[0.07] hover:text-fg">What you get</a>
          <a href="#faq" className="rounded-full px-3 py-1.5 hover:bg-ov/[0.07] hover:text-fg">Questions</a>
        </nav>
        <LeadButton className="ml-auto inline-flex items-center gap-2 rounded-full bg-violet px-4 py-2.5 text-[14px] font-bold text-onp transition-transform hover:scale-[1.04] sm:px-5"><TgIcon size={17} className="[&>circle]:fill-black/25" /><span className="whitespace-nowrap">Order on Telegram</span></LeadButton>
      </div>
    </header>
  );
}

function GHero({ c }: { c: LandingContent }) {
  const reduce = useReducedMotion();
  const lines = [c.headline, c.accent];
  return (
    <section className="relative isolate overflow-hidden pb-16 pt-[88px] sm:pb-24 sm:pt-28">
      <div className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-[620px] bg-[linear-gradient(180deg,rgb(var(--pd)/.55),transparent)]" />
      <div className="pointer-events-none absolute -left-40 top-20 -z-10 h-[480px] w-[480px] rounded-full bg-[radial-gradient(closest-side,rgb(var(--p)/.25),transparent)]" />
      <div className="mx-auto grid max-w-[1320px] items-end gap-8 px-5 sm:px-8 lg:grid-cols-[1.15fr_1fr] lg:gap-14">
        <div className="relative min-w-0">
          {c.recentOn && <RecentTicker align="left" inline />}
          <motion.p initial={reduce ? false : { opacity: 0 }} animate={{ opacity: 1 }} className="inline-flex items-center gap-2.5 rounded-full bg-black/30 px-3.5 py-1.5 text-[13px] font-semibold text-fg-2">
            <Bars /> {c.badge}
          </motion.p>
          <h1 className="mt-5 font-display text-[38px] font-extrabold leading-[0.95] tracking-[-0.05em] sm:text-[64px] lg:text-[72px]">
            {lines.map((l, i) => (
              <motion.span key={i} className={clsx('block', i === 1 && 'text-violet')}
                initial={reduce ? false : { opacity: 0, x: -40 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.9, delay: 0.1 + i * 0.15, ease }}>{l}</motion.span>
            ))}
          </h1>
          {c.webOn && <OrderChoice c={c} tone="green" className="mt-6" />}
          <motion.p initial={reduce ? false : { opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }} className="mt-5 max-w-[52ch] text-[15.5px] leading-relaxed text-fg-2 sm:text-[18px]">{c.sub}</motion.p>
          {!c.webOn && <TgPill c={c} className="mt-5" />}
          <p className="mt-4 text-[14px] font-medium text-fg-3">Pay with {c.payment} · Live within {c.delivery}</p>
        </div>
        <div className="grid min-w-0 gap-4 sm:grid-cols-2">
          <Tile o={c.account} service="account" i={0} />
          <Tile o={c.funnel} service="funnel" i={1} />
        </div>
      </div>
    </section>
  );
}

function Tile({ o, service, i }: { o: Offer; service: 'account' | 'funnel'; i: number }) {
  const reduce = useReducedMotion();
  const primary = service === 'account';
  return (
    <motion.article initial={reduce ? false : { opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.35 + i * 0.12, ease }}
      className="group relative flex flex-col rounded-[14px] bg-plum p-3 transition-colors hover:bg-plum-2">
      {/* cover art */}
      <div className={clsx('relative aspect-[2/1] overflow-hidden rounded-[10px] sm:aspect-square shadow-[0_18px_40px_-12px_rgba(0,0,0,.7)]',
        primary ? 'bg-[linear-gradient(135deg,rgb(var(--p)),rgb(var(--pd))_55%,#0b3d1f)]' : 'bg-[linear-gradient(135deg,#1f2937,#0f1a14_45%,rgb(var(--a)/.55))]')}>
        {primary ? (
          <motion.div className="absolute -bottom-[30%] -right-[30%] aspect-square w-[95%] rounded-full bg-[repeating-radial-gradient(circle,rgba(0,0,0,.55)_0_2px,rgba(0,0,0,.25)_3px_6px)] ring-[14px] ring-black/30"
            animate={reduce ? undefined : { rotate: 360 }} transition={{ duration: 14, repeat: Infinity, ease: 'linear' }}>
            <div className="absolute inset-[38%] rounded-full bg-violet ring-4 ring-black/40" />
          </motion.div>
        ) : (
          <svg viewBox="0 0 200 200" className="absolute inset-0 h-full w-full" aria-hidden>
            {[0, 1, 2, 3, 4].map(k => (
              <motion.path key={k} d={`M -10 ${120 + k * 14} C 50 ${70 + k * 14}, 120 ${170 + k * 10}, 210 ${100 + k * 14}`} fill="none" stroke="rgb(var(--a))" strokeOpacity={0.25 + k * 0.12} strokeWidth="2.5"
                initial={reduce ? false : { pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 1.6, delay: 0.6 + k * 0.12, ease }} />
            ))}
          </svg>
        )}
        <div className="absolute left-4 top-4">
          {o.badge && <span className={clsx('rounded-full px-2.5 py-1 text-[11.5px] font-bold', primary ? 'bg-black/35 text-white' : 'bg-white/10 text-white')}>{o.badge}</span>}
        </div>
        <div className="absolute bottom-4 left-4 text-white">
          <p className="font-display text-[40px] font-extrabold leading-none tracking-[-0.05em] sm:text-[44px] lg:text-[52px]">${o.price}</p>
          <p className="mt-1 text-[13px] font-semibold text-white/75">{o.unit}</p>
        </div>
        <LeadButton service={service} className="absolute bottom-4 right-4 hidden h-14 w-14 translate-y-2 sm:grid place-items-center rounded-full bg-violet text-onp opacity-100 shadow-[0_8px_20px_rgba(0,0,0,.45)] transition-all duration-300 hover:scale-105 sm:opacity-0 sm:group-hover:translate-y-0 sm:group-hover:opacity-100">
          <ArrowRight size={24} /><span className="sr-only">{o.cta}</span>
        </LeadButton>
      </div>
      <h2 className="mt-4 px-1 text-[17px] font-bold tracking-[-0.01em]">{o.title}</h2>
      <p className="mt-1 px-1 text-[14px] text-fg-3">{o.sub}</p>
      <ul className="mt-3 grid gap-1.5 px-1 text-[13.5px] text-fg-2">
        {o.bullets.map(b => <li key={b} className="flex gap-2"><Check size={15} className="mt-0.5 shrink-0 text-violet" strokeWidth={3} />{b}</li>)}
      </ul>
      <LeadButton service={service} className={clsx('mt-4 rounded-full px-5 py-3 text-[14.5px] font-bold transition-transform hover:scale-[1.02]', primary ? 'bg-violet text-onp' : 'border border-ov/25 text-fg hover:border-fg')}><span className="inline-flex items-center gap-2"><TgIcon size={17} className={primary ? '[&>circle]:fill-black/25' : ''} />{o.cta}</span></LeadButton>
    </motion.article>
  );
}

function Tracklist({ c }: { c: LandingContent }) {
  const tracks = [
    ['Answer three questions', 'Business Manager, what you advertise, daily budget', '0:45'],
    ['Send one message on Telegram', 'Your message is already typed. Press Send.', '0:05'],
    ['Pay your way', `${c.payment}. Then share your Business Manager ID.`, '2:00'],
    ['Account goes live', 'Shared to your Business Manager, ready to spend', c.deliveryShort],
    ['Top up anytime', 'Same chat, same agent, no new order', '∞'],
  ];
  const [now, setNow] = useState(0);
  const reduce = useReducedMotion();
  useEffect(() => { if (reduce) return; const id = setInterval(() => setNow(n => (n + 1) % tracks.length), 2200); return () => clearInterval(id); }, [reduce, tracks.length]);
  return (
    <section id="tracks" className="scroll-mt-20 py-16 sm:py-24">
      <div className="mx-auto max-w-[1320px] px-5 sm:px-8">
        <Reveal className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="text-[14px] font-semibold text-fg-3">Step by step</p>
            <h2 className="mt-1 font-display text-[36px] font-extrabold tracking-[-0.04em] sm:text-[56px]">How it works</h2>
            <p className="mt-2 text-[15px] text-fg-3">{c.brand} · 5 steps · about {c.delivery} in total</p>
          </div>
          <LeadButton className="inline-flex items-center gap-2 rounded-full bg-violet px-6 py-3.5 text-[15px] font-bold text-onp transition-transform hover:scale-[1.03]"><TgIcon size={18} className="[&>circle]:fill-black/25" />Start now<ArrowRight size={17} /></LeadButton>
        </Reveal>
        <Reveal delay={0.1} className="mt-8">
          <div className="hidden grid-cols-[48px_1fr_80px] gap-4 border-b border-ov/10 px-4 pb-2 text-[13px] text-fg-3 sm:grid">
            <span>#</span><span>Step</span><span className="flex justify-end"><Clock size={15} /></span>
          </div>
          <ol className="mt-2">
            {tracks.map(([t, d, time], i) => {
              const on = now === i;
              return (
                <li key={t} onMouseEnter={() => setNow(i)} className={clsx('group grid grid-cols-[40px_1fr_auto] items-center gap-4 rounded-md px-4 py-3 transition-colors sm:grid-cols-[48px_1fr_80px]', on ? 'bg-ov/[0.08]' : 'hover:bg-ov/[0.05]')}>
                  <span className="text-[16px] tabular-nums text-fg-3">{on ? <Bars /> : i + 1}</span>
                  <span className="min-w-0">
                    <span className={clsx('block truncate text-[16px] font-semibold', on && 'text-violet')}>{t}</span>
                    <span className="block truncate text-[14px] text-fg-3">{d}</span>
                  </span>
                  <span className="text-right text-[14px] tabular-nums text-fg-3">{time}</span>
                </li>
              );
            })}
          </ol>
        </Reveal>
      </div>
    </section>
  );
}

function Shelf({ c }: { c: LandingContent }) {
  const ref = useRef<HTMLDivElement>(null);
  const items = [
    { icon: Clock, t: `Live within ${c.delivery}`, d: 'Counted from confirmed payment.' },
    { icon: MessageCircle, t: 'One agent, one chat', d: 'The person who sells it supports it.' },
    { icon: Wallet, t: 'Top-ups on Telegram', d: 'Add funds without a new order.' },
    { icon: Building2, t: 'No BM? No problem', d: 'We help you create one for free.' },
    { icon: LayoutTemplate, t: 'Landing pages that convert', d: 'Built for your offer in the funnel plan.' },
    { icon: Send, t: 'Leads routed to your team', d: 'Round-robin to your agents.' },
    { icon: Radar, t: 'Server-side tracking', d: 'Lead and Purchase sent to Meta.' },
    { icon: ShieldCheck, t: `$${c.priceAccount} per account`, d: `Top-ups through us${Number(c.topupFee) ? ` (${c.topupFee}% fee)` : ''}, no 18% GST.` },
  ];
  const scroll = (d: number) => ref.current?.scrollBy({ left: d * 320, behavior: 'smooth' });
  return (
    <section id="shelf" className="scroll-mt-20 py-16 sm:py-20">
      <div className="mx-auto max-w-[1320px] px-5 sm:px-8">
        <Reveal className="flex items-end justify-between gap-4">
          <h2 className="font-display text-[30px] font-extrabold tracking-[-0.04em] sm:text-[44px]">Made for you</h2>
          <div className="hidden gap-2 sm:flex">
            <button onClick={() => scroll(-1)} aria-label="Scroll left" className="grid h-10 w-10 place-items-center rounded-full bg-black/40 hover:bg-black/60"><ChevronLeft size={20} /></button>
            <button onClick={() => scroll(1)} aria-label="Scroll right" className="grid h-10 w-10 place-items-center rounded-full bg-black/40 hover:bg-black/60"><ChevronRight size={20} /></button>
          </div>
        </Reveal>
      </div>
      <div ref={ref} className="mt-6 flex snap-x snap-mandatory gap-4 overflow-x-auto scroll-px-5 px-5 pb-4 [scrollbar-width:none] sm:scroll-px-8 sm:px-8 lg:px-[max(32px,calc((100vw-1320px)/2+32px))]">
        {items.map(({ icon: I, t, d }, i) => (
          <Reveal key={t} delay={i * 0.04} className="shrink-0 snap-start">
            <div className="group flex h-full w-[220px] flex-col rounded-[12px] bg-plum p-5 transition-colors hover:bg-plum-2 sm:w-[250px]">
              <span className={clsx('grid h-11 w-11 place-items-center rounded-full', i % 3 === 0 ? 'bg-violet text-onp' : 'bg-violet/15 text-violet')}><I size={20} strokeWidth={2} /></span>
              <p className="mt-10 text-[17px] font-bold leading-snug">{t}</p>
              <p className="mt-1.5 text-[14px] text-fg-3">{d}</p>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

function GFaq({ c }: { c: LandingContent }) {
  if (!c.faq.length) return null;
  return (
    <section id="faq" className="scroll-mt-20 py-16 sm:py-24">
      <div className="mx-auto max-w-[1320px] px-5 sm:px-8">
        <Reveal><h2 className="font-display text-[36px] font-extrabold tracking-[-0.04em] sm:text-[56px]">Questions</h2></Reveal>
        <div className="mt-8 grid gap-3 md:grid-cols-2">
          {c.faq.map(([q, a], i) => (
            <Reveal key={q + i} delay={(i % 2) * 0.05}>
              <details className="group rounded-[12px] bg-plum px-5 transition-colors open:bg-plum-2">
                <summary className="flex cursor-pointer list-none items-center justify-between gap-4 py-5 text-[16px] font-bold [&::-webkit-details-marker]:hidden">
                  {q}<Plus size={20} className="shrink-0 text-fg-3 transition-transform group-open:rotate-45 group-open:text-violet" />
                </summary>
                <p className="pb-5 text-[15px] leading-relaxed text-fg-2">{a}</p>
              </details>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function GCta({ c }: { c: LandingContent }) {
  return (
    <section className="px-3 pb-3 pt-8 sm:px-5 sm:pb-5">
      <div className="relative overflow-hidden rounded-[18px] bg-violet px-6 py-16 text-black sm:px-14 sm:py-24">
        <div className="absolute -right-24 -top-24 hidden h-[420px] w-[420px] rounded-full bg-[repeating-radial-gradient(circle,rgba(0,0,0,.18)_0_2px,transparent_3px_9px)] sm:block" />
        <Reveal>
          <h2 className="relative max-w-[14ch] font-display text-[44px] font-extrabold leading-[0.95] tracking-[-0.05em] sm:text-[84px]">{c.ctaTitle}</h2>
        </Reveal>
        <Reveal delay={0.1}><p className="relative mt-5 max-w-[44ch] text-[17px] font-medium text-black/70">{c.ctaText}</p></Reveal>
        <Reveal delay={0.15} className="relative mt-8 flex flex-col gap-3 sm:flex-row">
          <LeadButton className="rounded-full bg-black px-8 py-4 text-[16px] font-bold text-white transition-transform hover:scale-[1.03]">{c.account.cta} for ${c.priceAccount}</LeadButton>
          <LeadButton service="funnel" className="rounded-full border-2 border-black px-8 py-4 text-[16px] font-bold transition-colors hover:bg-black hover:text-white">{c.funnel.cta} for ${c.priceFunnel}/mo</LeadButton>
        </Reveal>
      </div>
      <footer className="mx-auto flex max-w-[1320px] flex-col gap-3 px-5 py-8 text-[13.5px] text-fg-3 sm:flex-row sm:items-center sm:justify-between sm:px-8">
        <p className="flex items-center gap-2.5 font-display text-[16px] font-bold text-fg"><Logo brand={c.brand} src={c.logo} />{c.brand}</p>
        <p className="flex flex-wrap gap-x-4">{c.webOn && <a href="/account" className="font-medium text-fg-2 hover:text-fg">My account · Top up</a>}{c.channel && <a href={c.channel} target="_blank" rel="noopener" className="hover:text-fg">Telegram channel</a>}<span>© {new Date().getFullYear()} {c.brand}. {c.footer}</span></p>
      </footer>
    </section>
  );
}
