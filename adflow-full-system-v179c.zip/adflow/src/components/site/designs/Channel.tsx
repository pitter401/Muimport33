'use client';

/* Telegram channel page (/telegram) in the same four looks as the landing pages:
   purple "stage", blue "card", green "chat", gold "horizon" — picked by the site theme (or /telegram/<theme>).
   Every Join button goes to /j (tracked join-request link → Subscribe event on that line's pixel). */

import { useEffect, useState, type CSSProperties, type ReactNode } from 'react';
import { motion, useReducedMotion } from 'framer-motion';
import { Plus, ArrowRight, Lock, Briefcase, MessageCircle, CreditCard, Filter, Bell, Check, Send, ShoppingBag, Zap, ShieldCheck, Star, BadgeDollarSign, Users } from 'lucide-react';
import clsx from 'clsx';
import { TgIcon } from '../Telegram';
import { WaJoinForm } from '../WaParts';
import { Reveal, ViewerBadge } from '../Sections';
import { RecentTicker } from '../RecentTicker';
import { VC, VARIANT, useV, pal, DARK, usePill, Eyebrow, H2, Wordmark, Partner, useAnim, radius, center, type V } from './Premium';
import type { LandingContent } from '@/server/content';

const ease = [0.16, 1, 0.3, 1] as const;
/** Page text per line (Agency / Premium / Funnel channel ads). Plain data: it comes from the server component. */
export type ChannelCopy = {
  sub: string; topics: string[]; offer: { icon: string; t: string; d: string; tag: string }[];
  posts: [string, string, string][]; tiles: [string, string][]; faq: [string, string][]; band: string; foot: string; lock: string;
};
export type ChannelText = { href: string; name: string;
  /** v131: tg = Telegram channel (default), wa = WhatsApp chat page, wac = WhatsApp community page (number form in the hero) */ kind?: 'tg' | 'wa' | 'wac'; form?: { line: string; cc: string; off?: boolean };
  steps?: { who: string; t: string; d: string }[]; band?: string; copy?: Partial<ChannelCopy>; order?: { href: string; label: string }; wa?: string;
  /** v118: channel-ad pages speak like the landing page (same headline + sub), the button sells and opens the channel */ hero?: { h: string; a: string; sub: string }; cta?: string };
const ICONS: Record<string, typeof Briefcase> = { briefcase: Briefcase, message: MessageCircle, card: CreditCard, filter: Filter, bag: ShoppingBag, zap: Zap, shield: ShieldCheck, star: Star, dollar: BadgeDollarSign, users: Users };

const JOIN = 'Join channel';
const SUB = 'Learn agency work, WhatsApp API 2K setup and how agency ad accounts are made. Joining is free — our services (ad accounts, top-ups, funnel setup) are paid.';
const OFFER: { icon: typeof Briefcase; t: string; d: string; tag: 'Training' | 'Service' }[] = [
  { icon: Briefcase, t: 'Agency work', d: 'Learn agency work from the start: finding clients, setup and how the work gets done.', tag: 'Training' },
  { icon: MessageCircle, t: 'WhatsApp API · 2K', d: 'WhatsApp API setup and the full process to reach the 2K limit.', tag: 'Training' },
  { icon: CreditCard, t: 'How agency accounts are made', d: 'The full inside process of how an agency ad account is created.', tag: 'Training' },
  { icon: Filter, t: 'Accounts & funnel setup', d: 'Need an agency ad account or a funnel built for you? Get it through the channel.', tag: 'Service' },
];
const TOPICS = ['Agency work', 'WhatsApp API 2K', 'Agency accounts', 'Funnel setup', 'Offers & updates'];

const STEPS_TG = [
  { who: 'You', t: 'Tap “Join channel”', d: 'Telegram opens and shows the channel.' },
  { who: 'Telegram', t: 'Tap “Request to Join”', d: 'The channel is private, so you send a join request first.' },
  { who: 'Done', t: 'You are in once approved', d: 'All posts, offers and updates open up for you.' },
];
const FAQ: [string, string][] = [
  ['Is joining the channel free?', 'Yes, joining the channel is completely free.'],
  ['Are the training and services free too?', 'No. Training and services are paid. You will find the full details inside the channel.'],
  ['When is my request approved?', 'We approve requests quickly. Once approved, the channel opens in Telegram.'],
  ['How do I get an ad account or a funnel?', 'Join the channel and talk to our team directly from there.'],
];
const POSTS: [string, string, string][] = [['Agency work — Part 1', 'Where clients come from', '10:24'], ['WhatsApp API · 2K', 'The full setup process', '13:05'], ['Agency account offer', 'Today’s rate & top-up', '18:40']];
const DEF: ChannelCopy = {
  sub: SUB, topics: TOPICS, offer: OFFER.map(o => ({ icon: o.icon === Briefcase ? 'briefcase' : o.icon === MessageCircle ? 'message' : o.icon === CreditCard ? 'card' : 'filter', t: o.t, d: o.d, tag: o.tag })),
  posts: POSTS, tiles: [['Training', 'Agency · API'], ['Services', 'Paid'], ['Updates', 'Daily'], ['Joining', 'Free']], faq: FAQ,
  band: 'Training, services and every new offer reach the {name} channel first.', foot: 'Joining the channel is free. Training and services are paid.', lock: 'Private channel · Free to join · Paid services',
};
const cp = (ch: ChannelText): ChannelCopy => ({ ...DEF, ...(ch.copy || {}) });
const isWa = (ch: ChannelText) => ch.kind === 'wa' || ch.kind === 'wac';
/** What the page is about: "Telegram channel" / "WhatsApp chat" / "WhatsApp community". */
const lbl = (ch: ChannelText) => ch.kind === 'wa' ? 'WhatsApp chat' : ch.kind === 'wac' ? 'WhatsApp community' : 'Telegram channel';
const badge = (ch: ChannelText) => ch.kind === 'wa' ? 'Official WhatsApp · real team' : ch.kind === 'wac' ? 'WhatsApp community' : 'Private Telegram channel';
const joinTxt = (ch: ChannelText) => ch.kind === 'wa' ? 'Chat on WhatsApp' : ch.kind === 'wac' ? 'Join WhatsApp community' : JOIN;
/** Opens in the same tab for WhatsApp (wa.me hands over to the app), new tab for Telegram. */
const tgt = (ch: ChannelText) => isWa(ch) ? {} : { target: '_blank', rel: 'noopener' };
function WaGlyph({ size = 18, className }: { size?: number; className?: string }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden="true" className={className}><path fill="currentColor" d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" /></svg>;
}
/** Telegram or WhatsApp logo, as the page needs. */
function CIcon({ ch, size = 18, className }: { ch: ChannelText; size?: number; className?: string }) {
  return isWa(ch) ? <WaGlyph size={size} /> : <TgIcon size={size} className={className} />;
}
const dark = (v: V) => v === 'stage' || v === 'horizon';

function Join({ ch, tone, className, children }: { ch: ChannelText; tone: 'white' | 'brand' | 'outline-white' | 'outline'; className?: string; children?: ReactNode }) {
  const pill = usePill();
  return <a href={ch.href} {...tgt(ch)} data-wa-chat={ch.kind === 'wa' ? '' : undefined} className={clsx(pill(tone), className)}><CIcon ch={ch} size={18} className="[&>circle]:fill-white/25" />{children ?? joinTxt(ch)}<ArrowRight size={16} /></a>;
}
function Actions({ c, ch, v, className }: { c: LandingContent; ch: ChannelText; v: V; className?: string }) {
  const anim = useAnim();
  const pill = usePill();
  return (
    <motion.div {...anim(0.2)} className={clsx('flex flex-col gap-4', v === 'stage' ? 'items-center lg:items-start' : v === 'horizon' ? 'items-center' : 'items-start', className)}>
      {ch.kind === 'wac' && ch.form
        ? <WaJoinForm line={ch.form.line} cc={ch.form.cc} off={ch.form.off} dark={dark(v)} btn={clsx(pill(dark(v) ? 'white' : 'brand'), '!w-full !whitespace-normal !normal-case !tracking-normal')} />
        : <Join ch={ch} tone={dark(v) ? 'white' : 'brand'} className={ch.cta ? 'max-w-full !whitespace-normal !text-[14.5px] !normal-case !leading-snug !tracking-normal sm:!text-[15.5px]' : ''}>{ch.cta}</Join>}
      <p className={clsx('inline-flex items-center gap-2 text-[14px]', dark(v) ? 'text-white/80' : 'text-fg-2')}><Lock size={14} />{cp(ch).lock}</p>
      {(ch.order || (ch.wa && !isWa(ch))) && (
        <p className={clsx('flex flex-wrap items-center gap-x-5 gap-y-2 text-[14.5px] font-semibold', v === 'horizon' ? 'justify-center' : v === 'stage' ? 'justify-center lg:justify-start' : '', dark(v) ? 'text-white/90' : 'text-fg')}>
          {ch.order && <a href={ch.order.href} className="inline-flex items-center gap-1.5 underline-offset-4 hover:underline"><ShoppingBag size={15} />{ch.order.label}</a>}
          {ch.wa && !isWa(ch) && <a href={ch.wa} target="_blank" rel="noopener" className="inline-flex items-center gap-1.5 underline-offset-4 hover:underline"><MessageCircle size={15} />No Telegram? WhatsApp community</a>}
        </p>
      )}
      {c.viewerFloor > 0 && <ViewerBadge theme={dark(v) ? 'purple' : 'blue'} floor={c.viewerFloor} />}
    </motion.div>
  );
}

/* ---------------- illustrations ---------------- */
/** Channel board in the same style as the ad-account dashboard. */
function ChannelBoard({ c, ch, tone }: { c: LandingContent; ch: ChannelText; tone: 'dark' | 'light' }) {
  const K = cp(ch);
  const reduce = useReducedMotion();
  const light = tone === 'light';
  const fl = (d: number) => ({ initial: reduce ? false : { opacity: 0, y: 20 }, animate: { opacity: 1, y: 0 }, transition: { duration: reduce ? 0 : 0.9, delay: reduce ? 0 : d, ease } } as const);
  return (
    <div className="relative w-full max-w-[360px] sm:max-w-[520px]">
      <motion.div {...fl(0.1)} className={clsx('relative mx-auto w-[88%] overflow-hidden rounded-2xl', light ? 'border border-edge bg-white shadow-[0_40px_80px_-30px_var(--m-shadow)]' : 'border border-white/20 bg-[color:var(--m-deep)] shadow-[0_40px_90px_-30px_rgba(0,0,0,.8)]')}>
        <div className="bg-[image:var(--m-board)] p-3 text-white sm:p-4">
          <div className="flex items-center gap-2 text-[9px] text-white/90 sm:text-[11px]">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={c.logo} alt="" className="h-5 w-5 rounded-md sm:h-6 sm:w-6" />
            <span className="font-semibold">{lbl(ch)}</span>
            <span className="ml-auto inline-flex items-center gap-1 rounded-full bg-white/25 px-2 py-0.5 font-semibold">{isWa(ch) ? <><WaGlyph size={10} />Online</> : <><Lock size={9} />Private</>}</span>
          </div>
          <div className="mt-3 grid grid-cols-2 gap-1.5 sm:gap-2">
            {K.tiles.map(([k, val]) => (
              <div key={k} className="rounded-lg bg-white/20 px-2 py-1.5"><p className="text-[8px] text-white/80 sm:text-[9.5px]">{k}</p><p className="text-[12px] font-semibold sm:text-[14px]">{val}</p></div>
            ))}
          </div>
        </div>
        <div className={clsx('divide-y px-3 py-1 text-[9px] sm:px-4 sm:text-[11px]', light ? 'divide-edge' : 'divide-white/10')}>
          {K.posts.map(([a, b, tm]) => (
            <div key={a} className="flex items-center gap-2 py-2"><span className={clsx('h-1.5 w-1.5 shrink-0 rounded-full', isWa(ch) ? 'bg-[#25D366]' : 'bg-[#2AABEE]')} /><span className={clsx('flex-1 truncate', light ? 'text-fg' : 'text-white/85')}><b className="font-semibold">{a}</b> <span className={light ? 'text-fg-3' : 'text-white/55'}>· {b}</span></span><span className={light ? 'text-fg-3' : 'text-white/50'}>{tm}</span></div>
          ))}
        </div>
      </motion.div>
      <motion.div {...fl(0.35)} className={clsx('relative z-[1] -mt-3 ml-auto mr-0 w-[58%] rounded-2xl p-3.5 sm:-mt-4 sm:w-[50%] sm:p-4', light ? 'border border-edge bg-white text-fg shadow-[0_24px_50px_-20px_var(--m-shadow)]' : 'border border-white/25 bg-[linear-gradient(150deg,rgba(255,255,255,.28),rgba(255,255,255,.12))] text-white shadow-[0_24px_50px_-20px_rgba(0,0,0,.6)] backdrop-blur-2xl')}>
        <p className="flex items-center gap-2 text-[11px] font-semibold sm:text-[12.5px]"><span className={clsx('grid h-6 w-6 place-items-center rounded-full text-white', isWa(ch) ? 'bg-[#25D366]' : 'bg-[#229ED9]')}>{isWa(ch) ? <WaGlyph size={13} /> : <Bell size={13} />}</span>{isWa(ch) ? 'New message · just now' : 'New post · just now'}</p>
        <p className="mt-2 text-[15px] font-medium sm:text-[17px]">{K.posts[1]?.[0]}</p>
        <p className={clsx('mt-0.5 text-[10.5px] sm:text-[12px]', light ? 'text-fg-2' : 'text-white/80')}>{K.posts[1]?.[1]}</p>
      </motion.div>
      <motion.div {...fl(0.5)} className="absolute bottom-3 left-0 z-[1] w-[40%] rounded-xl border border-white/15 bg-[color:var(--m-deep)] p-3 text-white shadow-[0_24px_50px_-20px_rgba(0,0,0,.7)] sm:bottom-5 sm:w-[36%] sm:p-3.5">
        <p className="text-[10px] text-white/70 sm:text-[11.5px]">{K.tiles[3]?.[0]} {String(K.tiles[3]?.[1] || '').toLowerCase()}</p><p className="mt-0.5 text-[15px] font-medium sm:text-[18px]">{K.tiles[1]?.[0]} {String(K.tiles[1]?.[1] || '').toLowerCase()}</p>
      </motion.div>
    </div>
  );
}

/** Green look: phone showing the channel feed. */
function ChannelPhone({ c, ch }: { c: LandingContent; ch: ChannelText }) {
  const reduce = useReducedMotion();
  const K = cp(ch);
  const posts = K.posts.map(([a, b]) => <><b>{a}</b><br />{b}</>);
  return (
    <div className="relative mx-auto w-full max-w-[330px]">
      <div className="absolute -right-7 top-[44%] z-10 grid h-24 w-24 rotate-12 place-items-center rounded-full bg-[#c6f36b] text-center text-[12px] font-extrabold uppercase leading-tight text-[#052e16] shadow-xl">{ch.hero ? <>Price<br /><span className="text-[20px] normal-case">{K.tiles[0]?.[1]}</span></> : <>Joining<br /><span className="text-[22px] normal-case">Free</span><span className="text-[9px] normal-case">services paid</span></>}</div>
      <div className="rounded-[46px] bg-[#0b1f14] p-2.5 shadow-[0_50px_90px_-40px_rgba(5,46,22,.7)]">
        <div className="overflow-hidden rounded-[38px] bg-[#e7f5ea]">
          <div className="flex items-center gap-3 bg-[#14532d] px-4 pb-3 pt-6 text-white">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={c.logo} alt="" className="h-9 w-9 rounded-full bg-white" />
            <span className="min-w-0 leading-tight"><b className="block truncate text-[14.5px]">{ch.name}</b><span className="inline-flex items-center gap-1 text-[12px] text-white/70">{isWa(ch) ? <>online · replies in minutes</> : <><Lock size={10} />private channel</>}</span></span>
            <CIcon ch={ch} size={20} className="ml-auto shrink-0" />
          </div>
          <div className="flex min-h-[400px] flex-col justify-end gap-2.5 bg-[radial-gradient(rgba(20,83,45,.08)_1px,transparent_1px)] bg-[size:14px_14px] p-3.5">
            {posts.map((t, i) => (
              <motion.div key={i} initial={reduce ? false : { opacity: 0, y: 10, scale: 0.96 }} whileInView={{ opacity: 1, y: 0, scale: 1 }} viewport={{ once: true }} transition={{ duration: reduce ? 0 : 0.45, delay: reduce ? 0 : 0.3 + i * 0.45 }}
                className="max-w-[90%] self-start rounded-2xl rounded-bl-md bg-white px-3.5 py-2.5 text-[13.5px] leading-snug text-[#0b1f14] shadow-sm">
                {t}<span className="mt-1 block text-right text-[10.5px] text-[#3c5446]/70">{K.posts[i]?.[2]}</span>
              </motion.div>
            ))}
            <motion.a href={ch.href} {...tgt(ch)} initial={reduce ? false : { opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: reduce ? 0 : 0.5, delay: reduce ? 0 : 1.8 }}
              className="mt-1 rounded-2xl bg-[#14532d] py-3 text-center text-[13.5px] font-bold text-white shadow-sm">{isWa(ch) ? joinTxt(ch) : 'Request to Join'}</motion.a>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------------- heroes (same build as the landing heroes) ---------------- */
function HeroStage({ c, ch }: { c: LandingContent; ch: ChannelText }) {
  const anim = useAnim();
  const K = cp(ch);
  // v118: on phones the Join / Order / WhatsApp buttons are on the first screen: small 16:9 board, text after the buttons
  return (
    <section style={{ ...DARK, ...pal(c.theme).hero, background: 'var(--m-hero)' } as CSSProperties} className="relative isolate overflow-hidden pb-14 pt-[72px] text-white sm:pb-24 sm:pt-[112px]">
      <div className="pointer-events-none absolute inset-x-0 bottom-0 -z-10 h-[45%] bg-[image:var(--m-glow)]" />
      <div className="mx-auto grid max-w-[1200px] items-center gap-5 px-5 sm:gap-9 sm:px-8 lg:grid-cols-[1fr_1.05fr] lg:gap-16">
        <div className="order-2 flex flex-col items-center text-center lg:order-1 lg:items-start lg:text-left">
          <Partner c={c} tone="dark" className="mb-5 hidden sm:inline-flex" />
          <motion.h1 {...anim(0.05)} className="text-balance text-[29px] font-light leading-[1.12] tracking-[-0.01em] sm:text-[56px] lg:text-[60px]">
            {ch.hero ? ch.hero.h : <>Join the {ch.name}</>} <span className="font-normal text-[color:var(--m-accent)]">{ch.hero ? ch.hero.a : lbl(ch)}</span>
          </motion.h1>
          <motion.p {...anim(0.12)} className="mt-5 hidden max-w-[46ch] text-[17px] font-light leading-relaxed text-white/85 sm:block sm:text-[18px]">{ch.hero?.sub || K.sub}</motion.p>
          <Actions c={c} ch={ch} v="stage" className="mt-5 sm:mt-8" />
          <motion.p {...anim(0.14)} className="mt-6 max-w-[46ch] text-[15.5px] font-light leading-relaxed text-white/85 sm:hidden">{ch.hero?.sub || K.sub}</motion.p>
          <Partner c={c} tone="dark" className="mt-5 sm:hidden" />
          <motion.p {...anim(0.3)} className="mt-7 text-[13px] font-medium uppercase tracking-[0.18em] text-white/70">{ch.hero ? `${c.payment} · within ${c.delivery}` : <>Free to join · Training &amp; services paid</>}</motion.p>
        </div>
        <div className="order-1 flex flex-col items-center lg:order-2">
          {c.recentOn && <RecentTicker align="center" inline className="mb-4 sm:mb-5" />}
          <motion.p {...anim(0)} className="mb-6 hidden items-center gap-3 sm:flex">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-[image:var(--m-grad)] shadow-[0_8px_24px_-8px_var(--m-shadow)] sm:h-11 sm:w-11">{isWa(ch) ? <WaGlyph size={20} /> : <Send size={20} />}</span>
            <span className="text-[23px] font-normal tracking-[-0.01em] sm:text-[30px]">{lbl(ch)}</span>
          </motion.p>
          <div className="hidden w-full justify-center sm:flex"><ChannelBoard c={c} ch={ch} tone="dark" /></div>
          <div className="aspect-[16/9] w-full max-w-[360px] overflow-hidden rounded-2xl border border-white/20 bg-[image:var(--m-board)] p-3.5 text-white shadow-[0_30px_70px_-30px_rgba(0,0,0,.8)] sm:hidden">
            <div className="flex items-center gap-2">
              <span className="grid h-8 w-8 place-items-center rounded-lg bg-white/25">{isWa(ch) ? <WaGlyph size={16} /> : <Send size={16} />}</span>
              <span className="text-[17px] font-medium leading-tight">{lbl(ch)}</span>
              <span className="ml-auto inline-flex items-center gap-1 rounded-full bg-white/25 px-2 py-0.5 text-[10px] font-semibold">{isWa(ch) ? <><WaGlyph size={10} />Online</> : <><Lock size={9} />Private</>}</span>
            </div>
            <div className="mt-3 grid grid-cols-2 gap-1.5">
              {K.tiles.map(([k, val]) => <div key={k} className="rounded-lg bg-white/20 px-2.5 py-1.5"><p className="text-[10px] text-white/80">{k}</p><p className="text-[15px] font-semibold leading-tight">{val}</p></div>)}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function HeroHorizon({ c, ch }: { c: LandingContent; ch: ChannelText }) {
  const anim = useAnim();
  const reduce = useReducedMotion();
  return (
    <section style={{ background: 'var(--m-hero)' }} className="relative isolate overflow-hidden pb-10 pt-[104px] text-white sm:pt-[136px]">
      <div className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-[60%] bg-[radial-gradient(rgba(255,255,255,.5)_1px,transparent_1px)] bg-[size:3px_3px] opacity-[.07]" />
      <div className="mx-auto flex max-w-[980px] flex-col items-center px-6 text-center sm:px-8">
        {c.recentOn && <RecentTicker align="center" inline className="mb-4" />}
        <Partner c={c} tone="dark" className="mb-4" />
        <motion.p {...anim(0)} className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-4 py-1.5 text-[12.5px] font-semibold uppercase tracking-[0.18em] text-white/80"><span className="h-1.5 w-1.5 rounded-full bg-[#fb923c]" />{badge(ch)}</motion.p>
        <motion.h1 {...anim(0.05)} className="mt-6 text-balance text-[38px] font-semibold leading-[1.06] tracking-[-0.035em] sm:text-[62px] lg:text-[70px]">
          {ch.hero ? ch.hero.h : <>Join the {ch.name}</>} <span className="text-[color:var(--m-accent)]">{ch.hero ? ch.hero.a : lbl(ch)}</span>
        </motion.h1>
        <motion.p {...anim(0.12)} className="mt-5 max-w-[50ch] text-[17px] leading-relaxed text-white/75 sm:text-[18px]">{ch.hero?.sub || cp(ch).sub}</motion.p>
        <Actions c={c} ch={ch} v="horizon" className="mt-8" />
      </div>
      <motion.div initial={reduce ? false : { opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: reduce ? 0 : 1, delay: reduce ? 0 : 0.3, ease }}
        className="mx-auto mt-14 flex max-w-[640px] justify-center px-4 [perspective:1400px]">
        <div className="w-full [transform:rotateX(14deg)] [transform-origin:top]"><ChannelBoard c={c} ch={ch} tone="dark" /></div>
      </motion.div>
    </section>
  );
}

function HeroCard({ c, ch }: { c: LandingContent; ch: ChannelText }) {
  const anim = useAnim();
  return (
    <section style={{ background: 'var(--m-hero)' }} className="relative overflow-hidden pb-16 pt-[96px] sm:pb-24 sm:pt-[124px]">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(rgb(var(--p)/.16)_1px,transparent_1px)] bg-[size:18px_18px] [mask-image:radial-gradient(ellipse_55%_45%_at_80%_20%,#000,transparent)]" />
      <div className="relative mx-auto grid max-w-[1200px] items-center gap-14 px-6 sm:px-8 lg:grid-cols-[1.05fr_1fr]">
        <div className="min-w-0">
          <div className="flex flex-wrap gap-2">
            {c.recentOn && <RecentTicker align="center" inline className="mb-4" />}
            <Partner c={c} tone="light" />
            <motion.p {...anim(0)} className="inline-flex items-center gap-2 rounded-full border border-edge bg-white px-3.5 py-1.5 text-[13px] font-semibold text-fg-2 shadow-sm"><span className="h-2 w-2 rounded-full bg-mint" />{badge(ch)}</motion.p>
          </div>
          <motion.h1 {...anim(0.05)} className="mt-5 text-balance text-[38px] font-bold leading-[1.04] tracking-[-0.045em] text-fg sm:text-[58px] lg:text-[62px]">
            {ch.hero ? ch.hero.h : <>Join the {ch.name}</>} <span className="text-violet">{ch.hero ? ch.hero.a : lbl(ch)}</span>
          </motion.h1>
          <motion.p {...anim(0.12)} className="mt-5 max-w-[48ch] text-[17px] leading-relaxed text-fg-2 sm:text-[18px]">{ch.hero?.sub || cp(ch).sub}</motion.p>
          <Actions c={c} ch={ch} v="card" className="mt-7" />
          <motion.div {...anim(0.3)} className="mt-7 grid max-w-[460px] grid-cols-3 divide-x divide-edge rounded-2xl border border-edge bg-white text-center shadow-sm">
            {(ch.hero ? [[cp(ch).tiles[0][1], 'Price'], [cp(ch).tiles[1][1], cp(ch).tiles[1][0]], ['7 days', 'Support']] : [['Free', 'Joining'], ['Daily', 'Updates'], ['Paid', 'Services']]).map(([a, b]) => (
              <div key={b} className="px-2 py-3"><p className="text-[18px] font-bold tracking-tight text-fg">{a}</p><p className="text-[12px] text-fg-3">{b}</p></div>
            ))}
          </motion.div>
        </div>
        <div className="mx-auto w-full max-w-[480px] py-6"><ChannelBoard c={c} ch={ch} tone="light" /></div>
      </div>
    </section>
  );
}

function HeroChat({ c, ch }: { c: LandingContent; ch: ChannelText }) {
  const anim = useAnim();
  return (
    <section style={{ background: 'var(--m-hero)' }} className="relative isolate overflow-hidden pb-16 pt-[92px] sm:pb-24 sm:pt-[120px]">
      <div className="pointer-events-none absolute -right-32 top-10 -z-10 h-[420px] w-[420px] rounded-full bg-[#86efac]/50 blur-3xl" />
      <div className="pointer-events-none absolute -left-40 bottom-0 -z-10 h-[380px] w-[380px] rounded-full bg-[#d9f99d]/70 blur-3xl" />
      <div className="mx-auto grid max-w-[1200px] items-center gap-12 px-6 sm:px-8 lg:grid-cols-[1.1fr_.9fr]">
        <div className="min-w-0">
          {c.recentOn && <RecentTicker align="center" inline className="mb-4" />}
          <Partner c={c} tone="green" className="mb-5" />
          <motion.h1 {...anim(0.05)} className="text-balance text-[42px] font-extrabold leading-[0.98] tracking-[-0.05em] text-fg sm:text-[68px] lg:text-[76px]">
            {ch.hero ? ch.hero.h : <>Join the {ch.name}</>} <span className="bg-[linear-gradient(transparent_58%,#c6f36b_58%,#c6f36b_92%,transparent_92%)] px-1">{ch.hero ? ch.hero.a : lbl(ch)}</span>
          </motion.h1>
          <motion.p {...anim(0.12)} className="mt-6 max-w-[46ch] text-[17px] leading-relaxed text-fg-2 sm:text-[19px]">{ch.hero?.sub || cp(ch).sub}</motion.p>
          <Actions c={c} ch={ch} v="chat" className="mt-8" />
        </div>
        <ChannelPhone c={c} ch={ch} />
      </div>
    </section>
  );
}

/* ---------------- sections ---------------- */
function Offers({ ch }: { ch: ChannelText }) {
  const v = useV();
  const green = v === 'chat';
  return (
    <section className={clsx('py-20 sm:py-28', green ? 'bg-[#f3fbf4]' : 'bg-void')}>
      <div className="mx-auto max-w-[1200px] px-6 sm:px-8">
        <Reveal className={center(v)}>
          <Eyebrow>{isWa(ch) ? 'What you get' : 'Inside the channel'}</Eyebrow>
          <H2 className="mt-4">Learn it or get it done, all in one place</H2>
          <div className={clsx('mt-7 flex flex-wrap gap-2', v !== 'chat' && 'justify-center')}>
            {cp(ch).topics.map(p => <span key={p} className="rounded-full border border-edge bg-plum-2 px-4 py-2 text-[13.5px] font-medium text-fg-2">{p}</span>)}
          </div>
        </Reveal>
        <div className={clsx('mt-12 grid gap-6 md:grid-cols-2', v !== 'chat' && 'mx-auto max-w-[980px]')}>
          {cp(ch).offer.map(({ icon, t, d, tag }, i) => {
            const I = ICONS[icon] || Briefcase;
            const hot = i === 0;
            return (
              <Reveal key={t} delay={i * 0.06} className={clsx('relative overflow-hidden p-8 sm:p-10', radius(v),
                hot ? 'bg-[image:var(--m-card)] text-white shadow-[0_40px_80px_-40px_var(--m-shadow)]' : green ? 'border-2 border-[#14532d] bg-white text-fg' : 'border border-edge bg-plum text-fg shadow-[0_30px_60px_-40px_var(--m-shadow)]')}>
                {hot && <div className="pointer-events-none absolute -bottom-24 -right-20 h-64 w-64 rounded-full bg-[radial-gradient(closest-side,var(--m-cardglow),transparent)]" />}
                <span className={clsx('grid h-12 w-12 place-items-center text-white', v === 'chat' ? 'rounded-full' : 'rounded-2xl', hot ? 'bg-white/20' : green ? 'bg-[#14532d]' : 'bg-[image:var(--m-grad)]')}><I size={22} /></span>
                <p className={clsx('mt-6 inline-flex rounded-full text-[12px] font-bold uppercase tracking-[0.16em]', green ? clsx('px-3 py-1', hot ? 'bg-[#c6f36b] text-[#052e16]' : 'bg-[#14532d] text-white') : hot ? 'text-[color:var(--m-accent)]' : 'text-violet')}>{tag}</p>
                <h3 className={clsx('mt-2 text-[24px] tracking-[-0.01em]', green ? 'font-bold' : dark(v) ? 'font-normal' : 'font-semibold')}>{t}</h3>
                <p className={clsx('mt-3 text-[15.5px] leading-relaxed', hot ? 'text-white/80' : 'text-fg-2')}>{d}</p>
              </Reveal>
            );
          })}
        </div>
        <Reveal className={clsx('mt-12 flex', v !== 'chat' && 'justify-center')}><Join ch={ch} tone="brand" /></Reveal>
      </div>
    </section>
  );
}

function Steps({ ch }: { ch: ChannelText }) {
  const v = useV();
  const STEPS = ch.steps || STEPS_TG;
  const how = isWa(ch) ? 'How it works' : 'How to join';
  if (v === 'card') return (
    <section className="bg-plum-2 py-20 sm:py-28">
      <div className="mx-auto grid max-w-[1100px] gap-12 px-6 sm:px-8 lg:grid-cols-[.9fr_1.1fr]">
        <Reveal><Eyebrow>{how}</Eyebrow><H2 className="mt-4">Three steps, one minute</H2><p className="mt-4 max-w-[38ch] text-[16px] text-fg-2">{isWa(ch) ? 'A real person from our team replies on WhatsApp.' : 'The channel opens as soon as your request is approved.'}</p><Join ch={ch} tone="brand" className="mt-8 hidden lg:inline-flex" /></Reveal>
        <ol className="relative">
          <span aria-hidden className="absolute bottom-8 left-[23px] top-8 w-[2px] bg-[linear-gradient(rgb(var(--p)),rgb(var(--p)/.15))]" />
          {STEPS.map(({ t, d }, i) => (
            <Reveal key={t} delay={i * 0.08}>
              <li className="relative flex list-none gap-5 pb-10 last:pb-0">
                <span className="relative z-[1] grid h-12 w-12 shrink-0 place-items-center rounded-full border-4 border-[rgb(var(--s2))] bg-violet text-white">{i === 0 ? <CIcon ch={ch} size={20} /> : i === 1 ? <Send size={20} /> : <Check size={20} />}</span>
                <div className="rounded-2xl border border-edge bg-white p-5 shadow-sm"><p className="text-[12px] font-bold uppercase tracking-[0.14em] text-violet">Step {i + 1}</p><h3 className="mt-1 text-[19px] font-semibold text-fg">{t}</h3><p className="mt-1.5 text-[15px] leading-relaxed text-fg-2">{d}</p></div>
              </li>
            </Reveal>
          ))}
        </ol>
      </div>
    </section>
  );
  if (v === 'chat') return (
    <section className="bg-void py-20 sm:py-28">
      <div className="mx-auto max-w-[900px] px-6 sm:px-8">
        <Reveal><Eyebrow>{how}</Eyebrow><H2 className="mt-4 max-w-[16ch]">Three steps, one minute</H2></Reveal>
        <div className="mt-12 space-y-6">
          {STEPS.map(({ who, t, d }, i) => (
            <Reveal key={t} delay={i * 0.08} className={clsx('flex items-end gap-3', i % 2 && 'flex-row-reverse')}>
              <span className={clsx('grid h-12 w-12 shrink-0 place-items-center rounded-full text-[18px] font-extrabold', i === 2 ? 'bg-[#c6f36b] text-[#052e16]' : 'bg-[#14532d] text-white')}>{i + 1}</span>
              <div className={clsx('max-w-[560px] rounded-[26px] p-6 shadow-[0_20px_50px_-35px_var(--m-shadow)]', i % 2 ? 'rounded-br-md bg-[#14532d] text-white' : 'rounded-bl-md border border-edge bg-[#f3fbf4]')}>
                <p className={clsx('text-[12px] font-bold uppercase tracking-[0.14em]', i % 2 ? 'text-[#c6f36b]' : 'text-violet')}>{who}</p>
                <h3 className="mt-1 text-[21px] font-bold tracking-[-0.02em]">{t}</h3>
                <p className={clsx('mt-1.5 text-[15.5px] leading-relaxed', i % 2 ? 'text-white/80' : 'text-fg-2')}>{d}</p>
              </div>
            </Reveal>
          ))}
        </div>
        <Reveal className="mt-12"><Join ch={ch} tone="brand" /></Reveal>
      </div>
    </section>
  );
  return (
    <section className={clsx('py-20 sm:py-28', v === 'horizon' ? 'bg-plum' : 'bg-plum-2')}>
      <div className="mx-auto max-w-[1200px] px-6 sm:px-8">
        <Reveal className={center(v)}><Eyebrow>{how}</Eyebrow><H2 className="mt-4">Three steps, one minute</H2></Reveal>
        <div className="mt-14 grid gap-10 md:grid-cols-3 md:gap-6">
          {STEPS.map(({ t, d }, i) => (
            <Reveal key={t} delay={i * 0.08} className="relative flex flex-col items-center text-center">
              <span className="grid h-16 w-16 place-items-center rounded-full bg-[image:var(--m-step)] text-[24px] font-light text-white shadow-[0_16px_34px_-14px_var(--m-shadow)]">{i + 1}</span>
              {i < STEPS.length - 1 && <ArrowRight aria-hidden size={26} strokeWidth={1.5} className="absolute -right-6 top-5 hidden text-violet/40 md:block" />}
              <h3 className="mt-6 text-[21px] font-normal text-fg">{t}</h3>
              <p className="mt-2.5 max-w-[32ch] text-[15px] leading-relaxed text-fg-2">{d}</p>
            </Reveal>
          ))}
        </div>
        <Reveal className="mt-12 flex justify-center"><Join ch={ch} tone="brand" /></Reveal>
      </div>
    </section>
  );
}

function Faq({ ch }: { ch: ChannelText }) {
  const FAQ = cp(ch).faq;
  const v = useV();
  if (v === 'chat') return (
    <section className="bg-void py-20 sm:py-28">
      <div className="mx-auto grid max-w-[1100px] gap-10 px-6 sm:px-8 lg:grid-cols-[.8fr_1.2fr]">
        <Reveal><Eyebrow>FAQ</Eyebrow><H2 className="mt-4">Frequently asked questions</H2></Reveal>
        <div className="space-y-3">
          {FAQ.map(([q, a]) => (
            <details key={q} className="group rounded-[22px] bg-[#f3fbf4] px-6 open:bg-[#14532d] open:text-white">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-4 py-5 text-[17px] font-bold [&::-webkit-details-marker]:hidden">
                {q}<span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-[#c6f36b] text-[#052e16] transition-transform group-open:rotate-45"><Plus size={18} /></span>
              </summary>
              <p className="pb-5 text-[15.5px] leading-relaxed text-white/85">{a}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
  if (v === 'card') return (
    <section className="bg-void py-20 sm:py-28">
      <div className="mx-auto max-w-[1100px] px-6 sm:px-8">
        <Reveal className="mx-auto max-w-[720px] text-center"><Eyebrow>FAQ</Eyebrow><H2 className="mt-4">Frequently asked questions</H2></Reveal>
        <div className="mt-12 grid items-start gap-4 md:grid-cols-2">
          {FAQ.map(([q, a]) => (
            <details key={q} className="group rounded-2xl border border-edge bg-white px-5 open:shadow-[0_20px_40px_-30px_var(--m-shadow)]">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-4 py-5 text-[16px] font-semibold text-fg [&::-webkit-details-marker]:hidden">
                {q}<span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-violet/10 text-violet transition-transform group-open:rotate-45"><Plus size={17} /></span>
              </summary>
              <p className="pb-5 text-[15px] leading-relaxed text-fg-2">{a}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
  return (
    <section className="bg-void py-20 sm:py-28">
      <div className="mx-auto max-w-[820px] px-6 sm:px-8">
        <Reveal className="text-center"><Eyebrow>FAQ</Eyebrow><H2 className="mt-4">Frequently asked questions</H2></Reveal>
        <div className="mt-12 divide-y divide-edge border-y border-edge">
          {FAQ.map(([q, a]) => (
            <details key={q} className="group">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-5 py-5 text-[17px] font-medium text-fg [&::-webkit-details-marker]:hidden sm:py-6">
                {q}<span className="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-edge text-violet transition-transform group-open:rotate-45"><Plus size={18} /></span>
              </summary>
              <p className="pb-6 pr-12 text-[15.5px] leading-relaxed text-fg-2">{a}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}

function Band({ ch }: { ch: ChannelText }) {
  const v = useV();
  const title = ch.band || (isWa(ch) ? (ch.kind === 'wa' ? 'Message us on WhatsApp in one tap' : 'Join the WhatsApp community') : 'Join the channel in one tap');
  const text = cp(ch).band.replace(/\{name\}/g, ch.name);
  if (v === 'chat') return (
    <section className="bg-void px-4 pb-4 sm:px-6 sm:pb-6">
      <div className="relative mx-auto max-w-[1240px] overflow-hidden rounded-[40px] bg-[#c6f36b] px-7 py-16 text-[#052e16] sm:px-14 sm:py-20">
        <div className="pointer-events-none absolute -right-20 -top-20 h-72 w-72 rounded-full border-[36px] border-[#052e16]/10" />
        <h2 className="relative max-w-[18ch] text-balance text-[36px] font-extrabold leading-[1] tracking-[-0.045em] sm:text-[58px]">{title}</h2>
        <p className="relative mt-5 max-w-[46ch] text-[17px] text-[#052e16]/75">{text}</p>
        <div className="relative mt-9"><Join ch={ch} tone="brand" /></div>
      </div>
    </section>
  );
  return (
    <section className={clsx('bg-void px-4 pb-4 sm:px-6 sm:pb-6', v === 'card' && 'pt-4')}>
      <div style={{ background: 'var(--m-band)' }} className={clsx('relative isolate mx-auto max-w-[1240px] overflow-hidden px-6 py-20 text-center text-white sm:py-24', v === 'card' ? 'rounded-3xl' : 'rounded-[32px]')}>
        <h2 className={clsx('mx-auto max-w-[20ch] text-balance text-[32px] leading-[1.12] sm:text-[48px]', dark(v) ? 'font-light' : 'font-semibold tracking-[-0.03em]')}>{title}</h2>
        <p className="mx-auto mt-5 max-w-[46ch] text-[17px] text-white/85">{text}</p>
        <div className="mt-10 flex justify-center"><Join ch={ch} tone="white" /></div>
      </div>
    </section>
  );
}

function Nav({ c, ch }: { c: LandingContent; ch: ChannelText }) {
  const v = useV();
  const pill = usePill();
  const d = dark(v);
  return (
    <header className={clsx('z-50', v === 'card' ? 'fixed inset-x-0 top-0 border-b border-edge bg-white/95 backdrop-blur-xl' : 'absolute inset-x-0 top-0')}>
      <div className={clsx('mx-auto flex max-w-[1200px] items-center gap-6 px-6 sm:px-8', v === 'card' ? 'h-16' : 'h-20')}>
        <Wordmark c={c} light={d} />
        <a href={ch.href} {...tgt(ch)} className={clsx(pill(d ? 'white' : 'brand'), 'ml-auto !px-5 !py-2.5')}><CIcon ch={ch} size={16} className="[&>circle]:fill-white/25" />{ch.kind === 'wa' ? 'Chat' : 'Join'}</a>
      </div>
    </header>
  );
}

function Footer({ c, ch }: { c: LandingContent; ch: ChannelText }) {
  const v = useV();
  const light = v === 'card';
  return (
    <footer className={light ? 'bg-[color:var(--m-foot)] text-fg-2' : 'bg-[color:var(--m-foot)] text-white/70'}>
      <div className="mx-auto flex max-w-[1200px] flex-col gap-4 px-6 py-12 sm:px-8">
        <Wordmark c={c} light={!light} />
        <p className="max-w-[44ch] text-[14px] leading-relaxed">{cp(ch).foot}</p>
        <a href="/" className={clsx('text-[14px] underline-offset-4 hover:underline', light ? 'text-fg' : 'text-white/85')}>{c.brand} website →</a>
      </div>
      <p className={clsx('border-t px-6 py-6 text-center text-[13px]', light ? 'border-edge text-fg-3' : 'border-white/10 text-white/50')}>© {new Date().getFullYear()} {c.brand}</p>
    </footer>
  );
}

/** Join button pinned to the bottom on phones once the hero button has scrolled away. */
function StickyJoin({ ch }: { ch: ChannelText }) {
  const [show, setShow] = useState(false);
  useEffect(() => { const f = () => setShow(window.scrollY > 560); f(); window.addEventListener('scroll', f, { passive: true }); return () => window.removeEventListener('scroll', f); }, []);
  const pill = usePill();
  return (
    <div className={clsx('fixed inset-x-0 bottom-0 z-50 px-4 pb-4 pt-6 transition-all duration-300 sm:hidden', show ? 'translate-y-0 opacity-100' : 'pointer-events-none translate-y-full opacity-0')} style={{ background: 'linear-gradient(180deg,transparent,rgb(var(--bg)/.92) 45%)' }}>
      <a href={ch.href} {...tgt(ch)} className={clsx(pill('brand'), 'w-full')}><CIcon ch={ch} size={18} className="[&>circle]:fill-white/25" />{joinTxt(ch)}</a>
    </div>
  );
}

export function ChannelLanding({ c, ch }: { c: LandingContent; ch: ChannelText }) {
  const v = VARIANT[c.theme] || 'stage';
  const Hero = { stage: HeroStage, card: HeroCard, chat: HeroChat, horizon: HeroHorizon }[v];
  const order: ((p: { ch: ChannelText }) => ReactNode)[] = v === 'chat' ? [Steps, Offers, Faq, Band] : [Offers, Steps, Faq, Band];
  return (
    <VC.Provider value={v}>
      <div className="font-display" style={pal(c.theme).page as CSSProperties}>
        <Nav c={c} ch={ch} />
        <main><Hero c={c} ch={ch} />{order.map((S, i) => <S key={i} ch={ch} />)}</main>
        <Footer c={c} ch={ch} />
        <div aria-hidden className="h-20 sm:hidden" />
        <StickyJoin ch={ch} />
      </div>
    </VC.Provider>
  );
}
