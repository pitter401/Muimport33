'use client';

/* Premium landing pages. One set of sections, four distinct looks:
   - purple  "stage"   : black -> violet -> magenta -> peach hero, dashboard on top, letter-spaced pills (the main page)
   - blue    "light"   : bright blue-white page, bold headline first, white dashboard, bento cards
   - green   "frame"   : white page with a rounded green hero frame, dashboard breaking out of the frame
   - gold    "horizon" : all-dark navy page with a sunset-orange glow and a tilted dashboard
   Every button opens the same lead form / Telegram / website flow as before. */

import { createContext, useContext, useState, type CSSProperties, type ReactNode } from 'react';
import { motion, useReducedMotion } from 'framer-motion';
import { Check, Plus, ArrowRight, Menu, X, Globe, UserRound, ShieldCheck, BadgeCheck, Clock, MessageCircle, Wallet, Building2, BadgeDollarSign, Users, Rocket, Bell, LineChart, Filter } from 'lucide-react';
import clsx from 'clsx';
import { TgIcon, TgPill } from '../Telegram';
import { OrderChoice } from '../OrderChoice';
import { LeadButton } from '../LeadModal';
import { RecentTicker } from '../RecentTicker';
import { Reveal, Logo, ViewerBadge } from '../Sections';
import { CountUp } from '../CountUp';
import type { LandingContent, Offer } from '@/server/content';

const ease = [0.16, 1, 0.3, 1] as const;
export type V = 'stage' | 'card' | 'chat' | 'horizon';
export const VARIANT: Record<string, V> = { purple: 'stage', blue: 'card', green: 'chat', gold: 'horizon' };
export const VC = createContext<V>('stage');
export const useV = () => useContext(VC);

import { pal, DARK } from '../palette';
export { pal, DARK };

/* ---------------- Funnel page (/funnel): same four looks, funnel first, ad accounts second ---------------- */
const isF = (c: LandingContent) => c.mode === 'funnel';
/** The two offers in page order: [main, second]. */
const offers = (c: LandingContent): [Offer, 'account' | 'funnel'][] => (isF(c) ? [[c.funnel, 'funnel'], [c.account, 'account']] : [[c.account, 'account'], [c.funnel, 'funnel']]);
const stepsFor = (c: LandingContent) => isF(c) ? [
  { t: 'Tell us about your offer', d: 'Answer two quick questions and message your funnel manager on Telegram.' },
  { t: 'We build your funnel', d: 'Landing page, lead form, Telegram routing and Meta tracking, ready in 2 to 3 days.' },
  { t: 'Leads start coming in', d: 'Run your ads to the page. Every lead reaches your sales team on Telegram in seconds.' },
] : [
  { t: 'Message us on Telegram', d: 'Answer three quick questions. Your message is pre-typed, just press Send.' },
  { t: 'Pay and share your BM ID', d: `${c.payment}. Send your Business Manager ID in the same chat.` },
  { t: 'Start advertising', d: `Your account is shared to your Business Manager within ${c.delivery}.` },
];
const whyFor = (c: LandingContent) => isF(c) ? [
  { icon: Clock, t: 'Live in 2 to 3 days', d: 'We set up the page, the form, the Telegram routing and the tracking for you.' },
  { icon: Bell, t: 'Leads straight to Telegram', d: 'Name, number and answers reach your team the moment someone fills the form.' },
  { icon: Users, t: 'An app for your sales team', d: 'Leads rotate between your agents, and a slow reply moves to the next one.' },
  { icon: LineChart, t: 'Meta tracking done right', d: 'Server-side Conversions API sends Lead and Purchase events, so your ads learn who buys.' },
  { icon: BadgeDollarSign, t: 'One monthly price', d: `$${c.priceFunnel} per month covers hosting, the apps and support. No setup surprises.` },
] : [
  { icon: Clock, t: `Live within ${c.delivery}`, d: 'Counted from confirmed payment. Your agent shares the account to your Business Manager in the same chat.' },
  { icon: MessageCircle, t: 'One agent, start to finish', d: 'The person who sells you the account supports it after launch.' },
  { icon: Wallet, t: 'Top-ups in the same chat', d: 'Add funds through your agent without placing a new order.' },
  { icon: Building2, t: 'No Business Manager yet?', d: 'We walk you through creating one. It is free and takes minutes.' },
  { icon: BadgeDollarSign, t: 'Clear pricing', d: `$${c.priceAccount} per account. You still pay Meta for your ads, but top-ups go through us${Number(c.topupFee) ? ` for a ${c.topupFee}% fee` : ''}, so you save the 18% GST.` },
];
const audienceFor = (c: LandingContent) => isF(c) ? [
  { icon: Users, t: 'Any business, any niche', d: 'E-commerce, local shops and services, coaching, real estate, apps and more. If you can sell it with Meta ads, we build the funnel for it.' },
  { icon: Rocket, t: 'Funnel and ad setup, done for you', d: 'We build the landing page, set up your ads and tracking, and send every lead straight to your team. You just close the sales.' },
] : [
  { icon: Users, t: 'Agencies', d: 'Run several clients without hitting limits. One account per client, top-ups in the same Telegram chat, and an agent who already knows your setup.' },
  { icon: Rocket, t: 'Affiliates & e-commerce', d: `No spending limit and multiple pages and domains, so a winning offer can scale from day one. Live within ${c.delivery}.` },
];

/* ---------------- per-look building blocks ---------------- */
type Tone = 'white' | 'brand' | 'outline-white' | 'outline';
export function usePill() {
  const v = useV();
  return (tone: Tone) => clsx(
    'inline-flex items-center justify-center gap-2 transition-transform duration-200 hover:scale-[1.02]',
    v === 'stage' || v === 'horizon' ? 'rounded-full px-8 py-4 text-[13px] font-semibold uppercase tracking-[0.22em]'
      : v === 'card' ? 'rounded-xl px-6 py-3.5 text-[15px] font-semibold' : 'rounded-full px-7 py-3.5 text-[15.5px] font-bold',
    tone === 'white' && 'bg-white text-[color:var(--m-ink)] shadow-[0_12px_30px_-12px_rgba(0,0,0,.45)]',
    tone === 'brand' && 'bg-[image:var(--m-btn)] text-white shadow-[0_14px_30px_-14px_var(--m-shadow)]',
    tone === 'outline-white' && 'border border-white/60 text-white hover:bg-white/10',
    tone === 'outline' && 'border border-violet/40 text-fg hover:bg-violet/10',
  );
}
export function Eyebrow({ children, className }: { children: ReactNode; className?: string }) {
  const v = useV();
  if (v === 'card') return <p className={clsx('inline-flex rounded-full bg-violet/10 px-3.5 py-1.5 text-[13px] font-semibold text-violet', className)}>{children}</p>;
  if (v === 'chat') return <p className={clsx('text-[15px] font-semibold text-violet', className)}>— {children}</p>;
  return <p className={clsx('text-[12.5px] font-semibold uppercase tracking-[0.24em]', v === 'horizon' ? 'text-lilac' : 'text-violet', className)}>{children}</p>;
}
export function H2({ children, className }: { children: ReactNode; className?: string }) {
  const v = useV();
  return <h2 className={clsx('text-balance text-fg', v === 'stage' || v === 'horizon' ? 'text-[32px] font-light leading-[1.15] tracking-[-0.01em] sm:text-[46px]'
    : v === 'card' ? 'text-[30px] font-semibold leading-[1.1] tracking-[-0.035em] sm:text-[44px]' : 'text-[34px] font-semibold leading-[1.02] tracking-[-0.04em] sm:text-[54px]', className)}>{children}</h2>;
}
export const radius = (v: V) => (v === 'stage' ? 'rounded-[28px]' : v === 'card' ? 'rounded-2xl' : v === 'chat' ? 'rounded-[32px]' : 'rounded-3xl');
export const center = (v: V) => (v === 'chat' ? 'max-w-[760px]' : 'mx-auto max-w-[720px] text-center');

export function PremiumLanding({ c }: { c: LandingContent }) {
  const v = VARIANT[c.theme] || 'stage';
  const order: Record<V, ((p: { c: LandingContent }) => ReactNode)[]> = {
    stage: [Provide, Audience, Steps, Why, Band, Faq],
    card: [CardPlans, CardSteps, CardWhy, Audience, CardFaq, Band],
    chat: [ChatSteps, ChatTickets, Audience, ChatWhy, ChatFaq, ChatBand],
    horizon: [Provide, Why, Steps, Audience, Faq, Band],
  };
  const Hero = { stage: HeroStage, card: HeroCard, chat: HeroChat, horizon: HeroHorizon }[v];
  return (
    <VC.Provider value={v}>
      <div className="font-display" style={pal(c.theme).page as CSSProperties}>
        <Nav c={c} />
        <main><Hero c={c} />{order[v].map((S, i) => <S key={i} c={c} />)}</main>
        <Footer c={c} />
      </div>
    </VC.Provider>
  );
}

/* ---------------- nav ---------------- */
/** Blue verified tick (scalloped badge) shown after the brand name. */
function VerifiedTick({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" aria-label="Verified" role="img" className={clsx('shrink-0', className)}>
      <path fill="#1d9bf0" d="M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z" />
      <path d="m8.6 12.2 2.4 2.4 4.6-4.8" fill="none" stroke="#fff" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function Wordmark({ c, light }: { c: LandingContent; light?: boolean }) {
  const v = useV();
  return (
    <a href="#" className={clsx('flex items-center gap-2.5', light ? 'text-white' : 'text-fg')}>
      {(c.logo || v === 'card' || v === 'chat') && <Logo brand={c.brand} src={c.logo} />}
      <span className={clsx('leading-none', v === 'stage' || v === 'horizon' ? 'text-[24px] font-bold uppercase tracking-[0.06em] sm:text-[27px]' : 'text-[21px] font-bold tracking-[-0.02em]')}>{c.brand}</span>
      {c.verified && <VerifiedTick className={v === 'stage' || v === 'horizon' ? '-ml-1 h-[22px] w-[22px] sm:h-[25px] sm:w-[25px]' : '-ml-1 h-[19px] w-[19px]'} />}
    </a>
  );
}
const LINKS: [string, string][] = [['#provide', 'Pricing'], ['#steps', 'How it works'], ['#why', 'Why us'], ['#faq', 'FAQ']];

function Nav({ c }: { c: LandingContent }) {
  const v = useV();
  const pill = usePill();
  const [open, setOpen] = useState(false);
  const dark = v === 'stage' || v === 'horizon';
  return (
    <header className={clsx('z-50', v === 'card' ? 'fixed inset-x-0 top-[var(--bar-h)] border-b border-edge bg-white/95 backdrop-blur-xl' : 'absolute inset-x-0 top-[var(--bar-h)]')}>
      <div className={clsx('mx-auto flex max-w-[1200px] items-center gap-6 px-6 sm:px-8', v === 'card' ? 'h-16' : 'h-20')}>
        <Wordmark c={c} light={dark} />
        <nav className={clsx('ml-8 hidden gap-8 text-[14px] font-medium md:flex', dark ? 'text-white/80' : 'text-fg-2')}>
          {LINKS.map(([h, l]) => <a key={h} href={h} className={dark ? 'hover:text-white' : 'hover:text-violet'}>{l}</a>)}
        </nav>
        <div className={clsx('ml-auto flex items-center gap-3', dark ? 'text-white' : 'text-fg')}>
          {c.webOn && <a href="/account" aria-label="My account" className={clsx('grid h-10 w-10 place-items-center rounded-full', dark ? 'hover:bg-white/10' : 'hover:bg-violet/10')}><UserRound size={22} strokeWidth={2} /></a>}
          <LeadButton className={clsx(pill(dark ? 'white' : 'brand'), 'hidden !px-5 !py-2.5 md:inline-flex')}>Get started</LeadButton>
          <button onClick={() => setOpen(o => !o)} aria-label="Menu" aria-expanded={open} className={clsx('grid h-10 w-10 place-items-center rounded-full md:hidden', dark ? 'hover:bg-white/10' : 'hover:bg-violet/10')}>
            {open ? <X size={26} /> : <Menu size={28} strokeWidth={1.8} />}
          </button>
        </div>
      </div>
      {open && (
        <div className={clsx('relative z-50 mx-4 rounded-2xl p-2 shadow-[0_30px_60px_-20px_rgba(0,0,0,.6)] md:hidden', dark ? 'border border-white/15 bg-[color:var(--m-deep)] text-white' : 'border border-edge bg-white text-fg')}>
          {LINKS.map(([h, l]) => <a key={h} href={h} onClick={() => setOpen(false)} className={clsx('block rounded-xl px-4 py-3.5 text-[16px]', dark ? 'hover:bg-white/10' : 'hover:bg-violet/5')}>{l}</a>)}
          <div className="p-2"><LeadButton className={clsx(pill(dark ? 'white' : 'brand'), 'w-full')}>Get started</LeadButton></div>
        </div>
      )}
    </header>
  );
}

/* ---------------- partner badge ---------------- */
/** "Meta Business Partner" style badge (text from Admin). Verified tick, no third-party logo. */
export function Partner({ c, tone, className }: { c: LandingContent; tone: 'dark' | 'light' | 'green'; className?: string }) {
  const anim = useAnim();
  if (!c.partner) return null;
  return (
    <motion.p {...anim(0)} className={clsx('inline-flex items-center gap-2 rounded-full py-1.5 pl-1.5 pr-4 text-[13.5px] font-semibold',
      tone === 'dark' ? 'border border-white/20 bg-white/10 text-white backdrop-blur' : tone === 'green' ? 'border border-[#14532d]/15 bg-white text-[#14532d] shadow-sm' : 'border border-edge bg-white text-fg shadow-sm', className)}>
      <span className="grid h-6 w-6 place-items-center rounded-full bg-[#0866ff] text-white"><BadgeCheck size={15} strokeWidth={2.4} /></span>
      {c.partner}
    </motion.p>
  );
}

/* ---------------- heroes ---------------- */
export function useAnim() {
  const reduce = useReducedMotion();
  // always ends visible (also for people with "reduce motion" switched on)
  return (d: number) => ({ initial: reduce ? false : { opacity: 0, y: 16 }, animate: { opacity: 1, y: 0 }, transition: { duration: reduce ? 0 : 0.8, delay: reduce ? 0 : d, ease } } as const);
}

/** Order cards (website orders on) or the Telegram button, + live viewers. */
function Actions({ c, dark, className }: { c: LandingContent; dark: boolean; className?: string }) {
  const pill = usePill();
  const anim = useAnim();
  const v = useV();
  const badge = dark ? 'purple' : 'blue';
  if (isF(c) && c.webFunnelOn) return ( // v118: funnel pages get the same two choices (Telegram / website)
    <motion.div {...anim(0.2)} className={clsx('flex w-full max-w-[560px] flex-col gap-3', v === 'stage' ? 'items-center lg:items-start' : v === 'card' ? 'items-start' : 'items-center', className)}>
      <OrderChoice funnel c={{ ...c, theme: badge }} tone={dark ? 'purple' : v === 'chat' ? 'green' : 'blue'} layout={v === 'card' ? 'rows' : v === 'chat' ? 'bubbles' : 'grid'} />
      <LeadButton service="account" className={clsx('text-[14px] font-medium underline-offset-4 hover:underline', dark ? 'text-white/80' : 'text-fg-2')}>Need an ad account? From ${c.priceAccount} →</LeadButton>
    </motion.div>
  );
  if (isF(c)) return (
    <motion.div {...anim(0.2)} className={clsx('flex flex-col gap-4', v === 'stage' ? 'items-center lg:items-start' : v === 'card' ? 'items-start' : 'items-center', v === 'chat' && 'items-start', className)}>
      <LeadButton service="funnel" className={pill(dark ? 'white' : 'brand')}>{c.funnel.cta} · ${c.priceFunnel}/mo<ArrowRight size={16} /></LeadButton>
      <TgPill c={c} className={dark ? 'justify-center text-white/80' : ''} />
      <LeadButton service="account" className={clsx('text-[14px] font-medium underline-offset-4 hover:underline', dark ? 'text-white/80' : 'text-fg-2')}>Need an ad account? From ${c.priceAccount} →</LeadButton>
      {c.viewerFloor > 0 && <ViewerBadge theme={badge} floor={c.viewerFloor} />}
    </motion.div>
  );
  return c.webOn ? (
    <motion.div {...anim(0.2)} className={clsx('w-full max-w-[560px]', className)}><OrderChoice c={{ ...c, theme: badge }} tone={dark ? 'purple' : v === 'chat' ? 'green' : 'blue'} layout={v === 'card' ? 'rows' : v === 'chat' ? 'bubbles' : 'grid'} /></motion.div>
  ) : (
    <motion.div {...anim(0.2)} className={clsx('flex flex-col gap-4', v === 'stage' ? 'items-center lg:items-start' : v === 'card' ? 'items-start' : 'items-center', className)}>
      <LeadButton className={pill(dark ? 'white' : 'brand')}>Get started<ArrowRight size={16} /></LeadButton>
      <TgPill c={c} className={dark ? 'justify-center text-white/80' : ''} />
      {c.viewerFloor > 0 && <ViewerBadge theme={badge} floor={c.viewerFloor} />}
    </motion.div>
  );
}

function HeroStage({ c }: { c: LandingContent }) {
  const anim = useAnim();
  // v118: on phones the order buttons must be on the first screen (people tap what they see without scrolling):
  // a small 16:9 board, the title inside it, the sub text and the Partner pill after the buttons
  return (
    <section style={{ ...DARK, ...pal(c.theme).hero, background: 'var(--m-hero)' } as CSSProperties} className="relative isolate overflow-hidden pb-14 pt-[calc(var(--bar-h)+64px)] text-white sm:pb-24 sm:pt-[calc(var(--bar-h)+112px)]">
      <div className="pointer-events-none absolute inset-x-0 bottom-0 -z-10 h-[45%] bg-[image:var(--m-glow)]" />
      <div className="mx-auto grid max-w-[1200px] items-center gap-5 px-5 sm:gap-9 sm:px-8 lg:grid-cols-[1fr_1.05fr] lg:gap-16">
        <div className="order-2 flex flex-col items-center text-center lg:order-1 lg:items-start lg:text-left">
          <Partner c={c} tone="dark" className="mb-5 hidden sm:inline-flex" />
          <motion.h1 {...anim(0.05)} className="text-balance text-[29px] font-light leading-[1.12] tracking-[-0.01em] sm:text-[56px] lg:text-[60px]">
            {c.headline} <span className="font-normal text-[color:var(--m-accent)]">{c.accent}</span>
          </motion.h1>
          <motion.p {...anim(0.12)} className="mt-5 hidden max-w-[46ch] text-[17px] font-light leading-relaxed text-white/85 sm:block sm:text-[18px]">{c.sub}</motion.p>
          <Actions c={c} dark className="mt-5 sm:mt-8" />
          <motion.p {...anim(0.14)} className="mt-6 max-w-[46ch] text-[15.5px] font-light leading-relaxed text-white/85 sm:hidden">{c.sub}</motion.p>
          <Partner c={c} tone="dark" className="mt-5 sm:hidden" />
          <motion.p {...anim(0.3)} className="mt-7 text-[13px] font-medium uppercase tracking-[0.18em] text-white/70">{c.payment} · within {c.delivery}</motion.p>
        </div>
        <div className="order-1 flex flex-col items-center lg:order-2">
          {c.recentOn && <RecentTicker align="center" inline className="mb-4 sm:mb-5" />}
          <motion.p {...anim(0)} className="mb-6 hidden items-center gap-3 sm:flex">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-[image:var(--m-grad)] shadow-[0_8px_24px_-8px_var(--m-shadow)] sm:h-11 sm:w-11">{isF(c) ? <Filter size={21} /> : <ShieldCheck size={22} />}</span>
            <span className="text-[23px] font-normal tracking-[-0.01em] sm:text-[30px]">{isF(c) ? c.funnel.title : c.account.title}</span>
          </motion.p>
          <div className="hidden w-full justify-center sm:flex">{isF(c) ? <FunnelBoard c={c} tone="dark" /> : <Board c={c} tone="dark" />}</div>
          <MiniBoard c={c} />
        </div>
      </div>
    </section>
  );
}

/** v118: phone-size 16:9 version of the hero board (title inside), so the order buttons fit on the first screen. */
function MiniBoard({ c }: { c: LandingContent }) {
  const reduce = useReducedMotion();
  const f = isF(c);
  const tiles: [string, ReactNode][] = f
    ? [['Leads this week', <CountUp key="a" value={412} />], ['Cost per lead', <CountUp key="b" prefix="$" value={1.84} decimals={2} />], ['Replied in 5 min', '96%'], ['Setup', '2–3 days']]
    : [['Spending limit', 'None'], ['Status', 'Active'], ['Delivery', c.deliveryShort], ['Balance', <CountUp key="c" prefix="$" value={2450} />]];
  return (
    <motion.div initial={reduce ? false : { opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: reduce ? 0 : 0.8, ease }}
      className="relative aspect-[16/9] w-full max-w-[360px] overflow-hidden rounded-2xl border border-white/20 bg-[image:var(--m-board)] p-3.5 text-white shadow-[0_30px_70px_-30px_rgba(0,0,0,.8)] sm:hidden">
      <div className="flex items-center gap-2">
        <span className="grid h-8 w-8 place-items-center rounded-lg bg-white/25">{f ? <Filter size={17} /> : <ShieldCheck size={18} />}</span>
        <span className="text-[17px] font-medium leading-tight">{f ? c.funnel.title : c.account.title}</span>
        <span className="ml-auto inline-flex items-center gap-1 rounded-full bg-white/25 px-2 py-0.5 text-[10px] font-semibold">{f ? <><span className="h-1.5 w-1.5 rounded-full bg-[#4ade80]" />Live</> : <><Check size={10} />Verified</>}</span>
      </div>
      <div className="mt-3 grid grid-cols-2 gap-1.5">
        {tiles.map(([k, val]) => (
          <div key={k} className="rounded-lg bg-white/20 px-2.5 py-1.5"><p className="text-[10px] text-white/80">{k}</p><p className="text-[15px] font-semibold leading-tight">{val}</p></div>
        ))}
      </div>
    </motion.div>
  );
}

function HeroHorizon({ c }: { c: LandingContent }) {
  const anim = useAnim();
  const reduce = useReducedMotion();
  return (
    <section style={{ background: 'var(--m-hero)' }} className="relative isolate overflow-hidden pb-10 pt-[calc(var(--bar-h)+104px)] text-white sm:pt-[calc(var(--bar-h)+136px)]">
      <div className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-[60%] bg-[radial-gradient(rgba(255,255,255,.5)_1px,transparent_1px)] bg-[size:3px_3px] opacity-[.07]" />
      <div className="mx-auto flex max-w-[980px] flex-col items-center px-6 text-center sm:px-8">
        {c.recentOn && <RecentTicker align="center" inline className="mb-6" />}
        <Partner c={c} tone="dark" className="mb-4" />
        <motion.p {...anim(0)} className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-4 py-1.5 text-[12.5px] font-semibold uppercase tracking-[0.18em] text-white/80"><span className="h-1.5 w-1.5 rounded-full bg-[#fb923c]" />{c.badge}</motion.p>
        <motion.h1 {...anim(0.05)} className="mt-6 text-balance text-[38px] font-semibold leading-[1.06] tracking-[-0.035em] sm:text-[62px] lg:text-[70px]">
          {c.headline} <span className="text-[color:var(--m-accent)]">{c.accent}</span>
        </motion.h1>
        <motion.p {...anim(0.12)} className="mt-5 max-w-[50ch] text-[17px] leading-relaxed text-white/75 sm:text-[18px]">{c.sub}</motion.p>
        <Actions c={c} dark className="mt-8" />
      </div>
      <motion.div initial={reduce ? false : { opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: reduce ? 0 : 1, delay: reduce ? 0 : 0.3, ease }}
        className="mx-auto mt-14 flex max-w-[640px] justify-center px-4 [perspective:1400px]">
        <div className="w-full [transform:rotateX(14deg)] [transform-origin:top]">{isF(c) ? <FunnelBoard c={c} tone="dark" /> : <Board c={c} tone="dark" />}</div>
      </motion.div>
    </section>
  );
}

/** Ad-accounts dashboard illustration with two floating cards. */
function Board({ c, tone }: { c: LandingContent; tone: 'dark' | 'light' }) {
  const reduce = useReducedMotion();
  const light = tone === 'light';
  const rows: [string, number][] = [['Agency account 01', 1240], ['Agency account 02', 860.5], ['Agency account 03', 412]];
  const fl = (d: number) => ({ initial: reduce ? false : { opacity: 0, y: 20 }, animate: { opacity: 1, y: 0 }, transition: { duration: reduce ? 0 : 0.9, delay: reduce ? 0 : d, ease } } as const);
  return (
    <div className="relative w-full max-w-[360px] sm:max-w-[520px]">
      <motion.div {...fl(0.1)} className={clsx('relative mx-auto w-[88%] overflow-hidden rounded-2xl', light ? 'border border-edge bg-white shadow-[0_40px_80px_-30px_var(--m-shadow)]' : 'border border-white/20 bg-[color:var(--m-deep)] shadow-[0_40px_90px_-30px_rgba(0,0,0,.8)]')}>
        <div className="bg-[image:var(--m-board)] p-3 text-white sm:p-4">
          <div className="flex items-center gap-2 text-[9px] text-white/90 sm:text-[11px]">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={c.logo} alt="" className="h-5 w-5 rounded-md sm:h-6 sm:w-6" />
            <span className="font-semibold">Ad accounts</span>
            <span className="ml-auto inline-flex items-center gap-1 rounded-full bg-white/25 px-2 py-0.5 font-semibold"><Check size={10} />Verified</span>
          </div>
          <p className="mt-3 text-[9px] font-semibold uppercase tracking-[0.14em] text-white/80 sm:text-[10px]">Placements</p>
          <div className="mt-1.5 flex flex-wrap gap-1 text-[8.5px] font-semibold sm:text-[10px]">
            {['Facebook', 'Instagram', 'Messenger', 'WhatsApp'].map(p => <span key={p} className="rounded-md bg-white/20 px-1.5 py-0.5">{p}</span>)}
          </div>
          <div className="mt-2.5 grid grid-cols-2 gap-1.5 sm:gap-2">
            {[['Ad accounts', '3'], ['Spending limit', 'None'], ['Status', 'Active'], ['Delivery', c.deliveryShort]].map(([k, val]) => (
              <div key={k} className="rounded-lg bg-white/20 px-2 py-1.5"><p className="text-[8px] text-white/80 sm:text-[9.5px]">{k}</p><p className="text-[12px] font-semibold sm:text-[14px]">{val}</p></div>
            ))}
          </div>
        </div>
        <div className={clsx('divide-y px-3 py-1 text-[9px] sm:px-4 sm:text-[11px]', light ? 'divide-edge' : 'divide-white/10')}>
          {rows.map(([n, val]) => (
            <div key={n} className="flex items-center gap-2 py-2"><span className="h-1.5 w-1.5 rounded-full bg-[#22c55e]" /><span className={clsx('flex-1 truncate', light ? 'text-fg' : 'text-white/85')}>{n}</span><span className={light ? 'text-fg-3' : 'text-white/60'}>Approved</span><span className={clsx('w-[58px] text-right tabular-nums sm:w-[70px]', light ? 'text-fg' : 'text-white/85')}><CountUp prefix="$" value={val} decimals={2} /></span></div>
          ))}
        </div>
      </motion.div>
      <motion.div {...fl(0.35)} className={clsx('relative z-[1] -mt-3 ml-auto mr-0 w-[56%] rounded-2xl p-3.5 sm:-mt-4 sm:w-[48%] sm:p-4', light ? 'border border-edge bg-white text-fg shadow-[0_24px_50px_-20px_var(--m-shadow)]' : 'border border-white/25 bg-[linear-gradient(150deg,rgba(255,255,255,.28),rgba(255,255,255,.12))] text-white shadow-[0_24px_50px_-20px_rgba(0,0,0,.6)] backdrop-blur-2xl')}>
        <p className="text-[22px] font-medium tabular-nums tracking-tight sm:text-[28px]"><CountUp prefix="$" value={2450} decimals={2} delay={300} /></p>
        <div className={clsx('mt-1.5 space-y-1 text-[10.5px] sm:text-[12px]', light ? 'text-fg-2' : 'text-white/85')}><p className="flex justify-between"><span>Balance</span><span>USD</span></p><p className="flex justify-between"><span>Last top-up</span><span>$500</span></p></div>
        <div className="mt-2.5 flex gap-1 text-[9px] font-bold sm:text-[10px]">{['USDT', 'UPI'].map(x => <span key={x} className={clsx('rounded px-1.5 py-0.5', light ? 'bg-[color:var(--m-ink)] text-white' : 'bg-white/90 text-[color:var(--m-ink)]')}>{x}</span>)}</div>
      </motion.div>
      <motion.div {...fl(0.5)} className="absolute bottom-3 left-0 z-[1] w-[40%] rounded-xl border border-white/15 bg-[color:var(--m-deep)] p-3 text-white shadow-[0_24px_50px_-20px_rgba(0,0,0,.7)] sm:bottom-5 sm:w-[36%] sm:p-3.5">
        <p className="text-[10px] text-white/70 sm:text-[11.5px]">Delivered within</p><p className="mt-0.5 text-[17px] font-medium sm:text-[20px]">{c.delivery}</p>
      </motion.div>
    </div>
  );
}

/** Funnel dashboard illustration: leads today, the click → form → Telegram → sale pipeline, and a live lead toast. */
function FunnelBoard({ c, tone }: { c: LandingContent; tone: 'dark' | 'light' }) {
  const reduce = useReducedMotion();
  const light = tone === 'light';
  const steps: [string, number][] = [['Ad clicks', 2450], ['Forms filled', 412], ['Telegram chats', 268], ['Sales', 61]];
  const fl = (d: number) => ({ initial: reduce ? false : { opacity: 0, y: 20 }, animate: { opacity: 1, y: 0 }, transition: { duration: reduce ? 0 : 0.9, delay: reduce ? 0 : d, ease } } as const);
  return (
    <div className="relative w-full max-w-[360px] sm:max-w-[520px]">
      <motion.div {...fl(0.1)} className={clsx('relative mx-auto w-[88%] overflow-hidden rounded-2xl', light ? 'border border-edge bg-white shadow-[0_40px_80px_-30px_var(--m-shadow)]' : 'border border-white/20 bg-[color:var(--m-deep)] shadow-[0_40px_90px_-30px_rgba(0,0,0,.8)]')}>
        <div className="bg-[image:var(--m-board)] p-3 text-white sm:p-4">
          <div className="flex items-center gap-2 text-[9px] text-white/90 sm:text-[11px]">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={c.logo} alt="" className="h-5 w-5 rounded-md sm:h-6 sm:w-6" />
            <span className="font-semibold">Lead funnel</span>
            <span className="ml-auto inline-flex items-center gap-1 rounded-full bg-white/25 px-2 py-0.5 font-semibold"><span className="h-1.5 w-1.5 rounded-full bg-[#4ade80]" />Live</span>
          </div>
          <div className="mt-3 grid grid-cols-2 gap-1.5 sm:gap-2">
            {([['Leads this week', 412, ''], ['Cost per lead', 1.84, '$'], ['Replied in 5 min', 96, '%'], ['Setup', 0, '2–3 days']] as [string, number, string][]).map(([k, val, u]) => (
              <div key={k} className="rounded-lg bg-white/20 px-2 py-1.5"><p className="text-[8px] text-white/80 sm:text-[9.5px]">{k}</p><p className="text-[12px] font-semibold sm:text-[14px]">{val ? (u === '$' ? <CountUp prefix="$" value={val} decimals={2} /> : <CountUp value={val} suffix={u} />) : u}</p></div>
            ))}
          </div>
        </div>
        <div className={clsx('space-y-2 px-3 py-3 text-[9px] sm:px-4 sm:text-[11px]')}>
          {steps.map(([n, val], i) => (
            <div key={n}>
              <div className="flex items-center justify-between"><span className={light ? 'text-fg' : 'text-white/85'}>{n}</span><span className={clsx('tabular-nums', light ? 'text-fg' : 'text-white/85')}><CountUp value={val} /></span></div>
              <div className={clsx('mt-1 h-1.5 overflow-hidden rounded-full', light ? 'bg-violet/10' : 'bg-white/10')}><div className="h-full rounded-full bg-[image:var(--m-grad)]" style={{ width: `${[100, 62, 42, 22][i]}%` }} /></div>
            </div>
          ))}
        </div>
      </motion.div>
      <motion.div {...fl(0.35)} className={clsx('relative z-[1] -mt-3 ml-auto mr-0 w-[60%] rounded-2xl p-3.5 sm:-mt-4 sm:w-[52%] sm:p-4', light ? 'border border-edge bg-white text-fg shadow-[0_24px_50px_-20px_var(--m-shadow)]' : 'border border-white/25 bg-[linear-gradient(150deg,rgba(255,255,255,.28),rgba(255,255,255,.12))] text-white shadow-[0_24px_50px_-20px_rgba(0,0,0,.6)] backdrop-blur-2xl')}>
        <p className="flex items-center gap-2 text-[11px] font-semibold sm:text-[12.5px]"><span className="grid h-6 w-6 place-items-center rounded-full bg-[#229ED9] text-white"><Bell size={13} /></span>New lead · just now</p>
        <p className="mt-2 text-[15px] font-medium sm:text-[17px]">Amit K. · Pune</p>
        <p className={clsx('mt-0.5 text-[10.5px] sm:text-[12px]', light ? 'text-fg-2' : 'text-white/80')}>Wants a callback · Budget $2,000/mo</p>
      </motion.div>
      <motion.div {...fl(0.5)} className="absolute bottom-3 left-0 z-[1] w-[40%] rounded-xl border border-white/15 bg-[color:var(--m-deep)] p-3 text-white shadow-[0_24px_50px_-20px_rgba(0,0,0,.7)] sm:bottom-5 sm:w-[36%] sm:p-3.5">
        <p className="text-[10px] text-white/70 sm:text-[11.5px]">Sales this week</p><p className="mt-0.5 text-[17px] font-medium sm:text-[20px]"><CountUp prefix="$" value={2450} delay={300} /></p>
      </motion.div>
    </div>
  );
}

/* ---------------- sections ---------------- */
function Provide({ c }: { c: LandingContent }) {
  const v = useV();
  return (
    <section id="provide" className={clsx('scroll-mt-20 bg-void py-20 sm:py-28', v === 'chat' && 'pt-16')}>
      <div className="mx-auto max-w-[1200px] px-6 sm:px-8">
        <Reveal className={center(v)}>
          <Eyebrow>What we provide</Eyebrow>
          <H2 className="mt-4">{isF(c) ? 'Lead funnels, and ad accounts to run them' : 'Ad accounts and services we provide'}</H2>
          <div className={clsx('mt-7 flex flex-wrap gap-2', v !== 'chat' && 'justify-center')}>
            {(isF(c) ? ['Landing page', 'Lead form', 'Telegram routing', 'Agent app', 'Conversions API'] : ['Facebook', 'Instagram', 'Messenger', 'WhatsApp', 'Audience Network']).map(p => <span key={p} className="rounded-full border border-edge bg-plum-2 px-4 py-2 text-[13.5px] font-medium text-fg-2">{p}</span>)}
          </div>
        </Reveal>
        <div className={clsx('mt-14 grid gap-6 md:grid-cols-2', v === 'chat' ? 'max-w-none' : 'mx-auto max-w-[980px]')}>
          <OfferCard o={offers(c)[0][0]} service={offers(c)[0][1]} featured />
          <OfferCard o={offers(c)[1][0]} service={offers(c)[1][1]} />
        </div>
      </div>
    </section>
  );
}

function OfferCard({ o, service, featured }: { o: Offer; service: 'account' | 'funnel'; featured?: boolean }) {
  const v = useV();
  const pill = usePill();
  return (
    <Reveal className={clsx('relative flex flex-col overflow-hidden p-8 sm:p-10', radius(v), featured ? 'bg-[image:var(--m-card)] text-white shadow-[0_40px_80px_-40px_var(--m-shadow)]' : 'border border-edge bg-plum text-fg shadow-[0_30px_60px_-40px_var(--m-shadow)]')}>
      {featured && <div className="pointer-events-none absolute -bottom-24 -right-20 h-64 w-64 rounded-full bg-[radial-gradient(closest-side,var(--m-cardglow),transparent)]" />}
      <p className={clsx('text-[12px] font-semibold uppercase tracking-[0.2em]', featured ? 'text-[#ffe4d6]' : 'text-violet')}>{o.badge}</p>
      <h3 className={clsx('mt-3 text-[26px] tracking-[-0.01em]', v === 'stage' || v === 'horizon' ? 'font-normal' : 'font-semibold')}>{o.title}</h3>
      <p className={clsx('mt-2 text-[15px] leading-relaxed', featured ? 'text-white/75' : 'text-fg-2')}>{o.sub}</p>
      <p className="mt-7 flex items-baseline gap-2"><span className={clsx('text-[54px] leading-none tracking-[-0.03em]', v === 'stage' || v === 'horizon' ? 'font-light' : 'font-bold')}><CountUp prefix="$" value={o.price} /></span><span className={clsx('text-[15px]', featured ? 'text-white/70' : 'text-fg-3')}>{o.unit}</span></p>
      <ul className="mt-7 space-y-3">
        {o.bullets.map(b => (
          <li key={b} className={clsx('flex gap-3 text-[15px]', featured ? 'text-white/90' : 'text-fg-2')}>
            <span className={clsx('mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full', featured ? 'bg-white/20' : 'bg-violet/10 text-violet')}><Check size={12} strokeWidth={3} /></span>{b}
          </li>
        ))}
      </ul>
      <LeadButton service={service} className={clsx(pill(featured ? 'white' : 'outline'), 'relative mt-9 w-full')}>{o.cta}</LeadButton>
    </Reveal>
  );
}

function Audience({ c }: { c: LandingContent }) {
  const v = useV();
  const cards = audienceFor(c);
  return (
    <section className={clsx('py-20 sm:py-28', v === 'chat' ? 'bg-void' : 'bg-plum-2')}>
      <div className="mx-auto max-w-[1200px] px-6 sm:px-8">
        <Reveal className={center(v)}><Eyebrow>Who it&apos;s for</Eyebrow><H2 className="mt-4">{isF(c) ? 'For every business that runs Meta ads' : 'Made for people who scale ads'}</H2></Reveal>
        <div className={clsx('mt-12 grid gap-6 md:grid-cols-2', v !== 'chat' && 'mx-auto max-w-[980px]')}>
          {cards.map(({ icon: I, t, d }, i) => (
            <Reveal key={t} delay={i * 0.08} className={clsx('border border-edge p-8 sm:p-10', radius(v), v === 'chat' ? 'bg-plum-2' : 'bg-plum')}>
              <span className={clsx('grid h-12 w-12 place-items-center bg-[image:var(--m-grad)] text-white', v === 'chat' ? 'rounded-full' : 'rounded-2xl')}><I size={22} /></span>
              <h3 className={clsx('mt-6 text-[24px] text-fg', v === 'stage' || v === 'horizon' ? 'font-normal' : 'font-semibold')}>{t}</h3>
              <p className="mt-3 text-[15.5px] leading-relaxed text-fg-2">{d}</p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function Steps({ c }: { c: LandingContent }) {
  const v = useV();
  const pill = usePill();
  const steps = stepsFor(c);
  return (
    <section id="steps" className={clsx('scroll-mt-20 py-20 sm:py-28', v === 'horizon' ? 'bg-plum' : 'bg-void')}>
      <div className="mx-auto max-w-[1200px] px-6 sm:px-8">
        <Reveal className={center(v)}><Eyebrow>How it works</Eyebrow><H2 className="mt-4">{isF(c) ? 'Your funnel, live in three steps' : 'Get your agency account in three steps'}</H2></Reveal>
        {v === 'card' || v === 'chat' ? (
          <div className="mt-12 grid gap-5 md:grid-cols-3">
            {steps.map(({ t, d }, i) => (
              <Reveal key={t} delay={i * 0.08} className={clsx('relative overflow-hidden border border-edge p-7', radius(v), v === 'chat' ? 'bg-plum-2' : 'bg-plum shadow-[0_20px_50px_-35px_var(--m-shadow)]')}>
                <span className={clsx('block font-bold leading-none tracking-[-0.05em] text-transparent [-webkit-text-stroke:1.5px_rgb(var(--p))]', v === 'chat' ? 'text-[72px]' : 'text-[56px]')}>0{i + 1}</span>
                <h3 className="mt-5 text-[20px] font-semibold text-fg">{t}</h3>
                <p className="mt-2 text-[15px] leading-relaxed text-fg-2">{d}</p>
              </Reveal>
            ))}
          </div>
        ) : (
          <div className="mt-14 grid gap-10 md:grid-cols-3 md:gap-6">
            {steps.map(({ t, d }, i) => (
              <Reveal key={t} delay={i * 0.08} className="relative flex flex-col items-center text-center">
                <span className="grid h-16 w-16 place-items-center rounded-full bg-[image:var(--m-step)] text-[24px] font-light text-white shadow-[0_16px_34px_-14px_var(--m-shadow)]">{i + 1}</span>
                {i < steps.length - 1 && <ArrowRight aria-hidden size={26} strokeWidth={1.5} className="absolute -right-6 top-5 hidden text-violet/40 md:block" />}
                <h3 className="mt-6 text-[21px] font-normal text-fg">{t}</h3>
                <p className="mt-2.5 max-w-[32ch] text-[15px] leading-relaxed text-fg-2">{d}</p>
              </Reveal>
            ))}
          </div>
        )}
        <Reveal className={clsx('mt-12 flex', v === 'chat' ? '' : 'justify-center')}><LeadButton className={pill('brand')}>Get started<ArrowRight size={16} /></LeadButton></Reveal>
      </div>
    </section>
  );
}

function Why({ c }: { c: LandingContent }) {
  const v = useV();
  const rows = whyFor(c);
  if (v === 'card') return (
    <section id="why" className="scroll-mt-20 bg-void py-20 sm:py-28">
      <div className="mx-auto max-w-[1200px] px-6 sm:px-8">
        <Reveal className={center(v)}><Eyebrow>Why {c.brand}</Eyebrow><H2 className="mt-4">{c.whyTitle}</H2></Reveal>
        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {rows.map(({ icon: I, t, d }, i) => (
            <Reveal key={t} delay={i * 0.04} className={clsx('rounded-2xl border border-edge bg-plum-2 p-6', i === 0 && 'lg:col-span-2 lg:row-span-1 bg-[image:var(--m-card)] text-white')}>
              <I size={24} className={i === 0 ? 'text-white' : 'text-violet'} />
              <h3 className={clsx('mt-4 text-[19px] font-semibold', i === 0 ? 'text-white' : 'text-fg')}>{t}</h3>
              <p className={clsx('mt-1.5 text-[15px] leading-relaxed', i === 0 ? 'text-white/80' : 'text-fg-2')}>{d}</p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
  if (v === 'chat') return (
    <section id="why" className="scroll-mt-20 bg-void py-20 sm:py-28">
      <div className="mx-auto max-w-[1200px] px-6 sm:px-8">
        <Reveal className={center(v)}><Eyebrow>Why {c.brand}</Eyebrow><H2 className="mt-4">{c.whyTitle}</H2></Reveal>
        <ol className="mt-12 divide-y divide-edge border-y border-edge">
          {rows.map(({ t, d }, i) => (
            <Reveal key={t} delay={i * 0.04}>
              <li className="grid list-none grid-cols-[52px_1fr] gap-x-4 py-7 sm:grid-cols-[90px_1fr_1.2fr] sm:items-baseline">
                <span className="text-[30px] font-semibold tracking-[-0.04em] text-violet sm:text-[40px]">0{i + 1}</span>
                <span className="text-[20px] font-semibold text-fg sm:text-[22px]">{t}</span>
                <span className="col-start-2 mt-1.5 text-[15px] leading-relaxed text-fg-2 sm:col-start-3 sm:mt-0">{d}</span>
              </li>
            </Reveal>
          ))}
        </ol>
      </div>
    </section>
  );
  return (
    <section id="why" className={clsx('scroll-mt-20 border-t border-edge py-20 sm:py-28', v === 'horizon' ? 'bg-void' : 'bg-void')}>
      <div className="mx-auto grid max-w-[1200px] gap-12 px-6 sm:px-8 lg:grid-cols-[.85fr_1.15fr] lg:gap-20">
        <Reveal><Eyebrow>Why {c.brand}</Eyebrow><H2 className="mt-4 max-w-[14ch]">{c.whyTitle}</H2></Reveal>
        <div className="grid gap-x-10 gap-y-9 sm:grid-cols-2">
          {rows.map(({ icon: I, t, d }, i) => (
            <Reveal key={t} delay={i * 0.04} className="flex gap-4">
              <I size={24} strokeWidth={1.6} className={clsx('mt-0.5 shrink-0', v === 'horizon' ? 'text-lilac' : 'text-violet')} />
              <span><span className="block text-[18px] font-medium text-fg">{t}</span><span className="mt-1.5 block text-[15px] leading-relaxed text-fg-2">{d}</span></span>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function Band({ c }: { c: LandingContent }) {
  const v = useV();
  const pill = usePill();
  return (
    <section className={clsx('bg-void px-4 pb-4 sm:px-6 sm:pb-6', v === 'card' && 'pt-4')}>
      <div style={{ background: 'var(--m-band)' }} className={clsx('relative isolate mx-auto max-w-[1240px] overflow-hidden px-6 py-20 text-white sm:py-24', v === 'card' ? 'rounded-3xl' : v === 'chat' ? 'rounded-[40px] text-left sm:px-14' : 'rounded-[32px] text-center')}>
        <h2 className={clsx('max-w-[20ch] text-balance text-[32px] leading-[1.12] sm:text-[48px]', v === 'stage' || v === 'horizon' ? 'mx-auto font-light' : 'font-semibold tracking-[-0.03em]', v === 'card' && 'mx-auto text-center')}>{c.ctaTitle}</h2>
        <p className={clsx('mt-5 max-w-[46ch] text-[17px] text-white/85', v !== 'chat' && 'mx-auto', v === 'card' && 'text-center')}>{c.ctaText}</p>
        <div className={clsx('mt-10 flex flex-col gap-4 sm:flex-row', v === 'chat' ? 'items-start' : 'items-center justify-center')}>
          {isF(c) ? <>
            <LeadButton service="funnel" className={pill('white')}>{c.funnel.cta} · ${c.priceFunnel}/mo</LeadButton>
            <LeadButton service="account" className={pill('outline-white')}>{c.account.cta} · ${c.priceAccount}</LeadButton>
          </> : <>
            <LeadButton service="account" className={pill('white')}>{c.account.cta} · ${c.priceAccount}</LeadButton>
            <LeadButton service="funnel" className={pill('outline-white')}>{c.funnel.cta} · ${c.priceFunnel}/mo</LeadButton>
          </>}
        </div>
      </div>
    </section>
  );
}

function Faq({ c }: { c: LandingContent }) {
  const v = useV();
  if (!c.faq.length) return null;
  const list = (
    <div className={clsx(v === 'card' ? 'space-y-3' : 'divide-y divide-edge border-y border-edge')}>
      {c.faq.map(([q, a], i) => (
        <details key={q + i} className={clsx('group', v === 'card' && 'rounded-2xl border border-edge bg-plum px-5')}>
          <summary className="flex cursor-pointer list-none items-center justify-between gap-5 py-5 text-[17px] font-medium text-fg [&::-webkit-details-marker]:hidden sm:py-6">
            {q}<span className="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-edge text-violet transition-transform group-open:rotate-45"><Plus size={18} /></span>
          </summary>
          <p className="pb-6 pr-12 text-[15.5px] leading-relaxed text-fg-2">{a}</p>
        </details>
      ))}
    </div>
  );
  return (
    <section id="faq" className={clsx('scroll-mt-20 py-20 sm:py-28', v === 'card' ? 'bg-plum-2' : 'bg-void')}>
      {v === 'chat' ? (
        <div className="mx-auto grid max-w-[1200px] gap-10 px-6 sm:px-8 lg:grid-cols-[.8fr_1.2fr]">
          <Reveal><Eyebrow>FAQ</Eyebrow><H2 className="mt-4">Questions, answered</H2></Reveal>
          {list}
        </div>
      ) : (
        <div className="mx-auto max-w-[820px] px-6 sm:px-8">
          <Reveal className="text-center"><Eyebrow>FAQ</Eyebrow><H2 className="mt-4">Frequently asked questions</H2></Reveal>
          <div className="mt-12">{list}</div>
        </div>
      )}
    </section>
  );
}

export function Footer({ c }: { c: LandingContent }) {
  const v = useV();
  const light = v === 'card';
  return (
    <footer className={light ? 'bg-[color:var(--m-foot)] text-fg-2' : 'bg-[color:var(--m-foot)] text-white/70'}>
      <div className="mx-auto flex max-w-[1200px] flex-col gap-8 px-6 py-14 sm:flex-row sm:items-start sm:justify-between sm:px-8">
        <div><Wordmark c={c} light={!light} /><p className="mt-4 max-w-[36ch] text-[14px] leading-relaxed">{c.footer}</p>{c.partner && <p className={clsx('mt-4 inline-flex items-center gap-2 text-[13.5px] font-semibold', light ? 'text-fg' : 'text-white')}><span className="grid h-5 w-5 place-items-center rounded-full bg-[#0866ff] text-white"><BadgeCheck size={13} strokeWidth={2.4} /></span>{c.partner}</p>}</div>
        <div className="flex flex-col gap-3 text-[14px]">
          {c.premiumOn && (c.tier === 'premium' ? <a href="/" className={light ? 'hover:text-fg' : 'hover:text-white'}>Standard ad accounts</a> : <a href="/premium" className={light ? 'hover:text-fg' : 'hover:text-white'}>Premium ad accounts</a>)}
          {[['/products', 'All products'], ['/pricing', 'Prices'], ['/top-up', 'Ad account top-up'], ['/how-it-works', 'How to order'], ['/faq', 'Help & FAQ'], ['/contact', 'Contact'], ['/terms', 'Terms'], ['/refund-policy', 'Refund & Replacement'], ['/privacy', 'Privacy']].map(([h, l]) => <a key={h} href={h} className={light ? 'hover:text-fg' : 'hover:text-white'}>{l}</a>)}
          {c.webOn && <a href="/account" className={light ? 'hover:text-fg' : 'hover:text-white'}>My account · Top up</a>}
          <a href="/telegram" className={clsx('inline-flex items-center gap-2', light ? 'hover:text-fg' : 'hover:text-white')}><TgIcon size={16} />Telegram channel</a>
        </div>
      </div>
      <p className={clsx('border-t px-6 py-6 text-center text-[13px]', light ? 'border-edge text-fg-3' : 'border-white/10 text-white/50')}>© {new Date().getFullYear()} {c.brand}</p>
    </footer>
  );
}

/* =====================================================================================
   BLUE & WHITE — "Card": a bank-card style account visual, tier cards, timeline, stat tiles
   ===================================================================================== */
function HeroCard({ c }: { c: LandingContent }) {
  const anim = useAnim();
  return (
    <section style={{ background: 'var(--m-hero)' }} className="relative overflow-hidden pb-16 pt-[calc(var(--bar-h)+96px)] sm:pb-24 sm:pt-[calc(var(--bar-h)+124px)]">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(rgb(var(--p)/.16)_1px,transparent_1px)] bg-[size:18px_18px] [mask-image:radial-gradient(ellipse_55%_45%_at_80%_20%,#000,transparent)]" />
      <div className="relative mx-auto grid max-w-[1200px] items-center gap-14 px-6 sm:px-8 lg:grid-cols-[1.05fr_1fr]">
        <div className="min-w-0">
          {c.recentOn && <RecentTicker align="left" inline className="mb-5" />}
          <div className="flex flex-wrap gap-2">
            <Partner c={c} tone="light" />
            <motion.p {...anim(0)} className="inline-flex items-center gap-2 rounded-full border border-edge bg-white px-3.5 py-1.5 text-[13px] font-semibold text-fg-2 shadow-sm"><span className="h-2 w-2 rounded-full bg-mint" />{c.badge}</motion.p>
          </div>
          <motion.h1 {...anim(0.05)} className="mt-5 text-balance text-[38px] font-bold leading-[1.04] tracking-[-0.045em] text-fg sm:text-[58px] lg:text-[62px]">
            {c.headline} <span className="text-violet">{c.accent}</span>
          </motion.h1>
          <motion.p {...anim(0.12)} className="mt-5 max-w-[48ch] text-[17px] leading-relaxed text-fg-2 sm:text-[18px]">{c.sub}</motion.p>
          <Actions c={c} dark={false} className="mt-7" />
          <motion.div {...anim(0.3)} className="mt-7 grid max-w-[460px] grid-cols-3 divide-x divide-edge rounded-2xl border border-edge bg-white text-center shadow-sm">
            {(isF(c) ? [['2–3d', 'Setup'], ['24/7', 'Lead capture'], ['$' + c.priceFunnel, 'Per month']] : [[c.deliveryShort, 'Delivery'], ['No', 'Spend limit'], ['7 days', 'Support']]).map(([a, b]) => (
              <div key={b} className="px-2 py-3"><p className="text-[18px] font-bold tracking-tight text-fg">{a}</p><p className="text-[12px] text-fg-3">{b}</p></div>
            ))}
          </motion.div>
        </div>
        {isF(c) ? <div className="mx-auto w-full max-w-[480px] py-6"><FunnelBoard c={c} tone="light" /></div> : <AccountCards c={c} />}
      </div>
    </section>
  );
}

/** Two stacked "ad account" cards (like bank cards) with notification toasts. */
function AccountCards({ c }: { c: LandingContent }) {
  const reduce = useReducedMotion();
  const fl = (d: number, x = 0) => ({ initial: reduce ? false : { opacity: 0, y: 24, x }, animate: { opacity: 1, y: 0, x: 0 }, transition: { duration: reduce ? 0 : 0.9, delay: reduce ? 0 : d, ease } } as const);
  return (
    <div className="relative mx-auto w-full max-w-[420px] pb-20 pt-12 sm:max-w-[480px]">
      <motion.div {...fl(0.05)} className="absolute inset-x-6 top-4 aspect-[1.6] rotate-[7deg] rounded-[26px] bg-[linear-gradient(135deg,#bcd7ff,#e3eeff)] shadow-[0_30px_60px_-30px_var(--m-shadow)]" />
      <motion.div {...fl(0.15)} className="relative aspect-[1.6] -rotate-[4deg] overflow-hidden rounded-[26px] bg-[image:var(--m-card)] p-5 text-white shadow-[0_40px_80px_-30px_var(--m-shadow)] sm:p-7">
        <div className="pointer-events-none absolute -right-16 -top-20 h-56 w-56 rounded-full bg-white/10" />
        <div className="pointer-events-none absolute -bottom-24 right-10 h-56 w-56 rounded-full bg-white/[0.06]" />
        <div className="relative flex items-center justify-between">
          <span className="flex items-center gap-2 text-[14px] font-semibold">{/* eslint-disable-next-line @next/next/no-img-element */}<img src={c.logo} alt="" className="h-7 w-7 rounded-lg" />{c.brand}{c.verified && <VerifiedTick className="-ml-1 h-4 w-4" />}</span>
          <span className="text-[11px] font-semibold uppercase tracking-[0.18em] text-white/70">Agency account</span>
        </div>
        <div className="relative mt-5 h-8 w-11 rounded-md bg-[linear-gradient(135deg,#fde68a,#f59e0b)] shadow-inner sm:mt-7 sm:h-9 sm:w-12" />
        <p className="relative mt-4 font-mono text-[15px] tracking-[0.18em] text-white/85 sm:mt-6 sm:text-[17px]">act_ •••• •••• 2189</p>
        <div className="relative mt-3 flex items-end justify-between sm:mt-5">
          <div><p className="text-[11px] uppercase tracking-[0.14em] text-white/60">Balance</p><p className="text-[24px] font-bold tracking-tight sm:text-[30px]"><CountUp prefix="$" value={2450} decimals={2} delay={300} /></p></div>
          <p className="text-right text-[12px] font-semibold text-white/80">Meta Ads<br /><span className="text-white/60">USD</span></p>
        </div>
      </motion.div>
      <motion.div {...fl(0.45, 20)} className="absolute -right-2 top-0 flex items-center gap-2.5 rounded-2xl border border-edge bg-white px-3.5 py-2.5 text-[12.5px] shadow-[0_20px_40px_-20px_var(--m-shadow)] sm:-right-6">
        <span className="grid h-7 w-7 place-items-center rounded-full bg-mint/15 text-mint"><Check size={15} strokeWidth={3} /></span>
        <span><b className="block text-fg">Shared to your BM</b><span className="text-fg-3">just now</span></span>
      </motion.div>
      <motion.div {...fl(0.6, -20)} className="absolute -left-1 bottom-2 flex items-center gap-2.5 rounded-2xl border border-edge bg-white px-3.5 py-2.5 text-[12.5px] shadow-[0_20px_40px_-20px_var(--m-shadow)] sm:-left-6">
        <span className="grid h-7 w-7 place-items-center rounded-full bg-violet/10 text-violet"><Wallet size={15} /></span>
        <span><b className="block text-fg">Top-up received</b><span className="text-mint">+<CountUp prefix="$" value={500} delay={600} /></span></span>
      </motion.div>
    </div>
  );
}

function CardHead({ eyebrow, title, className }: { eyebrow: string; title: string; className?: string }) {
  return <Reveal className={clsx('mx-auto max-w-[720px] text-center', className)}><Eyebrow>{eyebrow}</Eyebrow><H2 className="mt-4">{title}</H2></Reveal>;
}

function CardPlans({ c }: { c: LandingContent }) {
  const pill = usePill();
  const plans: [Offer, 'account' | 'funnel', boolean][] = offers(c).map(([o, s], i) => [o, s, i === 0]);
  return (
    <section id="provide" className="scroll-mt-24 bg-void py-20 sm:py-28">
      <div className="mx-auto max-w-[1100px] px-6 sm:px-8">
        <CardHead eyebrow="Pricing" title="Simple pricing, no surprises" />
        <div className="mt-14 grid gap-6 md:grid-cols-2">
          {plans.map(([o, svc, hot]) => (
            <Reveal key={svc} className={clsx('relative flex flex-col rounded-3xl border bg-white p-8 sm:p-9', hot ? 'border-violet shadow-[0_30px_70px_-35px_var(--m-shadow)] ring-4 ring-violet/10' : 'border-edge')}>
              {hot && <span className="absolute -top-3.5 left-8 rounded-full bg-violet px-3.5 py-1 text-[12px] font-bold text-white">{o.badge}</span>}
              <div className="flex items-center gap-3">
                <span className={clsx('grid h-11 w-11 place-items-center rounded-xl', hot ? 'bg-violet text-white' : 'bg-violet/10 text-violet')}>{(svc === 'funnel') ? <Filter size={21} /> : <ShieldCheck size={21} />}</span>
                <div><h3 className="text-[19px] font-semibold text-fg">{o.title}</h3>{!hot && <p className="text-[12.5px] font-medium text-fg-3">{o.badge}</p>}</div>
              </div>
              <p className="mt-6 flex items-baseline gap-2"><span className="text-[52px] font-bold leading-none tracking-[-0.04em] text-fg"><CountUp prefix="$" value={o.price} /></span><span className="text-[15px] text-fg-3">{o.unit}</span></p>
              <p className="mt-3 text-[15px] text-fg-2">{o.sub}</p>
              <div className="my-7 h-px bg-edge" />
              <ul className="space-y-3">{o.bullets.map(b => <li key={b} className="flex gap-3 text-[15px] text-fg-2"><Check size={18} className="mt-0.5 shrink-0 text-violet" strokeWidth={2.5} />{b}</li>)}</ul>
              <LeadButton service={svc} className={clsx(pill(hot ? 'brand' : 'outline'), 'mt-9 w-full')}>{o.cta}</LeadButton>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function CardSteps({ c }: { c: LandingContent }) {
  const pill = usePill();
  const steps = stepsFor(c).map((x, i) => ({ ...x, icon: [MessageCircle, isF(c) ? Filter : Wallet, Rocket][i] }));
  return (
    <section id="steps" className="scroll-mt-24 bg-plum-2 py-20 sm:py-28">
      <div className="mx-auto grid max-w-[1100px] gap-12 px-6 sm:px-8 lg:grid-cols-[.9fr_1.1fr]">
        <Reveal><Eyebrow>How it works</Eyebrow><H2 className="mt-4">{isF(c) ? 'Three steps to a live funnel' : 'Three steps to a live account'}</H2><p className="mt-4 max-w-[38ch] text-[16px] text-fg-2">{isF(c) ? 'Most funnels are live within the same week.' : 'Most customers are advertising the same day.'}</p><LeadButton className={clsx(pill('brand'), 'mt-8 hidden lg:inline-flex')}>Get started<ArrowRight size={16} /></LeadButton></Reveal>
        <ol className="relative">
          <span aria-hidden className="absolute bottom-8 left-[23px] top-8 w-[2px] bg-[linear-gradient(rgb(var(--p)),rgb(var(--p)/.15))]" />
          {steps.map(({ icon: I, t, d }, i) => (
            <Reveal key={t} delay={i * 0.08}>
              <li className="relative flex list-none gap-5 pb-10 last:pb-0">
                <span className="relative z-[1] grid h-12 w-12 shrink-0 place-items-center rounded-full border-4 border-[rgb(var(--s2))] bg-violet text-white"><I size={20} /></span>
                <div className="rounded-2xl border border-edge bg-white p-5 shadow-sm"><p className="text-[12px] font-bold uppercase tracking-[0.14em] text-violet">Step {i + 1}</p><h3 className="mt-1 text-[19px] font-semibold text-fg">{t}</h3><p className="mt-1.5 text-[15px] leading-relaxed text-fg-2">{d}</p></div>
              </li>
            </Reveal>
          ))}
        </ol>
      </div>
    </section>
  );
}

function CardWhy({ c }: { c: LandingContent }) {
  const tiles: [ReactNode, string][] = isF(c) ? [
    ['2–3d', 'from your brief to a live funnel'],
    [<CountUp key="p" prefix="$" value={c.priceFunnel} />, 'per month, hosting and apps included'],
    ['24/7', 'leads delivered to Telegram in seconds'],
  ] : [
    [c.deliveryShort, 'from payment to live account'],
    [<CountUp key="p" prefix="$" value={c.priceAccount} />, 'per agency ad account'],
    ['7 days', 'a week, Telegram support from your agent'],
  ];
  const rows = isF(c) ? whyFor(c).slice(1).map(r => [r.t, r.d]) : [
    ['One agent, start to finish', 'The person who sells you the account supports it after launch.'],
    ['Top-ups in the same chat', 'Add funds through your agent without placing a new order.'],
    ['No Business Manager yet?', 'We walk you through creating one. It is free and takes minutes.'],
    ['Clear pricing', `$${c.priceAccount} per account. Top-ups go through us${Number(c.topupFee) ? ` for a ${c.topupFee}% fee` : ''}, so you save the 18% GST.`],
  ];
  return (
    <section id="why" className="scroll-mt-24 bg-void py-20 sm:py-28">
      <div className="mx-auto max-w-[1100px] px-6 sm:px-8">
        <CardHead eyebrow={`Why ${c.brand}`} title={c.whyTitle} />
        <div className="mt-12 grid gap-4 sm:grid-cols-3">
          {tiles.map(([n, l], i) => (
            <Reveal key={l} delay={i * 0.06} className={clsx('rounded-3xl p-7', i === 0 ? 'bg-[image:var(--m-card)] text-white' : 'border border-edge bg-plum-2')}>
              <p className={clsx('text-[46px] font-bold leading-none tracking-[-0.04em]', i === 0 ? 'text-white' : 'text-violet')}>{n}</p>
              <p className={clsx('mt-3 text-[15px]', i === 0 ? 'text-white/80' : 'text-fg-2')}>{l}</p>
            </Reveal>
          ))}
        </div>
        <div className="mt-10 grid gap-x-10 gap-y-6 sm:grid-cols-2">
          {rows.map(([t, d], i) => (
            <Reveal key={t} delay={i * 0.04} className="flex gap-4">
              <span className="mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-full bg-violet/10 text-violet"><Check size={15} strokeWidth={3} /></span>
              <span><b className="block text-[17px] font-semibold text-fg">{t}</b><span className="mt-1 block text-[15px] leading-relaxed text-fg-2">{d}</span></span>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function CardFaq({ c }: { c: LandingContent }) {
  if (!c.faq.length) return null;
  return (
    <section id="faq" className="scroll-mt-24 bg-plum-2 py-20 sm:py-28">
      <div className="mx-auto max-w-[1100px] px-6 sm:px-8">
        <CardHead eyebrow="FAQ" title="Frequently asked questions" />
        <div className="mt-12 grid items-start gap-4 md:grid-cols-2">
          {c.faq.map(([q, a], i) => (
            <details key={q + i} className="group rounded-2xl border border-edge bg-white px-5 open:shadow-[0_20px_40px_-30px_var(--m-shadow)]">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-4 py-5 text-[16px] font-semibold text-fg [&::-webkit-details-marker]:hidden">
                {q}<span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-violet/10 text-violet transition-transform group-open:rotate-45"><Plus size={17} /></span>
              </summary>
              <p className="pb-5 text-[15px] leading-relaxed text-fg-2">{a}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}

/* =====================================================================================
   GREEN & WHITE — "Chat": a phone with the real Telegram conversation, ticket-style pricing,
   chat-bubble steps, a dark-green "why" strip and a lime call-to-action band
   ===================================================================================== */
function HeroChat({ c }: { c: LandingContent }) {
  const anim = useAnim();
  return (
    <section style={{ background: 'var(--m-hero)' }} className="relative isolate overflow-hidden pb-16 pt-[calc(var(--bar-h)+92px)] sm:pb-24 sm:pt-[calc(var(--bar-h)+120px)]">
      <div className="pointer-events-none absolute -right-32 top-10 -z-10 h-[420px] w-[420px] rounded-full bg-[#86efac]/50 blur-3xl" />
      <div className="pointer-events-none absolute -left-40 bottom-0 -z-10 h-[380px] w-[380px] rounded-full bg-[#d9f99d]/70 blur-3xl" />
      <div className="mx-auto grid max-w-[1200px] items-center gap-12 px-6 sm:px-8 lg:grid-cols-[1.1fr_.9fr]">
        <div className="min-w-0">
          {c.recentOn && <RecentTicker align="left" inline className="mb-5" />}
          <Partner c={c} tone="green" className="mb-5" />
          <motion.h1 {...anim(0.05)} className="text-balance text-[42px] font-extrabold leading-[0.98] tracking-[-0.05em] text-fg sm:text-[68px] lg:text-[76px]">
            {c.headline} <span className="bg-[linear-gradient(transparent_58%,#c6f36b_58%,#c6f36b_92%,transparent_92%)] px-1">{c.accent}</span>
          </motion.h1>
          <motion.p {...anim(0.12)} className="mt-6 max-w-[46ch] text-[17px] leading-relaxed text-fg-2 sm:text-[19px]">{c.sub}</motion.p>
          <Actions c={c} dark={false} className="mt-8" />
        </div>
        <Phone c={c} />
      </div>
    </section>
  );
}

/** Phone with the Telegram chat that every customer actually goes through. */
function Phone({ c }: { c: LandingContent }) {
  const reduce = useReducedMotion();
  const F = isF(c);
  const msgs: { me?: boolean; t: ReactNode }[] = F ? [
    { me: true, t: 'Hi! I want a landing page and funnel ' },
    { t: <>Hi! It&apos;s <b><CountUp prefix="$" value={c.priceFunnel} /></b> a month: page, lead form, Telegram routing and tracking. What do you sell?</> },
    { me: true, t: 'Home loans in Pune' },
    { t: 'Perfect. Your funnel goes live in 2 to 3 days ' },
  ] : [
    { me: true, t: 'Hi! I want an agency ad account ' },
    { t: <>Hi! It&apos;s <b><CountUp prefix="$" value={c.priceTg} /></b> per account. Please send your Business Manager ID.</> },
    { me: true, t: 'BM ID: 1784 •••• ••••' },
    { t: 'Payment received Sharing it now.' },
  ];
  return (
    <div className="relative mx-auto w-full max-w-[330px]">
      <div className="absolute -left-8 top-16 z-10 grid h-24 w-24 -rotate-12 place-items-center rounded-full bg-[#c6f36b] text-center text-[12px] font-extrabold uppercase leading-tight text-[#052e16] shadow-xl">Live in<br /><span className="text-[22px] normal-case">{F ? '2–3d' : c.deliveryShort}</span></div>
      <div className="rounded-[46px] bg-[#0b1f14] p-2.5 shadow-[0_50px_90px_-40px_rgba(5,46,22,.7)]">
        <div className="overflow-hidden rounded-[38px] bg-[#e7f5ea]">
          <div className="flex items-center gap-3 bg-[#14532d] px-4 pb-3 pt-6 text-white">
            <span className="grid h-9 w-9 place-items-center rounded-full bg-[#c6f36b] text-[15px] font-bold text-[#052e16]">{c.agentName.charAt(0).toUpperCase() || 'A'}</span>
            <span className="leading-tight"><b className="block text-[14.5px]">{c.agentName || 'Your agent'}</b><span className="text-[12px] text-white/70">online</span></span>
            <TgIcon size={20} className="ml-auto" />
          </div>
          <div className="flex min-h-[400px] flex-col justify-end gap-2 bg-[radial-gradient(rgba(20,83,45,.08)_1px,transparent_1px)] bg-[size:14px_14px] p-3.5">
            {msgs.map((m, i) => (
              <motion.div key={i} initial={reduce ? false : { opacity: 0, y: 10, scale: 0.96 }} whileInView={{ opacity: 1, y: 0, scale: 1 }} viewport={{ once: true }} transition={{ duration: reduce ? 0 : 0.45, delay: reduce ? 0 : 0.3 + i * 0.45 }}
                className={clsx('max-w-[84%] rounded-2xl px-3.5 py-2 text-[13.5px] leading-snug shadow-sm', m.me ? 'self-end rounded-br-md bg-[#d9fdd3] text-[#0b1f14]' : 'self-start rounded-bl-md bg-white text-[#0b1f14]')}>
                {m.t}
              </motion.div>
            ))}
            <motion.div initial={reduce ? false : { opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: reduce ? 0 : 0.5, delay: reduce ? 0 : 2.2 }}
              className="self-start w-[88%] rounded-2xl rounded-bl-md bg-white p-3 shadow-sm">
              <p className="flex items-center gap-2 text-[13px] font-bold text-[#14532d]"><span className="grid h-5 w-5 place-items-center rounded-full bg-[#16a34a] text-white">{F ? <Bell size={11} strokeWidth={3} /> : <Check size={12} strokeWidth={3} />}</span>{F ? 'New lead from your funnel' : 'Account live in your BM'}</p>
              <div className="mt-2 flex items-end justify-between rounded-xl bg-[#ecfbf0] px-3 py-2">
                <span className="text-[11px] text-[#3c5446]">{F ? 'Amit K. · Pune' : 'Agency account 01'}<br /><span className="font-semibold text-[#16a34a]">{F ? 'Wants a callback' : 'Active'}</span></span>
                <span className="text-right text-[11px] text-[#3c5446]">{F ? 'Leads this week' : 'Balance'}<br /><b className="text-[16px] text-[#0b1f14]">{F ? <CountUp value={412} delay={2400} /> : <CountUp prefix="$" value={2450} decimals={2} delay={2400} />}</b></span>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ChatSteps({ c }: { c: LandingContent }) {
  const pill = usePill();
  const steps = stepsFor(c).map((x, i) => ({ ...x, who: isF(c) ? ['You', 'We build', 'Done'][i] : ['You', 'Agent', 'Done'][i] }));
  return (
    <section id="steps" className="scroll-mt-20 bg-void py-20 sm:py-28">
      <div className="mx-auto max-w-[900px] px-6 sm:px-8">
        <Reveal><Eyebrow>How it works</Eyebrow><H2 className="mt-4 max-w-[16ch]">It all happens in one Telegram chat</H2></Reveal>
        <div className="mt-12 space-y-6">
          {steps.map(({ who, t, d }, i) => (
            <Reveal key={t} delay={i * 0.08} className={clsx('flex items-end gap-3', i % 2 && 'flex-row-reverse')}>
              <span className={clsx('grid h-12 w-12 shrink-0 place-items-center rounded-full text-[18px] font-extrabold', i === 2 ? 'bg-[#c6f36b] text-[#052e16]' : 'bg-[#14532d] text-white')}>{i + 1}</span>
              <div className={clsx('max-w-[560px] rounded-[26px] p-6 shadow-[0_20px_50px_-35px_var(--m-shadow)]', i % 2 ? 'rounded-br-md bg-[#14532d] text-white' : 'rounded-bl-md border border-edge bg-[#f3fbf4]')}>
                <p className={clsx('text-[12px] font-bold uppercase tracking-[0.14em]', i % 2 ? 'text-[#c6f36b]' : 'text-violet')}>{who}</p>
                <h3 className="mt-1 text-[21px] font-bold tracking-[-0.02em]">{t}</h3>
                <p className={clsx('mt-1.5 text-[15.5px] leading-relaxed', i % 2 ? 'text-white/80' : 'text-fg-2')}>{d}</p>
              </div>
            </Reveal>
          ))}
        </div>
        <Reveal className="mt-12"><LeadButton className={pill('brand')}><TgIcon size={18} className="[&>circle]:fill-white/25" />Start the chat<ArrowRight size={16} /></LeadButton></Reveal>
      </div>
    </section>
  );
}

function ChatTickets({ c }: { c: LandingContent }) {
  const pill = usePill();
  const plans: [Offer, 'account' | 'funnel', boolean][] = offers(c).map(([o, s], i) => [o, s, i === 0]);
  return (
    <section id="provide" className="scroll-mt-20 bg-[#f3fbf4] py-20 sm:py-28">
      <div className="mx-auto max-w-[1100px] px-6 sm:px-8">
        <Reveal><Eyebrow>Pricing</Eyebrow><H2 className="mt-4">Pick what you need</H2></Reveal>
        <div className="mt-12 grid gap-7 md:grid-cols-2">
          {plans.map(([o, svc, hot]) => (
            <Reveal key={svc} className={clsx('relative overflow-hidden rounded-[30px]', hot ? 'bg-[image:var(--m-card)] text-white' : 'border-2 border-[#14532d] bg-white text-fg')}>
              <div className="p-8 pb-6">
                <p className={clsx('inline-flex rounded-full px-3 py-1 text-[12px] font-bold', hot ? 'bg-[#c6f36b] text-[#052e16]' : 'bg-[#14532d] text-white')}>{o.badge}</p>
                <h3 className="mt-4 text-[26px] font-bold tracking-[-0.02em]">{o.title}</h3>
                <p className="mt-4 flex items-baseline gap-2"><span className="text-[58px] font-extrabold leading-none tracking-[-0.05em]"><CountUp prefix="$" value={o.price} /></span><span className={hot ? 'text-white/70' : 'text-fg-3'}>{o.unit}</span></p>
              </div>
              {/* ticket perforation */}
              <div className="relative flex items-center">
                <span className="absolute -left-4 h-8 w-8 rounded-full bg-[#f3fbf4]" />
                <span className={clsx('mx-6 w-full border-t-2 border-dashed', hot ? 'border-white/25' : 'border-[#14532d]/30')} />
                <span className="absolute -right-4 h-8 w-8 rounded-full bg-[#f3fbf4]" />
              </div>
              <div className="p-8 pt-6">
                <ul className="space-y-3">{o.bullets.map(b => <li key={b} className={clsx('flex gap-3 text-[15px]', hot ? 'text-white/90' : 'text-fg-2')}><span className={clsx('mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full', hot ? 'bg-[#c6f36b] text-[#052e16]' : 'bg-[#14532d] text-white')}><Check size={12} strokeWidth={3} /></span>{b}</li>)}</ul>
                <LeadButton service={svc} className={clsx(hot ? pill('white') : pill('brand'), 'mt-8 w-full')}>{o.cta}</LeadButton>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function ChatWhy({ c }: { c: LandingContent }) {
  const rows = isF(c) ? [
    ['Live in 2 to 3 days', 'Page, form, routing and tracking.'],
    ['Leads straight to Telegram', 'Your team sees them in seconds.'],
    ['An app for your sales team', 'Slow replies move to the next agent.'],
    ['Meta tracking done right', 'Lead and Purchase via Conversions API.'],
    [`$${c.priceFunnel} per month`, 'Hosting, apps and support included.'],
    ['Need an ad account too?', `Agency accounts from $${c.priceAccount}.`],
  ] : [
    [`Live within ${c.delivery}`, 'Counted from confirmed payment.'],
    ['One agent, start to finish', 'The person who sells it supports it.'],
    ['Top-ups in the same chat', 'No new order needed.'],
    ['No Business Manager yet?', 'We help you create one for free.'],
    [`$${c.priceAccount} per account`, `Top-ups through us${Number(c.topupFee) ? ` (${c.topupFee}% fee)` : ''}, no 18% GST.`],
    ['No spending limit', 'Multiple pages and domains.'],
  ];
  return (
    <section id="why" className="scroll-mt-20 bg-[#052e16] py-20 text-white sm:py-28">
      <div className="mx-auto max-w-[1100px] px-6 sm:px-8">
        <Reveal><p className="text-[15px] font-semibold text-[#c6f36b]">— Why {c.brand}</p><h2 className="mt-4 max-w-[18ch] text-balance text-[34px] font-bold leading-[1.02] tracking-[-0.04em] sm:text-[54px]">{c.whyTitle}</h2></Reveal>
        <div className="mt-12 grid gap-px overflow-hidden rounded-[28px] bg-white/10 sm:grid-cols-2 lg:grid-cols-3">
          {rows.map(([t, d], i) => (
            <Reveal key={t} delay={i * 0.04} className="bg-[#052e16] p-7">
              <span className="grid h-10 w-10 place-items-center rounded-full bg-[#c6f36b] text-[#052e16]"><Check size={20} strokeWidth={3} /></span>
              <h3 className="mt-5 text-[20px] font-bold tracking-[-0.02em]">{t}</h3>
              <p className="mt-1.5 text-[15px] text-white/70">{d}</p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function ChatFaq({ c }: { c: LandingContent }) {
  if (!c.faq.length) return null;
  return (
    <section id="faq" className="scroll-mt-20 bg-void py-20 sm:py-28">
      <div className="mx-auto grid max-w-[1100px] gap-10 px-6 sm:px-8 lg:grid-cols-[.8fr_1.2fr]">
        <Reveal><Eyebrow>FAQ</Eyebrow><H2 className="mt-4">Questions, answered</H2><p className="mt-4 text-[16px] text-fg-2">Anything else? Ask your agent on Telegram.</p></Reveal>
        <div className="space-y-3">
          {c.faq.map(([q, a], i) => (
            <details key={q + i} className="group rounded-[22px] bg-[#f3fbf4] px-6 open:bg-[#14532d] open:text-white">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-4 py-5 text-[17px] font-bold [&::-webkit-details-marker]:hidden">
                {q}<span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-[#c6f36b] text-[#052e16] transition-transform group-open:rotate-45"><Plus size={18} /></span>
              </summary>
              <p className="pb-5 text-[15.5px] leading-relaxed text-white/85">{a}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}

function ChatBand({ c }: { c: LandingContent }) {
  const pill = usePill();
  return (
    <section className="bg-void px-4 pb-4 sm:px-6 sm:pb-6">
      <div className="relative mx-auto max-w-[1240px] overflow-hidden rounded-[40px] bg-[#c6f36b] px-7 py-16 text-[#052e16] sm:px-14 sm:py-20">
        <div className="pointer-events-none absolute -right-20 -top-20 h-72 w-72 rounded-full border-[36px] border-[#052e16]/10" />
        <h2 className="relative max-w-[18ch] text-balance text-[36px] font-extrabold leading-[1] tracking-[-0.045em] sm:text-[58px]">{c.ctaTitle}</h2>
        <p className="relative mt-5 max-w-[46ch] text-[17px] text-[#052e16]/75">{c.ctaText}</p>
        <div className="relative mt-9 flex flex-col gap-3 sm:flex-row">
          <LeadButton service={offers(c)[0][1]} className={pill('brand')}><TgIcon size={18} className="[&>circle]:fill-white/25" />{isF(c) ? `${c.funnel.cta} · $${c.priceFunnel}/mo` : `${c.account.cta} · $${c.priceAccount}`}</LeadButton>
          <LeadButton service={offers(c)[1][1]} className={clsx(pill('outline'), '!border-[#052e16]/40 !text-[#052e16]')}>{isF(c) ? `${c.account.cta} · $${c.priceAccount}` : `${c.funnel.cta} · $${c.priceFunnel}/mo`}</LeadButton>
        </div>
      </div>
    </section>
  );
}

/* =====================================================================================
   /products — every product in one place, in the same four looks as the landing pages
   ===================================================================================== */
export type OrderWays = { web?: string; tg: string; wa?: string; text: string };
export type ProductQ = { q: string; a: string[] };
export type ProductItem = { id: string; title: string; price: number; unit: string; badge?: string; bullets: string[]; ways: OrderWays; cta: string; featured?: boolean; group?: 'popular' | 'managed' | 'full' | 'other'; topup?: string; alt?: string; qs?: ProductQ[] };
const GROUPS: { k: 'popular' | 'managed' | 'full' | 'other'; title: string; sub: string }[] = [
  { k: 'popular', title: 'Most popular', sub: '' },
  { k: 'managed', title: 'Agency ad accounts · we top up for you', sub: 'You send the ad budget to your agent and we add it to your account. A small top-up fee applies.' },
  { k: 'full', title: 'Full access ad accounts · you top up yourself', sub: 'The same accounts with full access: add funds with your own card in Ads Manager. No top-up fee from us.' },
  { k: 'other', title: 'Other services', sub: '' },
];
const WaMark = ({ size = 18 }: { size?: number }) => (
  <svg viewBox="0 0 24 24" width={size} height={size} fill="currentColor" aria-hidden><path d="M17.47 14.38c-.3-.15-1.75-.86-2.02-.96-.27-.1-.47-.15-.67.15-.2.3-.77.96-.94 1.16-.17.2-.35.22-.64.07-.3-.15-1.25-.46-2.38-1.47-.88-.79-1.47-1.76-1.65-2.06-.17-.3-.02-.46.13-.61.13-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.03-.52-.07-.15-.67-1.61-.92-2.2-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.79.37-.27.3-1.04 1.02-1.04 2.48 0 1.46 1.07 2.88 1.21 3.08.15.2 2.1 3.2 5.08 4.49.71.31 1.26.49 1.69.63.71.23 1.36.2 1.87.12.57-.09 1.75-.72 2-1.41.25-.7.25-1.29.17-1.41-.07-.13-.27-.2-.57-.35M12.05 21.5h-.01a9.5 9.5 0 0 1-4.84-1.33l-.35-.21-3.6.95.96-3.51-.23-.36a9.47 9.47 0 0 1-1.45-5.05c0-5.24 4.27-9.5 9.52-9.5 2.54 0 4.93.99 6.72 2.79a9.43 9.43 0 0 1 2.78 6.72c0 5.24-4.27 9.5-9.5 9.5M20.13 3.88A11.4 11.4 0 0 0 12.05.5C5.73.5.58 5.64.58 11.97c0 2.02.53 4 1.53 5.74L.5 23.5l5.94-1.56a11.44 11.44 0 0 0 5.6 1.43h.01c6.32 0 11.47-5.14 11.47-11.47 0-3.06-1.19-5.94-3.36-8.11" /></svg>
);
/** v134: "Order now" → a few quick questions for this product, then website / Telegram / WhatsApp (only the ways that are on).
 *  The answers go into the first Telegram / WhatsApp message, so the agent sees at once who is serious. */
function OrderPick({ p, className, children }: { p: ProductItem; className: string; children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const [ans, setAns] = useState<string[]>([]);
  const qs = p.qs || [];
  const done = qs.every((_, i) => !!ans[i]);
  const msg = [p.ways.text, ...qs.map((x, i) => `${x.q.replace(/\?$/, '')}: ${ans[i] || '-'}`)].join('\n');
  const withText = (base: string) => base.startsWith('http') ? `${base}?text=${encodeURIComponent(msg)}` : base;
  const opts = [
    p.ways.web && { k: 'web', href: p.ways.web, label: 'Order on the website', sub: 'Pay with crypto, instant order', icon: <Globe size={20} />, cls: 'bg-violet text-white' },
    { k: 'tg', href: withText(p.ways.tg), label: 'Order on Telegram', sub: 'Chat with a real agent', icon: <TgIcon size={22} />, cls: 'bg-[#229ED9]/10 text-fg' },
    p.ways.wa && { k: 'wa', href: withText(p.ways.wa), label: 'Order on WhatsApp', sub: 'Chat with a real agent', icon: <span className="text-[#25D366]"><WaMark size={22} /></span>, cls: 'bg-[#25D366]/10 text-fg' },
  ].filter(Boolean) as { k: string; href: string; label: string; sub: string; icon: ReactNode; cls: string }[];
  // v160: Telegram → first a lead with the right business + where they came from, then the chat opens with its code
  // (before: no code → a funnel order came in as an Agency chat with "Old non-tracked ads")
  const tgOrder = async (fallback: string) => {
    let to = fallback;
    try {
      const r = await fetch('/api/lead/products', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ product: p.id, text: msg, page_url: location.href, ref: document.referrer }) });
      const j = await r.json(); if (j?.link) to = j.link;
    } catch { /* the plain link still works */ }
    location.href = to;
  };
  if (opts.length === 1 && !qs.length) return <a href={opts[0].href} className={className} data-order-way={opts[0].k}>{children}</a>;
  return (
    <>
      <button type="button" onClick={() => { setAns([]); setOpen(true); }} className={className} data-order-pick={p.id}>{children}</button>
      {open && (
        <div className="fixed inset-0 z-[80] flex items-end justify-center bg-black/50 p-0 sm:items-center sm:p-6" onClick={() => setOpen(false)} role="dialog" aria-modal="true" aria-label={`Order ${p.title}`}>
          <div className="max-h-[92vh] w-full max-w-[460px] overflow-y-auto rounded-t-3xl bg-plum p-5 text-fg shadow-2xl sm:rounded-3xl" onClick={e => e.stopPropagation()} data-order-sheet>
            <div className="mb-1 flex items-start gap-3">
              <div className="min-w-0 flex-1"><p className="text-[13px] text-fg-3">{done ? 'How do you want to order?' : 'A few quick questions'}</p><p className="text-[18px] font-semibold leading-snug">{p.title}{p.price > 0 ? ` · $${p.price}` : ''}</p></div>
              <button type="button" onClick={() => setOpen(false)} aria-label="Close" className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-fg-3 hover:bg-ov/10"><X size={18} /></button>
            </div>
            {p.topup && <p className="mb-3 text-[13px] text-fg-3">{p.topup}</p>}
            {!!qs.length && (
              <div className="mb-4 space-y-3.5" data-order-qs>
                {qs.map((x, i) => (
                  <div key={x.q}>
                    <p className="mb-1.5 text-[14px] font-medium">{x.q}</p>
                    <div className="flex flex-wrap gap-2">
                      {x.a.map(a => (
                        <button key={a} type="button" data-ans={a} onClick={() => setAns(v => { const n = [...v]; n[i] = a; return n; })} className={clsx('rounded-full border px-3.5 py-2 text-[13.5px] font-medium transition-colors', ans[i] === a ? 'border-violet bg-violet text-white' : 'border-edge text-fg-2 hover:border-violet/50')}>{a}</button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
            {done ? (
              <div className="grid gap-2.5" data-order-ways>
                {opts.map(o => (
                  <a key={o.k} href={o.href} data-order-way={o.k} onClick={o.k === 'tg' ? e => { e.preventDefault(); void tgOrder(o.href); } : undefined} className={clsx('group flex items-center gap-3 rounded-2xl px-4 py-3.5 transition-transform hover:-translate-y-0.5', o.cls)}>
                    <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-white/15">{o.icon}</span>
                    <span className="min-w-0 flex-1"><span className="block text-[15.5px] font-semibold">{o.label}</span><span className="block text-[12.5px] opacity-75">{o.sub}</span></span>
                    <ArrowRight size={17} className="shrink-0 opacity-70 transition-transform group-hover:translate-x-0.5" />
                  </a>
                ))}
              </div>
            ) : <p className="rounded-xl bg-ov/[0.05] px-4 py-3 text-center text-[13px] text-fg-3">Answer the questions above to continue</p>}
          </div>
        </div>
      )}
    </>
  );
}

export function ProductsLanding({ c, products, note }: { c: LandingContent; products: ProductItem[]; note: string }) {
  const v = VARIANT[c.theme] || 'stage';
  return (
    <VC.Provider value={v}>
      <div className="font-display" style={pal(c.theme).page as CSSProperties}>
        <ProductsBody c={c} products={products} note={note} />
        <Footer c={c} />
      </div>
    </VC.Provider>
  );
}
function ProductsBody({ c, products, note }: { c: LandingContent; products: ProductItem[]; note: string }) {
  const v = useV();
  const pill = usePill();
  const dark = v === 'stage' || v === 'horizon';
  return (
    <>
      <section className={clsx('relative overflow-hidden pt-[var(--bar-h)]', dark ? 'bg-[image:var(--m-hero)] text-white' : 'bg-void text-fg')}>
        <div className="mx-auto flex h-20 max-w-[1200px] items-center gap-4 px-6 sm:px-8">
          <Wordmark c={c} light={dark} />
          <div className={clsx('ml-auto flex items-center gap-1 text-[14px] font-medium', dark ? 'text-white/85' : 'text-fg-2')}>
            <a href="/" className={clsx('rounded-full px-3 py-2', dark ? 'hover:bg-white/10' : 'hover:bg-violet/10')}>Home</a>
            {c.webOn && <a href="/account" className={clsx('rounded-full px-3 py-2', dark ? 'hover:bg-white/10' : 'hover:bg-violet/10')}>My account</a>}
          </div>
        </div>
        <div className={clsx('mx-auto max-w-[1200px] px-6 pb-16 pt-8 sm:px-8 sm:pb-20 sm:pt-12', v !== 'chat' && 'text-center')}>
          <Eyebrow className={dark ? '!text-white/80' : ''}>All products</Eyebrow>
          <h1 className={clsx('mt-4 text-balance', dark ? 'text-[38px] font-light leading-[1.08] tracking-[-0.01em] sm:text-[58px]' : 'text-[36px] font-semibold leading-[1.05] tracking-[-0.04em] sm:text-[56px]')}>Everything you need to run Meta ads</h1>
          <p className={clsx('mt-5 max-w-[56ch] text-[16px] leading-relaxed', v !== 'chat' && 'mx-auto', dark ? 'text-white/80' : 'text-fg-2')}>{note}</p>
        </div>
      </section>
      <section className="bg-void py-14 sm:py-20">
        {/* v134: grouped — who tops up the account is the first thing they see */}
        <div className="mx-auto max-w-[1200px] space-y-12 px-3 sm:space-y-16 sm:px-8">
          {GROUPS.map(g => { const ps = products.filter(p => (p.group || 'other') === g.k); return ps.length ? (
            <div key={g.k} data-group={g.k}>
              <div className="mb-4 px-1 sm:mb-6">
                <h2 className="text-[19px] font-semibold tracking-[-0.01em] text-fg sm:text-[26px]">{g.title}</h2>
                {g.sub && <p className="mt-1.5 max-w-[70ch] text-[13.5px] leading-relaxed text-fg-3 sm:text-[15px]">{g.sub}</p>}
              </div>
              {/* v118: two cards side by side on phones too (less scrolling) */}
              <div className="grid grid-cols-2 gap-3 sm:gap-6 lg:grid-cols-3">
                {ps.map(p => { const wide = ps.length === 1; /* v135: a lone card takes the full row (no empty half), bullets in 2 columns → shorter */ return (
                <Reveal key={p.id} data-wide={wide ? '1' : undefined} className={clsx('relative flex flex-col overflow-hidden p-4 sm:p-8', wide && 'col-span-2 lg:col-span-3', radius(v), p.featured ? 'bg-[image:var(--m-card)] text-white shadow-[0_40px_80px_-40px_var(--m-shadow)]' : 'border border-edge bg-plum text-fg shadow-[0_30px_60px_-40px_var(--m-shadow)]')}>
                  <div id={p.id} className="absolute -top-24" />
                  {p.featured && <div className="pointer-events-none absolute -bottom-24 -right-20 h-64 w-64 rounded-full bg-[radial-gradient(closest-side,var(--m-cardglow),transparent)]" />}
                  {p.badge && <p className={clsx('text-[10px] font-semibold uppercase tracking-[0.14em] sm:text-[12px] sm:tracking-[0.18em]', p.featured ? 'text-[#ffe4d6]' : 'text-violet')}>{p.badge}</p>}
                  <div className={clsx(wide && 'flex items-end justify-between gap-3')}>
                  <h2 className={clsx('mt-2 text-[16px] leading-snug tracking-[-0.01em] sm:mt-3 sm:text-[23px]', wide && 'min-w-0 flex-1 text-[18px]', dark ? 'font-normal' : 'font-semibold')}>{p.title}</h2>
                  <p className={clsx(wide ? 'shrink-0' : 'mt-3 sm:mt-5', 'flex flex-wrap items-baseline gap-x-1.5 gap-y-0.5 sm:gap-2')}>
                    {p.price > 0 && <span className={clsx('text-[32px] leading-none tracking-[-0.03em] sm:text-[46px]', dark ? 'font-light' : 'font-bold')}>${p.price}</span>}
                    <span className={clsx(p.price > 0 ? 'text-[11.5px] sm:text-[14.5px]' : 'text-[17px] font-semibold sm:text-[26px]', p.featured ? 'text-white/75' : p.price > 0 ? 'text-fg-3' : 'text-fg')}>{p.unit}</span>
                  </p>
                  </div>
                  {p.topup && <p data-topup-note className={clsx('mt-3 rounded-xl px-2.5 py-1.5 text-[11.5px] font-semibold leading-snug sm:mt-4 sm:px-3 sm:text-[13.5px]', p.featured ? 'bg-white/15 text-white' : p.group === 'full' ? 'bg-[#16a34a]/10 text-[#15803d]' : 'bg-violet/10 text-violet')}>{p.topup}</p>}
                  <ul className={clsx('mb-5 mt-4 sm:mb-8 sm:mt-6', wide ? 'grid grid-cols-2 gap-x-4 gap-y-2 sm:gap-x-8 sm:gap-y-3 lg:grid-cols-4' : 'space-y-2 sm:space-y-3')}>
                    {p.bullets.map(b => (
                      <li key={b} className={clsx('flex gap-2 text-[12px] leading-snug sm:gap-3 sm:text-[15px]', p.featured ? 'text-white/90' : 'text-fg-2')}>
                        <span className={clsx('mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded-full sm:h-5 sm:w-5', p.featured ? 'bg-white/20' : 'bg-violet/10 text-violet')}><Check size={10} strokeWidth={3} /></span>{b}
                      </li>
                    ))}
                  </ul>
                  {p.alt && <p className={clsx('-mt-2 mb-4 text-[11.5px] leading-snug sm:mb-6 sm:text-[13px]', p.featured ? 'text-white/75' : 'text-fg-3')}>{p.alt}</p>}
                  <OrderPick p={p} className={clsx('relative mt-auto inline-flex w-full items-center justify-center gap-1.5 rounded-full px-3 py-2.5 text-[13px] font-semibold sm:hidden', p.featured ? 'bg-white text-[color:var(--m-ink)]' : 'bg-[image:var(--m-grad)] text-white')}>{p.cta}<ArrowRight size={14} /></OrderPick>
                  <OrderPick p={p} className={clsx(pill(p.featured ? 'white' : 'brand'), 'relative mt-auto hidden sm:inline-flex', wide ? 'w-full sm:max-w-[360px]' : 'w-full')}>{p.cta}<ArrowRight size={16} /></OrderPick>
                </Reveal>
                ); })}
              </div>
            </div>
          ) : null; })}
        </div>
        <p className="mx-auto mt-10 max-w-[1200px] px-6 text-center text-[14px] text-fg-3 sm:px-8">Questions before ordering? <a href="/telegram" className="font-semibold text-violet hover:underline">Talk to us on Telegram</a></p>
      </section>
    </>
  );
}
