'use client';

/* Design 4 — "Private": black & gold, editorial serif. A tilting metallic account card,
   a menu-style price list with dotted leaders, a centred timeline and large serif figures. */

import { useRef } from 'react';
import { motion, useMotionValue, useSpring, useTransform, useReducedMotion, useScroll } from 'framer-motion';
import { Plus } from 'lucide-react';
import clsx from 'clsx';
import { TgIcon, TgPill } from '../Telegram';
import { OrderChoice } from '../OrderChoice';
import { LeadButton } from '../LeadModal';
import { RecentTicker } from '../RecentTicker';
import { Reveal } from '../Sections';
import type { LandingContent, Offer } from '@/server/content';

const ease = [0.16, 1, 0.3, 1] as const;
const ROMAN = ['I', 'II', 'III', 'IV', 'V'];

export function GoldLanding({ c }: { c: LandingContent }) {
  return (
    <>
      <GoNav c={c} />
      <main className="pt-[var(--bar-h)]">
        <GoHero c={c} />
        <Figures c={c} />
        <Timeline c={c} />
        <GoFaq c={c} />
      </main>
      <GoCta c={c} />
    </>
  );
}

function Monogram({ brand, size = 34, src }: { brand: string; size?: number; src?: string }) {
  // eslint-disable-next-line @next/next/no-img-element
  if (src) return <img src={src} alt="" width={size} height={size} style={{ width: size, height: size }} className="shrink-0 rounded-full object-contain" />;
  return (
    <span className="grid place-items-center rounded-full border border-violet/60 font-display font-medium text-violet" style={{ width: size, height: size, fontSize: size * 0.48 }}>
      {brand.trim().charAt(0).toUpperCase() || 'A'}
    </span>
  );
}

function GoNav({ c }: { c: LandingContent }) {
  return (
    <header className="fixed inset-x-0 top-[var(--bar-h)] z-50 bg-void/85 backdrop-blur-md">
      <div className="mx-auto flex h-[72px] max-w-[1240px] items-center px-5 sm:px-10">
        <nav className="hidden flex-1 gap-8 text-[13.5px] tracking-[0.02em] text-fg-3 md:flex">
          <a href="#figures" className="hover:text-violet">Standards</a><a href="#process" className="hover:text-violet">Process</a><a href="#faq" className="hover:text-violet">Questions</a>
        </nav>
        <a href="#" className="flex flex-1 items-center gap-3 font-display text-[22px] tracking-[-0.01em] md:justify-center"><Monogram brand={c.brand} src={c.logo} />{c.brand}</a>
        <div className="flex flex-1 justify-end">
          <LeadButton className="inline-flex items-center gap-2 rounded-full border border-violet/70 px-4 py-2.5 text-[14px] text-violet transition-colors hover:bg-violet hover:text-onp sm:px-5"><TgIcon size={17} /><span className="whitespace-nowrap sm:hidden">Request</span><span className="hidden whitespace-nowrap sm:inline">Request an account</span></LeadButton>
        </div>
      </div>
      <div className="mx-auto h-px max-w-[1240px] bg-gradient-to-r from-transparent via-violet/40 to-transparent" />
    </header>
  );
}

function GoHero({ c }: { c: LandingContent }) {
  const reduce = useReducedMotion();
  return (
    <section className="relative isolate overflow-hidden pb-20 pt-28 sm:pb-28 sm:pt-32">
      <div className="pointer-events-none absolute right-[-10%] top-[10%] -z-10 h-[620px] w-[620px] rounded-full bg-[radial-gradient(closest-side,rgb(var(--p)/.20),transparent)]" />
      <div className="mx-auto grid max-w-[1240px] items-center gap-14 px-5 sm:px-10 lg:grid-cols-[1.05fr_1fr]">
        <div className="relative min-w-0">
          {c.recentOn && <RecentTicker align="left" />}
          <motion.p initial={reduce ? false : { opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1.2 }} className="flex items-center gap-3 text-[14px] text-fg-3">
            <span className="h-px w-10 bg-violet/60" />{c.badge}
          </motion.p>
          <motion.h1 initial={reduce ? false : { opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1.2, ease }}
            className="mt-5 font-display text-[42px] font-light leading-[1.02] tracking-[-0.03em] sm:text-[60px] lg:text-[64px]">
            {c.headline} <span className="font-normal italic text-violet">{c.accent}</span>
          </motion.h1>
          {c.webOn && <OrderChoice c={c} tone="gold" className="mt-7" />}
          <motion.p initial={reduce ? false : { opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4, duration: 1 }} className="mt-5 max-w-[48ch] text-[16.5px] leading-[1.7] text-fg-2">{c.sub}</motion.p>
          {!c.webOn && <TgPill c={c} className="mt-4" />}

          <motion.div initial={reduce ? false : { opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6, duration: 1, ease }} className="mt-8 border-t border-violet/25">
            <MenuItem n={0} o={c.account} service="account" />
            <MenuItem n={1} o={c.funnel} service="funnel" />
          </motion.div>
          <p className="mt-5 text-[13.5px] text-fg-3">Settled in {c.payment}. Delivered within {c.delivery}.</p>
        </div>
        <motion.div initial={reduce ? false : { opacity: 0, scale: 0.92, rotate: -4 }} animate={{ opacity: 1, scale: 1, rotate: 0 }} transition={{ duration: 1.4, delay: 0.3, ease }}>
          <GoldCard c={c} />
        </motion.div>
      </div>
    </section>
  );
}

function MenuItem({ n, o, service }: { n: number; o: Offer; service: 'account' | 'funnel' }) {
  return (
    <LeadButton service={service} className="group block w-full border-b border-violet/25 py-5 text-left">
      <span className="flex items-baseline gap-4">
        <span className="w-8 shrink-0 font-display text-[15px] italic text-violet">{ROMAN[n]}.</span>
        <span className="font-display text-[22px] tracking-[-0.01em] transition-colors group-hover:text-violet sm:text-[26px]">{o.title}</span>
        <span className="mx-1 hidden flex-1 translate-y-[-5px] border-b border-dotted border-fg-3/50 sm:block" />
        <span className="ml-auto shrink-0 font-display text-[26px] text-violet sm:ml-0 sm:text-[30px]">${o.price}<span className="ml-1 font-sans text-[13px] text-fg-3">{o.unit === 'per month' ? '/ month' : ''}</span></span>
      </span>
      <span className="mt-2 block pl-12 text-[14.5px] text-fg-3">{o.sub}</span>
      <span className="mt-2.5 flex flex-wrap items-center gap-x-5 gap-y-1 pl-12 text-[13.5px] text-fg-2">
        {o.bullets.slice(0, 2).map(b => <span key={b} className="flex items-center gap-2"><span className="h-1 w-1 rotate-45 bg-violet" />{b}</span>)}
        <span className="inline-flex items-center gap-1.5 text-violet"><TgIcon size={15} />{o.cta}<span className="transition-transform group-hover:translate-x-1">→</span></span>
      </span>
    </LeadButton>
  );
}

function GoldCard({ c }: { c: LandingContent }) {
  const ref = useRef<HTMLDivElement>(null);
  const reduce = useReducedMotion();
  const mx = useMotionValue(0.5), my = useMotionValue(0.5);
  const rx = useSpring(useTransform(my, [0, 1], [14, -14]), { stiffness: 120, damping: 14 });
  const ry = useSpring(useTransform(mx, [0, 1], [-18, 18]), { stiffness: 120, damping: 14 });
  const gx = useTransform(mx, [0, 1], ['0%', '100%']);
  const glare = useTransform(gx, x => `radial-gradient(circle at ${x} 30%, rgba(255,255,255,.55), transparent 45%)`);
  return (
    <div className="mx-auto w-full max-w-[460px] [perspective:1400px]"
      onPointerMove={e => { const r = ref.current!.getBoundingClientRect(); mx.set((e.clientX - r.left) / r.width); my.set((e.clientY - r.top) / r.height); }}
      onPointerLeave={() => { mx.set(0.5); my.set(0.5); }}>
      <motion.div ref={ref} style={reduce ? undefined : { rotateX: rx, rotateY: ry }} animate={reduce ? undefined : { y: [0, -10, 0] }} transition={{ y: { duration: 6, repeat: Infinity, ease: 'easeInOut' } }}
        className="relative aspect-[1.586] w-full overflow-hidden rounded-[22px] text-[#2a1d08] shadow-[0_50px_100px_-30px_rgba(0,0,0,.9),0_30px_60px_-30px_rgb(var(--p)/.45)]">
        <div className="absolute inset-0 bg-[linear-gradient(135deg,#f7e3b0_0%,#d4af6a_28%,#a8823f_55%,#e9cf93_78%,#b8914c_100%)]" />
        <div className="absolute inset-0 opacity-30 mix-blend-overlay bg-[repeating-linear-gradient(115deg,rgba(255,255,255,.5)_0_1px,transparent_1px_6px)]" />
        <motion.div className="absolute inset-0" style={{ background: glare }} />
        {!reduce && <motion.div className="absolute inset-y-0 w-1/3 bg-gradient-to-r from-transparent via-white/45 to-transparent" initial={{ x: '-120%' }} animate={{ x: '420%' }} transition={{ duration: 2.6, repeat: Infinity, repeatDelay: 3.5, ease: 'easeInOut' }} />}
        <div className="relative flex h-full flex-col justify-between p-6 sm:p-8">
          <div className="flex items-start justify-between">
            <span className="font-display text-[22px] tracking-[-0.01em]">{c.brand}</span>
            <span className="text-right text-[11px] leading-tight opacity-75">Agency<br />ad account</span>
          </div>
          <div className="h-10 w-14 rounded-md bg-[linear-gradient(135deg,#fff3cf,#c9a35a)] shadow-inner ring-1 ring-black/10">
            <div className="m-1.5 h-[calc(100%-12px)] rounded-sm border border-black/20 bg-[repeating-linear-gradient(90deg,transparent_0_8px,rgba(0,0,0,.15)_8px_9px)]" />
          </div>
          <div>
            <p className="font-mono text-[15px] tracking-[0.18em] sm:text-[18px]">act •••• •••• 7742</p>
            <div className="mt-3 flex items-end justify-between text-[11px]">
              <span><span className="block opacity-60">Status</span><span className="text-[13px] font-semibold">Active</span></span>
              <span><span className="block opacity-60">Delivered in</span><span className="text-[13px] font-semibold">{c.delivery}</span></span>
              <span className="font-display text-[26px] italic">${c.priceAccount}</span>
            </div>
          </div>
        </div>
      </motion.div>
      <div className="mx-auto mt-10 h-6 w-3/4 rounded-[50%] bg-[radial-gradient(closest-side,rgba(0,0,0,.7),transparent)]" />
    </div>
  );
}

function Figures({ c }: { c: LandingContent }) {
  const f = [[c.deliveryShort, 'From payment to a live account in your Business Manager.'], [`$${c.priceAccount}`, 'Per agency ad account. Your ad spend goes straight to Meta.'], ['1', 'Agent for you, from the first message to every top-up.']];
  return (
    <section id="figures" className="scroll-mt-24 border-y border-violet/20 py-14 sm:py-24">
      <div className="mx-auto grid max-w-[1240px] gap-10 px-5 sm:px-10 md:grid-cols-3 md:gap-0">
        {f.map(([n, d], i) => (
          <Reveal key={i} delay={i * 0.1} className={clsx('md:px-10', i > 0 && 'md:border-l md:border-violet/20')}>
            <p className="font-display text-[64px] font-light leading-none tracking-[-0.04em] text-violet sm:text-[96px]">{n}</p>
            <p className="mt-4 max-w-[30ch] text-[15.5px] leading-relaxed text-fg-2">{d}</p>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

function Timeline({ c }: { c: LandingContent }) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start 75%', 'end 60%'] });
  const h = useSpring(scrollYProgress, { stiffness: 100, damping: 24 });
  const steps = [
    ['Tell us about your advertising', 'Three short questions: Business Manager, what you advertise, and your daily budget.'],
    ['A private conversation', 'Telegram opens with your message ready. Your agent replies in the same chat.'],
    ['Settle the account', `${c.payment}. Then share your Business Manager ID.`],
    ['Your account, live', `Shared to your Business Manager within ${c.delivery}. Top-ups whenever you need them.`],
  ];
  return (
    <section id="process" className="scroll-mt-24 py-16 sm:py-28">
      <div className="mx-auto max-w-[1000px] px-5 sm:px-10">
        <Reveal className="text-center">
          <h2 className="font-display text-[40px] font-light tracking-[-0.03em] sm:text-[60px]">The <span className="italic text-violet">process</span></h2>
          <p className="mx-auto mt-4 max-w-[46ch] text-[16px] text-fg-2">{c.chatText}</p>
        </Reveal>
        <div ref={ref} className="relative mt-16">
          <div className="absolute bottom-0 left-4 top-0 w-px bg-violet/15 md:left-1/2" />
          <motion.div className="absolute left-4 top-0 w-px origin-top bg-violet md:left-1/2" style={{ scaleY: h, bottom: 0 }} />
          <div className="grid gap-14">
            {steps.map(([t, d], i) => (
              <Reveal key={t} delay={0.05} className={clsx('relative pl-14 md:w-1/2', i % 2 ? 'md:ml-auto md:pl-16' : 'md:pl-0 md:pr-16 md:text-right')}>
                <span className={clsx('absolute left-0 top-0 grid h-8 w-8 place-items-center rounded-full border border-violet bg-void font-display text-[14px] italic text-violet', i % 2 ? 'md:-left-4' : 'md:left-auto md:-right-4')}>{ROMAN[i]}</span>
                <h3 className="font-display text-[24px] tracking-[-0.01em] sm:text-[28px]">{t}</h3>
                <p className="mt-2 text-[15.5px] leading-relaxed text-fg-2">{d}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function GoFaq({ c }: { c: LandingContent }) {
  if (!c.faq.length) return null;
  return (
    <section id="faq" className="scroll-mt-24 border-t border-violet/20 py-20 sm:py-28">
      <div className="mx-auto grid max-w-[1240px] gap-12 px-5 sm:px-10 lg:grid-cols-[.7fr_1.3fr]">
        <Reveal><h2 className="font-display text-[40px] font-light leading-[1.05] tracking-[-0.03em] sm:text-[56px]">Questions, <span className="italic text-violet">answered</span></h2></Reveal>
        <div className="border-t border-violet/20">
          {c.faq.map(([q, a], i) => (
            <details key={q + i} className="group border-b border-violet/20">
              <summary className="flex cursor-pointer list-none items-baseline gap-5 py-6 [&::-webkit-details-marker]:hidden">
                <span className="w-8 shrink-0 font-display text-[14px] italic text-violet">{String(i + 1).padStart(2, '0')}</span>
                <span className="flex-1 font-display text-[19px] sm:text-[22px]">{q}</span>
                <Plus size={18} className="shrink-0 text-violet transition-transform duration-300 group-open:rotate-45" />
              </summary>
              <p className="max-w-[60ch] pb-6 pl-[52px] text-[15.5px] leading-[1.75] text-fg-2">{a}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}

function GoCta({ c }: { c: LandingContent }) {
  return (
    <section className="relative isolate overflow-hidden border-t border-violet/20 pt-24 sm:pt-32">
      <div className="absolute left-1/2 top-0 -z-10 h-[500px] w-[900px] -translate-x-1/2 rounded-full bg-[radial-gradient(closest-side,rgb(var(--p)/.22),transparent)]" />
      <div className="mx-auto max-w-[900px] px-5 text-center">
        <Reveal><Monogram brand={c.brand} size={56} src={c.logo} /></Reveal>
        <Reveal delay={0.1}><h2 className="mx-auto mt-8 max-w-[16ch] font-display text-[42px] font-light leading-[1.05] tracking-[-0.03em] sm:text-[72px]">{c.ctaTitle}</h2></Reveal>
        <Reveal delay={0.15}><p className="mx-auto mt-6 max-w-[44ch] text-[16.5px] text-fg-2">{c.ctaText}</p></Reveal>
        <Reveal delay={0.2} className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
          <LeadButton className="rounded-full bg-gradient-to-r from-violet-soft via-violet to-violet-deep px-9 py-4 text-[16px] font-medium text-onp shadow-[0_15px_40px_-12px_rgb(var(--p)/.7)] transition-transform hover:scale-[1.03]">Request an account for ${c.priceAccount}</LeadButton>
          <LeadButton service="funnel" className="text-[15px] text-violet underline decoration-violet/40 underline-offset-[6px] hover:decoration-violet">or set up a funnel for ${c.priceFunnel}/month</LeadButton>
        </Reveal>
      </div>
      <footer className="mx-auto mt-24 flex max-w-[1240px] flex-col items-center gap-3 border-t border-violet/20 px-5 py-8 text-[13px] text-fg-3 sm:flex-row sm:justify-between sm:px-10">
        <p className="flex items-center gap-3 font-display text-[17px] text-fg"><Monogram brand={c.brand} size={28} src={c.logo} />{c.brand}</p>
        <p className="flex flex-wrap justify-center gap-x-4">{c.webOn && <a href="/account" className="font-medium text-fg-2 hover:text-violet">My account · Top up</a>}{c.channel && <a href={c.channel} target="_blank" rel="noopener" className="hover:text-violet">Telegram channel</a>}<span>© {new Date().getFullYear()} {c.brand}. {c.footer}</span></p>
      </footer>
    </section>
  );
}
