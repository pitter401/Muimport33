'use client';

import { Globe, ArrowRight } from 'lucide-react';
import clsx from 'clsx';
import { LeadButton } from './LeadModal';
import { TgIcon } from './Telegram';
import { ViewerBadge } from './Sections';
import { CountUp } from './CountUp';
import type { LandingContent } from '@/server/content';

type Tone = 'purple' | 'green' | 'blue' | 'gold';

/** Above-the-fold choice: Order on Telegram ($20) or Order on Website ($17, save $3). Shown when website orders are switched on. */
/** v118: `funnel` = the same two choices for the funnel (Telegram chat or website order, monthly price). */
export function OrderChoice({ c: c0, tone, className, layout = 'grid', funnel }: { c: LandingContent; tone: Tone; className?: string; layout?: 'grid' | 'rows' | 'bubbles'; funnel?: boolean }) {
  const c = funnel ? { ...c0, priceTg: c0.priceFunnel, priceWeb: c0.priceFunnelWeb || c0.priceFunnel, tier: '' } as LandingContent : c0;
  const href = funnel ? '/order?kind=funnel' : c.tier === 'premium' ? '/order?tier=premium' : '/order';
  const service = funnel ? 'funnel' as const : undefined;
  const save = Math.max(0, Math.round((Number(c.priceTg) - Number(c.priceWeb)) * 100) / 100);
  if (layout === 'rows') return <OrderRows c={c} tone={tone} save={save} className={className} href={href} service={service} />;
  if (layout === 'bubbles') return <OrderBubbles c={c} save={save} className={className} href={href} service={service} />;
  const card = {
    purple: 'rounded-2xl border border-edge bg-plum/90',
    green: 'rounded-2xl bg-plum',
    blue: 'rounded-2xl border border-edge bg-white shadow-[0_10px_30px_-18px_rgb(var(--p)/.5)]',
    gold: 'rounded-none border border-violet/30 bg-ov/[0.02]',
  }[tone];
  const hot = {
    purple: 'rounded-2xl border border-violet/60 bg-gradient-to-br from-violet/30 to-orchid/15 shadow-[0_18px_40px_-18px_rgb(var(--p)/.9)]',
    green: 'rounded-2xl bg-violet text-onp',
    blue: 'rounded-2xl bg-violet text-white shadow-[0_14px_34px_-14px_rgb(var(--p)/.8)]',
    gold: 'rounded-none border border-violet bg-gradient-to-br from-violet/25 to-transparent',
  }[tone];
  const priceCls = tone === 'gold' ? 'font-display font-normal' : 'font-display font-semibold';
  return (
    <div className={clsx('relative z-[1] grid w-full max-w-[560px] grid-cols-2 gap-2.5 text-left sm:gap-3', className)}>
      <div className="min-w-0">
        <LeadButton direct service={service} className={clsx('group flex h-full w-full flex-col p-3.5 text-left transition-transform hover:-translate-y-0.5 sm:p-4', card)}>
          <span className="flex items-center gap-2"><TgIcon size={22} className="shrink-0" /><span className="text-[13.5px] font-semibold leading-tight text-fg sm:text-[15px]">Order on Telegram</span></span>
          <span className={clsx('mt-2.5 text-[30px] leading-none tracking-tight text-fg sm:text-[36px]', priceCls)}><CountUp prefix="$" value={c.priceTg} /></span>
          <span className="mt-1.5 text-[12px] leading-snug text-fg-3 sm:text-[13px]">{service === 'funnel' ? 'Per month · chat with an agent' : 'Chat with a real agent'}</span>
          <span className={clsx('mt-auto inline-flex items-center gap-1 pt-2.5 text-[12.5px] font-semibold sm:text-[13.5px]', tone === 'gold' ? 'text-violet' : 'text-[#229ED9]')}>Open Telegram <ArrowRight size={14} className="transition-transform group-hover:translate-x-0.5" /></span>
        </LeadButton>
      </div>
      <div className="relative min-w-0">
        {save > 0 && <span className={clsx('absolute -top-2.5 right-3 z-10 rounded-full px-2.5 py-0.5 text-[11.5px] font-bold', tone === 'blue' || tone === 'green' ? 'bg-[#C6FF4D] text-black' : 'bg-mint text-[#062b12]')}>Save ${save}</span>}
        <a href={href} className={clsx('group flex h-full w-full flex-col p-3.5 transition-transform hover:-translate-y-0.5 sm:p-4', hot)}>
          <span className="flex items-center gap-2"><span className={clsx('grid h-[22px] w-[22px] shrink-0 place-items-center rounded-full', tone === 'green' || tone === 'blue' ? 'bg-black/15' : 'bg-violet/30')}><Globe size={13} /></span><span className={clsx('text-[13.5px] font-semibold leading-tight sm:text-[15px]', tone === 'green' || tone === 'blue' ? '' : 'text-fg')}>Order on Website</span></span>
          <span className={clsx('mt-2.5 flex items-baseline gap-1.5 text-[30px] leading-none tracking-tight sm:text-[36px]', priceCls, tone === 'green' || tone === 'blue' ? '' : 'text-fg')}><CountUp prefix="$" value={c.priceWeb} /><s className="text-[14px] font-normal opacity-60">${c.priceTg}</s></span>
          <span className={clsx('mt-1.5 text-[12px] leading-snug sm:text-[13px]', tone === 'green' || tone === 'blue' ? 'opacity-80' : 'text-fg-3')}>{service === 'funnel' ? 'Per month · pay with crypto' : 'Pay with crypto, instant order'}</span>
          <span className={clsx('mt-auto inline-flex items-center gap-1 pt-2.5 text-[12.5px] font-semibold sm:text-[13.5px]', tone === 'green' || tone === 'blue' ? '' : 'text-lilac')}>Order now <ArrowRight size={14} className="transition-transform group-hover:translate-x-0.5" /></span>
        </a>
      </div>
      {!!c.viewerFloor && <div className="col-span-2 mt-1.5 flex justify-center"><ViewerBadge theme={c.theme} floor={c.viewerFloor} /></div>}
    </div>
  );
}

/** Compact version: the two choices as slim rows, one under the other (blue = rounded rows, green = pill rows). */
function OrderRows({ c, tone, save, className, href, service }: { c: LandingContent; tone: Tone; save: number; className?: string; href: string; service?: 'funnel' }) {
  const pillShape = tone === 'green';
  const shape = pillShape ? 'rounded-full pl-2.5 pr-5' : 'rounded-2xl px-3.5';
  const plain = pillShape ? 'border-2 border-[#14532d]/15 bg-white text-fg' : 'border border-edge bg-white text-fg shadow-[0_8px_24px_-18px_rgb(var(--p)/.6)]';
  const hot = pillShape ? 'bg-[#14532d] text-white shadow-[0_14px_30px_-16px_rgba(20,83,45,.8)]' : 'bg-violet text-white shadow-[0_14px_30px_-14px_rgb(var(--p)/.8)]';
  const row = 'group flex w-full items-center gap-3 py-2.5 text-left transition-transform hover:-translate-y-0.5 sm:py-3';
  const icon = 'grid h-10 w-10 shrink-0 place-items-center rounded-full';
  return (
    <div className={clsx('relative z-[1] w-full max-w-[440px] space-y-2.5', className)}>
      <LeadButton direct service={service} className={clsx(row, shape, plain)}>
        <span className={clsx(icon, 'bg-[#229ED9]/10')}><TgIcon size={22} /></span>
        <span className="min-w-0 flex-1"><span className="block text-[15px] font-semibold leading-tight">Order on Telegram</span><span className="block text-[12.5px] text-fg-3">Chat with a real agent</span></span>
        <span className="text-[22px] font-bold tracking-tight"><CountUp prefix="$" value={c.priceTg} /></span>
        <ArrowRight size={17} className="shrink-0 text-fg-3 transition-transform group-hover:translate-x-0.5" />
      </LeadButton>
      <a href={href} className={clsx(row, shape, hot)}>
        <span className={clsx(icon, 'bg-white/15')}><Globe size={19} /></span>
        <span className="min-w-0 flex-1">
          <span className="flex flex-wrap items-center gap-x-2 gap-y-1 text-[15px] font-semibold leading-tight">Order on Website{save > 0 && <span className={clsx('shrink-0 whitespace-nowrap rounded-full px-2 py-0.5 text-[11px] font-bold', pillShape ? 'bg-[#c6f36b] text-[#052e16]' : 'bg-[#C6FF4D] text-black')}>Save ${save}</span>}</span>
          <span className="block text-[12.5px] text-white/75">Pay with crypto, instant order</span>
        </span>
        <span className="text-right leading-none"><span className="block text-[22px] font-bold tracking-tight"><CountUp prefix="$" value={c.priceWeb} /></span><s className="text-[12px] opacity-60">${c.priceTg}</s></span>
        <ArrowRight size={17} className="shrink-0 opacity-80 transition-transform group-hover:translate-x-0.5" />
      </a>
      {!!c.viewerFloor && <div className="pt-1"><ViewerBadge theme={c.theme} floor={c.viewerFloor} /></div>}
    </div>
  );
}

/** Green page: the two choices as Telegram-style chat bubbles (left = Telegram, right = website). */
function OrderBubbles({ c, save, className, href, service }: { c: LandingContent; save: number; className?: string; href: string; service?: 'funnel' }) {
  return (
    <div className={clsx('relative z-[1] flex w-full max-w-[460px] flex-col gap-3', className)}>
      <LeadButton direct service={service} className="group flex max-w-[88%] items-center gap-3 self-start rounded-[26px] rounded-bl-md border border-[#14532d]/15 bg-white px-4 py-3 text-left text-fg shadow-[0_14px_30px_-22px_rgba(20,83,45,.7)] transition-transform hover:-translate-y-0.5">
        <TgIcon size={26} className="shrink-0" />
        <span className="min-w-0"><span className="block text-[15px] font-bold leading-tight">Order on Telegram · <CountUp prefix="$" value={c.priceTg} /></span><span className="block text-[12.5px] text-fg-3">Chat with a real agent</span></span>
        <ArrowRight size={17} className="shrink-0 text-[#16a34a] transition-transform group-hover:translate-x-0.5" />
      </LeadButton>
      <div className="relative max-w-[88%] self-end">
        {save > 0 && <span className="absolute -left-3 -top-3 z-10 -rotate-6 whitespace-nowrap rounded-lg bg-[#c6f36b] px-2.5 py-1 text-[11.5px] font-extrabold text-[#052e16] shadow-md">Save ${save}</span>}
        <a href={href} className="group flex items-center gap-3 rounded-[26px] rounded-br-md bg-[#14532d] px-4 py-3 text-white shadow-[0_18px_36px_-18px_rgba(20,83,45,.9)] transition-transform hover:-translate-y-0.5">
          <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-white/15"><Globe size={17} /></span>
          <span className="min-w-0"><span className="block text-[15px] font-bold leading-tight">Order on Website · <CountUp prefix="$" value={c.priceWeb} /> <s className="text-[12px] font-medium opacity-60">${c.priceTg}</s></span><span className="block text-[12.5px] text-white/75">Pay with crypto, instant order</span></span>
          <ArrowRight size={17} className="shrink-0 text-[#c6f36b] transition-transform group-hover:translate-x-0.5" />
        </a>
        <p className="mt-1 text-right text-[11px] text-fg-3">✓✓ read</p>
      </div>
      {!!c.viewerFloor && <div className="pt-1"><ViewerBadge theme={c.theme} floor={c.viewerFloor} /></div>}
    </div>
  );
}
