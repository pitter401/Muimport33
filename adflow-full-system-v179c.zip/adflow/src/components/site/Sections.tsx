'use client';
import { trackAtc, pageLine } from './track';

import { useEffect, useRef, useState } from 'react';
import { motion, useInView, useScroll, useSpring, useReducedMotion, useMotionValueEvent } from 'framer-motion';
import { Plus, CheckCheck, Eye, Paperclip, ArrowRight } from 'lucide-react';
import clsx from 'clsx';
import { TgIcon } from './Telegram';
import { LeadButton } from './LeadModal';
import type { LandingContent } from '@/server/content';

/** "X+ people are viewing this" social-proof badge. Polls /api/viewers every 30s. */
export function ViewerBadge({ theme, floor }: { theme: string; floor: number }) {
  const [count, setCount] = useState(floor);
  
  // stable visitor token from sessionStorage so the same tab doesn't double-count on re-renders
  const tok = useRef<string>('');
  useEffect(() => {
    if (!floor) return;
    if (!tok.current) {
      try { tok.current = sessionStorage.getItem('af_vtok') || ''; } catch { /* */ }
      if (!tok.current) {
        tok.current = Math.random().toString(36).slice(2) + Date.now().toString(36);
        try { sessionStorage.setItem('af_vtok', tok.current); } catch { /* */ }
      }
    }
    let alive = true;
    const poll = async () => {
      try {
        const r = await fetch(`/api/viewers?theme=${encodeURIComponent(theme)}&tok=${encodeURIComponent(tok.current)}`);
        if (!r.ok || !alive) return;
        const d = await r.json();
        if (typeof d.count === 'number' && d.count > 0) {
          setCount(d.count);
        }
      } catch { /* */ }
    };
    poll();
    const id = setInterval(poll, 30_000);
    return () => { alive = false; clearInterval(id); };
  }, [theme, floor]);

  if (!floor) return null;
  // styled per landing design, using that design's own colour tokens
  const k = (['purple', 'gold', 'green', 'blue'].includes(theme) ? theme : 'purple') as 'purple' | 'gold' | 'green' | 'blue';
  const box = {
    purple: 'border border-violet/35 bg-plum-2/80 backdrop-blur-md shadow-[0_8px_24px_-12px_rgb(var(--p)/.7)]',
    gold: 'border border-violet/45 bg-void/70',
    green: 'bg-plum-2',
    blue: 'border border-edge bg-white shadow-[0_6px_18px_-10px_rgb(var(--p)/.45)]',
  }[k];
  const accent = k === 'purple' ? 'text-lilac' : 'text-violet';
  const dot = k === 'purple' ? 'bg-lilac' : 'bg-violet';
  const num = {
    purple: 'font-semibold',
    gold: 'font-display text-[15.5px] italic sm:text-[16.5px]',
    green: 'font-bold',
    blue: 'font-semibold',
  }[k];
  return (
    <div className={clsx('inline-flex items-center gap-2 rounded-full px-3.5 py-2 sm:px-4', box)}>
      <span className="relative flex h-2 w-2 shrink-0">
        <span className={clsx('absolute inline-flex h-full w-full animate-ping rounded-full opacity-60', dot)} />
        <span className={clsx('relative inline-flex h-2 w-2 rounded-full', dot)} />
      </span>
      <Eye className={clsx('h-[15px] w-[15px] shrink-0', accent)} strokeWidth={2.2} />
      <span className={clsx('text-[13px] leading-none text-fg-2 sm:text-[13.5px]', k === 'green' && 'font-medium')}>
        <span className={clsx('tabular-nums', accent, num)}>{count}+ people</span> are viewing this
      </span>
    </div>
  );
}

const ease = [0.16, 1, 0.3, 1] as const;

export function Reveal({ children, className, delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) {
  const reduce = useReducedMotion();
  return (
    <motion.div className={className} initial={reduce ? false : { opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: '-80px' }} transition={{ duration: 0.8, delay, ease }}>
      {children}
    </motion.div>
  );
}

/** PageView + ViewContent — sent only after the visitor has really looked at the page for `delay` seconds
 *  (time counts only while the tab is visible). Server dedups by visitor id. */
export function VcBeacon({ theme, delay = 5 }: { theme: string; delay?: number }) {
  useEffect(() => {
    const need = Math.max(0.8, delay) * 1000;
    let seen = 0, since = document.visibilityState === 'visible' ? Date.now() : 0, sent = false;
    const fire = () => {
      if (sent) return; sent = true;
      fetch('/api/vc', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ theme, url: location.href, seen: Math.round(seen / 1000), line: pageLine() }), keepalive: true }).catch(() => {});
    };
    const tick = () => {
      if (sent) return;
      if (since) { seen += Date.now() - since; since = document.visibilityState === 'visible' ? Date.now() : 0; }
      if (seen >= need) fire();
    };
    const onVis = () => { tick(); if (document.visibilityState === 'visible' && !since) since = Date.now(); };
    const iv = setInterval(tick, 500);
    document.addEventListener('visibilitychange', onVis);
    // "Order on website" links go straight to /order (no popup) → AddToCart too
    const onClick = (e: MouseEvent) => { const el = (e.target as Element | null)?.closest?.('a[href^="/order"]'); if (el) trackAtc('website'); };
    document.addEventListener('click', onClick, true);
    return () => { clearInterval(iv); document.removeEventListener('visibilitychange', onVis); document.removeEventListener('click', onClick, true); };
  }, [theme, delay]);
  return null;
}

export function Logo({ brand, src }: { brand: string; src?: string }) {
  // eslint-disable-next-line @next/next/no-img-element
  if (src) return <img src={src} alt="" width={30} height={30} className="h-[30px] w-[30px] shrink-0 rounded-[9px] object-contain" />;
  return (
    <span className="grid h-7 w-7 place-items-center rounded-[9px] bg-gradient-to-br from-violet-soft to-orchid font-display text-[14px] font-bold text-onp shadow-[0_6px_18px_-6px_rgb(var(--p)/.8)]">
      {brand.trim().charAt(0).toUpperCase() || 'A'}
    </span>
  );
}

export function Nav({ c }: { c: LandingContent }) {
  const [scrolled, setScrolled] = useState(false);
  const { scrollY } = useScroll();
  useMotionValueEvent(scrollY, 'change', v => setScrolled(v > 20));
  return (
    <header className="fixed inset-x-0 top-[var(--bar-h)] z-50 bg-gradient-to-b from-void via-void/80 to-transparent px-3 pb-2 pt-3">
      <div className={clsx('mx-auto flex h-14 max-w-[1120px] items-center gap-8 rounded-full px-4 pl-5 transition-all duration-300',
        scrolled ? 'glass border border-edge' : 'border border-transparent')}>
        <a href="#" className="flex items-center gap-2.5 font-display text-[19px] font-semibold tracking-[-0.03em]"><Logo brand={c.brand} src={c.logo} />{c.brand}</a>
        <nav className="hidden gap-7 text-[14px] text-fg-2 md:flex">
          <a href="#chat" className="transition-colors hover:text-fg">How it works</a>
          <a href="#why" className="transition-colors hover:text-fg">Why us</a>
          <a href="#faq" className="transition-colors hover:text-fg">Questions</a>
        </nav>
        <LeadButton className="btn-primary ml-auto whitespace-nowrap px-4 py-2.5 text-[14px] sm:px-5"><TgIcon size={17} className="[&>circle]:fill-white/20" /><span className="sm:hidden">Order now</span><span className="hidden sm:inline">Order on Telegram</span></LeadButton>
      </div>
    </header>
  );
}

export function Marquee({ c }: { c: LandingContent }) {
  const items = [...c.payment.split(/,| or /).map(x => x.trim()).filter(Boolean), `Delivery within ${c.delivery}`, 'Top-ups on Telegram', 'Business Manager setup help', 'Conversions API tracking', 'One dedicated agent'];
  const row = [...items, ...items];
  return (
    <div className="relative overflow-hidden border-y border-edge bg-plum/40 py-5 [mask-image:linear-gradient(to_right,transparent,#000_12%,#000_88%,transparent)]">
      <div className="flex w-max animate-marquee gap-12 whitespace-nowrap text-[15px] text-fg-2">
        {row.map((t, i) => <span key={i} className="flex items-center gap-12">{t}<span className="h-1.5 w-1.5 rotate-45 bg-violet-soft/60" /></span>)}
      </div>
    </div>
  );
}

export function ChatDemo({ c }: { c: LandingContent }) {
  const CHAT: { me?: boolean; t: string; img?: boolean }[] = [
    { me: true, t: 'Hi! I want an agency ad account. My code: L-8KQ2M' },
    { t: `Hi Amit, I’m ${c.agentName}. Do you already have a Business Manager?` },
    { me: true, t: 'Yes. BM ID 1029384756' },
    { t: `Perfect. It’s $${c.priceAccount} per account. ${c.payment}, whichever is easier.` },
    { me: true, t: 'Paid ', img: true },
    { t: 'Received. Your account is now shared to your BM. You can launch ' },
  ];
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: '-120px' });
  const reduce = useReducedMotion();
  const [n, setN] = useState(reduce ? CHAT.length : 0);
  const [typing, setTyping] = useState(false);
  useEffect(() => {
    if (!inView || reduce) return;
    let i = 0, alive = true;
    const step = () => {
      if (!alive || i >= CHAT.length) { setTyping(false); return; }
      const agent = !CHAT[i].me;
      setTyping(agent);
      setTimeout(() => { if (!alive) return; setTyping(false); i++; setN(i); setTimeout(step, 450); }, agent ? 1100 : 650);
    };
    step();
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [inView, reduce]);

  const steps = [
    ['Answer three questions', 'Business Manager, what you advertise, daily budget. Under a minute.'],
    ['Send one message', 'Telegram opens with your message typed. Press Send and your agent replies.'],
    ['Pay your way', `${c.payment}, then share your Business Manager ID.`],
    ['Launch', `The account appears in your Business Manager within ${c.delivery}. Top-ups happen in the same chat.`],
  ];

  return (
    <section id="chat" className="relative isolate scroll-mt-24 overflow-hidden py-16 sm:py-28">
      <div className="pointer-events-none absolute left-1/2 top-1/3 -z-10 h-[500px] w-[800px] -translate-x-1/2 rounded-full bg-[radial-gradient(closest-side,rgb(var(--p)/.12),transparent)]" />
      <div className="wrap grid items-center gap-14 lg:grid-cols-[1fr_440px] lg:gap-20">
        <div>
          <Reveal><h2 className="h2 max-w-[15ch]">{c.chatTitle}</h2></Reveal>
          <Reveal delay={0.1}><p className="mt-5 max-w-[48ch] text-[17px] leading-relaxed text-fg-2">{c.chatText}</p></Reveal>
          <ProcessSteps steps={steps} />
        </div>
        <Reveal delay={0.1}>
          <div ref={ref} className="relative mx-auto w-full max-w-[400px]">
            <div className="absolute -inset-6 -z-10 rounded-[48px] bg-[radial-gradient(closest-side,rgb(var(--p)/.22),transparent)]" />
            <div className="overflow-hidden rounded-[36px] border border-edge bg-plum" style={{ boxShadow: 'var(--shadow)' }}>
              <div className="flex items-center gap-3 border-b border-edge bg-plum-2 px-5 py-4">
                <div className="grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-violet to-orchid font-display text-[15px] font-bold text-onp">{c.agentName.charAt(0)}</div>
                <div className="flex-1">
                  <p className="text-[15px] font-semibold">{c.agentName} from {c.brand}</p>
                  <p className="text-[12.5px] text-violet">{typing ? 'typing…' : 'online'}</p>
                </div>
              </div>
              <div className="flex min-h-[420px] flex-col justify-end gap-2 bg-[radial-gradient(ellipse_at_top,rgb(var(--p)/.08),transparent_60%)] p-4">
                {CHAT.slice(0, n).map((m, i) => (
                  <motion.div key={i} initial={{ opacity: 0, y: 12, scale: 0.96 }} animate={{ opacity: 1, y: 0, scale: 1 }} transition={{ type: 'spring', damping: 22, stiffness: 300 }}
                    className={clsx('max-w-[82%] rounded-[18px] px-3.5 py-2 text-[14px] leading-snug', m.me ? 'self-end rounded-br-md bg-gradient-to-br from-violet to-violet-deep text-onp' : 'self-start rounded-bl-md bg-plum-3 text-fg')}>
                    {m.img && <span className="mb-1.5 flex items-center gap-2 rounded-xl bg-white/15 px-3 py-2 text-[12.5px]"><Paperclip size={14} className="shrink-0" />payment-screenshot.jpg</span>}
                    {m.t}
                    <span className={clsx('ml-2 inline-flex translate-y-0.5 items-center gap-0.5 text-[10.5px]', m.me ? 'opacity-70' : 'text-fg-3')}>
                      {`10:${String(12 + i * 2).padStart(2, '0')}`}{m.me && <CheckCheck size={13} />}
                    </span>
                  </motion.div>
                ))}
                {typing && (
                  <div className="flex w-fit gap-1 self-start rounded-[18px] rounded-bl-md bg-plum-3 px-4 py-3">
                    {[0, 1, 2].map(d => <motion.span key={d} className="h-1.5 w-1.5 rounded-full bg-fg-2" animate={{ opacity: [0.3, 1, 0.3], y: [0, -3, 0] }} transition={{ repeat: Infinity, duration: 0.9, delay: d * 0.15 }} />)}
                  </div>
                )}
              </div>
              <div className="flex items-center gap-2 border-t border-edge bg-plum-2 px-4 py-3">
                <div className="flex-1 rounded-full bg-ov/[0.06] px-4 py-2.5 text-[13.5px] text-fg-3">Message</div>
                <div className="grid h-10 w-10 place-items-center rounded-full bg-violet text-onp">
                  <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="m22 2-7 20-4-9-9-4Z" /><path d="M22 2 11 13" /></svg>
                </div>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function ProcessSteps({ steps }: { steps: string[][] }) {
  const ref = useRef<HTMLOListElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start 80%', 'end 55%'] });
  const h = useSpring(scrollYProgress, { stiffness: 120, damping: 25 });
  return (
    <ol ref={ref} className="relative mt-10 grid gap-7 pl-12">
      <span className="absolute bottom-2 left-[15px] top-2 w-px bg-ov/10" />
      <motion.span className="absolute left-[15px] top-2 w-px origin-top bg-gradient-to-b from-violet via-orchid to-violet" style={{ scaleY: h, bottom: 8 }} />
      {steps.map(([t, d], i) => (
        <Reveal key={t} delay={i * 0.06} className="relative">
          <li className="list-none">
            <span className="absolute -left-12 top-0 grid h-8 w-8 place-items-center rounded-full border border-violet/50 bg-void font-display text-[13px] font-semibold text-lilac shadow-[0_0_20px_-4px_rgb(var(--p)/.8)]">{i + 1}</span>
            <h3 className="text-[18px] font-semibold tracking-[-0.01em]">{t}</h3>
            <p className="mt-1.5 max-w-[46ch] text-[15px] leading-relaxed text-fg-2">{d}</p>
          </li>
        </Reveal>
      ))}
    </ol>
  );
}

export function Why({ c }: { c: LandingContent }) {
  const rows = [
    [`Live within ${c.delivery}`, 'Counted from confirmed payment. Your agent shares the account to your Business Manager in the same chat.'],
    ['One agent, start to finish', 'The person who sells you the account supports it after launch.'],
    ['Top-ups in the same chat', 'Add funds through your agent without placing a new order.'],
    ['No Business Manager yet?', 'We walk you through creating one. It is free and takes minutes.'],
    ['Clear pricing', `$${c.priceAccount} per account. You still pay Meta for your ads, but top-ups go through us${Number(c.topupFee) ? ` for a ${c.topupFee}% fee` : ''}, so you save the 18% GST.`],
  ];
  return (
    <section id="why" className="scroll-mt-24 border-t border-edge py-16 sm:py-28">
      <div className="wrap grid gap-10 lg:grid-cols-[.8fr_1.2fr] lg:gap-16">
        <Reveal>
          <h2 className="h2 max-w-[13ch]">{c.whyTitle}</h2>
          <LeadButton className="btn-primary mt-8 hidden px-6 py-3.5 text-[15px] lg:inline-flex"><TgIcon size={18} className="[&>circle]:fill-white/20" />{c.account.cta}<ArrowRight size={16} /></LeadButton>
        </Reveal>
        <ol className="divide-y divide-edge border-y border-edge">
          {rows.map(([t, d], i) => (
            <Reveal key={t} delay={i * 0.04}>
              <li className="grid list-none grid-cols-[36px_1fr] gap-x-4 py-6 sm:grid-cols-[48px_1fr] sm:py-7">
                <span className="pt-0.5 font-display text-[14px] font-semibold tabular-nums text-lilac">{String(i + 1).padStart(2, '0')}</span>
                <span>
                  <span className="block text-[18px] font-semibold tracking-[-0.01em] sm:text-[19px]">{t}</span>
                  <span className="mt-1.5 block max-w-[52ch] text-[15px] leading-relaxed text-fg-2">{d}</span>
                </span>
              </li>
            </Reveal>
          ))}
        </ol>
      </div>
    </section>
  );
}

export function Faq({ c }: { c: LandingContent }) {
  if (!c.faq.length) return null;
  return (
    <section id="faq" className="scroll-mt-24 py-16 sm:py-28">
      <div className="wrap grid gap-12 lg:grid-cols-[.8fr_1.2fr]">
        <Reveal><h2 className="h2 max-w-[11ch]">Questions before you start</h2></Reveal>
        <div className="grid gap-3">
          {c.faq.map(([q, a], i) => (
            <Reveal key={q + i} delay={i * 0.04}>
              <details className="glass group rounded-2xl border border-edge px-6 transition-colors open:border-violet/40">
                <summary className="flex cursor-pointer list-none items-center justify-between gap-6 py-5 text-[16.5px] font-semibold [&::-webkit-details-marker]:hidden">
                  {q}<span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-ov/[0.07] transition-transform duration-300 group-open:rotate-45 group-open:bg-violet group-open:text-onp"><Plus size={16} /></span>
                </summary>
                <p className="max-w-[62ch] pb-6 text-[15px] leading-relaxed text-fg-2">{a}</p>
              </details>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

export function FinalCta({ c }: { c: LandingContent }) {
  return (
    <section className="px-3 pb-3 sm:px-5 sm:pb-5">
      <div className="relative isolate overflow-hidden rounded-[36px] px-6 py-16 text-center text-white sm:py-28">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_90%_80%_at_50%_100%,rgb(var(--band1))_0%,rgb(var(--band2))_45%,#05040a_90%)]" />
        <div className="absolute left-1/2 top-[60%] -z-10 h-[360px] w-[680px] -translate-x-1/2 rounded-full bg-[radial-gradient(closest-side,rgb(var(--a)/.2),transparent)]" />
        <Reveal><h2 className="mx-auto max-w-[15ch] font-display text-[40px] font-semibold leading-[1.04] tracking-[-0.04em] sm:text-[68px]">{c.ctaTitle}</h2></Reveal>
        <Reveal delay={0.1}><p className="mx-auto mt-6 max-w-[44ch] text-[17px] text-white/70">{c.ctaText}</p></Reveal>
        <Reveal delay={0.2} className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <LeadButton className="btn bg-white px-8 py-4 text-[16px] text-[#0b0b14] hover:bg-white/90">{c.account.cta} for ${c.priceAccount}</LeadButton>
          <LeadButton service="funnel" className="btn border border-white/25 bg-white/5 px-8 py-4 text-[16px] text-white hover:bg-white/10">{c.funnel.cta} for ${c.priceFunnel}/mo</LeadButton>
        </Reveal>
      </div>
      <footer className="wrap flex flex-col gap-3 py-8 text-[13.5px] text-fg-3 sm:flex-row sm:items-center sm:justify-between">
        <p className="flex items-center gap-2.5 font-display text-[16px] font-semibold text-fg"><Logo brand={c.brand} src={c.logo} />{c.brand}</p>
        <p className="flex flex-wrap gap-x-4 gap-y-1">
          {c.webOn && <a href="/account" className="font-medium text-fg-2 hover:text-fg">My account · Top up</a>}{c.channel && <a href={c.channel} target="_blank" rel="noopener" className="hover:text-fg">Telegram channel</a>}
          <span>© {new Date().getFullYear()} {c.brand}. {c.footer}</span>
        </p>
      </footer>
    </section>
  );
}
