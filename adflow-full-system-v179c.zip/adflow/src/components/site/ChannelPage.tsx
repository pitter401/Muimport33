import type { Metadata } from 'next';
import { landingContent } from '@/server/content';
import { getSettings } from '@/server/settings';
import { shareMeta } from '@/server/site';
import { THEME_VARS, themeCss } from './themes';
import { ChannelLanding } from './designs/Channel';
import { VcBeacon } from './Sections';
import { LeadModalProvider, ChatFab, WaFab } from './LeadModal';
import { ChanFallback } from './ChanFallback';
import { chanCopy, orderLink, waLink, type ChanLine } from '@/server/chanads';

const nameOf = (s: ReturnType<typeof getSettings>) => (s.channel_name || s.brand_name || '').trim();

export async function channelMetadata(line?: ChanLine): Promise<Metadata> {
  const s = getSettings();
  const title = `${nameOf(s)} · ${line === 'funnel' ? 'Landing page + funnel' : line === 'premium' ? 'Premium ad accounts' : line ? 'Agency ad accounts' : 'Private Telegram channel'}${line ? ' · Telegram channel' : ''}`;
  const description = line ? chanCopy(s, line).sub : 'Agency work, WhatsApp API 2K setup, how agency ad accounts are made, ad accounts and funnel setup. Free to join — services are paid.';
  return { title, description, robots: { index: !line, follow: true }, alternates: { canonical: line ? `/${line}/telegram` : '/telegram' }, ...(await shareMeta({ title, description, line: line === 'funnel' ? 'funnel' : 'agency', url: line ? `/${line}/telegram` : '/telegram' }, s)) };
}

/** /telegram — channel page in one of the four landing looks. Joins from it count on the Agency pixel (Subscribe).
 *  line (v111): /agency|premium|funnel/telegram — the channel-ad pages: their own text, the bot DMs the offer on joining. */
export function ChannelPage({ theme, line }: { theme: string; line?: ChanLine }) {
  const s = getSettings();
  const t = theme in THEME_VARS ? theme : 'purple';
  const c = landingContent(t, s, line === 'funnel' ? 'funnel' : 'agency', line === 'premium' && s.premium_on === '1' ? 'premium' : '');
  // v118: every channel page offers the website order as a card next to Join (with the website price and the saving)
  const ln: ChanLine = line || 'agency';
  const ord = orderLink(s, ln, false);
  const order = ord ? { order: { href: ord, label: 'Order on website' } } : {};
  // v118: the channel-ad pages sell like the landing page: same headline + sub, a selling button that opens the channel
  const sell = line ? { hero: { h: c.headline, a: c.accent, sub: c.sub }, cta: line === 'funnel' ? 'Join Telegram channel & buy funnel setup' : line === 'premium' ? 'Join Telegram channel & buy Premium ad account' : 'Join Telegram channel & buy agency ad account' } : {};
  const ch = line
    ? { href: `/j?line=${line}&src=ad`, name: nameOf(s), ...sell, copy: chanCopy(s, line), ...order, ...(waLink(s) ? { wa: waLink(s) } : {}) }
    : { href: '/j?line=agency&src=page', name: nameOf(s), ...order, ...(waLink(s) ? { wa: waLink(s) } : {}) };
  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: themeCss(t) + ':root{--bar-h:0px}' }} />
      {/* v121: same floating Telegram chat + WhatsApp buttons and the same "Telegram didn't open?" fallback as the landing pages (same admin switches) */}
      <LeadModalProvider theme={c.theme} defaultService={line === 'funnel' ? 'funnel' : 'account'} autoMsg={c.autoMsg} titles={{ account: c.account.title, funnel: c.funnel.title }}
        web={{ on: c.webOn, priceWeb: c.priceWeb, priceTg: c.priceTg }} chat={{ on: c.chatOn, text: c.chatBtnText }} fallback={c.fallback}>
        <VcBeacon theme={t} delay={c.vcDelay} />
        <ChannelLanding c={c} ch={ch} />
        {c.chatOn && <ChatFab text={c.chatBtnText} lift />}
        {c.wa?.fab && <WaFab link={c.wa.link} above={c.chatOn} lift />}
        {c.fallback.on && <ChanFallback fallback={c.fallback} order={ord} />}
      </LeadModalProvider>
    </>
  );
}
