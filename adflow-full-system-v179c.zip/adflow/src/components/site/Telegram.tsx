'use client';

import { motion, useReducedMotion } from 'framer-motion';
import { ClipboardList, Zap, Gift } from 'lucide-react';
import { useEffect } from 'react';
import clsx from 'clsx';
import type { LandingContent } from '@/server/content';

const ease = [0.22, 1, 0.36, 1] as const;

/** Telegram paper-plane mark (shows people the order happens on Telegram). */
export function TgIcon({ size = 18, className }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden className={className}>
      <circle cx="12" cy="12" r="12" fill="#229ED9" />
      <path fill="#fff" d="M5.4 11.7l11.1-4.3c.5-.2 1 .1.8.9l-1.9 8.9c-.1.6-.5.8-1 .5l-2.9-2.1-1.4 1.3c-.2.2-.3.3-.6.3l.2-2.9 5.3-4.8c.2-.2 0-.3-.3-.1l-6.6 4.1-2.8-.9c-.6-.2-.6-.6.1-.9z" />
    </svg>
  );
}

/** One plain line under the description: [Telegram logo] Order on Telegram · A real agent replies in minutes.
 *  Deliberately NOT styled like a button (no box, no border). */
export function TgPill({ c, className }: { c: LandingContent; className?: string }) {
  const reduce = useReducedMotion();
  return (
    <motion.p initial={reduce ? false : { opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.5, ease }}
      className={clsx('flex w-full max-w-full items-center gap-1 min-[375px]:gap-1.5 overflow-hidden whitespace-nowrap py-0.5 text-[12px] leading-none text-fg-2 min-[355px]:text-[12.5px] min-[375px]:text-[13px] min-[400px]:text-[14px] sm:gap-2 sm:text-[15px]', className)}>
      <TgIcon size={17} className="shrink-0" />
      <span className="font-semibold text-fg">{c.tgNote}</span>
      {c.tgNoteSub && <><span aria-hidden className="text-fg-3">·</span><span className="min-w-0 truncate">{c.tgNoteSub}</span></>}
    </motion.p>
  );
}

/** The 3-step "how ordering works" strip: form → Telegram → account live. */
export function TgSteps({ c, className, tone = 'default' }: { c: LandingContent; className?: string; tone?: 'default' | 'light' | 'serif' }) {
  const reduce = useReducedMotion();
  const icons = [<ClipboardList key="a" size={20} />, <TgIcon key="b" size={22} />, <Zap key="c" size={20} />];
  return (
    <div className={clsx('mx-auto w-full max-w-[1100px]', className)}>
      <p className={clsx('mb-3 text-center text-[12.5px] font-semibold uppercase tracking-[0.14em] text-fg-3', tone === 'serif' && 'font-display normal-case tracking-[0.02em] text-[15px] italic')}>
        How ordering works
      </p>
      <ol className={clsx('grid gap-2.5 sm:grid-cols-3 sm:gap-3')}>
        {c.tgSteps.slice(0, 3).map((t, i) => (
          <motion.li key={i}
            initial={reduce ? false : { opacity: 0, y: 14 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: '-40px' }}
            transition={{ duration: 0.6, delay: i * 0.1, ease }}
            className={clsx('relative flex items-center gap-3 border px-4 py-3.5',
              tone === 'light' ? 'rounded-xl border-edge bg-white shadow-sm' : tone === 'serif' ? 'rounded-none border-violet/25 bg-ov/[0.02]' : 'rounded-2xl border-edge bg-ov/[0.04] backdrop-blur',
              i === 1 && 'border-[#229ED9]/50 bg-[#229ED9]/[0.08]')}>
            <span className={clsx('grid h-10 w-10 shrink-0 place-items-center rounded-full', i === 1 ? 'bg-[#229ED9]/15' : 'bg-violet/15 text-violet')}>{icons[i]}</span>
            <span className="min-w-0">
              <span className="block text-[11.5px] font-semibold uppercase tracking-[0.1em] text-fg-3">Step {i + 1}</span>
              <span className="block text-[14.5px] font-medium leading-snug text-fg">{t}</span>
            </span>
          </motion.li>
        ))}
      </ol>
    </div>
  );
}

/** Thin bar above the nav: the Telegram channel (when set) or "Trusted by 1,000+ advertisers". */
/** Came from a retargeting ad (?rt=1): remember it for 7 days, so the offer stays when they come back or open the order page. */
function useRtCookie(on: boolean) {
  useEffect(() => {
    try { if (on && /[?&]rt=1(?:[&#]|$)/.test(location.search)) document.cookie = 'af_rt=1; path=/; max-age=' + 7 * 86400 + '; samesite=lax'; } catch { /* ignore */ }
  }, [on]);
}

export function ProofBar({ c }: { c: LandingContent }) {
  useRtCookie(true);
  // this week's retargeting offer replaces the top bar
  if (c.deal) {
    return (
      <div data-deal-bar className="fixed inset-x-0 top-0 z-[60] border-b border-white/15 bg-[linear-gradient(90deg,rgb(var(--pd)/.92),rgb(var(--p)/.9)_55%,rgb(var(--a)/.92))] backdrop-blur-xl">
        <div className="mx-auto flex h-[var(--bar-h)] w-full max-w-3xl items-center justify-center gap-2 px-3 text-center text-[12.5px] font-semibold leading-tight text-white sm:text-[13.5px]">
          <span className="min-w-0 [text-wrap:balance]"><Gift size={15} strokeWidth={2.2} className="mr-1.5 inline-block -translate-y-px align-middle text-[#fde68a]" aria-hidden />{c.deal.text}</span>
        </div>
      </div>
    );
  }
  if (c.chanBar) {
    const b = c.chanBar;
    return (
      <a href={b.href} target="_blank" rel="noopener" data-chan-bar className="fixed inset-x-0 top-0 z-[60] block border-b border-white/15 bg-[linear-gradient(90deg,rgb(var(--pd)/.74),rgb(var(--p)/.7)_55%,rgb(var(--a)/.74))] backdrop-blur-xl backdrop-saturate-150">
        <span className="flex h-[var(--bar-h)] w-full items-center justify-center gap-2 px-3 text-[12.5px] font-semibold text-white sm:text-[13.5px]">
          <svg width="18" height="18" viewBox="0 0 24 24" className="shrink-0" aria-hidden><circle cx="12" cy="12" r="12" fill="#fff" fillOpacity=".22" /><path d="M5.5 11.8l10.6-4.1c.5-.2.9.1.8.8l-1.8 8.5c-.1.6-.5.7-1 .5l-2.8-2-1.3 1.3c-.2.2-.3.3-.6.3l.2-2.9 5.2-4.7c.2-.2 0-.3-.3-.1l-6.4 4-2.8-.9c-.6-.2-.6-.6.2-.7z" fill="#fff" /></svg>
          <span className="min-w-0 truncate">{b.text}</span>
          <span className="shrink-0 rounded-full bg-white px-2.5 py-0.5 text-[12px] font-bold text-[rgb(var(--pd))]">{b.cta} →</span>
        </span>
      </a>
    );
  }
  if (!c.proofText) return null;
  return (
    <div className="fixed inset-x-0 top-0 z-[60] bg-[linear-gradient(90deg,#0b1220,#13314d_50%,#0b1220)] shadow-[0_1px_0_rgba(255,255,255,.08)]">
      <div className="flex h-[var(--bar-h)] w-full items-center justify-center gap-2 px-3 text-[12.5px] font-medium text-white sm:text-[13.5px]">
        <span className="h-2 w-2 shrink-0 rounded-full bg-[#4ade80]" />
        <span className="min-w-0 truncate">{c.proofText}</span>
      </div>
    </div>
  );
}
