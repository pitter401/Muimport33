'use client';

import { useState } from 'react';
import clsx from 'clsx';

const WaIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" /></svg>
);

/** v131 community page: their WhatsApp number first (so the chat they start later is matched to this ad visit), then the community link.
 *  Drawn inside the landing hero, so it takes the page theme (dark = purple/gold heroes, light = blue/green). */
export function WaJoinForm({ line, cc, off, dark, btn }: { line: string; cc: string; off?: boolean; dark?: boolean; btn: string }) {
  const [phone, setPhone] = useState(''); const [busy, setBusy] = useState(false); const [err, setErr] = useState('');
  async function go(e: React.FormEvent) {
    e.preventDefault();
    setErr(''); setBusy(true);
    try {
      const r = await fetch('/api/wajoin', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ phone, line, page_url: location.href }) });
      const j = await r.json().catch(() => ({}));
      if (!j.ok || !j.link) { setErr(j.error || 'Something went wrong. Try again.'); return; }
      location.href = j.link;
    } catch { setErr('Network error. Try again.'); } finally { setBusy(false); }
  }
  if (off) return <p id="wa-join" className={clsx('scroll-mt-28 rounded-2xl px-4 py-3 text-[14.5px]', dark ? 'bg-white/10 text-white/85' : 'bg-plum-2 text-fg-2')}>The WhatsApp community is not open right now. Please try again later.</p>;
  return (
    <form id="wa-join" onSubmit={go} data-wa-join className="w-full max-w-[420px] scroll-mt-28 text-left">
      <label className={clsx('mb-1.5 block text-[14px] font-semibold', dark ? 'text-white/90' : 'text-fg')} htmlFor="wa-phone">Your WhatsApp number</label>
      <div className={clsx('flex items-center overflow-hidden rounded-2xl border', dark ? 'border-white/25 bg-white/10 focus-within:border-white/70' : 'border-edge bg-white focus-within:border-violet')}>
        <span className={clsx('pl-4 pr-1 text-[16px]', dark ? 'text-white/60' : 'text-fg-3')}>+{cc}</span>
        <input id="wa-phone" inputMode="tel" autoComplete="tel" required value={phone} onChange={e => setPhone(e.target.value.replace(/[^\d+ ]/g, ''))} placeholder="98765 43210"
          className={clsx('min-w-0 flex-1 bg-transparent px-2 py-3.5 text-[17px] outline-none', dark ? 'text-white placeholder:text-white/40' : 'text-fg placeholder:text-fg-3')} />
      </div>
      {err && <p className={clsx('mt-2 text-[13.5px]', dark ? 'text-[#fca5a5]' : 'text-[#d93025]')}>{err}</p>}
      <button type="submit" disabled={busy} className={clsx(btn, 'mt-3 disabled:opacity-60')}><WaIcon />{busy ? 'Opening…' : 'Join WhatsApp community'}</button>
      <p className={clsx('mt-2 text-[13px]', dark ? 'text-white/65' : 'text-fg-3')}>Use the same number you use on WhatsApp.</p>
    </form>
  );
}
