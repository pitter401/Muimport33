import { shareMeta } from '@/server/site';
import type { Metadata } from 'next';
import { getSettings } from '@/server/settings';
import { landingContent } from '@/server/content';
import { productList } from '@/server/products';
import { themeCss } from './themes';
import { ProductsLanding } from './designs/Premium';
import { ProofBar } from './Telegram';
import { WaFab } from './LeadModal';

export async function productsMetadata(): Promise<Metadata> {
  const s = getSettings();
  const title = `Products — ${s.brand_name}`;
  const description = `All ${s.brand_name} products: agency ad accounts, Premium ad accounts, full access ad accounts, Facebook account + Business Manager setup, ad account top-ups and landing page + funnel setup.`;
  return { title, description, ...(await shareMeta({ title, description, url: '/products' }, s)) };
}

/** /products — the site's own look; /products/purple · blue · green · gold for each landing design */
export function ProductsView({ theme }: { theme: string }) {
  const s = getSettings();
  const c = landingContent(theme, s, 'agency');
  const note = `Pick what you need. Ad accounts are shared to your Business Manager within ${s.delivery_time || '1 hour'}. Pay with ${s.payment_text || 'USDT or UPI'}.`;
  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: themeCss(c.theme) + `:root{--bar-h:${c.deal ? '44px' : c.proofText || c.chanBar ? '36px' : '0px'}}` }} />
      {/* v135: same as the landing pages — Telegram channel bar on top (the bot makes each visitor their own join-request link) + WhatsApp community button */}
      <ProofBar c={c} />
      <ProductsLanding c={c} products={productList(s)} note={note} />
      {c.wa?.fab && <WaFab link={c.wa.link} above={false} />}
    </>
  );
}
