'use client';

import { useRef } from 'react';
import { motion, useMotionValue, useSpring, useTransform, useReducedMotion } from 'framer-motion';
import clsx from 'clsx';

/** Card with a cursor-following glow and a gentle 3D tilt. */
export function Spotlight({ children, className, tilt = true, glow = 'rgb(var(--ps) / .22)' }: { children: React.ReactNode; className?: string; tilt?: boolean; glow?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const reduce = useReducedMotion();
  const mx = useMotionValue(0.5), my = useMotionValue(0.5);
  const rx = useSpring(useTransform(my, [0, 1], [5, -5]), { stiffness: 160, damping: 18 });
  const ry = useSpring(useTransform(mx, [0, 1], [-6, 6]), { stiffness: 160, damping: 18 });

  function move(e: React.PointerEvent) {
    const el = ref.current; if (!el) return;
    const r = el.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
    mx.set(x); my.set(y);
    el.style.setProperty('--x', `${x * 100}%`);
    el.style.setProperty('--y', `${y * 100}%`);
  }
  function leave() { mx.set(0.5); my.set(0.5); }

  return (
    <motion.div
      ref={ref}
      onPointerMove={e => e.pointerType === 'mouse' && move(e)}
      onPointerLeave={leave}
      style={tilt && !reduce ? { rotateX: rx, rotateY: ry, transformPerspective: 1100 } : undefined}
      className={clsx('group/spot relative', className)}
    >
      <div
        className="pointer-events-none absolute inset-0 z-10 rounded-[inherit] opacity-0 transition-opacity duration-300 group-hover/spot:opacity-100"
        style={{ background: `radial-gradient(520px circle at var(--x,50%) var(--y,50%), ${glow}, transparent 45%)` }}
      />
      {children}
    </motion.div>
  );
}
