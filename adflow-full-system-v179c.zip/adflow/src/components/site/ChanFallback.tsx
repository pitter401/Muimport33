'use client';

import { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { X, Globe, ArrowRight } from 'lucide-react';
import clsx from 'clsx';
import { TgIcon } from './Telegram';
import { WaIcon, type Fallback } from './LeadModal';

/** v121 channel pages: same fallback as the landing pages. Tapped "Join" but no join request reached the channel
 *  (Telegram didn't open / not installed) → WhatsApp community (+ agent) and, when on, the website order. No Meta event. */
export function ChanFallback({ fallback, order }: { fallback: Fallback; order?: string | null }) {
  const [state, setState] = useState<'idle' | 'wait' | 'show'>('idle');
  const [round, setRound] = useState(0);
  const since = useRef(0);
  const joinHref = useRef('');
  const wa = fallback.wa || null, web = !!fallback.web && !!order;

  // any "Join" link on the page (they all go through /j) starts the watch
  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      const a = (e.target as HTMLElement | null)?.closest?.('a[href^="/j?"]') as HTMLAnchorElement | null;
      if (!a) return;
      joinHref.current = a.getAttribute('href') || '';
      since.current = Date.now();
      setState('wait'); setRound(r => r + 1);
    };
    document.addEventListener('click', onClick, true);
    return () => document.removeEventListener('click', onClick, true);
  }, []);

  useEffect(() => {
    if (state !== 'wait') return;
    let stop = false, n = 0;
    const t0 = since.current;
    const inApp = /FBAN|FBAV|FB_IAB|Instagram|FBIOS|Messenger/i.test(navigator.userAgent);
    const wait = (inApp ? Math.min(10, fallback.sec) : fallback.sec) * 1000;
    const show = () => { if (!stop) setState(s => (s === 'wait' ? 'show' : s)); };
    const check = async () => {
      if (stop) return;
      n++;
      try {
        const j = await (await fetch('/api/chanjoin?since=' + t0, { cache: 'no-store' })).json();
        if (stop) return;
        if (j.asked) { stop = true; setState('idle'); return; } // the join request arrived → nothing to show
      } catch { /* offline for a moment */ }
      if (Date.now() - t0 >= wait && document.visibilityState === 'visible') show();
      if (n >= 40) { stop = true; return; }
      setTimeout(() => void check(), 3000);
    };
    const first = setTimeout(() => void check(), Math.min(2500, Math.max(1000, wait - 1500)));
    const due = setTimeout(() => { if (document.visibilityState === 'visible') show(); }, wait);
    const onVis = () => { if (document.visibilityState === 'visible' && Date.now() - t0 > Math.min(5000, wait)) setTimeout(() => void check().then(() => { if (!stop) show(); }), 2500); };
    document.addEventListener('visibilitychange', onVis);
    return () => { stop = true; clearTimeout(first); clearTimeout(due); document.removeEventListener('visibilitychange', onVis); };
  }, [state, round, fallback.sec]);

  const close = () => setState('idle');
  return (
    <AnimatePresence>
      {state === 'show' && (
        <motion.div className="fixed inset-0 z-[100] flex items-end justify-center bg-black/70 backdrop-blur-md sm:items-center sm:p-6"
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onMouseDown={e => { if (e.target === e.currentTarget) close(); }}>
          <motion.div role="dialog" aria-modal="true" aria-label="Telegram didn’t open?" data-chan-fb
            className="relative w-full rounded-t-[28px] border border-edge bg-plum px-6 pb-[calc(24px+env(safe-area-inset-bottom))] pt-6 font-sans [box-shadow:var(--shadow)] sm:max-w-[480px] sm:rounded-[28px] sm:p-8"
            initial={{ y: 40, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 30, opacity: 0 }} transition={{ type: 'spring', damping: 30, stiffness: 320 }}>
            <button onClick={close} aria-label="Close" className="absolute right-4 top-4 grid h-9 w-9 place-items-center rounded-full bg-ov/[0.07] text-fg-2 hover:text-fg"><X size={18} /></button>
            <div className="pt-2">
              {wa ? <div className="mx-auto mb-4 grid h-14 w-14 place-items-center rounded-full bg-[#25D366]/15 text-[#25D366]"><WaIcon size={28} /></div>
                : <div className="mx-auto mb-4 grid h-14 w-14 place-items-center rounded-full bg-violet/20 text-lilac"><Globe size={26} /></div>}
              <h3 className="text-center font-display text-[24px] font-semibold leading-tight tracking-tight text-fg">Telegram didn’t open?</h3>
              <p className="mx-auto mt-2 max-w-[36ch] text-center text-[15px] leading-relaxed text-fg-2">{wa ? wa.text : fallback.text}</p>
              {wa && (
                <a href={wa.link} target="_blank" rel="noopener" onClick={close} data-fb-wa
                  className="mt-6 flex w-full items-center justify-center gap-2 rounded-full bg-[#25D366] px-6 py-3.5 text-[16px] font-semibold text-white shadow-[0_12px_30px_-12px_#25D366] transition-transform hover:scale-[1.02]">
                  <WaIcon size={21} /> Join on WhatsApp{wa.members ? <span className="rounded-full bg-white/25 px-2 py-0.5 text-[12.5px] font-bold">{wa.members}</span> : null}
                </a>
              )}
              {wa?.agent && (
                <a href={wa.agent} target="_blank" rel="noopener" onClick={close} data-fb-wa-agent
                  className="mt-3 flex w-full items-center justify-center gap-2 rounded-full border border-[#25D366]/60 px-6 py-3 text-[15px] font-semibold text-fg transition-colors hover:bg-[#25D366]/10">
                  <WaIcon size={18} className="text-[#25D366]" /> Chat with an agent on WhatsApp
                </a>
              )}
              {web && <a href={order!} onClick={close} data-fb-order className={clsx('btn-primary w-full', wa ? 'mt-3' : 'mt-6')}>Order on website <ArrowRight size={17} /></a>}
              {joinHref.current && (
                <a href={joinHref.current} target="_blank" rel="noopener" data-fb-retry className="mt-4 flex items-center justify-center gap-2 text-[14px] font-medium text-[#5fc3f5]">
                  <TgIcon size={17} /> I have Telegram — try again
                </a>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
