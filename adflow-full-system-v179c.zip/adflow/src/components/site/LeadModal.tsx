'use client';

import { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Check, X, ChevronLeft, Loader2, Globe, ArrowRight, MessageCircle } from 'lucide-react';
import clsx from 'clsx';
import { TgIcon } from './Telegram';
import { trackAtc, trackStep, pageLine, pageTier } from './track';

/** https://t.me/user?text=… → tg://resolve?domain=user&text=… (opens the Telegram app directly, also from Facebook/Instagram in-app browsers). */
function tgScheme(link: string) {
  try {
    const u = new URL(link);
    if (u.hostname !== 't.me') return null;
    const domain = u.pathname.replace(/^\//, '').split('/')[0];
    const q = new URLSearchParams({ domain });
    if (u.searchParams.get('text')) q.set('text', u.searchParams.get('text')!);
    if (u.searchParams.get('start')) q.set('start', u.searchParams.get('start')!);
    return 'tg://resolve?' + q.toString().replace(/\+/g, '%20');
  } catch { return null; }
}

/** `onFail` (website fallback on): when the Telegram app clearly didn't open on a phone, stay on our page instead of going to t.me. */
function openTelegram(link: string, onFail?: () => void) {
  const mobile = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
  const app = mobile ? tgScheme(link) : null;
  if (!app) { window.location.href = link; return; }
  window.location.href = app;
  // App not installed / blocked → fall back to the t.me page (or our website-order card)
  setTimeout(() => { if (!document.hidden) { if (onFail) onFail(); else window.location.href = link; } }, 1600);
}

const inAppBrowser = () => /FBAN|FBAV|FB_IAB|Instagram|FBIOS|Messenger/i.test(navigator.userAgent);
const PENDING = 'af_tg_pending';
type Pending = { t: string; link: string; service: Service; at: number };
const savePending = (p: Pending | null) => { try { if (p) sessionStorage.setItem(PENDING, JSON.stringify(p)); else sessionStorage.removeItem(PENDING); } catch { /* private mode */ } };
const readPending = (): Pending | null => {
  try { const p = JSON.parse(sessionStorage.getItem(PENDING) || 'null') as Pending | null; return p && p.t && Date.now() - p.at < 15 * 60000 ? p : null; } catch { return null; }
};

const digits = (v: string) => v.replace(/\D/g, '');
function validIndian(v: string) {
  let d = digits(v);
  if (d.length === 11 && d.startsWith('0')) d = d.slice(1);
  if (d.length === 12 && d.startsWith('91')) d = d.slice(2);
  return /^[6-9]\d{9}$/.test(d);
}

type Service = 'account' | 'funnel' | 'chat';
type Answers = { has_bm?: string; niche?: string; budget?: string };
export type WebChoice = { on: boolean; priceWeb: string | number; priceTg: string | number };
export type ChatBtn = { on: boolean; text: string };
export type Fallback = { on: boolean; web?: boolean; sec: number; text: string; priceFunnel?: string; wa?: { link: string; text: string; members: string; agent: string } | null };

const Ctx = createContext<(s?: Service, direct?: boolean) => void>(() => {});
export const useLeadModal = () => useContext(Ctx);

/** `direct` = skip the "Website or Telegram?" choice (used by the Telegram card itself). */
export function LeadButton({ service, className, children, direct }: { service?: Service; className?: string; children: React.ReactNode; direct?: boolean }) {
  const open = useLeadModal();
  return <button type="button" className={className} onClick={() => open(service, direct)}>{children}</button>;
}

/** Small floating “Chat with agent” button (bottom-right) — same Telegram flow, own first message. */
export function ChatFab({ text, lift, href }: { text: string; lift?: boolean; href?: string }) {
  const open = useLeadModal();
  // v135: with our Telegram channel set, the round button joins the channel (/j → the bot makes this visitor their own join-request link)
  if (href) return (
    <a href={href} target="_blank" rel="noopener" aria-label={text} title={text} data-chan-fab
      className={clsx(lift ? 'bottom-[calc(92px+env(safe-area-inset-bottom))] sm:bottom-[calc(14px+env(safe-area-inset-bottom))]' : 'bottom-[calc(14px+env(safe-area-inset-bottom))]', 'fixed right-3.5 z-[90] inline-flex h-12 w-12 items-center justify-center rounded-full bg-[#229ED9] text-white shadow-[0_8px_22px_-8px_rgba(34,158,217,.9)] transition-transform hover:scale-105 active:scale-95 sm:h-auto sm:w-auto sm:gap-1.5 sm:py-2 sm:pl-2.5 sm:pr-3.5 sm:text-[13px] sm:font-semibold')}>
      <svg width="22" height="22" viewBox="0 0 24 24" aria-hidden className="sm:h-[17px] sm:w-[17px]"><path fill="currentColor" d="M5.5 11.8l10.6-4.1c.5-.2.9.1.8.8l-1.8 8.5c-.1.6-.5.7-1 .5l-2.8-2-1.3 1.3c-.2.2-.3.3-.6.3l.2-2.9 5.2-4.7c.2-.2 0-.3-.3-.1l-6.4 4-2.8-.9c-.6-.2-.6-.6.2-.7z" /></svg>
      <span className="hidden sm:inline">{text}</span>
    </a>
  );
  return (
    <button type="button" onClick={() => open('chat')} aria-label={text} title={text}
      className={clsx(lift ? 'bottom-[calc(92px+env(safe-area-inset-bottom))] sm:bottom-[calc(14px+env(safe-area-inset-bottom))]' : 'bottom-[calc(14px+env(safe-area-inset-bottom))]', 'fixed right-3.5 z-[90] inline-flex h-12 w-12 items-center justify-center rounded-full bg-[#229ED9] text-white shadow-[0_8px_22px_-8px_rgba(34,158,217,.9)] transition-transform hover:scale-105 active:scale-95 sm:h-auto sm:w-auto sm:gap-1.5 sm:py-2 sm:pl-2.5 sm:pr-3.5 sm:text-[13px] sm:font-semibold')}>
      <span className="relative grid place-items-center"><MessageCircle size={22} strokeWidth={2.3} className="sm:h-[17px] sm:w-[17px]" />
        <span className="absolute -right-1 -top-1 h-2.5 w-2.5 rounded-full border-2 border-[#229ED9] bg-[#4ade80]" /></span>
      <span className="hidden sm:inline">{text}</span>
    </button>
  );
}

const WA_PATH = 'M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z';
export function WaIcon({ size = 24, className }: { size?: number; className?: string }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden className={className}><path fill="currentColor" d={WA_PATH} /></svg>;
}

/** Round WhatsApp button (community link) — same size as the chat button, sits right above it. No Meta event.
 *  `lift` (v121, channel pages): on phones it sits above the sticky "Join" bar. */
export function WaFab({ link, above, lift }: { link: string; above: boolean; lift?: boolean }) {
  return (
    <a href={link} target="_blank" rel="noopener" aria-label="Join on WhatsApp" title="Join on WhatsApp" data-wa-fab
      className={clsx('fixed right-3.5 z-[90] grid h-12 w-12 place-items-center rounded-full bg-[#25D366] text-white shadow-[0_8px_22px_-8px_rgba(37,211,102,.9)] transition-transform hover:scale-105 active:scale-95',
        lift ? (above ? 'bottom-[calc(152px+env(safe-area-inset-bottom))] sm:bottom-[calc(66px+env(safe-area-inset-bottom))]' : 'bottom-[calc(92px+env(safe-area-inset-bottom))] sm:bottom-[calc(14px+env(safe-area-inset-bottom))]')
          : above ? 'bottom-[calc(74px+env(safe-area-inset-bottom))] sm:bottom-[calc(66px+env(safe-area-inset-bottom))]' : 'bottom-[calc(14px+env(safe-area-inset-bottom))]')}>
      <WaIcon size={27} />
    </a>
  );
}

const STEPS = [
  {
    key: 'has_bm' as const,
    q: 'Do you have a Facebook Business Manager?',
    hint: 'The ad account is shared to your Business Manager.',
    options: [
      { v: 'yes', label: 'Yes, I have one' },
      { v: 'no', label: 'Not yet', sub: 'We’ll help you create one for free' },
    ],
  },
  {
    key: 'niche' as const,
    q: 'What do you advertise?',
    options: [
      { v: 'Ecommerce', label: 'Ecommerce' },
      { v: 'Lead generation', label: 'Lead generation or services' },
      { v: 'Apps / Gaming', label: 'Apps or gaming' },
      { v: 'Finance / Crypto', label: 'Finance or crypto' },
      { v: 'Other', label: 'Something else' },
    ],
  },
  {
    key: 'budget' as const,
    q: 'What’s your daily ad budget?',
    options: [
      { v: '< $20/day', label: 'Under $20 a day' },
      { v: '$20–100/day', label: '$20 to $100 a day' },
      { v: '$100–500/day', label: '$100 to $500 a day' },
      { v: '$500+/day', label: 'More than $500 a day' },
    ],
  },
];

/** URL of the other business's page when this button belongs there, else null. "/funnel/blue" ⇄ "/p/blue", "/funnel" ⇄ "/". */
function otherPageUrl(s: Service): string | null {
  if (typeof location === 'undefined' || s === 'chat') return null;
  const line = pageLine();
  if (!((line === 'funnel' && s === 'account') || (line === 'agency' && s === 'funnel'))) return null;
  const p = location.pathname.replace(/\/+$/, '');
  let to: string;
  if (line === 'funnel') { const m = p.match(/^\/funnel\/([a-z]+)$/); to = m ? '/p/' + m[1] : '/'; }
  else { const m = p.match(/^\/p\/([a-z]+)$/); to = m ? '/funnel/' + m[1] : '/funnel'; }
  return to + location.search;
}

const STEPS_F = [
  {
    key: 'niche' as const,
    q: 'What do you sell?',
    hint: 'So we can plan the right page and form for you.',
    options: [
      { v: 'Coaching / Courses', label: 'Coaching or courses' },
      { v: 'Real estate', label: 'Real estate' },
      { v: 'Local services', label: 'Local services or clinic' },
      { v: 'Ecommerce', label: 'Ecommerce' },
      { v: 'Other', label: 'Something else' },
    ],
  },
  {
    key: 'budget' as const,
    q: 'What’s your monthly ad budget?',
    options: [
      { v: '< $500/mo', label: 'Under $500 a month' },
      { v: '$500–2,000/mo', label: '$500 to $2,000 a month' },
      { v: '$2,000–10,000/mo', label: '$2,000 to $10,000 a month' },
      { v: '$10,000+/mo', label: 'More than $10,000 a month' },
    ],
  },
];

export function LeadModalProvider({ children, theme, titles, autoMsg = false, web, chat, fallback, defaultService = 'account' }: { children: React.ReactNode; theme: string; titles: { account: string; funnel: string }; autoMsg?: boolean; web?: WebChoice; chat?: ChatBtn; fallback?: Fallback; defaultService?: Service }) {
  const [open, setOpen] = useState(false);
  const [service, setService] = useState<Service>(defaultService);
  // funnel enquiries get their own two questions (no Business Manager question)
  const Q = service === 'funnel' ? STEPS_F : STEPS;
  const [step, setStep] = useState(0);
  const [ans, setAns] = useState<Answers>({});
  const [form, setForm] = useState({ name: '', phone: '', website: '' });
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<{ link: string | null; t?: string } | null>(null);
  const [choose, setChoose] = useState(false);
  // Website fallback: 'wait' = checking if the Telegram chat started, 'show' = offer the website order, 'ok' = chat started
  const [fb, setFb] = useState<'wait' | 'show' | 'ok' | null>(null);
  const [ask, setAsk] = useState({ email: '', question: '', busy: false, sent: false, err: '' });
  const fbOn = !!fallback?.on;
  const fbWeb = !!fallback?.web, fbWa = fallback?.wa || null;
  const [round, setRound] = useState(0); // 'try again' restarts the wait
  const dialogRef = useRef<HTMLDivElement>(null);

  const openModal = useCallback((s0?: Service, direct?: boolean) => {
    const s = s0 || defaultService;
    // Ad account asked on the Funnel page → go to the Agency page; funnel asked on the Agency page → go to the Funnel page
    // (same design, same ?utm/fbclid). Each page then tracks on its own pixel.
    const other = otherPageUrl(s);
    if (other) { location.href = other; return; }
    trackAtc(s === 'chat' ? 'chat' : s);
    setService(s); setStep(s === 'chat' ? STEPS.length : 0); setAns({}); setErr(''); setDone(null); setFb(null);
    setChoose(s === 'account' && !direct && !!web?.on);
    setOpen(true);
  }, [web?.on, defaultService]);

  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') { setOpen(false); savePending(null); } };
    window.addEventListener('keydown', onKey);
    setTimeout(() => dialogRef.current?.focus(), 50);
    return () => { document.body.style.overflow = prev; window.removeEventListener('keydown', onKey); };
  }, [open]);

  // Back on the landing page after going to t.me (desktop / browser back) → reopen the same screen and keep checking
  useEffect(() => {
    if (!fbOn) return;
    const p = readPending();
    if (!p) return;
    setService(p.service); setChoose(false); setDone({ link: p.link, t: p.t }); setFb('wait'); setOpen(true);
  }, [fbOn]);

  // Ask the server every 3 s (max ~2 min) whether the Telegram chat has started
  const tok = done?.t;
  useEffect(() => {
    if (!fbOn || !tok || !open) return;
    let stop = false, n = 0;
    const started0 = Date.now();
    const wait = (inAppBrowser() ? Math.min(10, fallback!.sec) : fallback!.sec) * 1000;
    const check = async () => {
      if (stop) return;
      n++;
      try {
        const r = await fetch('/api/lead?t=' + encodeURIComponent(tok), { cache: 'no-store' });
        const j = await r.json().catch(() => ({}));
        if (stop) return;
        if (j.started) { stop = true; savePending(null); setFb('ok'); return; }
        if (r.status === 404 || r.status === 400) { stop = true; savePending(null); return; }
      } catch { /* offline for a moment — try again */ }
      if (Date.now() - started0 >= wait) setFb(f => (f === 'wait' ? 'show' : f));
      if (n >= 40) { stop = true; return; }
      setTimeout(() => void check(), 3000);
    };
    const first = setTimeout(() => void check(), Math.min(2500, Math.max(1000, wait - 1500)));
    const due = setTimeout(() => { if (!stop) setFb(f => (f === 'wait' ? 'show' : f)); }, wait);
    // Came back from Telegram (or from the error page) without starting the chat → show the card sooner
    const onVis = () => { if (document.visibilityState === 'visible' && Date.now() - started0 > Math.min(5000, wait)) setTimeout(() => setFb(f => (f === 'wait' ? 'show' : f)), 2500); };
    document.addEventListener('visibilitychange', onVis);
    return () => { stop = true; clearTimeout(first); clearTimeout(due); document.removeEventListener('visibilitychange', onVis); };
  }, [fbOn, tok, open, fallback, round]);

  async function sendAsk(e: React.FormEvent) {
    e.preventDefault();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(ask.email.trim())) return setAsk(a => ({ ...a, err: 'Enter a valid email address.' }));
    setAsk(a => ({ ...a, busy: true, err: '' }));
    try {
      const r = await fetch('/api/lead/ask', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ t: tok, email: ask.email, question: ask.question }) });
      const j = await r.json().catch(() => ({}));
      if (!r.ok || !j.ok) throw new Error(j.error || 'Could not send. Try again.');
      savePending(null);
      setAsk(a => ({ ...a, busy: false, sent: true }));
    } catch (er) { setAsk(a => ({ ...a, busy: false, err: (er as Error).message })); }
  }
  const close = () => { setOpen(false); savePending(null); };

  const pick = (key: keyof Answers, v: string) => {
    setAns(a => ({ ...a, [key]: v }));
    setTimeout(() => setStep(s => s + 1), key === 'has_bm' && v === 'no' ? 1400 : 220);
  };

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr('');
    if (form.name.trim().length < 2) return setErr('Enter your full name.');
    if (!validIndian(form.phone)) return setErr('Enter a valid 10-digit mobile number.');
    setBusy(true);
    try {
      const r = await fetch('/api/lead', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ ...form, ...ans, service, theme, page_url: location.href, line: pageLine(), tier: pageTier() }),
      });
      const j = await r.json();
      if (!r.ok || !j.ok) throw new Error(j.error || 'Could not send your details. Try again.');
      setDone({ link: j.link ?? null, t: j.t });
      const watch = fbOn && j.link && j.t;
      if (watch) { setFb('wait'); savePending({ t: j.t, link: j.link, service, at: Date.now() }); }
      if (j.link) setTimeout(() => openTelegram(j.link, watch ? () => setFb(f => (f === 'ok' ? f : 'show')) : undefined), 900);
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'Could not send your details. Try again.');
    } finally { setBusy(false); }
  }

  // v168: the name + number step is on screen → one funnel beacon (no Meta event, no UI change)
  useEffect(() => { if (open && !choose && !done && step >= Q.length) trackStep('form'); }, [open, choose, done, step, Q.length]);
  const total = Q.length + 1;
  const title = service === 'chat' ? (chat?.text || 'Chat with agent') : service === 'funnel' ? titles.funnel : titles.account;
  const save = web ? Math.max(0, Math.round((Number(web.priceTg) - Number(web.priceWeb)) * 100) / 100) : 0;

  return (
    <Ctx.Provider value={openModal}>
      {children}
      <AnimatePresence>
        {open && (
          <motion.div
            className="fixed inset-0 z-[100] flex items-end justify-center bg-black/70 backdrop-blur-md sm:items-center sm:p-6"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            onMouseDown={e => { if (e.target === e.currentTarget) close(); }}
          >
            <motion.div
              ref={dialogRef} tabIndex={-1} role="dialog" aria-modal="true" aria-label={title}
              className="relative max-h-[94dvh] w-full overflow-y-auto rounded-t-[28px] bg-plum px-6 pb-[calc(24px+env(safe-area-inset-bottom))] pt-6 border border-edge [box-shadow:var(--shadow)] outline-none sm:max-w-[480px] sm:rounded-[28px] sm:p-8"
              initial={{ y: 40, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 30, opacity: 0 }}
              transition={{ type: 'spring', damping: 30, stiffness: 320 }}
            >
              <button onClick={close} aria-label="Close" className="absolute right-4 top-4 grid h-9 w-9 place-items-center rounded-full bg-ov/[0.07] text-fg-2 hover:text-fg">
                <X size={18} />
              </button>

              {choose && !done ? (
                <div className="pt-1">
                  <h3 className="pr-10 font-display text-[24px] font-semibold leading-tight tracking-tight">How do you want to order?</h3>
                  <p className="mt-2 text-[14px] text-fg-3">Same agency ad account. Pick what’s easier for you.</p>
                  <div className="mt-5 grid gap-3">
                    <a href={pageTier() ? '/order?tier=premium' : '/order'} className="relative flex items-center gap-4 rounded-2xl border-2 border-violet bg-violet/15 px-4 py-4 text-left transition-colors hover:bg-violet/20">
                      {save > 0 && <span className="absolute -top-2.5 right-4 rounded-full bg-mint px-2.5 py-0.5 text-[11.5px] font-bold text-[#062b12]">Save ${save}</span>}
                      <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-violet/25 text-lilac"><Globe size={20} /></span>
                      <span className="min-w-0 flex-1"><span className="block text-[16px] font-semibold">Order on Website</span><span className="block text-[13px] text-fg-3">Pay online, instant order</span></span>
                      <span className="text-right"><span className="block font-display text-[24px] font-semibold leading-none">${web?.priceWeb}</span>{save > 0 && <s className="text-[12.5px] text-fg-3">${web?.priceTg}</s>}</span>
                    </a>
                    <button type="button" onClick={() => setChoose(false)} className="flex items-center gap-4 rounded-2xl border border-edge bg-ov/[0.04] px-4 py-4 text-left transition-colors hover:border-[#229ED9]/60">
                      <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-[#229ED9]/15"><TgIcon size={24} /></span>
                      <span className="min-w-0 flex-1"><span className="block text-[16px] font-semibold">Order on Telegram</span><span className="block text-[13px] text-fg-3">Chat with a real agent</span></span>
                      <span className="flex items-center gap-1 font-display text-[24px] font-semibold leading-none">${web?.priceTg}<ArrowRight size={16} className="text-fg-3" /></span>
                    </button>
                  </div>
                </div>
              ) : done && fb === 'ok' ? (
                <div className="pt-4 text-center" data-fb="ok">
                  <div className="mx-auto mb-5 grid h-16 w-16 place-items-center rounded-full bg-[#229ED9]/20 text-[#5fc3f5]"><Check size={30} strokeWidth={2.5} /></div>
                  <h3 className="font-display text-[26px] font-semibold tracking-tight">You’re connected</h3>
                  <p className="mx-auto mt-2 max-w-[34ch] text-[15px] leading-relaxed text-fg-2">Your agent will reply in the same Telegram chat in a few minutes.</p>
                  <button type="button" onClick={close} className="btn-ghost mt-6 w-full">Close</button>
                </div>
              ) : done && fb === 'show' ? (
                <div className="pt-2" data-fb="show">
                  {fbWeb ? <div className="mx-auto mb-4 grid h-14 w-14 place-items-center rounded-full bg-violet/20 text-lilac"><Globe size={26} /></div>
                    : <div className="mx-auto mb-4 grid h-14 w-14 place-items-center rounded-full bg-[#25D366]/15 text-[#25D366]"><WaIcon size={28} /></div>}
                  <h3 className="text-center font-display text-[24px] font-semibold leading-tight tracking-tight">{service === 'chat' || !fbWeb ? 'Telegram didn’t open?' : 'Order on our website'}</h3>
                  <p className="mx-auto mt-2 max-w-[36ch] text-center text-[15px] leading-relaxed text-fg-2">{fbWeb ? fallback!.text : fbWa?.text}</p>
                  {fbWeb && <a href={`/order?lead=${encodeURIComponent(done.t || '')}${pageTier() ? '&tier=premium' : ''}${service === 'funnel' ? '&kind=funnel' : service === 'account' ? '&kind=account' : ''}`} onClick={() => savePending(null)}
                    className="btn-primary mt-6 w-full" data-fb-order>
                    Order on website{web?.priceWeb && service !== 'chat' ? ` · $${service === 'funnel' ? (fallback!.priceFunnel || web.priceWeb) : web.priceWeb}` : ''} <ArrowRight size={17} />
                  </a>}
                  {fbWa && (
                    <a href={fbWa.link} target="_blank" rel="noopener" onClick={() => savePending(null)} data-fb-wa
                      className={clsx('flex w-full items-center justify-center gap-2 rounded-full bg-[#25D366] px-6 py-3.5 text-[16px] font-semibold text-white shadow-[0_12px_30px_-12px_#25D366] transition-transform hover:scale-[1.02]', fbWeb ? 'mt-3' : 'mt-6')}>
                      <WaIcon size={21} /> Join on WhatsApp{fbWa.members ? <span className="rounded-full bg-white/25 px-2 py-0.5 text-[12.5px] font-bold">{fbWa.members}</span> : null}
                    </a>
                  )}
                  {fbWa?.agent && (
                    <a href={fbWa.agent} target="_blank" rel="noopener" onClick={() => savePending(null)} data-fb-wa-agent
                      className="mt-3 flex w-full items-center justify-center gap-2 rounded-full border border-[#25D366]/60 px-6 py-3 text-[15px] font-semibold text-fg transition-colors hover:bg-[#25D366]/10">
                      <WaIcon size={18} className="text-[#25D366]" /> Chat with an agent on WhatsApp
                    </a>
                  )}
                  {service === 'chat' && (ask.sent ? (
                    <p className="mt-4 rounded-2xl bg-violet/15 px-4 py-3 text-center text-[14px] text-lilac" data-fb-asked>Thanks! We’ll reply to {ask.email.trim()} soon.</p>
                  ) : (
                    <form onSubmit={sendAsk} noValidate className="mt-5 rounded-2xl border border-edge bg-ov/[0.03] p-4">
                      <p className="mb-3 text-[14px] font-medium">Or leave your email and we’ll reply there</p>
                      <input type="email" autoComplete="email" placeholder="you@email.com" value={ask.email} onChange={e => setAsk(a => ({ ...a, email: e.target.value }))}
                        className="w-full rounded-xl border border-edge bg-ov/[0.04] px-4 py-3 text-[16px] outline-none focus:border-violet" />
                      <textarea rows={2} placeholder="Your question (optional)" value={ask.question} maxLength={600} onChange={e => setAsk(a => ({ ...a, question: e.target.value }))}
                        className="mt-2.5 w-full resize-none rounded-xl border border-edge bg-ov/[0.04] px-4 py-3 text-[16px] outline-none focus:border-violet" />
                      {ask.err && <p role="alert" className="mt-2 text-[14px] text-[color:var(--err)]">{ask.err}</p>}
                      <button disabled={ask.busy} className="btn-ghost mt-3 w-full">{ask.busy ? <Loader2 size={17} className="animate-spin" /> : 'Send'}</button>
                    </form>
                  ))}
                  {done.link && (
                    <a href={done.link} target="_blank" rel="noopener" onClick={() => { setFb('wait'); setRound(r => r + 1); }} className="mt-4 flex items-center justify-center gap-2 text-[14px] font-medium text-[#5fc3f5]" data-fb-retry>
                      <TgIcon size={17} /> I have Telegram — try again
                    </a>
                  )}
                </div>
              ) : done ? (
                <div className="pt-4 text-center">
                  <div className="mx-auto mb-5 grid h-16 w-16 place-items-center rounded-full bg-violet/20 text-lilac"><Check size={30} strokeWidth={2.5} /></div>
                  <h3 className="font-display text-[26px] font-semibold tracking-tight">{service === 'chat' ? 'Opening the chat' : 'Form submitted'}</h3>
                  {done.link && <p className="mt-1 flex items-center justify-center gap-2 text-[15px] font-medium text-[#5fc3f5]"><Loader2 size={16} className="animate-spin" /> Opening Telegram…</p>}
                  {done.link ? (
                    <>
                      <ol className="mx-auto mt-5 grid max-w-[340px] gap-2.5 text-left text-[15px]">
                        {['Telegram opens with your message already typed', 'Tap Send', 'Your agent replies in the same chat'].map((t, i) => (
                          <li key={i} className="flex items-center gap-3 rounded-2xl border border-edge bg-ov/[0.04] px-4 py-3">
                            <span className={clsx('grid h-7 w-7 shrink-0 place-items-center rounded-full text-[13px] font-bold', i === 1 ? 'bg-[#229ED9] text-white' : 'bg-violet/20 text-lilac')}>{i + 1}</span>
                            <span className="text-fg">{t}</span>
                          </li>
                        ))}
                      </ol>
                      <a href={done.link} onClick={e => { e.preventDefault(); openTelegram(done.link!, fbOn && done.t ? () => setFb(f => (f === 'ok' ? f : 'show')) : undefined); }} className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full bg-[#229ED9] px-6 py-4 text-[16px] font-semibold text-white shadow-[0_12px_30px_-10px_#229ED9] transition-transform hover:scale-[1.02]">
                        <TgIcon size={20} className="[&>circle]:fill-white/20" /> Didn’t open? Tap here
                      </a>
                      {fbOn && done.t && <button type="button" onClick={() => setFb('show')} className="mt-3 text-[14px] font-medium text-fg-2 underline-offset-4 hover:text-fg hover:underline" data-fb-link>Don’t have Telegram? {service === 'chat' || !fbWeb ? 'Other options' : 'Order on the website'}</button>}
                      {autoMsg && <p className="mt-3 text-[13px] text-fg-3">Can’t send a message? No problem. We’ll message you on Telegram at your number in a few minutes.</p>}
                    </>
                  ) : (
                    <p className="mx-auto mt-3 max-w-[34ch] text-[15px] leading-relaxed text-fg-2">An agent will message you on Telegram at your number shortly.</p>
                  )}
                </div>
              ) : (
                <>
                  <p className="pr-10 text-[13px] font-medium text-fg-3">{title}</p>
                  <div className={clsx('mt-3 flex gap-1.5', service === 'chat' && 'hidden')} aria-hidden>
                    {Array.from({ length: total }).map((_, i) => (
                      <span key={i} className={clsx('h-1 flex-1 rounded-full transition-colors', i <= step ? 'bg-gradient-to-r from-violet to-orchid' : 'bg-ov/10')} />
                    ))}
                  </div>

                  <AnimatePresence mode="wait" initial={false}>
                    <motion.div key={step} initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }} transition={{ duration: 0.18 }} className="mt-6">
                      {step < Q.length ? (
                        <>
                          <h3 className="font-display text-[24px] font-semibold leading-tight tracking-tight">{Q[step].q}</h3>
                          {Q[step].hint && <p className="mt-2 text-[14px] text-fg-3">{Q[step].hint}</p>}
                          <div className="mt-5 grid gap-2.5">
                            {Q[step].options.map(o => {
                              const sel = ans[Q[step].key] === o.v;
                              return (
                                <button key={o.v} type="button" onClick={() => pick(Q[step].key, o.v)}
                                  className={clsx('flex w-full items-center gap-3 rounded-2xl border px-4 py-3.5 text-left transition-colors',
                                    sel ? 'border-violet bg-violet/15' : 'border-edge hover:border-violet/40 hover:bg-ov/[0.03]')}>
                                  <span className="flex-1">
                                    <span className="block text-[15px] font-medium">{o.label}</span>
                                    {'sub' in o && o.sub && <span className="mt-0.5 block text-[13px] text-fg-3">{o.sub}</span>}
                                  </span>
                                  <span className={clsx('grid h-5 w-5 shrink-0 place-items-center rounded-full border', sel ? 'border-violet bg-violet text-onp' : 'border-ov/25')}>
                                    {sel && <Check size={12} strokeWidth={3} />}
                                  </span>
                                </button>
                              );
                            })}
                          </div>
                          {step === 0 && ans.has_bm === 'no' && (
                            <p className="mt-4 rounded-2xl bg-violet/15 px-4 py-3 text-[14px] leading-relaxed text-lilac">
                              No problem. A Business Manager is free to create at business.facebook.com and takes about five minutes. Your agent will walk you through it.
                            </p>
                          )}
                        </>
                      ) : (
                        <form onSubmit={submit} noValidate>
                          <h3 className="font-display text-[24px] font-semibold leading-tight tracking-tight">{service === 'chat' ? 'Chat with a live agent' : 'Last step: your name and number'}</h3>
                          <p className="mt-2 flex items-start gap-2 text-[14px] text-fg-3"><TgIcon size={18} className="mt-px shrink-0" />{service === 'chat' ? 'Enter your name and number. Telegram opens and an agent replies in a few minutes — ask anything.' : 'Next, Telegram opens and you chat with your agent there.'}</p>
                          <div className="mt-5 grid gap-3">
                            <label className="block">
                              <span className="mb-1.5 block text-[13px] font-medium text-fg-2">Full name</span>
                              <input type="text" autoComplete="name" placeholder="Your name" value={form.name}
                                onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                                className="w-full rounded-xl border border-edge bg-ov/[0.04] px-4 py-3.5 text-[16px] outline-none transition-colors placeholder:text-fg-3/70 focus:border-violet focus:bg-ov/[0.06]" />
                            </label>
                            <label className="block">
                              <span className="mb-1.5 block text-[13px] font-medium text-fg-2">Mobile number (Telegram)</span>
                              <span className="flex items-stretch overflow-hidden rounded-xl border border-edge bg-ov/[0.04] transition-colors focus-within:border-violet focus-within:bg-ov/[0.06]">
                                <span className="grid place-items-center border-r border-edge px-3.5 text-[16px] font-medium text-fg-2">+91</span>
                                <input type="tel" inputMode="numeric" autoComplete="tel-national" placeholder="98765 43210" value={form.phone} maxLength={16}
                                  onChange={e => setForm(f => ({ ...f, phone: e.target.value.replace(/[^\d\s+-]/g, '') }))}
                                  className="min-w-0 flex-1 bg-transparent px-3.5 py-3.5 text-[16px] outline-none placeholder:text-fg-3/70" />
                              </span>
                            </label>
                            <input tabIndex={-1} name="af_hp_field" autoComplete="new-password" aria-hidden className="absolute -left-[9999px] h-0 w-0 opacity-0" value={form.website} onChange={e => setForm(f => ({ ...f, website: e.target.value }))} />
                          </div>
                          {err && <p role="alert" className="mt-3 text-[14px] text-[color:var(--err)]">{err}</p>}
                          <button disabled={busy} className="btn-primary mt-6 w-full">
                            {busy ? <><Loader2 size={17} className="animate-spin" /> Sending</> : <><TgIcon size={19} className="[&>circle]:fill-white/20" /> Continue to Telegram</>}
                          </button>
                          <p className="mt-3 text-center text-[12px] text-fg-3">Your details go only to your assigned agent.</p>
                        </form>
                      )}
                    </motion.div>
                  </AnimatePresence>

                  {step > 0 && service !== 'chat' && (
                    <button type="button" onClick={() => setStep(s => s - 1)} className="mt-5 inline-flex items-center gap-1 text-[14px] font-medium text-fg-3 hover:text-fg">
                      <ChevronLeft size={16} /> Back
                    </button>
                  )}
                </>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </Ctx.Provider>
  );
}
