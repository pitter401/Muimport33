'use client';
/** AddToCart: the visitor pressed an Order / Chat button (once per browser tab session; server dedups per visitor too). */
/** Which landing page this is: the Funnel page (/funnel…) or the main Agency page. */
export const pageLine = () => (typeof location !== 'undefined' && /^\/funnel(\/|$)/.test(location.pathname) ? 'funnel' : 'agency');
/** /premium → Premium lead (its own prices). */
export const pageTier = () => (typeof location !== 'undefined' && /^\/premium(\/|$)/.test(location.pathname) ? 'premium' : '');
let sent = false;
export function trackAtc(what: string) {
  if (sent) return;
  try { const k = 'af_atc_' + pageLine() + pageTier(); if (sessionStorage.getItem(k)) { sent = true; return; } sessionStorage.setItem(k, '1'); } catch { /* private mode */ }
  sent = true;
  fetch('/api/vc', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ ev: 'atc', what, url: location.href, line: pageLine() }), keepalive: true }).catch(() => {});
}
/** v168: a landing-page funnel step (reached the name + number step) — stored for the admin's funnel only, never a Meta event. Once per page load. */
const stepSent = new Set<string>();
export function trackStep(step: 'form') {
  if (stepSent.has(step)) return;
  stepSent.add(step);
  try { fetch('/api/vc', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ ev: 'step', step, url: location.href, line: pageLine() }), keepalive: true }).catch(() => {}); } catch { /* never break the page */ }
}
