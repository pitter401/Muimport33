import type { Metadata } from 'next';
import { landingContent } from '@/server/content';
import { getSettings } from '@/server/settings';
import { shareMeta } from '@/server/site';
import { waPageData } from '@/server/wapages';
import { chanCopy, chanDelivery, orderLink, type ChanLine } from '@/server/chanads';
import { THEME_VARS, themeCss } from './themes';
import { ChannelLanding, type ChannelText } from './designs/Channel';
import { VcBeacon } from './Sections';
import { LeadModalProvider } from './LeadModal';

/** v131: WhatsApp ad pages in the same four landing looks as the Telegram channel pages (purple, blue, green, gold).
 *  chat = every button opens WhatsApp with a pre-typed message (their code inside) through /w;
 *  community = their WhatsApp number in the hero, then the community link (Subscribe goes when that number writes to us and keeps chatting). */
export async function waMetadata(ln: ChanLine, mode: 'chat' | 'community'): Promise<Metadata> {
  const s = getSettings();
  const d = waPageData(ln, mode);
  const title = `${d.brand} · ${d.what} · WhatsApp${mode === 'community' ? ' community' : ''}`;
  return { title, description: d.text, robots: { index: false, follow: false }, ...(await shareMeta({ title, description: d.text, line: ln === 'funnel' ? 'funnel' : 'agency', url: `/${ln}/${mode === 'chat' ? 'whatsapp' : 'community'}` }, s)) };
}

/** The Telegram channel text, said for WhatsApp. */
function waCopy(ln: ChanLine, mode: 'chat' | 'community') {
  const s = getSettings();
  const k = chanCopy(s, ln);
  const tw = (x: string) => x.replace(/Telegram or WhatsApp/g, 'Telegram or WhatsApp').replace(/on Telegram/g, 'on WhatsApp').replace(/Join the channel to see real results first\./, 'Message us on WhatsApp to see real results first.');
  const how = mode === 'chat' ? 'Tap “Chat on WhatsApp”. WhatsApp opens with a message ready, press send and our team replies.' : 'Enter your WhatsApp number, join the community, then message us anytime on WhatsApp.';
  return {
    ...k,
    sub: tw(k.sub),
    offer: k.offer.map(o => ({ ...o, d: tw(o.d) })),
    faq: [...k.faq.slice(0, 3).map(([q, a]) => [q, tw(a)] as [string, string]), [ln === 'funnel' ? 'How do I start?' : 'How do I order?', how] as [string, string]],
    band: mode === 'chat' ? 'Our team replies on WhatsApp in minutes. Ask anything before you pay.' : 'Offers, delivery updates and results reach the {name} WhatsApp community first.',
    foot: tw(k.foot), lock: mode === 'chat' ? 'Real person replies · in minutes' : 'Free to join · Paid services',
    posts: mode === 'chat'
      ? [['You', `Hi! I want ${ln === 'funnel' ? 'a funnel setup' : ln === 'premium' ? 'a Premium ad account' : 'an agency ad account'}`, '10:24'], [d0(s), k.posts[1][1], '10:25'], [d0(s), ln === 'funnel' ? 'Setup slots open this week' : `Shared in ${chanDelivery(s, ln)} after payment`, '10:25']] as [string, string, string][]
      : k.posts,
  };
}
const d0 = (s: ReturnType<typeof getSettings>) => s.brand_name || 'AdsBhai';

export function WhatsAppPage({ theme, line, mode }: { theme: string; line: ChanLine; mode: 'chat' | 'community' }) {
  const s = getSettings();
  const t = theme in THEME_VARS ? theme : 'purple';
  const d = waPageData(line, mode);
  const c = landingContent(t, s, line === 'funnel' ? 'funnel' : 'agency', line === 'premium' && s.premium_on === '1' ? 'premium' : '');
  const ord = orderLink(s, line, false);
  const chat = mode === 'chat';
  const steps = chat
    ? [{ who: 'You', t: 'Tap “Chat on WhatsApp”', d: 'WhatsApp opens with a message ready for you.' }, { who: 'You', t: 'Press send', d: 'A real person from our team replies in a few minutes.' },
      { who: 'Done', t: line === 'funnel' ? 'Get your funnel built' : 'Get your account', d: line === 'funnel' ? 'We build your landing page and funnel and start the ads.' : `Shared to your Business Manager within ${d.delivery}.` }]
    : [{ who: 'You', t: 'Enter your WhatsApp number', d: 'So our team knows it is you when you write.' }, { who: 'WhatsApp', t: 'Join the community', d: 'Offers, tips and updates from our team.' },
      { who: 'Done', t: 'Message us anytime', d: 'Ask anything, our team replies on WhatsApp.' }];
  const ch: ChannelText = {
    kind: chat ? 'wa' : 'wac', href: chat ? `/w?line=${line}` : '#wa-join', name: d.brand,
    hero: { h: c.headline, a: c.accent, sub: c.sub.replace(/on Telegram/g, 'on WhatsApp') }, band: d.title || undefined, cta: chat ? `Chat on WhatsApp & buy ${line === 'funnel' ? 'funnel setup' : line === 'premium' ? 'Premium ad account' : 'agency ad account'}` : undefined,
    copy: { ...waCopy(line, mode), ...(d.text ? { band: d.text } : {}) }, steps, ...(ord ? { order: { href: ord, label: 'Order on website' } } : {}),
    ...(chat ? {} : { form: { line, cc: d.cc, off: !d.on } }),
  };
  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: themeCss(t) + ':root{--bar-h:0px}' }} />
      <LeadModalProvider theme={c.theme} defaultService={line === 'funnel' ? 'funnel' : 'account'} autoMsg={c.autoMsg} titles={{ account: c.account.title, funnel: c.funnel.title }}
        web={{ on: c.webOn, priceWeb: c.priceWeb, priceTg: c.priceTg }} chat={{ on: false, text: c.chatBtnText }} fallback={{ ...c.fallback, on: false }}>
        <VcBeacon theme={t} delay={c.vcDelay} />
        <div data-wa-page={`${line}-${mode}`}><ChannelLanding c={c} ch={ch} /></div>
      </LeadModalProvider>
    </>
  );
}
