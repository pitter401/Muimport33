/** Four landing themes (one premium layout, four colour palettes). Pick one in Admin app → Settings → Landing page. Preview any at /p/<theme>. */
export const THEME_VARS: Record<string, { label: string; scheme: 'dark' | 'light'; font: string; vars: Record<string, string> }> = {
  purple: {
    label: 'Magenta gradient (main)', scheme: 'light', font: '"Montserrat Variable"',
    vars: {
      bg: '255 255 255', s1: '255 255 255', s2: '247 243 255', s3: '237 230 255', p: '124 58 237', pd: '91 33 182', ps: '167 139 250', pt: '109 40 217', a: '217 70 239',
      ok: '22 163 74', fg: '22 18 58', fg2: '78 72 112', fg3: '128 122 158', ov: '22 18 58', onp: '255 255 255', edge: 'rgba(76,29,149,.12)',
      band1: '124 58 237', band2: '30 10 72', err: '#DC2626', shadow: '0 30px 70px -28px rgba(91,33,182,.35)',
    },
  },

  green: {
    label: 'Green & white', scheme: 'light', font: '"Bricolage Grotesque Variable"',
    vars: {
      bg: '255 255 255', s1: '255 255 255', s2: '242 248 240', s3: '222 240 220', p: '22 128 61', pd: '20 83 45', ps: '74 222 128', pt: '21 128 61', a: '101 163 13',
      ok: '22 163 74', fg: '6 30 18', fg2: '60 84 70', fg3: '112 135 122', ov: '6 30 18', onp: '255 255 255', edge: 'rgba(21,128,61,.14)',
      band1: '22 128 61', band2: '3 43 26', err: '#DC2626', shadow: '0 30px 70px -28px rgba(21,128,61,.35)',
    },
  },


  blue: {
    label: 'Blue & white', scheme: 'light', font: 'var(--font-geist-sans)',
    vars: {
      bg: '255 255 255', s1: '255 255 255', s2: '242 247 255', s3: '222 234 252', p: '22 99 230', pd: '11 58 168', ps: '96 165 250', pt: '11 58 168', a: '14 165 233',
      ok: '22 163 74', fg: '7 22 60', fg2: '66 80 110', fg3: '118 131 158', ov: '7 22 60', onp: '255 255 255', edge: 'rgba(8,60,160,.12)',
      band1: '22 99 230', band2: '3 26 80', err: '#DC2626', shadow: '0 30px 70px -28px rgba(8,60,160,.3)',
    },
  },


  // the old gold page, now "Sunset orange": an all-dark navy page with an orange-coral glow
  gold: {
    label: 'Sunset orange', scheme: 'dark', font: '"Sora Variable"',
    vars: {
      bg: '11 13 30', s1: '20 23 48', s2: '26 30 60', s3: '36 41 80', p: '249 115 22', pd: '234 88 12', ps: '253 186 116', pt: '253 186 116', a: '244 63 94',
      ok: '74 222 128', fg: '255 247 240', fg2: '214 206 222', fg3: '150 144 170', ov: '255 255 255', onp: '255 255 255', edge: 'rgba(255,255,255,.1)',
      band1: '234 88 12', band2: '60 20 40', err: '#FCA5A5', shadow: '0 40px 90px -30px rgba(249,115,22,.4)',
    },
  },


};

export function themeCss(theme: string) {
  const t = THEME_VARS[theme] || THEME_VARS.purple;
  const v = Object.entries(t.vars).map(([k, val]) => `--${k}:${val};`).join('');
  return `:root{${v}--font-display:${t.font};color-scheme:${t.scheme}}html,body{background:rgb(var(--bg))}`;
}
