'use client';

import { useEffect, useRef, useState } from 'react';
import clsx from 'clsx';

type Item = { name: string; text: string; at: number };

function ago(t: number) {
  const m = Math.floor((Date.now() - t) / 60000);
  if (m < 1) return 'just now';
  if (m < 60) return `${m} min ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h} hour${h === 1 ? '' : 's'} ago`;
  const d = Math.floor(h / 24);
  return d === 1 ? 'yesterday' : `${d} days ago`;
}

function agoShort(t: number) {
  const m = Math.floor((Date.now() - t) / 60000);
  if (m < 1) return 'just now';
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  return h < 24 ? `${h}h ago` : `${Math.floor(h / 24)}d ago`;
}

/** Recent purchases / top-ups, newest first, one at a time. Re-checks every minute: when a newer purchase arrives it is shown next.
 *  Ages are re-computed live ("just now" -> "2 minutes ago"). Hidden when there is nothing to show.
 *  Sits in the empty space above the hero badge (absolute, so it never pushes the page down). */
const ROTATE = 8; // cycle through the newest N entries

export function RecentTicker({ align = 'center', className, inline }: { align?: 'center' | 'left'; className?: string; inline?: boolean }) {
  const [items, setItems] = useState<Item[]>([]);
  const [i, setI] = useState(0);
  const [show, setShow] = useState(false);
  const [, tick] = useState(0);
  const newest = useRef(0);
  const jump = useRef(false);
  const txt = useRef<HTMLSpanElement>(null);
  const cur = useRef<Item | null>(null);
  const [compact, setCompact] = useState(false);
  useEffect(() => {
    let alive = true;
    let first = true;
    const load = () => fetch('/api/recent', { cache: 'no-store' }).then(r => r.json()).then((j: { items?: Item[] }) => {
      if (!alive) return;
      const a = [...(j.items || [])].sort((x, y) => y.at - x.at);
      // a newer purchase came in -> show it next (on the next rotation, with the normal fade)
      if (!first && a.length && a[0].at > newest.current) jump.current = true;
      if (a.length) newest.current = a[0].at;
      // keep the entry that is on screen right now (the list may have shifted)
      const c = cur.current;
      const k = c ? a.findIndex(x => x.at === c.at && x.name === c.name) : -1;
      if (k >= 0) setI(k);
      setItems(a);
      if (first && a.length) { first = false; setI(0); setTimeout(() => alive && setShow(true), 1200 + Math.random() * 1500); }
    }).catch(() => {});
    load();
    const t = setInterval(() => { if (document.visibilityState === 'visible') load(); }, 60_000);
    return () => { alive = false; clearInterval(t); };
  }, []);
  useEffect(() => {
    if (!items.length) return;
    let t: ReturnType<typeof setTimeout>;
    const n = Math.min(ROTATE, items.length);
    const cycle = () => {
      t = setTimeout(() => { setShow(false); t = setTimeout(() => { setI(x => { if (jump.current) { jump.current = false; return 0; } return x + 1 >= n ? 0 : x + 1; }); tick(v => v + 1); setShow(true); cycle(); }, 700 + Math.random() * 2500); }, 5000);
    };
    cycle();
    return () => clearTimeout(t);
  }, [items.length]);
  useEffect(() => { setCompact(false); }, [i, items]);
  useEffect(() => {
    const el = txt.current;
    if (!compact && el && el.scrollWidth > el.clientWidth + 1) setCompact(true);
  });
  // inline: takes its own row (for designs with little space under the header); keeps the height so nothing jumps
  if (!items.length) return inline ? <div aria-hidden className="mb-3 h-7" /> : null;
  const it = items[i % items.length];
  cur.current = it;
  // " on Telegram" / " on Website" is dropped on phones so the city always fits
  const cut = it.text.search(/ on (Telegram|Website)$/);
  const main = cut > 0 ? it.text.slice(0, cut) : it.text, via = cut > 0 ? it.text.slice(cut) : '';
  // phones: "bought" instead of "purchased" + short age, so name, item and city fit on one line
  const verb = main.startsWith('purchased ') ? 'purchased' : '', rest = verb ? main.slice(10) : main;
  // too long for the screen -> "Priyanka · 2 Ad Accounts · Navi Mumbai"
  const fromAt = rest.lastIndexOf(' from '), what = fromAt > 0 ? rest.slice(0, fromAt) : rest, city = fromAt > 0 ? rest.slice(fromAt + 6) : '';
  return (
    <div aria-live="polite" className={clsx('pointer-events-none max-w-[calc(100vw-32px)]', inline ? 'relative mb-3 flex h-7' : 'absolute bottom-full mb-2.5 w-max', !inline && (align === 'center' ? 'left-1/2 -translate-x-1/2' : 'left-0'), className)}>
      <div className={clsx('flex max-w-full items-center gap-1.5 whitespace-nowrap rounded-full sm:gap-2 border border-edge bg-plum/95 py-1 pl-1 pr-2.5 text-[11.5px] text-fg-2 sm:pr-3 shadow-[0_8px_24px_-12px_rgba(0,0,0,.6)] transition-all duration-500 sm:text-[12.5px]',
        show ? 'translate-y-0 opacity-100' : 'translate-y-1 opacity-0')}>
        <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full bg-gradient-to-br from-violet to-orchid text-[10.5px] font-bold text-white">{it.name[0]}</span>
        <span ref={txt} className="min-w-0 truncate"><b className="font-semibold text-fg">{it.name}</b>{compact
          ? <> · {what}{city && <> · {city}</>}</>
          : <> {verb && <><span className="sm:hidden">bought</span><span className="hidden sm:inline">{verb}</span> </>}{rest}{via && <span className="hidden sm:inline">{via}</span>}</>}</span>
        <span className="shrink-0 text-fg-3"><span className="sm:hidden">{agoShort(it.at)}</span><span className="hidden sm:inline">({ago(it.at)})</span></span>
      </div>
    </div>
  );
}
