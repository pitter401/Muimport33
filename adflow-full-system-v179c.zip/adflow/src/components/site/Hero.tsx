'use client';

import { useEffect, useState } from 'react';
import { motion, useReducedMotion, AnimatePresence } from 'framer-motion';
import { Check, MousePointerClick, LayoutTemplate, Send, Radar } from 'lucide-react';
import clsx from 'clsx';
import { TgIcon, TgPill } from './Telegram';
import { OrderChoice } from './OrderChoice';
import { LeadButton } from './LeadModal';
import { RecentTicker } from './RecentTicker';
import { Spotlight } from './Spotlight';
import { ViewerBadge } from './Sections';
import type { LandingContent, Offer } from '@/server/content';

const ease = [0.16, 1, 0.3, 1] as const;

export function Hero({ c }: { c: LandingContent }) {
  const reduce = useReducedMotion();
  return (
    <section className="relative isolate overflow-hidden pb-14 pt-28 sm:pb-24 sm:pt-36">
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute left-1/2 top-[-260px] h-[560px] w-[1000px] -translate-x-1/2 rounded-[50%] bg-[radial-gradient(closest-side,rgb(var(--p)/.38),transparent)]" />
        <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-b from-transparent to-void" />
      </div>

      <div className="wrap">
        <div className="relative mx-auto max-w-[900px] text-center">
          {c.recentOn && <RecentTicker />}
          <motion.div initial={reduce ? false : { opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, ease }}
            className="mx-auto inline-flex items-center gap-2 rounded-full border border-edge bg-ov/[0.05] px-3.5 py-1.5 text-[13px] text-fg-2">
            <span className="h-2 w-2 rounded-full bg-mint" />
            {c.badge}
          </motion.div>

          <motion.h1 initial={reduce ? false : { opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.05, ease }}
            className="mt-6 text-balance font-display text-[36px] font-semibold leading-[1.06] tracking-[-0.035em] sm:text-[58px] lg:text-[64px]">
            {c.headline} <span className="text-lilac">{c.accent}</span>
          </motion.h1>
          {c.webOn && <OrderChoice c={c} tone="purple" className="mx-auto mt-6" />}

          <motion.p initial={reduce ? false : { opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.55, ease }}
            className="mx-auto mt-5 max-w-[56ch] text-[16px] leading-[1.65] text-fg-2 sm:text-[18px]">{c.sub}</motion.p>
          {!c.webOn && <TgPill c={c} className="mt-5 justify-center" />}
          {!c.webOn && !!c.viewerFloor && <div className="mt-4 flex justify-center"><ViewerBadge theme={c.theme} floor={c.viewerFloor} /></div>}
        </div>

        <div className="mx-auto mt-12 grid max-w-[1100px] gap-5 sm:mt-14 lg:grid-cols-2">
          <motion.div className="min-w-0" initial={reduce ? false : { opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.9, delay: 0.7, ease }}>
            <AccountCard o={c.account} />
          </motion.div>
          <motion.div className="min-w-0" initial={reduce ? false : { opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.9, delay: 0.85, ease }}>
            <FunnelCard o={c.funnel} priceAccount={c.priceAccount} />
          </motion.div>
        </div>

        <motion.p initial={reduce ? false : { opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.4 }} className="mt-8 text-center text-[14px] text-fg-3">
          Pay with {c.payment}. Delivered within {c.delivery} of payment.
        </motion.p>
      </div>
    </section>
  );
}

function PriceTag({ o }: { o: Offer }) {
  return (
    <p className="shrink-0 text-right font-display">
      <span className="block text-[40px] font-semibold leading-none tracking-[-0.05em] sm:text-[54px]">${o.price}</span>
      <span className="text-[13px] text-fg-3">{o.unit}</span>
    </p>
  );
}

function AccountCard({ o }: { o: Offer }) {
  return (
    <Spotlight className="h-full rounded-[28px]">
      <div className="glass relative flex h-full flex-col overflow-hidden rounded-[28px] border border-violet/40 p-6 sm:p-8">
        <div className="relative flex items-start justify-between gap-4">
          <div className="min-w-0">
            {o.badge && <span className="inline-flex items-center rounded-full bg-violet/15 px-2.5 py-1 text-[12px] font-medium text-lilac">{o.badge}</span>}
            <h2 className="mt-4 font-display text-[24px] font-semibold tracking-[-0.03em] sm:text-[26px]">{o.title}</h2>
            <p className="mt-1.5 text-[14.5px] text-fg-3">{o.sub}</p>
          </div>
          <PriceTag o={o} />
        </div>
        <AccountRows />
        <ul className="relative mt-6 grid gap-2.5 text-[14.5px] text-fg-2 sm:grid-cols-2">
          {o.bullets.map(t => <li key={t} className="flex gap-2.5"><Check size={17} className="mt-0.5 shrink-0 text-mint" strokeWidth={2.5} />{t}</li>)}
        </ul>
        <div className="relative mt-auto pt-7"><LeadButton className="btn-primary w-full py-4 text-[16px]"><TgIcon size={19} className="[&>circle]:fill-white/20" />{o.cta}</LeadButton></div>
      </div>
    </Spotlight>
  );
}

function AccountRows() {
  const reduce = useReducedMotion();
  const [live, setLive] = useState(!!reduce);
  const [spend, setSpend] = useState(reduce ? 248.6 : 0);
  useEffect(() => {
    if (reduce) return;
    let id: ReturnType<typeof setInterval> | undefined;
    const timers: ReturnType<typeof setTimeout>[] = [];
    const loop = () => {
      setLive(false); setSpend(0);
      timers.push(setTimeout(() => {
        setLive(true);
        let v = 0;
        id = setInterval(() => { v = Math.min(248.6, v + 6 + Math.random() * 5); setSpend(v); if (v >= 248.6 && id) clearInterval(id); }, 60);
      }, 1900));
    };
    loop();
    const rep = setInterval(loop, 9000);
    return () => { clearInterval(rep); if (id) clearInterval(id); timers.forEach(clearTimeout); };
  }, [reduce]);

  return (
    <div className="relative mt-6 overflow-hidden rounded-2xl border border-edge bg-void/50">
      <div className="flex items-center justify-between border-b border-edge px-4 py-2.5 text-[12px] text-fg-3"><span>Ad accounts</span><span>Spent today</span></div>
      <div className={clsx('flex items-center gap-3 px-4 py-3.5 transition-colors duration-700', live ? 'bg-mint/[0.08]' : 'bg-transparent')}>
        <div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-violet to-orchid text-[13px] font-bold text-onp">YA</div>
        <div className="min-w-0 flex-1">
          <p className="truncate text-[14px] font-semibold">Your new account</p>
          <p className="truncate font-mono text-[11.5px] text-fg-3">act_221890477742</p>
        </div>
        <AnimatePresence mode="wait" initial={false}>
          <motion.span key={live ? 'a' : 'p'} initial={{ opacity: 0, scale: 0.85 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.85 }}
            className={clsx('inline-flex shrink-0 items-center gap-1.5 rounded-full p-1.5 text-[12px] font-medium sm:px-2.5 sm:py-1', live ? 'bg-mint/15 text-mint' : 'bg-amber-400/15 text-amber-500')}>
            <span className={clsx('h-1.5 w-1.5 rounded-full', live ? 'bg-mint' : 'animate-pulse bg-amber-500')} /><span className="hidden sm:inline">{live ? 'Active' : 'Pending'}</span>
          </motion.span>
        </AnimatePresence>
        <span className="shrink-0 text-right font-mono text-[13px] tabular-nums sm:w-[72px] sm:text-[13.5px]">${spend.toFixed(2)}</span>
      </div>
      <div className="flex items-center gap-3 border-t border-edge px-4 py-3.5 opacity-75">
        <div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-plum-3 text-[13px] font-bold text-lilac">MS</div>
        <div className="min-w-0 flex-1">
          <p className="truncate text-[14px] font-medium">Main store</p>
          <p className="truncate font-mono text-[11.5px] text-fg-3">act_221890471163</p>
        </div>
        <span className="inline-flex shrink-0 items-center gap-1.5 rounded-full bg-mint/15 p-1.5 text-[12px] font-medium text-mint sm:px-2.5 sm:py-1"><span className="h-1.5 w-1.5 rounded-full bg-mint" /><span className="hidden sm:inline">Active</span></span>
        <span className="shrink-0 text-right font-mono text-[13px] tabular-nums text-fg-2 sm:w-[72px] sm:text-[13.5px]">$612.40</span>
      </div>
    </div>
  );
}

function FunnelCard({ o, priceAccount }: { o: Offer; priceAccount: string }) {
  return (
    <Spotlight className="h-full rounded-[28px]" glow="rgb(var(--a) / .14)">
      <div className="glass relative flex h-full flex-col overflow-hidden rounded-[28px] border border-edge p-6 sm:p-8">
        <div className="relative flex items-start justify-between gap-4">
          <div className="min-w-0">
            {o.badge && <span className="inline-flex items-center rounded-full bg-ov/[0.07] px-2.5 py-1 text-[12px] font-medium text-fg-2">{o.badge}</span>}
            <h2 className="mt-4 font-display text-[24px] font-semibold tracking-[-0.03em] sm:text-[26px]">{o.title}</h2>
            <p className="mt-1.5 text-[14.5px] text-fg-3">{o.sub}</p>
          </div>
          <PriceTag o={o} />
        </div>
        <Pipeline priceAccount={priceAccount} />
        <ul className="relative mt-6 grid gap-2.5 text-[14.5px] text-fg-2 sm:grid-cols-2">
          {o.bullets.map(t => <li key={t} className="flex gap-2.5"><Check size={17} className="mt-0.5 shrink-0 text-orchid" strokeWidth={2.5} />{t}</li>)}
        </ul>
        <div className="relative mt-auto pt-7"><LeadButton service="funnel" className="btn-ghost w-full py-4 text-[16px]"><TgIcon size={19} />{o.cta}</LeadButton></div>
      </div>
    </Spotlight>
  );
}

function Pipeline({ priceAccount }: { priceAccount: string }) {
  const reduce = useReducedMotion();
  const nodes = [{ icon: MousePointerClick, label: 'Ad click' }, { icon: LayoutTemplate, label: 'Landing' }, { icon: Send, label: 'Telegram' }, { icon: Radar, label: 'CAPI' }];
  const [active, setActive] = useState(reduce ? 4 : 0);
  useEffect(() => {
    if (reduce) return;
    const id = setInterval(() => setActive(a => (a + 1) % 5), 900);
    return () => clearInterval(id);
  }, [reduce]);
  return (
    <div className="relative mt-6 rounded-2xl border border-edge bg-void/50 px-4 py-5">
      <div className="relative flex items-start justify-between">
        <div className="absolute left-[24px] right-[24px] top-[22px] h-px bg-ov/10" />
        <motion.div className="absolute left-[24px] top-[22px] h-px bg-gradient-to-r from-violet to-orchid"
          animate={{ width: `calc((100% - 48px) * ${Math.min(active, 3) / 3})` }} transition={{ duration: 0.6, ease }} />
        {nodes.map(({ icon: I, label }, i) => {
          const on = i <= active;
          return (
            <div key={label} className="relative z-10 flex w-12 flex-col items-center">
              <motion.div animate={{ scale: i === active ? 1.12 : 1 }} transition={{ type: 'spring', stiffness: 300, damping: 15 }}
                className={clsx('grid h-11 w-11 place-items-center rounded-2xl border transition-colors duration-500',
                  on ? 'border-violet/60 bg-gradient-to-br from-violet/35 to-orchid/20 text-fg shadow-[0_0_24px_-4px_rgb(var(--ps)/.8)]' : 'border-edge bg-plum-2 text-fg-3')}>
                <I size={18} />
              </motion.div>
              <span className={clsx('mt-2 whitespace-nowrap text-[11.5px] transition-colors', on ? 'text-fg' : 'text-fg-3')}>{label}</span>
            </div>
          );
        })}
      </div>
      <div className="mt-4 flex items-center justify-between rounded-xl bg-ov/[0.05] px-3.5 py-2.5 text-[12.5px]">
        <span className="text-fg-3">Last event sent to Meta</span>
        <AnimatePresence mode="wait">
          <motion.span key={active >= 3 ? 'p' : 'l'} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} className="font-medium text-mint">
            {active >= 3 ? `Purchase $${(Number(priceAccount) || 0).toFixed(2)}` : 'Lead'}
          </motion.span>
        </AnimatePresence>
      </div>
    </div>
  );
}
