/* Small public pages (Prices, Top-up, How to order, Help & FAQ, Contact) — real pages Google can show as
 * sitelinks under the main result (like "Help & FAQ · Prices · Contact"). Text comes from Settings. */
import type { Metadata } from 'next';
import { getSettings, fmt, lines, type Settings } from '@/server/settings';
import { landingContent } from '@/server/content';
import { siteUrl, siteIcons, gscCode } from '@/server/site';
import { THEME_VARS, themeCss } from './themes';
import type { CSSProperties } from 'react';
import clsx from 'clsx';
import { pal, DARK, darkTop, pageThemeCss } from './palette';
import { ProofBar, TgIcon } from './Telegram';
import { WaFab } from './LeadModal';


export type InfoSlug = 'pricing' | 'top-up' | 'how-it-works' | 'faq' | 'contact' | 'terms' | 'refund-policy' | 'privacy';
export const INFO_PAGES: { slug: InfoSlug; label: string }[] = [
  { slug: 'pricing', label: 'Prices' },
  { slug: 'top-up', label: 'Ad account top-up' },
  { slug: 'how-it-works', label: 'How to order' },
  { slug: 'faq', label: 'Help & FAQ' },
  { slug: 'contact', label: 'Contact' },
  { slug: 'terms', label: 'Terms & Conditions' },
  { slug: 'refund-policy', label: 'Refund & Replacement' },
  { slug: 'privacy', label: 'Privacy Policy' },
];

const UPDATED = '22 November 2026';
type Block = { h?: string; p?: string; list?: string[]; qa?: [string, string][]; rows?: [string, string, string][] };
type Page = { title: string; h1: string; description: string; blocks: Block[] };

function build(slug: InfoSlug, s: Settings): Page {
  const c = landingContent(s.theme in THEME_VARS ? s.theme : 'purple', s, 'agency');
  const f = (t: string) => fmt(t, s, { price_account: c.priceAccount });
  const fee = `${Number(s.topup_comm_pct) || 0}%`, min = s.topup_min || '30', brand = s.brand_name;
  const support = String(s.owner_username || '').replace(/^@/, '');
  const faqF = lines(f(s.f_faq)).map(l => { const i = l.indexOf('|'); return (i > 0 ? [l.slice(0, i).trim(), l.slice(i + 1).trim()] : ['', '']) as [string, string]; }).filter(x => x[0]);
  switch (slug) {
    case 'pricing': return {
      title: `Prices — ${brand}`, h1: 'Prices',
      description: `${brand} prices: agency ad account $${c.priceAccount} one-time, ad account top-up ${fee} fee, landing page + funnel $${c.priceFunnel}/month. Pay with ${c.payment}.`,
      blocks: [
        { rows: [
          [c.account.title, `$${c.priceAccount}`, `One-time per account. ${c.account.sub}. Free replacement if there is any issue.`],
          ['Ad account top-up', `${fee} fee`, `Add ad budget to your account through your agent. Minimum top-up $${min}.`],
          ...(s.premium_on === '1' ? [[`${s.premium_title} `, `$${s.price_premium}`, `${s.premium_sub}. ${lines(s.premium_bullets).join(' · ')}.`] as [string, string, string]] : []),
          [c.funnel.title, `$${c.priceFunnel} / month`, c.funnel.sub],
        ] },
        { h: 'What you get with an ad account', list: c.account.bullets },
        { h: 'What the funnel setup includes', list: c.funnel.bullets },
        { h: 'Payment', p: `${c.payment}. Your agent sends the payment details in the Telegram chat. The account is delivered within ${c.delivery} of payment.` },
      ],
    };
    case 'top-up': return {
      title: `Ad account top-up (${fee} fee) — ${brand}`, h1: 'Ad account top-up',
      description: `Top up the ad account you bought from ${brand}: ${fee} fee, minimum $${min}, paid with ${c.payment}. Funds are added by your agent on Telegram.`,
      blocks: [
        { h: 'How a top-up works', list: [
          'Message your agent on Telegram with your ad account ID and the amount.',
          `Pay the amount + ${fee} fee (${c.payment}).`,
          'The funds are added to your ad account and you can keep your ads running.',
        ] },
        { h: 'Fee and minimum', p: `The fee is ${fee} of the amount. Minimum top-up is $${min}. Example: $200 top-up + ${fee} = $${(200 * (1 + (Number(s.topup_comm_pct) || 0) / 100)).toFixed(0)} total.` },
        { h: 'Why replacement is free', p: 'We earn from the top-up fee, so we want your ads to keep running. If your account has any issue, you get a replacement free of charge.' },
      ],
    };
    case 'how-it-works': return {
      title: `How to order — ${brand}`, h1: 'How to order',
      description: `Order an agency ad account or a funnel from ${brand} in 3 steps on Telegram. Delivery within ${c.delivery}.`,
      blocks: [
        { h: 'Order in 3 steps', list: c.tgSteps.length ? c.tgSteps : ['Tell us what you need on Telegram', `Pay with ${c.payment}`, `Your account is live within ${c.delivery}`] },
        { h: 'Business Manager (BM) ID', p: 'The ad account is shared to your Facebook Business Manager. Open business.facebook.com → Business settings → Business info to find your BM ID. No BM yet? It is free to create and your agent will help.' },
        { h: 'Delivery', p: `Ad accounts are delivered within ${c.delivery} of payment. Landing page + funnel setup is ready in 1–2 days.` },
      ],
    };
    case 'faq': return {
      title: `Help & FAQ — ${brand}`, h1: 'Help & FAQ',
      description: `Answers about ${brand} agency ad accounts, top-ups, payment, delivery and funnel setup.`,
      blocks: [{ h: 'Agency ad accounts', qa: c.faq }, ...(faqF.length ? [{ h: 'Landing page + funnel', qa: faqF }] : [])],
    };
    case 'contact': return {
      title: `Contact — ${brand}`, h1: `Contact ${brand}`,
      description: `Contact ${brand} on Telegram for agency ad accounts, top-ups and funnel setup.`,
      blocks: [
        { p: `We work on Telegram. Start your order from our homepage and your own agent replies in the chat — usually within minutes.` },
        ...(c.channel ? [{ h: 'Telegram channel', p: 'Updates, offers and guides are posted on our Telegram channel.' }] : []),
      ],
    };
    // v125: legal pages
    case 'refund-policy': return {
      title: `Refund & Replacement Policy — ${brand}`, h1: 'Refund & Replacement Policy',
      description: `${brand} does not give refunds. If anything goes wrong with your order, you get a replacement.`,
      blocks: [
        { p: `Last updated: ${UPDATED}. This policy applies to every order placed with ${brand}: on our website, on Telegram, on WhatsApp or through a payment link.` },
        { h: 'No refunds', list: [
          'All our products are digital services delivered online (ad accounts, ad account top-ups, landing page and funnel setup, Facebook account and Business Manager setup, and other services).',
          'Payments are final. We do not give refunds — in full or in part — for any reason, including a change of mind, an unused account or unused balance.',
          'Part payments: when an order is paid in parts, every part paid counts towards that order and is not refunded.',
        ] },
        { h: 'Replacement instead of refund', list: [
          'Wrong product: if you receive a different product from the one you ordered, we replace it with the correct product at no extra cost.',
          'Account issue: if your ad account is disabled, restricted or cannot run ads, we give you a replacement account.',
          'Unspent top-up: any unspent balance on an account that is replaced is moved to your replacement account, so you do not lose it.',
          'Funnel setup: if something in your setup does not work as agreed, we fix it or set it up again.',
          'Replacement is the only remedy we offer. Asking for a replacement never turns into a cash refund.',
        ] },
        { h: 'Top-ups', p: 'Top-up money is added to your ad account and is spent by your ads on Meta. Once it is added it cannot be taken back or refunded. The top-up fee is for our service and is not refundable.' },
        { h: 'How to ask for a replacement', p: `Message our support team${support ? ` on Telegram at @${support}` : ' on Telegram'} with your order details (ad account ID, Business Manager ID or payment details). We aim to replace within ${c.delivery}.` },
        { h: 'Payment disputes', p: 'Please contact us first if anything is wrong. We always solve the problem with a replacement. By paying for an order you agree to this policy.' },
      ],
    };
    case 'terms': return {
      title: `Terms & Conditions — ${brand}`, h1: 'Terms & Conditions',
      description: `Terms for buying agency ad accounts, top-ups and funnel setup from ${brand}.`,
      blocks: [
        { p: `Last updated: ${UPDATED}. By ordering from ${brand} (website, Telegram, WhatsApp or a payment link) you agree to these terms.` },
        { h: '1. Our services', p: `${brand} provides agency ad accounts for Meta (Facebook and Instagram) ads, ad account top-ups, landing page and funnel setup, and related services. Ad accounts are shared to your Business Manager with access to run campaigns and see performance.` },
        { h: '2. Prices and payment', list: [
          'Prices are in US dollars and are shown on our website or given by our team before you pay.',
          `We accept ${c.payment}. Payments in other currencies are converted at the rate our team gives you before payment.`,
          `Top-ups carry a service fee of ${fee} (minimum top-up $${min}).`,
          'An order is delivered after the full price is paid, unless our team agrees otherwise in writing.',
        ] },
        { h: '3. Delivery', p: `Ad accounts are usually delivered within ${c.delivery} after payment and after you send your Business Manager ID. Funnel setup usually takes 1–2 days. Delays from Meta are outside our control.` },
        { h: '4. Refunds and replacement', p: 'We do not give refunds. If anything goes wrong — a wrong product, a disabled or restricted account — you get a replacement. Full details are in our Refund & Replacement Policy, which is part of these terms.' },
        { h: '5. Your responsibilities', list: [
          'Follow Meta’s Advertising Standards and Community Standards in every ad you run.',
          'Keep your Business Manager and login details safe and do not share account access with people you do not trust.',
          'Give correct details (Business Manager ID, ad account ID, payment details). We are not responsible for a delivery made to the ID you gave us.',
        ] },
        { h: '6. No guarantee of ad results', p: 'We provide the ad account and the setup. We do not guarantee ad approvals, reach, leads, sales or any other result, and we are not responsible for decisions Meta makes about your ads, pages or Business Manager.' },
        { h: '7. Limit of liability', p: `Our total liability for any order is limited to replacing the product of that order. ${brand} is not liable for lost profits, lost ad spend or any indirect loss.` },
        { h: '8. Changes', p: 'We may update these terms and our prices. The version on this page when you place an order applies to that order.' },
        { h: '9. Contact', p: `Questions about these terms: message our support team${support ? ` on Telegram at @${support}` : ' on Telegram'}.` },
      ],
    };
    case 'privacy': return {
      title: `Privacy Policy — ${brand}`, h1: 'Privacy Policy',
      description: `How ${brand} collects, uses and protects your information.`,
      blocks: [
        { p: `Last updated: ${UPDATED}. This policy explains what information ${brand} collects when you visit our website or order from us, and how we use it.` },
        { h: 'What we collect', list: [
          'Details you give us: name, phone number, email, Telegram or WhatsApp username, Business Manager ID, ad account IDs and order details.',
          'Payment details: the amount, payment method, transaction or reference number. Card and wallet details are handled by the payment provider, not stored by us.',
          'Website data: pages visited, device and browser, IP address and cookies, including the Meta Pixel and Meta Conversions API.',
          'Messages you send to our support team on Telegram or WhatsApp.',
        ] },
        { h: 'How we use it', list: [
          'To deliver your order, share ad accounts, add top-ups and give support.',
          'To confirm payments and prevent fraud.',
          'To measure and improve our ads (for example, telling Meta that a visit led to a message or a purchase). Contact details sent to Meta are hashed.',
          'To send you messages about your order and our services. You can ask us to stop at any time.',
        ] },
        { h: 'Who we share it with', p: 'Only with services needed to run our business: Meta (ad accounts and ad measurement), Telegram and WhatsApp (messaging), and payment providers. We do not sell your personal information.' },
        { h: 'How long we keep it', p: 'We keep order and payment records as long as needed for support, accounting and legal reasons. You can ask us to delete your other information.' },
        { h: 'Your choices', p: `You can ask to see, correct or delete your information by messaging our support team${support ? ` on Telegram at @${support}` : ' on Telegram'}. You can block cookies in your browser settings.` },
        { h: 'Changes', p: 'We may update this policy. The latest version is always on this page.' },
      ],
    };
  }
}

export async function infoMetadata(slug: InfoSlug): Promise<Metadata> {
  const s = getSettings();
  const p = build(slug, s);
  const google = gscCode(s.gsc_verify);
  return {
    metadataBase: new URL(await siteUrl()),
    title: p.title, description: p.description,
    alternates: { canonical: `/${slug}` },
    robots: { index: true, follow: true },
    openGraph: { type: 'website', url: `/${slug}`, siteName: s.brand_name, title: p.title, description: p.description, images: [{ url: '/share-image?line=agency', width: 1200, height: 675 }] },
    icons: siteIcons(s),
    ...(google ? { verification: { google } } : {}),
  };
}

type Look ='stage' | 'card' | 'chat' | 'horizon';
const LOOK: Record<string, Look> = { purple: 'stage', blue: 'card', green: 'chat', gold: 'horizon' };
/** Same buttons as the landing page of each theme. */
function pill(v: Look, tone: 'white' | 'brand' | 'outline-white' | 'outline') {
  return clsx('inline-flex items-center justify-center gap-2 transition-transform duration-200 hover:scale-[1.02]',
    v === 'stage' || v === 'horizon' ? 'rounded-full px-7 py-3.5 text-[13px] font-semibold uppercase tracking-[0.2em]'
      : v === 'card' ? 'rounded-xl px-6 py-3.5 text-[15px] font-semibold' : 'rounded-full px-7 py-3.5 text-[15.5px] font-bold',
    tone === 'white' && 'bg-white text-[color:var(--m-ink)] shadow-[0_12px_30px_-12px_rgba(0,0,0,.45)]',
    tone === 'brand' && 'bg-[image:var(--m-btn)] text-white shadow-[0_14px_30px_-14px_var(--m-shadow)]',
    tone === 'outline-white' && 'border border-white/60 text-white hover:bg-white/10',
    tone === 'outline' && 'border border-violet/40 text-fg hover:bg-violet/10');
}
function Tick({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" aria-label="Verified" role="img" className={clsx('shrink-0', className)}>
      <path fill="#1d9bf0" d="M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z" />
      <path d="m8.6 12.2 2.4 2.4 4.6-4.8" fill="none" stroke="#fff" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
function Mark({ c, v, light }: { c: ReturnType<typeof landingContent>; v: Look; light: boolean }) {
  const big = v === 'stage' || v === 'horizon';
  return (
    <a href="/" className={clsx('flex items-center gap-2.5', light ? 'text-white' : 'text-fg')}>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={c.logo} alt="" width={30} height={30} className="h-[30px] w-[30px] shrink-0 rounded-[9px] object-contain" />
      <span className={clsx('leading-none', big ? 'text-[22px] font-bold uppercase tracking-[0.06em] sm:text-[26px]' : 'text-[21px] font-bold tracking-[-0.02em]')}>{c.brand}</span>
      {c.verified && <Tick className={big ? '-ml-1 h-[21px] w-[21px]' : '-ml-1 h-[19px] w-[19px]'} />}
    </a>
  );
}

export async function InfoPage({ slug }: { slug: InfoSlug }) {
  const s = getSettings();
  const t = s.theme in THEME_VARS ? s.theme : 'purple';
  const c = landingContent(t, s, 'agency');
  const p = build(slug, s);
  const base = await siteUrl();
  const v = LOOK[t] || 'stage';
  const dark = darkTop(t);
  const ld = JSON.stringify({ '@context': 'https://schema.org', '@type': 'BreadcrumbList', itemListElement: [
    { '@type': 'ListItem', position: 1, name: s.brand_name, item: `${base}/` },
    { '@type': 'ListItem', position: 2, name: p.h1, item: `${base}/${slug}` },
  ] }).replace(/</g, '\\u003c');
  const faqLd = p.blocks.some(b => b.qa?.length) ? JSON.stringify({ '@context': 'https://schema.org', '@type': 'FAQPage', mainEntity: p.blocks.flatMap(b => b.qa || []).map(([q, a]) => ({ '@type': 'Question', name: q, acceptedAnswer: { '@type': 'Answer', text: a } })) }).replace(/</g, '\\u003c') : '';
  const heroStyle = { ...(dark ? { ...DARK, ...(pal(t).hero || {}) } : {}), background: 'var(--m-hero)' } as CSSProperties;
  const h2 = v === 'stage' || v === 'horizon' ? 'text-[26px] font-light tracking-[-0.01em] sm:text-[32px]' : 'text-[24px] font-semibold tracking-[-0.03em] sm:text-[30px]';
  const radius = v === 'stage' ? 'rounded-[28px]' : v === 'card' ? 'rounded-2xl' : v === 'chat' ? 'rounded-[32px]' : 'rounded-3xl';
  const footLight = v === 'card';
  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: themeCss(t) + pageThemeCss(t) + `:root{--bar-h:${c.chanBar || c.proofText ? '36px' : '0px'}}` }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: ld }} />
      {faqLd && <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: faqLd }} />}
      <ProofBar c={c} />
      <div className="min-h-screen bg-void font-display text-fg">
        <section style={heroStyle} className={clsx('relative isolate overflow-hidden pb-14 pt-[var(--bar-h)] sm:pb-20', dark && 'text-white')}>
          {dark && <div className="pointer-events-none absolute inset-x-0 bottom-0 -z-10 h-[60%] bg-[image:var(--m-glow)]" />}
          <header className="mx-auto flex h-20 max-w-[1200px] items-center gap-6 px-6 sm:px-8">
            <Mark c={c} v={v} light={dark} />
            <nav className={clsx('ml-6 hidden gap-7 text-[14px] font-medium lg:flex', dark ? 'text-white/80' : 'text-fg-2')}>
              {INFO_PAGES.map(x => <a key={x.slug} href={`/${x.slug}`} className={clsx(x.slug === slug ? (dark ? 'text-white' : 'text-fg') + ' font-semibold' : dark ? 'hover:text-white' : 'hover:text-violet')}>{x.label}</a>)}
            </nav>
            <a href="/" className={clsx(pill(v, dark ? 'white' : 'brand'), 'ml-auto shrink-0 whitespace-nowrap !px-5 !py-2.5', (v === 'stage' || v === 'horizon') && '!text-[12px] !tracking-[0.14em]')}>Order now</a>
          </header>
          <div className="mx-auto mt-2 flex max-w-[1200px] gap-2 overflow-x-auto px-6 pb-1 [scrollbar-width:none] sm:px-8 lg:hidden">
            {INFO_PAGES.map(x => <a key={x.slug} href={`/${x.slug}`} className={clsx('shrink-0 rounded-full px-3.5 py-1.5 text-[13.5px] font-medium',
              x.slug === slug ? (dark ? 'bg-white text-[color:var(--m-ink)]' : 'bg-violet text-onp') : dark ? 'border border-white/25 text-white/85' : 'border border-edge text-fg-2')}>{x.label}</a>)}
          </div>
          <div className="mx-auto max-w-[820px] px-6 pt-10 text-center sm:px-8 sm:pt-16">
            <nav aria-label="Breadcrumb" className={clsx('mb-4 text-[13px]', dark ? 'text-white/70' : 'text-fg-3')}><a href="/" className="hover:underline">{c.brand}</a> › {p.h1}</nav>
            <h1 className={clsx('text-balance', v === 'stage' || v === 'horizon' ? 'text-[38px] font-light leading-[1.12] tracking-[-0.01em] sm:text-[58px]' : 'text-[36px] font-semibold leading-[1.05] tracking-[-0.04em] sm:text-[54px]')}>{p.h1}</h1>
            <p className={clsx('mx-auto mt-5 max-w-[56ch] text-[16.5px] leading-relaxed sm:text-[18px]', dark ? 'font-light text-white/85' : 'text-fg-2')}>{p.description}</p>
          </div>
        </section>

        <main className="mx-auto max-w-[860px] px-6 py-14 sm:px-8 sm:py-20">
          {p.blocks.map((b, i) => (
            <section key={i} className={i ? 'mt-14' : ''}>
              {b.h && <h2 className={clsx('mb-5 text-fg', h2)}>{b.h}</h2>}
              {b.p && <p className="text-[16px] leading-relaxed text-fg-2">{b.p}</p>}
              {b.list && <ul className="grid gap-3">{b.list.map((x, j) => (
                <li key={j} className="flex gap-3.5 text-[16px] leading-relaxed text-fg-2">
                  <span className="mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-full bg-[image:var(--m-grad)] text-[13px] font-bold text-white">{j + 1}</span><span className="pt-0.5">{x}</span>
                </li>))}</ul>}
              {b.rows && <div className="grid gap-4">{b.rows.map(([n, price, d], j) => (
                <div key={j} className={clsx(radius, 'p-6 sm:p-7', j === 0 ? 'bg-[image:var(--m-card)] text-white shadow-[0_30px_70px_-30px_var(--m-shadow)]' : 'border border-edge bg-plum')}>
                  <div className="flex flex-wrap items-baseline justify-between gap-2">
                    <h2 className="text-[20px] font-semibold tracking-tight">{n}</h2>
                    <span className={clsx('text-[26px] font-semibold tracking-tight', j === 0 ? (v === 'card' ? 'text-white' : 'text-[color:var(--m-accent)]') : 'text-violet')}>{price}</span>
                  </div>
                  <p className={clsx('mt-2 text-[15px] leading-relaxed', j === 0 ? 'text-white/80' : 'text-fg-2')}>{d}</p>
                </div>
              ))}</div>}
              {b.qa && <div className={clsx(v === 'card' ? 'space-y-3' : 'divide-y divide-edge border-y border-edge')}>{b.qa.map(([q, a], j) => (
                <details key={j} className={clsx('group', v === 'card' && 'rounded-2xl border border-edge bg-plum px-5')} open={j < 1}>
                  <summary className="flex cursor-pointer list-none items-center justify-between gap-5 py-5 text-[17px] font-medium text-fg [&::-webkit-details-marker]:hidden">
                    {q}<span className="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-edge text-[20px] leading-none text-violet transition-transform group-open:rotate-45">+</span>
                  </summary>
                  <p className="pb-6 pr-12 text-[15.5px] leading-relaxed text-fg-2">{a}</p>
                </details>
              ))}</div>}
            </section>
          ))}
        </main>

        <section className="px-4 pb-16 sm:px-8 sm:pb-24">
          <div style={{ background: 'var(--m-band)' }} className={clsx('mx-auto max-w-[1100px] px-6 py-12 text-center sm:py-16', radius, v === 'chat' ? 'text-[color:var(--m-ink)]' : 'text-white')}>
            <p className={clsx('text-balance', v === 'stage' || v === 'horizon' ? 'text-[28px] font-light sm:text-[40px]' : 'text-[28px] font-semibold tracking-[-0.03em] sm:text-[38px]')}>Ready when you are</p>
            <p className="mx-auto mt-3 max-w-[48ch] text-[15.5px] opacity-85">Your own agent on Telegram. {c.payment}. Live within {c.delivery}.</p>
            <div className="mt-7 flex flex-wrap justify-center gap-3">
              <a href="/" className={pill(v, v === 'chat' ? 'brand' : 'white')}>Order an ad account</a>
              <a href="/funnel" className={pill(v, v === 'chat' ? 'outline' : 'outline-white')}>Landing + funnel</a>
              {slug === 'contact' && c.channel && <a href={c.channel} target="_blank" rel="noopener" className={pill(v, v === 'chat' ? 'outline' : 'outline-white')}>Telegram channel</a>}
            </div>
          </div>
        </section>

        <footer className={footLight ? 'bg-[color:var(--m-foot)] text-fg-2' : 'bg-[color:var(--m-foot)] text-white/70'}>
          <div className="mx-auto flex max-w-[1200px] flex-col gap-8 px-6 py-14 sm:flex-row sm:items-start sm:justify-between sm:px-8">
            <div><Mark c={c} v={v} light={!footLight} /><p className="mt-4 max-w-[36ch] text-[14px] leading-relaxed">{c.footer}</p></div>
            <div className="flex flex-col gap-3 text-[14px]">
              <a href="/" className={footLight ? 'hover:text-fg' : 'hover:text-white'}>Ad accounts</a>
              <a href="/funnel" className={footLight ? 'hover:text-fg' : 'hover:text-white'}>Funnel setup</a>
              {s.premium_on === '1' && <a href="/premium" className={footLight ? 'hover:text-fg' : 'hover:text-white'}>Premium ad accounts</a>}
              {INFO_PAGES.map(x => <a key={x.slug} href={`/${x.slug}`} className={footLight ? 'hover:text-fg' : 'hover:text-white'}>{x.label}</a>)}
              {c.webOn && <a href="/account" className={footLight ? 'hover:text-fg' : 'hover:text-white'}>My account · Top up</a>}
              <a href="/telegram" className={clsx('inline-flex items-center gap-2', footLight ? 'hover:text-fg' : 'hover:text-white')}><TgIcon size={16} />Telegram channel</a>
            </div>
          </div>
          <p className={clsx('border-t px-6 py-6 text-center text-[13px]', footLight ? 'border-edge text-fg-3' : 'border-white/10 text-white/50')}>© {new Date().getFullYear()} {c.brand}</p>
        </footer>
      </div>
      {c.wa?.fab && <WaFab link={c.wa.link} above={false} />}
    </>
  );
}
