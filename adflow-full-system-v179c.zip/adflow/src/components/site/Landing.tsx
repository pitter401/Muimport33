import { LeadModalProvider, ChatFab, WaFab } from './LeadModal';
import { VcBeacon } from './Sections';
import { PremiumLanding } from './designs/Premium';
import { themeCss } from './themes';
import { ProofBar } from './Telegram';
import type { LandingContent } from '@/server/content';

/** All four themes use the premium layout; the theme only picks its colour palette.
 *  (The older designs are kept in ./designs and Sections for a quick switch back.) */
function Design({ c }: { c: LandingContent }) {
  return <PremiumLanding c={c} />;
}

export function Landing({ c }: { c: LandingContent }) {
  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: themeCss(c.theme) + `:root{--bar-h:${c.deal ? '44px' : c.proofText || c.chanBar ? '36px' : '0px'}}` }} />
      <ProofBar c={c} />
      <LeadModalProvider theme={c.theme} defaultService={c.mode === 'funnel' ? 'funnel' : 'account'} autoMsg={c.autoMsg} titles={{ account: c.account.title, funnel: c.funnel.title }}
        web={{ on: c.webOn, priceWeb: c.priceWeb, priceTg: c.priceTg }} chat={{ on: c.chatOn, text: c.chatBtnText }} fallback={c.fallback}>
        <VcBeacon theme={c.theme} delay={c.vcDelay} />
        <Design c={c} />
        {(c.chatOn || c.chanBar) && <><div aria-hidden className="h-16 sm:hidden" />{c.chanBar ? <ChatFab text={`Join our Telegram channel`} href={c.chanBar.href} /> : <ChatFab text={c.chatBtnText} />}</>}
        {c.wa?.fab && <WaFab link={c.wa.link} above={c.chatOn || !!c.chanBar} />}
      </LeadModalProvider>
    </>
  );
}
