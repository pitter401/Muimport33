/** Profit per agent / manager: ad cost shared by leads, ad account cost, commission → net profit. Admin only. */
import { all, one, run, commSql } from './db';
import { getSettings, setSetting, type Settings } from './settings';
import { num, money, now, localDate, avgReplyMs, presence } from './util';

export const LINES = ['agency', 'funnel'] as const;
export type Line = (typeof LINES)[number];
/** Ad spend lines, each its own budget: normal Agency page, /premium page, /funnel page, /telegram channel page (Subscribe ads, no leads/sales). */
export const SPEND_LINES = ['agency', 'premium', 'funnel', 'telegram', 'ch_agency', 'ch_premium', 'ch_funnel', 'wa_agency', 'wa_premium', 'wa_funnel'] as const; // ch_* = channel-ad pages (v114), wa_* = WhatsApp ad pages (v135)
export type SpendLine = (typeof SPEND_LINES)[number];
export const spendLine = (v: unknown): SpendLine => ((SPEND_LINES as readonly string[]).includes(String(v)) ? v as SpendLine : 'agency');
const DAY = 86400000;
const budget = (s: Settings, l: SpendLine) => num(l === 'funnel' ? s.ad_budget_funnel : l === 'telegram' ? s.ad_budget_telegram : l === 'premium' ? s.premium_ad_budget : l === 'ch_agency' ? s.ad_budget_ch_agency : l === 'ch_premium' ? s.ad_budget_ch_premium : l === 'ch_funnel' ? s.ad_budget_ch_funnel : l === 'wa_agency' ? s.ad_budget_wa_agency : l === 'wa_premium' ? s.ad_budget_wa_premium : l === 'wa_funnel' ? s.ad_budget_wa_funnel : s.ad_budget_agency);

/** The day each line's daily budget started, so a line switched on later (e.g. Telegram, Premium) is not filled in for the past.
 *  'off' = the line had no budget when last seen → when it gets one, it starts that day. No entry (older installs) → the old rule. */
// read straight from the database (several updates can happen inside one call, before the settings cache refreshes)
function sinceMap(_s?: Settings): Record<string, string> { try { return JSON.parse(one<{ v: string }>("SELECT v FROM settings WHERE k='ad_line_since'")?.v || '{}') || {}; } catch { return {}; } }
function setSince(s: Settings, l: SpendLine, v: string) { const m = sinceMap(s); if (m[l] === v) return; m[l] = v; setSetting('ad_line_since', JSON.stringify(m)); }
function lineSince(s: Settings, l: SpendLine, set?: string): string | null {
  if (set) { setSince(s, l, set); return set; }
  const v = sinceMap(s)[l];
  return v && v !== 'off' ? v : null;
}

/** v86: Premium became its own spend line. Before, "Agency ads / day" was Agency + Premium together → take the Premium part out once
 *  (the budget setting and the untouched daily-budget rows since Premium started). */
export function splitPremiumSpend(s: Settings = getSettings(), t = now()) {
  if (s.spend_split === '1') return;
  setSetting('spend_split', '1');
  // start day of every line: its first row; a line with a budget but no rows yet starts today
  if (s.ad_auto_since) for (const l of SPEND_LINES) {
    const first = one<{ d: string | null }>('SELECT MIN(date) d FROM ad_spend WHERE line=?', l)?.d;
    if (first) setSince(getSettings(), l, first < s.ad_auto_since ? s.ad_auto_since : first);
    else if (budget(s, l) > 0 && l !== 'premium') setSince(getSettings(), l, localDate(t, s));
  }
  // before v86 the Premium budget default was 20 (only used for the Premium tab) — keep it if it was never saved
  const saved = one<{ v: string }>("SELECT v FROM settings WHERE k='premium_ad_budget'");
  if (!saved && s.ad_auto_since && s.premium_on === '1') { setSetting('premium_ad_budget', '20'); s = getSettings(); }
  const p = money(num(s.premium_ad_budget)), a = money(num(s.ad_budget_agency));
  if (!(p > 0) || !(a >= p) || !s.ad_auto_since) return; // nothing to split (fresh install / premium off)
  setSetting('ad_budget_agency', String(money(a - p)));
  const first = one<{ v: number | null }>("SELECT MIN(created_at) v FROM leads WHERE tier='premium'")?.v;
  const from = first ? localDate(first, s) : localDate(t, s);
  lineSince(s, 'premium', from);
  for (const r of all<{ date: string }>("SELECT date FROM ad_spend WHERE line='agency' AND auto=1 AND amount=? AND date>=?", a, from)) {
    run("UPDATE ad_spend SET amount=? WHERE date=? AND line='agency'", money(a - p), r.date);
    run("INSERT OR IGNORE INTO ad_spend(date, line, amount, note, auto) VALUES(?,'premium',?,'Daily budget',1)", r.date, p);
  }
}

/** Adds each day's ad budget to Ad spend by itself (one row per day per page). A row the admin edited is never touched. */
export function ensureAutoSpend(s: Settings = getSettings(), t = now()) {
  if (s.mads_on === '1') return; // v151: spend comes from Meta — no daily budget rows
  if (s.spend_split !== '1') { splitPremiumSpend(s, t); s = getSettings(); }
  const today = localDate(t, s);
  if (!s.ad_auto_since) {
    if (!SPEND_LINES.some(l => budget(s, l) > 0)) return;
    setSetting('ad_auto_since', today); s = getSettings();
  }
  // fill missing days since the start (max 60 back, e.g. after the server was off)
  const from = s.ad_auto_since > localDate(t - 60 * DAY, s) ? s.ad_auto_since : localDate(t - 60 * DAY, s);
  for (const l of SPEND_LINES) {
    const b = money(budget(s, l));
    const row = one<{ amount: number; auto: number }>('SELECT amount, auto FROM ad_spend WHERE date=? AND line=?', today, l);
    if (row && row.auto === 1 && row.amount !== b) {
      if (b > 0) run('UPDATE ad_spend SET amount=? WHERE date=? AND line=?', b, today, l);
      else run('DELETE FROM ad_spend WHERE date=? AND line=? AND auto=1', today, l);
    }
    const m = sinceMap(getSettings());
    if (b <= 0) { if (m[l] !== 'off') setSince(getSettings(), l, 'off'); continue; }
    // switched on now → starts today; no record yet (older installs) → the old rule (since the first day of auto budgets)
    const since = m[l] === 'off' ? lineSince(getSettings(), l, today)! : m[l] || from;
    if (!m[l]) setSince(getSettings(), l, from);
    const start = since > from ? since : from;
    for (let d = start; d <= today; d = localDate(Date.parse(d + 'T12:00:00Z') + DAY - num(s.tz_offset_min) * 60000, s))
      run("INSERT OR IGNORE INTO ad_spend(date, line, amount, note, auto) VALUES(?,?,?,'Daily budget',1)", d, l, b);
  }
}

/** v151: after the Meta switch goes OFF, each line's daily budget starts again from this day (never fills the Meta days back). */
export function restartBudgetsFrom(day: string) {
  const s = getSettings();
  for (const l of SPEND_LINES) setSince(s, l, budget(s, l) > 0 ? day : 'off');
}

export function spendByLine(f: number, t: number, s: Settings) {
  const out: Record<Line, number> = { agency: 0, funnel: 0 };
  // v135: ads that bring CHATS are shared over the agents' chats: funnel pages → funnel; Agency / Premium / WhatsApp pages → agency
  // (per-agent profit: Premium chats are agency chats). Telegram channel / subscriber ads (telegram, ch_*) stay a team cost.
  for (const r of all<{ line: string; v: number }>('SELECT line, COALESCE(SUM(amount),0) v FROM ad_spend WHERE date>=? AND date<=? GROUP BY line', localDate(f, s), localDate(t - 1, s))) {
    if (r.line === 'telegram' || r.line.startsWith('ch_')) continue;
    if (/(^|_)funnel$/.test(r.line)) out.funnel = money(out.funnel + r.v);
    else out.agency = money(out.agency + r.v);
  }
  return out;
}
/** All ad spend in a range (every line) — the team total and Home use this. */
export const spendAll = (f: number, t: number, s: Settings) => money(one<{ v: number }>('SELECT COALESCE(SUM(amount),0) v FROM ad_spend WHERE date>=? AND date<=?', localDate(f, s), localDate(t - 1, s))!.v);
const KINDS = ['agency', 'premium', 'full', 'fb', 'funnel', 'other'] as const;

/** Account cost of sales in a range (sales saved before v46 have no cost → today's setting). */
/** v156: replacement accounts cost us an account (no sale). Line filter: the client's line. */
/** v166: the line filter for replacement accounts (alias l = the chat), shared by Home and the Spend page */
export const replLineSql = (line?: string | null) => (line === 'premium' ? " AND l.tier='premium'" : line === 'funnel' ? " AND l.line='funnel'" : line && line !== 'all' ? " AND COALESCE(l.line,'agency')!='funnel' AND COALESCE(l.tier,'')!='premium'" : '');
export function replCost(f: number, t: number, line?: string | null) {
  try {
    return money(one<{ v: number }>(`SELECT COALESCE(SUM(r.cost),0) v FROM meta_replacements r LEFT JOIN leads l ON l.id=r.lead_id WHERE r.created_at>=? AND r.created_at<?${replLineSql(line)}`, f, t)!.v);
  } catch { return 0; }
}
export const costSql = (s: Settings) => `COALESCE(cost, CASE WHEN service='account' THEN qty * ${num(s.acct_cost, 3)} ELSE 0 END)`;

/** A lead counts on the day it first messaged on Telegram (same base for everybody, so the shares add up to the spend). */
const LEAD_AT = 'COALESCE(l.started_at, l.assigned_at)';
/** The product kind of a sale (alias x, its lead l) — one rule for the Team cards and "What sold". */
const KIND_SQL = `CASE WHEN x.service='funnel' THEN 'funnel' WHEN x.item='fb_old' THEN 'fb' WHEN x.service='custom' THEN 'other'
           WHEN COALESCE(x.full,0)=1 OR x.item IN ('full','premium_full') THEN 'full'
           WHEN COALESCE(x.tier, CASE WHEN l.tier='premium' THEN 'premium' END)='premium' THEN 'premium' ELSE 'agency' END`;
/** v166: the commission of sale x that is `agent`'s (a split sale → only their share), as in commSql. */
const OWN_COMM = (agent: string) => `CASE WHEN EXISTS(SELECT 1 FROM sale_splits p WHERE p.sale_id=x.id) THEN COALESCE((SELECT SUM(p.share) FROM sale_splits p WHERE p.sale_id=x.id AND p.agent_id=${agent}),0) ELSE x.commission END`;

export function teamProfit(f: number, t: number) {
  const s = getSettings();
  ensureAutoSpend(s);
  const spend = spendByLine(f, t, s);
  const line = "CASE WHEN l.line='funnel' THEN 'funnel' ELSE 'agency' END";
  // leads per line (everyone, incl. chats with no agent) → cost per lead of each page
  const leadsLine: Record<Line, number> = { agency: 0, funnel: 0 };
  for (const r of all<{ ln: Line; n: number }>(`SELECT ${line} ln, COUNT(*) n FROM leads l WHERE ${LEAD_AT}>=? AND ${LEAD_AT}<? AND l.status!='merged' AND l.tg_chat_id IS NOT NULL GROUP BY ln`, f, t)) leadsLine[r.ln] = r.n;
  const cpl: Record<Line, number | null> = { agency: leadsLine.agency ? spend.agency / leadsLine.agency : null, funnel: leadsLine.funnel ? spend.funnel / leadsLine.funnel : null };
  const salesLine: Record<Line, { n: number; rev: number }> = { agency: { n: 0, rev: 0 }, funnel: { n: 0, rev: 0 } };
  for (const r of all<{ ln: Line; n: number; rev: number }>(`SELECT ${line} ln, COUNT(*) n, COALESCE(SUM(x.amount),0) rev FROM sales x LEFT JOIN leads l ON l.id=x.lead_id WHERE x.created_at>=? AND x.created_at<? AND COALESCE(x.wa,0)=0 GROUP BY ln`, f, t)) salesLine[r.ln] = { n: r.n, rev: r.rev };

  const agents = all<any>(`SELECT a.id, a.name, a.role, a.comm_per_sale, a.comm_premium, a.comm_funnel, a.receive, a.online, a.last_seen,
      (SELECT COUNT(*) FROM leads l WHERE l.agent_id=a.id AND ${LEAD_AT}>=@f AND ${LEAD_AT}<@t AND l.status!='merged' AND l.tg_chat_id IS NOT NULL AND COALESCE(l.line,'agency')!='funnel') leads_agency,
      (SELECT COUNT(*) FROM leads l WHERE l.agent_id=a.id AND ${LEAD_AT}>=@f AND ${LEAD_AT}<@t AND l.status!='merged' AND l.tg_chat_id IS NOT NULL AND l.line='funnel') leads_funnel,
      (SELECT COUNT(*) FROM sales x WHERE x.agent_id=a.id AND x.created_at>=@f AND x.created_at<@t) sales,
      (SELECT COALESCE(SUM(amount),0) FROM sales x WHERE x.agent_id=a.id AND x.created_at>=@f AND x.created_at<@t) revenue,
      ${commSql('a.id', 'x.created_at>=@f AND x.created_at<@t')} sale_comm, -- v141: 50/50 cover splits by their share
      (SELECT COALESCE(SUM(${costSql(s)}),0) FROM sales x WHERE x.agent_id=a.id AND x.created_at>=@f AND x.created_at<@t) acct_cost,
      (SELECT COALESCE(SUM(amount),0) FROM topups x WHERE x.agent_id=a.id AND x.created_at>=@f AND x.created_at<@t) topup_vol,
      (SELECT COALESCE(SUM(commission),0) FROM topups x WHERE x.agent_id=a.id AND x.created_at>=@f AND x.created_at<@t) topup_fees,
      (SELECT COALESCE(SUM(amount),0) FROM agent_bonus b WHERE b.agent_id=a.id AND b.created_at>=@f AND b.created_at<@t) bonus, -- v159: incentive from the admin (a cost)
      (SELECT COUNT(*) FROM leads l WHERE l.agent_id=a.id AND l.fu_due=1 AND l.status='active') fu_pending
    FROM agents a WHERE a.deleted=0`, { f, t });

  // v135: reply time counts only working hours (a chat at night answered in the morning is not 8 hours)
  const replies = all<{ agent_id: number; started_at: number; assigned_at: number | null; first_reply_at: number }>('SELECT agent_id, started_at, assigned_at, first_reply_at FROM leads WHERE first_reply_at IS NOT NULL AND started_at>=? AND started_at<? AND agent_id IS NOT NULL', f, t);
  for (const a of agents) { const mine = replies.filter(r => r.agent_id === a.id); a.avg_resp = avgReplyMs(mine, s); a.replies_n = mine.length; Object.assign(a, presence(a.last_seen)); } // v141: online = app used in the last 30 min
  // v135: what each agent sold — accounts by kind (Agency / Premium / full access / Funnel / other), Telegram vs WhatsApp, commission per kind
  const z = () => ({ n: 0, accts: 0, rev: 0, comm: 0 });
  for (const a of agents) { a.by_kind = Object.fromEntries(KINDS.map(k => [k, z()])); a.by_ch = { tg: { n: 0, rev: 0 }, wa: { n: 0, rev: 0 } }; a.accts_total = 0; }
  for (const r of all<{ agent_id: number; kind: typeof KINDS[number]; ch: 'tg' | 'wa'; n: number; accts: number; rev: number; comm: number }>(`SELECT x.agent_id,
      ${KIND_SQL} kind,
      CASE WHEN COALESCE(x.wa,0)=1 OR l.ch='wa' OR l.tg_chat_id LIKE 'wa:%' THEN 'wa' ELSE 'tg' END ch,
      COUNT(*) n, COALESCE(SUM(CASE WHEN x.service='account' THEN x.qty ELSE 0 END),0) accts, COALESCE(SUM(x.amount),0) rev, COALESCE(SUM(${OWN_COMM('x.agent_id')}),0) comm
    FROM sales x LEFT JOIN leads l ON l.id=x.lead_id WHERE x.created_at>=? AND x.created_at<? AND x.agent_id IS NOT NULL GROUP BY 1,2,3`, f, t)) {
    const a = agents.find(x => x.id === r.agent_id); if (!a) continue;
    const k = a.by_kind[r.kind]; k.n += r.n; k.accts += r.accts; k.rev = money(k.rev + r.rev); k.comm = money(k.comm + r.comm);
    a.by_ch[r.ch].n += r.n; a.by_ch[r.ch].rev = money(a.by_ch[r.ch].rev + r.rev); a.accts_total += r.accts;
  }
  // v166: split shares on someone else's sale → that agent's product line too (so the kinds add up to the card's commission)
  for (const r of all<{ agent_id: number; kind: typeof KINDS[number]; comm: number }>(`SELECT p.agent_id, ${KIND_SQL} kind, COALESCE(SUM(p.share),0) comm
    FROM sale_splits p JOIN sales x ON x.id=p.sale_id LEFT JOIN leads l ON l.id=x.lead_id WHERE x.created_at>=? AND x.created_at<? AND p.agent_id IS NOT x.agent_id GROUP BY 1,2`, f, t)) {
    const a = agents.find(x => x.id === r.agent_id); if (!a) continue;
    const k = a.by_kind[r.kind]; if (k) k.comm = money(k.comm + r.comm);
  }
  // real conversion: how many of the agent's chats in the range bought (repeat sales count once); follow-ups sent / won; top-up count
  for (const r of all<{ agent_id: number; bought: number; fu_sent: number; fu_won: number }>(`SELECT l.agent_id, COALESCE(SUM(EXISTS(SELECT 1 FROM sales x WHERE x.lead_id=l.id)),0) bought,
      COALESCE(SUM(COALESCE(l.fu_ever,0)>0),0) fu_sent, COALESCE(SUM(COALESCE(l.fu_ever,0)>0 AND EXISTS(SELECT 1 FROM sales x WHERE x.lead_id=l.id)),0) fu_won
    FROM leads l WHERE l.agent_id IS NOT NULL AND ${LEAD_AT}>=? AND ${LEAD_AT}<? AND l.status!='merged' AND l.tg_chat_id IS NOT NULL GROUP BY l.agent_id`, f, t)) {
    const a = agents.find(x => x.id === r.agent_id); if (!a) continue;
    a.converted = r.bought; a.fu_sent = r.fu_sent; a.fu_won = r.fu_won;
  }
  // v140: conversion for the period the admin is looking at = people who bought IN this period ÷ chats that were active
  // IN this period (the customer wrote, old chat or new) — plus buyers who didn't write (paid by link) so it never goes over 100%.
  // WhatsApp sales added by hand without a chat count as one buyer each.
  // v162: each chat active in the period counts for ONE person: the one who sold to it in the period (last sale), else its owner.
  // Bot-channel chats count only when they bought (same as Home), so the agents + "not on an agent" add up to Home.
  const own = activeByAgent(f, t);
  for (const ag of agents) {
    const o = own.get(ag.id) || { act: 0, buy: 0 };
    const nl = one<{ n: number }>('SELECT COUNT(*) n FROM sales x WHERE x.agent_id=? AND x.lead_id IS NULL AND x.created_at>=? AND x.created_at<?', ag.id, f, t)!.n;
    (ag as any).period_chats = o.act + nl; (ag as any).period_buyers = o.buy + nl;
  }
  for (const r of all<{ agent_id: number; n: number }>('SELECT agent_id, COUNT(*) n FROM topups WHERE agent_id IS NOT NULL AND created_at>=? AND created_at<? GROUP BY agent_id', f, t)) {
    const a = agents.find(x => x.id === r.agent_id); if (a) a.topups_n = r.n;
  }
  // v135: time in the app (one row per minute the app was open and talking to the server), first / last time seen in the range
  const fm = Math.floor(f / 60000), tm = Math.ceil(t / 60000);
  for (const r of all<{ agent_id: number; n: number; a: number; b: number }>('SELECT agent_id, COUNT(*) n, MIN(minute) a, MAX(minute) b FROM agent_active WHERE minute>=? AND minute<? GROUP BY agent_id', fm, tm)) {
    const a = agents.find(x => x.id === r.agent_id); if (!a) continue;
    a.active_min = r.n; a.first_at = r.a * 60000; a.last_at = r.b * 60000;
  }
  const offMin = Math.round(num(s.tz_offset_min, 330));
  for (const r of all<{ agent_id: number; d: number }>('SELECT agent_id, COUNT(DISTINCT (minute + ?) / 1440) d FROM agent_active WHERE minute>=? AND minute<? GROUP BY agent_id', offMin, fm, tm)) {
    const a = agents.find(x => x.id === r.agent_id); if (a) a.active_days = r.d;
  }
  // v151: ad cost per chat. Meta switch ON → each chat costs its campaign's Meta spend that day ÷ that campaign's chats that day;
  // the rest of the line's spend (untagged chats, other ad account money) is shared by the chats with no Meta campaign.
  // OFF → line spend ÷ line chats (as before). Same total either way.
  const leadCost = new Map<number, number>();
  const chatsL = all<{ id: number; agent_id: number | null; camp: string | null; ln: Line; at: number; bought: number; first_buy: number | null }>(`SELECT l.id, l.agent_id, l.camp, ${line} ln, ${LEAD_AT} at,
      EXISTS(SELECT 1 FROM sales x WHERE x.lead_id=l.id) bought, (SELECT MIN(x.created_at) FROM sales x WHERE x.lead_id=l.id) first_buy
    FROM leads l WHERE ${LEAD_AT}>=? AND ${LEAD_AT}<? AND l.status!='merged' AND l.tg_chat_id IS NOT NULL`, f, t);
  const meta = s.mads_on === '1';
  const tagged = new Set<number>();
  if (meta) {
    const { campDaySpend, guessLine } = require('./metaads') as typeof import('./metaads');
    const sp = campDaySpend(localDate(f, s), localDate(t - 1, s));
    const cnt = new Map<string, number>();
    const key = (c: typeof chatsL[number]) => `${localDate(c.at, s)}|${c.camp}`;
    for (const c of chatsL) if (c.camp && sp.has(key(c))) cnt.set(key(c), (cnt.get(key(c)) || 0) + 1);
    const used: Record<Line, number> = { agency: 0, funnel: 0 };
    // the campaign's money sits in the bucket of the line the campaign is mapped to (funnel pages → funnel, the rest → agency)
    const campB = new Map<string, Line | null>();
    for (const c of chatsL) {
      if (!c.camp || !sp.has(key(c))) continue;
      let b = campB.get(c.camp);
      if (b === undefined) { const g = guessLine(c.camp, s).line; b = g === 'skip' || g.startsWith('rt_') || g.startsWith('ch_') || g === 'telegram' ? null : /(^|_)funnel$/.test(g) ? 'funnel' : 'agency'; campB.set(c.camp, b); }
      if (!b) continue;
      const v = num(sp.get(key(c))) / (cnt.get(key(c)) || 1);
      leadCost.set(c.id, v); tagged.add(c.id); used[b] += v;
    }
    for (const ln of LINES) {
      const rest = Math.max(0, spend[ln] - used[ln]);
      const others = chatsL.filter(c => c.ln === ln && !tagged.has(c.id));
      for (const c of others) leadCost.set(c.id, others.length ? rest / others.length : 0);
    }
  } else for (const c of chatsL) leadCost.set(c.id, num(cpl[c.ln]));
  const per = new Map<number, { cost: number; chats: number; tagged: number; buyers: number; camps: Map<string, { chats: number; buyers: number; cost: number }> }>();
  for (const c of chatsL) {
    if (c.agent_id == null) continue;
    let p = per.get(c.agent_id); if (!p) { p = { cost: 0, chats: 0, tagged: 0, buyers: 0, camps: new Map() }; per.set(c.agent_id, p); }
    const v = leadCost.get(c.id) || 0;
    p.cost += v; p.chats++; if (tagged.has(c.id) || (!meta && c.camp)) p.tagged++; if (c.bought) p.buyers++;
    const k = c.camp || ''; const cc = p.camps.get(k) || { chats: 0, buyers: 0, cost: 0 }; cc.chats++; cc.cost += v; if (c.bought) cc.buyers++; p.camps.set(k, cc);
  }
  // new buyers vs repeat sales in the range
  const nr = new Map<number, { first: number; repeat: number }>();
  for (const r of all<{ agent_id: number; first: number; n: number }>(`SELECT x.agent_id, (x.created_at=(SELECT MIN(y.created_at) FROM sales y WHERE y.lead_id=x.lead_id)) first, COUNT(*) n
      FROM sales x WHERE x.agent_id IS NOT NULL AND x.lead_id IS NOT NULL AND x.created_at>=? AND x.created_at<? GROUP BY 1,2`, f, t)) {
    const o = nr.get(r.agent_id) || { first: 0, repeat: 0 }; if (r.first) o.first += r.n; else o.repeat += r.n; nr.set(r.agent_id, o);
  }
  const rows = agents.map(a => {
    const pa = per.get(a.id);
    const ad = money(pa ? pa.cost : 0);
    const revenue = money(a.revenue), fees = money(a.topup_fees), comm = money(a.sale_comm), acct = money(a.acct_cost);
    const bonus = money(a.bonus || 0);
    const profit = money(revenue + fees - ad - acct - comm); // v162: incentive is the owner's separate account, not taken off profit
    const cost = ad + acct + comm;
    return {
      ...a, bonus, leads: a.leads_agency + a.leads_funnel, revenue, topup_vol: money(a.topup_vol), topup_fees: fees, sale_comm: comm, acct_cost: acct,
      ad_cost: ad, cpa: a.sales ? money(ad / a.sales) : null, profit, roi: cost > 0 ? Math.round(profit / cost * 100) : null,
      converted: a.converted || 0, conv_cohort_pct: a.leads_agency + a.leads_funnel ? Math.round((a.converted || 0) / (a.leads_agency + a.leads_funnel) * 100) : null,
      // v140: shown as "Conversion" — buyers in the period ÷ chats active in the period
      period_chats: (a as any).period_chats || 0, period_buyers: (a as any).period_buyers || 0,
      conv_pct: (a as any).period_chats ? Math.round(((a as any).period_buyers || 0) / (a as any).period_chats * 100) : null,
      fu_sent: a.fu_sent || 0, fu_won: a.fu_won || 0, topups_n: a.topups_n || 0, active_min: a.active_min || 0, active_days: a.active_days || 0, first_at: a.first_at || null, last_at: a.last_at || null,
      // v151: cost per chat / per new buyer, ROAS, profit per chat, tagged %, new vs repeat sales, per-campaign split
      cost_per_chat: pa && pa.chats ? money(ad / pa.chats) : null,
      cpa_new: pa && pa.buyers ? money(ad / pa.buyers) : null, buyers_new: pa ? pa.buyers : 0,
      roas: ad > 0 ? money(revenue / ad) : null, profit_per_chat: pa && pa.chats ? money(profit / pa.chats) : null,
      tagged_pct: pa && pa.chats ? Math.round(pa.tagged / pa.chats * 100) : null,
      sales_new: nr.get(a.id)?.first || 0, sales_repeat: nr.get(a.id)?.repeat || 0,
      low_data: !pa || pa.chats < 10,
      camps: pa ? [...pa.camps.entries()].map(([camp, v]) => ({ camp: camp || null, chats: v.chats, buyers: v.buyers, cost: money(v.cost), cpa: v.buyers ? money(v.cost / v.buyers) : null })).sort((x, y) => y.chats - x.chats).slice(0, 12) : [],
    };
  }).sort((x, y) => y.profit - x.profit || y.accts_total - x.accts_total || (y.conv_pct || 0) - (x.conv_pct || 0));
  // v135: who is best at what (needs a few results so one lucky chat doesn't win)
  const best = (pick: (r: typeof rows[number]) => number | null | undefined, ok: (r: typeof rows[number]) => boolean = () => true, low = false) => {
    const c = rows.filter(r => ok(r) && pick(r) != null && (low || num(pick(r)) > 0));
    if (!c.length) return null;
    const w = c.reduce((a, b) => ((low ? num(pick(b)) < num(pick(a)) : num(pick(b)) > num(pick(a))) ? b : a));
    return { id: w.id, name: w.name, value: pick(w) };
  };
  const awards = {
    most_profitable: best(r => r.profit),
    best_converter: best(r => r.conv_pct, r => r.period_chats >= 5),
    fastest_reply: best(r => r.avg_resp, r => r.replies_n >= 3, true),
    most_premium: best(r => r.by_kind.premium.accts),
    most_accounts: best(r => r.accts_total),
    best_followups: best(r => r.fu_won, r => r.fu_sent >= 3),
    top_topups: best(r => r.topup_fees),
    most_active: best(r => r.active_min),
    // v151
    cheapest_closer: best(r => r.cpa_new, r => r.buyers_new >= 3, true),
    best_profit_per_chat: best(r => r.profit_per_chat, r => !r.low_data),
  };
  const sum = (k: string) => money(rows.reduce((x, r) => x + num(r[k]), 0));
  // v135: what is not on any agent (WhatsApp sales the admin added, website orders, top-ups with no agent) — counted in the totals,
  // so "Your net profit (whole team)" is the same number as Home → Net profit
  const off = 'x.agent_id IS NULL OR NOT EXISTS(SELECT 1 FROM agents a WHERE a.id=x.agent_id AND a.deleted=0)';
  const wa = one<{ n: number; v: number; c: number; m: number }>(`SELECT COUNT(*) n, COALESCE(SUM(amount),0) v, COALESCE(SUM(${costSql(s)}),0) c, COALESCE(SUM(commission),0) m FROM sales x WHERE (${off}) AND x.created_at>=? AND x.created_at<?`, f, t)!;
  // v161: commission not on a live agent card: unsplit sales of no / a deleted agent + a deleted agent's share of any split sale
  const offComm = money(one<{ v: number }>(`SELECT
    (SELECT COALESCE(SUM(CASE WHEN EXISTS(SELECT 1 FROM sale_splits p WHERE p.sale_id=x.id) THEN 0 ELSE x.commission END),0) FROM sales x WHERE (${off}) AND x.created_at>=? AND x.created_at<?)
   +(SELECT COALESCE(SUM(p.share),0) FROM sale_splits p JOIN sales x ON x.id=p.sale_id WHERE x.created_at>=? AND x.created_at<? AND NOT EXISTS(SELECT 1 FROM agents a WHERE a.id=p.agent_id AND a.deleted=0)) v`, f, t, f, t)!.v);
  const topOff = one<{ v: number; c: number }>(`SELECT COALESCE(SUM(amount),0) v, COALESCE(SUM(commission),0) c FROM topups x WHERE (${off}) AND x.created_at>=? AND x.created_at<?`, f, t)!;
  const web = one<{ n: number; v: number; q: number }>("SELECT COUNT(*) n, COALESCE(SUM(amount),0) v, COALESCE(SUM(CASE WHEN kind='account' THEN qty ELSE 0 END),0) q FROM web_orders WHERE status='delivered' AND delivered_at>=? AND delivered_at<?", f, t)!;
  const webTop = one<{ fee: number }>("SELECT COALESCE(SUM(fee),0) fee FROM web_topups WHERE status='done' AND done_at>=? AND done_at<?", f, t)!;
  const webAcct = money(web.q * num(s.acct_cost, 3) + replCost(f, t)); // + v156 replacement accounts
  const totalSpend = spendAll(f, t, s);
  const onAgents = sum('ad_cost');
  const offBonus = money(one<{ v: number }>('SELECT COALESCE(SUM(amount),0) v FROM agent_bonus x WHERE x.created_at>=? AND x.created_at<? AND NOT EXISTS(SELECT 1 FROM agents a WHERE a.id=x.agent_id AND a.deleted=0)', f, t)?.v || 0);
  const offProfit = money(wa.v - wa.c - offComm + topOff.c + web.v + webTop.fee - webAcct); // v162: no incentive here
  return {
    rows, awards,
    // v135: everything not on an agent card, so  Σ cards + off − spend not on agents = the team total (= Home → Net profit)
    off: {
      sales: one<{ n: number; v: number }>(`SELECT COUNT(*) n, COALESCE(SUM(amount),0) v FROM sales x WHERE (${off}) AND x.created_at>=? AND x.created_at<?`, f, t),
      topup_fees: money(topOff.c), web: { n: web.n, v: money(web.v) }, web_topup_fees: money(webTop.fee), acct_cost: money(wa.c + webAcct), comm: offComm,
      spend: money(totalSpend - onAgents), profit: money(offProfit - (totalSpend - onAgents)),
    },
    lines: LINES.map(l => ({ line: l, spend: spend[l], budget: budget(s, l), leads: leadsLine[l], cpl: cpl[l] == null ? null : money(cpl[l]!), sales: salesLine[l].n, revenue: money(salesLine[l].rev), cpa: salesLine[l].n ? money(spend[l] / salesLine[l].n) : null })),
    total: { spend: totalSpend, leads: rows.reduce((x, r) => x + r.leads, 0), sales: rows.reduce((x, r) => x + r.sales, 0) + wa.n + web.n, revenue: money(sum('revenue') + wa.v + web.v), topup_fees: money(sum('topup_fees') + topOff.c + webTop.fee), ad_cost: onAgents, acct_cost: money(sum('acct_cost') + wa.c + webAcct), sale_comm: money(sum('sale_comm') + offComm), bonus: money(sum('bonus') + offBonus), profit: money(sum('profit') + offProfit - (totalSpend - onAgents)), wa: { n: wa.n, revenue: money(wa.v), acct_cost: money(wa.c) }, web: { n: web.n, revenue: money(web.v) }, not_on_agents: money(Math.max(0, totalSpend - onAgents)) },
    acct_cost: num(s.acct_cost, 3),
    meta_on: s.mads_on === '1',
  };
}

/** v161: "What sold" — sales of a period by product (count of sales, units, revenue), the same product rule as the Team cards.
 *  `where` filters the sales (alias x, leads alias l); params come after f, t. */
export const PRODUCTS = [['agency', 'Agency ad account'], ['premium', 'Premium ad account'], ['full', 'Full access ad account'], ['fb', 'Facebook account + BM'], ['funnel', 'Landing page + funnel'], ['other', 'Other / custom']] as const;
export function salesByProduct(f: number, t: number, where = '1=1', ...params: unknown[]) { return salesByProduct0(f, t, null, where, ...params); }
/** v166: one agent's "What sold": their sales, commission by their split share, + their shares on other people's sales. */
export function agentSalesByProduct(agentId: number, f: number, t: number) {
  const rows = salesByProduct0(f, t, agentId, 'x.agent_id=?', agentId);
  for (const r of all<{ kind: string; comm: number }>(`SELECT ${KIND_SQL} kind, COALESCE(SUM(p.share),0) comm FROM sale_splits p JOIN sales x ON x.id=p.sale_id LEFT JOIN leads l ON l.id=x.lead_id
      WHERE p.agent_id=? AND x.agent_id IS NOT p.agent_id AND x.created_at>=? AND x.created_at<? GROUP BY 1`, agentId, f, t)) { const k = rows.find(x => x.k === r.kind); if (k) k.comm = money(k.comm + r.comm); }
  return rows;
}
function salesByProduct0(f: number, t: number, agentId: number | null, where = '1=1', ...params: unknown[]) {
  const rows = all<{ kind: string; n: number; units: number; rev: number; comm: number; wa_n: number; wa_rev: number }>(`SELECT
      ${KIND_SQL} kind,
      COUNT(*) n, COALESCE(SUM(MAX(COALESCE(x.qty,1),1)),0) units, COALESCE(SUM(x.amount),0) rev, COALESCE(SUM(${agentId ? OWN_COMM(String(Number(agentId))) : 'x.commission'}),0) comm,
      COALESCE(SUM(CASE WHEN COALESCE(x.wa,0)=1 OR l.ch='wa' OR l.tg_chat_id LIKE 'wa:%' THEN 1 ELSE 0 END),0) wa_n,
      COALESCE(SUM(CASE WHEN COALESCE(x.wa,0)=1 OR l.ch='wa' OR l.tg_chat_id LIKE 'wa:%' THEN x.amount ELSE 0 END),0) wa_rev
    FROM sales x LEFT JOIN leads l ON l.id=x.lead_id WHERE x.created_at>=? AND x.created_at<? AND (${where}) GROUP BY 1`, f, t, ...params);
  return PRODUCTS.map(([k, label]) => { const r = rows.find(x => x.kind === k); return { k, label, n: r?.n || 0, units: r?.units || 0, rev: money(r?.rev || 0), comm: money(r?.comm || 0), wa_n: r?.wa_n || 0, wa_rev: money(r?.wa_rev || 0) }; });
}

/** v161: where a chat / sale came from (one rule for chats and sales). Alias: l = the lead (may be NULL for a sale without a chat). */
export const SOURCES = [['lead_ads', 'Lead ads (landing page)'], ['wa_ads', 'WhatsApp ads page'], ['wa_comm', 'WhatsApp community'], ['wa_ctwa', 'Click-to-WhatsApp ads'], ['wa_direct', 'WhatsApp direct (no ad)'], ['wa_old', 'WhatsApp (old, not tracked)'], ['tg_channel', 'Telegram channel / bot'],
  ['products', 'Products page'], ['website', 'Website (shop)'], ['badge', 'Client badge (client sites)'], ['tg_direct', 'Telegram direct'], ['no_chat', 'Client without a chat'], ['wa_hand', 'WhatsApp sale (no chat linked)']] as const;
export const sourceSql = (l = 'l', saleLead = 'x.lead_id') => `CASE WHEN ${saleLead} IS NULL THEN 'wa_hand'
  WHEN ${l}.camp LIKE 'AdsBhai badge%' THEN 'badge' WHEN ${l}.source='products' THEN 'products' WHEN ${l}.source IN ('channel','bot') THEN 'tg_channel'
  WHEN COALESCE(${l}.ch,'')='wa' OR ${l}.tg_chat_id LIKE 'wa:%' THEN CASE ${l}.camp_kind WHEN 'page' THEN 'wa_ads' WHEN 'community' THEN 'wa_comm' WHEN 'ctwa' THEN 'wa_ctwa' WHEN 'direct' THEN 'wa_direct' ELSE 'wa_old' END
  WHEN COALESCE(${l}.manual_client,0)=1 THEN 'no_chat'
  WHEN ${l}.source='web' THEN 'website' WHEN ${l}.source='form' OR ${l}.vid IS NOT NULL OR COALESCE(${l}.page_url,'')!='' THEN 'lead_ads' ELSE 'tg_direct' END`;
/** New chats, people who wrote, buyers, sales and revenue of a period by source. salesWhere on x (sales) / l; leadsWhere on l. */
export function bySource(f: number, t: number, salesWhere = '1=1', leadsWhere = '1=1', sp: unknown[] = [], lp: unknown[] = []) {
  const sales = all<{ k: string; n: number; rev: number; buyers: number }>(`SELECT ${sourceSql()} k, COUNT(*) n, COALESCE(SUM(x.amount),0) rev, COUNT(DISTINCT COALESCE(x.lead_id, -x.id)) buyers
    FROM sales x LEFT JOIN leads l ON l.id=x.lead_id WHERE x.created_at>=? AND x.created_at<? AND (${salesWhere}) GROUP BY 1`, f, t, ...sp);
  const chats = all<{ k: string; n: number }>(`SELECT ${sourceSql('l', 'l.id')} k, COUNT(*) n FROM leads l WHERE COALESCE(l.started_at, l.created_at)>=? AND COALESCE(l.started_at, l.created_at)<? AND l.status!='merged' AND l.tg_chat_id IS NOT NULL AND (${leadsWhere}) GROUP BY 1`, f, t, ...lp);
  const wrote = all<{ k: string; n: number }>(`SELECT ${sourceSql('l', 'l.id')} k, COUNT(*) n FROM leads l WHERE l.status!='merged' AND (${leadsWhere}) AND l.id IN (SELECT m.lead_id FROM messages m WHERE m.dir='in' AND m.created_at>=? AND m.created_at<?) GROUP BY 1`, ...lp, f, t);
  return SOURCES.map(([k, label]) => {
    const s = sales.find(x => x.k === k), c = chats.find(x => x.k === k), w = wrote.find(x => x.k === k);
    return { k, label, chats: c?.n || 0, wrote: w?.n || 0, sales: s?.n || 0, buyers: s?.buyers || 0, rev: money(s?.rev || 0) };
  }).filter(r => r.chats || r.wrote || r.sales);
}

/** v162: chats active in a period (wrote, not a bot-channel chat; or bought) → one person each: the last seller in the period, else the chat's owner.
 *  key null = no agent. buy = those that bought in the period. */
export function activeByAgent(f: number, t: number) {
  const rows = all<{ owner: number | null; act: number; buy: number }>(`SELECT owner, COUNT(*) act, SUM(bought) buy FROM (
      SELECT l.id, CASE WHEN EXISTS(SELECT 1 FROM sales x WHERE x.lead_id=l.id AND x.created_at>=@f AND x.created_at<@t)
          THEN (SELECT x.agent_id FROM sales x WHERE x.lead_id=l.id AND x.created_at>=@f AND x.created_at<@t AND x.agent_id IS NOT NULL ORDER BY x.id DESC LIMIT 1)
          ELSE l.agent_id END owner,
        EXISTS(SELECT 1 FROM sales x WHERE x.lead_id=l.id AND x.created_at>=@f AND x.created_at<@t) bought
      FROM leads l WHERE (l.status!='merged' AND COALESCE(l.source,'')!='channel' AND l.id IN (SELECT m.lead_id FROM messages m WHERE m.dir='in' AND m.created_at>=@f AND m.created_at<@t))
        OR l.id IN (SELECT x.lead_id FROM sales x WHERE x.lead_id IS NOT NULL AND x.created_at>=@f AND x.created_at<@t)
    ) GROUP BY owner`, { f, t } as never);
  return new Map(rows.map(r => [r.owner, { act: r.act, buy: r.buy }]));
}
