/** v159: "Wait for the chat screenshot before the channel post".
 *  The share runs as always (IP change, live Meta data, the client's album + message, records). Only the channel post,
 *  the story and the Saved Messages copy wait: everything they need is kept here (no Meta call again later).
 *  The team uploads the client-chat screenshot → long ID numbers are found (OCR) and blurred (phones half) →
 *  a preview → "Post now". The worker then posts (the chat account / story live only in the worker).
 *  "Send without screenshot" posts the usual style. The post waits for ever until one of the two. */
import fs from 'fs';
import path from 'path';
import { one, all, run } from './db';
import { getSettings } from './settings';
import { now, HttpError } from './util';
import { leadById, displayName } from './crm';
import * as M from './meta';
import type { ProofData } from './proof';

export function postsDir(act?: string) {
  const db = process.env.DB_PATH || path.join(process.cwd(), 'data', 'adflow.db');
  const d = path.join(path.dirname(db), 'posts', ...(act ? [act.replace(/\D/g, '')] : []));
  fs.mkdirSync(d, { recursive: true });
  return d;
}
type Kept = { d: ProofData; manual: boolean; at: number; top: boolean };
const cleanAct = (v: unknown) => String(v || '').replace(/\D/g, '');

/** Called by deliverProof (inside the queue job) instead of posting. */
export async function holdPost(act: string, p: { d: ProofData; partner: Buffer; billing: Buffer; topImg: Buffer | null; manual: boolean }, say: (t: string) => void = () => {}) {
  const dir = postsDir(act);
  for (const f of ['shot.png', 'top.png']) { try { fs.unlinkSync(path.join(dir, f)); } catch { /* */ } }
  fs.writeFileSync(path.join(dir, 'partner.png'), p.partner);
  fs.writeFileSync(path.join(dir, 'billing.png'), p.billing);
  if (p.topImg) fs.writeFileSync(path.join(dir, 'top.png'), p.topImg);
  const kept: Kept = { d: p.d, manual: p.manual, at: now(), top: !!p.topImg };
  fs.writeFileSync(path.join(dir, 'post.json'), JSON.stringify(kept));
  run('UPDATE meta_accounts SET post_wait=?, post_ready=0, post_mode=NULL WHERE act_id=?', now(), act);
  const a = M.acctOf(act);
  const lead = a?.lead_id ? leadById(a.lead_id) : undefined;
  run('INSERT INTO meta_log(act_id, lead_id, kind, note, by, created_at) VALUES(?,?,?,?,?,?)', act, a?.lead_id ?? null, 'post_wait', 'Channel post / story waiting for the chat screenshot', 'system', now());
  say('📸 Channel post / story wait for the client-chat screenshot (Ad accounts → the account → Upload chat screenshot)');
  try {
    await M.alertTeam('📸 Upload the chat screenshot', `${lead ? displayName(lead) : 'Client'} · ${a?.name || 'act_' + act} (act_${act})\nThe account is delivered. The channel post and story wait for the client-chat screenshot: Ad accounts → the account → Upload chat screenshot.`, a?.lead_id ?? null);
  } catch { /* */ }
}

function kept(act: string): Kept | null {
  try { return JSON.parse(fs.readFileSync(path.join(postsDir(act), 'post.json'), 'utf8')) as Kept; } catch { return null; }
}
function waitingAcct(act: string) {
  const a = M.acctOf(act);
  if (!a) throw new HttpError(404, 'Account not found');
  if (!a.post_wait) throw new HttpError(400, 'This account has no post waiting');
  if ((a.post_ready || 0) > 0) throw new HttpError(409, 'The post is already being sent');
  if (!kept(act)) throw new HttpError(400, 'The saved post data is missing. Use "Send proof images again".');
  return a;
}

/* ---------------- OCR: find long numbers and blur them ---------------- */
type Box = { x0: number; y0: number; x1: number; y1: number; half: boolean };
type Word = { text: string; bbox: { x0: number; y0: number; x1: number; y1: number } };
/** Which boxes to blur: any word with 10+ digits (act_…, BM / page / user IDs), and number groups on one line
 *  that make 10+ digits together ("+91 98765 43210"). Phone-like numbers → only the right half (last digits). */
export function idBoxes(lines: Word[][]): Box[] {
  const out: Box[] = [];
  const digits = (t: string) => t.replace(/\D/g, '').length;
  const phoneLike = (t: string, n: number) => /^\+/.test(t.trim()) || (n === 10 && /^[6-9]/.test(t.replace(/\D/g, ''))) || (n === 12 && /^91[6-9]/.test(t.replace(/\D/g, '')));
  for (const ws of lines) {
    const used = new Set<number>();
    ws.forEach((w, i) => {
      const n = digits(w.text);
      if (n >= 10) { used.add(i); out.push({ ...w.bbox, half: n <= 13 && phoneLike(w.text, n) }); }
    });
    // runs of number-only words next to each other
    const isNum = (t: string) => /^[+(]?[\d()\-–.]+[,.:;]?$/.test(t.trim()) && digits(t) > 0;
    let i = 0;
    while (i < ws.length) {
      if (used.has(i) || !isNum(ws[i].text)) { i++; continue; }
      let j = i, n = 0;
      while (j < ws.length && !used.has(j) && isNum(ws[j].text)) { n += digits(ws[j].text); j++; }
      if (j - i >= 2 && n >= 10) {
        const run = ws.slice(i, j);
        const text = run.map(w => w.text).join(' ');
        out.push({ x0: Math.min(...run.map(w => w.bbox.x0)), y0: Math.min(...run.map(w => w.bbox.y0)), x1: Math.max(...run.map(w => w.bbox.x1)), y1: Math.max(...run.map(w => w.bbox.y1)), half: n <= 13 && phoneLike(text, n) });
      }
      i = j;
    }
  }
  return out;
}

let ocrBusy: Promise<unknown> = Promise.resolve();
/** One OCR at a time (memory); the worker is closed after each screenshot. */
async function ocrLines(png: Buffer): Promise<Word[][]> {
  const T = await import('tesseract.js');
  const langPath = path.join(process.cwd(), 'node_modules', '@tesseract.js-data', 'eng', '4.0.0');
  const w = await T.createWorker('eng', 1, { langPath, cacheMethod: 'none', gzip: true } as Parameters<typeof T.createWorker>[2]);
  try {
    const r = await w.recognize(png, {}, { blocks: true });
    const lines: Word[][] = [];
    for (const b of (r.data as { blocks?: { paragraphs: { lines: { words: Word[] }[] }[] }[] }).blocks || [])
      for (const p of b.paragraphs) for (const l of p.lines) lines.push(l.words.map(x => ({ text: x.text, bbox: x.bbox })));
    return lines;
  } finally { try { await w.terminate(); } catch { /* */ } }
}

/** v175: the text of a screenshot (one OCR at a time), for "Delivered by hand" (finds the act ID, BM ID, amounts). */
export async function ocrText(input: Buffer): Promise<string> {
  const sharp = (await import('sharp')).default;
  const img = await sharp(input).rotate().resize({ width: 2000, height: 2400, fit: 'inside', withoutEnlargement: true }).png().toBuffer();
  const m = await sharp(img).metadata();
  const k = (m.width || 0) < 1000 ? 2 : 1;
  const inp = k > 1 ? await sharp(img).resize({ width: (m.width || 0) * k }).png().toBuffer() : img;
  const r1 = ocrBusy.then(() => Promise.race([ocrLines(inp), new Promise<never>((_, rej) => setTimeout(() => rej(new Error('timeout')), 90000))]));
  ocrBusy = r1.catch(() => 0);
  return (await r1).map(l => l.map(w => w.text).join(' ')).join('\n');
}

/** The screenshot with every long ID blurred. Fails loudly when the text could not be read (never posts a screenshot we could not check). */
export async function blurIds(input: Buffer): Promise<{ img: Buffer; found: number; half: number }> {
  const sharp = (await import('sharp')).default;
  let img: Buffer;
  try { img = await sharp(input).rotate().resize({ width: 2400, height: 2400, fit: 'inside', withoutEnlargement: true }).png().toBuffer(); }
  catch { throw new HttpError(400, 'This file is not an image. Upload a screenshot (PNG / JPG).'); }
  const meta = await sharp(img).metadata();
  const W = meta.width || 0, H = meta.height || 0;
  if (W < 200 || H < 200) throw new HttpError(400, 'The screenshot is too small');
  // small screenshots read better a bit bigger
  const k = W < 1000 ? 2 : 1;
  const ocrIn = k > 1 ? await sharp(img).resize({ width: W * k }).png().toBuffer() : img;
  const run1 = ocrBusy.then(() => Promise.race([ocrLines(ocrIn), new Promise<never>((_, rej) => setTimeout(() => rej(new Error('timeout')), 90000))]));
  ocrBusy = run1.catch(() => 0);
  let lines: Word[][];
  try { lines = await run1; } catch (e) { throw new HttpError(500, `Could not read the screenshot to blur the IDs (${(e as Error).message}). Try again, or use "Send without screenshot".`); }
  const boxes = idBoxes(lines).map(b => ({ ...b, x0: b.x0 / k, y0: b.y0 / k, x1: b.x1 / k, y1: b.y1 / k }));
  const parts: { input: Buffer; left: number; top: number }[] = [];
  for (const b of boxes) {
    const pad = Math.max(4, Math.round((b.y1 - b.y0) * 0.25));
    let x0 = Math.max(0, Math.floor(b.x0 - pad)); const y0 = Math.max(0, Math.floor(b.y0 - pad));
    const x1 = Math.min(W, Math.ceil(b.x1 + pad)), y1 = Math.min(H, Math.ceil(b.y1 + pad));
    if (b.half) x0 = Math.max(x0, Math.round(x0 + (x1 - x0) * 0.45)); // a phone: the first digits stay readable
    const w = x1 - x0, h = y1 - y0;
    if (w < 2 || h < 2) continue;
    const sigma = Math.max(6, Math.min(40, h / 2.2));
    // pixelate + blur: the digits cannot be read back
    const small = await sharp(img).extract({ left: x0, top: y0, width: w, height: h }).resize({ width: Math.max(1, Math.round(w / 10)), height: Math.max(1, Math.round(h / 10)) }).png().toBuffer();
    const piece = await sharp(small).resize({ width: w, height: h, kernel: 'nearest' }).blur(sigma).png().toBuffer();
    parts.push({ input: piece, left: x0, top: y0 });
  }
  const outImg = parts.length ? await sharp(img).composite(parts).png().toBuffer() : img;
  return { img: outImg, found: boxes.length, half: boxes.filter(b => b.half).length };
}

/* ---------------- API (web process) ---------------- */
export async function uploadShot(actIn: unknown, image: unknown) {
  const act = cleanAct(actIn);
  waitingAcct(act);
  const m = /^data:image\/[a-z+.-]+;base64,(.+)$/i.exec(String(image || ''));
  if (!m) throw new HttpError(400, 'Choose the screenshot');
  const buf = Buffer.from(m[1], 'base64');
  if (buf.length > 25 * 1024 * 1024) throw new HttpError(400, 'The screenshot is too big (max 25 MB)');
  const r = await blurIds(buf);
  const dir = postsDir(act);
  fs.writeFileSync(path.join(dir, 'shot.png'), r.img);
  const sharp = (await import('sharp')).default;
  const prev = await sharp(r.img).resize({ height: 1400, withoutEnlargement: true }).jpeg({ quality: 82 }).toBuffer();
  return { ok: true, found: r.found, half: r.half, preview: 'data:image/jpeg;base64,' + prev.toString('base64') };
}
/** "Post now" (with the uploaded screenshot) or "Send without screenshot" → the worker posts within a few seconds. */
export function releasePost(actIn: unknown, withShot: boolean, actor: M.Actor) {
  const act = cleanAct(actIn);
  waitingAcct(act);
  if (withShot && !fs.existsSync(path.join(postsDir(act), 'shot.png'))) throw new HttpError(400, 'Upload the chat screenshot first');
  const ch = run('UPDATE meta_accounts SET post_ready=1, post_mode=? WHERE act_id=? AND post_wait>0 AND COALESCE(post_ready,0)=0', withShot ? 'shot' : 'plain', act).changes;
  if (!ch) throw new HttpError(409, 'The post is already being sent');
  run('INSERT INTO meta_log(act_id, lead_id, kind, note, by, created_at) VALUES(?,?,?,?,?,?)', act, M.acctOf(act)?.lead_id ?? null, 'post_go', withShot ? 'Post with the chat screenshot' : 'Post without screenshot', actor.name || actor.role, now());
  return { ok: true };
}
export function shotPreview(actIn: unknown) {
  const act = cleanAct(actIn);
  const f = path.join(postsDir(act), 'shot.png');
  return fs.existsSync(f) ? f : null;
}
/** Accounts whose post waits (for the Requests banner). */
export function waitingPosts() {
  return all<{ act_id: string; name: string | null; lead_id: number | null; post_wait: number; post_ready: number }>('SELECT act_id, name, lead_id, post_wait, COALESCE(post_ready,0) post_ready FROM meta_accounts WHERE post_wait>0 ORDER BY post_wait')
    .map(a => { const l = a.lead_id ? leadById(a.lead_id) : undefined; return { act_id: a.act_id, name: a.name, client: l ? displayName(l) : null, lead_id: a.lead_id, since: a.post_wait, sending: a.post_ready > 0 }; });
}

/* ---------------- worker ---------------- */
let ticking = false, booted = false;
export async function shotTick() {
  if (ticking) return 0;
  ticking = true;
  let n = 0;
  try {
    // a post left "sending" by a restart (10+ min): nothing went out yet → waiting again; the channel already got it → done (never twice)
    if (!booted) {
      booted = true;
      for (const a of all<{ act_id: string }>('SELECT act_id FROM meta_accounts WHERE post_ready=2 AND post_wait>0')) {
        const go = one<{ t: number }>("SELECT MAX(created_at) t FROM meta_log WHERE act_id=? AND kind='post_go'", a.act_id)?.t || 0;
        const went = one<{ c: number }>("SELECT COUNT(*) c FROM meta_log WHERE act_id=? AND kind IN ('post','story') AND created_at>=?", a.act_id, go)?.c || 0;
        if (went) run('UPDATE meta_accounts SET post_wait=NULL, post_ready=0, post_mode=NULL WHERE act_id=?', a.act_id);
        else run('UPDATE meta_accounts SET post_ready=0, post_mode=NULL WHERE act_id=?', a.act_id);
      }
    }
    for (const a of all<{ act_id: string; post_mode: string | null }>('SELECT act_id, post_mode FROM meta_accounts WHERE post_ready=1 AND post_wait>0 ORDER BY post_wait LIMIT 3')) {
      if (!run('UPDATE meta_accounts SET post_ready=2 WHERE act_id=? AND post_ready=1', a.act_id).changes) continue; // claim: one post only
      const log: string[] = [];
      try {
        const k = kept(a.act_id);
        if (!k) throw new Error('saved post data missing');
        const dir = postsDir(a.act_id);
        const rd = (f: string) => fs.existsSync(path.join(dir, f)) ? fs.readFileSync(path.join(dir, f)) : null;
        const partner = rd('partner.png'), billing = rd('billing.png');
        if (!partner || !billing) throw new Error('saved proof images missing');
        const shot = a.post_mode === 'shot' ? rd('shot.png') : null;
        if (a.post_mode === 'shot' && !shot) throw new Error('chat screenshot missing');
        const P = await import('./proof');
        const r = await P.postDelivery({ act: a.act_id, d: k.d, partner, billing, topImg: rd('top.png'), manual: k.manual, shot, say: t => log.push(t) });
        run('UPDATE meta_accounts SET post_wait=NULL, post_ready=0, post_mode=NULL WHERE act_id=?', a.act_id);
        run('INSERT INTO meta_log(act_id, lead_id, kind, note, by, created_at) VALUES(?,?,?,?,?,?)', a.act_id, M.acctOf(a.act_id)?.lead_id ?? null, 'post_done', log.join(' · ').slice(0, 900) || 'posted', 'system', now());
        if (r.channel === false) await M.alertTeam('⚠️ Channel post failed', `act_${a.act_id}: ${log.filter(t => /fail|refus|could not/i.test(t)).join(' · ') || log.join(' · ')}`.slice(0, 900));
        try { fs.rmSync(dir, { recursive: true, force: true }); } catch { /* */ }
        n++;
      } catch (e) {
        // nothing went out → it waits again (the team sees it and can try again)
        run('UPDATE meta_accounts SET post_ready=0, post_mode=NULL WHERE act_id=?', a.act_id);
        run('INSERT INTO meta_log(act_id, lead_id, kind, note, by, created_at) VALUES(?,?,?,?,?,?)', a.act_id, null, 'post_fail', ((e as Error).message + ' ' + log.join(' · ')).slice(0, 900), 'system', now());
        try { await M.alertTeam('⚠️ Post not sent', `act_${a.act_id}: ${(e as Error).message}. It is waiting again in Ad accounts.`); } catch { /* */ }
      }
    }
  } finally { ticking = false; }
  return n;
}
export const _test = { kept, one };
