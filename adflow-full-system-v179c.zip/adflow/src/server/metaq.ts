/**
 * v152: Ad accounts by PROFILE behind one iProxy line.
 *  - Profile = one Facebook profile (iX browser profile): one app (App ID + Secret) + one user token (60-day) → its BMs and their ad accounts.
 *  - Every Meta call of a profile goes through the one iProxy proxy (never the server IP).
 *  - Before a profile's work the IP is changed with the iProxy link and checked through the proxy (new IP, not the server, the right country).
 *  - So it is a queue: one profile at a time. Manual share / top-up / take back go first; the hourly sync after.
 */
import { one, all, run } from './db';
import { leadById, displayName } from './crm';
import { getSettings, setSetting } from './settings';
import fs from 'fs';
import path from 'path';
import { now, num, HttpError } from './util';
import { graph, graphAll, enc, dec, MetaError, request, parseProxy, maskProxy, WRITES, type Creds } from './metagraph';
import * as M from './meta';

export type Job = { id: number; profile_id: number; kind: string; ref: string | null; payload: string | null; prio: number; status: string; step: string | null; log: string | null;
  error: string | null; by: string | null; created_at: number; started_at: number | null; done_at: number | null };

const DAY = 86400000;
const fast = () => process.env.MQ_FAST === '1';
const sleep = (ms: number) => new Promise(r => setTimeout(r, fast() ? Math.min(ms, 30) : ms));
const IP_URL = () => process.env.MQ_IP_URL || 'http://ip-api.com/json/?fields=status,query,countryCode';
const KIND_LABEL: Record<string, string> = { proof: 'Proof images', setup: 'Connect profile', sync: 'Sync', request: 'Request', unshare: 'Take back', rename: 'Rename', web_order: 'Website order', web_topup: 'Website top-up', add_bm: 'Share to another BM', finish: 'Finish (name + proof)', cut: 'Take back top-up' };

/* ======================= queue ======================= */
export function enqueue(profileId: number, kind: string, ref: string, payload: Record<string, unknown>, actor: M.Actor, prio = 5) {
  if (kind === 'sync' || kind === 'setup') {
    const same = one<Job>("SELECT * FROM meta_jobs WHERE profile_id=? AND kind=? AND status='queued'", profileId, kind);
    if (same) return { id: same.id, eta_min: etaMin(same.id) };
  }
  if (kind === 'cut' || kind === 'unshare' || kind === 'request' || kind === 'proof' || kind === 'finish' || kind === 'web_order' || kind === 'web_topup') {
    const same = one<Job>("SELECT * FROM meta_jobs WHERE kind=? AND ref=? AND status IN ('queued','running')", kind, ref);
    if (same) return { id: same.id, eta_min: etaMin(same.id) };
  }
  const r = run('INSERT INTO meta_jobs(profile_id, kind, ref, payload, prio, status, by, created_at, log) VALUES(?,?,?,?,?,?,?,?,?)',
    profileId, kind, ref, JSON.stringify(payload || {}), prio, 'queued', JSON.stringify(actor), now(), '[]');
  const id = Number(r.lastInsertRowid);
  return { id, eta_min: etaMin(id) };
}
/** v155: a clear title: "Top-up $60 · Adsbhai 3 · Aditya Rawat", "Share · Adsbhai 2 → BM 123…" */
function jobLabel(j: Job) {
  const base = KIND_LABEL[j.kind] || j.kind;
  try {
    if (j.kind === 'request') {
      const r = one<M.Req>('SELECT * FROM meta_requests WHERE id=?', num(j.ref));
      if (!r) return base;
      const l = one<{ name: string | null; tg_name: string | null }>('SELECT name, tg_name FROM leads WHERE id=?', r.lead_id);
      const who = l?.name || l?.tg_name || '';
      const a = r.act_id ? M.acctOf(r.act_id) : undefined;
      return r.kind === 'topup' ? `Top-up $${r.amount ?? ''}${a ? ' · ' + (a.name || 'act_' + a.act_id) : ''}${who ? ' · ' + who : ''}` : `${r.kind === 'replace' ? 'Replacement' : 'Share'}${a ? ' · ' + (a.name || 'act_' + a.act_id) : ''}${r.client_bm ? ' → BM ' + r.client_bm : ''}${who ? ' · ' + who : ''}`;
    }
    if (['unshare', 'rename', 'proof', 'finish', 'add_bm'].includes(j.kind)) { const a = M.acctOf(j.ref); return a ? `${base} · ${a.name || 'act_' + a.act_id}` : base; }
  } catch { /* plain */ }
  return base;
}
/** Minutes until this job runs: every profile ahead of it costs one IP change (~1.5 min). */
function etaMin(id: number) {
  const j = one<Job>('SELECT * FROM meta_jobs WHERE id=?', id);
  if (!j) return 1;
  const ahead = one<{ n: number }>(`SELECT COUNT(DISTINCT profile_id) n FROM meta_jobs WHERE status IN ('queued','running') AND profile_id!=? AND (prio<? OR (prio=? AND id<?))`, j.profile_id, j.prio, j.prio, j.id)!.n;
  return Math.max(1, Math.round((ahead + 1) * 1.5));
}
function jobStep(id: number, text: string) {
  const j = one<Job>('SELECT log FROM meta_jobs WHERE id=?', id);
  let l: { at: number; t: string }[] = []; try { l = JSON.parse(j?.log || '[]'); } catch { /* */ }
  l.push({ at: now(), t: text.slice(0, 200) });
  run('UPDATE meta_jobs SET step=?, log=? WHERE id=?', text.slice(0, 200), JSON.stringify(l.slice(-40)), id);
}
const pubJob = (j: Job) => {
  let log: { at: number; t: string }[] = []; try { log = JSON.parse(j.log || '[]'); } catch { /* */ }
  const p = M.profileById(j.profile_id);
  return { id: j.id, kind: j.kind, label: jobLabel(j), ref: j.ref, status: j.status, step: j.step, error: j.error, log, prio: j.prio,
    profile: p ? `${p.ix || p.name}` : '?', profile_id: j.profile_id, created_at: j.created_at, started_at: j.started_at, done_at: j.done_at,
    eta_min: j.status === 'queued' ? etaMin(j.id) : null, by: (() => { try { return (JSON.parse(j.by || '{}') as M.Actor).name; } catch { return null; } })() };
};
export function listJobs() {
  return {
    open: all<Job>("SELECT * FROM meta_jobs WHERE status IN ('queued','running') ORDER BY status='running' DESC, prio, id").map(pubJob),
    recent: all<Job>("SELECT * FROM meta_jobs WHERE status NOT IN ('queued','running') ORDER BY id DESC LIMIT 30").map(pubJob),
  };
}
export const jobById = (id: unknown) => { const j = one<Job>('SELECT * FROM meta_jobs WHERE id=?', num(id)); return j ? pubJob(j) : null; };
export function cancelJob(id: unknown) {
  const j = one<Job>('SELECT * FROM meta_jobs WHERE id=?', num(id));
  if (!j || j.status !== 'queued') throw new HttpError(400, 'Only a waiting job can be cancelled');
  run("UPDATE meta_jobs SET status='cancelled', done_at=? WHERE id=?", now(), j.id);
  if (j.kind === 'request') run("UPDATE meta_requests SET status='pending', job_id=NULL WHERE id=? AND status='queued'", num(j.ref));
  return { ok: true };
}

/* ======================= settings ======================= */
export function qSettings() {
  const s = getSettings();
  return {
    proxy: s.mq_proxy ? maskProxy(s.mq_proxy) : '', has_link: !!s.mq_ip_link, wait_s: num(s.mq_wait_s, 20), country: s.mq_country,
    auto_sync: s.mq_auto_sync !== '0', every_min: num(s.mq_every_min, 60), auto_approve: s.mq_auto_approve !== '0', partner_hand: s.mq_partner_hand !== '0', cat_usd: num(s.meta_cat_usd, 100),
    post_on: s.meta_post_on === '1', post_chat: s.meta_post_chat, post_next: num(s.meta_post_next, 151), proof_client: s.meta_proof_client !== '0', story_on: s.meta_story_on !== '0', shot_wait: s.meta_shot_wait === '1',
    digest_on: s.meta_digest_on !== '0', digest_time: s.meta_digest_time || '22:00', digest_last: s.meta_digest_last || '',
    last_ip: s.mq_ip || null, last_ip_at: num(s.mq_ip_at) || null,
  };
}
export function saveQSettings(b: Record<string, unknown>) {
  if (b.proxy !== undefined && b.proxy !== null && String(b.proxy).trim() !== '') {
    const v = String(b.proxy).trim();
    try { if (!parseProxy(v)) throw new Error('empty'); } catch (e) { throw new HttpError(400, 'Proxy: ' + (e as Error).message); }
    setSetting('mq_proxy', v);
  }
  if (b.ip_link !== undefined && String(b.ip_link || '').trim() !== '') {
    const v = String(b.ip_link).trim();
    if (!/^https?:\/\/\S+$/i.test(v)) throw new HttpError(400, 'The change-IP link must start with http:// or https://');
    setSetting('mq_ip_link', v);
  }
  const bool = (k: string, key: Parameters<typeof setSetting>[0]) => { if (b[k] !== undefined) setSetting(key, b[k] ? '1' : '0'); };
  bool('auto_sync', 'mq_auto_sync'); bool('partner_hand', 'mq_partner_hand'); bool('auto_approve', 'mq_auto_approve'); bool('post_on', 'meta_post_on'); bool('proof_client', 'meta_proof_client'); bool('story_on', 'meta_story_on'); bool('digest_on', 'meta_digest_on'); bool('shot_wait', 'meta_shot_wait');
  if (b.digest_time !== undefined) { const v = String(b.digest_time || '').trim(); if (!/^([01]?\d|2[0-3]):[0-5]\d$/.test(v)) throw new HttpError(400, 'Time like 22:00'); setSetting('meta_digest_time', v.padStart(5, '0')); }
  if (b.wait_s !== undefined) setSetting('mq_wait_s', String(Math.min(120, Math.max(5, Math.round(num(b.wait_s, 20))))));
  if (b.every_min !== undefined) setSetting('mq_every_min', String(Math.min(1440, Math.max(30, Math.round(num(b.every_min, 60))))));
  if (b.country !== undefined) setSetting('mq_country', String(b.country || '').trim().toUpperCase().slice(0, 2));
  if (b.cat_usd !== undefined) { const v = num(b.cat_usd); if (!(v > 0)) throw new HttpError(400, 'Enter the Premium line in USD'); setSetting('meta_cat_usd', String(v)); }
  if (b.post_chat !== undefined) setSetting('meta_post_chat', String(b.post_chat || '').trim().slice(0, 80));
  if (b.post_next !== undefined) { const v = Math.round(num(b.post_next)); if (!(v > 0)) throw new HttpError(400, 'Enter the next client number'); setSetting('meta_post_next', String(v)); }
  return qSettings();
}

/* ======================= profiles ======================= */
const pubProfile = (p: M.Profile) => {
  const bms = all<M.Bm>('SELECT * FROM meta_bms WHERE profile_id=? AND deleted=0 ORDER BY id', p.id);
  const n = one<{ total: number; free: number; sold: number; disabled: number; nolimit: number }>(`SELECT COUNT(*) total, SUM(a.state='free') free, SUM(a.state IN ('assigned','invited')) sold,
    SUM(a.state='disabled') disabled, SUM(a.state='free' AND a.dsl IS NULL) nolimit FROM meta_accounts a JOIN meta_bms b ON b.bm_id=a.bm_id WHERE b.profile_id=? AND b.deleted=0 AND a.state!='gone'`, p.id)!;
  return {
    id: p.id, name: p.name, ix: p.ix, app_id: p.app_id, fb_name: p.fb_name, status: p.status, error: p.error, last_ip: p.last_ip, last_sync: p.last_sync,
    token_days: p.token_exp ? Math.floor((p.token_exp - now()) / DAY) : null, has_token: !!dec(p.token_enc), has_secret: !!dec(p.secret_enc),
    bms: bms.map(M.pubBm), accounts: n.total || 0, free: n.free || 0, sold: n.sold || 0, disabled: n.disabled || 0, no_limit: n.nolimit || 0,
    queued: one<{ n: number }>("SELECT COUNT(*) n FROM meta_jobs WHERE profile_id=? AND status IN ('queued','running')", p.id)!.n,
  };
};
export const listProfiles = () => all<M.Profile>('SELECT * FROM meta_profiles WHERE deleted=0 ORDER BY id').map(pubProfile);
export function profileDetail(id: unknown) {
  const p = M.profileById(id);
  if (!p) throw new HttpError(404, 'Profile not found');
  const bms = all<M.Bm>('SELECT * FROM meta_bms WHERE profile_id=? AND deleted=0 ORDER BY id', p.id);
  return { profile: pubProfile(p), bms: bms.map(b => ({ ...M.pubBm(b), accounts_list: M.listAccounts({ bm: b.bm_id }) })) };
}
const ADMIN: M.Actor = { role: 'admin', id: null, name: 'Admin' };
export function addProfile(b: Record<string, unknown>, actor: M.Actor = ADMIN) {
  const name = String(b.name || '').trim().slice(0, 40);
  const ix = String(b.ix || '').trim().toUpperCase().slice(0, 12);
  const appId = String(b.app_id || '').replace(/\D/g, '');
  const secret = String(b.secret || '').trim();
  const token = String(b.token || '').trim();
  if (!name) throw new HttpError(400, 'Give the profile a name');
  if (!ix) throw new HttpError(400, 'Enter the iX browser profile name (e.g. IX5)');
  if (appId.length < 8) throw new HttpError(400, 'Enter the App ID (App settings → Basic)');
  if (secret.length < 16) throw new HttpError(400, 'Enter the App Secret (App settings → Basic → Show)');
  if (token.length < 30) throw new HttpError(400, 'Paste the token from Graph API Explorer (starts with EAA…)');
  if (one('SELECT 1 FROM meta_profiles WHERE deleted=0 AND app_id=?', appId)) throw new HttpError(400, 'A profile with this App ID is already added. Open it and use “New token”.');
  const r = run("INSERT INTO meta_profiles(name, ix, app_id, secret_enc, token_enc, status, created_at) VALUES(?,?,?,?,?,'new',?)", name, ix, appId, enc(secret), enc(token), now());
  const id = Number(r.lastInsertRowid);
  const job = enqueue(id, 'setup', String(id), { exchange: true }, actor, 1);
  return { ok: true, profile: pubProfile(M.profileById(id)!), job };
}
export function updateProfile(id: unknown, b: Record<string, unknown>, actor: M.Actor = ADMIN) {
  const p = M.profileById(id);
  if (!p) throw new HttpError(404, 'Profile not found');
  if (b.name !== undefined && String(b.name).trim()) run('UPDATE meta_profiles SET name=? WHERE id=?', String(b.name).trim().slice(0, 40), p.id);
  if (b.ix !== undefined && String(b.ix).trim()) run('UPDATE meta_profiles SET ix=? WHERE id=?', String(b.ix).trim().toUpperCase().slice(0, 12), p.id);
  if (b.secret !== undefined && String(b.secret).trim().length >= 16) run('UPDATE meta_profiles SET secret_enc=? WHERE id=?', enc(String(b.secret).trim()), p.id);
  let job = null;
  if (b.token !== undefined && String(b.token).trim()) {
    if (String(b.token).trim().length < 30) throw new HttpError(400, 'Paste the token from Graph API Explorer (starts with EAA…)');
    run("UPDATE meta_profiles SET token_enc=?, status='new', error=NULL, alerted_at=NULL WHERE id=?", enc(String(b.token).trim()), p.id);
    job = enqueue(p.id, 'setup', String(p.id), { exchange: true }, actor, 1);
  }
  return { ok: true, profile: pubProfile(M.profileById(p.id)!), job };
}
export function deleteProfile(id: unknown) {
  const p = M.profileById(id);
  if (!p) throw new HttpError(404, 'Profile not found');
  const used = one<{ n: number }>("SELECT COUNT(*) n FROM meta_accounts a JOIN meta_bms b ON b.bm_id=a.bm_id WHERE b.profile_id=? AND a.state IN ('assigned','invited')", p.id)!.n;
  if (used) throw new HttpError(400, `${used} account${used > 1 ? 's are' : ' is'} still with clients. Take them back first.`);
  run("UPDATE meta_profiles SET deleted=1, token_enc='', secret_enc='' WHERE id=?", p.id);
  for (const b of all<M.Bm>('SELECT * FROM meta_bms WHERE profile_id=? AND deleted=0', p.id)) M.deleteBm(b.id);
  for (const j of all<Job>("SELECT * FROM meta_jobs WHERE profile_id=? AND status='queued'", p.id)) afterFail(j, 'Profile removed');
  run("UPDATE meta_jobs SET status='cancelled', done_at=? WHERE profile_id=? AND status='queued'", now(), p.id);
  return { ok: true };
}
export function syncProfile(id: unknown, actor: M.Actor = ADMIN) {
  const p = M.profileById(id);
  if (!p) throw new HttpError(404, 'Profile not found');
  return { ok: true, job: enqueue(p.id, 'sync', String(p.id), {}, actor, 4) };
}

/** Inside the queue (IP already changed): long token, the profile's BMs, then read every BM. */
async function doSetup(p: M.Profile, c: Creds, j: Job) {
  const pl = (() => { try { return JSON.parse(j.payload || '{}'); } catch { return {}; } })();
  if (pl.exchange) {
    jobStep(j.id, 'Making the 60-day token');
    const r = await graph<{ access_token: string; expires_in?: number }>(c, 'GET', 'oauth/access_token',
      { grant_type: 'fb_exchange_token', client_id: p.app_id, client_secret: dec(p.secret_enc), fb_exchange_token: dec(p.token_enc) });
    const exp = r.expires_in ? now() + r.expires_in * 1000 : now() + 60 * DAY;
    run('UPDATE meta_profiles SET token_enc=?, token_exp=? WHERE id=?', enc(r.access_token), exp, p.id);
    c.token = r.access_token;
  }
  const me = await graph<{ id: string; name: string }>(c, 'GET', 'me', { fields: 'id,name' });
  run('UPDATE meta_profiles SET fb_name=? WHERE id=?', me.name, p.id);
  jobStep(j.id, `Token OK: ${me.name}`);
  const biz = await graphAll<{ id: string; name: string; verification_status?: string; created_time?: string }>(c, 'me/businesses', { fields: 'id,name,verification_status,created_time', limit: 50 }, 4);
  jobStep(j.id, `${biz.length} BM${biz.length === 1 ? '' : 's'}: ${biz.map(b => b.name).join(', ')}`);
  for (const b of biz) {
    const ex = one<M.Bm>('SELECT * FROM meta_bms WHERE bm_id=?', b.id);
    if (ex) run("UPDATE meta_bms SET profile_id=?, name=?, verification=?, deleted=0, status='ok', error=NULL, alerted=0, su_id=?, su_name=? WHERE id=?", p.id, b.name, b.verification_status || null, me.id, me.name, ex.id);
    else run("INSERT INTO meta_bms(bm_id, name, token_enc, secret_enc, proxy_enc, su_id, su_name, verification, created_time, status, created_at, profile_id) VALUES(?,?,'','','',?,?,?,?,'ok',?,?)",
      b.id, b.name, me.id, me.name, b.verification_status || null, b.created_time ? Date.parse(b.created_time) : null, now(), p.id);
  }
  // BMs this profile no longer sees
  const ids = biz.map(b => b.id);
  for (const b of all<M.Bm>('SELECT * FROM meta_bms WHERE profile_id=? AND deleted=0', p.id)) if (!ids.includes(b.bm_id)) run("UPDATE meta_bms SET status='error', error='This profile no longer sees this BM' WHERE id=?", b.id);
  await syncBms(p, j);
}
async function syncBms(p: M.Profile, j: Job) {
  let n = 0;
  for (const b of all<M.Bm>('SELECT * FROM meta_bms WHERE profile_id=? AND deleted=0', p.id)) {
    jobStep(j.id, `Reading ${b.name || b.bm_id}`);
    const r = await M.syncBm(b.id);
    if (!r.ok) throw new MetaError(`${b.name || b.bm_id}: ${(r as { error?: string }).error || 'sync failed'}`, 0, 0, /token|session|expired/i.test(String((r as { error?: string }).error)) ? 'token' : 'meta');
    n += (r as { accounts?: number }).accounts || 0;
  }
  run("UPDATE meta_profiles SET last_sync=?, status='ok', error=NULL WHERE id=?", now(), p.id);
  jobStep(j.id, `${n} ad account${n === 1 ? '' : 's'} read`);
}

/* ======================= IP change ======================= */
async function ipVia(proxy: string) {
  const r = await request('GET', IP_URL(), null, proxy, 20000);
  let d: { query?: string; countryCode?: string; ip?: string; country?: string } = {};
  try { d = JSON.parse(r.text); } catch { throw new Error('IP check answered: ' + r.text.slice(0, 80)); }
  const ip = d.query || d.ip;
  if (!ip) throw new Error('IP check gave no IP');
  return { ip: String(ip), country: String(d.countryCode || d.country || '').toUpperCase() };
}
let serverIp: string | null = null;
async function serverIpOnce() {
  if (serverIp) return serverIp;
  try { serverIp = (await ipVia('')).ip; } catch { /* unknown */ }
  return serverIp;
}
/** v152: which IP each Meta route really uses (same request code as the Meta calls). No IP change. */
export async function ipCheck() {
  const s = getSettings();
  const one = async (proxy: string) => { try { const r = await ipVia(proxy); return { ip: r.ip, country: r.country, error: null as string | null }; } catch (e) { return { ip: null, country: null, error: (e as Error).message.slice(0, 120) }; } };
  const server = await one('');
  const iproxy = s.mq_proxy ? await one(s.mq_proxy) : null;
  const comments = s.cm_proxy ? await one(s.cm_proxy) : null;
  const same = (x: { ip: string | null } | null) => !!x?.ip && x.ip === server.ip;
  return { server, iproxy, comments, iproxy_leak: same(iproxy), comments_leak: same(comments), at: now() };
}
/** Change the iProxy IP and prove it changed (through the proxy). Throws when it didn't. */
export async function changeIp(say: (t: string) => void = () => {}) {
  const s = getSettings();
  if (!s.mq_proxy) throw new MetaError('Add the iProxy proxy first (Ad accounts → Profiles → iProxy line → Edit)', 0, 0, 'net');
  if (!s.mq_ip_link) throw new MetaError('Add the iProxy change-IP link first (Ad accounts → Profiles → iProxy line → Edit)', 0, 0, 'net');
  const vps = await serverIpOnce();
  if (!vps) throw new MetaError('Could not read the server IP, so the proxy cannot be checked. Nothing was sent to Meta.', 0, 0, 'net');
  let before = s.mq_ip || '';
  try { before = (await ipVia(s.mq_proxy)).ip; } catch { /* the phone may be changing already */ }
  for (let attempt = 1; attempt <= 2; attempt++) {
    const gap = num(getSettings().mq_ip_at) + 61000 - now(); // iProxy: at most one change per minute
    if (gap > 0) { say(`Waiting ${Math.ceil(gap / 1000)}s (iProxy allows one change a minute)`); await sleep(gap); }
    say(attempt === 1 ? 'Changing IP' : 'IP did not change, trying once more');
    try { await request('GET', s.mq_ip_link, null, '', 30000); } catch (e) { say('Change link: ' + (e as Error).message); }
    setSetting('mq_ip_at', String(now()));
    await sleep(num(s.mq_wait_s, 20) * 1000);
    let got: { ip: string; country: string } | null = null;
    try { got = await ipVia(s.mq_proxy); } catch (e) { say('IP check: ' + (e as Error).message); }
    if (got && got.ip !== before && got.ip !== vps && (!s.mq_country || got.country === s.mq_country)) {
      setSetting('mq_ip', got.ip);
      say(`IP changed ${mask(before)} → ${mask(got.ip)}${got.country ? ' (' + got.country + ')' : ''}`);
      return got;
    }
    if (got && got.ip === vps) throw new MetaError('The proxy shows the SERVER IP — stopped (Meta must never see the server)', 0, 0, 'net');
    if (got && s.mq_country && got.country !== s.mq_country) say(`New IP is in ${got.country || 'an unknown country'}, not ${s.mq_country}`);
  }
  throw new MetaError('IP did not change through iProxy. Check the phone / link. Nothing was sent to Meta.', 0, 0, 'net');
}
const mask = (ip: string) => (ip ? ip.replace(/^(\d+\.\d+)\.\d+\.\d+$/, '$1.x.x').replace(/^([0-9a-f]+:[0-9a-f]+):.*$/i, '$1:…') : '?');

/* ======================= the worker ======================= */
/** v154: client accounts saved "by hand" earlier (no name / partner read yet) → finish once: check partner, name "Adsbhai X …", proof. Runs after each start. */
export function finishOldShares() {
  let n = 0;
  for (const a of all<{ act_id: string; profile_id: number }>("SELECT a.act_id, b.profile_id FROM meta_accounts a JOIN meta_bms b ON b.bm_id=a.bm_id AND b.deleted=0 WHERE b.profile_id IS NOT NULL AND a.state='assigned' AND a.share_mode='bm' AND a.client_bm IS NOT NULL AND a.partner_name IS NULL AND a.proof_at IS NULL AND COALESCE(a.step,'')=''")) {
    run('UPDATE meta_accounts SET proof_at=0 WHERE act_id=?', a.act_id); // tried once: never again by itself after the next restart
    enqueue(a.profile_id, 'finish', a.act_id, {}, { role: 'admin', id: null, name: 'Auto (after update)' }, 3); n++;
  }
  return n;
}
/** v157 (once): client accounts named the old way "Adsbhai X {client} …" → "Adsbhai {our BM} X {client} {iX} {business}". */
export function renameOldClientNames() {
  const s = getSettings();
  if (s.meta_names_v157 === '1') return 0;
  const brand = s.brand_name || 'Adsbhai';
  let n = 0;
  for (const a of all<{ act_id: string; name: string | null; lead_id: number; biz_name: string | null; partner_name: string | null; bm_name: string | null; profile_id: number }>(
    "SELECT a.act_id, a.name, a.lead_id, a.biz_name, a.partner_name, b.name bm_name, b.profile_id FROM meta_accounts a JOIN meta_bms b ON b.bm_id=a.bm_id AND b.deleted=0 WHERE b.profile_id IS NOT NULL AND a.state IN ('assigned','invited') AND a.lead_id IS NOT NULL")) {
    if (!(a.name || '').toLowerCase().startsWith((brand + ' x ').toLowerCase())) continue;
    const lead = leadById(a.lead_id);
    if (!lead) continue;
    const nm = M.clientAcctName(a.bm_name, displayName(lead), M.profileById(a.profile_id)?.ix, a.biz_name || (/^BM \d/.test(a.partner_name || '') ? '' : a.partner_name) || '');
    if (nm && nm !== a.name) { enqueue(a.profile_id, 'rename', a.act_id, { name: nm }, { role: 'admin', id: null, name: 'Auto (new name format)' }, 6); n++; }
  }
  setSetting('meta_names_v157', '1');
  return n;
}
let busy = false;
let booted = false;
let lastAuto = 0;
export async function queueTick() {
  if (busy) return 0;
  busy = true;
  try {
    const s = getSettings();
    // a job left "running" by a crash → back in the queue once
    // v153: right after a server restart / update nothing is really running → every "running" job is looked at at once (else after 15 min)
    const staleBefore = booted ? now() - 15 * 60000 : now() + 1000;
    if (!booted) {
      finishOldShares(); renameOldClientNames();
      try { M.backfillCrmTopups(); } catch (e) { console.warn('[mq] top-up backfill', (e as Error).message); } // v165
      afterUpdateSync(); // v165: a new build → every profile (and old token BM) is read once
    }
    void import('./digest').then(D => D.digestTick()).catch(() => 0); // v158: daily top-up post
    void import('./shotpost').then(S => S.shotTick()).catch(e => console.warn('[shot]', (e as Error).message)); // v159: posts waiting for the chat screenshot
    booted = true;
    for (const j of all<Job & { wrote?: number }>("SELECT * FROM meta_jobs WHERE status='running' AND started_at<?", staleBefore)) {
      // safe jobs, and jobs that had not changed anything on Meta yet → back in the queue, they run again by themselves
      if (SAFE_AGAIN.includes(j.kind) || !j.wrote) { run("UPDATE meta_jobs SET status='queued', step='Restarted after a stop' WHERE id=?", j.id); jobStep(j.id, 'Server restarted, waiting in the queue again'); if (j.kind === 'request') run("UPDATE meta_requests SET status='queued' WHERE id=? AND status='running'", num(j.ref)); continue; }
      // it may have changed things on Meta already → never run it twice by itself
      const msg = 'Stopped in the middle (server restart). Check the account in Ads Manager and finish by hand.';
      run("UPDATE meta_jobs SET status='failed', error=?, done_at=? WHERE id=?", msg, now(), j.id); afterFail(j, msg, true);
      await M.alertTeam(`✋ Check by hand: ${KIND_LABEL[j.kind] || j.kind}`, `${jobWhat(j)}\n${msg}`);
    }
    // hourly auto sync (system ON + auto sync ON)
    if (M.metaEnabled() && s.mq_auto_sync !== '0' && now() - lastAuto > (process.env.MQ_FAST ? 1000 : 60000)) {
      lastAuto = now();
      const every = Math.max(30, num(s.mq_every_min, 60)) * 60000;
      for (const p of all<M.Profile>("SELECT * FROM meta_profiles WHERE deleted=0 AND status IN ('ok','error','ip_error') AND (last_sync IS NULL OR last_sync<?) AND NOT EXISTS(SELECT 1 FROM meta_jobs j WHERE j.profile_id=meta_profiles.id AND j.kind='sync' AND j.created_at>?)", now() - every, now() - every)) enqueue(p.id, 'sync', String(p.id), {}, { role: 'admin', id: null, name: 'Auto sync' }, 9);
      await tokenAlerts();
    }
    const first = one<Job>("SELECT * FROM meta_jobs WHERE status='queued' ORDER BY prio, id LIMIT 1");
    if (!first) return 0;
    const p = M.profileById(first.profile_id);
    const batch = all<Job>("SELECT * FROM meta_jobs WHERE status='queued' AND profile_id=? ORDER BY prio, id", first.profile_id);
    if (!p) { for (const j of batch) { run("UPDATE meta_jobs SET status='failed', error='Profile removed', done_at=? WHERE id=?", now(), j.id); afterFail(j, 'Profile removed'); } return 0; }
    try {
      // v154: the same profile as the last work (IP still on this profile, used in the last 15 min) → no new IP, just check it is still the same, not the server
      const s2 = getSettings();
      let kept = false;
      if (s2.mq_ip_profile === String(p.id) && s2.mq_ip && now() - Math.max(num(s2.mq_ip_used), num(s2.mq_ip_at)) < 15 * 60000) {
        try {
          const vps = await serverIpOnce();
          const got = await ipVia(s2.mq_proxy);
          if (vps && got.ip === s2.mq_ip && got.ip !== vps && (!s2.mq_country || got.country === s2.mq_country)) { kept = true; for (const j of batch) jobStep(j.id, `Same profile as the last work → IP kept (${mask(got.ip)}, ${got.country})`); }
        } catch { /* below: change it */ }
      }
      if (!kept) await changeIp(t => { for (const j of batch) jobStep(j.id, t); });
      setSetting('mq_ip_profile', String(p.id)); setSetting('mq_ip_used', String(now()));
      run('UPDATE meta_profiles SET last_ip=? WHERE id=?', getSettings().mq_ip || null, p.id);
    } catch (e) {
      const msg = (e as Error).message;
      run("UPDATE meta_profiles SET status='ip_error', error=? WHERE id=?", msg.slice(0, 300), p.id);
      for (const j of batch) { run("UPDATE meta_jobs SET status='failed', error=?, done_at=? WHERE id=?", msg, now(), j.id); afterFail(j, msg); }
      await M.alertTeam(`🌐 IP change failed: ${p.ix || p.name}`, `${msg}\n${batch.length} job${batch.length > 1 ? 's' : ''} stopped: ${batch.map(j => KIND_LABEL[j.kind] || j.kind).join(', ')}. Fix iProxy and run them again (Ad accounts → Queue).`);
      return batch.length;
    }
    for (const j of batch) {
      const cur = M.profileById(p.id);
      if (!cur) { run("UPDATE meta_jobs SET status='failed', error='Profile removed', done_at=? WHERE id=?", now(), j.id); afterFail(j, 'Profile removed'); continue; }
      run("UPDATE meta_jobs SET status='running', started_at=? WHERE id=?", now(), j.id);
      await runJob(cur, j);
    }
    setSetting('mq_ip_used', String(now()));
    return batch.length;
  } finally { busy = false; }
}

const NET_RE = /timeout|timed out|ECONN|ETIMEDOUT|EAI_AGAIN|socket hang up|fetch failed|Proxy (refused|not reachable|timeout)|network/i;
/** Jobs that are safe to run again (they read first and skip what is done). The others can move money / share twice. */
const SAFE_AGAIN = ['setup', 'sync', 'unshare', 'rename', 'finish']; // proof is safe too: images / channel post are sent once per sale (proof_at)
const jobWhat = (j: Job) => {
  if (j.kind === 'request') { const r = one<M.Req>('SELECT * FROM meta_requests WHERE id=?', num(j.ref)); const l = r ? one<{ name: string | null }>('SELECT name FROM leads WHERE id=?', r.lead_id) : null; return `Request #${j.ref}${r ? ` · ${r.kind === 'topup' ? `top-up $${r.amount} on act_${r.act_id}` : 'ad account'}` : ''}${l?.name ? ` · ${l.name}` : ''}`; }
  if (j.kind === 'web_order') return `Website order #${j.ref}`;
  if (j.kind === 'web_topup') return `Website top-up #${j.ref}`;
  return `${KIND_LABEL[j.kind] || j.kind} ${j.ref}`;
};
async function runJob(p: M.Profile, j: Job, retried = false): Promise<void> {
  let actor: M.Actor = ADMIN; try { actor = JSON.parse(j.by || '{}'); } catch { /* */ }
  const w0 = WRITES.n;
  WRITES.hook = () => { run('UPDATE meta_jobs SET wrote=1 WHERE id=? AND COALESCE(wrote,0)=0', j.id); };
  M.JOB.active = true;
  M.JOB.profileId = p.id;
  M.JOB.step = (t: string) => jobStep(j.id, t);
  try {
    const c: Creds = { token: dec(p.token_enc), secret: dec(p.secret_enc) || undefined, proxy: getSettings().mq_proxy };
    WRITES.token = c.token;
    let res: unknown = null;
    if (j.kind === 'setup') await doSetup(p, c, j);
    else if (j.kind === 'sync') await syncBms(p, j);
    else if (j.kind === 'request') {
      try {
        const r = await M.runRequest(num(j.ref), actor) as { done?: boolean; error?: string | null; status?: string };
        if (r.done === false) throw new Error(r.error || 'Request not done');
        res = r;
        await afterRequest(num(j.ref), j);
      } finally {
        // v159: a top-up message still waiting (something stopped before the image) → send it now, never lose it
        for (const [k, f] of [...M.laterMsg]) { M.laterMsg.delete(k); try { await f.send(); } catch { /* */ } }
      }
    } else if (j.kind === 'unshare') res = await M.unshareAcct(String(j.ref), actor);
    else if (j.kind === 'cut') res = await M.cutTopup(String(j.ref), JSON.parse(j.payload || '{}'), actor); // v161
    else if (j.kind === 'rename') { const pl = JSON.parse(j.payload || '{}'); res = await M.renameAcct(String(j.ref), pl.name ?? null); }
    else if (j.kind === 'proof') { const P = await import('./proof'); const pl = JSON.parse(j.payload || '{}'); res = await P.deliverProof(String(j.ref), { force: !!pl.force, step: t => jobStep(j.id, t) }); }
    else if (j.kind === 'web_order') res = await webOrderJob(num(j.ref), j);
    else if (j.kind === 'web_topup') res = await webTopupJob(num(j.ref), j);
    else if (j.kind === 'finish') { res = await M.finishShare(String(j.ref), actor); try { const P = await import('./proof'); await P.deliverProof(String(j.ref), { step: t => jobStep(j.id, t) }); } catch (e) { jobStep(j.id, 'Proof images: ' + (e as Error).message); } }
    else if (j.kind === 'add_bm') { const pl = JSON.parse(j.payload || '{}'); res = await M.addBmAcct(String(j.ref), pl.bm, actor); }
    else throw new Error('Unknown job ' + j.kind);
    jobStep(j.id, 'Done');
    run("UPDATE meta_jobs SET status='done', error=NULL, done_at=? WHERE id=?", now(), j.id);
    void res;
  } catch (e) {
    const msg = (e as Error).message || 'Error';
    // the phone's network dropped in the middle → new IP once (the link also wakes the mobile data), then the same job again
    const isNet = (e instanceof MetaError && e.kind === 'net') || NET_RE.test(msg);
    const wrote = WRITES.n !== w0;
    // a job that moves money / shares retries only when nothing was written to Meta yet; a proof post never (it could post twice)
    if (!retried && isNet && j.kind !== 'proof' && (SAFE_AGAIN.includes(j.kind) || !wrote)) {
      M.JOB.active = false;
      jobStep(j.id, 'Network problem (' + msg.slice(0, 80) + ') → changing IP and trying once more');
      try {
        await changeIp(t => jobStep(j.id, t));
        if (j.kind === 'request') run("UPDATE meta_requests SET status='queued', error=NULL WHERE id=? AND status IN ('manual','failed','running')", num(j.ref));
        return runJob(M.profileById(p.id) || p, j, true);
      } catch (e2) { jobStep(j.id, 'IP change: ' + (e2 as Error).message); }
    }
    jobStep(j.id, 'Failed: ' + msg);
    run("UPDATE meta_jobs SET status='failed', error=?, done_at=? WHERE id=?", msg.slice(0, 400), now(), j.id);
    if (e instanceof MetaError && (e.kind === 'token' || e.kind === 'perm')) {
      run("UPDATE meta_profiles SET status='blocked', error=? WHERE id=?", msg.slice(0, 300), p.id);
      await M.alertTeam(`❓ Check profile ${p.ix || p.name} (not sure what happened)`, `Meta: ${msg.slice(0, 200)}\nIt can be: a checkpoint / logout on this FB profile, the token ended, or the developer account needs verifying again. Open the profile in iX and check. Then: Ad accounts → Profiles → ${p.name} → New token.`);
    } else {
      const wasOk = p.status === 'ok';
      if (j.kind === 'setup' || j.kind === 'sync') run("UPDATE meta_profiles SET status='error', error=? WHERE id=?", msg.slice(0, 300), p.id);
      // sync: alert once when it starts failing; everything else: every failure
      if (!(j.kind === 'sync' && !wasOk)) {
        const byHand = isNet && wrote && !SAFE_AGAIN.includes(j.kind);
        await M.alertTeam(byHand ? `✋ Check by hand: ${KIND_LABEL[j.kind] || j.kind}` : `⚠️ Queue job failed: ${KIND_LABEL[j.kind] || j.kind}`,
          `${p.ix || p.name} · ${jobWhat(j)}\n${msg.slice(0, 200)}${byHand ? '\nThe network dropped after Meta was already changed, so it was not run again. Check the account in Ads Manager and finish by hand.' : '\nSee Ad accounts → Queue.'}`);
      }
    }
    afterFail(j, msg, wrote);
  } finally {
    M.JOB.active = false;
    M.JOB.profileId = 0;
    WRITES.token = '';
    WRITES.hook = null;
    M.JOB.step = () => {};
  }
}
/** A failed request goes back to the manager (Requests) with the reason. */
function afterFail(j: Job, msg: string, wrote = false) {
  if (j.kind === 'request') void import('./topupq').then(T => T.topupQueueSlow(num(j.ref))).catch(() => 0); // v160: the client's queue message
  // v155: the "account ready" message waiting for the proof images is never lost
  const act = j.kind === 'proof' || j.kind === 'finish' ? String(j.ref) : j.kind === 'request' ? one<M.Req>('SELECT * FROM meta_requests WHERE id=?', num(j.ref))?.act_id : null;
  if (act) void flushShareMsg(String(act));
  // v155: Meta was already changed (limit / top-up may be on) → never "Run again" by itself, only Done by hand after a check
  if (j.kind === 'request' && wrote && !/Partner not assigned yet|Fix partners by hand|\(#3\)|capability to make this API call/i.test(msg)) {
    run("UPDATE meta_requests SET status=CASE WHEN status IN ('done','rejected') THEN status ELSE 'manual' END, error=? WHERE id=?", ('Stopped after Meta was changed: check the account in Ads Manager (limit / top-up may already be on), then Done by hand. ' + msg).slice(0, 300), num(j.ref));
    return;
  }
  // v153: Meta does not let this app assign partners (#3) → the manager does that one step by hand
  if (j.kind === 'request' && /Partner not assigned yet|Fix partners by hand|Partner could not be checked/.test(msg)) {
    run("UPDATE meta_requests SET status=CASE WHEN status IN ('done','rejected') THEN status ELSE 'manual' END, error=? WHERE id=?", msg.slice(0, 300), num(j.ref));
    return;
  }
  if (j.kind === 'request' && /\(#3\)|capability to make this API call/i.test(msg)) {
    run("UPDATE meta_requests SET status=CASE WHEN status IN ('done','rejected') THEN status ELSE 'manual' END, error=? WHERE id=?", 'Meta does not let this app assign partners (#3). Assign the partner by hand in Business Settings → Ad accounts → Assign partner, then tap “Done by hand in Ads Manager”.', num(j.ref));
    return;
  }
  if (j.kind === 'request') run("UPDATE meta_requests SET status=CASE WHEN status IN ('done','rejected') THEN status ELSE 'failed' END, error=? WHERE id=?", msg.slice(0, 300), num(j.ref));
}

/** v155: a share message still waiting (proof failed) → send it now, without the images. */
async function flushShareMsg(act: string) {
  const a = M.acctOf(act) as (M.Acct & { share_msg?: number }) | undefined;
  if (!a?.share_msg || !a.lead_id) return;
  run('UPDATE meta_accounts SET share_msg=0 WHERE act_id=?', act);
  try { const { tellClient } = await import('./clientmsg'); await tellClient(leadById(a.lead_id), a.repl_of ? 'meta_msg_replace' : 'meta_msg_share', { acts: [act], bm: a.client_bm, balance: Math.max(0, a.locked ? 0 : a.cap - a.spent) / 100 }); } catch { /* best effort */ }
}
/** After a share: proof images to the client (or Saved Messages for a manual client) + the channel post. Never fails the share. */
async function afterRequest(reqId: number, j: Job) {
  const r = one<M.Req>('SELECT * FROM meta_requests WHERE id=?', reqId);
  if (!r || r.status !== 'done' || !r.act_id) return;
  // v157: a top-up on its own → the top-up proof image to the client (no channel post)
  if (r.kind === 'topup') {
    // v160: the image goes with the "Top-up done" text as its caption (one message); no image in the chat → the text alone
    const later = M.laterMsg.get(r.act_id);
    if (later) M.laterMsg.delete(r.act_id);
    let captioned = false;
    try { const P = await import('./proof'); captioned = !!(await P.deliverTopupProof(r.act_id, r.amount || 0, r.fee || 0, t => jobStep(j.id, t), later?.text || '')).captioned; } catch (e) { jobStep(j.id, 'Top-up image: ' + (e as Error).message); }
    if (later && !captioned) { try { await later.send(); jobStep(j.id, 'Top-up message sent to the client'); } catch (e) { jobStep(j.id, 'Top-up message: ' + (e as Error).message); } }
    try { await (await import('./topupq')).topupQueueDone(reqId); } catch { /* */ }
    return;
  }
  // v156: replacements get the proof images too (no channel post)
  try {
    const P = await import('./proof');
    await P.deliverProof(r.act_id, { manual: !!r.manual, step: t => jobStep(j.id, t) });
  } catch (e) { jobStep(j.id, 'Proof images: ' + (e as Error).message); }
  await flushShareMsg(r.act_id);
}

/* ======================= website orders / top-ups (auto) ======================= */
/** A paid website ad-account order → shared automatically (Auto approve ON, system ON, BM ID given, accounts in stock). */
export async function autoWebOrder(orderId: number) {
  const s = getSettings();
  if (!M.metaEnabled() || s.mq_auto_approve === '0' || s.mq_partner_hand !== '0') return false;
  const o = one<{ id: number; kind: string; qty: number; bm_id: string | null; tier: string | null; full: number | null; status: string }>('SELECT * FROM web_orders WHERE id=?', orderId);
  if (!o || o.kind !== 'account' || o.full || !o.bm_id) return false;
  const cat = o.tier === 'premium' ? 'premium' : 'std';
  // one profile must have the whole order in stock (one IP change, one profile)
  const per = new Map<number, number>();
  for (const a of M.freeAccounts(cat).filter(x => x.bstatus === 'ok')) { const pid = M.bmOf(a.bm_id)?.profile_id; if (pid) per.set(pid, (per.get(pid) || 0) + 1); }
  const pick = [...per.entries()].filter(([, n]) => n >= (o.qty || 1)).sort((x, y) => y[1] - x[1])[0];
  if (!pick) return false;
  enqueue(pick[0], 'web_order', String(o.id), {}, { role: 'admin', id: null, name: 'Website' }, 2);
  return true;
}
async function webOrderJob(orderId: number, j: Job) {
  const S = await import('./shop');
  const o = one<any>('SELECT * FROM web_orders WHERE id=?', orderId);
  if (!o || o.status !== 'paid') throw new Error('Order is not waiting for delivery');
  const cust = one<{ email: string; name: string | null }>('SELECT email, name FROM customers WHERE id=?', o.customer_id);
  const leadId = o.lead_id || clientLead(o.name || cust?.name || cust?.email || `Web ${o.code}`, 'web');
  const cat = o.tier === 'premium' ? 'premium' : 'std';
  const qty = Math.max(1, o.qty || 1);
  // only this profile's accounts (its IP was just changed), and all of them in stock before the first share
  const mine = () => M.freeAccounts(cat).filter(x => x.bstatus === 'ok' && M.bmOf(x.bm_id)?.profile_id === j.profile_id);
  if (mine().length < qty) throw new Error(`Only ${mine().length} free ${cat === 'premium' ? 'Premium' : '$25'} account${mine().length === 1 ? '' : 's'} on this profile, order needs ${qty}. Deliver it by hand (Website orders).`);
  const acts: string[] = [];
  try {
    for (let i = 0; i < qty; i++) {
      if (one<{ status: string }>('SELECT status FROM web_orders WHERE id=?', orderId)?.status !== 'paid') throw new Error('The order was delivered or cancelled meanwhile'); // v166: re-checked before each share
      const a = mine()[0];
      if (!a) throw new Error('Ran out of free accounts');
      jobStep(j.id, `Sharing act_${a.act_id} to BM ${o.bm_id}`);
      await M.shareAcct(a.act_id, { lead_id: leadId, mode: 'bm', client_bm: o.bm_id, agent_id: null, biz_name: null }, { role: 'admin', id: null, name: 'Website' });
      acts.push(a.act_id);
    }
  } catch (e) {
    if (acts.length) {
      (e as Error).message = `${(e as Error).message}. Already shared: ${acts.map(a => 'act_' + a).join(', ')} (${acts.length} of ${qty}). Finish the order by hand.`;
      WRITES.n++; // never run again by itself
    }
    throw e;
  }
  await S.deliverOrder(o, acts, '', 'auto');
  run("UPDATE tasks SET status='done', result=?, done_at=?, done_by='auto' WHERE order_id=? AND status='open'", acts.map(a => 'act_' + a).join(', '), now(), o.id);
  for (const a of acts) { try { const P = await import('./proof'); await P.deliverProof(a, { manual: true, step: t => jobStep(j.id, t) }); } catch (e) { jobStep(j.id, 'Proof: ' + (e as Error).message); } }
  return { acts };
}
export async function autoWebTopup(topupId: number) {
  const s = getSettings();
  if (!M.metaEnabled() || s.mq_auto_approve === '0') return false;
  const tp = one<{ id: number; act_id: string; amount: number; status: string }>('SELECT * FROM web_topups WHERE id=?', topupId);
  if (!tp) return false;
  const a = M.acctOf(tp.act_id);
  if (!a || !['assigned', 'invited'].includes(a.state)) return false;
  const bm = M.bmOf(a.bm_id);
  if (!bm?.profile_id) return false;
  enqueue(bm.profile_id, 'web_topup', String(tp.id), {}, { role: 'admin', id: null, name: 'Website' }, 1);
  return true;
}
async function webTopupJob(topupId: number, j: Job) {
  const S = await import('./shop');
  const tp = one<any>('SELECT * FROM web_topups WHERE id=?', topupId);
  if (!tp || tp.status !== 'paid') throw new Error('Top-up is not waiting');
  jobStep(j.id, `Adding $${tp.amount} to act_${tp.act_id}`);
  await M.topupAcct(tp.act_id, { amount: tp.amount, paid: tp.total, fee: num(tp.total) - num(tp.amount), agent_id: null, note: 'website ' + tp.code }, { role: 'admin', id: null, name: 'Website' });
  await S.finishTopup(tp, '', 'auto');
  run("UPDATE tasks SET status='done', result='auto', done_at=?, done_by='auto' WHERE topup_id=? AND status='open'", now(), tp.id);
  return { ok: true };
}

/** A client who is not in our chats (WhatsApp group, website): a lead row without a chat, so shares / credit / log work the same. */
export function clientLead(name: string, src: 'manual' | 'web') {
  const nm = String(name || '').trim().slice(0, 60) || 'Client';
  const r = run("INSERT INTO leads(token, source, name, status, created_at, started_at, manual_client) VALUES(?,?,?,'active',?,?,1)", `mc_${now()}_${Math.random().toString(36).slice(2, 8)}`, src, nm, now(), now());
  return Number(r.lastInsertRowid);
}

/** Manual share for a client without a chat in the app (agent → request, manager → shared right away). */
export async function manualShare(actor: M.Actor, b: Record<string, unknown>) {
  const name = String(b.client_name || '').trim();
  if (!name) throw new HttpError(400, 'Enter the client’s name');
  const bmId = String(b.client_bm || '').replace(/\D/g, '');
  if (bmId.length < 8 || bmId.length > 20) throw new HttpError(400, 'Enter the client’s Business Manager ID (numbers only)');
  const leadId = clientLead(name, 'manual');
  const lead = (await import('./crm')).leadById(leadId)!;
  return M.createRequest(actor, { ...b, kind: 'account', mode: 'bm', method: b.method || (actor.role === 'agent' ? 'upi' : 'manual') }, lead);
}

/** Admin: make + send the proof images / post again (live data → inside the queue). */
export function proofAgain(act: unknown, actor: M.Actor) {
  const a = M.acctOf(act);
  if (!a || !['assigned', 'invited'].includes(a.state)) throw new HttpError(400, 'This account is not with a client');
  const bm = M.bmOf(a.bm_id);
  if (!bm?.profile_id) throw new HttpError(400, 'Proof images are made for accounts of a profile');
  return { ok: true, queued: true, job: enqueue(bm.profile_id, 'proof', a.act_id, { force: 1 }, actor, 3) };
}

/* ======================= token alerts ======================= */
async function tokenAlerts() {
  for (const p of all<M.Profile>('SELECT * FROM meta_profiles WHERE deleted=0 AND token_exp IS NOT NULL AND token_exp<? AND (alerted_at IS NULL OR alerted_at<?)', now() + 7 * DAY, now() - DAY)) {
    run('UPDATE meta_profiles SET alerted_at=? WHERE id=?', now(), p.id);
    const d = Math.max(0, Math.floor((num(p.token_exp) - now()) / DAY));
    await M.alertTeam(`🔑 Token ends in ${d} day${d === 1 ? '' : 's'}: ${p.ix || p.name}`, `Make a new token in Graph API Explorer (same iX profile) → Ad accounts → Profiles → ${p.name} → New token.`);
  }
}

/** v165: after every server update (new build) → read everything once: each profile through the queue (IP change first), old token BMs directly. */
function afterUpdateSync() {
  let build = '';
  try { build = fs.readFileSync(path.join(process.cwd(), '.next', 'BUILD_ID'), 'utf8').trim(); } catch { return; }
  if (!build || getSettings().synced_build === build) return;
  setSetting('synced_build', build);
  let n = 0;
  for (const p of all<{ id: number }>("SELECT id FROM meta_profiles WHERE deleted=0 AND status IN ('ok','error','ip_error')")) { try { syncProfile(p.id); n++; } catch { /* */ } }
  void M.metaTick(true).catch(() => 0);
  if (n) console.log(`[mq] update ${build}: ${n} profile sync(s) queued`);
}
