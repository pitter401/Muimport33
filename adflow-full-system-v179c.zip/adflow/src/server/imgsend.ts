// v168: photos always go in full quality ("HD"). We never resize or recompress an image: the ORIGINAL bytes are stored
// and sent. Here we only decide HOW an image goes (as a photo or as a file), per platform, so the customer always gets
// the full resolution, and so what we store (photo vs document) matches what the platform echoes back.
//
// Platform rules (documented limits):
//  - WhatsApp Cloud API (WATI): an image message is JPEG or PNG, at most 5 MB. The uploaded file is what is delivered
//    (the API has no "HD" flag). Anything else (WebP, HEIC, > 5 MB) → sent as a document (a file, original bytes).
//  - Telegram Bot API sendPhoto / MTProto photo: at most 10 MB, width + height ≤ 10000, aspect ratio ≤ 20. Telegram
//    makes its own sizes from the original, the largest 2560 px on the long side (the "HD" size). A photo with a long
//    side > 2560 px would lose resolution → sent as a document instead (full resolution, original bytes).

export type ImgInfo = { fmt: 'png' | 'jpeg' | 'webp' | 'gif' | 'heic'; w: number; h: number } | null;
const IMG_EXT = /\.(png|jpe?g|webp|heic|heif)$/i;
const IMG_MIME = /^image\/(png|jpe?g|pjpeg|webp|heic|heif)\b/i;

/** Is this an image file we treat as a photo (png / jpg / jpeg / webp / heic), by mime type or by file name? */
export const isImageFile = (name?: string | null, mime?: string | null) => IMG_MIME.test(String(mime || '')) || IMG_EXT.test(String(name || '').trim());
/** A stored row / echo that is an image (a photo, or a document whose name is an image). */
export const looksImage = (kind?: string | null, nameOrRef?: string | null) =>
  kind === 'photo' || kind === 'image' || (!!nameOrRef && /\.(png|jpe?g|webp|heic|heif)(\b|$)/i.test(String(nameOrRef)));

/** Format and pixel size read from the file header (no decoding, nothing changed). null = not known. */
export function imgInfo(b: Buffer): ImgInfo {
  try {
    if (b.length >= 24 && b.readUInt32BE(0) === 0x89504e47 && b.toString('ascii', 12, 16) === 'IHDR') return { fmt: 'png', w: b.readUInt32BE(16), h: b.readUInt32BE(20) };
    if (b.length >= 10 && b.toString('ascii', 0, 3) === 'GIF') return { fmt: 'gif', w: b.readUInt16LE(6), h: b.readUInt16LE(8) };
    if (b.length >= 30 && b.toString('ascii', 0, 4) === 'RIFF' && b.toString('ascii', 8, 12) === 'WEBP') {
      const c = b.toString('ascii', 12, 16);
      if (c === 'VP8X') return { fmt: 'webp', w: 1 + b.readUIntLE(24, 3), h: 1 + b.readUIntLE(27, 3) };
      if (c === 'VP8L') { const v = b.readUInt32LE(21); return { fmt: 'webp', w: 1 + (v & 0x3fff), h: 1 + ((v >> 14) & 0x3fff) }; }
      if (c === 'VP8 ') return { fmt: 'webp', w: b.readUInt16LE(26) & 0x3fff, h: b.readUInt16LE(28) & 0x3fff };
      return null;
    }
    if (b.length >= 12 && b.toString('ascii', 4, 8) === 'ftyp' && /heic|heix|hevc|mif1|msf1|heif/.test(b.toString('ascii', 8, 12))) return { fmt: 'heic', w: 0, h: 0 };
    if (b.length >= 4 && b[0] === 0xff && b[1] === 0xd8) {
      let i = 2;
      while (i + 9 < b.length) {
        if (b[i] !== 0xff) { i++; continue; }
        const mk = b[i + 1];
        if (mk === 0xd8 || mk === 0x01 || (mk >= 0xd0 && mk <= 0xd7) || mk === 0xff) { i += mk === 0xff ? 1 : 2; continue; }
        const len = b.readUInt16BE(i + 2);
        // SOF0..SOF15 except DHT (C4), JPG (C8), DAC (CC)
        if (mk >= 0xc0 && mk <= 0xcf && mk !== 0xc4 && mk !== 0xc8 && mk !== 0xcc) return { fmt: 'jpeg', w: b.readUInt16BE(i + 7), h: b.readUInt16BE(i + 5) };
        if (mk === 0xda) break; // start of scan: no size found before it
        i += 2 + len;
      }
      return { fmt: 'jpeg', w: 0, h: 0 };
    }
  } catch { /* broken header */ }
  return null;
}
const MIME: Record<string, string> = { png: 'image/png', jpeg: 'image/jpeg', webp: 'image/webp', gif: 'image/gif', heic: 'image/heic' };
/** The real mime of an image (from its bytes, then its name) — used when the browser sent none. */
export function imageMime(b: Buffer, name?: string | null, mime?: string | null) {
  if (mime && IMG_MIME.test(mime)) return mime;
  const i = imgInfo(b); if (i) return MIME[i.fmt];
  const e = String(name || '').toLowerCase().match(IMG_EXT)?.[1];
  return e ? (e === 'jpg' || e === 'jpeg' ? 'image/jpeg' : e === 'heif' ? 'image/heic' : 'image/' + e) : mime || '';
}

export const WA_IMG_MAX = 5 * 1024 * 1024, TG_PHOTO_MAX = 10 * 1024 * 1024, TG_HD_SIDE = 2560;
/** How an image goes so it arrives in full resolution: 'photo' or 'document'. null = not an image (caller keeps its kind).
 *  `asked` = the kind the app asked for ('document' = the app's "Send without compression" — kept on Telegram, where a
 *  file is the original; on WhatsApp WATI sends a JPEG / PNG as an image anyway, so it is stored as the photo it becomes). */
export function imageSendKind(ch: 'wa' | 'tg', b: Buffer, name?: string | null, mime?: string | null, asked?: string | null): 'photo' | 'document' | null {
  if (!isImageFile(name, mime) && !imgInfo(b)) return null;
  const i = imgInfo(b);
  if (i?.fmt === 'gif') return null; // GIFs keep their old handling
  const fmt = i?.fmt || (/png/i.test(String(mime) + String(name)) ? 'png' : /jpe?g/i.test(String(mime) + String(name)) ? 'jpeg' : 'other');
  if (ch === 'wa') return (fmt === 'png' || fmt === 'jpeg') && b.length <= WA_IMG_MAX ? 'photo' : 'document';
  if (asked === 'document') return 'document';
  if (b.length > TG_PHOTO_MAX || fmt === 'heic') return 'document';
  if (i && i.w > 0 && i.h > 0) {
    const long = Math.max(i.w, i.h), short = Math.min(i.w, i.h);
    if (long > TG_HD_SIDE || i.w + i.h > 10000 || long / short > 20) return 'document'; // Telegram would shrink it
  }
  return 'photo';
}
