/* Admin → System: upload a new version zip and update, or build the Android apps — from the Admin app.
 * Each job runs as its own background process (it survives the web app restarting during the update)
 * and writes its output to data/jobs/<id>.log; the Admin app shows it live. */
import fs from 'fs';
import path from 'path';
import { execFileSync, spawn } from 'child_process';
import { HttpError } from './util';

export type JobKind = 'update' | 'apk';
export type Job = { id: string; kind: JobKind; started: number; file?: string; status: 'running' | 'ok' | 'failed'; code: number | null; ended: number | null };

const APP = () => process.cwd();                       // /root/adflow
const PARENT = () => path.dirname(APP());              // /root
const NAME = () => path.basename(APP());               // adflow
export const jobsDir = () => {
  const d = path.join(path.dirname(process.env.DB_PATH || path.join(APP(), 'data', 'adflow.db')), 'jobs');
  fs.mkdirSync(d, { recursive: true });
  return d;
};
const MAX_RUN = 2 * 3600_000;
/** job ids are "<kind>-<started ms>" → newest first by time (sorting by name put every "apk-…" after all "update-…") */
const byNewest = (a: string, b: string) => Number(b.split('-').pop()) - Number(a.split('-').pop());

function readJob(id: string): Job | null {
  try {
    const meta = JSON.parse(fs.readFileSync(path.join(jobsDir(), id + '.json'), 'utf8'));
    const exitF = path.join(jobsDir(), id + '.exit');
    let code: number | null = null, ended: number | null = null;
    if (fs.existsSync(exitF)) { code = Number(fs.readFileSync(exitF, 'utf8').trim()); ended = fs.statSync(exitF).mtimeMs; }
    // v173: the job's shell died without writing .exit (killed by a signal / reboot) → failed now, not "running" for 2 h
    let dead = false;
    if (code === null && Date.now() - meta.started > 20_000) {
      try { const pid = Number(fs.readFileSync(path.join(jobsDir(), id + '.pid'), 'utf8').trim()); if (pid > 1) { try { process.kill(pid, 0); } catch (e) { dead = (e as NodeJS.ErrnoException).code === 'ESRCH'; } } } catch { /* no pid file (older job) */ }
      if (dead) { try { fs.writeFileSync(exitF, '137'); } catch { /* read-only */ } code = 137; ended = Date.now(); }
    }
    const stale = code === null && Date.now() - meta.started > MAX_RUN;
    return { ...meta, code, ended, status: code === null ? (stale ? 'failed' : 'running') : code === 0 ? 'ok' : 'failed' };
  } catch { return null; }
}
export function listJobs(limit = 15): Job[] {
  const ids = fs.readdirSync(jobsDir()).filter(f => f.endsWith('.json')).map(f => f.slice(0, -5)).sort(byNewest).slice(0, limit);
  return ids.map(readJob).filter(Boolean) as Job[];
}
export const runningJob = () => listJobs(5).find(j => j.status === 'running') || null;

export function jobLog(id: string, from = 0) {
  if (!/^[a-z]+-\d+$/.test(id)) throw new HttpError(400, 'Bad job');
  const f = path.join(jobsDir(), id + '.log');
  if (!fs.existsSync(f)) return { text: '', next: 0, job: readJob(id) };
  const size = fs.statSync(f).size;
  const start = Math.max(0, Math.min(from, size), size - 400_000);
  const fd = fs.openSync(f, 'r');
  const buf = Buffer.alloc(size - start);
  fs.readSync(fd, buf, 0, buf.length, start);
  fs.closeSync(fd);
  // eslint-disable-next-line no-control-regex
  const text = buf.toString('utf8').replace(/\x1b\[[0-9;?]*[A-Za-z]/g, '').replace(/\r(?!\n)/g, '\n');
  return { text, next: size, job: readJob(id) };
}

/** Keep the 20 newest jobs (never the one just started). */
export function pruneJobs(keepId: string) {
  try {
    const dir = jobsDir();
    const all = fs.readdirSync(dir).filter(f => f.endsWith('.json')).map(f => f.slice(0, -5)).filter(x => x !== keepId).sort(byNewest);
    for (const f of all.slice(19)) for (const ext of ['.json', '.log', '.exit', '.sh', '.zip', '.pid']) try { fs.unlinkSync(path.join(dir, f + ext)); } catch { /* gone */ }
  } catch { /* fine */ }
}
/** Starts a bash script fully detached (double fork) so `pm2 reload` of the web app can't kill it. */
function launch(kind: JobKind, script: string, file?: string): Job {
  if (runningJob()) throw new HttpError(409, 'Another update/build is still running — wait for it to finish');
  const id = `${kind}-${Date.now()}`;
  const dir = jobsDir();
  const sh = path.join(dir, id + '.sh'), log = path.join(dir, id + '.log'), exit = path.join(dir, id + '.exit');
  fs.writeFileSync(path.join(dir, id + '.json'), JSON.stringify({ id, kind, started: Date.now(), file }));
  // v173: the shell writes its pid (a dead job is seen at once) and, when a signal stops it, says so in the log with who was running
  // (for finding what sent it) and writes .exit, so Build apps is never blocked by a job that is gone
  const pidF = path.join(dir, id + '.pid');
  fs.writeFileSync(sh, `#!/usr/bin/env bash\nexport PATH="$PATH:/usr/local/bin:/usr/bin:/bin"\nexport JOBLOG=${JSON.stringify(log)}\necho $$ > ${JSON.stringify(pidF)}\n`
    + `on_sig() { { echo; echo "==> ⚠️ Stopped by signal $1 at $(date '+%H:%M:%S'). Processes then:"; ps -eo pid,ppid,etime,args 2>/dev/null | grep -E 'pm2|node|npm|next|timeout' | grep -v grep | head -25; } >> ${JSON.stringify(log)} 2>&1; echo 143 > ${JSON.stringify(exit)}; trap - TERM INT HUP; kill -TERM -- -$$ 2>/dev/null; kill -TERM $CHILD 2>/dev/null; exit 143; }\n`
    + `trap 'on_sig TERM' TERM; trap 'on_sig INT' INT; trap 'on_sig HUP' HUP\n`
    + `(\n${script}\n) > ${JSON.stringify(log)} 2>&1 &\nCHILD=$!\nwait $CHILD; CODE=$?\nwhile kill -0 $CHILD 2>/dev/null; do wait $CHILD; CODE=$?; done\necho $CODE > ${JSON.stringify(exit)}\n`);
  const child = spawn('setsid', ['bash', '-c', `nohup bash ${JSON.stringify(sh)} >/dev/null 2>&1 &`], { detached: true, stdio: 'ignore', cwd: APP() });
  child.unref();
  pruneJobs(id);
  return readJob(id)!;
}

/** Checks the uploaded zip: only files inside "adflow/", no database, no .env, no node_modules. */
export function checkZip(zip: string) {
  let names: string[];
  try { names = execFileSync('unzip', ['-Z1', zip], { encoding: 'utf8', maxBuffer: 20 * 1024 * 1024 }).split('\n').filter(Boolean); }
  catch { throw new HttpError(400, 'This is not a valid zip file'); }
  const pre = NAME() + '/';
  if (!names.length) throw new HttpError(400, 'The zip is empty');
  const bad = names.find(n => !n.startsWith(pre) || n.split('/').includes('..') || n.startsWith('/') || n.includes('\\'));
  if (bad) throw new HttpError(400, `Wrong zip: every file must be inside "${pre}" (found "${bad.slice(0, 80)}")`);
  const risky = names.find(n => new RegExp(`^${pre}(data/|\\.env$|node_modules/|\\.next/|mobile/release\\.keystore)`).test(n));
  if (risky) throw new HttpError(400, `The zip must not contain ${risky.replace(pre, '')} — it would overwrite your live data`);
  if (!names.includes(pre + 'scripts/update.sh') || !names.includes(pre + 'package.json')) throw new HttpError(400, 'This does not look like a full system zip (no scripts/update.sh / package.json)');
  return names.length;
}

export function startUpdate(zipPath: string, originalName: string) {
  const files = checkZip(zipPath);
  const q = JSON.stringify;
  return launch('update', `set -o pipefail
trap 'rm -f ${q(zipPath)}' EXIT
echo "==> $(date '+%d %b %H:%M:%S') Update from ${originalName.replace(/[^\w.\- ]/g, '')} (${files} files)"
cd ${q(PARENT())} || exit 1
echo "==> Unzipping"
unzip -o -q ${q(zipPath)} || exit 1
cd ${q(APP())} || exit 1
echo "==> Installing + building (takes 1-3 minutes)"
if ! bash scripts/update.sh; then
  if grep -q ENOTEMPTY "$JOBLOG" && [ -d node_modules ]; then
    echo "==> npm ENOTEMPTY — moving old node_modules away and trying again"
    mv node_modules ${q(PARENT())}/node_modules_old_$(date +%s)
    bash scripts/update.sh || exit 1
    rm -rf ${q(PARENT())}/node_modules_old_*
  else exit 1; fi
fi
echo "==> ✅ Done $(date '+%H:%M:%S')"`, originalName);
}

export function startApkBuild() {
  return launch('apk', `set -o pipefail
echo "==> $(date '+%d %b %H:%M:%S') Building the Android apps (3-6 minutes)"
cd ${JSON.stringify(APP())} || exit 1
if [ "$(id -u)" = 0 ]; then bash scripts/build-apk.sh; else sudo -n bash scripts/build-apk.sh; fi || exit 1
echo "==> ✅ Done $(date '+%H:%M:%S') — open apps will show the Update popup"`);
}
