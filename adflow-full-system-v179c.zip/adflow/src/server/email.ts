import { getSettings, usesUploadedLogo, type Settings } from './settings';

const API = () => process.env.RESEND_API_BASE || 'https://api.resend.com';
export const publicUrl = () => (process.env.PUBLIC_URL || '').replace(/\/$/, '');
const esc = (s: unknown) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]!));

export function emailFrom(s: Settings = getSettings()) {
  let addr = s.email_from.trim();
  if (!addr) { try { addr = 'noreply@' + new URL(publicUrl()).hostname.replace(/^www\./, ''); } catch { addr = 'noreply@example.com'; } }
  const name = (s.email_from_name || s.brand_name || '').replace(/[<>"]/g, '').trim();
  return name ? `${name} <${addr}>` : addr;
}

/** Simple branded email: title, lines of text, optional big code / button / key-value rows. */
export function emailHtml(s: Settings, o: { title: string; lines?: string[]; code?: string; rows?: [string, string][]; button?: { text: string; url: string } }) {
  const logoSrc = usesUploadedLogo(s) ? `${publicUrl()}/api/logo?v=${s.logo_ver}` : `${publicUrl()}/brand/logo.png?size=80&v=${encodeURIComponent(s.brand_name + s.theme)}`;
  const logo = `<img src="${logoSrc}" width="40" height="40" alt="" style="border-radius:10px;vertical-align:middle;margin-right:10px">`;
  return `<!doctype html><html><body style="margin:0;background:#f4f5fb;font-family:Arial,Helvetica,sans-serif;color:#14142b">
<table width="100%" cellpadding="0" cellspacing="0" style="padding:28px 12px"><tr><td align="center">
<table width="100%" cellpadding="0" cellspacing="0" style="max-width:520px;background:#fff;border-radius:16px;overflow:hidden">
<tr><td style="padding:22px 26px;background:linear-gradient(135deg,#7B4DFF,#1FA2F0);color:#fff;font-size:20px;font-weight:bold">${logo}${esc(s.brand_name)}</td></tr>
<tr><td style="padding:26px">
<h1 style="margin:0 0 14px;font-size:21px">${esc(o.title)}</h1>
${(o.lines || []).map(l => `<p style="margin:0 0 12px;font-size:15px;line-height:1.55;color:#3a3a55">${esc(l)}</p>`).join('')}
${o.code ? `<div style="margin:18px 0;padding:16px;border-radius:12px;background:#f1edff;text-align:center;font-size:32px;letter-spacing:8px;font-weight:bold;color:#4b2fd6">${esc(o.code)}</div>` : ''}
${o.rows ? `<table width="100%" cellpadding="0" cellspacing="0" style="margin:14px 0;border:1px solid #ececf5;border-radius:12px">${o.rows.map(([k, v]) => `<tr><td style="padding:10px 14px;font-size:14px;color:#6b6b85;border-bottom:1px solid #f1f1f7">${esc(k)}</td><td style="padding:10px 14px;font-size:14px;font-weight:bold;text-align:right;border-bottom:1px solid #f1f1f7">${esc(v)}</td></tr>`).join('')}</table>` : ''}
${o.button ? `<p style="margin:22px 0 4px"><a href="${esc(o.button.url)}" style="display:inline-block;background:#5b3dff;color:#fff;text-decoration:none;padding:13px 22px;border-radius:10px;font-weight:bold;font-size:15px">${esc(o.button.text)}</a></p>` : ''}
</td></tr>
<tr><td style="padding:16px 26px;background:#fafafe;font-size:12px;color:#8a8aa3">${esc(s.brand_name)} · ${esc(publicUrl().replace(/^https?:\/\//, ''))}</td></tr>
</table></td></tr></table></body></html>`;
}

export async function sendEmail(to: string, subject: string, html: string) {
  const s = getSettings();
  if (!s.resend_api_key) return { ok: false, error: 'Email is not set up (Admin → Settings → Website orders → Resend API key)' };
  try {
    const r = await fetch(`${API()}/emails`, {
      method: 'POST', headers: { authorization: `Bearer ${s.resend_api_key}`, 'content-type': 'application/json' },
      body: JSON.stringify({ from: emailFrom(s), to: [to], subject, html }), signal: AbortSignal.timeout(15000),
    });
    const j = await r.json().catch(() => ({})) as { id?: string; message?: string };
    if (!r.ok) { console.warn('[email]', r.status, j.message); return { ok: false, error: j.message || `Resend error ${r.status}` }; }
    return { ok: true, id: j.id };
  } catch (e) { console.warn('[email]', e); return { ok: false, error: String(e) }; }
}
