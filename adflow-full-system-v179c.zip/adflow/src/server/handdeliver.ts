/* v175 (owner): "Delivered by hand · screenshots" — an ad account (or a top-up) given by hand, outside our BMs (or without the API).
 * The admin / manager uploads the Meta screenshots; the system then does what the automatic delivery does:
 *  - account: the account is saved to the client (a "hand" account, never synced), the sale is recorded (optional, once),
 *    the client gets the screenshots + "Your ad account is ready", the channel post + Saved Messages + story are made
 *    (from the screenshots, every long ID blurred), and a client number is used.
 *  - top-up: the top-up is recorded (fee on top), the client gets the screenshot + "Top-up done", the image goes to the daily post.
 * The Meta screenshots go to the client as they are (their own account); only the public post is blurred. */
import { one, run } from './db';
import { getSettings } from './settings';
import { HttpError, now, money, num } from './util';
import * as M from './meta';
import { addMsg, uploadToLead, recordSale, addTopup, displayName, agentById, type Lead } from './crm';

type Agent = NonNullable<ReturnType<typeof agentById>>;
const sharpLib = async () => (await import('sharp')).default;

/** data:image/...;base64 → a normalised PNG (max 2400 px) */
async function toPng(v: unknown): Promise<Buffer> {
  const m = /^data:image\/(png|jpe?g|webp);base64,([A-Za-z0-9+/=\s]+)$/.exec(String(v || ''));
  if (!m) throw new HttpError(400, 'Upload the screenshots as images (PNG / JPG)');
  const raw = Buffer.from(m[2], 'base64');
  if (raw.length > 12 * 1024 * 1024) throw new HttpError(400, 'A screenshot is too big (max 12 MB)');
  const sharp = await sharpLib();
  try { return await sharp(raw).rotate().resize({ width: 2400, height: 2400, fit: 'inside', withoutEnlargement: true }).png().toBuffer(); }
  catch { throw new HttpError(400, 'This file is not an image'); }
}
/** the whole screenshot centred on a 16:9 dark canvas (the post layouts expect 16:9; a phone screenshot is never cropped) */
async function to169(png: Buffer): Promise<Buffer> {
  const sharp = await sharpLib();
  const W = 1920, H = 1080;
  const fit = await sharp(png).resize({ width: W - 80, height: H - 80, fit: 'inside' }).png().toBuffer();
  const mt = await sharp(fit).metadata();
  return sharp({ create: { width: W, height: H, channels: 4, background: { r: 22, g: 11, b: 46, alpha: 1 } } })
    .composite([{ input: fit, left: Math.round((W - (mt.width || 0)) / 2), top: Math.round((H - (mt.height || 0)) / 2) }]).png().toBuffer();
}

/** What the screenshots say: the ad account ID, BM IDs and dollar amounts (suggestions only; the admin checks them). */
export async function handScan(images: unknown[]) {
  const { ocrText } = await import('./shotpost');
  let text = '';
  for (const im of images.slice(0, 4)) { try { text += '\n' + await ocrText(await toPng(im)); } catch { /* a bad one: skip */ } }
  const ids = [...new Set((text.match(/\d[\d\s]{13,20}\d/g) || []).map(x => x.replace(/\s/g, '')).filter(x => x.length >= 14 && x.length <= 18))];
  const actM = /act[_\s]?(\d{14,18})/i.exec(text.replace(/(\d)\s+(?=\d)/g, '$1'));
  const act = actM?.[1] || ids.find(x => /ad\s*account/i.test(text)) || ids[0] || '';
  const bm = ids.find(x => x !== act) || '';
  const amounts = [...new Set((text.match(/\$\s?\d{1,6}(?:,\d{3})*(?:\.\d{1,2})?/g) || []).map(x => money(x.replace(/[$,\s]/g, ''))).filter(x => x > 0))].slice(0, 6);
  return { act, bm, amounts, ids: ids.slice(0, 6) };
}

/** POST meta_hand {lead_id, kind: account|topup, shots: [dataURL…], act_id, client_bm?, tier?, balance?, sale?, price?, amount?, note?} */
export async function handDeliver(actorRole: 'admin' | 'manager', owner: Agent, lead: Lead, b: Record<string, unknown>) {
  const kind = b.kind === 'topup' ? 'topup' : 'account';
  const act = M.cleanAct(b.act_id);
  if (act.length < 10 || act.length > 20) throw new HttpError(400, 'Type the ad account ID (numbers, from the screenshot)');
  const raw = Array.isArray(b.shots) ? b.shots : [];
  if (!raw.length) throw new HttpError(400, 'Upload the screenshot(s)');
  const shots: Buffer[] = [];
  for (const x of raw.slice(0, 4)) shots.push(await toPng(x));
  const s = getSettings();
  const by = actorRole === 'admin' ? 'admin' : `manager:${owner.id}`;
  const a0 = M.acctOf(act);
  if (a0 && a0.lead_id && a0.lead_id !== lead.id) throw new HttpError(400, 'That ad account is with another client in the system');

  // the screenshots to the client, as they are (their own account)
  const toClient = async () => {
    if (!lead.tg_chat_id || (lead as Lead & { manual_client?: number }).manual_client) return false;
    let n = 0;
    for (const [i, im] of shots.entries()) {
      try { const fd = new FormData(); fd.append('file', new File([new Uint8Array(im)], `${kind}-${i + 1}.png`, { type: 'image/png' })); fd.append('kind', 'photo'); await uploadToLead(lead, fd, 'agent', lead.agent_id); n++; }
      catch (e) { addMsg(lead, { dir: 'sys', sender: 'system', text: `⚠️ Screenshot not sent to the client (${(e as Error).message}). Send it yourself.` }); break; }
    }
    return n > 0;
  };
  const { tellClient } = await import('./clientmsg');

  if (kind === 'topup') {
    const amount = money(b.amount);
    if (!(amount > 0)) throw new HttpError(400, 'Enter the top-up amount (USD added to the account)');
    const t = addTopup(lead, owner, amount, String(b.note || `By hand · act_${act}`), undefined, true) as { fee?: number };
    const fee = money(num(t?.fee));
    const logId = Number(run('INSERT INTO meta_log(act_id, lead_id, agent_id, kind, paid, fee, amount, note, by, created_at) VALUES(?,?,?,?,?,?,?,?,?,?)',
      act, lead.id, lead.agent_id, 'topup', money(amount + fee), fee, amount, 'by hand (screenshot)', by, now()).lastInsertRowid);
    if (a0 && a0.bm_id === 'hand') run('UPDATE meta_accounts SET cap=cap+?, low_sent=0 WHERE act_id=?', Math.round(amount * 100), act);
    const sent = await toClient();
    await tellClient(lead, 'meta_msg_topup_hand', { acts: [act], amount });
    try { const { blurIds } = await import('./shotpost'); const bl = await blurIds(shots[0]); (await import('./digest')).saveTopupImg(act, await to169(bl.img), { since: now() - 60000 }); } catch { /* the daily post goes without it */ }
    addMsg(lead, { dir: 'sys', sender: 'system', text: `💰 Top-up by hand: ${'$' + amount.toFixed(2)} on act_${act} · fee ${'$' + fee.toFixed(2)}${sent ? ' · screenshot sent' : ''}` });
    return { ok: true, kind, log: logId, fee };
  }

  // ---- a new account given by hand
  const clientBm = String(b.client_bm || '').replace(/\D/g, '');
  if (clientBm && (clientBm.length < 8 || clientBm.length > 20)) throw new HttpError(400, 'The client BM ID looks wrong');
  const balance = Math.max(0, money(b.balance));
  const premium = b.tier === 'premium';
  const dsl = premium ? Math.max(num(s.meta_cat_usd, 100), num(b.dsl)) : num(b.dsl) > 0 ? num(b.dsl) : 25;
  const name = String(b.name || '').trim().slice(0, 80) || `Hand · act_${act}`;
  if (a0 && a0.lead_id === lead.id && (a0 as { proof_at?: number | null }).proof_at) throw new HttpError(409, 'This account was already delivered to this client');
  const t = now();
  if (!a0) {
    const no = (one<{ m: number | null }>('SELECT MAX(no) m FROM meta_accounts')!.m || 0) + 1;
    run(`INSERT INTO meta_accounts(act_id, bm_id, no, name, status, currency, spent, cap, state, lead_id, share_mode, client_bm, assigned_at, synced_at, seen_at, partner_name, dsl, proof_at)
      VALUES(?, 'hand', ?, ?, 1, 'USD', 0, ?, 'assigned', ?, 'bm', ?, ?, ?, ?, ?, ?, ?)`, act, no, name, Math.round(balance * 100), lead.id, clientBm || null, t, t, t, displayName(lead), dsl, t);
  } else {
    run("UPDATE meta_accounts SET state='assigned', lead_id=?, share_mode='bm', client_bm=COALESCE(?, client_bm), assigned_at=?, cap=MAX(cap, spent)+?, dsl=COALESCE(dsl, ?), proof_at=?, low_sent=0, removed_at=NULL WHERE act_id=?",
      lead.id, clientBm || null, t, Math.round(balance * 100), dsl, t, act);
  }
  run('INSERT INTO meta_log(act_id, lead_id, agent_id, kind, amount, note, by, created_at) VALUES(?,?,?,?,?,?,?,?)', act, lead.id, lead.agent_id, 'share', 0, `By hand (screenshots)${clientBm ? ' · BM ' + clientBm : ''}`, by, t);
  try { (await import('./shop')).saveLeadAccounts(lead.id, [act], { bm: clientBm || null, source: 'hand' }); } catch { /* */ }
  // the sale: once, only when asked (Mark sold may have done it already)
  let sale: unknown = null;
  if (b.sale) sale = await recordSale(lead, owner, { service: 'account', qty: 1, amount: b.price, tier: premium ? 'premium' : undefined, closed_by: actorRole === 'manager' ? owner.id : null }, { admin: actorRole === 'admin' });
  // v175 (owner): the balance given with the account IS a top-up → recorded with the fee (like the automatic share) and in tonight's top-up post
  let topFee = 0;
  if (balance > 0) {
    const tr = addTopup(lead, owner, balance, `With the account act_${act} (by hand)`, undefined, true) as { fee?: number };
    topFee = money(num(tr?.fee));
    run('INSERT INTO meta_log(act_id, lead_id, agent_id, kind, paid, fee, amount, note, by, created_at) VALUES(?,?,?,?,?,?,?,?,?,?)',
      act, lead.id, lead.agent_id, 'topup', money(balance + topFee), topFee, balance, 'with the share (by hand)', by, now());
    try { const { blurIds } = await import('./shotpost'); const im = shots[2] || shots[shots.length - 1]; (await import('./digest')).saveTopupImg(act, await to169((await blurIds(im)).img), { since: now() - 60000 }); } catch { /* the daily post goes without the image */ }
  }
  const sent = await toClient();
  await tellClient(lead, 'meta_msg_share', { acts: [act], bm: clientBm || null, balance, topup: balance > 0 ? balance : null });
  addMsg(lead, { dir: 'sys', sender: 'system', text: `🎉 Ad account given by hand: ${name} (act_${act})${clientBm ? ' · BM ' + clientBm : ''} · balance ${'$' + balance.toFixed(2)}${sent ? ' · screenshots sent' : ''}` });
  // the public post (blurred screenshots): channel + Saved Messages + story, one client number
  let post: unknown = null;
  if (b.post !== false) {
    try {
      const { blurIds } = await import('./shotpost');
      const bl: Buffer[] = [];
      for (const im of shots.slice(0, 3)) bl.push(await to169((await blurIds(im)).img));
      const P = await import('./proof');
      const site = ((await import('./email')).publicUrl() || 'adsbhai.com').replace(/^https?:\/\//, '').replace(/\/$/, '');
      const d = { name, act, owner: '', partner: displayName(lead), balance: 0, threshold: null, dsl, card: null, currency: 'USD', brand: s.brand_name || 'AdsBhai', site,
        at: new Date(t + num(s.tz_offset_min, 330) * 60000).toLocaleString('en-GB', { day: 'numeric', month: 'short', year: 'numeric', hour: 'numeric', minute: '2-digit', hour12: true, timeZone: 'UTC' }),
        billDate: '', topup: balance > 0 ? balance : null } as Parameters<typeof P.postDelivery>[0]['d'];
      post = await P.postDelivery({ act, d, partner: bl[0], billing: bl[1] || bl[0], topImg: balance > 0 && bl[2] ? bl[2] : null, manual: !lead.tg_chat_id });
    } catch (e) { addMsg(lead, { dir: 'sys', sender: 'system', text: `⚠️ Channel post / story not made: ${(e as Error).message}` }); }
  }
  return { ok: true, kind, act, sale, post, topup: balance > 0 ? { amount: balance, fee: topFee } : null };
}

/** For the list: hand accounts are never synced (no BM). */
export const isHandAcct = (bmId: string | null | undefined) => bmId === 'hand';
