import { HttpError } from './util';

export const json = (d: unknown, status = 200, headers: Record<string, string> = {}) =>
  new Response(JSON.stringify(d), { status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...headers } });

export async function body(req: Request): Promise<Record<string, any>> {
  if (req.method !== 'POST') return {};
  try { return await req.json(); } catch { return {}; }
}

/** v127: unexpected errors show their text only in the admin / agent apps (logged in); public pages get a plain message. */
export function fail(e: unknown, expose = false) {
  if (e instanceof HttpError) return json({ ...(e.data || {}), error: e.message }, e.status);
  console.error('[api]', e);
  return json({ error: expose && e instanceof Error ? e.message : 'Something went wrong. Please try again.' }, 500);
}

/** v127: too many wrong passwords from one IP → wait (admin / agent login). */
const failsByIp = new Map<string, number[]>();
/** The IP nginx saw (X-Real-IP is set by our nginx and can't be faked by the visitor; cf-connecting-ip can, we're not behind Cloudflare). */
export const realIp = (req: Request) => req.headers.get('x-real-ip') || (req.headers.get('x-forwarded-for') || '').split(',').pop()!.trim() || 'local';
export function loginBlocked(ip: string) {
  const t = Date.now(), h = (failsByIp.get(ip) || []).filter(x => x > t - 15 * 60000);
  failsByIp.set(ip, h);
  return h.length >= 10;
}
export function loginFailed(ip: string) {
  const t = Date.now(), h = (failsByIp.get(ip) || []).filter(x => x > t - 15 * 60000);
  h.push(t); failsByIp.set(ip, h);
  if (failsByIp.size > 5000) for (const [k, v] of failsByIp) if (!v.some(x => x > t - 15 * 60000)) failsByIp.delete(k);
}

export function baseUrl(req: Request) {
  if (process.env.PUBLIC_URL) return process.env.PUBLIC_URL.replace(/\/$/, '');
  const proto = req.headers.get('x-forwarded-proto')?.split(',')[0] || 'https';
  const host = req.headers.get('x-forwarded-host') || req.headers.get('host');
  return `${proto}://${host}`;
}

export const clientIp = (req: Request) =>
  req.headers.get('cf-connecting-ip') || req.headers.get('x-real-ip') || (req.headers.get('x-forwarded-for') || '').split(',')[0].trim() || '';

export function getCookie(req: Request, name: string) {
  const m = (req.headers.get('cookie') || '').match(new RegExp('(?:^|;\\s*)' + name + '=([^;]+)'));
  return m ? decodeURIComponent(m[1]) : '';
}
