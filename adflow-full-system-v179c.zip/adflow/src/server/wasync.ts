// v137: WATI extras.
//  · Pro plan (Settings → WATI → "We're on the WATI Pro plan"): tap-to-answer list menu, buttons under every WhatsApp welcome,
//    chat status sync (sold / dead / deleted → SOLVED, customer writes again → OPEN) and contact attributes.
//    All of it is OFF while the Pro switch is off — no extra API calls.
//  · Any plan: replies typed in the WhatsApp Business app (coexistence: WATI sends no webhook for those) are pulled from the
//    Team Inbox (getMessages) into our chat as "owner" messages.
// Never throws to the caller; every API result goes to the WATI log (Admin → Settings → WATI → Last WATI API results).
import { one, all, run } from './db';
import { getSettings, bizOf, tierFor, fmt, forLead, toInr, type Settings } from './settings';
import { now } from './util';
import { parseLabels, isTalkToAgent, parseReplies, replyFor, btnKey, fillBtnText, cleanButtons, TALK_LABEL, type BtnReply } from './btnreplies';
import { fetchMedia, localDur, logWati, waDigits, waGetMessages, waPhoneSyncOn, waProAttrs, waProButtons, waProStatus, waSetAttrs, waSetChatStatus, type WaListRow, sameMediaKind, waClaimIds, waMediaInFlight } from './wati'; // v168: + sameMediaKind, waClaimIds, waMediaInFlight

type L = {
  id: number; status: string; tg_chat_id: string | null; ch?: string | null; service?: string | null; line?: string | null; tier?: string | null;
  agent_id: number | null; first_reply_at: number | null; sold_at: number | null; dead_at?: number | null; created_at: number; started_at: number | null;
  last_at: number | null; last_out_at: number | null; wa_tstatus?: string | null; wa_tstatus_at?: number | null; wa_attrs?: string | null; wa_attrs_err_at?: number | null;
};
const lineOf = (l: { service?: string | null; line?: string | null; tier?: string | null }) => (bizOf(l) === 'funnel' ? 'funnel' : l.tier === 'premium' ? 'premium' : 'agency') as 'agency' | 'premium' | 'funnel';
const LINE_LABEL = { agency: 'Agency', premium: 'Premium', funnel: 'Funnel' } as const;

/* ---------- buttons + list menu (Pro) — the defaults live in settings.ts (wati_btn_*), editable in Admin → Settings → WATI ---------- */
/** Buttons under the WhatsApp welcome for this chat's line (max 3, 20 characters, no emoji). A Premium chat never gets Agency buttons. */
export function waButtonsFor(s: Settings, l: { service?: string | null; line?: string | null; tier?: string | null }) {
  const ln = lineOf(l);
  return parseLabels((s as Record<string, string>)['wati_btn_' + ln], ln);
}
export { isTalkToAgent };
export { lineOf as waLineOf };

/** The 1/2/3/4 menu as a WhatsApp list. Row titles max 24 characters ("3 · Landing + funnel": the 25-character
 *  "Landing page + funnel" would be refused by WhatsApp). The leading number is what menuNum() reads. */
export function waMenuList(s: Settings, name: string) {
  const p = tierFor(s, 'premium');
  const first = String(name || '').trim().split(/\s+/)[0] || 'there';
  const rows: WaListRow[] = [
    { title: '1 · Agency ad account', description: fmt(`$${s.price_account} · Live in {delivery} · No spending limit`, s) },
    { title: '2 · Premium ad account', description: `$${p.price_account} · Aged profile + verified BM · Ready in ${p.delivery_time || s.delivery_time}` },
    { title: '3 · Landing + funnel', description: `$${s.price_funnel}/month · Done for you · Leads to your WhatsApp` },
    { title: '4 · Talk to an agent', description: 'Something else? Talk to our team' },
  ].map(r => ({ ...r, description: r.description!.replace(/\s+/g, ' ').slice(0, 72) }));
  return {
    header: String(s.brand_name || 'Welcome').slice(0, 60),
    body: `Hi ${first}! Welcome to ${s.brand_name || 'us'}.\nMeta agency ad accounts and funnels, trusted by 1,000+ advertisers.\n\nTap the button below and pick what you need. A real person replies in a few minutes.`,
    footer: 'Or just reply with 1, 2, 3 or 4',
    buttonText: 'Choose an option',
    sectionTitle: 'Our services',
    rows,
  };
}
export const listAsText = (m: ReturnType<typeof waMenuList>) => `${m.body}\n\n${m.rows.map(r => `${r.title} — ${r.description}`).join('\n')}`;
export const buttonsAsText = (body: string, b: string[]) => `${body}\n\n${b.map(x => `[ ${x} ]`).join('  ')}`;
export { waProButtons };

/* ---------- v138: automatic replies to the welcome buttons (Pro) ---------- */
type PL = { service?: string | null; line?: string | null; tier?: string | null; offer_until?: number | null; name?: string | null; tg_name?: string | null };
/** The tapped title → one of THIS chat's line labels (trimmed, case-insensitive). A Premium chat only matches Premium labels. */
export function waTapOf(s: Settings, l: PL, text: string): { label: string; reply: BtnReply | null; talk: boolean } | null {
  const t = String(text || '').trim();
  if (!t || t.length > 40) return null;
  const labels = waButtonsFor(s, l), ln = lineOf(l), map = parseReplies(s.wati_btn_replies);
  let label = labels.find(x => btnKey(x) === btnKey(t));
  // v140: the follow-up buttons under this line's replies (e.g. "💬 Talk to agent" inside See pricing) — two steps deep, same line only
  if (!label) {
    const seen = new Set(labels.map(btnKey));
    let layer = labels;
    for (let d = 0; d < 2 && !label; d++) {
      const next = layer.flatMap(x => replyFor(map, ln, labels, x)?.buttons || []).filter(x => !seen.has(btnKey(x)));
      next.forEach(x => seen.add(btnKey(x)));
      label = next.find(x => btnKey(x) === btnKey(t));
      layer = next;
    }
  }
  // "Talk to agent" typed or tapped always works (with or without the icon)
  if (!label && isTalkToAgent(t) && btnKey(t) === btnKey(TALK_LABEL)) label = TALK_LABEL;
  if (!label) return null;
  const reply = replyFor(map, ln, labels, label);
  return { label, reply: reply && reply.text.trim() ? reply : null, talk: isTalkToAgent(label) };
}
/** Placeholder values for one chat — the same settings and INR helper as the welcome / price strip
 *  (forLead: Premium prices for Premium chats, funnel texts, this week's offer; toInr: the admin's INR rate). */
export function btnVars(s0: Settings, l: PL): Record<string, string> {
  const s = forLead(s0, l), ln = lineOf(l);
  const price = ln === 'funnel' ? s.price_funnel : s.price_account;
  const min = s.topup_min || '30', prem = tierFor(s0, 'premium').price_account;
  const first = String(l.name || l.tg_name || '').trim().split(/\s+/)[0] || 'sir';
  return {
    name: first, price: String(price), price_inr: toInr(price, s), fee: `${s.topup_comm_pct}%`, min_topup: String(min), min_topup_inr: toInr(min, s),
    premium_price: String(prem), premium_price_inr: toInr(prem, s0), funnel_price: String(s.price_funnel), funnel_price_inr: toInr(s.price_funnel, s),
    delivery: s.delivery_time, payment: s.payment_text, brand: s.brand_name || 'AdsBhai',
  };
}
export function btnReplyText(s0: Settings, l: PL, tpl: string) {
  const s = forLead(s0, l);
  return fmt(fillBtnText(tpl, btnVars(s0, l)), s).trim();
}
/** Hard rule: a Premium chat is never shown the Agency account price. true = the text shows it (the reply is not sent). */
export function showsAgencyPrice(s0: Settings, l: PL, text: string) {
  if (lineOf(l) !== 'premium') return false;
  const ag = String(s0.price_account || '').trim(), pr = String(tierFor(s0, 'premium').price_account || '').trim();
  if (!ag || ag === pr) return false;
  const esc = ag.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return new RegExp(`(\\$|USD\\s?)\\s?${esc}(?!\\d|[.,]\\d)|${esc}\\s?(\\$|USD|dollars?)\\b`, 'i').test(text);
}
export { cleanButtons as waCleanButtons };

/* ---------- chat status + contact attributes (Pro) ---------- */
function attrsOf(l: L) {
  const ag = l.agent_id ? one<{ name: string }>('SELECT name FROM agents WHERE id=?', l.agent_id)?.name : null;
  const accts = one<{ n: number | null }>("SELECT SUM(qty) n FROM sales WHERE lead_id=? AND service='account'", l.id)?.n || 0;
  const st = l.status === 'sold' ? 'Sold' : l.status === 'dead' ? 'Dead' : l.first_reply_at ? 'Active' : 'New';
  return { adsbhai_line: LINE_LABEL[lineOf(l)], adsbhai_status: st, adsbhai_agent: ag || '', adsbhai_accounts: String(accts), adsbhai_lead_id: String(l.id) };
}
const busy = new Set<number>();
/** Bring WATI up to date for one chat: attributes (only when a value changed) and chat status (only on a change of state).
 *  opts.open = the customer just wrote (SOLVED → OPEN) · opts.solved = force SOLVED (a repeat sale). Returns the API calls made. */
export async function waSyncLead(leadId: number, opts: { open?: boolean; solved?: boolean } = {}, s: Settings = getSettings()): Promise<number> {
  if (!waProStatus(s) && !waProAttrs(s)) return 0;
  if (busy.has(leadId)) return 0;
  busy.add(leadId);
  let calls = 0;
  try {
    const l = one<L>('SELECT * FROM leads WHERE id=?', leadId);
    if (!l || l.ch !== 'wa' || !l.tg_chat_id?.startsWith('wa:') || l.status === 'merged') return 0;
    const wa = waDigits(l.tg_chat_id), t = now();
    if (waProAttrs(s) && !(l.wa_attrs_err_at && l.wa_attrs_err_at > t - 3600000)) {
      const a = attrsOf(l), j = JSON.stringify(a);
      if (j !== l.wa_attrs && run('UPDATE leads SET wa_attrs=? WHERE id=? AND COALESCE(wa_attrs,\'\')=?', j, l.id, l.wa_attrs || '').changes) {
        const prev: Record<string, string> = (() => { try { return JSON.parse(l.wa_attrs || '{}'); } catch { return {}; } })();
        const changed = Object.fromEntries(Object.entries(a).filter(([k, v]) => prev[k] !== v)); // only what changed
        calls++;
        if (!(await waSetAttrs(s, wa, changed))) run('UPDATE leads SET wa_attrs=?, wa_attrs_err_at=? WHERE id=?', l.wa_attrs ?? null, t, l.id); // tried again in 1 hour
      }
    }
    if (waProStatus(s)) {
      const closedAt = Math.max(l.status === 'sold' ? l.sold_at || 0 : 0, l.status === 'dead' ? l.dead_at || 0 : 0);
      let want: 'OPEN' | 'SOLVED' | null = null;
      if (opts.open && l.wa_tstatus === 'SOLVED') want = 'OPEN';
      else if ((l.status === 'sold' || l.status === 'dead') && l.wa_tstatus !== 'SOLVED' && (opts.solved || closedAt > (l.wa_tstatus_at || 0))) want = 'SOLVED';
      if (want && run('UPDATE leads SET wa_tstatus=?, wa_tstatus_at=? WHERE id=? AND COALESCE(wa_tstatus,\'\')=?', want, t, l.id, l.wa_tstatus || '').changes) {
        calls++;
        if (!(await waSetChatStatus(s, wa, want))) run('UPDATE leads SET wa_tstatus=? WHERE id=?', l.wa_tstatus ?? null, l.id); // not retried until the next change
      }
    }
  } catch (e) { logWati('error', 'sync: ' + (e as Error).message); } finally { busy.delete(leadId); }
  return calls;
}
/** Fire and forget (never slows the request, never throws). Changes within 100 ms (type + agent from one menu answer) → one call. */
const soon = new Map<number, { t: ReturnType<typeof setTimeout>; open: boolean; solved: boolean }>();
export function waSyncSoon(leadId: number | null | undefined, opts: { open?: boolean; solved?: boolean } = {}) {
  if (!leadId) return;
  try {
    const s = getSettings();
    if (!waProStatus(s) && !waProAttrs(s)) return;
    const prev = soon.get(leadId);
    if (prev) clearTimeout(prev.t);
    const o = { open: !!(opts.open || prev?.open), solved: !!(opts.solved || prev?.solved) };
    soon.set(leadId, { ...o, t: setTimeout(() => { soon.delete(leadId); void waSyncLead(leadId, o).catch(() => 0); }, 100) });
  } catch { /* */ }
}
/** A WhatsApp chat deleted in our app → SOLVED in WATI (call BEFORE the row is deleted; fire and forget). */
export function waDeletedSoon(chatId: string | null | undefined) {
  try {
    const s = getSettings();
    if (!chatId?.startsWith('wa:') || !waProStatus(s)) return;
    void waSetChatStatus(s, waDigits(chatId), 'SOLVED').catch(() => false);
  } catch { /* */ }
}
/** Worker (every minute): catches every change made anywhere (follow-ups → Dead, reassigns, sales…). Max ~20 API calls per run. */
export async function waSyncSweep(s: Settings = getSettings()) {
  if (!waProStatus(s) && !waProAttrs(s)) return 0;
  const t = now();
  const rows = all<{ id: number }>(`SELECT id FROM leads WHERE ch='wa' AND status!='merged' AND tg_chat_id LIKE 'wa:%' AND (COALESCE(last_at, created_at) > ? OR COALESCE(sold_at,0) > ? OR COALESCE(dead_at,0) > ?)
    ORDER BY COALESCE(last_at, created_at) DESC LIMIT 200`, t - 3 * 86400000, t - 86400000, t - 86400000);
  let calls = 0;
  for (const r of rows) { if (calls >= 20) break; calls += await waSyncLead(r.id, {}, s); }
  return calls;
}

/* ---------- phone-reply sync (any plan) ---------- */
const lastSync = new Map<string, number>();
const inflight = new Set<string>();
const norm = (x: string | null | undefined) => String(x || '').replace(/\s+/g, ' ').trim().toLowerCase();
// v168: kindOf → sameMediaKind (wati.ts): an image sent as a document and its photo echo are one kind
/** Pull the chat's last messages from WATI and add the ones typed in the WhatsApp Business app that we don't have yet.
 *  `gapMs` = at most once per this many ms per chat (30 s after a customer message, 60 s when a chat is opened).
 *  Our own API / welcome / AI messages are never added twice (WhatsApp id, or same text close in time).
 *  Imported messages keep their real time, are not unread for anyone and never push / start the welcome / the AI. */
export async function waPhoneSync(leadId: number, gapMs = 60000, s: Settings = getSettings()): Promise<number> {
  try {
    if (!waPhoneSyncOn(s)) return 0;
    const lead = one<L>('SELECT * FROM leads WHERE id=?', leadId);
    if (!lead?.tg_chat_id?.startsWith('wa:')) return 0;
    const wa = waDigits(lead.tg_chat_id), t0 = now();
    if (inflight.has(wa) || (lastSync.get(wa) || 0) > t0 - gapMs) return 0;
    lastSync.set(wa, t0); inflight.add(wa);
    try {
      const items = await waGetMessages(s, wa, 20);
      if (!items) return 0;
      const mine = items.filter(m => m.owner).sort((a, b) => (a.at || 0) - (b.at || 0));
      let n = 0;
      // v158: each message in the chat can stand for only ONE phone message (two "Nhi" in a row are two messages),
      // and a row that already has another WhatsApp id is a different message
      const used = new Set<number>();
      const allIds = new Set(mine.flatMap(x => x.ids));
      for (const m of mine) {
        const at = m.at ? Math.min(m.at, now()) : null;
        if (at && at < lead.created_at - 60000) continue; // older than this chat (an earlier conversation)
        if (m.ids.length) {
          const q = m.ids.map(() => '?').join(',');
          const had = one<{ id: number }>(`SELECT id FROM messages WHERE lead_id=? AND (wa_id IN (${q}) OR wa_id2 IN (${q}))`, lead.id, ...m.ids, ...m.ids);
          if (had) { used.add(had.id); continue; }
        }
        const near = (ms: number) => at ? [at - ms, at + ms] : [now() - 2 * 86400000, now() + 60000];
        if (m.media) {
          const [f, tt] = near(5 * 60000);
          const same = all<{ id: number; file_type: string | null; file_name: string | null; wa_id: string | null; wa_id2: string | null }>("SELECT id, file_type, file_name, wa_id, wa_id2 FROM messages WHERE lead_id=? AND dir='out' AND file_type IS NOT NULL AND sender!='owner' AND wa_echo IS NULL AND created_at BETWEEN ? AND ? ORDER BY id", lead.id, f, tt);
          // v168: only OUR rows not matched yet (an owner row / an echoed row has its own id → it is another message);
          // an image we sent as a document = WhatsApp's photo of it (same kind)
          const hit = same.find(r => !used.has(r.id) && !(r.wa_id && allIds.has(r.wa_id)) && !(r.wa_id2 && allIds.has(r.wa_id2)) && sameMediaKind(r.file_type, r.file_name, m.media!.kind, m.media!.ref));
          if (hit) { used.add(hit.id); if (m.ids.length) run('UPDATE messages SET wa_echo=1, wa_id2=? WHERE id=? AND wa_id2 IS NULL', m.ids[0], hit.id); continue; } // its webhook copy then matches by id
          // v168: a file of this kind is being sent to this number right now (our row is not saved yet) → next sync decides
          if (waMediaInFlight(wa, m.media.kind, m.media.ref)) continue;
        } else {
          const [f, tt] = near(15 * 60000), x = norm(m.text);
          const same = all<{ id: number; text: string | null; wa_id: string | null; wa_id2: string | null }>("SELECT id, text, wa_id, wa_id2 FROM messages WHERE lead_id=? AND dir='out' AND created_at BETWEEN ? AND ? ORDER BY id", lead.id, f, tt);
          const hit = same.find(r => { if (used.has(r.id) || (r.wa_id && allIds.has(r.wa_id)) || (r.wa_id2 && allIds.has(r.wa_id2))) return false; const y = norm(r.text); return y === x || (x.length >= 8 && (y.includes(x) || (y.length >= 8 && x.includes(y)))); });
          if (hit) { used.add(hit.id); continue; }
        }
        if (!waClaimIds(m.ids)) continue; // v168: the webhook (or another sync) is adding this one — claimed before the download
        const fid = m.media ? await fetchMedia(s, m.media) : null;
        const text = m.text || (m.media && !fid ? `[${m.media.kind === 'voice' || m.media.kind === 'audio' ? 'voice note' : m.media.kind} sent from the phone — open WhatsApp to see it]` : '');
        const ct = at || now();
        const read = /read/.test(m.status) ? ct : null, deliv = read || /deliver/.test(m.status) ? ct : null;
        const kd = fid && m.media ? m.media.kind : null;
        // v168: OR IGNORE — the unique (chat, WhatsApp id) index; a copy saved meanwhile is not saved again
        if (!run('INSERT OR IGNORE INTO messages(lead_id, dir, sender, text, file_id, file_type, created_at, wa_id, wa_id2, read_at, delivered_at, wa_echo, dur) VALUES(?,?,?,?,?,?,?,?,?,?,?,1,?)',
          lead.id, 'out', 'owner', text, fid, kd, ct, m.ids[0] || null, m.ids[1] || null, read, deliv, kd === 'voice' || kd === 'audio' ? localDur(fid) : null).changes) continue;
        // a human reply: the reply clock may use its real time; the chat's preview only moves when it is the newest message
        run(`UPDATE leads SET last_out_at=MAX(COALESCE(last_out_at,0), ?),
            first_reply_at=CASE WHEN ? >= COALESCE(started_at, created_at) THEN MIN(COALESCE(first_reply_at, ?), ?) ELSE first_reply_at END,
            last_text=CASE WHEN ? >= COALESCE(last_at,0) THEN ? ELSE last_text END, fu_due=CASE WHEN ? >= COALESCE(last_at,0) THEN 0 ELSE fu_due END,
            remind_due=CASE WHEN ? >= COALESCE(last_at,0) THEN 0 ELSE remind_due END, last_at=MAX(COALESCE(last_at,0), ?) WHERE id=?`,
          ct, ct, ct, ct, ct, (text || 'File').slice(0, 140), ct, ct, ct, lead.id);
        n++;
      }
      if (n) logWati('sync', `+${wa}: ${n} message(s) typed in the WhatsApp Business app added to chat #${lead.id}`);
      return n;
    } finally { inflight.delete(wa); }
  } catch (e) { logWati('error', 'phone sync: ' + (e as Error).message); return 0; }
}
/** Opening a chat in the agent / admin app → sync in the background (max once a minute; the next poll shows the new messages). */
export function waPhoneSyncSoon(lead: { id: number; tg_chat_id?: string | null } | null | undefined) {
  try { if (lead?.tg_chat_id?.startsWith('wa:') && waPhoneSyncOn()) void waPhoneSync(lead.id, 60000).catch(() => 0); } catch { /* */ }
}
