import { one, all, run, emptyInSql, commSql } from './db';
export { commSql };
import { publicUrl } from './email';
import { getSettings, setSetting, fmt, bizOf, msgFor, forLead, tierFor, routeOf, priceFor, leadOffer, type Settings, type Biz, type Route } from './settings';
import { now, HOUR, money, num, rnd, fillName, HttpError, voiceBlocked } from './util';
import { tg, sendText, sendFileId, uploadFile, extractMedia, msgText, downloadFile, type TgResult } from './telegram';
import { sendCapi, buildUserData, samePerson } from './capi';
import { pushTo } from './push';
import { isProxyChat, isProxyMsg, startProxyJob, HELP as PROXY_HELP } from './proxycheck';
import { handleJoinRequest, channelLinkForLead, handleChatMember } from './channel';
import { isPremiumPerson, productButtons, readChanCode, chanLine, lineFields, serviceMenu, sendMenu, answerStart, dmOnJoin, dmWelcome, noteBotStart, supportLink, lineFromText, channelPerson, joinByTok, latestJoinFor, sendPickEvent, LABEL as CHAN_LABEL, type ChanLine } from './chanads';
import { ubReady, queueUserbotText, isOwnEcho, limitMessage } from './userbot';
import { mediaDuration } from './audiodur';
import { imageSendKind, isImageFile } from './imgsend'; // v168
import { fetchMedia, localDur, saveMedia, isOurEcho, isVendorAuto, windowLeft, waMarkRead, takeSentId, waSendList, waSendButtons, logWati, type WaIn, dropSentId, waClaimIds, sameMediaKind, waMediaInFlight } from './wati'; // v168: + dropSentId, waClaimIds, sameMediaKind
import { offerLine, offerImageUrl, offerImageBytes, welcomeCaption, waBtnImgOn, waPlainImgOn } from './offerimg';
import { waProButtons, waMenuList, listAsText, waButtonsFor, buttonsAsText, isTalkToAgent, waSyncSoon, waDeletedSoon, waPhoneSync, waTapOf, btnReplyText, showsAgencyPrice, waCleanButtons } from './wasync';
import { btnKey } from './btnreplies';
import { paceAsk, paceAskWait, chOf, PRIO, tgaStopped, paceStatus } from './pace';
import { vary } from './vary';
import { checkUnitPrice } from './wasales';

export type Lead = {
  tier?: string | null; offer_until?: number | null; tried_agents?: string | null; tg_contact?: string | null; ch?: string | null; menu?: number | null; line?: string | null; biz?: string | null; biz_no?: number | null;
  id: number; token: string; source: string; theme: string | null; name: string | null; phone: string | null; email: string | null;
  service: string | null; has_bm: string | null; niche: string | null; budget: string | null; ip: string | null; ua: string | null;
  fbc: string | null; fbp: string | null; fbclid: string | null; page_url: string | null; vid: string | null; created_at: number;
  tg_chat_id: string | null; tg_username: string | null; tg_name: string | null; biz_conn: string | null; started_at: number | null;
  agent_id: number | null; assigned_at: number | null; status: string; last_in_at: number | null; last_out_at: number | null;
  first_reply_at: number | null; remind_at: number | null; remind_note: string | null; remind_due: number; contact_state: string | null; contact_at: number | null; tg_access_hash: string | null; agent_read_at: number; admin_read_at: number; fu_stage: number; fu_due: number; sold_at: number | null;
  last_text: string | null; last_at: number | null;
};
export type AgentRow = { id: number; name: string; username: string; tg_chat_id: string | null; comm_per_sale: number; receive: number; online: number; deleted: number; role?: string | null };

export const leadById = (id: number) => one<Lead>('SELECT * FROM leads WHERE id=?', id);
export const agentById = (id: number | null | undefined) => (id ? one<AgentRow>('SELECT * FROM agents WHERE id=?', id) : undefined);
export const displayName = (l: Partial<Lead>) => l.name || l.tg_name || (l.tg_username ? '@' + l.tg_username : 'Lead #' + l.id);
const serviceLabel = (svc: string | null | undefined) => (svc === 'funnel' ? 'Landing + Funnel' : svc === 'custom' ? 'Custom' : svc === 'chat' ? 'Chat with agent (question)' : 'Ad Account');

/* ---------------- messages ---------------- */
export function addMsg(lead: Pick<Lead, 'id'>, m: { dir: 'in' | 'out' | 'sys'; sender: string; agent_id?: number | null; text?: string; file_id?: string | null; file_type?: string | null; file_name?: string | null; tg_msg_id?: number | null; reply_to?: number | null; dur?: number | null; wa_id?: string | null }) {
  const t = now();
  // v139: a voice note / audio keeps its real length (WhatsApp copies are on our disk → read from the file)
  let dur = m.dur && m.dur > 0 ? m.dur : null;
  if (!dur && m.file_id && ['voice', 'audio'].includes(m.file_type || '')) dur = localDur(m.file_id);
  // v134: our WhatsApp message → its WhatsApp id (from the send) so delivered / read ticks can find it
  const chat = m.dir === 'out' && m.sender !== 'owner' ? one<{ tg_chat_id: string | null }>('SELECT tg_chat_id FROM leads WHERE id=?', lead.id)?.tg_chat_id : null;
  if (m.wa_id && chat && chat.startsWith('wa:')) dropSentId(chat, m.wa_id); // v168: id given with the row → out of the queue
  const waId = m.wa_id || (chat && chat.startsWith('wa:') ? takeSentId(chat) : null); // v166: an incoming WhatsApp message's id is saved with the row
  // v168: one WhatsApp id = one row per chat (unique index) → a second copy (webhook retry, phone sync race) is ignored, never an error
  const ins = (w: string | null) => run('INSERT OR IGNORE INTO messages(lead_id, dir, sender, agent_id, text, file_id, file_type, file_name, tg_msg_id, reply_to, created_at, wa_id, dur) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',
    lead.id, m.dir, m.sender, m.agent_id ?? null, m.text || '', m.file_id ?? null, m.file_type ?? null, m.file_name ?? null, m.tg_msg_id ?? null, m.reply_to ?? null, t, w, dur).changes;
  if (!ins(waId)) {
    // our own send (agent / admin / AI / bot) is never lost: a clashing id (a stale queued id) → saved without it
    if (!(m.dir === 'out' && m.sender !== 'owner' && waId && ins(null))) return;
  }
  // they wrote back → they have seen everything we sent before (blue ticks)
  if (m.dir === 'in') run("UPDATE messages SET read_at=? WHERE lead_id=? AND dir='out' AND read_at IS NULL", t, lead.id);
  const icon: Record<string, string> = { photo: 'Photo', video: 'Video', voice: 'Voice message', audio: 'Audio', document: 'File', sticker: 'Sticker', animation: 'GIF', video_note: '🎥 Video message' };
  const preview = (m.text || (m.file_type ? icon[m.file_type] || 'File' : '')).slice(0, 140);
  if (m.dir === 'in') {
    // v147: a plain "Ok" / "Thanks" / thumbs-up after our reply (nothing was waiting) → no reply needed; anything else → needs reply again
    const pv = one<{ last_in_at: number | null; last_out_at: number | null; noreply_at: number | null }>('SELECT last_in_at, last_out_at, noreply_at FROM leads WHERE id=?', lead.id);
    const waitingBefore = !!pv && (pv.last_in_at || 0) > (pv.last_out_at || 0) && (pv.noreply_at || 0) < (pv.last_in_at || 0);
    if (pv && (pv.last_out_at || 0) > 0 && !waitingBefore && isAck(m.text, m.file_type)) run("UPDATE leads SET noreply_at=?, noreply_by='auto' WHERE id=?", t, lead.id);
    run("UPDATE leads SET last_text=?, last_at=?, last_in_at=?, fu_stage=0, fu_due=0, fu_q=NULL, remind_due=0, auto_stop=NULL, status=CASE WHEN status='sold' OR sold_at IS NOT NULL THEN 'sold' ELSE 'active' END WHERE id=?", preview, t, t, lead.id);
  } else if (m.dir === 'out' && m.sender === 'bot') {
    // automatic welcome — not a human reply, so it doesn't start the follow-up clock
    run('UPDATE leads SET last_text=?, last_at=? WHERE id=?', preview, t, lead.id);
  } else if (m.dir === 'out') {
    run("UPDATE leads SET remind_due=0 WHERE id=?", lead.id);
    // a person answered (agent app, admin app or the owner's phone) → the chat is no longer unread for anyone
    if (['agent', 'admin', 'owner', 'ai'].includes(m.sender)) run('UPDATE leads SET agent_read_at=?, admin_read_at=? WHERE id=?', t, t, lead.id);
    // a person started talking → the waiting welcome (text + voice) is dropped right away (the worker sends the held agent alert)
    if (['agent', 'admin', 'owner'].includes(m.sender)) {
      run("UPDATE delayed_msgs SET due_at=? WHERE lead_id=? AND status='queued' AND due_at>?", t - 1, lead.id, t);
      run("UPDATE delayed_msgs SET status='queued', due_at=? WHERE lead_id=? AND status='wait'", t - 1, lead.id); // v141: deferred WhatsApp Pro welcome → dropped too
    }
    // v141: an agent answered → their "missed in a row" counter starts again
    if (m.sender === 'agent' && m.agent_id) run('UPDATE agents SET miss_n=0 WHERE id=? AND COALESCE(miss_n,0)>0', m.agent_id);
    run("UPDATE leads SET last_text=?, last_at=?, last_out_at=?, fu_due=0, fu_q=NULL, first_reply_at=COALESCE(first_reply_at, CASE WHEN ? IN ('agent','admin','owner') THEN ? END) WHERE id=?", preview, t, t, m.sender, t, lead.id);
  } else {
    run('UPDATE leads SET last_text=?, last_at=? WHERE id=?', preview, t, lead.id);
  }
}

/** v139: one page of a chat for the apps. New rows are found by id (`after` = the cursor, the highest id the app has —
 *  works for rows imported later with an older time), and shown in real time order: created_at, then id.
 *  Empty customer rows (no text, no media) are left out. Voice notes without a stored length get it from our file once. */
export function chatPage(leadId: number, after: number, limit: number, withAgent: boolean) {
  const rows = all<Record<string, any>>(`SELECT * FROM (SELECT m.id, m.dir, m.sender, m.text, m.file_id, m.file_type, m.file_name, m.created_at, m.read_at, m.delivered_at, m.reply_to, m.deleted_at, m.deleted_by, m.agent_id, m.via, m.dur${withAgent ? ", CASE WHEN a.role='manager' THEN a.name || ' (manager)' ELSE a.name END agent_name" : ''}
      FROM messages m ${withAgent ? 'LEFT JOIN agents a ON a.id=m.agent_id' : ''} WHERE m.lead_id=? AND m.id>? ORDER BY m.id LIMIT ?) ORDER BY created_at, id`, leadId, after, limit);
  const cursor = rows.reduce((x, r) => Math.max(x, r.id), after);
  const empty = new Set(all<{ id: number }>(`SELECT m.id FROM messages m WHERE m.lead_id=? AND m.id>? AND ${emptyInSql('m')}`, leadId, after).map(r => r.id));
  let fixed = 0;
  for (const r of rows) {
    if (fixed < 20 && !r.dur && ['voice', 'audio'].includes(r.file_type) && String(r.file_id || '').startsWith('wa:')) {
      fixed++; const d = localDur(r.file_id); if (d) { r.dur = d; run('UPDATE messages SET dur=? WHERE id=?', d, r.id); }
    }
  }
  return { messages: empty.size ? rows.filter(r => !empty.has(r.id)) : rows, cursor };
}

/* ---------------- routing ---------------- */
/** Agents (not the manager) that take this business's chats: tagged Agency / Funnel in Admin → Agents. */
/** Who shares the new chats of a business. Agency: the agents, plus the manager when the manager's "Receive new leads" is ON
 *  (so 4 chats → 3 agents + manager). `withMgr=false` = agents only (the unanswered-chat rotation, where the manager is the last stop). */
export function bizAgents(biz: Route, withMgr = true, ch: 'tg' | 'wa' = 'tg') {
  // the manager shares Agency chats when his "Receive new leads" is ON, Premium chats when he takes Premium (Admin → Agents → manager)
  const mgr = !withMgr ? '' : biz === 'agency' ? "OR (role='manager' AND receive=1)" : biz === 'premium' && mgrTakes('premium') ? "OR role='manager'" : '';
  return all<{ id: number; online: number }>(`SELECT id, online FROM agents WHERE deleted=0 AND (
      (receive=1 AND COALESCE(role,'agent')!='manager' AND (',' || COALESCE(lines,'agency') || ',') LIKE ? AND (',' || COALESCE(chans,'tg') || ',') LIKE ?) ${mgr}) ORDER BY id`, `%,${biz},%`, `%,${ch},%`);
}
/** Does the manager take Funnel / Premium chats? (Agency: his "Receive new leads" switch.) */
export const mgrTakes = (x: 'funnel' | 'premium', s: Settings = getSettings()) => (',' + (s.mgr_lines ?? 'funnel,premium') + ',').includes(',' + x + ',');
/** Funnel chats are handled by agents when the admin switched that on (or the manager doesn't take Funnel) AND some agent is tagged Funnel. */
export const funnelToAgents = (s: Settings = getSettings()) => (s.funnel_to_agents === '1' || !mgrTakes('funnel', s)) && bizAgents('funnel').length > 0;
export const managerId = () => one<{ id: number }>("SELECT id FROM agents WHERE deleted=0 AND role='manager' ORDER BY id LIMIT 1")?.id ?? null;

/** New chat → who gets it.
 *  Agency: agents tagged Agency (+ the manager when "Receive new leads" is ON).
 *  Funnel: the manager (if he takes Funnel and "Funnel leads to agents" is off), else agents tagged Funnel.
 *  Premium: agents tagged Premium (+ the manager if he takes Premium). Nobody → manager, then the normal agents — a chat is never lost. */
export function pickAgent(service?: string | null, line?: string | null, lead?: { tier?: string | null; ch?: string | null } | null): number | null {
  const s = getSettings();
  const biz = routeOf({ service, line, tier: lead?.tier });
  const ch = lead?.ch === 'wa' ? 'wa' : 'tg'; // v131: WhatsApp chats only to agents allowed WhatsApp (Admin → Agents), else the manager
  if (biz === 'funnel' && !funnelToAgents(s)) {
    const m = managerId();
    if (m) return m;
  }
  let rows = bizAgents(biz, true, ch);
  if (!rows.length && biz === 'premium') { const m = managerId(); if (m) return m; } // nobody takes Premium → the manager
  if (!rows.length && ch === 'wa') { const m = managerId(); if (m) return m; } // nobody has WhatsApp → the manager
  if (!rows.length && biz !== 'agency') rows = bizAgents('agency', true, ch); // no manager / no tagged agents: don't lose the lead
  if (!rows.length) rows = all<{ id: number; online: number }>(`SELECT id, online FROM agents WHERE deleted=0 AND receive=1 AND COALESCE(role,'agent')!='manager' AND (',' || COALESCE(chans,'tg') || ',') LIKE ? ORDER BY id`, `%,${ch},%`);
  let list = rows.filter(a => a.online);
  if (!list.length) list = rows;
  if (!list.length) return managerId();
  const key = (biz === 'funnel' ? 'rr_last_f' : biz === 'premium' ? 'rr_last_p' : 'rr_last') + (ch === 'wa' ? '_wa' : '');
  const last = num((s as Record<string, string>)[key]);
  const next = list.find(a => a.id > last) || list[0];
  setSetting(key as 'rr_last', next.id);
  return next.id;
}

/** Who gets this lead's Telegram chat: the agent who had them on their call list (they phoned / WhatsApp'd them, so the
 *  person expects them) — if still allowed for that business — else the normal rotation. */
export function ownerFor(lead: { service?: string | null; line?: string | null; tier?: string | null; call_agent_id?: number | null; ch?: string | null }) {
  const c = lead.call_agent_id;
  if (c && agentFits(c, routeOf(lead)) && (lead.ch !== 'wa' || agentHasWa(c))) return c;
  return pickAgent(lead.service, lead.line, lead);
}

/** v131: may this agent get WhatsApp chats? (the manager always) */
export const agentHasWa = (id: number | null | undefined) => !!id && !!one(`SELECT 1 FROM agents WHERE id=? AND deleted=0 AND (role='manager' OR (',' || COALESCE(chans,'tg') || ',') LIKE '%,wa,%')`, id);

/** Notify agent on Telegram (reply-able) + phone push. */
export async function notifyAgent(agent: AgentRow | undefined, text: string, leadId: number | null, push?: { title: string; body: string; alarm?: boolean }) {
  if (!agent) return;
  const s = getSettings();
  if (push) void pushTo('agent', agent.id, push.title, push.body, leadId ? { lead_id: String(leadId) } : {}, { alarm: !!push.alarm });
  if (!agent.tg_chat_id) return;
  const r = await tg(s, 'sendMessage', { chat_id: agent.tg_chat_id, text, disable_web_page_preview: true });
  if (r.ok && leadId) run('INSERT OR REPLACE INTO relay(agent_chat, msg_id, lead_id) VALUES(?,?,?)', String(agent.tg_chat_id), r.result.message_id, leadId);
}

/** v141: who answers this chat right now — the cover agent while one is set, else the owner (agent_id). */
export const handlerOf = (lead: { agent_id: number | null; cover_agent_id?: number | null }) => agentById(lead.cover_agent_id || lead.agent_id);
/** v141: the push title for a new message: "Cover for <Owner> – <Customer>" while covered, else "<Customer> · WhatsApp / Telegram". */
export function msgTitle(lead: Lead) {
  const who = displayName(lead);
  const c = (lead as Lead & { cover_agent_id?: number | null }).cover_agent_id;
  if (c && c !== lead.agent_id) return `Cover for ${agentById(lead.agent_id)?.name || 'agent'} – ${who}`;
  return who + (lead.ch === 'wa' ? ' · WhatsApp' : ' · Telegram');
}
async function relayToAgent(s: Settings, agent0: AgentRow | undefined, lead: Lead, head: string, text: string, type: string | null, fileId: string | null) {
  // v141: a covered chat → the cover gets it (the owner is away); a chat still waiting for its welcome → nothing yet
  if (await holdGate(lead.id)) return;
  const cov = (lead as Lead & { cover_agent_id?: number | null }).cover_agent_id;
  const agent = cov ? agentById(cov) : agent0;
  if (!agent) return;
  void pushTo('agent', agent.id, msgTitle(lead), text || (type ? 'Sent a ' + type.replace('_', ' ') : 'New message'), { lead_id: String(lead.id) });
  if (!agent.tg_chat_id) return;
  let r = fileId ? await sendFileId(s, agent.tg_chat_id, null, type || 'document', fileId, head + (text ? '\n' + text : '')) : null;
  if (!r || !r.ok) r = await tg(s, 'sendMessage', { chat_id: agent.tg_chat_id, text: head + '\n' + (text || (type ? `[${type}]` : '')), disable_web_page_preview: true });
  if (r.ok) run('INSERT OR REPLACE INTO relay(agent_chat, msg_id, lead_id) VALUES(?,?,?)', String(agent.tg_chat_id), r.result.message_id, lead.id);
}

/** After the welcome is sent: alert the CURRENT agent (+ admin) with any messages that came in meanwhile, and start the reply clock now. */
async function releaseAlert(lead: Lead, since: number, a: { info: string; title: string; body: string; admin: string }) {
  const later = all<{ text: string; file_type: string | null }>("SELECT text, file_type FROM messages WHERE lead_id=? AND dir='in' AND created_at>? ORDER BY created_at, id LIMIT 5", lead.id, since + 1);
  const extra = later.map(m => '💬 ' + (m.text || `[${m.file_type || 'file'}]`)).join('\n');
  const info = extra ? a.info.replace('\n↩️', '\n' + extra + '\n\n↩️') : a.info;
  run('UPDATE leads SET assigned_at=? WHERE id=? AND assigned_at IS NOT NULL', now(), lead.id);
  const ag = agentById(one<{ a: number | null }>('SELECT agent_id a FROM leads WHERE id=?', lead.id)?.a ?? lead.agent_id); // the CURRENT agent
  await notifyAgent(ag, info, lead.id, { title: a.title, body: a.body, alarm: true }); // new lead → rings even on silent (if the agent left that on)
  void pushTo('admin', null, a.title, a.admin, { lead_id: String(lead.id) }, { alarm: true });
}

export const CHANNEL_SLOT = '{{channel_join_link}}';
export const WELCOME_VOICE = '{{welcome_voice}}';
/* ---------------- welcome message (sent 30–40s later by the worker, so it feels human) ---------------- */
export function welcomeText(s0: Settings, lead: Pick<Lead, 'name' | 'tg_name'> & { service?: string | null; line?: string | null; tier?: string | null; offer_until?: number | null; source?: string | null; ch?: string | null; menu?: number | null }) {
  if (lead.menu === 1 && menuOn(s0)) return menuText(s0, lead);
  const s = forLead(s0, lead);
  let w = fillName(fmt(lead.service === 'chat' && s.chat_welcome_msg.trim() ? s.chat_welcome_msg : s.welcome_msg, s), lead).trim();
  // came from a retargeting ad → this week's offer, so they don't have to ask
  const o = leadOffer(s0, lead);
  if (o && o.text.trim()) w += (w ? '\n\n' : '') + '🎁 ' + o.text.trim();
  // {channel} becomes this person's own join link (made by the bot when the welcome is sent) → join request → Subscribe
  if (s.welcome_channel_on === '1' && lead.source !== 'channel' && (s.channel_link || s.channel_chat) && s.welcome_channel_line) w += (w ? '\n\n' : '') + fmt(s.welcome_channel_line, s, { channel: CHANNEL_SLOT });
  // WhatsApp community — one plain link for everyone (no tracking, no Meta event)
  if (lead.ch !== 'wa' && s.wa_on === '1' && s.welcome_wa_on === '1' && s.wa_comm_link.trim() && s.welcome_wa_line.trim()) w += (w ? '\n\n' : '') + fmt(s.welcome_wa_line, s);
  return w;
}
/* ======================= v133: no link → the 1/2/3/4 menu ======================= */
export const menuOn = (s: Settings) => s.menu_on !== '0' && !!String(s.menu_msg || '').trim();
/** WhatsApp *bold* / _italic_ marks → plain on Telegram (Telegram messages are sent as plain text). */
const plainMarks = (t: string) => t.replace(/\*([^*\n]+)\*/g, '$1').replace(/(^|[\s(])_([^_\n]+)_(?=$|[\s).,!?])/gm, '$1$2');
export function menuText(s: Settings, lead: Pick<Lead, 'name' | 'tg_name'> & { ch?: string | null }) {
  const p = tierFor(s, 'premium');
  const t = fillName(fmt(s.menu_msg, s, { price_premium: p.price_account, delivery_premium: p.delivery_time }), lead).replace(/\n{3,}/g, '\n\n').trim();
  return lead.ch === 'wa' ? t : plainMarks(t);
}
/** Their answer to the menu: 1 Agency · 2 Premium · 3 Funnel · 4 something else (also "ek/do/teen/chaar", "2️⃣", "premium"…). */
export function menuNum(text: string): 1 | 2 | 3 | 4 | null {
  const x = String(text || '').toLowerCase().replace(/[\uFE0F\u20E3*_.)\]\[(#:\-\s]/g, '');
  if (/^[1-4]$/.test(x)) return +x as 1 | 2 | 3 | 4;
  // v137: a WhatsApp list-menu tap arrives as its row title: "2 · Premium ad account", "4 · Talk to an agent"
  const row = String(text || '').match(/^\s*\*?([1-4])\uFE0F?\u20E3?\*?\s*[·•.\-):|]\s*\S/);
  if (row) return +row[1] as 1 | 2 | 3 | 4;
  const w: Record<string, 1 | 2 | 3 | 4> = { ek: 1, one: 1, do: 2, two: 2, teen: 3, tin: 3, three: 3, char: 4, chaar: 4, chār: 4, four: 4 };
  if (x in w) return w[x];
  const ln = String(text || '').length <= 60 ? lineFromText(text) : null;
  return ln === 'premium' ? 2 : ln === 'funnel' ? 3 : ln === 'agency' ? 1 : null;
}
const MENU_LABEL = { 1: 'Agency ad account', 2: '⭐ Premium ad account', 3: 'Landing page + funnel', 4: 'Something else' } as const;
/** A menu chat answered → the chat becomes that type (price strip, commission, pixel) and goes to an agent who handles it. */
export async function menuPick(s: Settings, lead: Lead, text: string): Promise<Lead> {
  if (lead.menu !== 1 || lead.status === 'sold') return lead;
  const n = menuNum(text);
  if (!n) return lead;
  if (!run('UPDATE leads SET menu=2 WHERE id=? AND menu=1', lead.id).changes) return lead;
  if (n === 4) addMsg(lead, { dir: 'sys', sender: 'system', text: `📋 Picked 4 from the menu: ${MENU_LABEL[4]}` });
  else {
    const t = n === 2 ? 'premium' : n === 3 ? 'funnel' : 'agency';
    if (chanOf(lead) !== t) setLeadType(lead, t, `customer, menu answer ${n}`);
    else addMsg(lead, { dir: 'sys', sender: 'system', text: `📋 Picked ${n} from the menu: ${MENU_LABEL[n]}` });
  }
  let l = leadById(lead.id)!;
  const wa = l.ch === 'wa';
  const fits = (id: number | null | undefined) => agentFits(id, routeOf(l)) && (!wa || agentHasWa(id));
  const to = n === 4 ? (managerId() ?? l.agent_id) : fits(l.agent_id) ? l.agent_id : ownerFor(l);
  if (to && to !== l.agent_id) {
    run('UPDATE leads SET agent_id=?, assigned_at=?, tried_agents=NULL WHERE id=?', to, now(), l.id);
    l = leadById(l.id)!;
    const ag = agentById(to);
    const who = displayName(l);
    addMsg(l, { dir: 'sys', sender: 'system', text: `🔀 Moved to ${ag?.name || 'agent'} (menu answer ${n})` });
    if (!alertsHeld(l.id)) await notifyAgent(ag, `🔀 #${l.id} ${who} picked ${n} from the menu: ${MENU_LABEL[n]}${wa ? ' (WhatsApp)' : ''}\nThis chat is yours now.\n\n↩️ Reply to this message to answer.`, l.id, { title: `${MENU_LABEL[n]} · new chat`, body: who, alarm: true });
  }
  if (wa) waSyncSoon(l.id); // v137: WATI contact attributes (Pro)
  return l;
}

/** v120: what decides the welcome's words (Agency / Premium / Funnel, chat or form) — if it changes before sending, the welcome is written again. */
const welcomeType = (l: { service?: string | null; line?: string | null; tier?: string | null; menu?: number | null }) => `${bizOf(l)}|${l.tier || ''}|${l.service || ''}|${l.line || ''}${l.menu === 1 ? '|menu' : ''}`;
/** v141: does a new chat wait (hidden from its agent, alert held) for its welcome? A welcome delay, a welcome voice note or the
 *  WhatsApp Pro buttons flow (welcome text + voice come after the customer's first action) → yes. */
export function welcomeHolds(s: Settings, lead: { ch?: string | null }) {
  return num(s.welcome_delay_sec, 35) > 0 || voiceOn(s) || (lead.ch === 'wa' && waProButtons(s));
}
const voiceOn = (s: Settings) => s.welcome_voice_on === '1' && !!s.el_key;
/** The full welcome text of a WhatsApp Pro chat, sent after the customer's first action (v141). */
export const WELCOME_TEXT2 = '{{welcome_text}}';
const FOREVER = 9e15;
const welcomeGap = (s: Settings) => { const base = Math.max(0, num(s.welcome_delay_sec, 35)); return base ? Math.max(0, base - 5 + Math.random() * 10) * 1000 : 0; };
const voiceGap = (s: Settings) => Math.max(5, num(s.welcome_voice_delay_sec, 25)) * 1000 * (0.85 + Math.random() * 0.3);
/** Is this the WhatsApp Pro buttons flow (the welcome goes as image + buttons; text + voice wait for an action)? List-menu chats are not. */
const proBtnFlow = (s: Settings, lead: { ch?: string | null; menu?: number | null }) => lead.ch === 'wa' && waProButtons(s) && !(lead.menu === 1 && menuOn(s));

/** Queues the welcome. When `notify` is given, the chat is held: hidden from its agent and the agent alert waits until the
 *  welcome text AND the welcome voice note are sent (or failed / skipped), with a safety time-out. Returns true if queued. */
function queueWelcome(s: Settings, lead: Lead, notify?: { info: string; title: string; body: string; admin: string }) {
  const w = welcomeText(s, lead);
  if (!w) return false;
  // we were already talking in this chat (agent / admin / owner's phone) → no welcome, no voice
  if (lead.tg_chat_id && one("SELECT 1 FROM messages m JOIN leads l ON l.id=m.lead_id WHERE l.tg_chat_id=? AND m.dir='out' AND m.sender IN ('agent','admin','owner') LIMIT 1", lead.tg_chat_id)) return false;
  const t = now(), due = t + welcomeGap(s);
  run("INSERT INTO delayed_msgs(lead_id, text, due_at, status, created_at, notify, wtype) VALUES(?,?,?,'queued',?,?,?)", lead.id, w, due, t, notify ? JSON.stringify(notify) : null, welcomeType(lead));
  const pro = proBtnFlow(s, lead);
  let until = due + 120000; // the welcome text is late (worker stopped) → the chat shows anyway 2 min after its due time
  // v141 WhatsApp Pro: the full welcome text and the voice wait ('wait') for the customer's first action
  if (pro) run("INSERT INTO delayed_msgs(lead_id, text, due_at, status, created_at, notify) VALUES(?,?,0,'wait',?,NULL)", lead.id, WELCOME_TEXT2, t);
  // a short AI voice note a little after the welcome (Admin → AI → Voice notes → Welcome voice note)
  if (voiceOn(s)) {
    const vd = voiceGap(s);
    run("INSERT INTO delayed_msgs(lead_id, text, due_at, status, created_at, notify) VALUES(?,?,?,?,?,NULL)", lead.id, WELCOME_VOICE, pro ? 0 : due + vd, pro ? 'wait' : 'queued', t);
    if (!pro) until = Math.max(until, due + vd + 60000); // safety: the voice delay + 60 s
  }
  if (notify) run('UPDATE leads SET hold_alert=?, hold_since=?, hold_until=?, released_at=NULL WHERE id=?', JSON.stringify(notify), t, until, lead.id);
  return true;
}
/** A chat is "waiting for its welcome" (v141: welcome text + welcome voice): agents and the manager don't see it yet, and no
 *  reply clock runs. Released when both went (or failed / skipped); safety time-out = hold_until. The admin always sees it. */
// held while something of the welcome is still to come: a step waiting for the customer's action (WhatsApp Pro), or a queued
// step that is not overdue (text: 2 min grace after its due time; voice: 60 s) — so a stopped worker never hides a chat for good
export const heldSql = (alias = 'l') => `(${alias}.hold_alert IS NOT NULL AND EXISTS (SELECT 1 FROM delayed_msgs d WHERE d.lead_id=${alias}.id AND (d.status='wait' OR (d.status='queued' AND d.due_at > ${now()} - CASE WHEN d.text='${WELCOME_VOICE}' THEN 60000 ELSE 120000 END) OR (d.status='sending' AND d.due_at > ${now()} - 300000))))`;
export const welcomePendingSql = heldSql;
/** v144: a chat needs a reply when the customer wrote last — open chats AND sold ones (repeat buyers, top-up requests). Never dead / merged. */
export const OPEN_ST = "('active','sold')";
/** v147: the customer wrote last AND it was not marked "No reply needed" (by the admin, or a plain "Ok" / "Thanks" after our reply). */
export const waitSql = (a = 'leads') => `COALESCE(${a}.last_in_at,0)>COALESCE(${a}.last_out_at,0) AND COALESCE(${a}.noreply_at,0)<COALESCE(${a}.last_in_at,0)`;
export const needsReplySql = (a = 'leads') => `${a}.status IN ${OPEN_ST} AND ${a}.tg_chat_id IS NOT NULL AND ${waitSql(a)} AND NOT ${heldSql(a)}`;
/** v147: a message that only closes the conversation — "ok", "thanks", "thik hai", a thumbs-up … (nothing that asks for anything). */
const ACK = new Set(['ok', 'okay', 'okey', 'oky', 'okk', 'okkk', 'okkkk', 'k', 'kk', 'kkk', 'ok ji', 'ok sir', 'ok bhai', 'ok bro', 'ok brother', 'ok dear', 'ok thanks', 'ok thank you', 'ok thanku', 'ok ty', 'okay sir', 'okay thanks', 'okay bhai',
  'ok done', 'done', 'thik hai', 'theek hai', 'thik h', 'thik', 'theek', 'thk hai', 'tik hai', 'thik hai bhai', 'thik hai sir', 'theek hai bhai', 'ok thik hai', 'thanks', 'thank you', 'thanku', 'thankyou', 'thanks bhai', 'thanks sir', 'thanks bro', 'thank you sir', 'thank you bhai', 'thx', 'ty', 'tq',
  'ji', 'ji sir', 'ji bhai', 'hmm', 'hm', 'hmmm', 'hmmmm', 'haan', 'haa', 'han', 'ha', 'haan ji', 'accha', 'acha', 'achha', 'achcha', 'acha thik hai', 'accha thik hai', 'sure', 'alright', 'fine', 'nice', 'good', 'great', 'cool', 'noted', 'got it', 'samajh gaya', 'samaj gaya']);
export function isAck(text: string | null | undefined, fileType?: string | null) {
  if (fileType === 'sticker') return true;
  if (fileType) return false;
  const raw = String(text || '').trim();
  if (!raw || raw.length > 30) return false;
  if (/^[\u{1F44D}\u{1F44C}\u{1F64F}\u{1F642}\u{1F60A}\u{2764}\u{FE0F}\u{1F3FB}-\u{1F3FF}\u{1F91D}\u{2705}\s]+$/u.test(raw)) return true; // thumbs-up, ok-hand, folded hands, smiles, heart, handshake, check
  const t = raw.toLowerCase().replace(/[\p{Extended_Pictographic}️‍]/gu, ' ').replace(/[.!,~\-]+/g, ' ').replace(/\s+/g, ' ').trim();
  return ACK.has(t);
}
export const chatHeld = (leadId: number) => !!one(`SELECT 1 FROM leads l WHERE l.id=? AND ${heldSql('l')}`, leadId);
export const welcomeDueAt = (leadId: number) => one<{ due_at: number }>(`SELECT due_at FROM delayed_msgs WHERE lead_id=? AND status='queued' AND notify IS NOT NULL AND due_at > ?`, leadId, now() - 120000)?.due_at ?? null;
/** Agent alerts for this lead are on hold until its welcome (text + voice) is done. */
const alertsHeld = (leadId: number) => !!one('SELECT 1 FROM leads WHERE id=? AND hold_alert IS NOT NULL', leadId);
/** v141: true = don't alert the agent now (still held, or the hold just ended and the release alert carried this message). */
async function holdGate(leadId: number) {
  if (!alertsHeld(leadId)) return false;
  if (chatHeld(leadId)) return true;
  await releaseHold(leadId, 'timeout');
  return true;
}
/** v141: the hold ends → the chat shows for its agent, the held "new lead" alert goes (with what they wrote meanwhile) and the
 *  reply / follow-up clocks start NOW (assigned_at, released_at). Once per chat. */
export async function releaseHold(leadId: number, why: 'done' | 'timeout' | 'answered' | 'failed' = 'done') {
  const r = one<{ hold_alert: string; hold_since: number | null }>('SELECT hold_alert, hold_since FROM leads WHERE id=? AND hold_alert IS NOT NULL', leadId);
  // claim once (RETURNING gives the new values, so the old ones are read first and the update checks they are unchanged)
  if (!r || !run('UPDATE leads SET hold_alert=NULL, hold_until=NULL, released_at=? WHERE id=? AND hold_alert=?', now(), leadId, r.hold_alert).changes) return false;
  const lead = leadById(leadId);
  if (!lead) return false;
  if (why === 'timeout') addMsg(lead, { dir: 'sys', sender: 'system', text: '⏱ Shown to the agent: the welcome (text / voice note) took too long — it may still be waiting in the send queue.' });
  let a: { info: string; title: string; body: string; admin: string };
  try { a = JSON.parse(r.hold_alert); } catch { return true; }
  await releaseAlert(lead, r.hold_since || 0, a);
  return true;
}
/** v141 (worker, every few seconds): holds past their safety time-out → released. */
export async function releaseDueHolds(at = now()) {
  let n = 0;
  void at;
  for (const x of all<{ id: number }>(`SELECT l.id FROM leads l WHERE l.hold_alert IS NOT NULL AND NOT ${heldSql('l')} LIMIT 50`)) if (await releaseHold(x.id, 'timeout')) n++;
  return n;
}
/** v141: after a welcome step went: anything still queued for this chat → keep holding (voice delay + 60 s safety), else release. */
async function holdNext(leadId: number) {
  if (!alertsHeld(leadId)) return;
  if (one("SELECT 1 FROM delayed_msgs WHERE lead_id=? AND status='wait'", leadId)) { run('UPDATE leads SET hold_until=? WHERE id=? AND hold_alert IS NOT NULL', FOREVER, leadId); return; }
  const q = one<{ due_at: number; text: string }>("SELECT due_at, text FROM delayed_msgs WHERE lead_id=? AND status='queued' ORDER BY due_at DESC LIMIT 1", leadId);
  if (q) { run('UPDATE leads SET hold_until=? WHERE id=? AND hold_alert IS NOT NULL', Math.max(now(), q.due_at) + (q.text === WELCOME_VOICE ? 60000 : 120000), leadId); return; }
  await releaseHold(leadId, 'done');
}
/** v141 WhatsApp Pro: the customer took an ACTION (an action button, Talk to agent, or typed their own message) → the full welcome
 *  text after the welcome delay, then the welcome voice after the voice delay (the same settings as everywhere). Once per chat. */
export async function startDeferredWelcome(s: Settings, leadId: number) {
  const t2 = one<{ id: number }>("SELECT id FROM delayed_msgs WHERE lead_id=? AND status='wait' AND text=?", leadId, WELCOME_TEXT2);
  const v = one<{ id: number }>("SELECT id FROM delayed_msgs WHERE lead_id=? AND status='wait' AND text=?", leadId, WELCOME_VOICE);
  if (!t2 && !v) return false;
  let due = now();
  if (t2) { due += welcomeGap(s); if (!run("UPDATE delayed_msgs SET status='queued', due_at=? WHERE id=? AND status='wait'", due, t2.id).changes) return false; }
  if (v) run("UPDATE delayed_msgs SET status='queued', due_at=? WHERE id=? AND status='wait'", due + voiceGap(s), v.id);
  await holdNext(leadId);
  return true;
}
/** WhatsApp Pro: info buttons (See pricing / What's included) are not an action. */
const INFO_KEYS = new Set([btnKey('See pricing'), btnKey("What's included")]);
export const isInfoTap = (label: string) => INFO_KEYS.has(btnKey(label));

/** Worker: send due welcome messages, unless an agent already replied. */
export async function sendDueWelcomes(at?: number) {
  await releaseDueHolds().catch(() => 0);
  const t = at ?? now();
  const rows = all<{ id: number; lead_id: number; text: string; created_at: number }>("SELECT * FROM delayed_msgs WHERE status='queued' AND due_at<=? ORDER BY due_at LIMIT 20", t);
  const s = getSettings();
  for (const r of rows as (typeof rows[number] & { notify: string | null; wtype: string | null })[]) {
    // v143: a welcome / welcome voice is a reply owed to someone who wrote first → the front of its channel's send queue, but
    // still paced. Nothing to send (an agent answered, voice off) → no slot needed.
    const l0 = leadById(r.lead_id) as (Lead & { auto_stop?: string | null; voice_off?: number | null; hold_alert?: string | null }) | undefined;
    const answered = !!l0 && !!one("SELECT 1 FROM messages WHERE lead_id=? AND dir='out' AND sender IN ('agent','admin','owner') AND created_at>=?", l0.id, r.created_at);
    const noVoice = r.text === WELCOME_VOICE && (!l0 || !!l0.auto_stop || !!l0.voice_off || s.welcome_voice_on !== '1');
    if (l0?.tg_chat_id && !answered && !noVoice && !paceAsk(chOf(l0), `wel:${r.id}`, r.text === WELCOME_VOICE ? 'voice' : 'welcome', PRIO.reply, t, l0.id)) {
      // waiting for its slot: the chat stays held a little longer (up to ~4 min after it was queued), then shows to the agent anyway
      if (l0.hold_alert) run('UPDATE delayed_msgs SET due_at=? WHERE id=? AND due_at<?', Math.min(t, r.created_at + 240000), r.id, Math.min(t, r.created_at + 240000));
      continue;
    }
    // 'sending' while it goes out (the chat stays held), 'done' after — so the hold is never released in the middle of a send
    if (!run("UPDATE delayed_msgs SET status='sending' WHERE id=? AND status='queued'", r.id).changes) continue;
    try { await sendOneWelcome(s, r); } finally { run("UPDATE delayed_msgs SET status='done' WHERE id=? AND status='sending'", r.id); }
    const lead = leadById(r.lead_id);
    if (lead && alertsHeld(lead.id)) await holdNext(lead.id);
  }
}
async function sendOneWelcome(s: Settings, r: { id: number; lead_id: number; text: string; created_at: number; notify: string | null; wtype: string | null }) {
  {
    const lead = leadById(r.lead_id);
    if (!lead?.tg_chat_id) return;
    const held = alertsHeld(lead.id);
    if (one("SELECT 1 FROM messages WHERE lead_id=? AND dir='out' AND sender IN ('agent','admin','owner') AND created_at>=?", lead.id, r.created_at)) { // someone already answered → no welcome, but the agent still gets the new-lead alert
      if (held) await releaseHold(lead.id, 'answered');
      else if (r.notify) await releaseAlert(lead, r.created_at, JSON.parse(r.notify));
      return;
    }
    if (r.text === WELCOME_VOICE) {
      if (!((lead as Lead & { auto_stop?: string | null }).auto_stop || s.welcome_voice_on !== '1')) {
        try { await (await import('./ai')).sendWelcomeVoice(s, lead); } catch (e) { addMsg(lead, { dir: 'sys', sender: 'system', text: `⚠️ Welcome voice note not sent: ${(e as Error).message.slice(0, 120)}` }); }
      }
      await holdNext(lead.id); // v141: the voice went (or failed / skipped) → the agent sees the chat now
      return;
    }
    if (r.text === WELCOME_TEXT2) { // v141 WhatsApp Pro: the full welcome text after the customer's first action
      let text = welcomeText(s, lead);
      if (text.includes(CHANNEL_SLOT)) { const link = await channelLinkForLead(lead).catch(() => null); text = link ? text.split(CHANNEL_SLOT).join(link) : text.split('\n').filter(x => !x.includes(CHANNEL_SLOT)).join('\n').trim(); }
      if (text) { const res = await sendText(s, lead.tg_chat_id, lead.biz_conn, text); if (res.ok) addMsg(lead, { dir: 'out', sender: 'bot', text, tg_msg_id: res.result?.message_id }); else addMsg(lead, { dir: 'sys', sender: 'system', text: `⚠️ Welcome text not sent: ${String(res.description || '').slice(0, 120)}` }); }
      await holdNext(lead.id);
      return;
    }
    // v120: the chat's type can change after the welcome was queued (first "Agency" message, then a Premium code a second later)
    // → the welcome is written again for what the chat is NOW, so a Premium chat never gets the $25 Agency welcome
    let text = r.wtype && r.wtype !== welcomeType(lead) ? welcomeText(s, lead) || r.text : r.text;
    if (text.includes(CHANNEL_SLOT)) {
      const link = await channelLinkForLead(lead).catch(() => null);
      text = link ? text.split(CHANNEL_SLOT).join(link) : text.split('\n').filter(x => !x.includes(CHANNEL_SLOT)).join('\n').trim();
    }
    // v137 (WATI Pro): WhatsApp menu → a tap-to-answer list; every other WhatsApp welcome carries buttons. Failed → the plain text (never lost).
    const rich = (lead as Lead).ch === 'wa' && waProButtons(s) ? await waRichWelcome(s, lead, text) : false;
    if (!rich) {
      // v140: normal WhatsApp (no Pro buttons): the line's offer image as its own session message first (inside the 24-hour
      // window the customer just opened, no template), then the same plain welcome. Image missing / refused → just the text.
      if ((lead as Lead).ch === 'wa' && !waProButtons(s) && waPlainImgOn(s) && !leadOffer(s, lead)) await waPlainImage(s, lead);
      const res = await sendText(s, lead.tg_chat_id, lead.biz_conn, text);
      if (res.ok) addMsg(lead, { dir: 'out', sender: 'bot', text, tg_msg_id: res.result?.message_id });
    }
    // v141 WhatsApp Pro buttons: the full welcome text + voice wait for an action. The welcome already carried the full text
    // (no image) → no second text. The buttons did not go (plain welcome) → nothing waits for an action: the voice comes as usual.
    if (rich === 'full' || !rich || rich === 'menu') run("UPDATE delayed_msgs SET status='done' WHERE lead_id=? AND text=? AND status IN ('wait','queued')", lead.id, WELCOME_TEXT2);
    if (rich !== 'caption' && rich !== 'full') run("UPDATE delayed_msgs SET status='queued', due_at=? WHERE lead_id=? AND text=? AND status='wait'", now() + voiceGap(s), lead.id, WELCOME_VOICE);
    if (held) await holdNext(lead.id);
    else if (r.notify) await releaseAlert(lead, r.created_at, JSON.parse(r.notify)); // queued before v141
  }
}
/** v140: normal WhatsApp welcome — the chat's own line image as a separate image message (never another line's). */
async function waPlainImage(s: Settings, lead: Lead) {
  try {
    const ln = offerLine(lead);
    const img = await offerImageBytes(s, ln);
    if (!img) return false;
    const { waSendFile } = await import('./wati');
    const r = await waSendFile(s, lead.tg_chat_id!, new File([new Uint8Array(img.buf)], `${ln}.${img.type === 'image/jpeg' ? 'jpg' : 'png'}`, { type: img.type }), 'photo', '');
    if (!r.ok) { logWati('error', `offer image (${ln}) not sent before the welcome: ${r.description || ''}`); return false; }
    addMsg(lead, { dir: 'out', sender: 'bot', text: '', file_id: r.result?.photo?.[0]?.file_id || null, file_type: 'photo' });
    return true;
  } catch (e) { logWati('error', 'offer image: ' + (e as Error).message); return false; }
}
/** v137: the WhatsApp welcome as an interactive message (WATI Pro). Sent (and saved in the chat) → v141: 'menu' (list), 'caption'
 *  (image + short caption + buttons), 'full' (the full welcome text went); false = not sent (the plain welcome goes instead). */
async function waRichWelcome(s: Settings, lead: Lead, text: string): Promise<false | 'menu' | 'caption' | 'full'> {
  try {
    if (lead.menu === 1 && menuOn(s)) {
      const m = waMenuList(s, lead.name || lead.tg_name || '');
      const r = await waSendList(s, lead.tg_chat_id!, m);
      if (!r.ok) { addMsg(lead, { dir: 'sys', sender: 'system', text: '⚠️ WhatsApp list menu not sent (' + String(r.description || '').slice(0, 100) + ') — sent the text menu instead' }); return false; }
      addMsg(lead, { dir: 'out', sender: 'bot', text: listAsText(m) });
      return 'menu';
    }
    const b = waButtonsFor(s, lead);
    // v140: ONE message = the line's offer image (header) + a short caption (≤300) + the buttons. Lines never cross:
    // a chat's own line only (Premium chat → Premium image); no image for that line → the welcome as before, text + buttons.
    // a chat with a retargeting offer price keeps its own welcome text (the image shows the normal price) → no image there
    const image = waBtnImgOn(s) && !leadOffer(s, lead) ? offerImageUrl(s, offerLine(lead)) : '';
    const body0 = image ? welcomeCaption(s, offerLine(lead), 'wa') : text;
    if (body0.length <= 1024) { // the welcome itself is the buttons message
      const r = await waSendButtons(s, lead.tg_chat_id!, { body: body0, buttons: b, image });
      if (!r.ok) { addMsg(lead, { dir: 'sys', sender: 'system', text: '⚠️ WhatsApp buttons not sent (' + String(r.description || '').slice(0, 100) + ') — sent the plain welcome instead' }); return false; }
      addMsg(lead, { dir: 'out', sender: 'bot', text: buttonsAsText(body0, b) });
      if (image && !r.img) addMsg(lead, { dir: 'sys', sender: 'system', text: 'Offer image not accepted by WhatsApp — the buttons went without it (see Settings → WATI → API log).' });
      return body0 === text ? 'full' : 'caption'; // v141: did the welcome carry the full welcome text?
    }
    // too long for a buttons message (1024 characters): the plain welcome, then a short buttons message
    const res = await sendText(s, lead.tg_chat_id!, lead.biz_conn, text);
    if (!res.ok) return false;
    addMsg(lead, { dir: 'out', sender: 'bot', text });
    const body = 'Tap a button to continue, or just type your question.';
    const r = await waSendButtons(s, lead.tg_chat_id!, { body, buttons: b, image });
    if (r.ok) addMsg(lead, { dir: 'out', sender: 'bot', text: buttonsAsText(body, b) });
    return 'full';
  } catch (e) { addMsg(lead, { dir: 'sys', sender: 'system', text: '⚠️ WhatsApp buttons error: ' + (e as Error).message.slice(0, 100) }); return false; }
}

/* ---------------- sending to leads ---------------- */
/** We answered from the agent/admin app → mark their messages read in the owner's Telegram too (no unread badge there).
 *  Needs the "Read messages" right for the bot (Telegram → Business → Chatbots). Best effort. */
export async function markSeenInTelegram(lead: Pick<Lead, 'id' | 'tg_chat_id' | 'biz_conn'>) {
  if (!lead.tg_chat_id || !lead.biz_conn) return;
  const last = one<{ v: number | null }>("SELECT MAX(tg_msg_id) v FROM messages WHERE lead_id=? AND dir='in' AND tg_msg_id IS NOT NULL", lead.id)?.v;
  if (!last) return;
  await tg(getSettings(), 'readBusinessMessage', { business_connection_id: lead.biz_conn, chat_id: Number(lead.tg_chat_id), message_id: last }).catch(() => null);
}

/** v113: one "seen" for a chat everywhere: opened in the admin OR the agent app → read in both apps and in the Telegram app.
 *  (Read in Telegram → the worker's seenTick marks it read in the apps.) Telegram is told only when something new came in. */
export function markReadEverywhere(lead: Pick<Lead, 'id' | 'tg_chat_id' | 'biz_conn'> & { tg_access_hash?: string | null; admin_read_at?: number | null; agent_read_at?: number | null }) {
  const since = Math.min(lead.admin_read_at || 0, lead.agent_read_at || 0);
  const fresh = one<{ v: number | null }>(`SELECT MAX(${lead.tg_chat_id?.startsWith('wa:') ? 'id' : 'tg_msg_id'}) v FROM messages WHERE lead_id=? AND dir='in' AND created_at>?`, lead.id, since)?.v;
  run('UPDATE leads SET admin_read_at=?, agent_read_at=? WHERE id=?', now(), now(), lead.id);
  if (fresh) void import('./push').then(p => p.pushClear(lead.id, (lead as { agent_id?: number | null }).agent_id ?? null)).catch(() => null); // v134: notification gone on the phones too
  if (fresh && lead.tg_chat_id) {
    if (lead.tg_chat_id.startsWith('wa:')) { void waMarkRead(getSettings(), lead.tg_chat_id); return; } // v134: WhatsApp: blue ticks + read on the phone
    void markSeenInTelegram(lead);
    void import('./userbot').then(u => u.readInTelegram(lead.tg_chat_id!, lead.tg_access_hash || null, fresh)).catch(() => null);
  }
}

/** The message (ours or theirs) a Telegram message replies to, as our message id. */
function replyRef(leadId: number, m: { reply_to_message?: { message_id?: number } }) {
  const id = m?.reply_to_message?.message_id;
  return id ? one<{ id: number }>('SELECT id FROM messages WHERE lead_id=? AND tg_msg_id=? ORDER BY id DESC LIMIT 1', leadId, id)?.id ?? null : null;
}

/** v166: a text send with the app's client id (cid): the same cid for the same chat within 10 minutes is sent once (a retry after
 *  a timeout never reaches the customer twice); a failed send frees the cid so the retry can go. No cid → sent as before. */
export async function sendOnceByCid(cid: unknown, leadId: number, send: () => Promise<unknown>) {
  const k = String(cid ?? '').trim().slice(0, 64);
  if (!k) { await send(); return { ok: true }; }
  const key = `t:${leadId}:${k}`; // review166: per chat (a cid from another chat never blocks this one)
  run('DELETE FROM upload_ids WHERE cid=? AND at<?', key, now() - 10 * 60000);
  if (!run('INSERT OR IGNORE INTO upload_ids(cid, lead_id, at) VALUES(?,?,?)', key, leadId, now()).changes) return { ok: true, dup: true };
  try { await send(); } catch (e) { run('DELETE FROM upload_ids WHERE cid=?', key); throw e; }
  return { ok: true };
}
export async function sendToLead(lead: Lead, text: string, sender: 'agent' | 'admin', agentId: number | null, replyTo: number | null = null) {
  if (!lead.tg_chat_id) throw new HttpError(400, 'This lead has not messaged on Telegram yet');
  const t = text.trim().slice(0, 4000);
  if (!t) throw new HttpError(400, 'Type a message first');
  const s = getSettings();
  // reply to one message (swipe in the app) → Telegram shows it as a reply
  const target = replyTo ? one<{ id: number; tg_msg_id: number | null }>('SELECT id, tg_msg_id FROM messages WHERE id=? AND lead_id=?', replyTo, lead.id) : undefined;
  if (lead.tg_chat_id.startsWith('wa:')) void waMarkRead(s, lead.tg_chat_id); // v134: replying = they see blue ticks
  const r = await sendText(s, lead.tg_chat_id, lead.biz_conn, t, target?.tg_msg_id || null);
  if (!r.ok && (lead as Lead & { ch?: string | null }).ch === 'wa') throw new HttpError(400, String(r.description || 'WhatsApp: not sent').replace(/^WA_WINDOW_CLOSED: /, ''), { wa_closed: /WA_WINDOW_CLOSED/.test(String(r.description)) });
  if (!r.ok) {
    // They haven't answered yet (auto-messaged lead) → Telegram Business can't write there; send as the chat account instead.
    const inactive = /BUSINESS_CHAT_INACTIVE|BUSINESS_PEER_USAGE_MISSING|chat not found|PEER_ID_INVALID|bot can't initiate|can't initiate conversation/i.test(String(r.description || ''));
    if ((inactive || !lead.last_in_at) && lead.tg_access_hash && ubReady(s)) {
      const u = await queueUserbotText(lead.id, t, agentId, sender);
      if (!u.ok) throw new HttpError(502, 'Telegram: ' + u.error);
      addMsg(lead, { dir: 'out', sender, agent_id: agentId, text: t, tg_msg_id: (u as { msg_id?: number | null }).msg_id ?? null, reply_to: target?.id ?? null });
      run("UPDATE messages SET via='ub' WHERE id=(SELECT MAX(id) FROM messages WHERE lead_id=?)", lead.id); // v137: delete goes through the chat account
      void markSeenInTelegram(lead);
      return;
    } else throw new HttpError(502, 'Telegram: ' + limitMessage(String(r.description || 'message not delivered')));
  }
  addMsg(lead, { dir: 'out', sender, agent_id: agentId, text: t, tg_msg_id: r.ok ? r.result?.message_id : null, reply_to: target?.id ?? null });
  void markSeenInTelegram(lead);
}

/** The customer turned off voice messages in Telegram → remember it (no more voice tries) and tell the team once in the chat */
export function markVoiceOff(leadId: number) {
  const l = leadById(leadId);
  if (!l || (l as Lead & { voice_off?: number }).voice_off) return;
  run('UPDATE leads SET voice_off=1 WHERE id=?', leadId);
  addMsg(l, { dir: 'sys', sender: 'system', text: '🔇 This customer has turned off voice messages in Telegram. Voice notes can’t reach them, so send text.' });
}
export async function uploadToLead(lead: Lead, form: FormData, sender: 'agent' | 'admin', agentId: number | null) {
  if (!lead.tg_chat_id) throw new HttpError(400, 'This lead has not messaged on Telegram yet');
  const file = form.get('file');
  if (!file || typeof file === 'string') throw new HttpError(400, 'Choose a file to send');
  if (file.size > 48 * 1024 * 1024) throw new HttpError(400, 'File is larger than 48 MB');
  // v134: one upload = one send. The app sends an id with each file (the same id when "tap to send again"): a request that
  // arrives twice (slow network / proxy timeout while the server was still sending) is not sent to the customer twice.
  const cid = String(form.get('cid') || '').slice(0, 64);
  if (cid) {
    run('DELETE FROM upload_ids WHERE at<?', now() - 86400000);
    if (!run('INSERT OR IGNORE INTO upload_ids(cid, lead_id, at) VALUES(?,?,?)', cid, lead.id, now()).changes) return;
    try { await uploadToLead(lead, (() => { const f = new FormData(); for (const [k, v] of form.entries()) if (k !== 'cid') f.append(k, v); return f; })(), sender, agentId); }
    catch (e) { run('DELETE FROM upload_ids WHERE cid=?', cid); throw e; } // failed → the retry may send it
    return;
  }
  const caption = String(form.get('caption') || '').slice(0, 1000);
  const ct = file.type || '';
  let kind = String(form.get('kind') || '');
  if (!['photo', 'video', 'document', 'voice', 'audio'].includes(kind))
    kind = ct.startsWith('image/') && !/gif|svg/.test(ct) ? 'photo' : ct.startsWith('video/') ? 'video' : ct.startsWith('audio/') ? 'audio' : 'document';
  // v168: an image (png / jpg / jpeg / webp / heic, by mime or name) goes in FULL quality: the original bytes, as a photo when the
  // platform keeps its resolution, else as a document (WhatsApp: JPEG/PNG ≤ 5 MB; Telegram: ≤ 10 MB and ≤ 2560 px). See imgsend.ts.
  if ((kind === 'photo' || kind === 'document') && isImageFile(file.name, ct)) {
    const ik = imageSendKind(lead.tg_chat_id.startsWith('wa:') ? 'wa' : 'tg', Buffer.from(await file.arrayBuffer()), file.name, ct, kind);
    if (ik) kind = ik;
  }
  // Team voice notes in our voice (Admin → AI → Voice notes → "Team voice notes in our voice"): only recordings made in the app
  let send: File = file;
  let sentBuf: Buffer | null = null; // v139: the voice note bytes we send (its length is read from them)
  let saidText: string | null = null; // team voice: what the customer hears (kept so the chat + AI know)
  const s0 = getSettings();
  // Every recording made in the app goes as a real Telegram voice note (OGG/Opus) — never as an audio file
  if (['voice', 'audio'].includes(kind) && /^voice\./.test(file.name || '')) {
    const raw = Buffer.from(await file.arrayBuffer());
    let out: Buffer | null;
    if (s0.team_voice_change === '1') { const tv = await (await import('./ai')).teamVoice(s0, raw, file.name); out = tv.data; saidText = tv.text; }
    else out = await (await import('./voicefx')).toVoiceOgg(raw);
    if (!out) throw new HttpError(502, 'Could not make the voice note on the server — nothing was sent. Try again.');
    send = new File([new Uint8Array(out)], 'voice.ogg', { type: 'audio/ogg' });
    sentBuf = out;
    kind = 'voice';
  }
  const r = await uploadFile(s0, lead.tg_chat_id, lead.biz_conn, send, kind, caption);
  if (!r.ok && (lead as Lead & { ch?: string | null }).ch === 'wa') throw new HttpError(400, String(r.description || 'WhatsApp: not sent').replace(/^WA_WINDOW_CLOSED: /, ''), { wa_closed: /WA_WINDOW_CLOSED/.test(String(r.description)) });
  if (!r.ok && kind === 'voice' && voiceBlocked(r.description)) {
    markVoiceOff(lead.id);
    throw new HttpError(400, 'This customer has turned off voice messages in Telegram, so no voice note can reach them. Send it as text.' + (saidText ? ' Your words are in the message box.' : ''), { voice_off: true, text: saidText || '' });
  }
  if (!r.ok) {
    // v148: Telegram Business sends files only within 24 h of the customer's last message (it answers PEER_ID_INVALID /
    // BUSINESS_PEER_USAGE_MISSING …). Then the file goes from the chat account instead, like text already does.
    const closed = /BUSINESS_CHAT_INACTIVE|BUSINESS_PEER_USAGE_MISSING|BUSINESS_PEER_INVALID|PEER_ID_INVALID|chat not found|can't initiate/i.test(String(r.description || ''));
    if ((closed || !lead.last_in_at) && ubReady(s0)) {
      const data = sentBuf || Buffer.from(await send.arrayBuffer());
      const fid = saveMedia(data, kind === 'voice' ? 'x.ogg' : (send.name && /\.[a-z0-9]{2,5}$/i.test(send.name) ? send.name : send.type || 'x.bin'));
      const u = await queueUserbotText(lead.id, caption, agentId, sender, { id: fid, kind });
      if (!u.ok) throw new HttpError(502, 'Telegram (from your chat account): ' + limitMessage(String(u.error)));
      addMsg(lead, { dir: 'out', sender, agent_id: agentId, text: caption, file_id: fid, file_type: kind, file_name: send.name, tg_msg_id: (u as { msg_id?: number | null }).msg_id ?? null, dur: kind === 'voice' ? localDur(fid) : null });
      run("UPDATE messages SET via='ub' WHERE id=(SELECT MAX(id) FROM messages WHERE lead_id=?)", lead.id);
      if (saidText) run('UPDATE messages SET transcript=? WHERE id=(SELECT MAX(id) FROM messages WHERE lead_id=?)', saidText, lead.id);
      void markSeenInTelegram(lead);
      return;
    }
    if (!lead.last_in_at && lead.tg_access_hash) throw new HttpError(400, 'They haven’t replied yet. Send a text message first; files work once they answer.');
    if (closed) throw new HttpError(400, 'Telegram lets us send files (voice, photo) only within 24 hours of the customer’s last message. Send it as text — text still goes. Files work again once they reply.');
    throw new HttpError(502, 'Telegram: ' + (r.description || 'upload failed'));
  }
  const [ft, fid, fname] = extractMedia(r.result);
  if (kind === 'voice' && (lead as Lead & { voice_off?: number }).voice_off) run('UPDATE leads SET voice_off=0 WHERE id=?', lead.id);
  // v139: the real length of the voice note (Telegram returns it; for WhatsApp it is read from the OGG we made)
  const dur = ['voice', 'audio'].includes(ft || kind) ? mediaDuration(r.result, sentBuf) : null;
  addMsg(lead, { dir: 'out', sender, agent_id: agentId, text: caption, file_id: fid, file_type: ft || kind, file_name: fname || send.name, tg_msg_id: r.result?.message_id, dur, wa_id: r.result?.wa_id || null }); // v168: + its WhatsApp id
  if (saidText) run('UPDATE messages SET transcript=? WHERE id=(SELECT MAX(id) FROM messages WHERE lead_id=?)', saidText, lead.id);
  void markSeenInTelegram(lead);
}

/* ---------------- follow-ups & reminders ----------------
 * The clock starts from the agent's LAST message that the client hasn't answered.
 *   FU1  = 12h after that message, FU2 = 24h after FU1 is sent, FU3 = 24h after FU2 is sent (Settings → fu_hours)
 *   Dead = only after FU3 was sent and the client stays quiet for 24h more (Settings → dead_hours)
 *   A client message resets everything. A pending "Remind me" pauses follow-ups and Dead.
 *   No new follow-up alerts during quiet hours (22–9 local time); they show up at 9:00.
 *   Safety net: any open chat with no activity at all for 7 days → Dead.
 */
export function fuGaps(s: Settings) {
  const g = String(s.fu_hours || '').split(/[,\s]+/).map(Number).filter(x => x > 0);
  return [g[0] || 12, g[1] || 24, g[2] || 24];
}
export function inQuiet(t: number, s: Settings) {
  const m = String(s.quiet_hours || '').match(/^\s*(\d{1,2})\s*-\s*(\d{1,2})\s*$/);
  if (!m) return false;
  const a = +m[1] % 24, b = +m[2] % 24;
  if (a === b) return false;
  const h = new Date(t + num(s.tz_offset_min, 330) * 60000).getUTCHours();
  return a > b ? h >= a || h < b : h >= a && h < b;
}
export function fmtLocal(t: number, s: Settings) {
  const d = new Date(t + num(s.tz_offset_min, 330) * 60000);
  const mon = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][d.getUTCMonth()];
  const h = d.getUTCHours(), mi = String(d.getUTCMinutes()).padStart(2, '0');
  return `${d.getUTCDate()} ${mon}, ${h % 12 || 12}:${mi} ${h < 12 ? 'AM' : 'PM'}`;
}

let lastFu = 0;
export async function runFollowups(force = false, at?: number) {
  if (!force && now() - lastFu < 60000) return;
  lastFu = now();
  const s = getSettings();
  const t = at ?? now();
  if (force && !at) { try { setSetting('fu_last_run', String(t)); } catch { /* */ } } // v117: shown in Follow-ups check
  const gaps = fuGaps(s);
  const deadH = Math.max(1, num(s.dead_hours, 24));
  type Row = { id: number; agent_id: number | null; name: string | null; tg_name: string | null; fu_stage?: number; remind_note?: string | null };
  const changed: (Row & { kind: 'fu' | 'dead' | 'stale' | 'stale_in' | 'remind' })[] = [];

  // 1) reminders the agent set ("Remind me tomorrow 11 AM")
  for (const x of all<Row>("SELECT id, agent_id, name, tg_name, remind_note FROM leads WHERE remind_at IS NOT NULL AND remind_at<=? AND status!='merged'", t)) {
    run("UPDATE leads SET remind_at=NULL, remind_note=NULL, remind_due=1, status=CASE WHEN status='dead' THEN 'active' ELSE status END WHERE id=?", x.id);
    addMsg(x, { dir: 'sys', sender: 'system', text: `⏰ Reminder${x.remind_note ? ': ' + x.remind_note : ''}` });
    changed.push({ ...x, kind: 'remind' });
  }

  // v141: a chat still held for its welcome (text + voice) has no follow-up clock; after the release the clock starts at the release
  const waiting = "status='active' AND tg_chat_id IS NOT NULL AND COALESCE(ch,'tg')!='wa' AND remind_at IS NULL AND COALESCE(remind_due,0)=0 AND last_out_at IS NOT NULL AND last_out_at > COALESCE(last_in_at,0) AND hold_alert IS NULL";
  const outAt = 'MAX(last_out_at, COALESCE(released_at,0))';
  // hot leads (they replied at least once after their first message) get AI-written follow-ups on their own timetable
  const { aiFuActive } = await import('./ai');
  const aiFu = s.fu_auto === '1' && aiFuActive(s);
  const HOT = "(SELECT COUNT(*) FROM messages hm WHERE hm.lead_id=leads.id AND hm.dir='in')>=2";
  const hotGaps = (() => { const g = String(s.ai_fu_hours || '').split(/[,\s]+/).map(Number).filter(x => x > 0); return [g[0] || 4, g[1] || 24, g[2] || 72]; })();
  const groups: [string, number[], number][] = aiFu ? [[`AND NOT ${HOT}`, gaps, deadH], [`AND ${HOT}`, hotGaps, Math.max(1, num(s.ai_fu_dead_hours, 48))]] : [['', gaps, deadH]];
  // 2) next follow-up (only when the previous one was actually sent: fu_due=0)
  if (!inQuiet(t, s)) {
    for (const [w, g] of groups)
      for (let st = 0; st < 3; st++)
        for (const x of all<Row>(`UPDATE leads SET fu_stage=fu_stage+1, fu_ever=MAX(COALESCE(fu_ever,0), fu_stage+1), fu_due=1 WHERE ${waiting} ${w} AND fu_due=0 AND fu_stage=? AND ${outAt}<? AND COALESCE(fu_retry_at,0)<=? RETURNING id, agent_id, name, tg_name, fu_stage`, st, t - g[st] * HOUR, t))
          changed.push({ ...x, kind: 'fu' });
  }
  // 3) Dead: all 3 follow-ups sent and still no answer
  for (const [w, , dh] of groups)
    for (const x of all<Row>(`UPDATE leads SET status='dead', dead_reason='followups', fu_due=0 WHERE ${waiting} ${w} AND fu_stage>=3 AND fu_due=0 AND ${outAt}<? RETURNING id, agent_id, name, tg_name`, t - dh * HOUR))
      changed.push({ ...x, kind: 'dead' });
  // 4) safety net: no message either way for 7 days (e.g. follow-ups were never sent) → Dead, with its own reason
  for (const x of all<Row & { waiting_us: number }>("UPDATE leads SET status='dead', dead_reason='inactive', fu_due=0 WHERE status='active' AND tg_chat_id IS NOT NULL AND remind_at IS NULL AND COALESCE(remind_due,0)=0 AND COALESCE(last_at, created_at) < ? RETURNING id, agent_id, name, tg_name, (COALESCE(last_in_at,0) > COALESCE(last_out_at,0)) AS waiting_us", t - 7 * 24 * HOUR))
    changed.push({ ...x, kind: x.waiting_us ? 'stale_in' : 'stale' });

  await runRevive(t, s);
  // v131: WhatsApp chats — follow-ups inside the 24-hour window (no quiet hours: the window would close), then Dead like Telegram
  for (const x of await waFollowupsDue(t, s)) changed.push({ ...x, kind: 'fu' });
  for (const x of all<Row>(`UPDATE leads SET status='dead', dead_reason='followups', fu_due=0 WHERE ch='wa' AND status='active' AND remind_at IS NULL AND COALESCE(remind_due,0)=0 AND last_out_at > COALESCE(last_in_at,0) AND fu_stage>=3 AND fu_due=0 AND last_out_at<? RETURNING id, agent_id, name, tg_name`, t - deadH * HOUR))
    changed.push({ ...x, kind: 'dead' });

  for (const c of changed) {
    const who = c.name || c.tg_name || 'Lead';
    const ag = agentById(c.agent_id);
    if (c.kind === 'dead') { addMsg(c, { dir: 'sys', sender: 'system', text: '☠️ No reply after all follow-ups — moved to Dead. A new message from them reopens the chat.' }); await notifyAgent(ag, `☠️ #${c.id} ${who}: no reply after 3 follow-ups, moved to Dead.`, null); }
    else if (c.kind === 'stale' || c.kind === 'stale_in') {
      const why = c.kind === 'stale_in' ? 'the client’s last message was never answered' : 'no follow-up was sent';
      addMsg(c, { dir: 'sys', sender: 'system', text: `☠️ No messages for 7 days (${why}) — moved to Dead. A new message from them reopens the chat.` });
      await notifyAgent(ag, `☠️ #${c.id} ${who}: no messages for 7 days (${why}), moved to Dead.`, null);
    }
    else if (c.kind === 'remind') await notifyAgent(ag, `⏰ Reminder: #${c.id} ${who}${c.remind_note ? ' — ' + c.remind_note : ''}`, c.id, { title: `⏰ Reminder: ${who}`, body: c.remind_note || 'You asked to be reminded about this chat.' });
    // v143: automatic follow-ups go into the send queue (per channel, at the safe speed, in priority order) — drainFollowups sends
    else if (s.fu_auto === '1') { run('UPDATE leads SET fu_q=? WHERE id=?', t, c.id); continue; }
    else await notifyAgent(ag, `⏰ Follow-up #${c.fu_stage} due: #${c.id} ${who}. Open your app and send a follow-up.`, c.id, { title: `Follow-up #${c.fu_stage} due`, body: `${who} hasn’t replied. Send a follow-up now.` });
  }
  await drainFollowups(t, s, aiFu);
  return changed.length;
}

/** v143: send the follow-ups waiting in the send queue — follow-up 1 before 2 before 3, oldest first, each only when its
 *  channel's pacing allows (a late one keeps its place; nothing is dropped). Runs every few seconds in the worker. */
let draining = false;
export async function drainFollowups(at?: number, s0?: Settings, aiFu0?: boolean) {
  if (draining) return 0;
  draining = true;
  try {
    const s = s0 || getSettings();
    const t = at ?? now();
    // chats that answered / were answered / closed meanwhile → out of the line
    run("UPDATE leads SET fu_q=NULL WHERE fu_q IS NOT NULL AND (COALESCE(fu_due,0)=0 OR status!='active' OR auto_stop IS NOT NULL)");
    run("DELETE FROM pace_q WHERE kind='fu' AND COALESCE(lead_id,0) NOT IN (SELECT id FROM leads WHERE fu_q IS NOT NULL)");
    if (s.fu_auto !== '1') { run('UPDATE leads SET fu_q=NULL WHERE fu_q IS NOT NULL'); return 0; }
    let aiFu = aiFu0;
    if (aiFu === undefined) { const { aiFuActive } = await import('./ai'); aiFu = aiFuActive(s); }
    const rows = all<{ id: number; agent_id: number | null; name: string | null; tg_name: string | null; fu_stage: number; tg_chat_id: string | null; ch: string | null; biz_conn: string | null; tg_access_hash: string | null }>(
      'SELECT id, agent_id, name, tg_name, fu_stage, tg_chat_id, ch, biz_conn, tg_access_hash FROM leads WHERE fu_q IS NOT NULL AND fu_due=1 ORDER BY fu_stage, fu_q, id LIMIT 300');
    let n = 0;
    for (const c of rows) {
      const stage = Math.min(3, Math.max(1, c.fu_stage || 1));
      const ch = chOf(c);
      if (!paceAsk(ch, `fu:${c.id}:${stage}`, 'fu', (PRIO as Record<string, number>)['fu' + stage], t, c.id)) continue;
      run('UPDATE leads SET fu_q=NULL WHERE id=?', c.id);
      if ((await autoFollowup(c.id, stage, s, aiFu)) !== 'fail') { run('UPDATE leads SET fu_fails=0, fu_retry_at=NULL WHERE id=?', c.id); n++; continue; }
      if (retryLater(c.id, t)) continue; // v117: could not send → tried again in 3 h (up to 3 times), not stuck
      const who = c.name || c.tg_name || 'Lead';
      await notifyAgent(agentById(c.agent_id), `⏰ Follow-up #${stage} due: #${c.id} ${who}. Open your app and send a follow-up.`, c.id, { title: `Follow-up #${stage} due`, body: `${who} hasn’t replied. Send a follow-up now.` });
    }
    return n;
  } finally { draining = false; }
}

/** v117: an automatic follow-up could not be sent → put it back and try again in 3 hours (3 tries, then the agent is asked). */
function retryLater(id: number, t: number) {
  const l = one<{ fu_fails: number | null }>('SELECT fu_fails FROM leads WHERE id=?', id);
  const n = (l?.fu_fails || 0) + 1;
  if (n > 3) return false;
  run('UPDATE leads SET fu_stage=MAX(COALESCE(fu_stage,1)-1,0), fu_due=0, fu_fails=?, fu_retry_at=? WHERE id=?', n, t + 3 * HOUR, id);
  return true;
}

/** v117: why follow-ups are / aren't going out — counts + example chats for Admin → More → What's running → Follow-ups check. */
export function fuHealth() {
  const s = getSettings(); const t = now(); const g = fuGaps(s);
  const act = "status='active' AND tg_chat_id IS NOT NULL";
  const n = (w: string, ...a: unknown[]) => one<{ n: number }>(`SELECT COUNT(*) n FROM leads WHERE ${act} AND ${w}`, ...a)!.n;
  const ex = (w: string, ...a: unknown[]) => all<{ id: number; name: string | null; tg_name: string | null }>(`SELECT id, name, tg_name FROM leads WHERE ${act} AND ${w} ORDER BY last_at DESC LIMIT 5`, ...a).map(x => `#${x.id} ${x.name || x.tg_name || ''}`.trim());
  const rows: { k: string; label: string; n: number; ex: string[]; bad?: boolean }[] = [];
  const add = (k: string, label: string, w: string, bad = false, ...a: unknown[]) => rows.push({ k, label, n: n(w, ...a), ex: ex(w, ...a), bad });
  add('waiting', 'Waiting for the client (follow-up clock running)', 'last_out_at IS NOT NULL AND last_out_at > COALESCE(last_in_at,0) AND COALESCE(fu_due,0)=0 AND auto_stop IS NULL');
  add('no_human', 'Only the bot welcome went out — nobody from the team wrote yet (follow-ups start after the team\'s first message)', 'last_out_at IS NULL AND last_in_at IS NOT NULL', true);
  // v177 (owner): the same chats as Chats → "Needs reply" (not ones marked "No reply needed", not ones still waiting for their welcome)
  add('client_last', 'Client wrote last — waiting for the TEAM to answer (no follow-ups to send)', `last_out_at IS NOT NULL AND ${waitSql('leads')} AND NOT ${heldSql('leads')}`, true);
  add('queued', 'In the send queue — goes out at the safe sending speed (follow-up 1 first, then 2, then 3)', 'fu_q IS NOT NULL AND COALESCE(fu_due,0)=1');
  add('stuck', 'A follow-up was due but could not be sent automatically — stuck until someone sends a message', 'COALESCE(fu_due,0)=1 AND fu_q IS NULL AND last_out_at < ?', true, t - HOUR);
  add('stopped', 'Automatic messages stopped for the chat (client blocked us / deleted account …)', 'auto_stop IS NOT NULL', true);
  add('remind', 'Paused by a "Remind me"', '(remind_at IS NOT NULL OR COALESCE(remind_due,0)=1)');
  const ob = one<{ n: number; oldest: number | null }>("SELECT COUNT(*) n, MIN(created_at) oldest FROM ub_outbox WHERE status='queued'")!;
  const stops = all<{ auto_stop: string; n: number }>(`SELECT auto_stop, COUNT(*) n FROM leads WHERE ${act} AND auto_stop IS NOT NULL GROUP BY auto_stop ORDER BY n DESC LIMIT 4`);
  const fuSent = one<{ n: number }>("SELECT COUNT(*) n FROM messages WHERE sender IN ('followup','ai') AND dir='out' AND created_at>?", t - 3 * 86400000)!.n;
  const fuFail = one<{ n: number }>("SELECT COUNT(*) n FROM messages WHERE dir='sys' AND text LIKE '⚠️ Automatic follow-up%' AND created_at>?", t - 3 * 86400000)!.n;
  return {
    auto: s.fu_auto === '1', gaps: g, quiet: s.quiet_hours, quiet_now: inQuiet(t, s), last_run: num(s.fu_last_run) || null,
    sent_3d: fuSent, failed_3d: fuFail, outbox: { queued: ob.n, oldest: ob.oldest }, ub_ready: ubReady(s), ub_paused: num(s.ub_pause_until) > t || tgaStopped(t, s), ub_status: s.ub_status || '',
    rows, stops, pace: paceStatus(t),
  };
}

/** Errors that mean THIS client can't get messages (blocked us, deleted account, no such chat) → stop all automatic messages to them. */
const CLIENT_GONE = /blocked|USER_IS_BLOCKED|YOU_BLOCKED_USER|deactivated|INPUT_USER_DEACTIVATED|USER_DEACTIVATED|user not found|chat not found|PEER_ID_INVALID|BUSINESS_PEER_INVALID|PRIVACY_PREMIUM_REQUIRED|USER_PRIVACY_RESTRICTED|CHAT_WRITE_FORBIDDEN/i;
/** Telegram Business can only write where the client wrote recently → send as the chat account (userbot) instead. */
const BIZ_INACTIVE = /BUSINESS_CHAT_INACTIVE|BUSINESS_PEER_USAGE_MISSING|bot can't initiate|can't initiate conversation/i;
/** v143: the TELEGRAM CHAT ACCOUNT has a spam limit (PEER_FLOOD …) → its automatic messages wait (24 h or Resume). Per channel:
 *  a WhatsApp chat or a Telegram-bot chat is never held by it. Without a lead → is the chat account stopped at all. */
export const autoBlocked = (s: Settings, lead?: Parameters<typeof chOf>[0]) => (lead === undefined || chOf(lead) === 'tga') && tgaStopped(now(), s);

export function stopAuto(leadId: number, why: string) {
  if (!run("UPDATE leads SET auto_stop=? WHERE id=? AND auto_stop IS NULL", why.slice(0, 120), leadId).changes) return;
  addMsg({ id: leadId }, { dir: 'sys', sender: 'system', text: `🛑 Automatic messages stopped for this chat: ${why}. They start again only if the client writes.` });
}

/**
 * Send follow-up #stage (Settings → Follow-up 1/2/3, funnel chats get the funnel texts) through Telegram Business.
 * 'sent' · 'skip' (this chat is stopped / blocked us — no reminder either) · 'fail' (agent gets the usual reminder).
 */
async function autoFollowup(leadId: number, stage: number, s: Settings, aiFu = false): Promise<'sent' | 'skip' | 'fail'> {
  const l = leadById(leadId);
  if (!l || !l.tg_chat_id || l.status !== 'active') return 'skip';
  if ((l as Lead & { auto_stop?: string | null }).auto_stop) return 'skip';
  // v143: the send queue already waits while this chat's own channel is paused; this is only a last check (Telegram chat account only)
  if (autoBlocked(s, l as never)) { addMsg(l, { dir: 'sys', sender: 'system', text: `⏸ Follow-up ${stage} waits: the Telegram chat account has a spam limit. It goes out by itself when the pause ends (Admin → Auto first message → Resume).` }); return 'fail'; }
  // hot lead → the AI writes it from the chat (falls back to the template if it can't)
  let text = '', sender: 'followup' | 'ai' = 'followup';
  if (aiFu && (one<{ n: number }>("SELECT COUNT(*) n FROM messages WHERE lead_id=? AND dir='in'", l.id)?.n || 0) >= 2) {
    const { aiFollowup } = await import('./ai');
    const r = await aiFollowup(l, stage);
    if (r?.reminded) { run('UPDATE leads SET fu_due=0 WHERE id=?', l.id); return 'sent'; } // the customer named a time → reminder instead
    if (r?.text) { text = r.text; sender = 'ai'; }
  }
  if (!text) {
    const sl = forLead(s, l);
    const raw0 = [sl.fu1, sl.fu2, sl.fu3][stage - 1] || '';
    if (!raw0.trim()) return 'fail';
    const raw = vary(raw0, Math.random, s.fu_vary !== '0'); // v143: one of the versions + small wording changes
    text = fmt(raw, sl, { name: (l.name || l.tg_name || '').split(' ')[0] || 'there' }).replace(/\s+([,!])/g, '$1').trim().slice(0, 4000);
  }
  let r: { ok?: boolean; description?: string; result?: { message_id?: number } } = {};
  try { r = await sendText(s, l.tg_chat_id, l.biz_conn, text); } catch (e) { r = { ok: false, description: (e as Error).message }; }
  const err = String(r.description || '');
  if (!r.ok) {
    if (CLIENT_GONE.test(err) && !BIZ_INACTIVE.test(err)) { stopAuto(l.id, `Telegram: ${err.slice(0, 80)}`); return 'skip'; }
    if ((BIZ_INACTIVE.test(err) || !l.last_in_at) && ubReady(s)) { // v117: no saved hash is fine, the chat account finds the chat
      run("INSERT INTO ub_outbox(lead_id, text, agent_id, sender, status, created_at) VALUES(?,?,NULL,?,'queued',?)", l.id, text, sender, now());
    } else {
      addMsg(l, { dir: 'sys', sender: 'system', text: `⚠️ Automatic follow-up ${stage} could not be delivered${err ? ` (${err.slice(0, 80)})` : ''}. Please send it yourself.` });
      return 'fail';
    }
  }
  addMsg(l, { dir: 'out', sender, text, tg_msg_id: r?.result?.message_id }); // starts the next gap (sender 'bot' would not)
  addMsg(l, { dir: 'sys', sender: 'system', text: sender === 'ai' ? `🤖 AI follow-up ${stage} of 3 sent (written from this chat).` : `🤖 Follow-up ${stage} of 3 sent automatically.` });
  if (sender === 'ai') await notifyAgent(agentById(l.agent_id), `🤖 AI follow-up ${stage}/3 sent to #${l.id} ${l.name || l.tg_name || ''}:\n${text.slice(0, 300)}`, l.id).catch(() => {});
  return 'sent';
}

/**
 * Dead chats: one automatic message N1 days after going Dead (default 7) and one at N2 days (default 15).
 * The chat stays in Dead; if the client replies, the normal flow reopens it into Leads.
 */
export async function runRevive(t: number, s: Settings = getSettings()) {
  if (s.revive_on !== '1' || inQuiet(t, s)) return 0; // v143: the send queue holds a paused channel (per channel) // (WhatsApp chats are skipped below: their 24h window is closed)
  const days = String(s.revive_days || '7,15').split(',').map(x => num(x.trim())).filter(x => x > 0).slice(0, 2);
  if (!days.length) return 0;
  let sent = 0;
  for (let st = 0; st < days.length; st++) {
    const gap = st === 0 ? days[0] : days[st] - days[st - 1];
    // stage st is due when the chat has been dead for days[st] AND (for the 2nd) the 1st went out at least `gap` days ago
    const rows = all<Lead>(`SELECT * FROM leads WHERE status='dead' AND sold_at IS NULL AND tg_chat_id IS NOT NULL AND COALESCE(ch,'tg')!='wa' AND auto_stop IS NULL AND dead_at IS NOT NULL AND COALESCE(revive_stage,0)=? AND dead_at<=?
      ${st > 0 ? 'AND (revive_at IS NULL OR revive_at<=?)' : ''} ORDER BY dead_at LIMIT 20`, st, t - days[st] * 24 * HOUR, ...(st > 0 ? [t - Math.max(1, gap) * 24 * HOUR] : []));
    for (const l of rows) {
      if (!paceAsk(chOf(l), `rv:${l.id}:${st + 1}`, 'revive', PRIO.revive, t, l.id)) continue; // v143: send queue
      // claim first so two processes never send twice
      if (!run('UPDATE leads SET revive_stage=?, revive_at=? WHERE id=? AND COALESCE(revive_stage,0)=? AND status=?', st + 1, t, l.id, st, 'dead').changes) continue;
      const sl = forLead(s, l); // funnel chats get the funnel texts, Premium its prices
      const raw0 = [sl.revive1, sl.revive2][st] || '';
      if (!raw0.trim()) continue;
      const raw = vary(raw0, Math.random, s.fu_vary !== '0');
      const text = fmt(raw, sl, { name: (l.name || l.tg_name || '').split(' ')[0] || 'there' }).replace(/\s+([,!])/g, '$1').trim().slice(0, 4000);
      let ok = false;
      let gone = false;
      let mid: number | null = null;
      try {
        const r = await sendText(s, l.tg_chat_id!, l.biz_conn, text);
        ok = !!r.ok; mid = r.result?.message_id ?? null;
        const err = String(r.description || '');
        if (!ok && CLIENT_GONE.test(err) && !BIZ_INACTIVE.test(err)) { stopAuto(l.id, `Telegram: ${err.slice(0, 80)}`); gone = true; }
        else if (!ok && ubReady(s)) { run("INSERT INTO ub_outbox(lead_id, text, agent_id, sender, status, created_at) VALUES(?,?,NULL,'bot','queued',?)", l.id, text, now()); ok = true; }
      } catch { ok = false; }
      if (gone) continue;
      if (ok) {
        addMsg(l, { dir: 'out', sender: 'bot', text, tg_msg_id: mid });
        run("UPDATE leads SET status='dead' WHERE id=? AND status!='dead'", l.id); // stays in Dead until they reply
        addMsg(l, { dir: 'sys', sender: 'system', text: `📨 Dead-chat message ${st + 1} sent (${days[st]} days). The chat stays in Dead; if they reply it comes back to Leads.` });
        sent++;
      } else addMsg(l, { dir: 'sys', sender: 'system', text: `⚠️ Dead-chat message ${st + 1} could not be delivered (Telegram).` });
    }
  }
  return sent;
}

/** Agent/admin sets or clears a "remind me" time for a chat. */
export function setReminder(lead: Lead, at: unknown, note: unknown, by: string) {
  const s = getSettings();
  const t = num(at);
  if (!t) {
    run('UPDATE leads SET remind_at=NULL, remind_note=NULL, remind_due=0 WHERE id=?', lead.id);
    addMsg(lead, { dir: 'sys', sender: 'system', text: '⏰ Reminder cancelled' });
    return { ok: true };
  }
  if (t < now() + 30000) throw new HttpError(400, 'Pick a time in the future');
  if (t > now() + 60 * 24 * HOUR) throw new HttpError(400, 'Pick a time within the next 60 days');
  const n = String(note || '').trim().slice(0, 200);
  run('UPDATE leads SET remind_at=?, remind_note=?, remind_due=0, remind_by=? WHERE id=?', t, n || null, by, lead.id);
  addMsg(lead, { dir: 'sys', sender: 'system', text: `⏰ Reminder set for ${fmtLocal(t, s)}${n ? ' — ' + n : ''}` });
  return { ok: true, at: t };
}

/* ---------------- sales / topups / wallet ---------------- */
export async function recordSale(lead: Lead, agent0: AgentRow, b: { service?: string; qty?: unknown; amount?: unknown; paid?: number; link_id?: number; full?: unknown; force?: unknown; closed_by?: number | null;
  unit_price?: unknown; tier?: unknown; item?: unknown; list_price?: number | null; meta_req?: number; no_comm?: unknown }, opt: { admin?: boolean; check?: boolean } = {}) {
  // v141: a covered chat (or within the cover's credit window) → the sale is the cover's (commission, stats); the owner is kept
  // only Agency / Premium ACCOUNT sales follow the cover credit / split rules (funnel / custom: the normal rules, no commission)
  const isAcct = String(b.service || 'account') !== 'custom'; // v141: funnel sales carry the agent's funnel commission too
  const credit0 = isAcct ? saleCredit(lead, agent0) : { agent: agent0, split: null };
  // v162: a funnel sale in a covered chat: the cover has no funnel commission → the sale stays with the chat's owner (who has one)
  const own0 = b.service === 'funnel' && !credit0.split && credit0.agent.id !== lead.agent_id ? agentById(lead.agent_id) : undefined;
  const credit = own0 && !own0.deleted && own0.role !== 'manager' && !(num((credit0.agent as AgentRow & { comm_funnel?: number | null }).comm_funnel) > 0) && num((own0 as AgentRow & { comm_funnel?: number | null }).comm_funnel) > 0
    ? { agent: own0, split: null } : credit0;
  const agent = credit.agent, split = credit.split;
  const closedBy = b.closed_by ?? agent0.id;
  // A Premium chat can still buy the normal (standard) ad account: service 'account_std' → normal price + commission
  // v144: a product from the chat catalog (payment link): tier 'premium' = a Premium account even in an Agency chat, 'agency' = the normal one
  const std = b.service === 'account_std' || (b.tier === 'agency' && lead.tier === 'premium');
  const premPick = b.tier === 'premium' && lead.tier !== 'premium';
  const prem = (lead.tier === 'premium' && !std) || premPick;
  const s0 = getSettings();
  // Premium chats: the Premium price. Retargeting offer chats: the offer price (funnel offer = first month only).
  const firstFunnel = b.service === 'funnel' && !one("SELECT 1 FROM sales WHERE lead_id=? AND service='funnel'", lead.id);
  const s = std ? s0 : premPick ? tierFor(s0, 'premium') : priceFor(s0, b.service === 'funnel' && !firstFunnel ? { ...lead, offer_until: null } : lead);
  if (b.link_id) {
    // v135: a paid payment link — if the sale was just marked by hand, that sale becomes this payment (never two sales for one payment)
    const svc0 = b.service === 'account_std' ? 'account' : String(b.service || 'account'), qty0 = Math.max(1, parseInt(String(b.qty)) || 1);
    const hand = one<{ id: number; amount: number; list_price: number | null }>('SELECT id, amount, list_price FROM sales WHERE lead_id=? AND pay_link_id IS NULL AND service=? AND qty=? AND created_at>? ORDER BY id DESC LIMIT 1', lead.id, svc0, qty0, now() - 30 * 60000);
    if (hand) {
      // v166: the amount paid (never NULL: no amount → the hand sale's) + the special-price fields like a new sale
      const amt = money(b.paid || 0) > 0 ? money(b.paid!) : hand.amount;
      const lp = b.list_price && b.list_price > 0 ? money(b.list_price) : hand.list_price;
      const sp = lp && lp > 0 && Math.abs(amt - lp * qty0) > 0.004 ? lp : null;
      run('UPDATE sales SET pay_link_id=?, amount=?, list_price=?, discount=? WHERE id=?', b.link_id, amt, sp, sp != null ? money(sp * qty0 - amt) : null, hand.id);
      return { sale_id: hand.id, merged: true };
    }
  } else {
    if (one('SELECT id FROM sales WHERE lead_id=? AND created_at>?', lead.id, now() - 30000)) throw new HttpError(409, 'This sale was already recorded a moment ago');
    // v135: the payment link already recorded this sale → marking it again by hand would count it twice
    const viaLink = !b.force && one<{ code: string; created_at: number }>('SELECT p.code, x.created_at FROM sales x JOIN pay_links p ON p.id=x.pay_link_id WHERE x.lead_id=? AND x.created_at>? ORDER BY x.id DESC LIMIT 1', lead.id, now() - 48 * HOUR);
    if (viaLink) throw new HttpError(409, `Already recorded: payment link ${viaLink.code} was paid and saved as a sale. Only record again if this is a NEW sale.`, { code: 'paid_link', link: viaLink.code });
    // v156: the ad account system already saved this sale (request done) → marking it by hand would count it twice
    const viaSys = !b.force && !b.meta_req && one<{ id: number }>("SELECT x.meta_req_id id FROM sales x WHERE x.lead_id=? AND x.meta_req_id IS NOT NULL AND x.created_at>? AND NOT EXISTS(SELECT 1 FROM meta_requests r WHERE r.id=x.meta_req_id AND r.sale_id=x.id) ORDER BY x.id DESC LIMIT 1", lead.id, now() - 48 * HOUR); // v165: not a sale whose request was made from it
    if (viaSys) throw new HttpError(409, `Already recorded: the ad account system saved this sale (request #${viaSys.id}). Only record again if this is a NEW sale.`, { code: 'paid_link' });
  }
  // v156: an agent sold the other type (Premium in a normal chat, normal in a Premium chat) → the manager checks it first.
  // Nothing is recorded (no sale, no commission, no Purchase) until the manager approves (and may change the type / drop the commission).
  if (opt.check && (b.service === 'account' || b.service === 'account_std' || !b.service)) {
    const soldPrem = b.service !== 'account_std' && (b.tier === 'premium' || (b.tier !== 'agency' && lead.tier === 'premium'));
    if (soldPrem !== (lead.tier === 'premium')) {
      const S = await import('./shop');
      const what = `${soldPrem ? 'Premium' : 'Normal ($25)'} ad account sold in a ${lead.tier === 'premium' ? 'Premium' : 'normal'} chat${b.paid ? ` · paid $${money(b.paid)}` : ''} · by ${agent0.name}`;
      const id = await S.createTask({ kind: 'sale_check', source: 'system', lead_id: lead.id, agent_id: agent0.id, amount: b.paid ? money(b.paid) : null, note: what });
      run('UPDATE tasks SET data=? WHERE id=?', JSON.stringify({ agent_id: agent0.id, b, type: soldPrem ? 'premium' : 'normal' }), id);
      addMsg(lead, { dir: 'sys', sender: 'system', agent_id: agent0.id, text: `⏳ ${what}: waiting for the manager's check (Tasks #${id}). Sale and commission are recorded after approval.` });
      return { pending_check: id };
    }
  }
  // Repeat sales to the same client are recorded (commission etc.) but Meta gets only ONE Purchase per client: the first sale.
  const repeat = !!one('SELECT id FROM sales WHERE lead_id=?', lead.id);
  const service = std ? 'account' : ['account', 'funnel', 'custom'].includes(String(b.service)) ? String(b.service) : 'account';
  const qty = Math.max(1, Math.min(100, parseInt(String(b.qty)) || 1));
  // paid?: a crypto payment link was paid → record exactly what the client paid (the price when the link was made)
  // v144: the price per account (or per month) can be changed: "special price". Still an account / funnel sale (cost, counts,
  // commission per account, Purchase value = what was charged). Agents: at most max_discount_pct below the normal price.
  // v161: full access → its own list price (Mark sold → Full access)
  const listUnit = money(service === 'funnel' ? num(s.price_funnel) : b.full && service === 'account' ? (num(prem ? s0.price_premium_full : s0.price_account_full) || num(s.price_account)) : num(s.price_account));
  const hasUnit = !b.paid && service !== 'custom' && b.unit_price != null && String(b.unit_price).trim() !== '';
  const closer = closedBy ? agentById(closedBy) : undefined;
  const free = !!opt.admin || (closer ? closer.role === 'manager' : agent0.role === 'manager');
  const unit = hasUnit ? checkUnitPrice(s0, b.unit_price, listUnit, free, service === 'funnel' ? 'month' : 'account') : 0;
  const amount = money(b.paid && b.paid > 0 ? b.paid : service === 'custom' ? num(b.amount) : hasUnit ? unit * qty : listUnit * qty);
  if (!(amount > 0)) throw new HttpError(400, 'Enter a valid amount');
  // the normal price per unit when sold at another price (by hand, or a paid link made with a special price)
  const listP = hasUnit && Math.abs(unit - listUnit) > 0.004 ? listUnit : b.link_id && b.list_price && b.list_price > 0 && Math.abs(amount - b.list_price * qty) > 0.004 ? money(b.list_price) : null;
  const special = listP != null ? { list: listP, unit: money(amount / qty), discount: money(listP * qty - amount) } : null;
  // Premium ad account sale: the agent's own Premium commission when one is set (Admin → Agents), else the normal one
  type CA = AgentRow & { comm_premium?: number | null; comm_funnel?: number | null };
  // v141: funnel → the agent's funnel commission (per month sold; none when not set)
  const rateOf = (a: AgentRow) => service === 'funnel' ? num((a as CA).comm_funnel) : prem && service === 'account' && (a as CA).comm_premium != null ? num((a as CA).comm_premium) : num(a.comm_per_sale);
  const perSale = rateOf(agent);
  let commission = agent.role === 'manager' || !['account', 'funnel'].includes(service) ? 0 : money(perSale * qty); // commission on ad account sales (+ v141: funnel when set); manager: none
  // v141: split 50/50 with the cover (the commission of the agent side; a manager's half is 0 — it stays with the business)
  let shares: { a: AgentRow; v: number }[] = [];
  const baseA = split ? (split.owner.role !== 'manager' ? split.owner : split.cover) : null;
  const full = split && ['account', 'funnel'].includes(service) && baseA!.role !== 'manager' ? money(rateOf(baseA!) * qty) : 0;
  if (b.no_comm) commission = 0; // v156: the manager approved the sale without commission
  const useSplit = !b.no_comm && !!split && full > 0; // only the first commission-bearing sale (account, or funnel with a funnel commission; never a top-up)
  if (useSplit) {
    shares = [split!.owner, split!.cover].map(a => ({ a, v: a.role === 'manager' ? 0 : money(full / 2) }));
    commission = money(shares.reduce((x, y) => x + y.v, 0));
  }
  const cost = service === 'account' ? money(num(s.acct_cost, 3) * qty) : 0; // what the ad accounts cost us (kept with the sale)
  // sold at this week's retargeting offer price?
  const normal = service === 'funnel' ? num(tierFor(s0, lead.tier).price_funnel) : num((std ? s0 : tierFor(s0, lead.tier)).price_account);
  const offer = service !== 'custom' && !premPick && lead.offer_until != null && (special ? (special.list < normal) : amount < normal * qty); // incl. a paid offer link after the offer ended (v144: a special price is not an offer)
  const item = b.item === 'fb_old' ? 'fb_old' : null; // v144: Facebook account + BM sold through a payment link (custom sale, like on WhatsApp)
  const sale = one<{ id: number }>('INSERT INTO sales(lead_id, agent_id, service, qty, amount, commission, cost, created_at, offer, tier, line, full, pay_link_id, owner_agent_id, closed_by, list_price, discount, item) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) RETURNING id',
    lead.id, agent.id, service, qty, amount, commission, cost, now(), offer ? 1 : null, service === 'account' ? (prem ? 'premium' : 'agency') : null, lead.line || 'agency', b.full ? 1 : null, b.link_id || null, lead.agent_id ?? null, closedBy,
    special?.list ?? null, special ? special.discount : null, item)!;
  if (b.meta_req) run('UPDATE sales SET meta_req_id=? WHERE id=?', b.meta_req, sale.id); // v156: saved by the ad account system
  else if (service === 'account' && !b.link_id) { // v165: sold in the chat → its "give" request in Ad accounts → Requests (by itself)
    try { const M = await import('./meta'); M.requestFromSale(lead.id, sale.id, qty, prem ? 'premium' : 'std', agentById(closedBy)?.name || 'Admin'); } catch (e) { console.warn('[sale] request', (e as Error).message); }
  }
  if (useSplit) run('UPDATE leads SET cover_split_used=1 WHERE id=?', lead.id);
  if (useSplit) for (const x of shares) run('INSERT INTO sale_splits(sale_id, agent_id, share, reason, at) VALUES(?,?,?,?,?)', sale.id, x.a.id, x.v, split.reason, now());
  run("UPDATE leads SET status='sold', sold_at=COALESCE(sold_at, ?), fu_due=0 WHERE id=?", now(), lead.id);
  if ((lead as Lead).ch === 'wa') waSyncSoon(lead.id, { solved: true }); // v137 (WATI Pro): SOLVED + attributes
  addMsg(lead, { dir: 'sys', sender: 'system', agent_id: agent.id, text: `✅ Sold: ${item === 'fb_old' ? 'Facebook account + BM' : serviceLabel(service)}${prem && service === 'account' ? ' ⭐ Premium' : std ? ' (standard)' : ''}${b.full ? ' (full access)' : ''} × ${qty} = $${amount}${special ? ` · Special price ($${special.unit} instead of $${special.list}${service === 'funnel' ? ' / month' : ''})` : ''}${offer ? ' · 🎁 offer price' : ''} (${byLine(agent, lead)})${useSplit ? ' · ' + split!.reason : ''}${repeat ? ' · repeat sale, no Meta Purchase' : ''}` });
  if (repeat) return { sale_id: sale.id, amount, commission, ...(special ? { special } : {}), capi: 'repeat sale: Purchase not sent (only the first sale counts)' };
  // Purchase CAPI — only here, when the agent marks the sale. Uses the browser data saved at form time.
  const event_id = s.purchase_once === '1' ? 'purchase_lead_' + lead.id : 'purchase_' + sale.id;
  const capi = await sendCapi(s, {
    ch: (lead as Lead & { ch?: string | null }).ch, line: lead.line, event_id, event_name: 'Purchase', lead_id: lead.id, source_url: lead.page_url, once: { leads: samePerson(lead) },
    user_data: buildUserData(lead, s),
    custom_data: { value: amount, currency: 'USD', content_name: (item === 'fb_old' ? 'Facebook account + BM' : serviceLabel(service)) + (prem && service === 'account' ? ' (Premium)' : ''), num_items: qty, order_id: 'S' + sale.id },
  });
  return { sale_id: sale.id, amount, commission, ...(special ? { special } : {}), capi: 'dedup' in capi ? 'not sent: this client already had a Purchase' : capi.status };
}

/** v141: "by Suvo", or "sold by Suvo (covering for Babai)" when the credit is not the chat's owner. */
export const byLine = (a: AgentRow, lead: { agent_id: number | null }) => (lead.agent_id && a.id !== lead.agent_id && a.role !== 'manager' ? `sold by ${a.name} (covering for ${nameOf(lead.agent_id)})` : `by ${a.name}`);
/** Top-up fee for this chat. Premium retargeting offer: the FIRST top-up has 0% fee on up to offer_premium_free dollars. */
export function topupFee(lead: Pick<Lead, 'id' | 'service' | 'line' | 'tier' | 'offer_until'>, amount: number, s0: Settings = getSettings()) {
  const pct = num(tierFor(s0, lead.tier).topup_comm_pct); // Premium chats: the Premium top-up fee
  const o = leadOffer(s0, lead);
  const first = !one('SELECT 1 FROM topups WHERE lead_id=?', lead.id) && !one("SELECT 1 FROM pay_links WHERE lead_id=? AND kind='topup' AND status='paid'", lead.id);
  const free = o && o.free && first ? Math.min(amount, o.free) : 0;
  return { pct, free, fee: money((amount - free) * pct / 100) };
}

export function addTopup(lead: Lead, agent: AgentRow, amountIn: unknown, note: unknown, paid?: { fee: number; free?: number | null }, force = false) {
  const amount = money(amountIn);
  if (!(amount > 0)) throw new HttpError(400, 'Enter a valid topup amount');
  // v156: the ad account system already saved this top-up → by hand it would count twice
  const viaSys = !paid && !force && one<{ id: number }>('SELECT COALESCE(meta_req_id, meta_log_id) id FROM topups WHERE lead_id=? AND (meta_req_id IS NOT NULL OR meta_log_id IS NOT NULL) AND ABS(amount-?)<0.01 AND created_at>? ORDER BY id DESC LIMIT 1', lead.id, amount, now() - 48 * HOUR); // v165: + top-ups the ad account system logged
  if (viaSys) throw new HttpError(409, `Already recorded: the ad account system saved this $${amount} top-up (#${viaSys.id}). Only record again if this is a NEW top-up.`, { code: 'paid_link' });
  // Our service fee charged to the client on every topup (NOT an agent commission). Stored in topups.commission.
  // paid: a crypto top-up link was paid → keep the fee it was made with
  const f = topupFee(lead, amount);
  const fee = paid ? money(paid.fee) : f.fee, free = paid ? num(paid.free) : f.free, pct = f.pct;
  const total = money(amount + fee);
  // v141: recorded for whoever handles the chat (the cover while covering) — stats only. Top-ups are outside every cover credit /
  // split rule: agents never earn on top-ups (topups.commission is our fee).
  const by = (() => { const l = leadById(lead.id) as CovLead | undefined; const c = l?.cover_agent_id ? agentById(l.cover_agent_id) : undefined; return c && !c.deleted ? c : agent; })();
  run('INSERT INTO topups(lead_id, agent_id, amount, commission, note, created_at, offer_free, owner_agent_id, closed_by) VALUES(?,?,?,?,?,?,?,?,?)', lead.id, by.id, amount, fee, String(note || '').slice(0, 200), now(), free || null, lead.agent_id ?? null, agent.id);
  addMsg(lead, { dir: 'sys', sender: 'system', agent_id: by.id, text: `💰 Topup $${amount} recorded · ${pct}% fee $${fee}${free ? ` (🎁 offer: no fee on the first $${free})` : ''} · client pays $${total}` });
  return { amount, fee, total, pct, free };
}

export function wallet(agentId: number) {
  const e1 = one<{ c: number; n: number }>(`SELECT ${commSql('?')} c, (SELECT COUNT(*) FROM sales WHERE agent_id=?) n`, agentId, agentId, agentId)!; // v141: split sales by their share
  const e2 = one<{ c: number; v: number }>('SELECT COALESCE(SUM(commission),0) c, COALESCE(SUM(amount),0) v FROM topups WHERE agent_id=?', agentId)!;
  const p = one<{ paid: number; pending: number }>("SELECT COALESCE(SUM(CASE WHEN status='paid' THEN amount END),0) paid, COALESCE(SUM(CASE WHEN status='pending' THEN amount END),0) pending FROM payouts WHERE agent_id=?", agentId)!;
  const bonus = money(one<{ v: number }>('SELECT COALESCE(SUM(amount),0) v FROM agent_bonus WHERE agent_id=?', agentId)?.v || 0); // v159: incentive from the admin
  const earned = money(e1.c + bonus); // agents earn per-sale commission + incentives; topup fees belong to the business
  return { bonus, sale_comm: money(e1.c), sales: e1.n, topup_fees: money(e2.c), topup_vol: money(e2.v), topups: one<{ n: number }>('SELECT COUNT(*) n FROM topups WHERE agent_id=?', agentId)!.n, earned, paid: money(p.paid), pending: money(p.pending), available: money(earned - p.paid - p.pending) };
}

export function leadLink(s0: Settings, token: string, chat = false, biz: Biz = 'agency') {
  const s = msgFor(s0, biz);
  if (s.tg_mode === 'business' && s.owner_username) {
    let t = String((chat && s.chat_prefill_text.trim() ? s.chat_prefill_text : s.prefill_text) || '');
    t = t.includes('{code}') ? t.replace(/\{code\}/g, 'L-' + token) : `${t} L-${token}`.trim();
    return `https://t.me/${s.owner_username}?text=${encodeURIComponent(t)}`;
  }
  return s.bot_username ? `https://t.me/${s.bot_username}?start=l_${token}` : null;
}

/** Pre-typed WhatsApp message for a lead (Agency or Funnel text). {tg_link} = their own Telegram link, so the Lead event still fires when they write there. */
export function waText(s0: Settings, lead: Partial<Lead> & { tier?: string | null; token?: string | null; service?: string | null; line?: string | null; name?: string | null; tg_name?: string | null }, base?: string) {
  const biz = bizOf(lead);
  const s = msgFor(s0, biz);
  const full = lead.token && !(lead as any).tg_chat_id ? leadLink(s0, lead.token, lead.service === 'chat', biz) : (s.owner_username ? `https://t.me/${s.owner_username}` : null);
  // short link on our own site (adsbhai.com/t/CODE → their Telegram chat with the code typed) instead of the long t.me?text=… one
  const host = String(base || '').replace(/^https?:\/\//, '').replace(/\/$/, '');
  const link = full && lead.token && !(lead as any).tg_chat_id && host && !/^(localhost|127\.)/.test(host) ? `https://${host}/t/${lead.token}` : full; // https:// so WhatsApp shows the preview image
  let t = String(s.wa_msg || '');
  if (!link) t = t.split('\n').filter(x => !x.includes('{tg_link}') && !/telegram:\s*$/i.test(x.trim())).join('\n');
  return fmt(fillName(t, lead), priceFor(s0, lead as Lead), { tg_link: link || '' }).replace(/\n{3,}/g, '\n\n').trim();
}

/* ---------------- Telegram webhook ---------------- */
export async function handleUpdate(u: any) {
  // Telegram re-sends an update when our answer is slow → handle each update_id once (the same message showed 3×)
  if (typeof u?.update_id === 'number') {
    if (!run('INSERT OR IGNORE INTO tg_seen(update_id, at) VALUES(?,?)', u.update_id, now()).changes) return;
    if (u.update_id % 200 === 0) run('DELETE FROM tg_seen WHERE at<?', now() - 3 * 86400000);
  }
  const s = getSettings();

  // Someone asked to join our Telegram channel (join link from the landing top bar) → Subscribe + approve
  if (u.chat_join_request) { await handleJoinRequest(u.chat_join_request); return; }
  if (u.chat_member) { handleChatMember(u.chat_member); return; }
  // v139: See pricing / What's included in the bot welcome → answered in the bot chat (no lead, no Meta event)
  if (u.callback_query) { await (await import('./botinfo')).handleBotCallback(u.callback_query, s); return; }

  if (u.business_connection) {
    const bc = u.business_connection;
    if (bc.is_enabled) {
      setSetting('biz_conn_id', bc.id);
      setSetting('owner_id', String(bc.user?.id || ''));
      if (bc.user?.username) setSetting('owner_username', bc.user.username);
      setSetting('owner_name', [bc.user?.first_name, bc.user?.last_name].filter(Boolean).join(' '));
    } else if (bc.id === s.biz_conn_id) setSetting('biz_conn_id', '');
    return;
  }

  // Messages / the chat were deleted in Telegram. Telegram doesn't say WHO deleted (us in our own app, or the client),
  // and deleting a chat in our app is normal cleanup → automatic messages keep going. If the client really blocked us
  // or left, the next send fails with that error and stops them then (CLIENT_GONE).
  if (u.deleted_business_messages?.chat?.id) {
    const l = one<{ id: number }>('SELECT id FROM leads WHERE tg_chat_id=? ORDER BY id DESC LIMIT 1', String(u.deleted_business_messages.chat.id));
    const n = u.deleted_business_messages.message_ids?.length || 0;
    const last = l && one<{ text: string; created_at: number }>("SELECT text, created_at FROM messages WHERE lead_id=? ORDER BY created_at DESC, id DESC LIMIT 1", l.id);
    if (l && !(last && last.text.startsWith('🗑') && Date.now() - last.created_at < 10 * 60_000))
      // a quiet note only: it doesn't move the chat up the list (deleting old chats in the app is cleanup)
      run("INSERT INTO messages(lead_id, dir, sender, text, created_at) VALUES(?, 'sys', 'system', ?, ?)", l.id, `🗑 ${n > 1 ? `${n} messages` : 'A message'} deleted in Telegram (this chat here stays as it is; automatic messages continue)`, now());
    return;
  }

  const bm = u.business_message;
  if (bm?.business_connection_id && bm.business_connection_id !== s.biz_conn_id) {
    // Missed the business_connection update (e.g. bot was added before the token was saved) — fetch it now.
    const r = await tg(s, 'getBusinessConnection', { business_connection_id: bm.business_connection_id }).catch(() => null);
    const bc = r?.ok ? r.result : null;
    if (bc?.is_enabled !== false) {
      setSetting('biz_conn_id', bm.business_connection_id);
      if (bc?.user) {
        setSetting('owner_id', String(bc.user.id || ''));
        if (bc.user.username) setSetting('owner_username', bc.user.username);
        setSetting('owner_name', [bc.user.first_name, bc.user.last_name].filter(Boolean).join(' '));
      }
    }
  }
  if (bm) {
    if (bm.sender_business_bot || bm.chat?.type !== 'private') return;
    if (bm.from && String(bm.from.id) !== String(bm.chat.id)) {
      if (isOwnEcho(String(bm.chat.id), msgText(bm))) return; // our own auto/agent message sent as the chat account
      // The owner replied from his own phone — keep it in the chat history
      const lead = one<Lead>("SELECT * FROM leads WHERE tg_chat_id=? AND status!='merged' ORDER BY id DESC LIMIT 1", String(bm.chat.id));
      // v168: the copy of a message we already saved with its Telegram id (sent as the chat account, e.g. a file with no caption) → not twice
      if (lead && bm.message_id && one("SELECT 1 FROM messages WHERE lead_id=? AND dir='out' AND via='ub' AND tg_msg_id=? AND created_at>?", lead.id, bm.message_id, now() - 3600000)) return;
      if (lead) { const [ft, fid, fn] = extractMedia(bm); addMsg(lead, { dir: 'out', sender: 'owner', text: msgText(bm), file_id: fid, file_type: ft, file_name: fn, tg_msg_id: bm.message_id, reply_to: replyRef(lead.id, bm) }); }
      return;
    }
    return handleLeadMessage(s, bm, bm.business_connection_id);
  }

  const m = u.message;
  if (!m || m.chat?.type !== 'private') return;
  const chatId = String(m.chat.id);
  const text = msgText(m);
  const startParam = text.startsWith('/start') ? text.split(/\s+/)[1] || '' : null;

  // Agent links their Telegram for notifications
  if (startParam?.startsWith('ag_')) {
    const id = parseInt(startParam.slice(3).split('_')[0]);
    const code = startParam.split('_')[2] || '';
    const ag = one<AgentRow & { pass_hash: string }>('SELECT * FROM agents WHERE id=? AND deleted=0', id);
    if (ag && code === linkCode(ag.id, ag.pass_hash)) {
      run('UPDATE agents SET tg_chat_id=? WHERE id=?', chatId, ag.id);
      await tg(s, 'sendMessage', { chat_id: chatId, text: `✅ Connected, ${ag.name}! New leads and their messages will also arrive here.\n\nTo answer from Telegram, REPLY (swipe left) to a lead's message here.` });
    } else await tg(s, 'sendMessage', { chat_id: chatId, text: 'This link has expired. Open your agent app and tap “Connect Telegram” again.' });
    return;
  }

  // v111 channel flow: the services menu (plain /start, channel post link) and "/start svc_<line>[_<tok>]" buttons
  if (startParam !== null && s.chan_menu_on !== '0' && !one('SELECT 1 FROM agents WHERE tg_chat_id=? AND deleted=0', chatId) && await chanStart(s, m, startParam)) return;
  // v116: a team member (agent / admin linked to the bot) taps Start → say so, and show what customers see
  if (startParam !== null && (startParam === '' || startParam === 'menu' || /^ch(_[a-z]+)?$/.test(startParam))) {
    const me = one<{ name: string }>('SELECT name FROM agents WHERE tg_chat_id=? AND deleted=0', chatId);
    if (me) {
      await sendMenu(s, chatId, `You are connected as ${me.name} (team), so new leads come to you here.\n\nPreview, this is what customers see:`);
      return;
    }
  }

  // Owner's proxy checker (a proxy list as text or .txt file)
  const proxyChat = isProxyChat(s, chatId);
  if (proxyChat && isProxyMsg(m)) { void startProxyJob(s, m); return; }

  const agent = one<AgentRow>('SELECT * FROM agents WHERE tg_chat_id=? AND deleted=0', chatId);
  if (!agent && proxyChat) { await tg(s, 'sendMessage', { chat_id: chatId, text: PROXY_HELP }); return; }
  if (agent) {
    const rt = m.reply_to_message;
    const map = rt ? one<{ lead_id: number }>('SELECT lead_id FROM relay WHERE agent_chat=? AND msg_id=?', chatId, rt.message_id) : undefined;
    if (!map) { await tg(s, 'sendMessage', { chat_id: chatId, text: '↩️ To answer a lead, REPLY (swipe left) to one of their messages here, or use your agent app.' }); return; }
    const lead = leadById(map.lead_id);
    if (!lead?.tg_chat_id) return;
    // v166: the same rules as the app — the chat's agent (or its cover while covered) or the manager; not while the welcome is pending
    const cov = (lead as Lead & { cover_agent_id?: number | null }).cover_agent_id || null;
    const mayAnswer = agent.role === 'manager' || (cov ? cov === agent.id : lead.agent_id === agent.id);
    if (!mayAnswer || chatHeld(lead.id)) {
      await tg(s, 'sendMessage', { chat_id: chatId, text: !mayAnswer && cov && lead.agent_id === agent.id ? `⚠️ Not sent: ${agentById(cov)?.name || 'another agent'} is covering this chat right now.` : !mayAnswer ? '⚠️ Not sent: this chat is no longer yours.' : '⚠️ Not sent yet: this chat opens after the welcome message is sent.' });
      return;
    }
    let [ft, fid, fn] = extractMedia(m);
    let r: TgResult;
    let said: string | null = null;
    let tvDur: number | null = (m.voice?.duration || m.audio?.duration) ?? null;
    if (fid && ft === 'voice' && s.team_voice_change === '1') {
      // a voice note the agent recorded in Telegram → our voice too (never their own voice)
      try {
        const f = await downloadFile(s, fid);
        if (!f?.res.ok) throw new Error('could not download the voice note');
        const tv = await (await import('./ai')).teamVoice(s, Buffer.from(await f.res.arrayBuffer()), 'voice.ogg');
        r = await uploadFile(s, lead.tg_chat_id, lead.biz_conn, new File([new Uint8Array(tv.data)], 'voice.ogg', { type: 'audio/ogg' }), 'voice', m.caption || '');
        if (r.ok) { [ft, fid, fn] = extractMedia(r.result); said = tv.text; tvDur = mediaDuration(r.result, tv.data); }
      } catch (e) { r = { ok: false, description: (e as Error).message }; }
    } else r = fid ? await sendFileId(s, lead.tg_chat_id, lead.biz_conn, ft!, fid, m.caption || '') : await sendText(s, lead.tg_chat_id, lead.biz_conn, text);
    if (r.ok) { addMsg(lead, { dir: 'out', sender: 'agent', agent_id: agent.id, text: fid ? m.caption || '' : text, file_id: fid, file_type: ft, file_name: fn, tg_msg_id: r.result?.message_id, dur: tvDur }); if (said) run('UPDATE messages SET transcript=? WHERE id=(SELECT MAX(id) FROM messages WHERE lead_id=?)', said, lead.id); void markSeenInTelegram(lead); }
    else if (ft === 'voice' && voiceBlocked(r.description)) { markVoiceOff(lead.id); await tg(s, 'sendMessage', { chat_id: chatId, text: '⚠️ Not delivered: this customer has turned off voice messages in Telegram. Send it as text.' }); }
    else await tg(s, 'sendMessage', { chat_id: chatId, text: '⚠️ Not delivered: ' + (r.description || '') });
    return;
  }
  // v116: chats happen with our support account → someone writing to the bot (not already chatting in the bot, not a form link)
  // gets the menu with buttons to support, instead of a new chat inside the bot
  if (s.owner_username && !startParam?.startsWith('l_') && !one("SELECT 1 FROM leads WHERE tg_chat_id=? AND biz_conn IS NULL AND status!='merged'", chatId)) {
    noteBotStart(String(m.from?.id || chatId), [m.from?.first_name, m.from?.last_name].filter(Boolean).join(' '), 'text', null);
    if (one("SELECT 1 FROM leads WHERE tg_chat_id=? AND status!='merged'", chatId) && await sendOpenChat(s, chatId, String(m.from?.id || chatId), m.from?.first_name || '')) return;
    await answerStart(s, chatId, String(m.from?.id || chatId));
    return;
  }
  return handleLeadMessage(s, m, null);
}

export const linkCode = (id: number, passHash: string) => passHash.slice(-10).replace(/[^A-Za-z0-9]/g, 'x');

/** Can this person own a chat of this business? Funnel (with "Funnel leads to agents" OFF) → only the manager. */
function agentFits(agentId: number | null | undefined, biz: Route) {
  if (!agentId) return false;
  const a = one<{ role: string | null; lines: string | null; deleted: number }>('SELECT role, lines, deleted FROM agents WHERE id=?', agentId);
  if (!a || a.deleted) return false;
  if (a.role === 'manager') return true;
  if (biz === 'funnel' && !funnelToAgents()) return false;
  return (',' + (a.lines || 'agency') + ',').includes(',' + biz + ',');  // Premium: only agents tagged Premium
}

/** Move an earlier chat of the same person into the form lead. Its agent is kept only if allowed for the form's business
 *  (e.g. a Funnel form never keeps an Agency agent) — otherwise the chat is assigned fresh. */
function mergeOldChat(formId: number, oldId: number, oldAgent: number | null) {
  // v168: a WhatsApp message both chats have (same wa_id) stays once (the unique index would refuse the move)
  run('DELETE FROM messages WHERE lead_id=? AND wa_id IS NOT NULL AND wa_id IN (SELECT wa_id FROM messages WHERE lead_id=? AND wa_id IS NOT NULL)', oldId, formId);
  run('UPDATE messages SET lead_id=? WHERE lead_id=?', formId, oldId);
  // keep the person's Meta events and sales on the new chat → no second Lead / Purchase for the same person
  run('UPDATE capi_log SET lead_id=? WHERE lead_id=?', formId, oldId);
  run('UPDATE sales SET lead_id=? WHERE lead_id=?', formId, oldId);
  run("UPDATE leads SET tg_chat_id=NULL, status='merged' WHERE id=?", oldId);
  const f = leadById(formId)!;
  const caller = (f as Lead & { call_agent_id?: number | null }).call_agent_id;
  if (!f.agent_id && caller && agentFits(caller, routeOf(f))) run('UPDATE leads SET agent_id=?, assigned_at=? WHERE id=?', caller, now(), formId); // the one who called them
  else if (!f.agent_id && agentFits(oldAgent, routeOf(f))) run('UPDATE leads SET agent_id=?, assigned_at=? WHERE id=?', oldAgent, now(), formId);
}

const firstName = (n: string | null | undefined) => (String(n || '').trim().split(/\s+/)[0] || '').toLowerCase().normalize('NFKD').replace(/[^\p{L}\p{N}]/gu, '');
/** A form filled in the last 30 min, not yet on Telegram, with the same first name as this chat — only if exactly one fits. */
function formByName(tgName: string) {
  const fn = firstName(tgName);
  if (fn.length < 2) return null;
  // forms from the last 30 min — or ones an agent phoned in the last 48 h (they often message later, from the agent's call)
  const c = all<{ token: string; name: string | null }>("SELECT token, name FROM leads WHERE source='form' AND status='new' AND tg_chat_id IS NULL AND started_at IS NULL AND (created_at>? OR (call_state IS NOT NULL AND call_at>?)) ORDER BY id DESC", now() - 30 * 60000, now() - 48 * 3600000)
    .filter(r => firstName(r.name) === fn);
  return c.length === 1 ? c[0].token : null;
}

async function sendLeadEvent(s: Settings, lead: Lead) {
  await sendCapi(s, {
    line: lead.line, event_id: 'lead_' + lead.id, event_name: 'Lead', lead_id: lead.id, source_url: lead.page_url, once: { leads: samePerson(lead) },
    user_data: buildUserData(lead, s),
    custom_data: { content_name: serviceLabel(lead.service) + (lead.tier === 'premium' ? ' (Premium)' : ''), content_category: lead.niche || undefined },
  });
}

/** The auto first message found the form's phone on Telegram and that person ALREADY chats with us (wrote without the code)
 *  → join the two: the chat becomes the form lead (right business, right owner, Lead event). True when linked. */
export async function linkChatToForm(formId: number, chatId: string) {
  const old = one<Lead>("SELECT * FROM leads WHERE tg_chat_id=? AND id!=? AND status!='merged' ORDER BY id DESC LIMIT 1", chatId, formId);
  const f = leadById(formId);
  if (!old || !f || f.tg_chat_id) return false;
  const s = getSettings();
  run(`UPDATE leads SET tg_chat_id=?, tg_access_hash=COALESCE(tg_access_hash, ?), tg_username=?, tg_name=?, biz_conn=?, started_at=COALESCE(?, ?), last_in_at=?, last_out_at=?, last_at=?, last_text=?, status='active', contact_state='linked' WHERE id=?`,
    chatId, old.tg_access_hash ?? null, old.tg_username, old.tg_name, old.biz_conn, old.started_at, now(), old.last_in_at, old.last_out_at, old.last_at ?? now(), old.last_text, formId);
  const before = old.agent_id;
  mergeOldChat(formId, old.id, old.agent_id);
  let l = leadById(formId)!;
  if (!l.agent_id) {
    const aid = ownerFor(l);
    if (aid) run('UPDATE leads SET agent_id=?, assigned_at=?, tried_agents=NULL, agent_read_at=0 WHERE id=?', aid, now(), formId);
    l = leadById(formId)!;
  } else run('UPDATE leads SET assigned_at=? WHERE id=?', now(), formId); // v166: the reply timer starts now (not at the auto first message)
  const biz = bizOf(l) === 'funnel' ? 'Funnel' : 'Agency';
  addMsg(l, { dir: 'sys', sender: 'system', text: `🔗 This chat is their ${biz} form (same phone number) — joined with it${l.agent_id !== before ? ` → now with ${agentById(l.agent_id)?.name || 'the manager'}` : ''}` });
  if (l.agent_id && l.agent_id !== before) await notifyAgent(agentById(l.agent_id), `🔗 #${l.id} ${displayName(l)} — their ${biz} chat is now yours.\n\n↩️ Reply to this message to answer.`, l.id, { title: `🔗 ${biz} chat for you`, body: displayName(l) });
  await sendLeadEvent(s, l);
  return true;
}

async function handleLeadMessage(s: Settings, m: any, conn: string | null) {
  const chatId = String(m.chat.id);
  const text = msgText(m);
  const [file_type, file_id, file_name] = extractMedia(m);
  const tgName = [m.from?.first_name, m.from?.last_name].filter(Boolean).join(' ');
  const startParam = !conn && text.startsWith('/start') ? text.split(/\s+/)[1] || '' : null;
  let code: string | null = null;
  if (startParam?.startsWith('l_')) code = startParam.slice(2);
  else { const mm = text.match(/\bL-([A-Za-z0-9]{12})\b/); if (mm) code = mm[1]; }
  // No code (they deleted the pre-typed text) and a brand-new chat → the form they just filled, matched by first name
  let byName = false;
  if (!code && !one("SELECT 1 FROM leads WHERE tg_chat_id=? AND status!='merged'", chatId)) {
    const t = formByName(tgName);
    if (t) { code = t; byName = true; }
  }

  let lead: Lead | undefined, fresh = false;
  if (code) {
    const l = one<Lead>('SELECT * FROM leads WHERE token=?', code);
    if (l && (!l.tg_chat_id || l.tg_chat_id === chatId)) {
      lead = l;
      if (!l.tg_chat_id || !l.started_at) {
        fresh = true;
        run("UPDATE leads SET tg_chat_id=?, tg_username=?, tg_name=?, biz_conn=?, started_at=?, last_in_at=?, status='active' WHERE id=?", chatId, m.from?.username || '', tgName, conn, now(), now(), l.id);
        // Same person chatted before without a code → merge into the form lead (it has the browser data for CAPI)
        const old = one<{ id: number; agent_id: number | null }>("SELECT id, agent_id FROM leads WHERE tg_chat_id=? AND id!=? AND status!='merged' ORDER BY id DESC LIMIT 1", chatId, l.id);
        if (old) mergeOldChat(l.id, old.id, old.agent_id);
        if (byName) addMsg(l, { dir: 'sys', sender: 'system', text: `🔗 Wrote without the form code — linked to their ${bizOf(l) === 'funnel' ? 'Funnel' : 'Agency'} form by name (${l.name || ''})` });
      }
    }
  }
  if (!lead) {
    lead = one<Lead>("SELECT * FROM leads WHERE tg_chat_id=? AND status!='merged' ORDER BY id DESC LIMIT 1", chatId);
    // Auto-messaged form lead answering for the first time → this is when the Lead event happens
    if (lead && !lead.started_at) {
      fresh = true;
      run("UPDATE leads SET tg_username=COALESCE(NULLIF(?,''), tg_username), tg_name=COALESCE(NULLIF(?,''), tg_name), biz_conn=COALESCE(?, biz_conn), started_at=?, last_in_at=?, status='active' WHERE id=?",
        m.from?.username || '', tgName, conn, now(), now(), lead.id);
    }
  }
  let chanNew: ChanLine | null = null;
  if (!lead) {
    fresh = true;
    // v116: someone from the channel flow writes to our support account (bot button → pre-typed message) → a channel lead
    // for that service, with their ad click data, routed like any lead (Premium agents / Funnel → manager / round robin)
    // v118: the pre-typed message carries our code ("My code: CP-…") = which service + who → always a tracked channel lead
    const code = conn ? readChanCode(text) : null;
    const cp = conn ? (channelPerson(String(m.from?.id || chatId)) || (code ? channelPerson(code.uid) || { cj: null } : null)) : null;
    if (cp) {
      const came = chanLine(cp.cj?.line_x || cp.cj?.line || 'agency');
      let ln: ChanLine = code?.line || lineFromText(text) || came;
      if (came === 'premium' && ln === 'agency') ln = 'premium'; // v117: from the Premium ad → always Premium, never the cheaper account
      const f = lineFields(ln), cj = cp.cj;
      chanNew = ln;
      const r = one<{ id: number }>(`INSERT INTO leads(token, source, service, line, tier, name, tg_chat_id, tg_username, tg_name, biz_conn, vid, ip, ua, fbc, fbp, fbclid, page_url, created_at, started_at, last_in_at, status)
        VALUES(?, 'channel', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active') RETURNING id`,
        rnd(12), f.service, f.line, f.tier, tgName, chatId, m.from?.username || '', tgName, conn, cj?.vid || null, cj?.ip || null, cj?.ua || null, cj?.fbc || null, cj?.fbp || null,
        cj?.fbc ? cj.fbc.split('.').slice(3).join('.') || null : null, cj?.page_url || null, now(), now(), now())!;
      lead = { id: r.id } as Lead;
    } else {
      // v133: no link and nothing in their message says what they want → they get the 1/2/3/4 menu (their answer sets the chat type)
      const menu = menuOn(s) && !lineFromText(text) ? 1 : null;
      const r = one<{ id: number }>("INSERT INTO leads(token, source, name, tg_chat_id, tg_username, tg_name, biz_conn, menu, created_at, started_at, last_in_at, status) VALUES(?,?,?,?,?,?,?,?,?,?,?,'active') RETURNING id",
        rnd(12), 'telegram', tgName, chatId, m.from?.username || '', tgName, conn, menu, now(), now(), now())!;
      lead = { id: r.id } as Lead;
    }
  } else if (conn && lead.biz_conn !== conn) run('UPDATE leads SET biz_conn=? WHERE id=?', conn, lead.id);
  lead = leadById(lead.id)!;
  // v118: an existing chat taps a service in the bot (message with our code) → the chat becomes that service (not once sold);
  // from the Premium ad never down to the cheaper account
  if (!fresh && conn) {
    const cc = readChanCode(text);
    if (cc && lead.status !== 'sold' && chanOf(lead) !== cc.line && !(chanOf(lead) === 'premium' && cc.line === 'agency')) {
      setLeadType(lead, cc.line, 'customer, bot button');
      lead = leadById(lead.id)!;
    }
  }
  const who = displayName(lead);

  if (fresh) {
    if (!lead.agent_id) {
      // the agent who called them; else Funnel → the manager, everything else round-robin
      const aid = ownerFor(lead);
      if (aid) { run('UPDATE leads SET agent_id=?, assigned_at=? WHERE id=?', aid, now(), lead.id); lead.agent_id = aid; }
    } else { run('UPDATE leads SET assigned_at=? WHERE id=?', now(), lead.id); lead.assigned_at = now(); } // v166: already owned (auto first message) → the reply timer starts at their first message
    // Lead CAPI — only now, when the person has actually messaged on Telegram (form leads, once per lead)
    if (lead.source === 'form') await sendLeadEvent(s, lead);
    // v116: channel person picked a service → Contact (or Lead) for the channel ad sets, now that they really messaged us
    if (chanNew) await sendPickEvent(s, lead, chanNew, String(m.from?.id || chatId));
    const cl = lead as Lead & { call_state?: string | null; call_by?: string | null; call_note?: string | null };
    if (cl.call_state) addMsg(lead, { dir: 'sys', sender: 'system', text: `📞 ${cl.call_by || 'Someone'} called them before (${({ called: 'called', no_answer: 'no answer', interested: 'interested', converted: 'converted', not_interested: 'not interested' } as Record<string, string>)[cl.call_state] || cl.call_state})${cl.call_note ? ` — “${cl.call_note}”` : ''}` });
    if (startParam !== null) addMsg(lead, { dir: 'in', sender: 'lead', text: lead.source === 'channel' ? `▶️ Picked “${CHAN_LABEL[chanOf(lead)]}” in the bot` : '▶️ Started the chat' });
    else addMsg(lead, { dir: 'in', sender: 'lead', text, file_id, file_type, file_name, tg_msg_id: m.message_id, reply_to: replyRef(lead.id, m), dur: mediaDuration(m) });
    const ag = agentById(lead.agent_id);
    const info = [
      `🔔 NEW LEAD #${lead.id}`, `👤 ${who}${lead.tg_username ? ' (@' + lead.tg_username + ')' : ''}`,
      lead.phone ? `📞 ${lead.phone}` : '', lead.email ? `✉️ ${lead.email}` : '',
      lead.source === 'form' ? `🛒 ${serviceLabel(lead.service)}${lead.line === 'funnel' ? ' · from the Funnel page' : ''}` : lead.source === 'channel' ? `📣 From the Telegram channel · ${CHAN_LABEL[chanOf(lead)]} ${lead.biz_conn ? '' : ' (chat is in the bot)'}` : '(messaged directly, no form)',
      lead.tier === 'premium' && bizOf(lead) === 'agency' ? `⭐ PREMIUM — collect $${tierFor(s, 'premium').price_account} per account (top-up fee ${tierFor(s, 'premium').topup_comm_pct}%)` : '',
      leadOffer(s, lead)?.agent || '',
      lead.niche ? `🎯 ${lead.niche}   💵 ${lead.budget || '-'}   BM: ${lead.has_bm || '-'}` : '',
      startParam === null && (text || file_id) ? `\n💬 ${text || '[' + file_type + ']'}` : '', '', '↩️ Reply to this message to answer.',
    ].filter(x => x !== '').join('\n');
    const alert = { info, title: lead.tier === 'premium' ? 'New Premium Telegram lead' : 'New Telegram lead', body: `${who}${lead.niche ? ' · ' + lead.niche : ''}`, admin: `${who} → ${ag ? ag.name : 'unassigned'}` };
    // Welcome first, then the agents get the alert (if a welcome delay is set)
    const wantWelcome = s.welcome_on !== '0' && lead.contact_state !== 'sent';
    const hold = wantWelcome && welcomeHolds(s, lead); // v141: also while the welcome voice is on (held until text + voice)
    if (wantWelcome && queueWelcome(s, lead, hold ? alert : undefined) && hold) return;
    await notifyAgent(ag, info, lead.id, { title: alert.title, body: alert.body, alarm: true });
    void pushTo('admin', null, alert.title, alert.admin, { lead_id: String(lead.id) }, { alarm: true });
    return;
  }
  if (startParam !== null && !text.replace(/^\/start\s*\S*/, '').trim()) return; // repeated /start
  addMsg(lead, { dir: 'in', sender: 'lead', text, file_id, file_type, file_name, tg_msg_id: m.message_id, reply_to: replyRef(lead.id, m), dur: mediaDuration(m) });
  if (lead.menu === 1) lead = await menuPick(s, lead, text); // v133: answered the menu
  if (await holdGate(lead.id)) return; // shown together with the "new lead" alert after the welcome (text + voice) goes out
  lead = coverOnInbound(lead); // v141: the owner is away → a temporary cover answers (the owner stays the owner)
  await relayToAgent(s, handlerOf(lead), lead, `💬 #${lead.id} ${who}:`, text, file_type, file_id);
}

/* ======================= no reply in time → next agent → manager ======================= */
/** Working window "9-22" in local time. Returns the hour range or null (= always working). */
function workRange(s: Settings): [number, number] | null {
  const m = String(s.work_hours || '').match(/^\s*(\d{1,2})\s*-\s*(\d{1,2})\s*$/);
  if (!m) return null;
  const a = +m[1] % 24, b = +m[2] % 24;
  return a === b ? null : [a, b];
}
export function inWork(t: number, s: Settings) {
  const r = workRange(s); if (!r) return true;
  const h = new Date(t + num(s.tz_offset_min, 330) * 60000).getUTCHours();
  return r[0] < r[1] ? h >= r[0] && h < r[1] : h >= r[0] || h < r[1];
}
/** Adds `mins` of WORKING time to t (time outside working hours doesn't count). */
export function addWorkMinutes(t: number, mins: number, s: Settings) {
  if (!workRange(s)) return t + mins * 60000;
  let left = mins * 60000, cur = t, guard = 0;
  while (left > 0 && guard++ < 2000) {
    const step = Math.min(left, 60000 - (cur % 60000) || 60000);
    if (inWork(cur, s)) left -= step;
    cur += step;
  }
  return cur;
}

/** Called every minute by the worker. */
export async function runReassign(at = now()) {
  const s = getSettings();
  await returnCovers(at).catch(e => console.warn('[cover]', (e as Error).message)); // v141: covered chats back to their owner
  if (s.reassign_on !== '1' || !inWork(at, s)) return 0;
  const mins = Math.max(5, num(s.reassign_min, 30));
  // Every chat nobody answered within `mins`: agent → next agent → … → manager → agents again (round and round) until someone replies.
  const rows = all<Lead & { role: string | null }>(`SELECT l.*, a.role FROM leads l JOIN agents a ON a.id=l.agent_id
    WHERE l.status='active' AND l.started_at IS NOT NULL AND l.assigned_at IS NOT NULL
      AND l.last_in_at IS NOT NULL AND MAX(l.assigned_at, l.started_at) < ?
      AND NOT EXISTS (SELECT 1 FROM messages m WHERE m.lead_id=l.id AND m.dir='out' AND m.sender IN ('agent','admin','owner') AND m.created_at>=MAX(l.assigned_at, l.started_at))
      AND NOT ${welcomePendingSql('l')}
    ORDER BY l.assigned_at LIMIT 50`, at - mins * 60000);
  let moved = 0;
  // each business rotates only through its own agents (Agency / Funnel tags)
  for (const l of rows) {
    if (addWorkMinutes(Math.max(l.assigned_at!, l.started_at || 0), mins, s) > at) continue; // v166: timed from their first message too
    const biz = routeOf(l);
    const agentsAll = () => (biz === 'funnel' && !funnelToAgents(s) ? [] : bizAgents(biz, false, (l as Lead & { ch?: string | null }).ch === 'wa' ? 'wa' : 'tg'));
    const order = String(l.tried_agents || '').split(',').filter(Boolean).map(Number);
    const atMgr = l.role === 'manager';
    const mgr = one<{ id: number }>("SELECT id FROM agents WHERE deleted=0 AND role='manager' ORDER BY id LIMIT 1");
    const who = displayName(l);
    // Funnel chats belong to the manager (and when there are no agents at all): stay there, remind again
    if (atMgr && !agentsAll().length) {
      run('UPDATE leads SET assigned_at=? WHERE id=?', at, l.id);
      addMsg(l, { dir: 'sys', sender: 'system', text: `⏱ Still no reply after ${mins} min → reminded the manager again` });
      await notifyAgent(agentById(l.agent_id), `🚨 Still unanswered — #${l.id} ${who}${l.phone ? '\n📞 ' + l.phone : ''}\nNo reply for ${mins} min. Please reply now.\n\n↩️ Reply to this message to answer.`, l.id, { title: '🚨 Still unanswered', body: `${who} — reply now` });
      moved++;
      continue;
    }
    let tried: number[], next: { id: number } | undefined;
    if (atMgr) {
      // the manager didn't answer either → new round with the agents, continuing after the last agent who had it
      tried = [];
      const all1 = agentsAll(); const pool = all1.filter(a => a.online).length ? all1.filter(a => a.online) : all1;
      const lastAgent = [...order].reverse().find(id => id !== l.agent_id) || 0;
      next = pool.find(a => a.id > lastAgent) || pool[0];
    } else {
      tried = order.filter(id => id !== l.agent_id); tried.push(l.agent_id!);
      const cands = agentsAll().filter(a => !tried.includes(a.id));
      const pool = cands.filter(a => a.online).length ? cands.filter(a => a.online) : cands;
      // next agent after the current one (round the circle); after every agent tried → the manager
      next = pool.find(a => a.id > l.agent_id!) || pool[0] || mgr;
      if (!next) { tried = []; const again = agentsAll().filter(a => a.id !== l.agent_id); next = again.find(a => a.id > l.agent_id!) || again[0]; }
    }
    if (!next || next.id === l.agent_id) {
      // nobody else to move to: remind the same person
      run('UPDATE leads SET assigned_at=? WHERE id=?', at, l.id);
      await notifyAgent(agentById(l.agent_id), `⏱ Still unanswered — #${l.id} ${who}. Please reply now.`, l.id, { title: '⏱ Still unanswered', body: `${who} — reply now` });
      continue;
    }
    const from = agentById(l.agent_id), to = agentById(next.id);
    if (atMgr) tried = [l.agent_id!];
    run('UPDATE leads SET agent_id=?, assigned_at=?, tried_agents=?, agent_read_at=0 WHERE id=?', next.id, at, tried.join(','), l.id);
    if (l.ch === 'wa') waSyncSoon(l.id);
    const toMgr = to?.role === 'manager';
    addMsg(l, { dir: 'sys', sender: 'system', text: `⏱ No reply in ${mins} min from ${from?.name || 'agent'} → moved to ${to?.name || 'next agent'}${toMgr ? ' (manager)' : atMgr ? ' (new round)' : ''}` });
    await notifyAgent(to, `${toMgr ? '🚨 No agent replied' : '⏱ Lead moved to you'} — #${l.id} ${who}${l.phone ? '\n📞 ' + l.phone : ''}\nNobody answered for ${mins} min. Please reply now.\n\n↩️ Reply to this message to answer.`, l.id, { title: toMgr ? '🚨 Unanswered lead' : '⏱ Lead moved to you', body: `${who} — reply now`, alarm: true });
    if (from) await notifyAgent(from, `⏱ #${l.id} ${who} was moved to ${to?.name || 'another agent'} because there was no reply in ${mins} min.`, null);
    if (!atMgr) await noteMiss(from?.id, l.id); // v141: a miss in a row (3 → receiving leads OFF)
    moved++;
  }
  moved += await coverNoReply(at, mins, s); // v141: existing customers waiting too long → cover → manager
  return moved;
}

/* ======================= v141: temporary cover (owner away / no reply in time) + auto-off after 3 misses ======================= */
type CovLead = Lead & { cover_agent_id?: number | null; cover_since?: number | null; cover_reason?: string | null; last_cover_id?: number | null; last_cover_from?: number | null; cover_split_used?: number | null };
const DAY = 24 * HOUR;
/** The owner is away = "receiving leads" OFF (by hand or auto-off). The manager is never "away" here (he is the last stop). */
export const ownerOff = (id: number | null | undefined) => !!id && !!one("SELECT 1 FROM agents WHERE id=? AND COALESCE(role,'agent')!='manager' AND (deleted=1 OR receive=0)", id);
const coverUsable = (id: number | null | undefined) => !!id && !!one("SELECT 1 FROM agents WHERE id=? AND deleted=0 AND (receive=1 OR role='manager')", id);
/** An existing customer: someone from the team already answered them (or they bought). New chats use the normal rotation. */
const existingCustomer = (l: { first_reply_at?: number | null; status?: string }) => !!l.first_reply_at || l.status === 'sold';
export function agentLog(agentId: number, kind: string, text: string, leadId: number | null = null) {
  run('INSERT INTO agent_log(agent_id, kind, text, lead_id, at) VALUES(?,?,?,?,?)', agentId, kind, text.slice(0, 300), leadId, now());
}
/** The cover for a chat: the least-loaded agent who is ON (fits the chat's line / channel first), never the excluded ones;
 *  the manager only when no agent is ON. Load = open chats they answer now (own, not covered + covering). */
export function pickCover(l: { ch?: string | null; service?: string | null; line?: string | null; tier?: string | null }, exclude: number[]): number | null {
  const ch = l.ch === 'wa' ? 'wa' : 'tg';
  let pool = bizAgents(routeOf(l), false, ch).map(a => a.id).filter(id => !exclude.includes(id));
  if (!pool.length) pool = all<{ id: number }>(`SELECT id FROM agents WHERE deleted=0 AND receive=1 AND COALESCE(role,'agent')!='manager' AND (',' || COALESCE(chans,'tg') || ',') LIKE ? ORDER BY id`, `%,${ch},%`).map(a => a.id).filter(id => !exclude.includes(id));
  if (!pool.length) { const m = managerId(); return m && !exclude.includes(m) ? m : null; }
  const load = (id: number) => one<{ n: number }>("SELECT COUNT(*) n FROM leads WHERE status IN ('active','sold') AND last_in_at > ? AND (cover_agent_id=? OR (agent_id=? AND cover_agent_id IS NULL))", now() - 7 * DAY, id, id)!.n;
  return pool.map(id => ({ id, n: load(id) })).sort((a, b) => a.n - b.n || a.id - b.id)[0].id;
}
const nameOf = (id: number | null | undefined) => { const a = agentById(id); return a ? a.name + (a.role === 'manager' ? ' (manager)' : '') : 'agent'; };
function setCover(l: CovLead, to: number, reason: 'off' | 'noreply', why: string, at = now()) {
  run('UPDATE leads SET cover_agent_id=?, cover_since=?, cover_reason=?, last_cover_from=CASE WHEN last_cover_id=? AND cover_agent_id IS NOT NULL THEN last_cover_from ELSE ? END, last_cover_id=?, cover_split_used=0 WHERE id=?', to, at, reason, to, at, to, l.id);
  addMsg(l, { dir: 'sys', sender: 'system', text: `🛟 ${nameOf(to)} is covering this chat for ${nameOf(l.agent_id)} (${why}). ${nameOf(l.agent_id)} still owns it.` });
  agentLog(to, 'cover_start', `Covering #${l.id} ${displayName(l)} for ${nameOf(l.agent_id)} (${why})`, l.id);
  if (l.agent_id) agentLog(l.agent_id, 'covered', `#${l.id} ${displayName(l)} covered by ${nameOf(to)} (${why})`, l.id);
  if (l.ch === 'wa') waSyncSoon(l.id);
}
/** The cover ends: the chat answers to its owner again. */
export function coverSummary(l: CovLead) {
  const c = l.cover_agent_id, since = l.cover_since || 0;
  const sent = one<{ n: number }>("SELECT COUNT(*) n FROM messages WHERE lead_id=? AND dir='out' AND sender='agent' AND agent_id=? AND created_at>=? AND deleted_at IS NULL", l.id, c, since)!.n;
  const got = one<{ n: number }>("SELECT COUNT(*) n FROM messages WHERE lead_id=? AND dir='in' AND created_at>=?", l.id, since)!.n;
  const sales = one<{ n: number; v: number }>('SELECT COUNT(*) n, COALESCE(SUM(amount),0) v FROM sales WHERE lead_id=? AND created_at>=?', l.id, since)!;
  const tops = one<{ n: number }>('SELECT COUNT(*) n FROM topups WHERE lead_id=? AND created_at>=?', l.id, since)!.n;
  const links = one<{ n: number }>("SELECT COUNT(*) n FROM pay_links WHERE lead_id=? AND agent_id=? AND created_at>=? AND status IN ('new','pending_payment','partially_paid')", l.id, c, since)!.n;
  const last = one<{ text: string }>("SELECT text FROM messages WHERE lead_id=? AND dir='out' AND sender='agent' AND agent_id=? AND created_at>=? AND deleted_at IS NULL AND COALESCE(text,'')!='' ORDER BY created_at DESC, id DESC LIMIT 1", l.id, c, since)?.text;
  return `${nameOf(c)} sent ${sent} message${sent === 1 ? '' : 's'}, the customer sent ${got}` + (sales.n ? `, ${sales.n} sale${sales.n === 1 ? '' : 's'}` : '') + (tops ? `, ${tops} top-up${tops === 1 ? '' : 's'}` : '') + (links ? `, ${links} unpaid payment link${links === 1 ? '' : 's'}` : '') + (last ? `. Last from ${nameOf(c)}: "${last.slice(0, 120)}"` : '');
}
async function endCover(l: CovLead, why: string, summary = false) {
  const c = l.cover_agent_id;
  const sum = summary && c ? coverSummary(l) : '';
  if (!c || !run('UPDATE leads SET cover_agent_id=NULL, cover_since=NULL, cover_reason=NULL WHERE id=? AND cover_agent_id=?', l.id, c).changes) return false;
  addMsg(l, { dir: 'sys', sender: 'system', text: `↩ Back with ${nameOf(l.agent_id)}: covered by ${nameOf(c)} while you were away (${why}).${sum ? '\nCover summary: ' + sum + '.' : ''}` });
  agentLog(c, 'cover_end', `#${l.id} ${displayName(l)} back with ${nameOf(l.agent_id)} (${why})`, l.id);
  if (l.agent_id) agentLog(l.agent_id, 'cover_back', `#${l.id} ${displayName(l)} back from ${nameOf(c)} (${why})`, l.id);
  if (l.ch === 'wa') waSyncSoon(l.id);
  const fresh = leadById(l.id);
  if (fresh && (fresh.last_in_at || 0) > (fresh.last_out_at || 0)) // the customer is waiting → the owner is told
    await notifyAgent(agentById(l.agent_id), `↩ #${l.id} ${displayName(l)} is back with you (covered by ${nameOf(c)}). They are waiting for a reply.\n\n↩️ Reply to this message to answer.`, l.id, { title: 'Chat back with you', body: displayName(l) });
  return true;
}
/** The agent's last message in the chat that the customer answered (a real conversation), after `since`; 0 = none. */
export const realConvAt = (leadId: number, agentId: number | null | undefined, since = 0) => (agentId ? one<{ v: number | null }>(`SELECT MAX(m.created_at) v FROM messages m WHERE m.lead_id=? AND m.dir='out' AND m.sender='agent' AND m.agent_id=? AND m.created_at>=? AND m.deleted_at IS NULL
  AND EXISTS (SELECT 1 FROM messages i WHERE i.lead_id=m.lead_id AND i.dir='in' AND i.created_at>m.created_at)`, leadId, agentId, since)?.v || 0 : 0);
/** An existing customer of an agent who is away writes → a cover (the same one for the whole away time). The owner never changes. */
export function coverOnInbound(l0: Lead): Lead {
  const l = l0 as CovLead;
  if (!l.agent_id || !existingCustomer(l)) return l0;
  if (l.cover_agent_id && coverUsable(l.cover_agent_id)) {
    // the manager covered because nobody was ON — an agent is ON again → that agent takes over the cover
    if (l.cover_reason === 'off' && agentById(l.cover_agent_id)?.role === 'manager') { const to = pickCover(l, [l.agent_id, l.cover_agent_id]); if (to && agentById(to)?.role !== 'manager') { setCover(l, to, 'off', `${nameOf(l.agent_id)} is away`); return leadById(l.id)!; } }
    return l0;
  }
  if (!ownerOff(l.agent_id) && !l.cover_agent_id) return l0;
  const to = pickCover(l, [l.agent_id, ...(l.cover_agent_id ? [l.cover_agent_id] : [])]);
  if (!to) return l0;
  setCover(l, to, ownerOff(l.agent_id) ? 'off' : (l.cover_reason === 'noreply' ? 'noreply' : 'off'), `${nameOf(l.agent_id)} is away`);
  return leadById(l.id)!;
}
/** Covered chats go back to their owner (worker, every minute; also right when the owner is ON again):
 *  - always at most cover_max_days (7) after the cover started (with a summary of the cover);
 *  - quiet: no customer message for cover_quiet_h hours (72) → back;
 *  - a sale / top-up was made during the cover (the cover got the credit) → back once the owner is ON;
 *  - the owner is ON again and the cover had NO real conversation (cover message + customer reply) → back, unless the cover sent a
 *    payment link that is still unpaid (kept until paid or 24 h);
 *  - a real conversation (a deal in progress) → the cover keeps it. "No reply in time" covers are kept the same way. */
export async function returnCovers(at = now(), ownerId?: number) {
  const s = getSettings();
  const quietMs = Math.max(1, num(s.cover_quiet_h, 72)) * HOUR, maxMs = Math.max(1, num(s.cover_max_days, 7)) * DAY;
  let n = 0;
  for (const l of all<CovLead>(`SELECT * FROM leads WHERE cover_agent_id IS NOT NULL ${ownerId ? 'AND agent_id=' + Number(ownerId) : ''} LIMIT 300`)) {
    const owner = agentById(l.agent_id);
    if (!owner || owner.deleted) continue; // stays with the cover until the admin / manager assigns it
    // hard cap: never longer than cover_max_days (7) — back to the owner with a summary of the cover, even with a deal in progress
    if ((l.cover_since || at) < at - maxMs) { if (await endCover(l, `the cover's ${Math.round(maxMs / DAY)}-day limit was reached`, true)) n++; continue; }
    if (Math.max(l.last_in_at || 0, l.cover_since || 0) < at - quietMs) { if (await endCover(l, `no customer message for ${Math.round(quietMs / HOUR)} h`)) n++; continue; }
    if (ownerOff(owner.id)) continue; // still away
    if (one('SELECT 1 FROM sales WHERE lead_id=? AND created_at>=? UNION ALL SELECT 1 FROM topups WHERE lead_id=? AND created_at>=? LIMIT 1', l.id, l.cover_since || 0, l.id, l.cover_since || 0)) { if (await endCover(l, `${nameOf(l.cover_agent_id)} closed the sale`)) n++; continue; }
    if (l.cover_reason !== 'off') continue;
    if (realConvAt(l.id, l.cover_agent_id, l.cover_since || 0)) continue; // a deal in progress → the cover keeps it
    if (one("SELECT 1 FROM pay_links WHERE lead_id=? AND agent_id=? AND status IN ('new','pending_payment','partially_paid') AND created_at>=? AND created_at>?", l.id, l.cover_agent_id, l.cover_since || 0, at - DAY)) continue;
    if (await endCover(l, `${owner.name} is back`)) n++;
  }
  return n;
}
/** Who gets the credit for a sale / top-up in this chat (v141):
 *  - covered right now → the cover (full credit + commission; a manager cover = the normal manager rule, no commission);
 *  - back with the owner, within cover_credit_days after the cover's last real conversation (cover message + customer reply) →
 *    the sale counts for the OWNER; the FIRST commission-bearing account sale has its commission split 50/50 with the cover (a
 *    manager's half is 0 and stays with us); later sales are 100% the owner's (leads.cover_split_used). Top-ups never split;
 *  - else the one who closed it (`actor`, the normal rules). */
export function saleCredit(lead0: Lead, actor: AgentRow): { agent: AgentRow; split: null | { owner: AgentRow; cover: AgentRow; reason: string } } {
  const l = (leadById(lead0.id) || lead0) as CovLead;
  if (l.cover_agent_id) { const c = agentById(l.cover_agent_id); if (c && !c.deleted) return { agent: c, split: null }; }
  const owner = agentById(l.agent_id), cover = agentById(l.last_cover_id);
  if (owner && cover && !owner.deleted && cover.id !== owner.id && !(l as CovLead & { cover_split_used?: number | null }).cover_split_used) { // only the FIRST commission-bearing account sale after the return
    const s = getSettings();
    const days = Math.max(0, num(s.cover_credit_days, 7));
    const last = realConvAt(l.id, cover.id); // the cover's last real conversation
    if (last && last >= now() - days * DAY) {
      const d = (t: number) => new Date(t + num(s.tz_offset_min, 330) * 60000);
      const M = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      const a = d(l.last_cover_from || last), b = d(last);
      const span = a.getUTCMonth() === b.getUTCMonth() ? (a.getUTCDate() === b.getUTCDate() ? `${M[a.getUTCMonth()]} ${a.getUTCDate()}` : `${M[a.getUTCMonth()]} ${a.getUTCDate()}–${b.getUTCDate()}`) : `${M[a.getUTCMonth()]} ${a.getUTCDate()}–${M[b.getUTCMonth()]} ${b.getUTCDate()}`;
      return { agent: owner, split: { owner, cover, reason: `Split 50/50: ${cover.name} covered this chat (${span})` } };
    }
  }
  return { agent: actor, split: null };
}
/** A chat moved away from this agent by the no-reply rule → one more miss in a row; 3 in a row → receiving leads OFF. */
async function noteMiss(agentId: number | null | undefined, leadId: number) {
  const a = agentById(agentId);
  if (!a || a.deleted || a.role === 'manager') return;
  const n = one<{ n: number }>('UPDATE agents SET miss_n=COALESCE(miss_n,0)+1 WHERE id=? RETURNING miss_n n', a.id)?.n || 0;
  agentLog(a.id, 'miss', `#${leadId}: no reply in time, moved away (${n} in a row)`, leadId);
  if (n >= 3 && a.receive) await autoOff(a);
}
/** v141: 3 misses in a row → "receiving leads" OFF, the admin + manager are told, the agent's waiting customers get a cover. */
export async function autoOff(a: AgentRow) {
  if (!run('UPDATE agents SET receive=0, auto_off_at=?, miss_n=0 WHERE id=? AND receive=1', now(), a.id).changes) return false;
  agentLog(a.id, 'auto_off', 'Missed 3 chats in a row — receiving leads turned off automatically');
  const t = `${a.name} missed 3 chats – receiving leads turned off`;
  void pushTo('admin', null, t, 'They can turn it back on from the banner in their app, or you can in Team → Agents.', {});
  const m = managerId();
  if (m && m !== a.id) await notifyAgent(agentById(m), t, null, { title: t, body: 'Their waiting customers are covered by other agents.' });
  await coverWaiting(a.id);
  return true;
}
/** The agent is away now → their existing customers who are waiting for a reply get a cover right away. */
async function coverWaiting(ownerId: number) {
  for (const l of all<CovLead>(`SELECT * FROM leads WHERE agent_id=? AND cover_agent_id IS NULL AND status IN ('active','sold') AND tg_chat_id IS NOT NULL AND ${waitSql()} AND (first_reply_at IS NOT NULL OR status='sold') LIMIT 200`, ownerId)) {
    const to = pickCover(l, [ownerId]);
    if (!to) continue;
    setCover(l, to, 'off', `${nameOf(ownerId)} is away`);
    const x = leadById(l.id)!;
    await notifyAgent(agentById(to), `🛟 You are covering #${l.id} ${displayName(l)} for ${nameOf(ownerId)} — they are waiting for a reply.\n\n↩️ Reply to this message to answer.`, l.id, { title: msgTitle(x), body: 'Waiting for a reply', alarm: true });
  }
}
/** "Receiving leads" switched (admin, manager, or the agent's own banner tap after an auto-off). */
export async function setReceive(agentId: number, on: boolean, by: string) {
  const a = agentById(agentId);
  if (!a) throw new HttpError(404, 'Agent not found');
  if (on) {
    run('UPDATE agents SET receive=1, auto_off_at=NULL, miss_n=0 WHERE id=?', agentId);
    if (!a.receive) agentLog(agentId, 'receive_on', `Receiving leads turned ON (${by})`);
    await returnCovers(now(), agentId);
  } else {
    run('UPDATE agents SET receive=0, auto_off_at=NULL WHERE id=?', agentId); // by hand = the admin's lock (no banner)
    if (a.receive) agentLog(agentId, 'receive_off', `Receiving leads turned OFF (${by})`);
    if (a.role !== 'manager') await coverWaiting(agentId);
  }
  return { ok: true };
}
/** v166: an agent was deleted → the chats they were covering end that cover; a waiting customer whose owner is away gets a new cover. */
export async function dropAsCover(agentId: number) {
  let n = 0;
  for (const l of all<CovLead>('SELECT * FROM leads WHERE cover_agent_id=? LIMIT 500', agentId)) {
    if (!(await endCover(l, `${nameOf(agentId)} was removed`))) continue;
    n++;
    const x = leadById(l.id) as CovLead | undefined;
    if (!x || !x.agent_id || x.agent_id === agentId || !ownerOff(x.agent_id) || !existingCustomer(x) || (x.last_in_at || 0) <= (x.last_out_at || 0)) continue;
    const to = pickCover(x, [x.agent_id, agentId]);
    if (!to) continue;
    setCover(x, to, 'off', `${nameOf(x.agent_id)} is away`);
    await notifyAgent(agentById(to), `🛟 You are covering #${x.id} ${displayName(x)} for ${nameOf(x.agent_id)} — they are waiting for a reply.\n\n↩️ Reply to this message to answer.`, x.id, { title: msgTitle(leadById(x.id)!), body: 'Waiting for a reply', alarm: true });
  }
  return n;
}
/** Assign by hand (admin / manager): the chat moves for good; any cover ends and the credit window is cleared. */
export function clearCoverForAssign(leadId: number) {
  run('UPDATE leads SET cover_agent_id=NULL, cover_since=NULL, cover_reason=NULL, last_cover_id=NULL WHERE id=?', leadId);
}
/** The no-reply rule for EXISTING customers (working hours only): the one answering (owner, else the cover) did not reply within
 *  reassign_min → the chat goes to a cover (least-loaded agent ON, else the manager); the cover did not either → the manager.
 *  Ownership never changes. Each counts as a miss for the one who did not answer. */
async function coverNoReply(at: number, mins: number, s: Settings) {
  let n = 0;
  const rows = all<CovLead>(`SELECT l.* FROM leads l WHERE l.status IN ('active','sold') AND l.agent_id IS NOT NULL AND l.tg_chat_id IS NOT NULL AND l.started_at IS NOT NULL
      AND l.last_in_at IS NOT NULL AND ${waitSql('l')} AND (l.first_reply_at IS NOT NULL OR l.status='sold') AND l.remind_at IS NULL
      AND EXISTS (SELECT 1 FROM messages m WHERE m.lead_id=l.id AND m.dir='out' AND m.sender IN ('agent','admin','owner') AND m.created_at>=COALESCE(l.assigned_at,0))
      AND NOT ${heldSql('l')} ORDER BY l.last_in_at LIMIT 100`);
  for (const l of rows) {
    const wait = one<{ v: number | null }>("SELECT MIN(created_at) v FROM messages WHERE lead_id=? AND dir='in' AND created_at>?", l.id, l.last_out_at || 0)?.v || l.last_in_at || at;
    const from = Math.max(wait, l.cover_since || 0);
    if (addWorkMinutes(from, mins, s) > at) continue;
    const hid = l.cover_agent_id || l.agent_id!;
    const h = agentById(hid);
    if (!h || h.role === 'manager') continue; // the manager is the last stop
    const mgr = managerId();
    const to = l.cover_agent_id ? (mgr && mgr !== hid ? mgr : null) : pickCover(l, [l.agent_id!]);
    if (!to || to === hid) continue;
    setCover(l, to, ownerOff(l.agent_id) ? 'off' : 'noreply', `no reply from ${h.name} in ${mins} min`, at);
    await noteMiss(hid, l.id);
    const x = leadById(l.id)!;
    await notifyAgent(agentById(to), `⏱ #${l.id} ${displayName(l)} is waiting — no reply from ${h.name} in ${mins} min. You are covering for ${nameOf(l.agent_id)}. Please reply now.\n\n↩️ Reply to this message to answer.`, l.id, { title: msgTitle(x), body: 'No reply in time — please answer', alarm: true });
    n++;
  }
  return n;
}

/** v135: an agent / the manager asks the admin to delete a junk chat (spam, abuse, time-wasters). The admin deletes it from the admin app. */
export async function requestDelete(l: Lead, agent: { id: number; name: string }, reason: unknown) {
  const note = String(reason || '').trim().slice(0, 200);
  if (!note) throw new HttpError(400, 'Write why this chat should be deleted');
  run('UPDATE leads SET del_req_by=?, del_req_at=?, del_req_note=? WHERE id=?', agent.name, now(), note, l.id);
  addMsg(l, { dir: 'sys', sender: 'system', agent_id: agent.id, text: `🗑 ${agent.name} asked the admin to delete this chat: ${note}` });
  void pushTo('admin', null, 'Chat delete request', `${agent.name}: ${displayName(l)} · ${note}`, { lead_id: String(l.id) });
  return { ok: true };
}
export const deleteRequests = () => all<{ id: number; name: string | null; tg_name: string | null; tg_username: string | null; ch: string | null; del_req_by: string; del_req_at: number; del_req_note: string; agent_id: number | null }>(
  'SELECT id, name, tg_name, tg_username, ch, del_req_by, del_req_at, del_req_note, agent_id FROM leads WHERE del_req_at IS NOT NULL ORDER BY del_req_at DESC LIMIT 100')
  .map(l => ({ ...l, who: displayName(l as Partial<Lead>) }));
/** Admin keeps the chat: the request goes away. */
export function keepChat(leadId: number) {
  const l = leadById(leadId);
  if (!l) throw new HttpError(404, 'Chat not found');
  run('UPDATE leads SET del_req_by=NULL, del_req_at=NULL, del_req_note=NULL WHERE id=?', l.id);
  addMsg(l, { dir: 'sys', sender: 'system', text: '↩ Admin kept this chat (delete request declined)' });
  return { ok: true };
}

/** Admin only: delete a chat completely (e.g. test chats). Not allowed when money / accounts are attached to it —
 *  those keep the records (sales, top-ups, ad accounts, payments, tasks); move such a chat to Dead instead. */
export function deleteLead(leadId: number) {
  const l = leadById(leadId);
  if (!l) throw new HttpError(404, 'Chat not found');
  const has = (t: string, w = '') => !!one(`SELECT 1 FROM ${t} WHERE lead_id=?${w} LIMIT 1`, leadId);
  const blocked = [['sales', 'a sale'], ['topups', 'a top-up'], ['lead_accounts', 'an ad account'], ['meta_requests', 'an ad account request'], ['meta_log', 'ad account history'], ['meta_credits', 'a credit'], ['tasks', 'a task'], ['web_orders', 'a website order']]
    .find(([t]) => has(t)) || (has('pay_links', " AND status IN ('paid','pending_payment','partially_paid')") ? ['pay_links', 'a payment'] : null);
  if (blocked) { // v146: records must stay → the chat goes to Dead instead (automatic messages stopped), the delete request is closed
    run("UPDATE leads SET status='dead', dead_reason='deleted', fu_due=0, fu_stage=0, fu_q=NULL, remind_at=NULL, remind_due=0, auto_stop=COALESCE(auto_stop,'Deleted by admin (records kept)'), del_req_by=NULL, del_req_at=NULL, del_req_note=NULL WHERE id=?", l.id);
    addMsg(l, { dir: 'sys', sender: 'system', text: `☠️ Admin deleted this chat — it has ${blocked[1]}, so the records stay and it was moved to Dead instead. Automatic messages are off.` });
    if (l.ch === 'wa') waSyncSoon(l.id);
    return { ok: true, moved: 'dead', why: blocked[1] };
  }
  if (l.ch === 'wa' && !one("SELECT 1 FROM leads WHERE tg_chat_id=? AND id!=? AND status!='merged'", l.tg_chat_id, l.id)) waDeletedSoon(l.tg_chat_id); // v137 (WATI Pro): SOLVED
  for (const t of ['messages', 'relay', 'ub_outbox', 'ai_coach', 'ai_feedback', 'delayed_msgs', 'pay_links']) run(`DELETE FROM ${t} WHERE lead_id=?`, leadId);
  run('DELETE FROM leads WHERE id=?', leadId);
  return { ok: true };
}


/** Owner / manager marks which ad a chat belongs to (came without an ad, or the wrong one).
 *  Agency: line agency, no tier · Premium: line agency + tier premium · Funnel: line funnel.
 *  Changes the badge, prices / texts in the chat and which line its sales count under. */
export function setLeadType(l: Lead, type: string, by: string) {
  const t = type === 'premium' ? 'premium' : type === 'funnel' ? 'funnel' : 'agency';
  const svc = t === 'funnel' ? (l.service === 'chat' ? 'chat' : 'funnel') : (l.service === 'funnel' ? 'account' : l.service);
  run('UPDATE leads SET line=?, tier=?, service=? WHERE id=?', t === 'funnel' ? 'funnel' : 'agency', t === 'premium' ? 'premium' : null, svc, l.id);
  addMsg(l, { dir: 'sys', sender: 'system', text: `🏷 Marked as ${t === 'premium' ? '⭐ Premium' : t === 'funnel' ? 'Funnel' : 'Agency'} chat (by ${by})` });
  if (l.ch === 'wa') waSyncSoon(l.id);
  return { ok: true, type: t };
}


/* ======================= channel ads (v111): the bot's services menu → a lead in the bot chat ======================= */
const chanOf = (l: { service?: string | null; line?: string | null; tier?: string | null }): ChanLine => (bizOf(l) === 'funnel' ? 'funnel' : l.tier === 'premium' ? 'premium' : 'agency');

/** true = handled here. Plain /start (or ch…) with no open chat → the menu. svc_<line>[_<tok>] → a lead for that service
 *  (routed like any lead: round robin / Premium agents / Funnel → manager), or the open chat switched to it. */
async function chanStart(s: Settings, m: any, param: string): Promise<boolean> {
  const chatId = String(m.chat.id);
  const uid = String(m.from?.id || chatId);
  const tgName = [m.from?.first_name, m.from?.last_name].filter(Boolean).join(' ');
  if (param.startsWith('l_')) return false;
  const open = one<Lead>("SELECT * FROM leads WHERE tg_chat_id=? AND status!='merged' ORDER BY id DESC LIMIT 1", chatId);
  const sv = param.match(/^svc_(agency|premium|funnel)(?:_([A-Za-z0-9]{6,16}))?$/);
  if (!sv) {
    if (!(param === '' || param === 'menu' || /^ch(_[a-z]+)?$/.test(param))) return false;
    // already talking IN THE BOT (old flow, no support account) → the normal chat flow; chats with our support account
    // (or anyone else) always get an answer here: the remembered offer / welcome / menu
    if (open && !s.owner_username && !open.biz_conn) return false;
    // v116: came back (blocked the bot before, or opened it again) → show what they came for: their channel-ad page's offer,
    // else the welcome they got on joining, else the plain services menu
    noteBotStart(uid, tgName, param || 'start', latestJoinFor(uid)?.id ?? null);
    // v118: already chatting with our support account → "welcome back" + straight back to that chat (no menu)
    if (open && s.owner_username && await sendOpenChat(s, chatId, uid, tgName)) return true;
    await answerStart(s, chatId, uid);
    return true;
  }
  const ln = chanLine(sv[1]);
  // v116: chats happen with our support account → the button opens it with the message typed (old bot messages still work)
  const sup = supportLink(s, ln, uid);
  if (sup && !open) {
    noteBotStart(uid, tgName, 'svc_' + ln, ((sv[2] ? joinByTok(sv[2]) : undefined) || latestJoinFor(uid))?.id ?? null);
    await tg(s, 'sendMessage', { chat_id: chatId, text: `Tap below to chat with our team about: ${CHAN_LABEL[ln]}.`, reply_markup: { inline_keyboard: [[{ text: '💬 Chat with our team', url: sup }]] } });
    return true;
  }
  // their join (ad click data): from the button's token, else their latest channel-ad join (came back via a channel post)
  const cj = (sv[2] ? joinByTok(sv[2]) : undefined) || latestJoinFor(uid);
  noteBotStart(uid, tgName, 'svc_' + ln, cj?.id ?? null);
  if (open) {
    // picked (another) service in an open chat → switch it (not once sold), tell the agent
    if (chanOf(open) !== ln && open.status !== 'sold') setLeadType(open, ln, 'customer, bot menu');
    const l = coverOnInbound(leadById(open.id)!);
    addMsg(l, { dir: 'in', sender: 'lead', text: `▶️ Picked “${CHAN_LABEL[ln]}” in the bot` });
    await relayToAgent(s, handlerOf(l), l, `💬 #${l.id} ${displayName(l)}:`, `Picked “${CHAN_LABEL[ln]}” in the bot`, null, null);
    return true;
  }
  const f = lineFields(ln);
  const token = rnd(12);
  run(`INSERT INTO leads(token, source, service, line, tier, name, vid, ip, ua, fbc, fbp, fbclid, page_url, created_at, status, last_at, last_text)
       VALUES(?, 'channel', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'new', ?, ?)`,
    token, f.service, f.line, f.tier, tgName || null, cj?.vid || null, cj?.ip || null, cj?.ua || null, cj?.fbc || null, cj?.fbp || null,
    cj?.fbc ? cj.fbc.split('.').slice(3).join('.') || null : null, cj?.page_url || null, now(), now(), `Picked ${CHAN_LABEL[ln]} in the bot`);
  await handleLeadMessage(s, { ...m, text: `/start l_${token}` }, null);
  const nl = one<Lead>('SELECT * FROM leads WHERE token=?', token);
  if (nl) await sendPickEvent(s, nl, ln, uid);
  return true;
}

/** v118: someone who already has a chat with our support account opens the bot → "welcome back" + the direct link to that chat. */
async function sendOpenChat(s: Settings, chatId: string, uid: string, name = '') {
  const u = String(s.owner_username || '').replace(/^@/, '');
  if (!u) return false;
  const first = String(name || '').trim().split(/\s+/)[0] || 'there';
  const text = String(s.chan_back_text || '').replace(/\{name\}/g, first).replace(/\{support\}/g, '@' + u).replace(/\{brand\}/g, s.brand_name || '').trim();
  const base = publicUrl();
  const img = base ? `${base}/chan/welcome.jpg` : '';
  // v118: + our other products, each with its code (tracked); a Premium person never sees the cheaper Agency account
  const markup = { inline_keyboard: [[{ text: '💬 Continue chat with support', url: `https://t.me/${u}` }], ...productButtons(s, uid), ...(base ? [[{ text: '🌐 Visit our website', url: base }]] : [])] };
  let r: { ok?: boolean } = img && text.length <= 1024 ? await tg(s, 'sendPhoto', { chat_id: chatId, photo: img, caption: text, reply_markup: markup }) : { ok: false };
  if (!r.ok) r = await tg(s, 'sendMessage', { chat_id: chatId, text, reply_markup: markup, disable_web_page_preview: true });
  if (r.ok) run('UPDATE bot_subs SET replied_at=? WHERE tg_user=?', now(), uid);
  return !!r.ok;
}

/** v119: pressed Start in the bot but never wrote to our support account → up to 3 reminders from the bot, same gaps as the
 *  normal follow-ups (fu_hours, from the bot's last message), never in quiet hours. Each has the support button (their service +
 *  code) and our other products with codes (a Premium person never sees Agency). Stops the moment they have a chat with support,
 *  if they block the bot, or after the 3rd. A new Start restarts the clock. No Meta events, no payment talk. */
export async function runBotFollowups(at?: number, limit = 300) {
  const s = getSettings();
  const u = String(s.owner_username || '').replace(/^@/, '');
  if (s.bfu_on === '0' || !s.bot_token || !u) return 0;
  const t = at ?? now();
  if (inQuiet(t, s)) return 0;
  const t0 = now();
  const gaps = fuGaps(s);
  const rows = all<{ tg_user: string; name: string | null; replied_at: number; bfu_n: number | null; bfu_at: number | null }>(`SELECT tg_user, name, replied_at, bfu_n, bfu_at FROM bot_subs
    WHERE replied_at > 0 AND COALESCE(bfu_n,0) < 3 AND last_at > ?
      AND tg_user NOT IN (SELECT tg_chat_id FROM leads WHERE tg_chat_id IS NOT NULL AND status!='merged')
      AND tg_user NOT IN (SELECT tg_chat_id FROM agents WHERE tg_chat_id IS NOT NULL)
    ORDER BY replied_at LIMIT ?`, t - 21 * 24 * HOUR, limit);
  let n = 0;
  for (const r of rows) {
    const k = r.bfu_n || 0;
    if (t < Math.max(r.replied_at, r.bfu_at || 0) + gaps[k] * HOUR) continue;
    const back = latestJoinFor(r.tg_user);
    const ln = back ? chanLine(back.line_x || back.line) : null;
    const lineFor: ChanLine | null = ln === 'agency' && isPremiumPerson(r.tg_user) ? 'premium' : ln;
    const first = String(r.name || '').trim().split(/\s+/)[0] || 'there';
    const text = vary(String((s as Record<string, string>)['bfu' + (k + 1)] || ''), Math.random, s.fu_vary !== '0').replace(/\{name\}/g, first).replace(/\{support\}/g, '@' + u)
      .replace(/\{delivery\}/g, (lineFor === 'premium' ? s.premium_delivery : s.delivery_time) || s.delivery_time).replace(/\{brand\}/g, s.brand_name || '').trim();
    if (!text) { run('UPDATE bot_subs SET bfu_n=?, bfu_at=? WHERE tg_user=?', k + 1, t, r.tg_user); continue; }
    const first_btn = { text: '💬 Message our support team', url: lineFor ? supportLink(s, lineFor, r.tg_user) : `https://t.me/${u}` };
    const markup = { inline_keyboard: [[first_btn], ...productButtons(s, r.tg_user)] };
    // v143: the bot's own send queue (gap 3 s, 30 / min by default); a real-time run waits for short gaps, ~45 s per run at most
    const key = `bfu:${r.tg_user}:${k + 1}`;
    if (!(at === undefined ? await paceAskWait('tgb', key, 'botfu', PRIO.botfu, 4000) : paceAsk('tgb', key, 'botfu', PRIO.botfu, t))) {
      if (at === undefined && now() - t0 > 45000) break;
      continue;
    }
    const x = await tg(s, 'sendMessage', { chat_id: r.tg_user, text, reply_markup: markup, disable_web_page_preview: true }).catch(e => ({ ok: false, description: String(e) }));
    if (x.ok) { n++; run('UPDATE bot_subs SET bfu_n=?, bfu_at=? WHERE tg_user=?', k + 1, t, r.tg_user); run('INSERT INTO bot_log(tg_user, kind, at) VALUES(?,?,?)', r.tg_user, 'reminder' + (k + 1), t); }
    else if (/blocked|deactivated|not found/i.test(String(x.description || ''))) run('UPDATE bot_subs SET bfu_n=9, bfu_at=? WHERE tg_user=?', t, r.tg_user);
    else run('UPDATE bot_subs SET bfu_at=? WHERE tg_user=?', t - gaps[k] * HOUR + 3 * HOUR, r.tg_user); // try again in 3h
    await new Promise(res => setTimeout(res, 120));
  }
  return n;
}

/** v116 (worker, once): everyone who pressed Start in the bot and never got an answer → answer them now (slowly, Telegram limits). */
export async function answerMissedStarts(limit = 200) {
  const s = getSettings();
  if (!s.bot_token) return 0;
  const rows = all<{ tg_user: string }>('SELECT tg_user FROM bot_subs WHERE replied_at IS NULL AND tg_user NOT IN (SELECT tg_chat_id FROM agents WHERE tg_chat_id IS NOT NULL AND deleted=0) ORDER BY started_at LIMIT ?', limit);
  let n = 0;
  for (const r of rows) {
    if (s.owner_username && one("SELECT 1 FROM leads WHERE tg_chat_id=? AND status!='merged'", r.tg_user) && await sendOpenChat(s, r.tg_user, r.tg_user).catch(() => false)) { n++; await new Promise(res => setTimeout(res, 150)); continue; }
    const x = await answerStart(s, r.tg_user, r.tg_user).catch(() => null);
    if (x?.ok) n++;
    else if (x && !/blocked|deactivated|not found/i.test(x.error || '')) run('UPDATE bot_subs SET replied_at=-2 WHERE tg_user=?', r.tg_user); // don't retry forever
    await new Promise(res => setTimeout(res, 150));
  }
  return n;
}

/** v118 (worker, once): people who already chatted with our support account and pressed Start in the bot got no answer before
 *  (the old code never even noted their Start). Telegram lets a bot write only to people who started it, so we try every
 *  support-chat client once: the ones who pressed Start get "welcome back" + the link to their chat, the rest are refused by
 *  Telegram and nothing happens to them. */
export async function welcomeBackOnce(limit = 3000) {
  const s = getSettings();
  if (!s.bot_token || !s.owner_username) return { tried: 0, sent: 0 };
  if (one("SELECT 1 FROM settings WHERE k='_welcome_back_v118'")) return { tried: 0, sent: 0 };
  run("INSERT OR IGNORE INTO settings(k, v) VALUES('_welcome_back_v118', '1')");
  const rows = all<{ tg_chat_id: string; name: string | null; tg_name: string | null }>(`SELECT tg_chat_id, MAX(name) name, MAX(tg_name) tg_name FROM leads
    WHERE tg_chat_id IS NOT NULL AND biz_conn IS NOT NULL AND status!='merged'
      AND tg_chat_id NOT IN (SELECT tg_chat_id FROM agents WHERE tg_chat_id IS NOT NULL AND deleted=0)
      AND tg_chat_id NOT IN (SELECT tg_user FROM bot_subs WHERE replied_at > 0)
    GROUP BY tg_chat_id ORDER BY MAX(last_at) DESC LIMIT ?`, limit);
  let sent = 0;
  for (const r of rows) {
    const ok = await sendOpenChat(s, r.tg_chat_id, r.tg_chat_id, (r.name || r.tg_name || '').split(' ')[0]).catch(() => false);
    if (ok) { sent++; run('INSERT OR IGNORE INTO bot_subs(tg_user, name, src, started_at, last_at, replied_at) VALUES(?,?,?,?,?,?)', r.tg_chat_id, r.name || r.tg_name || '', 'back', now(), now(), now()); }
    await new Promise(res => setTimeout(res, 120));
  }
  return { tried: rows.length, sent };
}


/* ======================= v131: WhatsApp chats (WATI) ======================= */
type WaLead = Lead & { voice_off?: number | null; ch?: string | null; wa_ad?: string | null; wa_lead_at?: number | null; auto_stop?: string | null; fu_retry_at?: number | null };
const waDelayMin = (s: Settings) => Math.max(0, num(s.chan_sub_delay_min ?? 60, 60));

/** A message on WhatsApp (webhook). The customer's message → their chat (new chat: routed, welcome, alert);
 *  our own message typed in the WhatsApp Business app on the phone → shown in the chat as ours (the AI keeps quiet). */
/** v133: is this "sent" webhook the copy of a message we already have (sent by us in the last 30 min, not matched yet)?
 *  Text: same words (spaces ignored). Voice / photo / file: the oldest unmatched one of that kind. Marks it as matched. */
function waEchoOf(leadId: number, m: WaIn) {
  const norm = (x: string | null | undefined) => String(x || '').replace(/\s+/g, ' ').trim();
  // v168: 1st — by id. The id WATI gave back when we sent it is on our row (wa_id); the echo carries the WhatsApp id and WATI's id.
  const ids = [...new Set([m.msgId, ...(m.ids || [])].filter(Boolean).map(String))];
  if (ids.length) {
    const q = ids.map(() => '?').join(',');
    const mine = one<{ id: number; wa_id: string | null; wa_id2: string | null; wa_echo: number | null }>(
      `SELECT id, wa_id, wa_id2, wa_echo FROM messages WHERE lead_id=? AND dir='out' AND sender!='owner' AND (wa_id IN (${q}) OR wa_id2 IN (${q})) ORDER BY id LIMIT 1`, leadId, ...ids, ...ids);
    if (mine) {
      const other = ids.find(x => x !== mine.wa_id && x !== mine.wa_id2) || null;
      run('UPDATE messages SET wa_echo=1, wa_id2=COALESCE(wa_id2, ?) WHERE id=?', other, mine.id);
      return true;
    }
  }
  const rows = all<{ id: number; text: string | null; file_type: string | null; file_name: string | null; created_at: number; wa_id: string | null }>(
    "SELECT id, text, file_type, file_name, created_at, wa_id FROM messages WHERE lead_id=? AND dir='out' AND sender!='owner' AND wa_echo IS NULL AND created_at>? ORDER BY id", leadId, now() - 30 * 60000);
  // v168: no id match → by kind within 5 min; an image we sent as a document and WhatsApp's photo of it count as the same kind.
  // Rows still without a WhatsApp id first (a row with an id would have matched above if it were this message).
  const media = m.media ? rows.filter(r => r.file_type && r.created_at > now() - 5 * 60000 && sameMediaKind(r.file_type, r.file_name, m.media!.kind, m.media!.ref)) : [];
  const hit = m.media ? (media.find(r => !r.wa_id) || media[0]) : rows.find(r => !r.file_type && (norm(r.text) === norm(m.text) || (norm(m.text).length >= 8 && norm(r.text).includes(norm(m.text))))); // v137: list / buttons: we keep body + options
  if (!hit) return false;
  run('UPDATE messages SET wa_echo=1, wa_id2=? WHERE id=?', ids.find(x => x !== hit.wa_id) || null, hit.id);
  return true;
}
/** v134: "delivered" / "read" from WhatsApp → the ticks on our message (read also means delivered). */
export function waStatus(ids: string[], st: 'delivered' | 'read' | 'failed') {
  if (!ids.length) return 0;
  const q = ids.map(() => '?').join(',');
  const t = now();
  if (st === 'failed') return run(`UPDATE messages SET wa_failed=1 WHERE dir='out' AND (wa_id IN (${q}) OR wa_id2 IN (${q}))`, ...ids, ...ids).changes;
  if (st === 'read') return run(`UPDATE messages SET read_at=COALESCE(read_at, ?), delivered_at=COALESCE(delivered_at, ?) WHERE dir='out' AND (wa_id IN (${q}) OR wa_id2 IN (${q}))`, t, t, ...ids, ...ids).changes;
  return run(`UPDATE messages SET delivered_at=COALESCE(delivered_at, ?) WHERE dir='out' AND (wa_id IN (${q}) OR wa_id2 IN (${q}))`, t, ...ids, ...ids).changes;
}
/** v166: one WhatsApp message id is handled once (WATI retries a slow webhook) — like tg_seen for Telegram. */
function waClaim(msgId: string | null | undefined) {
  if (!msgId) return true;
  if (Math.random() < 0.01) run('DELETE FROM wa_seen WHERE at<?', now() - 3 * 86400000);
  return run('INSERT OR IGNORE INTO wa_seen(msg_id, at) VALUES(?,?)', String(msgId), now()).changes > 0;
}
export async function handleWaInbound(s: Settings, m: WaIn) {
  if (s.wati_on !== '1') return 'off';
  const chat = 'wa:' + m.wa;
  let lead = one<WaLead>("SELECT * FROM leads WHERE tg_chat_id=? AND status!='merged' ORDER BY id DESC LIMIT 1", chat);
  if (m.owner) {
    // v137: WATI's own automation rule text → a system note, never "Owner (phone)" (and never in the AI's context)
    if (isVendorAuto(m.text)) { if (lead && !one("SELECT 1 FROM messages WHERE lead_id=? AND dir='sys' AND text LIKE 'WATI automation%' AND created_at>?", lead.id, now() - 3600000)) addMsg(lead, { dir: 'sys', sender: 'system', text: 'WATI automation rule message was sent to the customer (not shown). Turn it off in WATI → Automation.' }); return 'vendor'; }
    if (m.text && isOurEcho(m.wa, m.text)) { // the copy of a message we sent from the app / AI
      if (lead) { const id = lead.id; setTimeout(() => { try { waEchoOf(id, m); } catch { /* */ } }, 4000); }
      return 'echo';
    }
    if (!m.text && !m.media) return 'echo';
    if (!lead) return 'owner-nochat';
    // v133: the welcome / follow-ups / AI are sent by the worker (another process) → match the copy against what we saved
    if (waEchoOf(lead.id, m)) return 'echo';
    if (m.msgId && one('SELECT 1 FROM messages WHERE lead_id=? AND (wa_id=? OR wa_id2=?)', lead.id, m.msgId, m.msgId)) return 'dup';
    for (const x of m.ids || []) if (x !== m.msgId && one('SELECT 1 FROM messages WHERE lead_id=? AND (wa_id=? OR wa_id2=?)', lead.id, x, x)) return 'dup'; // v168
    // v166: claimed before the first await (a 2nd delivery while the media downloads).
    // v168: all its ids at once — the phone sync claims the same ones before ITS download (the 2 "Owner (phone)" copies)
    if (!waClaimIds([m.msgId, ...(m.ids || [])])) return 'dup';
    const L0 = lead;
    const saveOwner = async () => {
      const fid = m.media ? await fetchMedia(s, m.media) : null;
      // v134: a photo / voice sent from the phone that could not be downloaded still shows (as a note) instead of disappearing
      addMsg(L0, { dir: 'out', sender: 'owner', text: m.text || (m.media && !fid ? `[${m.media.kind === 'voice' || m.media.kind === 'audio' ? 'voice note' : m.media.kind} sent from the phone — open WhatsApp to see it]` : ''), file_id: fid, file_type: fid && m.media ? m.media.kind : null, wa_id: m.msgId || null });
    };
    // v168: we are sending a file of this kind to this number right now (WATI has not answered yet, so our row is not saved) →
    // this is most likely its echo: wait for our row (max 90 s) instead of saving a 2nd copy as "Owner (phone)".
    if (m.media && waMediaInFlight(m.wa, m.media.kind, m.media.ref)) {
      const t0 = now();
      const tick = () => {
        try {
          if (waEchoOf(L0.id, m)) return;
          if (now() - t0 < 90000 && waMediaInFlight(m.wa, m.media!.kind, m.media!.ref)) { setTimeout(tick, 1000); return; }
          void saveOwner().catch(e => logWati('error', 'owner media: ' + (e as Error).message)); // it really was from the phone
        } catch { /* */ }
      };
      setTimeout(tick, 1000);
      return 'echo-wait';
    }
    await saveOwner();
    return 'owner';
  }
  if (lead && m.msgId && one('SELECT 1 FROM messages WHERE lead_id=? AND wa_id=?', lead.id, m.msgId)) return 'dup'; // webhook sent twice
  if (!waClaim(m.msgId)) return 'dup'; // v166: claimed before any await
  const code = m.text.match(/\bW-([A-Za-z0-9]{8})\b/)?.[1];
  const click = code ? one<{ code: string; line: string; vid: string | null; ip: string | null; ua: string | null; fbc: string | null; fbp: string | null; page_url: string | null; camp: string | null; adset: string | null; ad: string | null; lead_id: number | null }>('SELECT * FROM wa_clicks WHERE code=?', code) : undefined;
  const join = one<{ id: number; line: string; vid: string | null; ip: string | null; ua: string | null; fbc: string | null; fbp: string | null; page_url: string | null; camp: string | null; adset: string | null; ad: string | null; lead_id: number | null; sub_due: number | null }>(
    'SELECT * FROM wa_joins WHERE phone=? AND created_at>? ORDER BY id DESC LIMIT 1', m.wa, now() - 30 * 86400000);
  let fresh = false;
  if (!lead) {
    fresh = true;
    const src = click || join;
    const ln: ChanLine = src?.line ? chanLine(src.line) : lineFromText(m.text) || 'agency';
    const f = lineFields(ln);
    // Click-to-WhatsApp ad (no page in between): WATI tells which ad (source id) — kept as the campaign row
    const ctwa = !src && m.src && (m.src.id || m.src.url) ? m.src : null;
    const camp = src?.camp ?? (ctwa ? 'Click-to-WhatsApp ads' : null), ad = src?.ad ?? (ctwa?.id ? 'Ad ' + ctwa.id : null);
    // v133: no page code / community number and nothing in the message says what they want → the 1/2/3/4 menu
    const menu = !src && menuOn(s) && !lineFromText(m.text) ? 1 : null;
    const r = one<{ id: number }>(`INSERT INTO leads(token, source, ch, service, line, tier, menu, name, phone, tg_chat_id, tg_name, vid, ip, ua, fbc, fbp, fbclid, page_url, wa_ad, camp, adset, ad, created_at, started_at, last_in_at, status)
      VALUES(?, 'whatsapp', 'wa', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active') RETURNING id`,
      rnd(12), f.service, f.line, f.tier, menu, m.name || null, '+' + m.wa, chat, m.name || null, src?.vid || null, src?.ip || null, src?.ua || null, src?.fbc || null, src?.fbp || null,
      src?.fbc ? src.fbc.split('.').slice(3).join('.') || null : null, src?.page_url || ctwa?.url || null, ctwa?.id || null, camp, src?.adset ?? null, ad, now(), now(), now())!;
    lead = leadById(r.id) as WaLead;
  } else if (click && lead.status !== 'sold') {
    const want = chanLine(click.line);
    if (chanOf(lead) !== want && !(chanOf(lead) === 'premium' && want === 'agency')) { setLeadType(lead, want, 'customer, WhatsApp page'); lead = leadById(lead.id) as WaLead; }
  }
  if (click && !click.lead_id) run('UPDATE wa_clicks SET lead_id=? WHERE code=?', lead.id, click.code);
  // community sign-up (number on our page) → Subscribe 1 hour after they start writing to us (if the chat is still alive)
  if (join && !join.sub_due) run('UPDATE wa_joins SET lead_id=?, msg_at=?, sub_due=? WHERE id=?', lead.id, now(), now() + waDelayMin(s) * 60000, join.id);
  const fid = m.media ? await fetchMedia(s, m.media) : null;
  const text = m.text || (m.media && !fid ? `[${m.media.kind}]` : '');
  const who = displayName(lead);
  if (fresh) {
    if (!lead.agent_id) {
      const aid = ownerFor(lead);
      if (aid) { run('UPDATE leads SET agent_id=?, assigned_at=? WHERE id=?', aid, now(), lead.id); lead.agent_id = aid; }
    } else run('UPDATE leads SET assigned_at=? WHERE id=?', now(), lead.id); // v166: the reply timer starts now
    addMsg(lead, { dir: 'in', sender: 'lead', text, file_id: fid, file_type: fid ? m.media!.kind : null, wa_id: m.msgId || null });
    waSyncSoon(lead.id); // v137 (WATI Pro): contact attributes
    const ag = agentById(lead.agent_id);
    const info = [
      `🟢 NEW WHATSAPP LEAD #${lead.id}`, `👤 ${who} · +${m.wa}`,
      click || join ? `🛒 ${CHAN_LABEL[chanOf(lead)]}${join && !click ? ' · from the WhatsApp community' : ''}` : lead.wa_ad ? '📣 From a Click-to-WhatsApp ad' : '(messaged the number directly)',
      lead.tier === 'premium' && bizOf(lead) === 'agency' ? `⭐ PREMIUM — collect $${tierFor(s, 'premium').price_account} per account (top-up fee ${tierFor(s, 'premium').topup_comm_pct}%)` : '',
      text ? `\n💬 ${text}` : '', '', '↩️ Reply to this message to answer (goes to their WhatsApp).',
    ].filter(x => x !== '').join('\n');
    const alert = { info, title: lead.tier === 'premium' ? 'New Premium WhatsApp lead' : 'New WhatsApp lead', body: who, admin: `${who} → ${ag ? ag.name : 'unassigned'}` };
    const wantWelcome = s.welcome_on !== '0';
    const hold = wantWelcome && welcomeHolds(s, lead); // v141: held until the welcome text + voice (Pro: until after the first action)
    if (wantWelcome && queueWelcome(s, lead, hold ? alert : undefined) && hold) return 'new';
    await notifyAgent(ag, info, lead.id, { title: alert.title, body: alert.body, alarm: true });
    void pushTo('admin', null, alert.title, alert.admin, { lead_id: String(lead.id) }, { alarm: true });
    return 'new';
  }
  // v137: replies typed in the WhatsApp Business app since their last message (no webhook for those) → in the chat first,
  // so the order stays right (max once / 30 s per chat, 6 s timeout)
  await waPhoneSync(lead.id, 30000, s);
  addMsg(lead, { dir: 'in', sender: 'lead', text, file_id: fid, file_type: fid ? m.media!.kind : null, wa_id: m.msgId || null });
  const wasMenu = lead.menu === 1;
  if (lead.menu === 1) lead = await menuPick(s, lead, text); // v133: answered the menu
  waSyncSoon(lead.id, { open: true }); // v137 (WATI Pro): customer wrote again → OPEN; attributes
  // v138 (WATI Pro, buttons on): a tapped welcome button → marked as a tap (the AI / coach see "[customer tapped button: …]")
  const inId = one<{ id: number }>("SELECT MAX(id) id FROM messages WHERE lead_id=? AND dir='in'", lead.id)?.id ?? 0;
  const tap = !wasMenu && !fid && waProButtons(s) ? waTapOf(s, lead, text) : null;
  if (tap && inId) run("UPDATE messages SET via='tap' WHERE id=?", inId);
  lead = coverOnInbound(lead) as WaLead; // v141: the owner is away → a temporary cover answers (the owner stays the owner)
  const held0 = alertsHeld(lead.id); // v141: the new chat is still waiting for its welcome → the agent is told at the release
  // v137: "Talk to agent" button (or typed) → the agent is told right away
  if (isTalkToAgent(text) && !wasMenu) {
    addMsg(lead, { dir: 'sys', sender: 'system', text: '🙋 Customer asked to talk to an agent' });
    if (!held0) await notifyAgent(handlerOf(lead), `🙋 #${lead.id} ${who} wants to talk to an agent (WhatsApp).\n\n↩️ Reply to this message to answer.`, lead.id, { title: 'Customer wants an agent', body: who, alarm: true });
  }
  const tapped = tap ? await waTapReply(s, leadById(lead.id) as WaLead, tap, inId) : null;
  // v141 WhatsApp Pro buttons: the customer's first ACTION (an action button / Talk to agent / their own typed message; not See
  // pricing / What's included) → after its auto-reply: the full welcome text (welcome delay), then the welcome voice (voice delay)
  if (!wasMenu && waProButtons(s) && !(tap && isInfoTap(tap.label))) await startDeferredWelcome(s, lead.id);
  await waLeadCheck(s, lead.id);
  if (await holdGate(lead.id)) return 'held';
  const ag = handlerOf(leadById(lead.id) || lead);
  const body = tap ? `${who} tapped ${tap.label}${tapped === 'sent' ? ' · auto-replied' : tapped === 'dup' ? ' · auto-reply already sent' : tapped === 'failed' ? ' · auto-reply NOT sent' : ''}` : text || 'New message';
  if (ag) void pushTo('agent', ag.id, msgTitle(leadById(lead.id) || lead), body, { lead_id: String(lead.id) });
  return tap ? 'tap' : 'msg';
}

/** v138: the automatic reply to a tapped welcome button (WATI Pro + buttons on). Same send path as every WhatsApp message
 *  (logged in the WATI API log, shown in the chat as "Auto-reply"). Once per button per chat in 10 minutes.
 *  The AI does not answer the same tap. Not sent → a note in the chat + the agent is alerted. */
const TAP_GAP = 10 * 60000;
async function waTapReply(s: Settings, lead: WaLead, tap: NonNullable<ReturnType<typeof waTapOf>>, inId: number): Promise<'sent' | 'dup' | 'failed' | 'off'> {
  if (!tap.reply || !lead?.tg_chat_id) return 'off';
  const text = noEmo(btnReplyText(s, lead, tap.reply.text)).slice(0, 4000);
  if (!text) return 'off';
  const t = now(), k = btnKey(tap.label); // v140: the same key with or without the label icon
  // once per button per chat within 10 minutes (atomic: two webhooks at once → one reply)
  if (!run('INSERT INTO btn_taps(lead_id, k, at) VALUES(?,?,?) ON CONFLICT(lead_id, k) DO UPDATE SET at=excluded.at WHERE btn_taps.at < ?', lead.id, k, t, t - TAP_GAP).changes) {
    if (inId) run('UPDATE leads SET ai_done_msg=MAX(COALESCE(ai_done_msg,0), ?) WHERE id=?', inId, lead.id);
    return 'dup';
  }
  if (inId) run('UPDATE leads SET ai_done_msg=MAX(COALESCE(ai_done_msg,0), ?) WHERE id=?', inId, lead.id); // the AI won't answer this tap too
  const fail = async (why: string) => {
    addMsg(lead, { dir: 'sys', sender: 'system', text: `⚠️ Auto-reply to "${tap.label}" not sent (${why.slice(0, 140)}). Please answer the customer.` });
    await releaseHold(lead.id, 'failed'); // v141: the bot could not answer → the agent must see the chat now
    await notifyAgent(handlerOf(lead) || agentById(managerId()), `⚠️ #${lead.id} ${displayName(lead)} tapped "${tap.label}" on WhatsApp, but the auto-reply was not sent (${why.slice(0, 120)}).\nPlease answer them now.\n\n↩️ Reply to this message to answer.`, lead.id, { title: 'Auto-reply not sent', body: `${displayName(lead)} tapped ${tap.label}`, alarm: true }).catch(() => {});
    return 'failed' as const;
  };
  try {
    if (showsAgencyPrice(s, lead, text)) return await fail('the text shows the Agency price in a Premium chat — fix it in Settings → WATI');
    const btns = waCleanButtons(tap.reply.buttons);
    let saved = '';
    if (btns.length && text.length <= 1024) {
      const { waSendButtons: sendB } = await import('./wati');
      // v140: the line's image as the header only when "image on replies" is ON (default OFF: text + buttons)
      const O = await import('./offerimg');
      const image = O.imgOnReplies(s) && O.waBtnImgOn(s) ? O.offerImageUrl(s, O.offerLine(lead)) : '';
      const r = await sendB(s, lead.tg_chat_id, { body: text, buttons: btns, image });
      if (r.ok) saved = buttonsAsText(text, btns);
    }
    if (!saved) {
      const r = await sendText(s, lead.tg_chat_id, lead.biz_conn, text);
      if (!r.ok) return await fail(String(r.description || 'WhatsApp: not sent').replace(/^WA_WINDOW_CLOSED: /, ''));
      saved = text;
    }
    addMsg(lead, { dir: 'out', sender: 'bot', text: saved });
    run("UPDATE messages SET via='btn' WHERE id=(SELECT MAX(id) FROM messages WHERE lead_id=? AND dir='out')", lead.id);
    // optional voice note (the same real OGG/Opus voice as the welcome voice note) — in the background, never blocks the webhook
    if (tap.reply.voice) {
      if (!s.el_key) addMsg(lead, { dir: 'sys', sender: 'system', text: `Voice note for "${tap.label}" skipped: add the ElevenLabs key (Admin → AI → Voice notes).` });
      else if (!lead.voice_off) void import('./ai').then(a => a.sendBtnVoice(s, lead, text, !/\{name\}/.test(tap.reply!.text))).catch(e => addMsg(lead, { dir: 'sys', sender: 'system', text: `⚠️ Voice note for "${tap.label}" not sent: ${(e as Error).message.slice(0, 120)}` }));
    }
    return 'sent';
  } catch (e) { return await fail((e as Error).message); }
}
const noEmo = (t: string) => String(t || '').replace(/(?![\u2190-\u21FF\u23F1])[\p{Extended_Pictographic}\u{1F3FB}-\u{1F3FF}\uFE0F\u200D]/gu, '').replace(/[ \t]{2,}/g, ' ').trim();

/** WhatsApp Lead event: only after a real conversation — the customer answered our messages `wa_lead_turns` times
 *  (customer → us → customer → us → customer = 2). Once per chat, to the WhatsApp pixel. */
export async function waLeadCheck(s: Settings, leadId: number) {
  const l = leadById(leadId) as WaLead | undefined;
  if (!l || l.ch !== 'wa' || l.wa_lead_at) return false;
  const need = Math.max(1, num(s.wa_lead_turns, 2));
  let turns = 0, prev = '';
  for (const x of all<{ dir: string }>("SELECT dir FROM messages WHERE lead_id=? AND dir IN ('in','out') ORDER BY created_at, id", l.id)) { if (x.dir === 'in' && prev === 'out') turns++; prev = x.dir; }
  if (turns < need) return false;
  if (!run('UPDATE leads SET wa_lead_at=? WHERE id=? AND wa_lead_at IS NULL', now(), l.id).changes) return false;
  await sendCapi(s, {
    ch: 'wa', line: l.line, event_id: 'walead_' + l.id, event_name: 'Lead', lead_id: l.id, source_url: l.page_url, once: { leads: samePerson(l) },
    user_data: buildUserData(l, s),
    custom_data: { content_name: serviceLabel(l.service) + (l.tier === 'premium' ? ' (Premium)' : '') + ' · WhatsApp' },
  });
  addMsg(l, { dir: 'sys', sender: 'system', text: '📈 Real conversation on WhatsApp → Lead sent to Meta' });
  return true;
}

/** Worker: community sign-ups whose chat is still alive 1 hour (Settings → Send Subscribe only if they stay) after they wrote → Subscribe. */
export async function waSubscribeDue(s: Settings = getSettings()) {
  if (s.wati_on !== '1') return 0;
  const rows = all<{ id: number; phone: string; line: string; vid: string | null; ip: string | null; ua: string | null; fbc: string | null; fbp: string | null; page_url: string | null; lead_id: number | null; created_at: number }>(
    'SELECT * FROM wa_joins WHERE sub_due IS NOT NULL AND sub_due<=? AND sub_at IS NULL LIMIT 50', now());
  let n = 0;
  for (const j of rows) {
    const l = j.lead_id ? leadById(j.lead_id) as WaLead | undefined : undefined;
    if (!l || l.status === 'dead' || l.auto_stop) { run("UPDATE wa_joins SET sub_at=?, sub_state='not_alive' WHERE id=?", now(), j.id); continue; }
    run("UPDATE wa_joins SET sub_at=?, sub_state='sent' WHERE id=?", now(), j.id);
    await sendCapi(s, {
      ch: 'wa', line: j.line === 'funnel' ? 'funnel' : 'agency', event_id: 'wasub_' + j.phone, event_name: 'Subscribe', lead_id: l.id, source_url: j.page_url,
      user_data: buildUserData({ ...l, phone: '+' + j.phone, ip: j.ip || l.ip, ua: j.ua || l.ua, fbc: j.fbc || l.fbc, fbp: j.fbp || l.fbp, vid: j.vid || l.vid, created_at: j.created_at }, s),
      custom_data: { content_name: 'WhatsApp community' },
    });
    addMsg(l, { dir: 'sys', sender: 'system', text: '👥 Joined from the WhatsApp community page and still chatting → Subscribe sent to Meta' });
    n++;
  }
  return n;
}

/** WhatsApp follow-ups, all inside the 24-hour window: +6 h and +12 h after our message (Settings), and a last one
 *  15 min before the window closes. No quiet hours (the window would close). Returns the chats made due. */
async function waFollowupsDue(t: number, s: Settings) {
  if (s.wati_on !== '1' || s.wa_fu_on === '0') return [];
  const g = String(s.wa_fu_hours || '6,12').split(/[,\s]+/).map(Number).filter(x => x > 0);
  const h1 = (g[0] || 6) * HOUR, h2 = (g[1] || 12) * HOUR, lastMs = Math.max(1, num(s.wa_fu_last_min, 15)) * 60000;
  const rows = all<{ id: number; agent_id: number | null; name: string | null; tg_name: string | null; fu_stage: number; last_in_at: number | null }>(
    `SELECT id, agent_id, name, tg_name, fu_stage, last_in_at, released_at FROM leads WHERE ch='wa' AND status='active' AND tg_chat_id IS NOT NULL AND remind_at IS NULL AND COALESCE(remind_due,0)=0 AND hold_alert IS NULL
       AND last_out_at IS NOT NULL AND last_out_at > COALESCE(last_in_at,0) AND fu_due=0 AND fu_stage<3 AND auto_stop IS NULL AND COALESCE(fu_retry_at,0)<=?`, t);
  const out: { id: number; agent_id: number | null; name: string | null; tg_name: string | null; fu_stage: number }[] = [];
  for (const r of rows) {
    if (!windowLeft(r.last_in_at, t)) continue; // window closed → only the phone app can write now
    const finalAt = (r.last_in_at || 0) + 24 * HOUR - lastMs;
    // the clock starts at our first message after their last one (the welcome doesn't count, same as Telegram)
    const anchor0 = one<{ v: number | null }>("SELECT MIN(created_at) v FROM messages WHERE lead_id=? AND dir='out' AND sender!='bot' AND created_at>?", r.id, r.last_in_at || 0)?.v;
    if (!anchor0) continue;
    const anchor = Math.max(anchor0, (r as { released_at?: number | null }).released_at || 0); // v141: never before the release
    let next = 0;
    if (t >= finalAt) next = 3;
    else if (r.fu_stage === 0 && t >= anchor + h1) next = 1;
    else if (r.fu_stage === 1 && t >= anchor + h2) next = 2;
    if (!next) continue;
    if (run('UPDATE leads SET fu_stage=?, fu_ever=MAX(COALESCE(fu_ever,0), ?), fu_due=1 WHERE id=? AND fu_due=0 AND fu_stage<?', next, next, r.id, next).changes) out.push({ ...r, fu_stage: next });
  }
  return out;
}

/** v147: admin → "No reply needed" on one or many chats: they leave Needs reply until the customer writes again. Nothing is sent. */
export function markNoReply(ids: number[], by = 'Admin') {
  let n = 0;
  for (const id of ids.slice(0, 500)) {
    const l = leadById(id); if (!l) continue;
    addMsg(l, { dir: 'sys', sender: 'system', text: `${by} marked this chat: no reply needed. It comes back to Needs reply when the customer writes again.` });
    run("UPDATE leads SET noreply_at=?, noreply_by=? WHERE id=?", Math.max(now(), l.last_in_at || 0), by, l.id);
    n++;
  }
  return { ok: true, n };
}
