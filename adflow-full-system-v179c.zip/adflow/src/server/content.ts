import { getSettings, fmt, lines, usesUploadedLogo, DEFAULTS, tierFor, offerOf, applyOffer, type Settings } from './settings';
import { kitVersion } from './brandkit';
import { viewerBase } from './viewers';

export type Offer = { badge: string; title: string; sub: string; price: string; unit: string; bullets: string[]; cta: string };
export type LandingContent = {
  mode: 'agency' | 'funnel'; tier: '' | 'premium'; premiumOn: boolean; deal: { text: string; kind: 'agency' | 'premium' | 'funnel' } | null; theme: string; brand: string; badge: string; headline: string; accent: string; sub: string; payment: string; delivery: string; deliveryShort: string;
  priceAccount: string; priceTg: string; priceFunnel: string; account: Offer; funnel: Offer;
  chatTitle: string; chatText: string; agentName: string; whyTitle: string; faq: [string, string][];
  ctaTitle: string; ctaText: string; footer: string; channel: string; tgNote: string; tgNoteSub: string; tgSteps: string[]; logo: string; partner: string; verified: boolean; topupFee: string; proofText: string; proofLink: string; chanBar: { text: string; cta: string; href: string } | null; autoMsg: boolean; webOn: boolean; priceWeb: string; webFunnelOn: boolean; priceFunnelWeb: string; chatOn: boolean; chatBtnText: string; recentOn: boolean; fallback: { on: boolean; web: boolean; sec: number; text: string; priceFunnel: string; wa: { link: string; text: string; members: string; agent: string } | null }; wa: { link: string; fab: boolean } | null; vcDelay: number; viewerFloor: number;
};

/** "1 hour" → "1h", "24 hours" → "24h", "30 minutes" → "30m" */
export function shortDelivery(d: string) {
  const m = String(d).trim().match(/^(\d+)\s*(h|hr|hrs|hour|hours|m|min|mins|minute|minutes|d|day|days)\b/i);
  if (!m) return d;
  const u = m[2][0].toLowerCase();
  return m[1] + (u === 'h' ? 'h' : u === 'm' ? 'min' : 'd');
}

/** Channel top bar: on, and a channel set (link or @username/id). The link goes through /j (tracked join link → Subscribe). */
function chanBar(s: Settings, F: boolean) {
  if (s.chan_bar_on !== '1' || !(s.channel_link || s.channel_chat)) return null;
  const name = (s.channel_name || s.brand_name || '').trim();
  const text = fmt((F && s.f_chan_bar_text.trim() ? s.f_chan_bar_text : s.chan_bar_text) || '', s, { channel_name: name });
  return { text, cta: s.chan_bar_cta || 'Join', href: `/j?line=${F ? 'funnel' : 'agency'}` };
}

/** wa.me link for the agent's WhatsApp number (any format: +1 (646) 270-7080, 91 98…) */
export function waAgentLink(s: Settings) {
  const d = String(s.wa_agent_number || '').replace(/\D/g, '');
  if (s.wa_on !== '1' || s.wa_agent_on !== '1' || d.length < 8) return '';
  return `https://wa.me/${d}${s.wa_agent_text.trim() ? '?text=' + encodeURIComponent(s.wa_agent_text.trim()) : ''}`;
}

/** "Telegram didn't open?" box: website order (Agency page, website orders on) and/or WhatsApp. */
function fallbackOf(s: Settings, F: boolean, f: (t: string) => string) {
  const web = !F && s.web_orders_on === '1' && s.tg_fallback_on === '1';
  const wa = s.wa_on === '1' && s.wa_fallback_on === '1' && s.wa_comm_link.trim()
    ? { link: s.wa_comm_link.trim(), text: f(s.wa_fallback_text), members: s.wa_members.trim(), agent: waAgentLink(s) } : null;
  const sec = wa ? Math.min(120, Math.max(3, Number(s.wa_fallback_sec) || 4)) : Math.min(120, Math.max(5, Number(s.tg_fallback_sec) || 20));
  return { on: web || !!wa, web, sec, text: web ? (f(s.tg_fallback_text) || 'Looks like Telegram didn’t open. You can place your order directly on our website.') : '', priceFunnel: s.price_funnel_web || s.price_funnel, wa };
}

/** mode 'funnel' = the Funnel page (/funnel): funnel first, ad accounts second, its own texts, Telegram only. */
export function landingContent(theme: string, s0: Settings = getSettings(), mode: 'agency' | 'funnel' = 'agency', tierIn: '' | 'premium' = '', rt = false): LandingContent {
  const F = mode === 'funnel';
  // /premium: the same page with the Premium prices, delivery and offer
  const P = !F && tierIn === 'premium' && s0.premium_on === '1';
  // came from a retargeting ad (?rt=1, or earlier this week): this week's offer banner + offer price
  const o = rt ? offerOf(s0, F ? 'funnel' : P ? 'premium' : 'agency') : null;
  const s = applyOffer(P ? tierFor(s0, 'premium') : s0, o);
    const tg = Number(s.price_account) || 0, web = Number(s.price_account_web) || 0;
  // Both pages show the LOWEST ad account price (the website price, e.g. $20) in their text; the Telegram price
  // is shown only where the person picks "Order on Telegram" (priceTg).
  const low = s.web_orders_on === '1' && web > 0 && (!tg || web < tg) ? String(web) : s.price_account;
  const f = (t: string) => fmt(t, s, { price_account: low });
  return {
    mode, deal: o ? { text: o.text, kind: o.route } : null, tier: P ? 'premium' : '', premiumOn: s0.premium_on === '1', theme, brand: s.brand_name, badge: f(P ? s.premium_badge : F ? s.f_badge : s.stock_badge), headline: f(P ? s.premium_headline : F ? s.f_headline : s.headline), accent: f(P ? s.premium_accent : F ? s.f_accent : s.headline_accent), sub: f(P ? s.premium_text : F ? s.f_sub : s.subheadline),
    payment: f(s.payment_text), delivery: s.delivery_time, deliveryShort: shortDelivery(s.delivery_time),
    priceAccount: low, priceTg: s.price_account, priceFunnel: s.price_funnel,
    account: P
      ? { badge: f(s.premium_badge), title: f(s.premium_title), sub: f(s.premium_sub), price: low, unit: 'per account', bullets: lines(f(s.premium_bullets)), cta: f(s.account_cta) }
      : { badge: f(s.account_badge), title: f(s.account_title), sub: f(s.account_sub), price: low, unit: 'per account', bullets: lines(f(s.account_bullets)), cta: f(s.account_cta) },
    funnel: { badge: f(s.funnel_badge), title: f(s.funnel_title), sub: f(s.funnel_sub), price: s.price_funnel, unit: 'per month', bullets: lines(f(s.funnel_bullets)), cta: f(s.funnel_cta) },
    chatTitle: f(s.chat_title), chatText: f(s.chat_text), agentName: s.demo_agent_name || 'Your agent', whyTitle: f(F ? s.f_why_title : s.why_title),
    faq: lines(f(F ? s.f_faq : s.faq)).filter(l => !/ad policies still apply/i.test(l)).map(l => { const i = l.indexOf('|'); return (i > 0 ? [l.slice(0, i).trim(), l.slice(i + 1).trim()] : [l, '']) as [string, string]; }).filter(x => x[0]),
    ctaTitle: f(F ? s.f_cta_title : s.cta_title), ctaText: f(F ? s.f_cta_text : s.cta_text), footer: s.partner_on === '1' && /not\s+affiliated/i.test(s.footer_note) ? f(DEFAULTS.footer_note) : f(s.footer_note), channel: s.channel_link,
    tgNote: f(s.tg_note), tgNoteSub: f(s.tg_note_sub), tgSteps: lines(f(s.tg_steps)),
    logo: usesUploadedLogo(s) ? `/api/logo?v=${s.logo_ver}` : `/brand/logo.png?size=96&theme=${theme}&v=${kitVersion(s)}`, verified: s.brand_verified === '1', topupFee: String(Number(s.topup_comm_pct) || 0), partner: s.partner_on === '1' ? (s.partner_text || '').trim() : '', proofText: f(s.proof_text), proofLink: s.proof_link || s.channel_link, chanBar: chanBar(s, F), autoMsg: s.auto_msg_on === '1' && !!s.ub_session, webOn: !F && s.web_orders_on === '1', priceWeb: s.price_account_web, webFunnelOn: F && s.web_orders_on === '1', priceFunnelWeb: s.price_funnel_web || s.price_funnel, chatOn: s.chat_btn_on === '1', chatBtnText: s.chat_btn_text || 'Chat with agent', recentOn: s.recent_on === '1',
    fallback: fallbackOf(s, F, f),
    wa: s.wa_on === '1' && s.wa_comm_link.trim() ? { link: s.wa_comm_link.trim(), fab: s.wa_fab_on === '1' } : null,
    vcDelay: Math.min(60, Math.max(0, Number(s.vc_delay_sec) || 0)),
    viewerFloor: viewerBase(s), // starting number shown before the first update (0 = badge off)
  };
}

export function seo(s: Settings = getSettings()) {
  return { title: fmt(s.seo_title, s), description: fmt(s.seo_description, s), ...(usesUploadedLogo(s) ? { icons: { icon: `/api/logo?v=${s.logo_ver}`, apple: `/api/logo?v=${s.logo_ver}` } } : {}) };
}
