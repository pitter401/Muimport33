/**
 * Website orders (master switch: Settings → web_orders_on)
 *  - Customers log in with an email code (Resend)
 *  - Ad account / funnel orders, paid by crypto (NOWPayments) or INR (manual, optional UPI QR)
 *  - Paid orders + top-ups become Manager tasks; manager delivers → email + Telegram + Meta Purchase
 *  - Agents can also forward Telegram chats to the manager (BM ID, top-up, funnel...)
 */
import crypto from 'crypto';
import { one, all, run, tx } from './db';
import { getSettings, tierFor, offerOf, applyOffer, offerUntil, type Settings } from './settings';
import { now, HOUR, num, money, HttpError, cleanPhone } from './util';
import { sendEmail, emailHtml, publicUrl } from './email';
import { npCreatePayment, npPaymentStatus, enabledCoins, NP_PAID, coinName, coinNetwork, coinTicker } from './nowpay';
import { sendCapi, buildUserData, samePerson } from './capi';
import { pushTo } from './push';
import { tellClient } from './clientmsg';
import { addMsg, agentById, notifyAgent, displayName, leadById, type Lead } from './crm';
import { joinByTok } from './chanads';

export type { Customer } from './auth';
import type { Customer } from './auth';
export type Order = {
  id: number; code: string; customer_id: number; kind: 'account' | 'funnel'; full?: number | null; qty: number; bm_id: string | null; unit_price: number; amount: number;
  status: string; pay_method: string | null; np_invoice_id: string | null; np_payment_id: string | null; np_status: string | null; pay_currency: string | null;
  inr_amount: number | null; utr: string | null; paid_at: number | null; delivered_at: number | null; accounts: string | null; note: string | null;
  ip: string | null; ua: string | null; fbc: string | null; fbp: string | null; page_url: string | null; created_at: number; name?: string | null; phone?: string | null;
  pay_address?: string | null; pay_amount?: number | null; pay_extra?: string | null; np_expires?: number | null; np_checked?: number | null;
};
export type Topup = {
  id: number; code: string; customer_id: number; account_id: number; act_id: string; amount: number; fee: number; total: number; status: string; pay_method: string | null;
  np_invoice_id: string | null; np_payment_id: string | null; np_status: string | null; pay_currency: string | null; inr_amount: number | null; utr: string | null;
  pay_address?: string | null; pay_amount?: number | null; pay_extra?: string | null; np_expires?: number | null; np_checked?: number | null;
  paid_at: number | null; done_at: number | null; note: string | null; created_at: number;
};
export type Task = {
  id: number; kind: string; source: string; lead_id: number | null; order_id: number | null; topup_id: number | null; agent_id: number | null;
  bm_id: string | null; act_id: string | null; qty: number | null; amount: number | null; note: string | null; status: string; result: string | null;
  created_at: number; done_at: number | null; done_by: string | null;
};

/* Status flow (orders & top-ups):
 *   new → pending_payment (crypto invoice made) → paid → delivered/done
 *   new → awaiting_inr (INR chosen) → inr_review (customer sent UTR) → paid (manager confirms) → delivered/done
 *   any unpaid → cancelled
 */
export const webOn = (s: Settings = getSettings()) => s.web_orders_on === '1';
const needWeb = () => { if (!webOn()) throw new HttpError(404, 'Website orders are switched off'); };
const code = (p: string) => p + '-' + crypto.randomBytes(4).toString('hex').toUpperCase().slice(0, 6);
const usd = (n: number) => '$' + money(n).toFixed(2).replace(/\.00$/, '');
const cleanAct = (v: string) => v.trim().replace(/^act_/i, '').replace(/\D/g, '');
export const managers = () => all<{ id: number; name: string; tg_chat_id: string | null }>("SELECT id, name, tg_chat_id FROM agents WHERE deleted=0 AND role='manager' ORDER BY id");
export const managerLink = (s: Settings = getSettings()) => {
  const m = s.manager_tg.trim();
  if (!m) return s.owner_username ? `https://t.me/${s.owner_username}` : '';
  return /^https?:\/\//.test(m) ? m : `https://t.me/${m.replace(/^@/, '')}`;
};

/* ======================= login by email code ======================= */
const otpHash = (email: string, c: string) => crypto.createHmac('sha256', process.env.APP_SECRET || 'x').update(email + '|' + c).digest('hex');
const ipHits = new Map<string, number[]>();
export const normEmail = (e: unknown) => String(e || '').trim().toLowerCase().slice(0, 160);
export const validEmail = (e: string) => /^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(e);

export async function sendOtp(emailIn: unknown, ip: string) {
  needWeb();
  const email = normEmail(emailIn);
  if (!validEmail(email)) throw new HttpError(400, 'Enter a valid email address');
  const t = now();
  const hits = (ipHits.get(ip) || []).filter(x => x > t - HOUR); hits.push(t); ipHits.set(ip, hits);
  if (hits.length > 12) throw new HttpError(429, 'Too many attempts. Try again in an hour.');
  const row = one<{ sent_at: number; sends: number; window_start: number }>('SELECT sent_at, sends, window_start FROM otp_codes WHERE email=?', email);
  if (row && t - row.sent_at < 45000) throw new HttpError(429, 'Please wait a few seconds before asking for a new code');
  const fresh = !row || t - (row.window_start || 0) > HOUR;
  if (!fresh && row && row.sends >= 5) throw new HttpError(429, 'Too many codes for this email. Try again in an hour.');
  const c = String(crypto.randomInt(0, 1000000)).padStart(6, '0');
  const s = getSettings();
  const r = await sendEmail(email, `${c} is your ${s.brand_name} login code`, emailHtml(s, {
    title: 'Your login code', lines: ['Enter this code on the website to continue. It expires in 10 minutes.', 'If you didn’t ask for it, you can ignore this email.'], code: c,
  }));
  if (!r.ok) throw new HttpError(503, 'Could not send the email right now. Please try again or order on Telegram.');
  run(`INSERT INTO otp_codes(email, code_hash, expires, tries, sent_at, sends, window_start) VALUES(?,?,?,0,?,1,?)
       ON CONFLICT(email) DO UPDATE SET code_hash=excluded.code_hash, expires=excluded.expires, tries=0, sent_at=excluded.sent_at,
       sends=CASE WHEN ? THEN 1 ELSE otp_codes.sends+1 END, window_start=CASE WHEN ? THEN excluded.window_start ELSE otp_codes.window_start END`,
    email, otpHash(email, c), t + 10 * 60000, t, t, fresh ? 1 : 0, fresh ? 1 : 0);
  return { ok: true };
}

export function verifyOtp(emailIn: unknown, codeIn: unknown): Customer {
  needWeb();
  const email = normEmail(emailIn);
  const c = String(codeIn || '').replace(/\D/g, '');
  const row = one<{ code_hash: string; expires: number; tries: number }>('SELECT code_hash, expires, tries FROM otp_codes WHERE email=?', email);
  if (!row || row.expires < now()) throw new HttpError(400, 'The code expired. Ask for a new one.');
  if (row.tries >= 5) throw new HttpError(429, 'Too many wrong tries. Ask for a new code.');
  const good = otpHash(email, c);
  if (c.length !== 6 || !crypto.timingSafeEqual(Buffer.from(good), Buffer.from(row.code_hash))) {
    run('UPDATE otp_codes SET tries=tries+1 WHERE email=?', email);
    throw new HttpError(400, 'Wrong code. Check the email and try again.');
  }
  run('DELETE FROM otp_codes WHERE email=?', email);
  let cust = one<Customer>('SELECT * FROM customers WHERE email=?', email);
  if (!cust) { run('INSERT INTO customers(email, created_at, last_login) VALUES(?,?,?)', email, now(), now()); cust = one<Customer>('SELECT * FROM customers WHERE email=?', email)!; }
  else run('UPDATE customers SET last_login=? WHERE id=?', now(), cust.id);
  return cust;
}

/* ======================= tasks (manager inbox) ======================= */
export async function createTask(t: Partial<Task> & { kind: string; source: string }) {
  const r = run(`INSERT INTO tasks(kind, source, lead_id, order_id, topup_id, agent_id, bm_id, act_id, qty, amount, note, status, created_at)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,'open',?)`, t.kind, t.source, t.lead_id ?? null, t.order_id ?? null, t.topup_id ?? null, t.agent_id ?? null,
    t.bm_id ?? null, t.act_id ?? null, t.qty ?? null, t.amount ?? null, t.note ?? null, now());
  const id = Number(r.lastInsertRowid);
  await notifyManagers(id);
  return id;
}
export function taskTitle(t: Task) {
  const k: Record<string, string> = { sale_check: 'Check sale type', account: 'New ad account', topup: 'Top-up', funnel: 'Funnel setup', other: 'Request', web_order: 'Website order', web_topup: 'Website top-up' };
  return k[t.kind] || t.kind;
}
async function notifyManagers(taskId: number) {
  const t = one<Task>('SELECT * FROM tasks WHERE id=?', taskId)!;
  const d = taskDetail(t);
  const body = [d.summary, d.who].filter(Boolean).join(' · ');
  for (const m of managers()) await notifyAgent({ ...agentById(m.id)! }, `📥 ${taskTitle(t)} #${t.id}\n${body}\n\nOpen the app → Tasks.`, null, { title: `📥 ${taskTitle(t)}`, body });
  void pushTo('admin', null, `📥 ${taskTitle(t)}`, body, { task_id: String(t.id) });
}
export function taskDetail(t: Task) {
  const o = t.order_id ? one<Order>('SELECT * FROM web_orders WHERE id=?', t.order_id) : undefined;
  const tp = t.topup_id ? one<Topup>('SELECT * FROM web_topups WHERE id=?', t.topup_id) : undefined;
  const cust = (o || tp) ? one<Customer>('SELECT * FROM customers WHERE id=?', (o || tp)!.customer_id) : undefined;
  const lead = t.lead_id ? leadById(t.lead_id) : undefined;
  const ag = t.agent_id ? agentById(t.agent_id) : undefined;
  let summary = '';
  if (o) summary = o.kind === 'funnel' ? `Funnel setup · ${usd(o.amount)}` : `${o.full ? '🔑 FULL ACCESS · ' : ''}${o.qty} ad account${o.qty > 1 ? 's' : ''} · BM ${o.bm_id} · ${usd(o.amount)}`;
  else if (tp) summary = `Top-up ${usd(tp.amount)} → act_${tp.act_id} (paid ${usd(tp.total)})`;
  else if (t.kind === 'account') summary = `${t.qty || 1} ad account${(t.qty || 1) > 1 ? 's' : ''} · BM ${t.bm_id || '-'}`;
  else if (t.kind === 'topup') summary = `Top-up ${usd(t.amount || 0)} → act_${t.act_id || '-'}`;
  else summary = t.note || '';
  const who = cust ? `${o?.name || cust.name || cust.email} (${cust.email})` : lead ? `${displayName(lead)}${ag ? ' · via ' + ag.name : ''}` : '';
  const pay = o || tp ? { method: (o || tp)!.pay_method, status: (o || tp)!.status, inr: (o || tp)!.inr_amount, utr: (o || tp)!.utr, currency: (o || tp)!.pay_currency } : null;
  return { summary, who, order: o, topup: tp, customer: cust ? { id: cust.id, email: cust.email, name: o?.name || cust.name, phone: o?.phone || cust.phone } : null, lead: lead ? { id: lead.id, name: displayName(lead), phone: lead.phone } : null, agent: ag ? ag.name : null, pay };
}
/** review166: open → working (done_at = when it was claimed). A claim older than 5 minutes (the server restarted mid-way) can be taken again,
 *  so a task is never stuck as "working" for good. */
const claimTask = (id: number) => run("UPDATE tasks SET status='working', done_at=? WHERE id=? AND (status='open' OR (status='working' AND COALESCE(done_at,0)<?))", now(), id, now() - 5 * 60000).changes > 0;
export function listTasks(status: 'open' | 'done' | 'all' = 'open', limit = 200) {
  // v166: a task being finished right now ('working') still shows as open
  const rows = all<Task>(`SELECT * FROM tasks ${status === 'all' ? '' : status === 'open' ? "WHERE status IN ('open','working')" : 'WHERE status=?'} ORDER BY id DESC LIMIT ?`, ...(status === 'all' || status === 'open' ? [limit] : [status, limit]));
  return rows.map(t => ({ ...t, title: taskTitle(t), ...taskDetail(t) }));
}

/* ======================= a Telegram client's ad accounts ======================= */
/** Save ad account IDs for a chat (manager delivered them, or a top-up was made to them). */
export function saveLeadAccounts(leadId: number, acts: string[], o: { bm?: string | null; task?: number | null; source: string }) {
  for (const a of acts.map(cleanAct).filter(x => x.length >= 6))
    run('INSERT OR IGNORE INTO lead_accounts(lead_id, act_id, bm_id, task_id, source, created_at) VALUES(?,?,?,?,?,?)', leadId, a, o.bm || null, o.task || null, o.source, now());
}
/** The chat's ad accounts, newest first, with how much was topped up through the manager. */
export function leadAccounts(leadId: number) {
  return all<{ act_id: string; bm_id: string | null; source: string; created_at: number; topped: number; last_topup: number | null }>(
    `SELECT a.act_id, a.bm_id, a.source, a.created_at,
       COALESCE((SELECT SUM(t.amount) FROM tasks t WHERE t.lead_id=a.lead_id AND t.kind='topup' AND t.act_id=a.act_id AND t.status='done'), 0) topped,
       (SELECT MAX(t.done_at) FROM tasks t WHERE t.lead_id=a.lead_id AND t.kind='topup' AND t.act_id=a.act_id AND t.status='done') last_topup
     FROM lead_accounts a WHERE a.lead_id=? ORDER BY a.id DESC`, leadId);
}

/** Agent sends a Telegram chat's request to the manager. */
export async function forwardToManager(lead: Lead, agentId: number, b: Record<string, unknown>) {
  const kind = ['account', 'topup', 'funnel', 'other'].includes(String(b.kind)) ? String(b.kind) : 'other';
  const bm = String(b.bm_id || '').replace(/\D/g, '');
  const act = cleanAct(String(b.act_id || ''));
  const qty = Math.max(1, Math.min(50, Math.floor(num(b.qty, 1))));
  const amount = money(b.amount);
  const note = String(b.note || '').trim().slice(0, 500);
  if (kind === 'account' && (bm.length < 8 || bm.length > 20)) throw new HttpError(400, 'Enter the client’s Business Manager ID (numbers only)');
  if (kind === 'topup' && (act.length < 6 || !(amount > 0))) throw new HttpError(400, 'Enter the ad account ID and the top-up amount');
  if ((kind === 'other' || kind === 'funnel') && !note && kind === 'other') throw new HttpError(400, 'Write what the manager should do');
  if (!managers().length) throw new HttpError(400, 'No manager yet. Admin → Team → set someone as Manager.');
  if (kind === 'topup') saveLeadAccounts(lead.id, [act], { source: 'topup' });
  const id = await createTask({ kind, source: 'agent', lead_id: lead.id, agent_id: agentId, bm_id: bm || null, act_id: act || null, qty: kind === 'account' ? qty : null, amount: kind === 'topup' ? amount : null, note: note || null });
  const t = one<Task>('SELECT * FROM tasks WHERE id=?', id)!;
  addMsg(lead, { dir: 'sys', sender: 'system', agent_id: agentId, text: `📤 Sent to manager: ${taskTitle(t)} — ${taskDetail(t).summary}${note && kind !== 'other' ? ' · ' + note : ''}` });
  return { ok: true, id };
}

/** Manager finishes a task. For website orders this delivers the order. */
export async function completeTask(taskId: number, b: Record<string, unknown>, by: string) {
  const t = one<Task>('SELECT * FROM tasks WHERE id=?', taskId);
  if (!t) throw new HttpError(404, 'Task not found');
  if (t.status === 'done') return { ok: true, already: true };
  // v156: an agent's sale of the other type → manager approves (Premium / Normal, with or without commission) or rejects
  if (t.kind === 'sale_check') {
    const d = JSON.parse((t as Task & { data?: string | null }).data || '{}') as { agent_id: number; b: Record<string, any>; type: string };
    const lead = t.lead_id ? leadById(t.lead_id) : undefined;
    if (!lead) throw new HttpError(400, 'Client chat not found');
    if (b.reject) {
      if (!run("UPDATE tasks SET status='done', result=?, done_at=?, done_by=? WHERE id=? AND status='open'", 'Rejected: not recorded', now(), by, t.id).changes) return { ok: true, already: true };
      run("UPDATE tasks SET status='done', result=?, done_at=?, done_by=? WHERE id=?", 'Rejected: not recorded', now(), by, t.id);
      addMsg(lead, { dir: 'sys', sender: 'system', text: `🚫 Manager rejected the sale (Tasks #${t.id}): not recorded` });
      void notifyAgent(agentById(d.agent_id), `🚫 Sale not approved for ${displayName(lead)} (Tasks #${t.id})`, lead.id);
      return { ok: true };
    }
    // never twice: one approval at a time, and not when this sale is already in the records
    if (!claimTask(t.id)) return { ok: true, already: true };
    const back = () => run("UPDATE tasks SET status='open', done_at=NULL WHERE id=? AND status='working'", t.id);
    const dup = d.b.meta_req ? one<{ id: number }>('SELECT id FROM sales WHERE meta_req_id=?', d.b.meta_req) : d.b.link_id ? one<{ id: number }>('SELECT id FROM sales WHERE pay_link_id=?', d.b.link_id) : undefined;
    const hand = one<{ id: number; amount: number }>('SELECT id, amount FROM sales WHERE lead_id=? AND created_at>? ORDER BY id DESC LIMIT 1', lead.id, t.created_at);
    if (dup || hand) { back(); throw new HttpError(409, `This sale is already in the records (sale #${(dup || hand)!.id}${hand && !dup ? `, $${hand.amount} marked after this task` : ''}). Reject this task so it is not counted twice.`); }
    const prem = b.type ? b.type === 'premium' : d.type === 'premium';
    const b2: Record<string, any> = { ...d.b, force: 1 };
    if (prem) { b2.service = 'account'; b2.tier = 'premium'; }
    else if (lead.tier === 'premium') { b2.service = 'account_std'; delete b2.tier; }
    else { b2.service = 'account'; b2.tier = 'agency'; }
    if (b.no_comm) b2.no_comm = 1;
    const ag = agentById(d.agent_id);
    if (!ag) { back(); throw new HttpError(400, 'The agent was deleted'); }
    const { recordSale } = await import('./crm');
    let r: { sale_id?: number; commission?: number };
    try { r = await recordSale(lead, { ...ag, deleted: 0 }, b2 as any, {}) as { sale_id?: number; commission?: number }; } catch (e) { back(); throw e; }
    if (r.sale_id && d.b.meta_req) run('UPDATE sales SET meta_req_id=? WHERE id=?', d.b.meta_req, r.sale_id);
    const res = `Approved as ${prem ? 'Premium' : 'Normal'}${b.no_comm ? ', no commission' : ''}`;
    run("UPDATE tasks SET status='done', result=?, done_at=?, done_by=? WHERE id=?", res, now(), by, t.id);
    void notifyAgent(ag, `✅ Sale approved for ${displayName(lead)}: ${res}`, lead.id);
    return { ok: true };
  }
  const note = String(b.note || '').trim().slice(0, 500);
  const accounts = String(b.accounts || '').split(/[\s,;]+/).map(cleanAct).filter(x => x.length >= 6);
  // v166: claimed first (open → working) so two taps / two people never deliver or message the client twice
  if (!claimTask(t.id)) return { ok: true, already: true };
  let result = note;
  try {
    // v166: the queue is delivering this order / top-up right now → not by hand at the same time
    if ((t.order_id || t.topup_id) && one("SELECT 1 FROM meta_jobs WHERE kind=? AND ref=? AND status='running'", t.order_id ? 'web_order' : 'web_topup', String(t.order_id || t.topup_id)))
      throw new HttpError(409, 'This is being delivered automatically right now (Ad accounts → Queue). Wait for it to finish.');
    if (t.order_id) {
      const o = one<Order>('SELECT * FROM web_orders WHERE id=?', t.order_id)!;
      if (o.status !== 'paid') throw new HttpError(400, o.status === 'inr_review' || o.status === 'awaiting_inr' ? 'Confirm the INR payment first (Mark as paid)' : 'This order is not paid yet');
      await deliverOrder(o, accounts, note, by);
      result = accounts.length ? accounts.map(a => 'act_' + a).join(', ') : note;
    } else if (t.topup_id) {
      const tp = one<Topup>('SELECT * FROM web_topups WHERE id=?', t.topup_id)!;
      if (tp.status !== 'paid') throw new HttpError(400, tp.status === 'inr_review' || tp.status === 'awaiting_inr' ? 'Confirm the INR payment first (Mark as paid)' : 'This top-up is not paid yet');
      await finishTopup(tp, note, by);
    } else {
      if (t.kind === 'account' && !accounts.length) throw new HttpError(400, 'Enter the ad account ID(s) you shared');
      if (t.kind === 'account') result = accounts.map(a => 'act_' + a).join(', ') + (note ? ' · ' + note : '');
      if (t.kind === 'account' && t.lead_id) saveLeadAccounts(t.lead_id, accounts, { bm: t.bm_id, task: t.id, source: 'manager' });
      const lead = t.lead_id ? leadById(t.lead_id) : undefined;
      if (lead) {
        addMsg(lead, { dir: 'sys', sender: 'system', text: `✅ Manager done: ${taskTitle(t)}${result ? ' — ' + result : ''}` });
        // tell the client automatically (account shared / top-up added); never the account type or our BM
        let told = false;
        if (t.kind === 'account') told = await tellClient(lead, 'meta_msg_share', { acts: accounts, bm: t.bm_id });
        else if (t.kind === 'topup' && t.amount) {
          const acts = t.act_id ? [cleanAct(t.act_id)] : accounts;
          if (acts.length) told = await tellClient(lead, 'meta_msg_topup', { acts, amount: money(t.amount) });
        }
        const ag = agentById(t.agent_id);
        await notifyAgent(ag, `✅ Manager finished ${taskTitle(t)} for #${lead.id} ${displayName(lead)}${result ? ': ' + result : ''}.\n${told ? 'The client got the message automatically.' : 'Tell the client in the chat.'}`, lead.id, { title: '✅ Manager done', body: `${displayName(lead)}: ${result || taskTitle(t)}` });
      }
    }
  } catch (e) { run("UPDATE tasks SET status='open', done_at=NULL WHERE id=? AND status='working'", t.id); throw e; }
  run("UPDATE tasks SET status='done', result=?, done_at=?, done_by=? WHERE id=?", result || null, now(), by, t.id);
  return { ok: true };
}

/* ======================= orders ======================= */
/** Website prices for a visitor from a retargeting ad: the Agency offer on the ad account (not Premium — its offer is the first top-up) and the Funnel offer. */
export function shopSettings(s0: Settings, tier: string | null, rt: boolean) {
  const s = tierFor(s0, tier);
  if (!rt) return { s, offer: null as null | { text: string } };
  const oa = tier === 'premium' ? null : offerOf(s0, 'agency'), of = offerOf(s0, 'funnel'), op = tier === 'premium' ? offerOf(s0, 'premium') : null;
  const out = applyOffer(applyOffer(s, oa), of);
  const text = (op || oa || of)?.text || '';
  return { s: out, offer: oa || of || op ? { text } : null };
}
export function prices(s: Settings = getSettings()) {
  return { account: money(s.price_account_web), full: money(s.price_account_full), funnel: money(s.price_funnel_web || s.price_funnel), telegram: money(s.price_account), topupMin: money(s.topup_min || 30), topupPct: num(s.topup_comm_pct, 3) };
}

/** Secret for opening one order's payment page without logging in (sent only to the person who placed it). */
export function orderKey(code: string) {
  return crypto.createHmac('sha256', String(process.env.APP_SECRET || 'x')).update('order|' + code).digest('base64url').slice(0, 22);
}
export function checkOrderKey(code: string, key: unknown) {
  const good = orderKey(code), k = String(key || '');
  return k.length === good.length && crypto.timingSafeEqual(Buffer.from(k), Buffer.from(good));
}

const guestHits = new Map<string, number[]>();
/** Order without email code: find or create the customer by email. Their login (OTP) is only needed for My account. */
export function guestCustomer(emailIn: unknown, ip: string): Customer {
  needWeb();
  const email = normEmail(emailIn);
  if (!validEmail(email)) throw new HttpError(400, 'Enter a valid email address — we send your order details there');
  const t = now();
  const hits = (guestHits.get(ip) || []).filter(x => x > t - HOUR); hits.push(t); guestHits.set(ip, hits);
  if (hits.length > 15) throw new HttpError(429, 'Too many orders from this network. Try again in an hour.');
  let cust = one<Customer>('SELECT * FROM customers WHERE email=?', email);
  if (!cust) { run('INSERT INTO customers(email, created_at) VALUES(?,?)', email, t); cust = one<Customer>('SELECT * FROM customers WHERE email=?', email)!; }
  return cust;
}

export async function createOrder(cust: Customer, b: Record<string, unknown>, fp: { ip: string; ua: string; fbc: string; fbp: string; page_url: string }, guest = false) {
  needWeb();
  const s0 = getSettings();
  const tier = b.tier === 'premium' && s0.premium_on === '1' ? 'premium' : null; // /order?tier=premium → Premium website price
  const rt = b.rt === true; // came from a retargeting ad (set by the route from the af_rt cookie / ?rt=1)
  const s = shopSettings(s0, tier, rt).s;
  const p = prices(s);
  const kind = b.kind === 'funnel' ? 'funnel' : 'account';
  const full = kind === 'account' && (b.kind === 'full' || b.full === true || b.full === 1 || b.full === '1') ? 1 : 0; // full access: they top up themselves
  const qty = kind === 'funnel' ? 1 : Math.floor(num(b.qty, 1));
  if (!(qty >= 1 && qty <= 20)) throw new HttpError(400, 'Choose between 1 and 20 accounts');
  const bm = String(b.bm_id || '').replace(/\D/g, '');
  if (kind === 'account' && (bm.length < 8 || bm.length > 20)) throw new HttpError(400, 'Enter your Business Manager ID (numbers only, from business.facebook.com → Business settings → Business info)');
  const name = String(b.name || '').trim().slice(0, 80);
  if (name.length < 2) throw new HttpError(400, 'Enter your name');
  const phone = cleanPhone(String(b.phone || '').slice(0, 30), s.default_cc || '91');
  if (!phone) throw new HttpError(400, 'Enter a valid mobile number');
  const tgp = b.tg === true || b.tg === 1 || b.tg === '1'; // ordered from /products (a link we give in Telegram / WhatsApp) → Telegram prices
  const unit = kind === 'funnel' ? (tgp ? money(s.price_funnel) : p.funnel) : full ? p.full : tgp ? money(s.price_account) : p.account;
  const amount = money(unit * qty);
  if (!(amount > 0)) throw new HttpError(400, 'Price is not set. Contact support.');
  // offer order: Agency/Funnel at the offer price, or a Premium order whose first top-up has no fee
  const offerTag = !full && !tgp && rt && (tier === 'premium' ? kind === 'account' && !!offerUntil(s0, 'premium', true) : unit < money(kind === 'funnel' ? s0.price_funnel_web || s0.price_funnel : tierFor(s0, tier).price_account_web)) ? '1' : null;
  const open = one<{ n: number }>("SELECT COUNT(*) n FROM web_orders WHERE customer_id=? AND status IN ('new','pending_payment','awaiting_inr') AND created_at>?", cust.id, now() - 24 * HOUR)!.n;
  if (open >= 5) throw new HttpError(429, 'You have several unpaid orders. Pay or cancel one first.');
  // A guest order never overwrites an existing customer's saved details (only fills empty ones)
  if (guest) run('UPDATE customers SET name=COALESCE(NULLIF(name,\'\'), ?), phone=COALESCE(NULLIF(phone,\'\'), ?) WHERE id=?', name, phone, cust.id);
  else run('UPDATE customers SET name=?, phone=? WHERE id=?', name, phone, cust.id);
  const c = code('AB');
  // Came from the landing form where Telegram didn't open → link the order to that lead (ad click data + agent note)
  const lead = leadByToken(b.lead_token);
  // From the bot (Telegram's own browser has no ad cookies) → the ad click data of their channel join
  const cj = typeof b.cj === 'string' ? joinByTok(b.cj) : undefined;
  const fbc = fp.fbc || lead?.fbc || cj?.fbc || '', fbp = fp.fbp || lead?.fbp || cj?.fbp || '';
  run(`INSERT INTO web_orders(cj_id, src, full, offer, tier, code, customer_id, kind, qty, bm_id, unit_price, amount, status, ip, ua, fbc, fbp, page_url, created_at, name, phone, lead_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,'new',?,?,?,?,?,?,?,?,?)`,
    cj?.id ?? null, b.src === 'channel' || cj ? 'channel' : null, full, offerTag, kind === 'account' ? tier : null, c, cust.id, kind, qty, kind === 'account' ? bm : null, unit, amount, fp.ip, fp.ua, fbc, fbp, (fp.page_url || lead?.page_url || '').slice(0, 500), now(), name, phone, lead?.id ?? null);
  const o = one<Order>('SELECT * FROM web_orders WHERE code=?', c)!;
  if (lead) {
    // Don't also message them on Telegram by phone; if they open Telegram later, the agent sees this note
    run("UPDATE leads SET contact_state=CASE WHEN COALESCE(contact_state,'')='' THEN 'web_order' ELSE contact_state END WHERE id=?", lead.id);
    addMsg(lead, { dir: 'sys', sender: 'system', text: `🌐 Placed a website order ${c} · ${kind === 'funnel' ? 'Landing + funnel' : `${qty}${full ? ' full access' : ''}${tier && kind === 'account' ? ' Premium' : ''} ad account${qty > 1 ? 's' : ''}`} · ${usd(amount)} (Telegram didn’t open). Don’t sell it again — check Website orders.` });
  }
  // Email right away: order received + link back to its payment page
  void sendEmail(cust.email, `Order received — ${c}`, emailHtml(s, {
    title: 'We got your order 👍',
    lines: [`Hi ${name.split(' ')[0]}! Complete the payment and your ${kind === 'funnel' ? 'funnel setup starts' : `ad account${qty > 1 ? 's are' : ' is'} shared to your Business Manager within ${s.delivery_time}`}.`, 'Already paid? You can ignore this — we’ll email you as soon as the payment is confirmed.'],
    rows: [['Order', c], ['Product', kind === 'funnel' ? 'Landing + funnel' : `${qty} ${full ? 'full access ' : ''}${tier ? 'Premium ' : ''}agency ad account${qty > 1 ? 's' : ''}`], ...(kind === 'account' ? [['Business Manager', bm] as [string, string]] : []), ['Total', usd(amount)]],
    button: { text: 'Complete payment', url: `${publicUrl()}/order?o=${c}&k=${orderKey(c)}` },
  }));
  // Meta: order form submitted = InitiateCheckout. Lead is sent later, when the payment address / UPI QR is shown.
  void sendCapi(s, {
    event_id: 'wic_' + o.id, event_name: 'InitiateCheckout', source_url: o.page_url,
    user_data: orderUserData(o, cust, s),
    custom_data: { content_name: kind === 'funnel' ? 'Landing + Funnel (website)' : tier ? 'Ad Account (Premium, website)' : 'Ad Account (website)', currency: 'USD', value: amount, num_items: qty },
  });
  return o;
}

function leadByToken(t: unknown) {
  const tok = String(t || '').trim();
  if (!/^[A-Za-z0-9_-]{8,40}$/.test(tok)) return undefined;
  return one<Lead>('SELECT * FROM leads WHERE token=? AND created_at>?', tok, now() - 7 * 24 * HOUR);
}
/** Name + phone + product from the landing form, to fill the website order form. Only for the person holding the secret lead token. */
export function leadPrefill(t: unknown) {
  const l = leadByToken(t);
  if (!l) return null;
  const phone = String(l.phone || '').replace(/^\+?91(?=\d{10}$)/, '');
  return { name: l.name || '', phone, kind: l.service === 'funnel' ? 'funnel' : 'account' };
}
/** Same person as this website order: their Telegram chats (by order link or phone) and their other website orders. */
export function orderPerson(o: Order, cust: Customer, prefix: string) {
  const leads = new Set<number>(samePerson({ id: (o as { lead_id?: number | null }).lead_id ?? null, phone: o.phone || cust.phone || null }));
  const l = (o as { lead_id?: number | null }).lead_id ? one<{ id: number; tg_chat_id: string | null; phone: string | null }>('SELECT id, tg_chat_id, phone FROM leads WHERE id=?', (o as { lead_id?: number | null }).lead_id) : undefined;
  for (const x of samePerson(l)) leads.add(x);
  const events = all<{ id: number }>('SELECT id FROM web_orders WHERE customer_id=? AND id!=?', o.customer_id, o.id).map(r => prefix + r.id);
  return { leads: [...leads], events };
}
function orderUserData(o: Order, cust: Customer, s: Settings) {
  return buildUserData({ name: o.name || cust.name || '', phone: o.phone || cust.phone || '', email: cust.email, ip: o.ip, ua: o.ua, fbc: o.fbc, fbp: o.fbp, vid: 'c' + cust.id, page_url: o.page_url }, s);
}
/** Meta Lead for a website order — sent once per order, when the customer actually reaches the payment step
 *  (crypto address created, UPI QR shown, or — without UPI — when they send the UTR). */
function webOrderLead(orderId: number, how: string) {
  const s = getSettings();
  const o = one<Order>('SELECT * FROM web_orders WHERE id=?', orderId);
  if (!o) return;
  const cust = one<Customer>('SELECT * FROM customers WHERE id=?', o.customer_id)!;
  void sendCapi(s, {
    event_id: 'wlead_o' + o.id, event_name: 'Lead', source_url: o.page_url, lead_id: (o as { lead_id?: number | null }).lead_id ?? null, once: orderPerson(o, cust, 'wlead_o'),
    user_data: orderUserData(o, cust, s),
    custom_data: { content_name: o.kind === 'funnel' ? 'Landing + Funnel (website)' : 'Ad Account (website)', currency: 'USD', value: o.amount, lead_type: how },
  });
}

type Payable = { table: 'web_orders' | 'web_topups'; row: Order | Topup; total: number; desc: string };
function payable(table: 'web_orders' | 'web_topups', id: number, custId: number): Payable {
  const row = one<Order & Topup>(`SELECT * FROM ${table} WHERE id=? AND customer_id=?`, id, custId);
  if (!row) throw new HttpError(404, 'Not found');
  const total = table === 'web_orders' ? row.amount : row.total;
  const desc = table === 'web_orders' ? (row.kind === 'funnel' ? 'Landing + funnel setup' : `${row.qty} agency ad account(s)`) : `Ad account top-up $${row.amount}`;
  return { table, row, total, desc };
}

/** Customer picks how to pay. Crypto → NOWPayments invoice in our page. INR → manual (optional UPI QR). */
export async function startPayment(table: 'web_orders' | 'web_topups', id: number, cust: Customer, b: Record<string, unknown>) {
  needWeb();
  const s = getSettings();
  const p = payable(table, id, cust.id);
  if (!['new', 'pending_payment', 'awaiting_inr'].includes(p.row.status)) throw new HttpError(400, 'This is already paid or closed');
  const back = table === 'web_orders' ? `${publicUrl()}/order?o=${p.row.code}&k=${orderKey(p.row.code)}` : `${publicUrl()}/account?topup=${p.row.code}`;
  if (b.method === 'inr') {
    if (s.inr_on !== '1') throw new HttpError(400, 'INR payment is not available right now');
    const inr = Math.ceil(p.total * num(s.inr_rate, 90));
    run(`UPDATE ${p.table} SET pay_method='inr', inr_amount=?, status='awaiting_inr' WHERE id=?`, inr, id);
    const info = inrInfo(s, p.row.code, inr);
    if (table === 'web_orders' && info.upi) webOrderLead(id, 'upi_qr');
    return { ok: true, ...info };
  }
  void back;
  const coins = enabledCoins(s);
  const cur = String(b.currency || '').toLowerCase();
  if (!coins.includes(cur)) throw new HttpError(400, 'Choose one of the listed coins');
  // Same coin and the timer is still running → show the same address again (no new address on every click)
  if (!b.renew && p.row.pay_method === 'crypto' && p.row.pay_currency === cur && p.row.pay_address && (p.row.np_expires || 0) > now() + 60000) return { ok: true, crypto: cryptoInfo(p.row) };
  const pay = await npCreatePayment(s, { code: p.row.code, amount: p.total, desc: `${s.brand_name}: ${p.desc} (${p.row.code})`, payCurrency: cur });
  run(`UPDATE ${p.table} SET pay_method='crypto', np_payment_id=?, pay_currency=?, pay_address=?, pay_amount=?, pay_extra=?, np_expires=?, np_status='waiting', status='pending_payment' WHERE id=?`,
    pay.id, cur, pay.address, pay.amount, pay.extra, pay.expires, id);
  if (table === 'web_orders') webOrderLead(id, 'crypto_address');
  return { ok: true, crypto: cryptoInfo(one<Order & Topup>(`SELECT * FROM ${p.table} WHERE id=?`, id)!) };
}

/** What the customer needs to pay by crypto inside our page. */
export function cryptoInfo(r: { pay_currency: string | null; pay_address?: string | null; pay_amount?: number | null; pay_extra?: string | null; np_expires?: number | null; np_status: string | null }) {
  if (!r.pay_address || !r.pay_currency) return null;
  const s = getSettings();
  return { currency: r.pay_currency, coin: coinName(s, r.pay_currency), ticker: coinTicker(s, r.pay_currency), network: coinNetwork(s, r.pay_currency),
    address: r.pay_address, amount: r.pay_amount ?? null, extra: r.pay_extra || null, expires: r.np_expires || 0, np_status: r.np_status || 'waiting' };
}

/** Customer's page asks for the status: also ask NOWPayments directly (max every 15s), so it works even if the IPN is late. */
export async function refreshCrypto(table: 'web_orders' | 'web_topups', id: number) {
  const row = one<Order & Topup>(`SELECT * FROM ${table} WHERE id=?`, id);
  if (!row || row.pay_method !== 'crypto' || !row.np_payment_id || row.status !== 'pending_payment' || now() - (row.np_checked || 0) < 15000) return;
  run(`UPDATE ${table} SET np_checked=? WHERE id=?`, now(), id);
  const st = await npPaymentStatus(getSettings(), row.np_payment_id);
  if (st && String(st.payment_id || '') === String(row.np_payment_id)) await handleIpn({ ...st, order_id: row.code });
}

export function inrInfo(s: Settings, ref: string, inr: number) {
  const upi = s.upi_on === '1' && s.upi_id.trim() ? `upi://pay?${new URLSearchParams({ pa: s.upi_id.trim(), pn: (s.upi_name || s.brand_name).slice(0, 40), am: inr.toFixed(2), cu: 'INR', tn: ref }).toString()}` : null;
  return { inr_amount: inr, rate: num(s.inr_rate, 90), upi, upi_id: upi ? s.upi_id.trim() : null, manager: managerLink(s) };
}

/** Customer says they paid by INR (with UTR / reference). Goes to the manager to check. */
export async function submitUtr(table: 'web_orders' | 'web_topups', id: number, cust: Customer, utrIn: unknown) {
  needWeb();
  const p = payable(table, id, cust.id);
  if (p.row.status !== 'awaiting_inr' && p.row.status !== 'inr_review') throw new HttpError(400, 'Choose INR payment first');
  const utr = String(utrIn || '').trim().replace(/[^\w-]/g, '').slice(0, 40);
  if (utr.length < 6) throw new HttpError(400, 'Enter the UPI reference / UTR number from your payment app');
  const firstTime = p.row.status === 'awaiting_inr';
  run(`UPDATE ${p.table} SET utr=?, status='inr_review' WHERE id=?`, utr, id);
  if (table === 'web_orders') webOrderLead(id, 'inr_utr'); // no-op if already sent at the QR step
  if (firstTime) await createTask(table === 'web_orders'
    ? { kind: 'web_order', source: 'web', order_id: id, note: `INR ₹${p.row.inr_amount} · UTR ${utr} — check and mark as paid` }
    : { kind: 'web_topup', source: 'web', topup_id: id, note: `INR ₹${p.row.inr_amount} · UTR ${utr} — check and mark as paid` });
  else run(`UPDATE tasks SET note=? WHERE ${table === 'web_orders' ? 'order_id' : 'topup_id'}=? AND status='open'`, `INR ₹${p.row.inr_amount} · UTR ${utr} — check and mark as paid`, id);
  return { ok: true };
}

/** Payment confirmed (NOWPayments IPN, or manager confirms INR). Idempotent. */
export async function markPaid(table: 'web_orders' | 'web_topups', id: number, by: string) {
  const row = one<Order & Topup>(`SELECT * FROM ${table} WHERE id=?`, id);
  if (!row) throw new HttpError(404, 'Not found');
  if (['paid', 'delivered', 'done'].includes(row.status)) return { ok: true, already: true };
  if (row.status === 'cancelled' && by !== 'nowpayments') throw new HttpError(400, 'This was cancelled');
  run(`UPDATE ${table} SET status='paid', paid_at=? WHERE id=?`, now(), id);
  const key = table === 'web_orders' ? 'order_id' : 'topup_id';
  const open = one<{ id: number }>(`SELECT id FROM tasks WHERE ${key}=? AND status='open'`, id);
  const s = getSettings();
  const cust = one<Customer>('SELECT * FROM customers WHERE id=?', row.customer_id)!;
  if (open) { run('UPDATE tasks SET note=? WHERE id=?', `Paid (${by === 'nowpayments' ? 'crypto' : 'INR confirmed'}) — ${table === 'web_orders' ? 'deliver now' : 'top up now'}`, open.id); await notifyManagers(open.id); }
  else await createTask(table === 'web_orders' ? { kind: 'web_order', source: 'web', order_id: id, note: 'Paid — deliver now' } : { kind: 'web_topup', source: 'web', topup_id: id, note: 'Paid — top up now' });
  // v152: Auto approve ON → the queue shares / tops up by itself (the task closes when it is done; otherwise the manager does it as before)
  try { const Q = await import('./metaq'); if (table === 'web_orders') await Q.autoWebOrder(id); else await Q.autoWebTopup(id); } catch (e) { console.warn('[meta] auto web', (e as Error).message); }
  const isOrder = table === 'web_orders';
  // Funnel bought on the website → same Telegram flow as before, but the chat goes to the manager
  const oPhone = (isOrder && row.phone) || cust.phone, oName = (isOrder && row.name) || cust.name || '';
  if (isOrder && row.kind === 'funnel' && oPhone) queuePhoneMessage(oPhone, oName,
    `Hi ${oName.split(' ')[0] || 'there'}! 👋 Thanks for your ${s.brand_name} funnel order ${row.code} — payment received ✅\nI’m your account manager. Tell me your niche and what you want to sell, and we’ll start the setup.`,
    { service: 'funnel', note: `🌐 Website funnel order ${row.code} · ${usd(row.amount)} · ${cust.email} — paid, start the setup here` });
  void sendEmail(cust.email, `Payment received — ${row.code}`, emailHtml(s, {
    title: 'Payment received ✅',
    lines: [isOrder ? (row.kind === 'funnel' ? 'Thanks! Your account manager will contact you on Telegram to start your funnel setup.' : `Thanks! Your ad account${row.qty > 1 ? 's are' : ' is'} being prepared and will be shared to your Business Manager within ${s.delivery_time}.`) : `Thanks! Your top-up of ${usd(row.amount)} is being added to act_${row.act_id}.`],
    rows: isOrder ? [['Order', row.code], ['Amount', usd(row.amount)], ...(row.bm_id ? [['Business Manager', row.bm_id] as [string, string]] : [])] : [['Top-up', row.code], ['Ad account', 'act_' + row.act_id], ['Amount', usd(row.amount)], ['Paid', usd(row.total)]],
    button: { text: 'Open my account', url: `${publicUrl()}/account` },
  }));
  return { ok: true };
}

export async function deliverOrder(o: Order, accounts: string[], note: string, by: string) {
  const s = getSettings();
  if (o.kind === 'account') {
    if (accounts.length < 1) throw new HttpError(400, 'Enter the ad account ID(s) you shared');
    if (accounts.length > o.qty) throw new HttpError(400, `This order is for ${o.qty} account${o.qty > 1 ? 's' : ''}`);
    const dup = accounts.find((a, i) => accounts.indexOf(a) !== i);
    if (dup) throw new HttpError(400, `act_${dup} is listed twice`);
  }
  tx(() => { // v166: claimed once (paid → delivered); a 2nd delivery (by hand + the queue job) is refused before anything is written
    if (!run("UPDATE web_orders SET status='delivered', delivered_at=?, accounts=?, note=COALESCE(?, note) WHERE id=? AND status='paid'", now(), accounts.join(',') || null, note || null, o.id).changes) throw new HttpError(409, 'This order was already delivered');
    for (const a of accounts) run('INSERT INTO web_accounts(customer_id, order_id, act_id, created_at) VALUES(?,?,?,?)', o.customer_id, o.id, a, now());
  });
  const cust = one<Customer>('SELECT * FROM customers WHERE id=?', o.customer_id)!;
  const acts = accounts.map(a => 'act_' + a);
  const funnel = o.kind === 'funnel';
  void sendEmail(cust.email, funnel ? `Your funnel setup has started — ${o.code}` : `Your ad account is ready — ${o.code}`, emailHtml(s, {
    title: funnel ? 'Your funnel setup has started 🚀' : `Your ad account${acts.length > 1 ? 's are' : ' is'} ready 🚀`,
    lines: funnel ? [note || 'Your account manager will message you on Telegram for the details.'] : [`We shared ${acts.length > 1 ? 'these ad accounts' : 'this ad account'} to your Business Manager ${o.bm_id}. Open Business settings → Ad accounts to find ${acts.length > 1 ? 'them' : 'it'}.`, ...(note ? [note] : []), 'Top-ups: log in to your account on our website any time.'],
    rows: funnel ? [['Order', o.code]] : [['Order', o.code], ...acts.map((a, i) => [`Ad account ${acts.length > 1 ? i + 1 : ''}`.trim(), a] as [string, string])],
    button: { text: 'Open my account', url: `${publicUrl()}/account` },
  }));
  // Funnel: the Telegram chat was already started when the payment came in (markPaid)
  const oPhone = o.phone || cust.phone, oName = o.name || cust.name || '';
  if (oPhone && !funnel) queuePhoneMessage(oPhone, oName, `Hi ${oName.split(' ')[0] || 'there'}! ✅ Your ${s.brand_name} ad account${acts.length > 1 ? 's are' : ' is'} ready: ${acts.join(', ')}\nShared to your Business Manager ${o.bm_id}.\nTop-ups: ${publicUrl()}/account`,
    { service: funnel ? 'funnel' : 'account', note: `🌐 Website ${funnel ? 'funnel order' : 'order'} ${o.code} · ${usd(o.amount)} · ${cust.email}${funnel ? ' — start the funnel setup here' : ''}` });
  // Meta Purchase: when the order is delivered (once per order)
  await sendCapi(s, {
    event_id: 'wpurchase_' + o.id, event_name: 'Purchase', source_url: o.page_url, lead_id: (o as { lead_id?: number | null }).lead_id ?? null, once: orderPerson(o, cust, 'wpurchase_'),
    user_data: buildUserData({ name: oName, phone: oPhone, email: cust.email, ip: o.ip, ua: o.ua, fbc: o.fbc, fbp: o.fbp, vid: (o as { cj_id?: number | null }).cj_id ? one<{ vid: string | null }>('SELECT vid FROM channel_joins WHERE id=?', (o as { cj_id?: number | null }).cj_id)?.vid || 'c' + cust.id : 'c' + cust.id }, s),
    custom_data: { currency: 'USD', value: o.amount, content_name: funnel ? 'Landing + Funnel (website)' : 'Ad Account (website)', num_items: o.qty, order_id: o.code },
  });
  void by;
}

/* ======================= top-ups ======================= */
export function customerAccounts(custId: number) {
  return all<{ id: number; act_id: string; order_id: number; created_at: number }>('SELECT id, act_id, order_id, created_at FROM web_accounts WHERE customer_id=? ORDER BY id DESC', custId);
}

export function createTopup(cust: Customer, b: Record<string, unknown>) {
  needWeb();
  const s = getSettings();
  const p = prices(s);
  let acc = b.account_id ? one<{ id: number; act_id: string; customer_id: number }>('SELECT * FROM web_accounts WHERE id=?', num(b.account_id)) : undefined;
  if (!acc && b.act_id) {
    const a = cleanAct(String(b.act_id));
    acc = one('SELECT * FROM web_accounts WHERE act_id=? AND customer_id=?', a, cust.id);
    if (!acc) throw new HttpError(400, 'This ad account was not bought on our website with your email. If you bought it through Telegram support, please contact your support agent for top-ups.');
  }
  if (!acc || acc.customer_id !== cust.id) throw new HttpError(400, 'Choose one of your ad accounts. Accounts bought through Telegram support are topped up by your support agent.');
  // an account bought on a Premium order → the Premium top-up fee
  const fromPremium = !!one('SELECT 1 FROM web_orders o JOIN web_accounts a ON a.order_id=o.id WHERE a.id=? AND o.tier=?', acc.id, 'premium');
  if (fromPremium) p.topupPct = num(tierFor(s, 'premium').topup_comm_pct, 3);
  const amount = money(b.amount);
  if (!(amount >= p.topupMin)) throw new HttpError(400, `Minimum top-up is ${usd(p.topupMin)}`);
  if (amount > 50000) throw new HttpError(400, 'For top-ups above $50,000 please contact your account manager');
  // Premium order from a retargeting ad: the customer's first top-up has no fee on up to offer_premium_free (within the offer days)
  const po = fromPremium ? one<{ created_at: number }>("SELECT o.created_at FROM web_orders o JOIN web_accounts a ON a.order_id=o.id WHERE a.id=? AND o.offer='1'", acc.id) : undefined;
  const op = offerOf(s, 'premium');
  const days = Math.min(30, Math.max(1, num(s.offer_days, 7)));
  const firstTu = !one("SELECT 1 FROM web_topups WHERE customer_id=? AND status NOT IN ('cancelled','expired')", cust.id);
  const free = po && op?.free && firstTu && po.created_at > now() - days * 24 * HOUR ? Math.min(amount, op.free) : 0;
  const fee = money((amount - free) * p.topupPct / 100);
  const total = money(amount + fee);
  const open = one<{ n: number }>("SELECT COUNT(*) n FROM web_topups WHERE customer_id=? AND status IN ('new','pending_payment','awaiting_inr') AND created_at>?", cust.id, now() - 24 * HOUR)!.n;
  if (open >= 5) throw new HttpError(429, 'You have several unpaid top-ups. Pay or cancel one first.');
  const c = code('TU');
  run("INSERT INTO web_topups(code, customer_id, account_id, act_id, amount, fee, total, status, created_at, offer_free) VALUES(?,?,?,?,?,?,?,'new',?,?)", c, cust.id, acc.id, acc.act_id, amount, fee, total, now(), free || null);
  return one<Topup>('SELECT * FROM web_topups WHERE code=?', c)!;
}

export async function finishTopup(tp: Topup, note: string, by: string) {
  const s = getSettings();
  if (!run("UPDATE web_topups SET status='done', done_at=?, note=COALESCE(?, note) WHERE id=? AND status='paid'", now(), note || null, tp.id).changes) throw new HttpError(409, 'This top-up was already added'); // v166: once
  const cust = one<Customer>('SELECT * FROM customers WHERE id=?', tp.customer_id)!;
  void sendEmail(cust.email, `Top-up added — act_${tp.act_id}`, emailHtml(s, {
    title: 'Top-up added ✅', lines: [`${usd(tp.amount)} was added to your ad account act_${tp.act_id}. It can take a few minutes to show in Ads Manager.`, ...(note ? [note] : [])],
    rows: [['Top-up', tp.code], ['Ad account', 'act_' + tp.act_id], ['Amount', usd(tp.amount)]], button: { text: 'Open my account', url: `${publicUrl()}/account` },
  }));
  if (cust.phone) queuePhoneMessage(cust.phone, cust.name || '', `✅ ${usd(tp.amount)} top-up added to act_${tp.act_id}. Thank you for using ${s.brand_name}!`, { service: 'account', note: `🌐 Website top-up ${tp.code} · ${usd(tp.amount)} → act_${tp.act_id} · ${cust.email}` });
  void by;
}

export function cancelItem(table: 'web_orders' | 'web_topups', id: number, custId: number | null) {
  const row = one<{ status: string; customer_id: number }>(`SELECT status, customer_id FROM ${table} WHERE id=?`, id);
  if (!row || (custId !== null && row.customer_id !== custId)) throw new HttpError(404, 'Not found');
  if (!['new', 'pending_payment', 'awaiting_inr', 'inr_review'].includes(row.status)) throw new HttpError(400, 'Paid orders can’t be cancelled here. Contact your account manager.');
  if (custId !== null && row.status === 'inr_review') throw new HttpError(400, 'Your INR payment is being checked. Contact your account manager to cancel.');
  run(`UPDATE ${table} SET status='cancelled' WHERE id=?`, id);
  run(`UPDATE tasks SET status='done', result='cancelled', done_at=? WHERE ${table === 'web_orders' ? 'order_id' : 'topup_id'}=? AND status='open'`, now(), id);
  return { ok: true };
}

/* ======================= NOWPayments IPN ======================= */
/** An IPN for an older payment address of the same order that carries no money news. */
export const staleNews = (current: string | null | undefined, p: Record<string, unknown>) =>
  !!current && !!p.payment_id && String(p.payment_id) !== String(current) && !NP_PAID.includes(String(p.payment_status || '')) && !['partially_paid', 'confirming'].includes(String(p.payment_status || ''));
export async function handleIpn(p: Record<string, unknown>) {
  const ref = String(p.order_id || '');
  const status = String(p.payment_status || '');
  const table = ref.startsWith('AB-') ? 'web_orders' : ref.startsWith('TU-') ? 'web_topups' : null;
  if (!table) return { ignored: true };
  const row = one<{ id: number; status: string; amount: number; total: number; np_payment_id: string | null }>(`SELECT id, status, amount, np_payment_id, ${table === 'web_orders' ? 'amount AS total' : 'total'} FROM ${table} WHERE code=?`, ref);
  if (!row) return { ignored: true };
  // The customer switched coin: news about the OLD address (waiting / expired) must not overwrite the new one. Money on it still counts.
  if (staleNews(row.np_payment_id, p)) return { ok: true, stale: true };
  run(`UPDATE ${table} SET np_status=?, np_payment_id=COALESCE(?, np_payment_id), pay_currency=COALESCE(?, pay_currency) WHERE id=?`, status, p.payment_id ? String(p.payment_id) : null, p.pay_currency ? String(p.pay_currency) : null, row.id);
  const priceOk = Math.abs(num(p.price_amount) - row.total) < 0.01 && String(p.price_currency || 'usd').toLowerCase() === 'usd';
  if (NP_PAID.includes(status)) {
    if (!priceOk) { console.warn('[ipn] amount mismatch', ref, p.price_amount, row.total); return { ok: false, mismatch: true }; }
    await markPaid(table, row.id, 'nowpayments');
  } else if (status === 'partially_paid' && ['new', 'pending_payment'].includes(row.status) && !one(`SELECT 1 FROM tasks WHERE ${table === 'web_orders' ? 'order_id' : 'topup_id'}=? AND status='open'`, row.id)) {
    const id = await createTask(table === 'web_orders' ? { kind: 'web_order', source: 'web', order_id: row.id, note: `⚠️ Partially paid (${p.actually_paid} ${p.pay_currency}). Check NOWPayments before delivering.` } : { kind: 'web_topup', source: 'web', topup_id: row.id, note: `⚠️ Partially paid (${p.actually_paid} ${p.pay_currency}). Check NOWPayments.` });
    void id;
  }
  return { ok: true };
}

/* ======================= Telegram message by phone (from the chat account) ======================= */
/** Queue a Telegram message to the customer's phone from the chat account. When it is sent, the chat is
 *  saved as a lead assigned to the manager, so the customer's reply lands with the manager (not a random agent). */
export function queuePhoneMessage(phone: string, name: string, text: string, lead?: { service: string; note: string }) {
  const m = managers()[0];
  const delay = Math.max(0, num(getSettings().welcome_delay_sec, 35)) * 1000; // same delay as the Telegram welcome message
  run("INSERT INTO ub_phone_jobs(phone, name, text, status, created_at, lead_json, due_at) VALUES(?,?,?,'queued',?,?,?)", phone, name, text.slice(0, 3500), now(),
    JSON.stringify({ service: lead?.service || 'account', note: lead?.note || '', agent_id: m?.id ?? null }), now() + delay);
}

/** Called by the worker after a phone message was sent: link the Telegram chat to a manager-owned lead. */
export function attachWebLead(jobId: number, u: { id: string; hash: string; username: string; name: string }) {
  const job = one<{ phone: string; name: string; text: string; lead_json: string | null }>('SELECT phone, name, text, lead_json FROM ub_phone_jobs WHERE id=?', jobId);
  if (!job || !job.lead_json) return null;
  const j = JSON.parse(job.lead_json) as { service: string; note: string; agent_id: number | null };
  const agentId = j.agent_id && agentById(j.agent_id) ? j.agent_id : (managers()[0]?.id ?? null);
  let lead = one<{ id: number }>("SELECT id FROM leads WHERE tg_chat_id=? AND source='web' AND status!='merged' ORDER BY id DESC LIMIT 1", u.id);
  if (!lead) {
    lead = one<{ id: number }>(`INSERT INTO leads(token, source, name, phone, service, tg_chat_id, tg_access_hash, tg_username, tg_name, created_at, status, agent_id, assigned_at, contact_state, contact_at)
      VALUES(?,?,?,?,?,?,?,?,?,?,'active',?,?,'sent',?) RETURNING id`,
      crypto.randomBytes(6).toString('hex'), 'web', job.name || u.name, job.phone, j.service, u.id, u.hash, u.username, u.name, now(), agentId, now(), now())!;
  } else run('UPDATE leads SET agent_id=COALESCE(?, agent_id), tg_access_hash=? WHERE id=?', agentId, u.hash, lead.id);
  if (getSettings().save_contacts === '1') run('UPDATE leads SET tg_contact=? WHERE id=?', String(job.name || u.name || '').trim().slice(0, 60) || null, lead.id);
  addMsg(lead, { dir: 'out', sender: 'auto', text: job.text });
  if (j.note) addMsg(lead, { dir: 'sys', sender: 'system', text: j.note });
  return lead.id;
}
