import { soundData } from './notifsound';
import crypto from 'crypto';
import { all, one, run } from './db';
import { getSettings, setSetting } from './settings';

const FCM = () => process.env.FCM_API_BASE || 'https://fcm.googleapis.com'; // tests
/** Firebase Cloud Messaging (HTTP v1). Service account JSON is pasted in Admin → Settings. */
let tokenCache: { token: string; exp: number; key: string } | null = null;

async function accessToken(sa: { client_email: string; private_key: string; token_uri?: string }) {
  const key = sa.client_email;
  if (tokenCache && tokenCache.key === key && tokenCache.exp > Date.now() + 60000) return tokenCache.token;
  const iat = Math.floor(Date.now() / 1000);
  const enc = (o: unknown) => Buffer.from(JSON.stringify(o)).toString('base64url');
  const unsigned = `${enc({ alg: 'RS256', typ: 'JWT' })}.${enc({ iss: sa.client_email, scope: 'https://www.googleapis.com/auth/firebase.messaging', aud: sa.token_uri || 'https://oauth2.googleapis.com/token', iat, exp: iat + 3600 })}`;
  const sig = crypto.createSign('RSA-SHA256').update(unsigned).sign(sa.private_key).toString('base64url');
  const r = await fetch(sa.token_uri || 'https://oauth2.googleapis.com/token', {
    method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer', assertion: `${unsigned}.${sig}` }),
  });
  const j = await r.json() as { access_token?: string; expires_in?: number };
  if (!j.access_token) throw new Error('FCM auth failed');
  tokenCache = { token: j.access_token, exp: Date.now() + (j.expires_in || 3600) * 1000, key };
  return j.access_token;
}

/** opts.alarm: a NEW LEAD — app 1.x+ (android3) also plays the alert on the alarm volume when the phone is on silent / vibrate (agent's switch). */
/** v134: ring on silent only when the admin switched it on (Settings → Agent app) and only inside working hours. */
function ringNow(s: ReturnType<typeof getSettings>, t = Date.now()) {
  if (s.alarm_on === '0') return false;
  const m = String(s.work_hours || '').match(/^\s*(\d{1,2})\s*-\s*(\d{1,2})\s*$/);
  if (!m) return true;
  const a = +m[1] % 24, b = +m[2] % 24;
  if (a === b) return true;
  const h = new Date(t + (Number(s.tz_offset_min) || 330) * 60000).getUTCHours();
  return a < b ? h >= a && h < b : h >= a || h < b;
}
/** v140: is "ring on silent / vibrate" switched off for this person? (agents.ring_off · admin phones: admin_ring_off) */
export function ringOffFor(role: 'agent' | 'admin', userId: number | null, s: ReturnType<typeof getSettings> = getSettings()) {
  if (role === 'admin') return s.admin_ring_off === '1';
  return !!userId && !!one<{ r: number | null }>('SELECT ring_off r FROM agents WHERE id=?', userId)?.r;
}
/** v140: the list for Settings → Phone notifications → Ring for each person (manager, agents, admin phones). */
export function ringPeople() {
  const s = getSettings();
  const ag = all<{ id: number; name: string; role: string; ring_off: number | null; phones: number }>("SELECT a.id, a.name, COALESCE(a.role,'agent') role, a.ring_off, (SELECT COUNT(*) FROM push_tokens t WHERE t.role='agent' AND t.user_id=a.id) phones FROM agents a WHERE a.deleted=0 ORDER BY a.role='manager' DESC, a.name");
  const adminPhones = one<{ n: number }>("SELECT COUNT(*) n FROM push_tokens WHERE role='admin'")?.n || 0;
  return [
    ...ag.map(a => ({ key: `agent:${a.id}`, name: a.name, role: a.role === 'manager' ? 'manager' : 'agent', ring: !a.ring_off, phones: a.phones })),
    { key: 'admin', name: 'Admin phones', role: 'admin', ring: s.admin_ring_off !== '1', phones: adminPhones },
  ];
}
export function setRingOff(key: string, off: boolean) {
  if (key === 'admin') { setSetting('admin_ring_off', off ? '1' : '0'); return true; }
  const m = /^agent:(\d+)$/.exec(String(key));
  return !!m && run('UPDATE agents SET ring_off=? WHERE id=? AND deleted=0', off ? 1 : 0, Number(m[1])).changes > 0;
}
export async function pushTo(role: 'agent' | 'admin', userId: number | null, title: string, body: string, data: Record<string, string> = {}, opts: { alarm?: boolean; force?: boolean } = {}) {
  const s = getSettings();
  if (!s.fcm_service_account) return;
  // v124: phone notifications without phone-style emojis
  const EMO = /[\u{1F000}-\u{1FAFF}\u{2600}-\u{26FF}\u2705\u2728\u274C\u2B50\u23E9-\u23FA\u231A\u231B\u2709\u21A9\u21AA]\uFE0F?[ \u00a0]?/gu;
  title = title.replace(EMO, '').trim(); body = body.replace(EMO, '').trim();
  // v134: one notification per chat on the phone — the chat is titled "Name · WhatsApp / Telegram", each alert is a line in it
  if (data.lead_id && !data.chat) {
    const l = one<{ id: number; name: string | null; tg_name: string | null; tg_username: string | null; ch: string | null; tg_chat_id: string | null }>('SELECT id, name, tg_name, tg_username, ch, tg_chat_id FROM leads WHERE id=?', Number(data.lead_id));
    if (l) {
      const who = l.name || l.tg_name || (l.tg_username ? '@' + l.tg_username : 'Lead #' + l.id);
      const wa = l.ch === 'wa' || String(l.tg_chat_id || '').startsWith('wa:');
      const plain = (t: string) => t.replace(who, '').replace(/^[\s·→-]+|[\s·]+$/g, '').replace(/\s*·\s*(WhatsApp|Telegram)$/, '').trim();
      const isName = title === who || title.startsWith(who + ' ·') || title.startsWith(who + ' (');
      const rest = plain(body);
      data = { ...data, chat: `${who} · ${wa ? 'WhatsApp' : 'Telegram'}`, line: (isName ? body : rest && rest !== '(WhatsApp)' ? `${title} · ${rest}` : title).slice(0, 180) };
    }
  }
  let sa: { client_email: string; private_key: string; project_id: string; token_uri?: string };
  try { sa = JSON.parse(s.fcm_service_account); } catch { return; }
  const rows = role === 'admin'
    ? all<{ token: string; platform: string | null }>("SELECT token, platform FROM push_tokens WHERE role='admin'")
    : all<{ token: string; platform: string | null }>("SELECT token, platform FROM push_tokens WHERE role='agent' AND user_id=?", userId);
  if (!rows.length) return;
  // v140: per-person "Ring on silent / vibrate" (Settings → Phone notifications → Ring for each person). It can only turn
  // the ring OFF: the normal notification with our sound still goes, only the play-on-silent part (alarm flag) is skipped.
  const ringOff = ringOffFor(role, userId, s);
  let at: string;
  try { at = await accessToken(sa); } catch (e) { console.error('[push]', e); return; }
  let sent = 0;
  await Promise.all(rows.map(async ({ token, platform }) => {
    // new app (1.1+): loud custom sound + vibration on the "alerts" channel
    // PRIORITY_MAX + public: shows as a heads-up alert on the lock screen; high priority + 1 day TTL so a sleeping phone still gets it when it wakes
    const common = { notification_priority: 'PRIORITY_MAX', visibility: 'PUBLIC' };
    const andr = platform === 'android2' ? { ...common, channel_id: 'alerts', sound: 'alert', default_vibrate_timings: false, vibrate_timings: ['0s', '0.4s', '0.2s', '0.4s', '0.2s', '0.6s'] } : { ...common, channel_id: 'chats', sound: 'default' };
    // newest app (android3): data-only message → our own receiver shows it (also when the app is closed) and can ring on silent
    const msg = platform === 'android3' || platform === 'android4'
      ? { token, data: { ...data, af: '1', title, body: body.slice(0, data.test ? 300 : 180), ...(!ringOff && (opts.force || ((opts.alarm || (s.alarm_scope !== 'leads' && !!data.lead_id && !data.test)) && ringNow(s))) ? { alarm: '1' } : {}), ...soundData(s) }, android: { priority: 'HIGH', ttl: '86400s' } }
      : { token, notification: { title, body: body.slice(0, 180) }, data, android: { priority: 'HIGH', ttl: '86400s', notification: andr } };
    try {
      const r = await fetch(`${FCM()}/v1/projects/${sa.project_id}/messages:send`, {
        method: 'POST', headers: { authorization: `Bearer ${at}`, 'content-type': 'application/json' },
        body: JSON.stringify({ message: msg }),
      });
      if (r.ok) sent++;
      if (r.status === 404 || r.status === 400) {
        const t = await r.text();
        if (/UNREGISTERED|INVALID_ARGUMENT|not a valid FCM/i.test(t)) run('DELETE FROM push_tokens WHERE token=?', token);
      }
    } catch (e) { console.error('[push]', e); }
  }));
  return sent;
}

/** v135: Admin → test notification to every phone that has the app installed and logged in (agents, manager, admins) —
 *  also to agents who are paused / not taking leads. Plays the team sound and always rings, even on silent / vibrate (any time). */
export async function pushTest(agentId: number | null = null, o: { text?: unknown; to?: unknown; only?: unknown } = {}) {
  const s = getSettings();
  if (!s.fcm_service_account) return { ok: false, error: 'Phone notifications are not set up (Admin → System → Firebase key).', people: [] as { name: string; phones: number; got: number }[], at: Date.now() };
  // v137: the admin's own message (optional) and who gets it: all / agents / admin phones
  // v139: one person too: 'agent:<id>' (manager / one agent) → only that person's phones
  const one1 = /^agent:(\d+)$/.exec(String(o.to ?? ''));
  if (one1) agentId = Number(one1[1]);
  const to = one1 ? 'agents' : o.to === 'agents' || o.to === 'admins' ? o.to : 'all';
  const own = String(o.text ?? '').replace(/\s+$/g, '').trim().slice(0, 300);
  const who = to === 'admins' ? [] : all<{ id: number; name: string; role: string; n: number }>(`SELECT a.id, a.name, a.role, COUNT(t.token) n FROM agents a JOIN push_tokens t ON t.role='agent' AND t.user_id=a.id
    WHERE a.deleted=0 ${agentId ? 'AND a.id=?' : ''} GROUP BY a.id ORDER BY a.role='manager' DESC, a.name`, ...(agentId ? [agentId] : []));
  const at = new Date(Date.now() + (Number(s.tz_offset_min) || 0) * 60000).toISOString().slice(11, 19);
  const title = own ? 'Message from Admin' : 'Test notification', body = own || `This is a test notification from ${s.brand_name || 'AdsBhai'}. Sent at ${at} — if it shows much later, the phone is holding back notifications.`;
  const t0 = Date.now();
  // v137: only these people ('agent:<id>' / 'admin:0') — the sound-sync flow sends the test first to phones that saved the new sound
  const only = Array.isArray(o.only) ? new Set(o.only.map(String)) : null;
  const people = await Promise.all(who.filter(a => !only || only.has('agent:' + a.id)).map(async a => ({ name: a.name + (a.role === 'manager' ? ' (manager)' : ''), role: 'agent', user_id: a.id, phones: a.n, ring_off: ringOffFor('agent', a.id, s), got: (await pushTo('agent', a.id, title, body, { test: '1' }, { force: true })) || 0 })));
  if (!agentId && to !== 'agents' && (!only || only.has('admin:0'))) {
    const n = all<{ token: string }>("SELECT token FROM push_tokens WHERE role='admin'").length;
    if (n) people.push({ name: 'Admin phones', role: 'admin', user_id: 0, phones: n, ring_off: ringOffFor('admin', null, s), got: (await pushTo('admin', null, title, body, { test: '1' }, { force: true })) || 0 });
  }
  // v139: who got a test → a phone that never reports back is flagged in "Phones registered"
  for (const p of people) if (p.got > 0) run('INSERT INTO push_tests(k, role, user_id, at) VALUES(?,?,?,?) ON CONFLICT(k) DO UPDATE SET at=excluded.at', `${p.role}:${p.user_id}`, p.role, p.user_id, t0);
  return { ok: true, people, at: t0, title, body, to };
}

/** v137: the admin uploaded / changed the sound → a silent data push makes every phone download it now (nothing is shown). */
/** v139: who a sound sync / status is for: all · agents · admins · agent:<id> (one person). Safe SQL (id is a number). */
function whoSql(to: unknown, p: string) {
  const m = /^agent:(\d+)$/.exec(String(to ?? ''));
  if (m) return ` AND ${p}role='agent' AND ${p}user_id=${Number(m[1])}`;
  return to === 'agents' ? ` AND ${p}role='agent'` : to === 'admins' ? ` AND ${p}role='admin'` : '';
}
export async function pushSoundSync(to: unknown = 'all') {
  const s = getSettings();
  if (!s.fcm_service_account) return { ok: false, sent: 0, phones: 0, error: 'Phone notifications are not set up (Admin → System → Firebase key).' };
  let sa: { client_email: string; private_key: string; project_id: string; token_uri?: string };
  try { sa = JSON.parse(s.fcm_service_account); } catch { return { ok: false, sent: 0, phones: 0, error: 'Firebase key is not valid JSON' }; }
  const w = whoSql(to, '');
  const rows = all<{ token: string }>(`SELECT token FROM push_tokens WHERE platform IN ('android3','android4')${w}`);
  if (!rows.length) return { ok: true, sent: 0, phones: 0 };
  let at: string;
  try { at = await accessToken(sa); } catch (e) { return { ok: false, sent: 0, phones: rows.length, error: (e as Error).message }; }
  const data = { af: '1', snd_sync: '1', ...soundData(s) };
  let sent = 0;
  await Promise.all(rows.map(({ token }) => fetch(`${FCM()}/v1/projects/${sa.project_id}/messages:send`, {
    method: 'POST', headers: { authorization: `Bearer ${at}`, 'content-type': 'application/json' },
    body: JSON.stringify({ message: { token, data, android: { priority: 'HIGH', ttl: '86400s' } } }),
  }).then(r => { if (r.ok) sent++; }).catch(() => null)));
  return { ok: true, sent, phones: rows.length, ver: soundData(s).snd || '', at: Date.now() };
}

/* ---------- v137: ring reports (what the phone played for the last alert, and why) ---------- */
const S = (v: unknown, n = 200) => String(v ?? '').slice(0, n);
export function saveRingReport(role: 'agent' | 'admin', userId: number, b: Record<string, unknown>) {
  const device = S(b.device, 80) || 'phone';
  const played = ['own', 'builtin', 'channel', 'none'].includes(String(b.played)) ? String(b.played) : 'none';
  const reason = S(b.error || b.own_sound_error || b.service_error || '', 300);
  // v137: a phone saved (or failed to save) the own sound → kept per phone for the "Saving sound…" list
  const ver = S(b.snd_ver, 40);
  if (ver && (b.kind === 'sync' || b.own_downloaded !== undefined)) {
    const okSaved = b.own_downloaded === true || b.ok === true;
    run(`INSERT INTO sound_saves(k, role, user_id, device, ver, ok, error, at) VALUES(?,?,?,?,?,?,?,?)
      ON CONFLICT(k) DO UPDATE SET ver=excluded.ver, ok=excluded.ok, error=excluded.error, at=excluded.at`, `${role}:${userId}:${device}`, role, userId, device, ver, okSaved ? 1 : 0, okSaved ? '' : S(b.own_sound_error || b.error || 'not saved', 200), Date.now());
  }
  const keep = ['kind', 'snd_ver', 'alarm_flag', 'ringer_mode', 'alarm_volume', 'alarm_volume_max', 'own_sound', 'own_downloaded', 'own_file', 'own_sound_error', 'played', 'player', 'via', 'focus', 'error', 'service_error', 'app_version', 'device', 'android', 'test'];
  const data = JSON.stringify(Object.fromEntries(keep.filter(k => b[k] !== undefined).map(k => [k, typeof b[k] === 'object' ? S(JSON.stringify(b[k])) : typeof b[k] === 'string' ? S(b[k], 300) : b[k]])));
  // v139: a ring report comes only from the new app → that person's tokens from the same phone (or their only token) are android4
  upgradeTokens(role, userId, device);
  run(`INSERT INTO push_reports(k, role, user_id, device, at, kind, played, reason, data) VALUES(?,?,?,?,?,?,?,?,?)
    ON CONFLICT(k) DO UPDATE SET at=excluded.at, kind=excluded.kind, played=excluded.played, reason=excluded.reason, data=excluded.data`,
    `${role}:${userId}:${device}`, role, userId, device, Date.now(), S(b.kind, 20) || 'alert', played, reason, data);
  return { ok: true };
}
/** v139: proof of the new app (ring report / native call) → android/2/3 rows of this person on this phone become android4. */
export function upgradeTokens(role: string, userId: number, device: string) {
  const rows = all<{ token: string; device: string | null }>("SELECT token, device FROM push_tokens WHERE role=? AND user_id=? AND platform IN ('android','android2','android3')", role, userId);
  const all4 = one<{ n: number }>('SELECT COUNT(*) n FROM push_tokens WHERE role=? AND user_id=?', role, userId)!.n;
  let n = 0;
  for (const r of rows) {
    if ((r.device && r.device === device) || (!r.device && all4 === 1)) { run("UPDATE push_tokens SET platform='android4', device=COALESCE(device, ?) WHERE token=?", device, r.token); n++; }
  }
  return n;
}
export function ringReports(since = 0) {
  return all<{ k: string; role: string; user_id: number; device: string; at: number; kind: string; played: string; reason: string; data: string; name: string | null }>(
    "SELECT r.*, CASE WHEN r.role='admin' THEN 'Admin' ELSE (SELECT name FROM agents a WHERE a.id=r.user_id) END name FROM push_reports r WHERE r.at>=? ORDER BY r.at DESC LIMIT 100", since)
    .map(r => ({ ...r, data: (() => { try { return JSON.parse(r.data); } catch { return {}; } })() }));
}

/** v134: this chat was read → its notification disappears on the phones of its agent and the admins (app 1.4+, silent). */
export async function pushClear(leadId: number, agentId: number | null) {
  const s = getSettings();
  if (!s.fcm_service_account) return;
  let sa: { client_email: string; private_key: string; project_id: string; token_uri?: string };
  try { sa = JSON.parse(s.fcm_service_account); } catch { return; }
  const rows = all<{ token: string }>("SELECT token FROM push_tokens WHERE platform='android4' AND (role='admin' OR (role='agent' AND user_id=?))", agentId ?? -1);
  if (!rows.length) return;
  let at: string;
  try { at = await accessToken(sa); } catch { return; }
  await Promise.all(rows.map(({ token }) => fetch(`${FCM()}/v1/projects/${sa.project_id}/messages:send`, {
    method: 'POST', headers: { authorization: `Bearer ${at}`, 'content-type': 'application/json' },
    body: JSON.stringify({ message: { token, data: { af: '1', clear: String(leadId) }, android: { priority: 'NORMAL', ttl: '3600s' } } }),
  }).catch(() => null)));
}

export const PUSH_PLATFORMS = ['android', 'android2', 'android3', 'android4', 'ios'];
/** v139: a phone registered its push token (from the app's JS or straight from Java). A native call or the app's own
 *  pushPlatform() proves the new app (our push receiver) → android4, never downgraded by an older JS path afterwards. */
export function registerToken(role: 'agent' | 'admin', userId: number, token: string, platform = 'android', extra: { native?: boolean; app_version?: unknown; device?: unknown } = {}) {
  token = String(token || '').trim();
  if (!token || token.length > 4096 || /\s/.test(token)) return { ok: false, error: 'bad token' };
  let pf = PUSH_PLATFORMS.includes(platform) ? platform : 'android';
  if (extra.native) pf = 'android4';
  const old = one<{ platform: string }>('SELECT platform FROM push_tokens WHERE token=?', token);
  if (old?.platform === 'android4' && pf !== 'android4' && pf !== 'ios') pf = 'android4'; // same token = same app; keep the proven value
  const t = Date.now();
  run(`INSERT INTO push_tokens(token, role, user_id, platform, updated_at, app_version, device, via, created_at) VALUES(?,?,?,?,?,?,?,?,?)
    ON CONFLICT(token) DO UPDATE SET role=excluded.role, user_id=excluded.user_id, platform=excluded.platform, updated_at=excluded.updated_at,
      app_version=COALESCE(excluded.app_version, push_tokens.app_version), device=COALESCE(excluded.device, push_tokens.device), via=excluded.via`,
    token, role, userId, pf, t, S(extra.app_version, 20) || null, S(extra.device, 80) || null, extra.native ? 'native' : 'js', t);
  console.log(`[push] registered ${role}:${userId} ${pf} via ${extra.native ? 'native' : 'js'}${extra.device ? ' · ' + S(extra.device, 80) : ''}`);
  return { ok: true, platform: pf };
}
/** v143: the app was opened on a phone (every start) — kept apart from the registration, so "registered Nov 21" next to
 *  "app opened 5 min ago" shows that the phone opens the app but its registration does not reach the server. */
export function noteSeen(role: 'agent' | 'admin', userId: number, b: Record<string, unknown>, ua = '') {
  run(`INSERT INTO app_seen(role, user_id, at, app_version, build, platform, native, plugin, ua) VALUES(?,?,?,?,?,?,?,?,?)
    ON CONFLICT(role, user_id) DO UPDATE SET at=excluded.at, app_version=COALESCE(NULLIF(excluded.app_version,''), app_seen.app_version), build=COALESCE(NULLIF(excluded.build,''), app_seen.build),
      platform=excluded.platform, native=excluded.native, plugin=excluded.plugin, ua=excluded.ua`,
    role, userId, Date.now(), S(b.app_version, 20), S(b.build, 20), S(b.platform, 20), b.native ? 1 : 0, b.plugin ? 1 : 0, S(ua, 160));
  return { ok: true };
}
/** v139: a step of the phone's push setup failed (permission, token, register…) → kept for Admin → Phone notifications. */
export function savePushDebug(role: 'agent' | 'admin', userId: number, b: Record<string, unknown>) {
  run('INSERT INTO push_debug(role, user_id, stage, error, platform, perm, version, device, at) VALUES(?,?,?,?,?,?,?,?,?)', role, userId, S(b.stage, 40) || 'unknown', S(b.error, 300), S(b.platform, 20), S(b.perm, 40), S(b.version, 20), S(b.device, 80), Date.now());
  run('DELETE FROM push_debug WHERE at<?', Date.now() - 30 * 86400000);
  return { ok: true };
}
/** v139: Admin → Phone notifications → "Phones registered": every token with who / app / when, the last setup error of
 *  that person, and "old app" for rows not refreshed in 7 days or from an app without our push receiver. */
export function pushPhones() {
  const rows = all<{ token: string; role: string; user_id: number; platform: string; updated_at: number; created_at: number | null; app_version: string | null; device: string | null; via: string | null; name: string | null; deleted: number | null }>(
    "SELECT t.token, t.role, t.user_id, t.platform, t.updated_at, t.created_at, t.app_version, t.device, t.via, CASE WHEN t.role='admin' THEN 'Admin' ELSE a.name END name, a.deleted FROM push_tokens t LEFT JOIN agents a ON t.role='agent' AND a.id=t.user_id ORDER BY t.updated_at DESC LIMIT 200");
  const t = Date.now();
  const lastErr = (role: string, uid: number) => one<{ stage: string; error: string; at: number }>('SELECT stage, error, at FROM push_debug WHERE role=? AND user_id=? ORDER BY id DESC LIMIT 1', role, uid);
  return rows.filter(r => !r.deleted).map(r => {
    const e = lastErr(r.role, r.user_id);
    let old = !['android4', 'ios'].includes(r.platform) || t - r.updated_at > 7 * 86400000;
    // v139: android4 but no ring report and no registration in the 5+ minutes after a test → maybe still an old app on that phone
    const tst = one<{ at: number }>('SELECT at FROM push_tests WHERE k=?', `${r.role}:${r.user_id}`);
    const quiet = !old && r.platform === 'android4' && !!tst && t - tst.at > 5 * 60000 && r.updated_at < tst.at
      && !one('SELECT 1 FROM push_reports WHERE role=? AND user_id=? AND at>=?', r.role, r.user_id, tst.at);
    if (quiet) old = true;
    // v143: last time the app was opened by this person (on a phone), and its version — apart from the registration time
    const seen = one<{ at: number; app_version: string | null; native: number; platform: string | null }>('SELECT at, app_version, native, platform FROM app_seen WHERE role=? AND user_id=?', r.role, r.role === 'admin' ? 0 : r.user_id);
    const lastSeen = r.role === 'agent' ? Math.max(seen?.at || 0, one<{ v: number | null }>('SELECT last_seen v FROM agents WHERE id=?', r.user_id)?.v || 0) : seen?.at || 0;
    const notReaching = !!seen?.native && seen.at - r.updated_at > 30 * 60000; // the app was opened since, but never registered again
    return { key: r.token.slice(-10), registered_at: r.updated_at, first_at: (r as { created_at?: number | null }).created_at || null, seen_at: lastSeen || null, seen_version: seen?.app_version || null, not_reaching: notReaching,
      reg_hint: notReaching ? `The app was opened ${new Date(seen!.at).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })} but did not register again${seen!.app_version ? ` (app ${seen!.app_version})` : ''} — install the latest APK on this phone.` : '', role: r.role, user_id: r.user_id, name: r.name || (r.role === 'admin' ? 'Admin' : 'Agent'), platform: r.platform, app_version: r.app_version, device: r.device, via: r.via, at: r.updated_at,
      old, old_why: !['android4', 'ios'].includes(r.platform) ? 'old app – open the new app' : quiet ? 'this phone may have an old app – no ring report after the last test' : old ? 'not refreshed for 7+ days – open the new app' : '',
      last_error: e && e.at >= r.updated_at - 60000 ? `${e.stage}: ${e.error}` : '', last_error_at: e?.at || null };
  });
}

/** v137: "Saving sound…" — per person (the phones that got the sync push): saved / waiting / error, since the sync was sent. */
export function soundSyncStatus(since: number, ver: string, to: unknown = 'all') {
  const people: { key: string; name: string; phones: number; saved: number; failed: number; error: string; state: 'saved' | 'waiting' | 'error' }[] = [];
  const rows = all<{ role: string; user_id: number; n: number; name: string | null; mgr: number }>(`SELECT t.role, t.user_id, COUNT(*) n, a.name, a.role='manager' mgr FROM push_tokens t LEFT JOIN agents a ON t.role='agent' AND a.id=t.user_id
    WHERE t.platform IN ('android3','android4') AND (t.role='admin' OR a.deleted=0) ${whoSql(to, 't.')} GROUP BY t.role, t.user_id ORDER BY t.role='admin', mgr DESC, a.name`);
  for (const r of rows) {
    const sv = all<{ ok: number; error: string }>('SELECT ok, error FROM sound_saves WHERE role=? AND user_id=? AND ver=? AND at>=?', r.role, r.role === 'admin' ? 0 : r.user_id, ver, since);
    const saved = sv.filter(x => x.ok).length, failed = sv.filter(x => !x.ok).length;
    people.push({ key: `${r.role}:${r.role === 'admin' ? 0 : r.user_id}`, name: r.role === 'admin' ? 'Admin phones' : (r.name || 'Agent') + (r.mgr ? ' (manager)' : ''), phones: r.n, saved, failed,
      error: sv.find(x => !x.ok)?.error || '', state: saved >= r.n || (saved > 0 && saved + failed >= r.n) ? 'saved' : failed >= r.n ? 'error' : 'waiting' });
  }
  return { people, done: people.every(p => p.state !== 'waiting') };
}

/** v168: Daily reel ready → a SILENT data-only push {type:'reel_ready'} so the app (1.7+) downloads it in the background
 *  (ReelPrefetchWorker). No notification payload and no "af" key: the 1.7 receiver handles it before anything is shown,
 *  and older apps' receivers (which only show messages with af=1) ignore it. Normal priority (no wake-up needed; a high
 *  priority message that shows nothing would be deprioritised by FCM). who = 'agents' (all normal agents) or the picked
 *  people ('admin', 'a:<id>'). */
export async function pushReelReady(who: 'agents' | string[], reelId: number) {
  const s = getSettings();
  if (!s.fcm_service_account) return { sent: 0, phones: 0 };
  let sa: { client_email: string; private_key: string; project_id: string; token_uri?: string };
  try { sa = JSON.parse(s.fcm_service_account); } catch { return { sent: 0, phones: 0 }; }
  let rows: { token: string }[];
  if (who === 'agents') rows = all<{ token: string }>("SELECT t.token FROM push_tokens t JOIN agents a ON a.id=t.user_id WHERE t.role='agent' AND t.platform='android4' AND a.deleted=0 AND COALESCE(a.role,'agent')!='manager'");
  else {
    const ids = who.map(k => /^a:(\d+)$/.exec(k)).filter(Boolean).map(m => Number(m![1]));
    rows = [
      ...(ids.length ? all<{ token: string }>(`SELECT token FROM push_tokens WHERE role='agent' AND platform='android4' AND user_id IN (${ids.map(() => '?').join(',')})`, ...ids) : []),
      ...(who.includes('admin') ? all<{ token: string }>("SELECT token FROM push_tokens WHERE role='admin' AND platform='android4'") : []),
    ];
  }
  if (!rows.length) return { sent: 0, phones: 0 };
  let at: string;
  try { at = await accessToken(sa); } catch { return { sent: 0, phones: rows.length }; }
  let sent = 0;
  await Promise.all(rows.map(({ token }) => fetch(`${FCM()}/v1/projects/${sa.project_id}/messages:send`, {
    method: 'POST', headers: { authorization: `Bearer ${at}`, 'content-type': 'application/json' },
    body: JSON.stringify({ message: { token, data: { type: 'reel_ready', reel_id: String(reelId) }, android: { priority: 'NORMAL', ttl: '21600s' } } }),
  }).then(r => { if (r.ok) sent++; }).catch(() => null)));
  return { sent, phones: rows.length };
}
