/** v160: the client sees a top-up waiting in our queue.
 *  Approved (or done by the manager) → "⏳ Your top-up is approved and in the queue · starting in about N min" in the client's chat.
 *  Telegram: that message counts down (edited every minute) and shows "adding it now" when the job starts.
 *  Done → the top-up image with the "Top-up done" caption goes, and the queue message is deleted.
 *  Stopped → the message says it takes a little longer (our team finishes it). WhatsApp can't edit / delete: one message only. */
import { one, all, run } from './db';
import { getSettings } from './settings';
import { now, money } from './util';
import { leadById, sendToLead } from './crm';

const usd = (n: number) => '$' + money(n).toFixed(2).replace(/\.00$/, '');
type QReq = { id: number; lead_id: number; act_id: string | null; amount: number | null; status: string; q_msg: number | null; q_eta: number | null; q_txt: string | null; job_id: number | null };

function textFor(r: QReq, state: 'wait' | 'run' | 'slow') {
  const what = `💰 ${usd(r.amount || 0)} → act_${r.act_id}`;
  if (state === 'run') return `⚙️ Your top-up is being added right now\n${what}`;
  if (state === 'slow') return `⏳ Your top-up is taking a little longer\n${what}\nOur team is on it, you'll get a message as soon as it is added.`;
  const left = Math.max(1, Math.ceil(((r.q_eta || now()) - now()) / 60000));
  return `⏳ Your top-up is approved and in the queue\n${what}\n⏱ Starting in about ${left} min`;
}
const isWa = (l: { ch?: string | null; tg_chat_id: string | null }) => l.ch === 'wa' || String(l.tg_chat_id || '').startsWith('wa:');

/** Request went into the queue → tell the client (once per request). */
export async function topupQueued(reqId: number, etaMin: number) {
  const r = one<QReq>('SELECT * FROM meta_requests WHERE id=?', reqId);
  if (!r || r.q_msg || !r.act_id || getSettings().meta_client_msgs === '0') return;
  const lead = leadById(r.lead_id) as (ReturnType<typeof leadById> & { manual_client?: number; ch?: string | null }) | undefined;
  if (!lead?.tg_chat_id || lead.manual_client) return;
  const eta = now() + Math.max(1, etaMin) * 60000;
  run('UPDATE meta_requests SET q_eta=? WHERE id=?', eta, reqId);
  const txt = textFor({ ...r, q_eta: eta }, 'wait');
  try {
    await sendToLead(lead, txt, 'agent', lead.agent_id);
    const m = one<{ id: number }>("SELECT MAX(id) id FROM messages WHERE lead_id=? AND dir='out'", lead.id);
    if (m?.id) run('UPDATE meta_requests SET q_msg=?, q_txt=? WHERE id=?', m.id, txt, reqId);
  } catch (e) { console.warn('[topupq] send', (e as Error).message); }
}

/** Edit our own Telegram message (bot / business connection). The chat account (userbot) and WhatsApp are not edited. */
async function editMsg(msgId: number, text: string) {
  const m = one<{ lead_id: number; tg_msg_id: number | null; via: string | null; deleted_at: number | null }>('SELECT lead_id, tg_msg_id, via, deleted_at FROM messages WHERE id=?', msgId);
  if (!m || m.deleted_at || !m.tg_msg_id || m.via === 'ub') return false;
  const lead = leadById(m.lead_id) as (ReturnType<typeof leadById> & { ch?: string | null }) | undefined;
  if (!lead?.tg_chat_id || isWa(lead)) return false;
  const { tg } = await import('./telegram');
  const r = await tg(getSettings(), 'editMessageText', { chat_id: lead.tg_chat_id, message_id: m.tg_msg_id, text, ...(lead.biz_conn ? { business_connection_id: lead.biz_conn } : {}) });
  if (r.ok || /not modified/i.test(String(r.description || ''))) { run('UPDATE messages SET text=? WHERE id=?', text, msgId); return true; }
  return false;
}

let ticking = false;
/** Worker, every ~30 s: the countdown / "adding it now". */
export async function tickQueued() {
  if (ticking) return;
  ticking = true;
  try {
    for (const r of all<QReq & { jstatus: string | null }>("SELECT r.*, j.status jstatus FROM meta_requests r LEFT JOIN meta_jobs j ON j.id=r.job_id WHERE r.kind='topup' AND r.q_msg>0 AND r.status IN ('queued','running') ORDER BY r.id LIMIT 20")) {
      const txt = textFor(r, r.jstatus === 'running' || r.status === 'running' ? 'run' : 'wait');
      if (txt === r.q_txt) continue;
      run('UPDATE meta_requests SET q_txt=? WHERE id=?', txt, r.id);
      try { await editMsg(r.q_msg!, txt); } catch { /* */ }
    }
  } finally { ticking = false; }
}

/** Top-up done (image + caption sent) → the queue message goes away. */
export async function topupQueueDone(reqId: number) {
  const r = one<QReq>('SELECT * FROM meta_requests WHERE id=?', reqId);
  if (!r?.q_msg) return;
  run('UPDATE meta_requests SET q_msg=NULL WHERE id=?', reqId);
  const m = one<{ lead_id: number }>('SELECT lead_id FROM messages WHERE id=?', r.q_msg);
  const lead = m ? leadById(m.lead_id) as (ReturnType<typeof leadById> & { ch?: string | null }) | undefined : undefined;
  if (!lead || isWa(lead)) return; // WhatsApp: cannot delete for the client
  try { const { deleteMessage } = await import('./msgdelete'); await deleteMessage(r.q_msg, { role: 'admin', id: null, name: 'System' }, () => true); }
  catch (e) { console.warn('[topupq] delete', (e as Error).message); }
}
/** The job stopped (manager finishes it by hand) → "taking a little longer". */
export async function topupQueueSlow(reqId: number) {
  const r = one<QReq>('SELECT * FROM meta_requests WHERE id=?', reqId);
  if (!r?.q_msg) return;
  const txt = textFor(r, 'slow');
  run('UPDATE meta_requests SET q_txt=? WHERE id=?', txt, reqId);
  try { await editMsg(r.q_msg, txt); } catch { /* */ }
}
