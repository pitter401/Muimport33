/** Proxy checker for the owner: send a proxy list (TXT file or text) to the bot → each proxy's IP, place, ISP and type (mobile / home / datacenter). */
import http from 'node:http';
import type { Settings } from './settings';
import { tg, downloadFile, msgText } from './telegram';

export type Proxy = { user: string; pass: string; host: string; port: number; raw: string };
export type Result = Proxy & {
  ok: boolean; err?: string; ip?: string; city?: string; region?: string; country?: string;
  isp?: string; as?: string; reverse?: string; kind?: 'mobile' | 'home' | 'datacenter';
};

const MAX = 50;
const isHost = (x: string) => /^[a-z0-9.-]+\.[a-z0-9-]+$/i.test(x) || /^\d{1,3}(\.\d{1,3}){3}$/.test(x);
const isPort = (x: string) => /^\d{2,5}$/.test(x) && +x > 0 && +x < 65536;

/** Reads one proxy per line: login:pass:host:port, host:port:login:pass, login:pass@host:port, http://login:pass@host:port, host:port */
export function parseProxies(text: string): Proxy[] {
  const out: Proxy[] = [];
  for (const line of text.split(/\r?\n/)) {
    const raw = line.trim().replace(/^(https?|socks5h?):\/\//i, '');
    if (!raw || raw.startsWith('#')) continue;
    let p: Proxy | null = null;
    const at = raw.lastIndexOf('@');
    if (at > 0) {
      const [cred, addr] = [raw.slice(0, at), raw.slice(at + 1)];
      const [host, port] = addr.split(':');
      const i = cred.indexOf(':');
      if (host && isHost(host) && port && isPort(port)) p = { user: i < 0 ? cred : cred.slice(0, i), pass: i < 0 ? '' : cred.slice(i + 1), host, port: +port, raw };
    } else {
      const a = raw.split(':');
      if (a.length === 4 && isHost(a[2]) && isPort(a[3])) p = { user: a[0], pass: a[1], host: a[2], port: +a[3], raw };
      else if (a.length === 4 && isHost(a[0]) && isPort(a[1])) p = { user: a[2], pass: a[3], host: a[0], port: +a[1], raw };
      else if (a.length === 2 && isHost(a[0]) && isPort(a[1])) p = { user: '', pass: '', host: a[0], port: +a[1], raw };
    }
    if (p) out.push(p);
  }
  return out;
}

const LOOKUP = () => process.env.PROXYCHECK_URL || 'http://ip-api.com/json/?fields=status,message,country,countryCode,regionName,city,isp,org,as,reverse,mobile,proxy,hosting,query';
const MOBILE_RE = /vivozap|mobile|movel|móvel|celular|cellular|wireless|\b[345]g\b|lte|gprs|\bwap\b|timbrasil|claro.?movel|nextel|jio|airtel/i;

/** Types the IP: the lookup's own mobile/hosting flags first, then the reverse hostname (e.g. *.user.vivozap.com.br = Vivo mobile). */
export function classify(j: { mobile?: boolean; hosting?: boolean; reverse?: string; isp?: string }): Result['kind'] {
  if (j.mobile || MOBILE_RE.test(j.reverse || '')) return 'mobile';
  if (j.hosting) return 'datacenter';
  return 'home';
}

export function checkProxy(p: Proxy, timeoutMs = 25000): Promise<Result> {
  return new Promise(resolve => {
    let done = false;
    const end = (r: Partial<Result>) => { if (!done) { done = true; resolve({ ...p, ok: false, ...r }); } };
    const headers: Record<string, string> = { 'User-Agent': 'Mozilla/5.0', Accept: 'application/json' };
    if (p.user) headers['Proxy-Authorization'] = 'Basic ' + Buffer.from(`${p.user}:${p.pass}`).toString('base64');
    const url = new URL(LOOKUP());
    headers.Host = url.host;
    const req = http.request({ host: p.host, port: p.port, method: 'GET', path: url.href, headers, timeout: timeoutMs }, res => {
      let body = '';
      res.setEncoding('utf8');
      res.on('data', c => { if (body.length < 20000) body += c; });
      res.on('end', () => {
        if (res.statusCode === 407) return end({ err: 'wrong login / password' });
        if (res.statusCode !== 200) return end({ err: `proxy answered ${res.statusCode}` });
        try {
          const j = JSON.parse(body);
          if (j.status && j.status !== 'success') return end({ err: j.message || 'lookup failed' });
          end({ ok: true, ip: j.query, city: j.city, region: j.regionName, country: j.countryCode || j.country, isp: j.isp || j.org, as: j.as, reverse: j.reverse || '', kind: classify(j) });
        } catch { end({ err: 'bad answer from proxy' }); }
      });
    });
    req.on('timeout', () => { req.destroy(); end({ err: 'timeout (no answer)' }); });
    req.on('error', e => end({ err: (e as any).code === 'ENOTFOUND' ? 'proxy host not found' : (e as any).code === 'ECONNREFUSED' ? 'connection refused' : String(e.message || e) }));
    req.end();
  });
}

export async function checkAll(list: Proxy[], concurrency = 5): Promise<Result[]> {
  const out: Result[] = new Array(list.length);
  let i = 0;
  await Promise.all(Array.from({ length: Math.min(concurrency, list.length) }, async () => {
    while (i < list.length) { const k = i++; out[k] = await checkProxy(list[k]); }
  }));
  return out;
}

const ICON = { mobile: '📱 MOBILE', home: '🏠 Home WiFi', datacenter: '🏢 Datacenter' } as const;

export function report(res: Result[]): string[] {
  const ipCount = new Map<string, number>();
  for (const r of res) if (r.ip) ipCount.set(r.ip, (ipCount.get(r.ip) || 0) + 1);
  const lines = res.map((r, n) => {
    const name = `${n + 1}. Port ${r.port}`;
    if (!r.ok) return `${name} — ❌ ${r.err}`;
    const dup = (ipCount.get(r.ip!) || 0) > 1 ? ' ⚠️ same IP as another port' : '';
    return `${name} — ${ICON[r.kind!]}${dup}\n   ${r.ip} · ${[r.city, r.region, r.country].filter(Boolean).join(', ')}\n   ${r.isp || ''}${r.reverse ? `\n   ${r.reverse}` : ''}`;
  });
  const ports = (k: Result['kind']) => res.filter(r => r.ok && r.kind === k).map(r => r.port);
  const mob = ports('mobile'), home = ports('home'), dc = ports('datacenter'), bad = res.filter(r => !r.ok).length;
  const sum = [
    `📊 Checked ${res.length} prox${res.length === 1 ? 'y' : 'ies'}`,
    `📱 Mobile: ${mob.length ? mob.join(', ') : 'none'}`,
    `🏠 Home WiFi: ${home.length ? home.join(', ') : 'none'}`,
    dc.length ? `🏢 Datacenter (avoid for Facebook): ${dc.join(', ')}` : '',
    bad ? `❌ Not working: ${bad}` : '',
    [...ipCount.values()].some(v => v > 1) ? '⚠️ Some ports gave the same IP — give each profile a different IP.' : '',
  ].filter(Boolean).join('\n');
  // Telegram max 4096 chars per message
  const chunks: string[] = [];
  let cur = '🔎 Proxy check\n';
  for (const l of lines) { if (cur.length + l.length + 2 > 3800) { chunks.push(cur); cur = ''; } cur += '\n' + l + '\n'; }
  if (cur.length + sum.length + 2 > 3800) { chunks.push(cur); cur = ''; }
  chunks.push(cur + '\n' + sum + '\n\nMobile check uses the IP lookup + hostname, so treat it as a strong hint, not a guarantee.');
  return chunks;
}

/** Chats allowed to use the checker: the setting list + the business owner. */
export function isProxyChat(s: Settings, chatId: string) {
  const ids = String(s.proxy_chat_ids || '').split(/[\s,]+/).filter(Boolean);
  return ids.includes(chatId) || (!!s.owner_id && s.owner_id === chatId);
}

/** True when the message is meant for the checker (a file, a /proxy command, or text with proxy lines). */
export function isProxyMsg(m: any) {
  const t = msgText(m);
  return !!m.document || /^\/(proxy|check)\b/i.test(t) || parseProxies(t).length > 0;
}

export const HELP = '🔎 Proxy checker\n\nSend me a .txt file (or paste the list) with one proxy per line, like:\nlogin:password:host:port\n\nI will check each one and tell you which ports are 📱 mobile, 🏠 home WiFi or 🏢 datacenter, with the IP, city and ISP.\n(Max 50 per check.)';

export let lastJob: Promise<void> | null = null;

/** Runs in the background so Telegram's webhook gets its answer at once (a check can take ~30 s). */
export function startProxyJob(s: Settings, m: any) {
  lastJob = runProxyJob(s, m).catch(e => console.error('[proxycheck]', e));
  return lastJob;
}

async function runProxyJob(s: Settings, m: any) {
  const chat_id = String(m.chat.id);
  const say = (text: string) => tg(s, 'sendMessage', { chat_id, text, disable_web_page_preview: true });
  let text = msgText(m);
  if (m.document) {
    if ((m.document.file_size || 0) > 300_000) { await say('⚠️ File is too big. Send a .txt with up to 50 proxies.'); return; }
    const f = await downloadFile(s, m.document.file_id);
    if (!f?.res.ok) { await say('⚠️ Could not read the file. Try again or paste the list as text.'); return; }
    text = await f.res.text();
  }
  let list = parseProxies(text);
  if (!list.length) { await say(m.document ? '⚠️ No proxies found in this file.\n\n' + HELP : HELP); return; }
  const extra = list.length > MAX ? list.length - MAX : 0;
  list = list.slice(0, MAX);
  await say(`⏳ Checking ${list.length} prox${list.length === 1 ? 'y' : 'ies'}… (up to 30 seconds)` + (extra ? `\n(Only the first ${MAX}; ${extra} skipped.)` : ''));
  const res = await checkAll(list);
  for (const c of report(res)) await say(c);
}
