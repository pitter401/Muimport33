// v168: one WhatsApp message = one row in a chat.
//  1. Rows that are the same WhatsApp message twice (same chat + same wa_id) → the first (lowest id) is kept; replies /
//     delete-log entries that pointed at a removed copy point at the kept row; a file only the copy had moves to the kept row.
//  2. The "Owner (phone)" photo that is only WhatsApp's echo of an image WE sent as a document (v167 bug: kind photo ≠ file,
//     so the echo was saved as a new message) → removed; our row becomes the photo it really was (and is marked as echoed).
//  3. A UNIQUE index on messages(lead_id, wa_id) for rows with a wa_id → a second copy can never be saved again
//     (the inserts use INSERT OR IGNORE, so a duplicate webhook never fails).
// Runs once (settings flag), in ONE transaction: on any error nothing changes and it is tried again at the next start.
import type Database from 'better-sqlite3';

export const MIG168_FLAG = '_mig_v168_waid';
const IMG_NAME = "(lower(m.file_name) LIKE '%.png' OR lower(m.file_name) LIKE '%.jpg' OR lower(m.file_name) LIKE '%.jpeg' OR lower(m.file_name) LIKE '%.webp' OR lower(m.file_name) LIKE '%.heic' OR lower(m.file_name) LIKE '%.heif')";

export function mig168(d: Database.Database, log: (s: string) => void = s => console.log(s)) {
  if (d.prepare('SELECT 1 FROM settings WHERE k=?').get(MIG168_FLAG)) {
    // flag set but the index missing (e.g. a restored backup) → only the index; it can't fail on a clean table
    try { d.exec('CREATE UNIQUE INDEX IF NOT EXISTS u_msg_lead_waid ON messages(lead_id, wa_id) WHERE wa_id IS NOT NULL'); } catch (e) { log('[db] v168 index: ' + (e as Error).message); }
    return null;
  }
  try {
    const res = d.transaction(() => {
      // 1. same chat + same WhatsApp id
      d.exec(`DROP TABLE IF EXISTS temp._m168;
        CREATE TEMP TABLE _m168 AS SELECT m.id dup, k.keep FROM messages m
          JOIN (SELECT lead_id, wa_id, MIN(id) keep FROM messages WHERE wa_id IS NOT NULL GROUP BY lead_id, wa_id HAVING COUNT(*) > 1) k
            ON k.lead_id=m.lead_id AND k.wa_id=m.wa_id WHERE m.id<>k.keep;
        CREATE INDEX temp._m168_dup ON _m168(dup);`);
      const dups = (d.prepare('SELECT COUNT(*) n FROM _m168').get() as { n: number }).n;
      if (dups) {
        d.exec(`UPDATE messages SET file_id=(SELECT c.file_id FROM _m168 x JOIN messages c ON c.id=x.dup WHERE x.keep=messages.id AND c.file_id IS NOT NULL ORDER BY c.id LIMIT 1),
                  file_type=COALESCE(file_type, (SELECT c.file_type FROM _m168 x JOIN messages c ON c.id=x.dup WHERE x.keep=messages.id AND c.file_id IS NOT NULL ORDER BY c.id LIMIT 1))
                WHERE file_id IS NULL AND id IN (SELECT keep FROM _m168) AND EXISTS (SELECT 1 FROM _m168 x JOIN messages c ON c.id=x.dup WHERE x.keep=messages.id AND c.file_id IS NOT NULL);
          UPDATE messages SET read_at=COALESCE(read_at, (SELECT MIN(c.read_at) FROM _m168 x JOIN messages c ON c.id=x.dup WHERE x.keep=messages.id)),
                  delivered_at=COALESCE(delivered_at, (SELECT MIN(c.delivered_at) FROM _m168 x JOIN messages c ON c.id=x.dup WHERE x.keep=messages.id))
                WHERE id IN (SELECT keep FROM _m168);
          UPDATE messages SET reply_to=(SELECT keep FROM _m168 WHERE dup=messages.reply_to) WHERE reply_to IN (SELECT dup FROM _m168);
          UPDATE msg_deletes SET msg_id=(SELECT keep FROM _m168 WHERE dup=msg_deletes.msg_id) WHERE msg_id IN (SELECT dup FROM _m168);
          DELETE FROM messages WHERE id IN (SELECT dup FROM _m168);`);
      }
      d.exec('DROP TABLE temp._m168');
      // 2. the echo of an image we sent as a document, saved as "Owner (phone)" photo within 3 minutes after it (1 : 1)
      const pairs = d.prepare(`SELECT o.id oid, o.wa_id, o.lead_id, o.created_at FROM messages o JOIN leads l ON l.id=o.lead_id
          WHERE l.tg_chat_id LIKE 'wa:%' AND o.dir='out' AND o.sender='owner' AND o.file_type='photo' AND o.wa_id IS NOT NULL ORDER BY o.id`).all() as { oid: number; wa_id: string; lead_id: number; created_at: number; mid?: number | null }[];
      // v168 (senior review): the first candidate NOT already paired (two images sent in a row → two echoes → both matched)
      const cand = d.prepare(`SELECT m.id FROM messages m WHERE m.lead_id=? AND m.dir='out' AND m.sender IN ('admin','agent','ai','bot')
            AND m.wa_echo IS NULL AND m.file_type='document' AND ${IMG_NAME} AND m.created_at BETWEEN ? AND ? ORDER BY m.id`);
      const used = new Set<number>();
      let echoes = 0;
      const fix = d.prepare("UPDATE messages SET file_type='photo', wa_echo=1, wa_id2=COALESCE(wa_id2, ?), delivered_at=COALESCE(delivered_at, (SELECT delivered_at FROM messages WHERE id=?)), read_at=COALESCE(read_at, (SELECT read_at FROM messages WHERE id=?)) WHERE id=?");
      const rep = d.prepare('UPDATE messages SET reply_to=? WHERE reply_to=?');
      const del = d.prepare('DELETE FROM messages WHERE id=?');
      const repDel = d.prepare('UPDATE msg_deletes SET msg_id=? WHERE msg_id=?'); // v168 (senior review): as step 1
      for (const p of pairs) {
        p.mid = (cand.all(p.lead_id, p.created_at - 180000, p.created_at) as { id: number }[]).map(r => r.id).find(id => !used.has(id)) ?? null;
        if (!p.mid) continue;
        used.add(p.mid);
        fix.run(p.wa_id, p.oid, p.oid, p.mid); rep.run(p.mid, p.oid); repDel.run(p.mid, p.oid); del.run(p.oid);
        echoes++;
      }
      // 3. the guard
      d.exec('CREATE UNIQUE INDEX IF NOT EXISTS u_msg_lead_waid ON messages(lead_id, wa_id) WHERE wa_id IS NOT NULL');
      d.prepare('INSERT OR IGNORE INTO settings(k, v) VALUES(?, ?)').run(MIG168_FLAG, JSON.stringify({ at: Date.now(), dups, echoes }));
      return { dups, echoes };
    })();
    if (res.dups || res.echoes) log(`[db] v168: removed ${res.dups} duplicate WhatsApp row(s), ${res.echoes} echo copy(ies) of our images`);
    return res;
  } catch (e) { log('[db] v168 migration failed (nothing changed, tried again next start): ' + (e as Error).message); return null; }
}
