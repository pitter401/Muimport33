/** v134: the team's notification sound. Default = the built-in alert; the admin can upload our own (Admin → Settings → Agent app).
 *  Saved next to the database (data/brand/) so it survives updates. Phones download it once per version (push data snd / snd_url). */
import fs from 'fs';
import path from 'path';
import { getSettings, setSetting, type Settings } from './settings';
import { HttpError } from './util';
import { publicUrl } from './email';

const DIR = () => path.join(path.dirname(process.env.DB_PATH || path.join(process.cwd(), 'data', 'adflow.db')), 'brand');
const TYPES: Record<string, string> = { 'audio/mpeg': 'mp3', 'audio/mp3': 'mp3', 'audio/ogg': 'ogg', 'audio/opus': 'ogg', 'audio/wav': 'wav', 'audio/x-wav': 'wav', 'audio/wave': 'wav', 'audio/mp4': 'm4a', 'audio/x-m4a': 'm4a', 'audio/m4a': 'm4a', 'audio/aac': 'aac' };
const EXT_TYPE: Record<string, string> = { mp3: 'audio/mpeg', ogg: 'audio/ogg', wav: 'audio/wav', m4a: 'audio/mp4', aac: 'audio/aac' };
export const MAX_SOUND = 1024 * 1024;

export async function saveNotifSound(file: File | null) {
  const dir = DIR();
  fs.mkdirSync(dir, { recursive: true });
  const old = getSettings().notif_sound_file;
  if (old) try { fs.unlinkSync(path.join(dir, old)); } catch { /* gone */ }
  if (!file) { setSetting('notif_sound_file', ''); setSetting('notif_sound', 'default'); setSetting('notif_sound_ver', String(Date.now())); return; }
  const byName = (file.name.split('.').pop() || '').toLowerCase();
  const ext = TYPES[file.type] || (EXT_TYPE[byName] ? byName : '');
  if (!ext) throw new HttpError(400, 'Sound must be MP3, OGG, M4A, AAC or WAV');
  if (file.size > MAX_SOUND) throw new HttpError(400, 'Sound must be smaller than 1 MB (a short 1–3 second sound is best)');
  if (file.size < 200) throw new HttpError(400, 'This file is empty');
  const name = `notif.${ext}`;
  fs.writeFileSync(path.join(dir, name), Buffer.from(await file.arrayBuffer()));
  setSetting('notif_sound_file', name);
  setSetting('notif_sound', 'own');
  setSetting('notif_sound_ver', String(Date.now()));
}

export function readNotifSound(): { buf: Buffer; type: string } | null {
  const f = getSettings().notif_sound_file;
  if (!f) return null;
  try { return { buf: fs.readFileSync(path.join(DIR(), f)), type: EXT_TYPE[f.split('.').pop()!] || 'application/octet-stream' }; } catch { return null; }
}

/** Our own sound in use → its version ('' = the built-in sound). */
export const ownSoundVer = (s: Settings = getSettings()) => s.notif_sound === 'own' && s.notif_sound_file ? s.notif_sound_ver || '1' : '';
export const ownSoundPath = (ver: string) => `/api/notif-sound?v=${encodeURIComponent(ver)}`;
/** Push data for the phone apps. */
export function soundData(s: Settings = getSettings()): Record<string, string> {
  const v = ownSoundVer(s);
  return v ? { snd: v, snd_url: publicUrl() + ownSoundPath(v) } : {};
}
