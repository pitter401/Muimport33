/**
 * v150 — Comments: every comment on our Facebook Page (normal posts + all ACTIVE ads) and on the ads' Instagram posts
 * (page-backed Instagram, no Instagram account needed) lands in Admin → Comments.
 *  - Scam / fake / abuse / competitor promo (links, phone numbers) → "Delete" label; auto-deleted when Auto-delete is ON.
 *  - Not sure → "Check"; normal → OK. The admin can delete anything by hand (Facebook + Instagram).
 *  - Every Meta call goes through the admin's own proxy (http or socks5), never the VPS IP.
 *  - Token: the short token from Graph API Explorer is changed into a 60-day user token; the Page token made from it never
 *    expires. A reminder comes 7 days before the user token ends (needed for the ads / Instagram part).
 */
import { all, one, run } from './db';
import { getSettings, setSetting, type Settings } from './settings';
import { graph, graphAll, parseProxy, MetaError, type Creds } from './metagraph';
import { now, HttpError } from './util';
import { pushTo } from './push';

const DAY = 86400000;
export type CmLabel = '' | 'bad' | 'doubt' | 'ok';
export type CmRow = {
  id: string; src: 'fb' | 'ig'; target: string; ad_id: string | null; ad_name: string | null; kind: 'ad' | 'post';
  author: string | null; author_id: string | null; text: string; created_at: number; seen_at: number;
  label: CmLabel; reason: string | null; status: 'live' | 'deleted' | 'auto_deleted' | 'gone'; deleted_at: number | null; deleted_by: string | null; permalink: string | null;
};

export function ensureCmTables() {
  run(`CREATE TABLE IF NOT EXISTS fb_comments(id TEXT PRIMARY KEY, src TEXT, target TEXT, ad_id TEXT, ad_name TEXT, kind TEXT, author TEXT, author_id TEXT, text TEXT,
       created_at INTEGER, seen_at INTEGER, label TEXT DEFAULT '', reason TEXT, status TEXT DEFAULT 'live', deleted_at INTEGER, deleted_by TEXT, permalink TEXT)`);
  run('CREATE INDEX IF NOT EXISTS fb_comments_t ON fb_comments(created_at)');
  run(`CREATE TABLE IF NOT EXISTS fb_ads(ad_id TEXT PRIMARY KEY, name TEXT, acct TEXT, fb_post TEXT, ig_media TEXT, ig_link TEXT, active INTEGER, seen_at INTEGER)`);
}

/* ---------------- credentials ---------------- */
const proxyOf = (s: Settings) => String(s.cm_proxy || '').trim();
const userCreds = (s: Settings): Creds => ({ token: s.cm_user_token, secret: s.cm_app_secret || undefined, proxy: proxyOf(s) });
const pageCreds = (s: Settings): Creds => ({ token: s.cm_page_token, secret: s.cm_app_secret || undefined, proxy: proxyOf(s) });
export const cmReady = (s: Settings = getSettings()) => !!(s.cm_page_token && s.cm_page_id);

function needProxy(s: Settings) {
  const p = proxyOf(s);
  if (!p) throw new HttpError(400, 'Add your proxy first (the same one your Facebook profile uses) — Meta calls never go from the server IP');
  try { parseProxy(p); } catch (e) { throw new HttpError(400, (e as Error).message); }
}

/** Admin pastes App ID + App Secret + the token from Graph API Explorer (+ proxy). */
export async function cmConnect(b: { app_id?: unknown; app_secret?: unknown; token?: unknown; proxy?: unknown }) {
  if (b.app_id !== undefined) setSetting('cm_app_id', String(b.app_id || '').replace(/\D/g, ''));
  if (b.app_secret !== undefined && String(b.app_secret).trim() && !String(b.app_secret).startsWith('••')) setSetting('cm_app_secret', String(b.app_secret).trim());
  if (b.proxy !== undefined) setSetting('cm_proxy', String(b.proxy || '').trim());
  const s = getSettings();
  const first = !s.cm_user_token;
  needProxy(s);
  const short = String(b.token || '').trim();
  if (!short) throw new HttpError(400, 'Paste the access token from Graph API Explorer');
  if (!s.cm_app_id || !s.cm_app_secret) throw new HttpError(400, 'Add the App ID and App Secret (App settings → Basic)');
  const c0: Creds = { token: short, proxy: proxyOf(s) };
  let long = short, exp = 0;
  try {
    const r = await graph<{ access_token: string; expires_in?: number }>(c0, 'GET', 'oauth/access_token', { grant_type: 'fb_exchange_token', client_id: s.cm_app_id, client_secret: s.cm_app_secret, fb_exchange_token: short });
    if (r.access_token) { long = r.access_token; exp = r.expires_in ? now() + r.expires_in * 1000 : now() + 60 * DAY; }
  } catch (e) { throw new HttpError(400, 'Meta did not accept the token / App Secret: ' + (e as Error).message); }
  const uc: Creds = { token: long, secret: s.cm_app_secret, proxy: proxyOf(s) };
  const pages = await graphAll<{ id: string; name: string; access_token: string; tasks?: string[] }>(uc, 'me/accounts', { fields: 'id,name,access_token,tasks', limit: 50 }, 3);
  const page = pages.find(p => (p.tasks || []).some(t => t === 'MODERATE' || t === 'MANAGE')) || pages[0];
  if (!page) throw new HttpError(400, 'This token sees no Facebook Page — in Generate Access Token pick the AdsBhai page');
  let accts: { id: string; name?: string }[] = [];
  try { accts = await graphAll<{ id: string; name?: string }>(uc, 'me/adaccounts', { fields: 'id,name', limit: 50 }, 3); } catch { /* no ads_read → only Facebook Page comments */ }
  setSetting('cm_user_token', long);
  setSetting('cm_token_exp', String(exp || ''));
  setSetting('cm_page_id', page.id);
  setSetting('cm_page_name', page.name);
  setSetting('cm_page_token', page.access_token);
  setSetting('cm_accts', JSON.stringify(accts.map(a => ({ id: a.id, name: a.name || a.id }))));
  setSetting('cm_last_err', '');
  setSetting('cm_warned', '');
  if (first) setSetting('cm_on', '1'); // a new token later must not switch checking back ON
  return { ok: true, page: page.name, accounts: accts.length, expires: exp };
}

export function cmDisconnect() {
  for (const k of ['cm_user_token', 'cm_page_token', 'cm_page_id', 'cm_page_name', 'cm_accts', 'cm_token_exp'] as const) setSetting(k, '');
  return { ok: true };
}

/* ---------------- classify ---------------- */
const BAD_WORDS = /(\bscam+(er|mer)?s?\b|\bfraud\b|\bfroud\b|\bfrod\b|\bfake\b|\bfek\b|\bchor\b|\bchori\b|\bcheat(er|ing)?\b|\bdhokh?a\b|\bdhokebaaz\b|\bloot(ne|te)?\b|\bthag\b|\bthug\b|\bfarzi\b|\bjhoo?th\b|\bbakwas\b|\bbekar\b|ठग|फ्रॉड|फ़्रॉड|धोखा|चोर|स्कैम|फेक|लूट|फर्जी)/i;
const PROMO = /(https?:\/\/|www\.|t\.me\/|wa\.me\/|chat\.whatsapp|telegram\.me|instagram\.com\/|\binbox\s*me\b|\bdm\s*me\b|contact\s*me|message\s*me)/i;
const PHONE = /(\+?\d[\d\s-]{8,}\d)/;
const customWords = (s: Settings) => String(s.cm_words || '').split(/[\n,]+/).map(w => w.trim().toLowerCase()).filter(w => w.length >= 2);

/** Quick rules (no AI): custom words / links / phone numbers → delete; scam words → delete (or "check" when AI can look). */
export function ruleLabel(text: string, s: Settings = getSettings()): { label: CmLabel; reason: string } | null {
  const t = String(text || '').toLowerCase();
  const w = customWords(s).find(x => t.includes(x));
  if (w) return { label: 'bad', reason: `your word: ${w}` };
  if (PROMO.test(t)) return { label: 'bad', reason: 'link / promotion' };
  if (PHONE.test(t)) return { label: 'bad', reason: 'phone number' };
  if (BAD_WORDS.test(t)) return { label: 'bad', reason: 'scam / fake / abuse words' };
  return null;
}

async function aiLabels(s: Settings, items: { id: string; text: string }[]): Promise<Record<string, { label: CmLabel; reason: string }>> {
  if (!items.length || !s.ai_key || s.cm_ai !== '1') return {};
  const { aiCommentLabels } = await import('./ai');
  try { return await aiCommentLabels(s, items); } catch (e) { console.error('[comments ai]', (e as Error).message); return {}; }
}

/* ---------------- sync ---------------- */
type FbC = { id: string; message?: string; created_time?: string; from?: { id: string; name: string }; permalink_url?: string };
type IgC = { id: string; text?: string; username?: string; timestamp?: string };
let busy = false;
let lastRun = 0;

export async function cmSync(force = false): Promise<{ new: number; deleted: number; ads: number } | null> {
  const s = getSettings();
  if (!cmReady(s)) return null;
  if (s.cm_on !== '1') { if (force) throw new HttpError(400, 'Comments is OFF — turn the switch ON first'); return null; } // v151: master switch
  const every = Math.max(1, Number(s.cm_every) || 2) * 60000;
  if (!force && now() - lastRun < every - 5000) return null;
  if (busy) return null;
  busy = true; lastRun = now();
  let added = 0, deleted = 0, adsN = 0;
  try {
    needProxy(s);
    ensureCmTables();
    const pc = pageCreds(s), uc = userCreds(s);
    // 1) active ads (all ad accounts the token sees) → their Facebook post + Instagram post
    const accts: { id: string }[] = (() => { try { return JSON.parse(s.cm_accts || '[]'); } catch { return []; } })();
    const seenAds = new Set<string>();
    if (s.cm_user_token) for (const a of accts) {
      try {
        const ads = await graphAll<{ id: string; name: string; creative?: { effective_object_story_id?: string; effective_instagram_media_id?: string; instagram_permalink_url?: string } }>(uc, `${a.id}/ads`, {
          effective_status: ['ACTIVE'], fields: 'id,name,creative{effective_object_story_id,effective_instagram_media_id,instagram_permalink_url}', limit: 100,
        }, 5);
        for (const ad of ads) {
          seenAds.add(ad.id);
          run(`INSERT INTO fb_ads(ad_id, name, acct, fb_post, ig_media, ig_link, active, seen_at) VALUES(?,?,?,?,?,?,1,?)
               ON CONFLICT(ad_id) DO UPDATE SET name=excluded.name, fb_post=excluded.fb_post, ig_media=excluded.ig_media, ig_link=excluded.ig_link, active=1, seen_at=excluded.seen_at`,
            ad.id, ad.name, a.id, ad.creative?.effective_object_story_id || null, ad.creative?.effective_instagram_media_id || null, ad.creative?.instagram_permalink_url || null, now());
        }
      } catch (e) { if ((e as MetaError).kind === 'token') throw e; console.error('[comments ads]', a.id, (e as Error).message); }
    }
    if (seenAds.size || accts.length) run(`UPDATE fb_ads SET active=0 WHERE ad_id NOT IN (${[...seenAds].map(() => '?').join(',') || "''"})`, ...seenAds);
    const ads = all<{ ad_id: string; name: string; fb_post: string | null; ig_media: string | null; ig_link: string | null }>('SELECT ad_id, name, fb_post, ig_media, ig_link FROM fb_ads WHERE active=1');
    adsN = ads.length;
    // 2) normal Page posts (last 15)
    let posts: { id: string }[] = [];
    try { posts = (await graph<{ data: { id: string }[] }>(pc, 'GET', `${s.cm_page_id}/posts`, { fields: 'id', limit: 15 })).data || []; } catch (e) { if ((e as MetaError).kind === 'token') throw e; }
    const fbTargets = new Map<string, { ad_id: string | null; ad_name: string | null; kind: 'ad' | 'post' }>();
    for (const p of posts) fbTargets.set(p.id, { ad_id: null, ad_name: null, kind: 'post' });
    for (const a of ads) if (a.fb_post) fbTargets.set(a.fb_post, { ad_id: a.ad_id, ad_name: a.name, kind: 'ad' });
    const fresh: CmRow[] = [];
    const ins = (r: Omit<CmRow, 'seen_at' | 'label' | 'reason' | 'status' | 'deleted_at' | 'deleted_by'>) => {
      const x = run(`INSERT OR IGNORE INTO fb_comments(id, src, target, ad_id, ad_name, kind, author, author_id, text, created_at, seen_at, permalink) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`,
        r.id, r.src, r.target, r.ad_id, r.ad_name, r.kind, r.author, r.author_id, r.text, r.created_at, now(), r.permalink);
      if (x.changes) { added++; fresh.push({ ...r, seen_at: now(), label: '', reason: null, status: 'live', deleted_at: null, deleted_by: null }); }
    };
    for (const [target, meta] of fbTargets) {
      try {
        const cs = (await graph<{ data: FbC[] }>(pc, 'GET', `${target}/comments`, { fields: 'id,message,created_time,from{id,name},permalink_url', filter: 'stream', order: 'reverse_chronological', limit: 50 })).data || [];
        for (const c of cs) {
          if (c.from?.id === s.cm_page_id) continue; // our own replies
          ins({ id: c.id, src: 'fb', target, ...meta, author: c.from?.name || null, author_id: c.from?.id || null, text: c.message || '', created_at: c.created_time ? Date.parse(c.created_time) : now(), permalink: c.permalink_url || null });
        }
      } catch (e) { if ((e as MetaError).kind === 'token') throw e; console.error('[comments fb]', target, (e as Error).message); }
    }
    // 3) Instagram posts of the ads (page-backed Instagram) — read + delete only (Meta allows no hide / reply there)
    for (const a of ads) {
      if (!a.ig_media || !s.cm_user_token) continue;
      try {
        const cs = (await graph<{ data: IgC[] }>(uc, 'GET', `${a.ig_media}/comments`, { fields: 'id,text,username,timestamp', limit: 50 })).data || [];
        for (const c of cs) ins({ id: c.id, src: 'ig', target: a.ig_media, ad_id: a.ad_id, ad_name: a.name, kind: 'ad', author: c.username || null, author_id: null, text: c.text || '', created_at: c.timestamp ? Date.parse(c.timestamp) : now(), permalink: a.ig_link });
      } catch (e) { if ((e as MetaError).kind === 'token') throw e; console.error('[comments ig]', a.ig_media, (e as Error).message); }
    }
    // 4) label the new ones → auto-delete
    if (fresh.length) {
      const pending: { id: string; text: string }[] = [];
      for (const c of fresh) {
        const r = ruleLabel(c.text, s);
        if (r && (r.reason.startsWith('your word') || r.reason !== 'scam / fake / abuse words' || !s.ai_key || s.cm_ai !== '1')) { setLabel(c.id, r.label, r.reason); c.label = r.label; continue; }
        pending.push({ id: c.id, text: c.text });
      }
      const ai = await aiLabels(s, pending);
      for (const p of pending) {
        const r = ai[p.id] || ruleLabel(p.text, s) || { label: 'ok' as CmLabel, reason: '' };
        setLabel(p.id, r.label, r.reason); const c = fresh.find(x => x.id === p.id); if (c) c.label = r.label;
      }
      for (const c of fresh) {
        if (c.label === 'bad' && s.cm_auto === '1') { if (await deleteOne(c.id, 'auto').catch(() => false)) deleted++; }
      }
      const doubts = fresh.filter(c => c.label === 'doubt' || (c.label === 'bad' && s.cm_auto !== '1'));
      if (doubts.length) void pushTo('admin', null, `💬 ${doubts.length} comment${doubts.length > 1 ? 's' : ''} to check`, doubts.slice(0, 3).map(c => `${c.src === 'ig' ? 'IG' : 'FB'}: ${c.text.slice(0, 80)}`).join('\n'), { tab: 'comments' }).catch(() => {});
    }
    setSetting('cm_last_sync', String(now()));
    setSetting('cm_last_err', '');
    return { new: added, deleted, ads: adsN };
  } catch (e) {
    const m = (e as Error).message;
    setSetting('cm_last_err', `${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}: ${m}`.slice(0, 300));
    if ((e as MetaError).kind === 'token' && s.cm_warned !== 'token') { setSetting('cm_warned', 'token'); void pushTo('admin', null, '⚠️ Comments stopped', 'The Meta token stopped working. Admin → Comments → paste a new token.').catch(() => {}); }
    if (force) throw e instanceof HttpError ? e : new HttpError(502, m);
    return null;
  } finally { busy = false; }
}

function setLabel(id: string, label: CmLabel, reason: string) { run('UPDATE fb_comments SET label=?, reason=? WHERE id=?', label, reason || null, id); }

async function deleteOne(id: string, by: string): Promise<boolean> {
  const s = getSettings();
  const c = one<CmRow>('SELECT * FROM fb_comments WHERE id=?', id);
  if (!c || c.status !== 'live') return false;
  try {
    await graph(c.src === 'ig' ? userCreds(s) : pageCreds(s), 'DELETE', id);
  } catch (e) {
    const me = e as MetaError;
    if (me.code === 100 || /does not exist|not exist|Unsupported delete/i.test(me.message)) { run("UPDATE fb_comments SET status='gone' WHERE id=?", id); return false; }
    throw e;
  }
  run('UPDATE fb_comments SET status=?, deleted_at=?, deleted_by=? WHERE id=?', by === 'auto' ? 'auto_deleted' : 'deleted', now(), by, id);
  return true;
}

export async function cmDelete(ids: string[], by = 'Admin') {
  const s = getSettings(); needProxy(s);
  if (s.cm_on !== '1') throw new HttpError(400, 'Comments is OFF — turn the switch ON first');
  let n = 0; const errs: string[] = [];
  for (const id of ids.slice(0, 100)) {
    try { if (await deleteOne(id, by)) n++; } catch (e) { errs.push((e as Error).message); }
  }
  if (!n && errs.length) throw new HttpError(502, 'Meta: ' + errs[0]);
  return { ok: true, n, failed: errs.length };
}
export function cmKeep(ids: string[]) { for (const id of ids.slice(0, 200)) setLabel(id, 'ok', 'kept by admin'); return { ok: true }; }

export function cmList(f: { label?: string | null; src?: string | null; ad?: string | null; status?: string | null; q?: string | null; before?: number }) {
  ensureCmTables();
  const w: string[] = []; const a: unknown[] = [];
  if (f.label === 'bad' || f.label === 'doubt' || f.label === 'ok') { w.push('label=?', "status='live'"); a.push(f.label); }
  if (f.status === 'deleted') w.push("status IN ('deleted','auto_deleted')");
  if (f.status === 'auto') w.push("status='auto_deleted'");
  if (f.src === 'fb' || f.src === 'ig') { w.push('src=?'); a.push(f.src); }
  if (f.ad === 'posts') w.push("kind='post'"); else if (f.ad) { w.push('ad_id=?'); a.push(f.ad); }
  if (f.q) { w.push('(text LIKE ? OR author LIKE ?)'); a.push(`%${f.q}%`, `%${f.q}%`); }
  if (f.before) { w.push('created_at<?'); a.push(f.before); }
  const rows = all<CmRow>(`SELECT * FROM fb_comments ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY created_at DESC LIMIT 100`, ...a);
  const counts = one<{ all_n: number; bad: number; doubt: number; deleted: number; today: number }>(`SELECT COUNT(*) all_n,
    SUM(label='bad' AND status='live') bad, SUM(label='doubt' AND status='live') doubt, SUM(status IN ('deleted','auto_deleted')) deleted,
    SUM(created_at>=?) today FROM fb_comments`, now() - DAY)!;
  return { rows, counts };
}

export function cmStatus() {
  ensureCmTables();
  const s = getSettings();
  const ads = all<{ ad_id: string; name: string; fb_post: string | null; ig_media: string | null; n: number; bad: number }>(`SELECT a.ad_id, a.name, a.fb_post, a.ig_media,
    (SELECT COUNT(*) FROM fb_comments c WHERE c.ad_id=a.ad_id) n, (SELECT COUNT(*) FROM fb_comments c WHERE c.ad_id=a.ad_id AND c.status IN ('deleted','auto_deleted')) bad
    FROM fb_ads a WHERE a.active=1 ORDER BY a.name`);
  let accts: { id: string; name: string }[] = []; try { accts = JSON.parse(s.cm_accts || '[]'); } catch { /* */ }
  return {
    connected: cmReady(s), page: s.cm_page_name || '', accounts: accts, app_id: s.cm_app_id || '', has_secret: !!s.cm_app_secret,
    proxy: s.cm_proxy ? s.cm_proxy.replace(/:\/\/[^@]*@/, '://••••@').replace(/^([^:/]+:\d+):.+$/, '$1:••••') : '',
    token_exp: Number(s.cm_token_exp) || 0, on: s.cm_on === '1', auto: s.cm_auto === '1', ai: s.cm_ai === '1', has_ai_key: !!s.ai_key,
    every: Number(s.cm_every) || 2, words: s.cm_words || '', last_sync: Number(s.cm_last_sync) || 0, last_err: s.cm_last_err || '', ads,
  };
}

export function cmSave(b: Record<string, unknown>) {
  for (const k of ['on', 'auto', 'ai'] as const) if (b[k] !== undefined) setSetting(`cm_${k}`, b[k] ? '1' : '0');
  if (b.words !== undefined) setSetting('cm_words', String(b.words || '').slice(0, 4000));
  if (b.every !== undefined) setSetting('cm_every', String(Math.min(60, Math.max(1, Number(b.every) || 2))));
  if (b.proxy !== undefined && !String(b.proxy).includes('••')) { const p = String(b.proxy || '').trim(); if (p) parseProxy(p); setSetting('cm_proxy', p); }
  return { ok: true };
}

/** Once a day: remind 7 days before the 60-day token ends (the ads / Instagram part needs it). */
export function cmTokenReminder(t = now()) {
  const s = getSettings();
  const exp = Number(s.cm_token_exp) || 0;
  if (!exp || !s.cm_user_token) return;
  const left = exp - t;
  const day = new Date(t).toISOString().slice(0, 10);
  if (left < 7 * DAY && s.cm_warned !== day) {
    setSetting('cm_warned', day);
    void pushTo('admin', null, '🔑 Comments token ends soon', left > 0 ? `In ${Math.ceil(left / DAY)} day(s). Graph API Explorer → Generate Access Token → paste it in Admin → Comments.` : 'It has ended — Instagram ad comments stopped. Paste a new token in Admin → Comments.').catch(() => {});
  }
}
