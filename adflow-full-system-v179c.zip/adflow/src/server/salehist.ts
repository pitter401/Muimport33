// v124: Admin → Sale history. Every sale (Telegram chats, WhatsApp, website orders) and every top-up, for a period,
// with who sold it (manager / agent / WhatsApp / website). Read-only.
import { all, run } from './db';
import { getSettings } from './settings';
import { dayRange, money, HttpError } from './util';
import { WA_ITEMS } from './wasales';

type Who = { key: string; name: string; role: 'manager' | 'agent' | 'whatsapp' | 'website' | 'admin' };
export type HistRow = { id: string; at: number; src: 'chat' | 'whatsapp' | 'website'; product: string; line: 'agency' | 'premium' | 'funnel'; qty: number; amount: number; commission: number; fee?: number;
  who: Who; customer: string; sub: string; lead_id: number | null; note: string | null; offer?: boolean; repeat?: boolean; status?: string; special?: { unit: number; list: number } | null };

const waLabel = (k: string | null) => WA_ITEMS.find(x => x.k === k)?.label || 'Sale';
const lineOf = (service: string | null, tier: string | null, line?: string | null): HistRow['line'] => (service === 'funnel' || line === 'funnel' ? 'funnel' : tier === 'premium' ? 'premium' : 'agency');
const nm = (r: { name?: string | null; tg_name?: string | null; tg_username?: string | null }) => r.name || r.tg_name || (r.tg_username ? '@' + r.tg_username : '') || 'Customer';

export function saleHistory(q: { range?: string | null; kind?: string | null; who?: string | null; line?: string | null }) {
  const s = getSettings();
  const [f, t] = dayRange(q.range || 'today', s);
  const topups = q.kind === 'topups';
  let rows: HistRow[] = [];
  // v166: totals / per-person come from SQL SUM / COUNT over the whole range (the lists below stay capped)
  type Agg = { src: HistRow['src']; line: HistRow['line']; who: Who; n: number; amount: number; commission: number; fee: number };
  const agg: Agg[] = [];
  const whoOf = (wa: boolean, r: { agent_id: number | null; agent_name: string | null; agent_role: string | null }): Who => (wa ? { key: 'wa', name: '', role: 'whatsapp' }
    : r.agent_id ? { key: 'a' + r.agent_id, name: r.agent_name || 'Agent #' + r.agent_id, role: r.agent_role === 'manager' ? 'manager' : 'agent' } : { key: 'admin', name: 'Admin', role: 'admin' });
  if (!topups) {
    for (const g of all<any>(`SELECT COALESCE(x.wa,0) wa, x.agent_id, a.name agent_name, a.role agent_role, x.service, x.tier, x.line, l.tier ltier, l.line lline, COUNT(*) n, COALESCE(SUM(x.amount),0) v, COALESCE(SUM(x.commission),0) c
      FROM sales x LEFT JOIN agents a ON a.id=x.agent_id LEFT JOIN leads l ON l.id=x.lead_id WHERE x.created_at>=? AND x.created_at<? GROUP BY 1,2,5,6,7,8,9`, f, t)) {
      const wa = !!g.wa, tier = wa ? g.tier : g.tier === 'premium' ? 'premium' : g.ltier;
      agg.push({ src: wa ? 'whatsapp' : 'chat', line: lineOf(g.service, tier, wa ? g.line : g.lline), who: whoOf(wa, g), n: g.n, amount: g.v, commission: g.c, fee: 0 });
    }
    for (const g of all<any>(`SELECT kind, tier, COUNT(*) n, COALESCE(SUM(amount),0) v FROM web_orders WHERE status IN ('paid','delivered') AND COALESCE(paid_at, created_at)>=? AND COALESCE(paid_at, created_at)<? GROUP BY 1,2`, f, t))
      agg.push({ src: 'website', line: lineOf(g.kind, g.tier), who: { key: 'web', name: 'Website', role: 'website' }, n: g.n, amount: g.v, commission: 0, fee: 0 });
    const sales = all<any>(`SELECT x.*, a.name agent_name, a.role agent_role, l.name, l.tg_name, l.tg_username, l.phone lphone, l.tier ltier, l.line lline, l.source lsource,
        (SELECT COUNT(*) FROM sales y WHERE y.lead_id=x.lead_id AND x.lead_id IS NOT NULL AND y.id<x.id) earlier
      FROM sales x LEFT JOIN agents a ON a.id=x.agent_id LEFT JOIN leads l ON l.id=x.lead_id WHERE x.created_at>=? AND x.created_at<? ORDER BY x.created_at DESC LIMIT 2000`, f, t);
    for (const r of sales) {
      const wa = !!r.wa;
      // v144: a Premium account sold in an Agency chat (payment link) is Premium (sales.tier); the Facebook account product has its own name
      const tier = wa ? r.tier : r.tier === 'premium' ? 'premium' : r.ltier;
      const ln = lineOf(r.service, tier, wa ? r.line : r.lline);
      const product = wa || r.item === 'fb_old' ? waLabel(r.item) : r.service === 'funnel' ? 'Landing page + funnel' : r.service === 'custom' ? 'Custom amount' : `${r.full ? 'Full access ' : ''}${tier === 'premium' ? 'Premium' : 'Agency'} ad account`;
      const who: Who = wa ? { key: 'wa', name: r.by_name ? `by ${r.by_name}` : '', role: 'whatsapp' }
        : r.agent_id ? { key: 'a' + r.agent_id, name: r.agent_name || 'Agent #' + r.agent_id, role: r.agent_role === 'manager' ? 'manager' : 'agent' } : { key: 'admin', name: 'Admin', role: 'admin' };
      rows.push({ id: 's' + r.id, at: r.created_at, src: wa ? 'whatsapp' : 'chat', product, line: ln, qty: r.qty || 1, amount: money(r.amount), commission: money(r.commission || 0), who,
        customer: wa ? r.cust_name || r.cust_phone || 'WhatsApp customer' : nm(r), sub: wa ? (r.cust_name && r.cust_phone ? r.cust_phone : '') : [r.tg_username ? '@' + r.tg_username : '', r.lphone || ''].filter(Boolean).join(' · '),
        lead_id: r.lead_id || null, note: r.note || null, offer: !!r.offer, repeat: !wa && r.earlier > 0, special: r.list_price > 0 ? { unit: money(r.amount / Math.max(1, r.qty || 1)), list: money(r.list_price) } : null });
    }
    const web = all<any>(`SELECT o.*, c.name cname, c.email FROM web_orders o LEFT JOIN customers c ON c.id=o.customer_id
      WHERE o.status IN ('paid','delivered') AND COALESCE(o.paid_at, o.created_at)>=? AND COALESCE(o.paid_at, o.created_at)<? ORDER BY o.id DESC LIMIT 1000`, f, t);
    for (const o of web) rows.push({ id: 'w' + o.id, at: o.paid_at || o.created_at, src: 'website', product: o.kind === 'funnel' ? 'Landing page + funnel' : `${o.full ? 'Full access ' : ''}${o.tier === 'premium' ? 'Premium' : 'Agency'} ad account`,
      line: lineOf(o.kind, o.tier), qty: o.qty || 1, amount: money(o.amount), commission: 0, who: { key: 'web', name: 'Website', role: 'website' }, customer: o.name || o.cname || o.email || 'Website customer',
      sub: [o.email, o.code].filter(Boolean).join(' · '), lead_id: o.lead_id || null, note: o.pay_method === 'inr' ? `INR ₹${o.inr_amount}${o.utr ? ' · UTR ' + o.utr : ''}` : o.pay_currency ? `Crypto ${String(o.pay_currency).toUpperCase()}` : null,
      status: o.status === 'delivered' ? 'Delivered' : 'Paid, not delivered yet' });
  } else {
    for (const g of all<any>(`SELECT COALESCE(x.wa,0) wa, x.agent_id, a.name agent_name, a.role agent_role, l.tier ltier, l.line lline, COUNT(*) n, COALESCE(SUM(x.amount),0) v, COALESCE(SUM(x.commission),0) c
      FROM topups x LEFT JOIN agents a ON a.id=x.agent_id LEFT JOIN leads l ON l.id=x.lead_id WHERE x.created_at>=? AND x.created_at<? GROUP BY 1,2,5,6`, f, t))
      agg.push({ src: g.wa ? 'whatsapp' : 'chat', line: lineOf(null, g.ltier, g.lline), who: whoOf(!!g.wa, g), n: g.n, amount: g.v, commission: 0, fee: g.c });
    for (const g of all<any>(`SELECT COUNT(*) n, COALESCE(SUM(amount),0) v, COALESCE(SUM(fee),0) fee FROM web_topups WHERE status IN ('paid','done') AND COALESCE(paid_at, created_at)>=? AND COALESCE(paid_at, created_at)<?`, f, t))
      if (g.n) agg.push({ src: 'website', line: 'agency', who: { key: 'web', name: 'Website', role: 'website' }, n: g.n, amount: g.v, commission: 0, fee: g.fee });
    const tops = all<any>(`SELECT x.*, a.name agent_name, a.role agent_role, l.name, l.tg_name, l.tg_username, l.tier ltier, l.line lline FROM topups x LEFT JOIN agents a ON a.id=x.agent_id LEFT JOIN leads l ON l.id=x.lead_id
      WHERE x.created_at>=? AND x.created_at<? ORDER BY x.created_at DESC LIMIT 2000`, f, t);
    for (const r of tops) {
      const wa = !!r.wa;
      rows.push({ id: 't' + r.id, at: r.created_at, src: wa ? 'whatsapp' : 'chat', product: 'Top-up', line: lineOf(null, r.ltier, r.lline), qty: 1, amount: money(r.amount), commission: 0, fee: money(r.commission || 0),
        who: wa ? { key: 'wa', name: r.agent_name ? `by ${r.agent_name}` : '', role: 'whatsapp' } : r.agent_id ? { key: 'a' + r.agent_id, name: r.agent_name || 'Agent #' + r.agent_id, role: r.agent_role === 'manager' ? 'manager' : 'agent' } : { key: 'admin', name: 'Admin', role: 'admin' },
        customer: wa ? (String(r.note || '').split(' · ')[1] || 'WhatsApp customer') : nm(r), sub: r.tg_username ? '@' + r.tg_username : '', lead_id: r.lead_id || null, note: r.note || null });
    }
    const wt = all<any>(`SELECT x.*, c.name cname, c.email FROM web_topups x LEFT JOIN customers c ON c.id=x.customer_id WHERE x.status IN ('paid','done') AND COALESCE(x.paid_at, x.created_at)>=? AND COALESCE(x.paid_at, x.created_at)<? ORDER BY x.id DESC LIMIT 1000`, f, t);
    for (const x of wt) rows.push({ id: 'wt' + x.id, at: x.paid_at || x.created_at, src: 'website', product: 'Top-up', line: 'agency', qty: 1, amount: money(x.amount), commission: 0, fee: money(x.fee || 0),
      who: { key: 'web', name: 'Website', role: 'website' }, customer: x.cname || x.email || 'Website customer', sub: [x.email, x.act_id ? 'act_' + x.act_id : ''].filter(Boolean).join(' · '), lead_id: null, note: null,
      status: x.status === 'done' ? 'Done' : 'Paid, not added yet' });
  }
  // everyone who sold something in this period (before the filters) → the "who" picker
  const people = [...new Map(agg.map(r => [r.who.key, r.who.role === 'whatsapp' ? { key: 'wa', name: 'WhatsApp', role: 'whatsapp' as const } : r.who])).values()];
  const keep = (r: { line: string; src: string; who: Who }) => (!q.line || q.line === 'all' || r.line === q.line) && (!q.who || q.who === 'all' || (q.who === 'wa' ? r.src === 'whatsapp' : r.who.key === q.who));
  rows = rows.filter(keep);
  const ag = agg.filter(keep);
  rows.sort((a, b) => b.at - a.at);
  const by = new Map<string, { key: string; name: string; role: string; n: number; amount: number; commission: number; fee: number }>();
  for (const r of ag) {
    const k = r.src === 'whatsapp' ? 'wa' : r.who.key;
    const e = by.get(k) || { key: k, name: r.src === 'whatsapp' ? 'WhatsApp' : r.who.name, role: r.src === 'whatsapp' ? 'whatsapp' : r.who.role, n: 0, amount: 0, commission: 0, fee: 0 };
    e.n += r.n; e.amount = money(e.amount + r.amount); e.commission = money(e.commission + r.commission); e.fee = money(e.fee + r.fee);
    by.set(k, e);
  }
  const sum = (k: 'amount' | 'commission' | 'fee') => money(ag.reduce((a, r) => a + (r[k] || 0), 0));
  const n = ag.reduce((a, r) => a + r.n, 0), list = rows.slice(0, 1000);
  return { kind: topups ? 'topups' : 'sales', from: f, to: t, total: { n, amount: sum('amount'), commission: sum('commission'), fee: sum('fee') },
    by: [...by.values()].sort((a, b) => b.amount - a.amount), people, rows: list, truncated: n > list.length }; // v166: the list shows the latest 1000
}

/** v124: remove a top-up written by mistake (Telegram chat or WhatsApp; website top-ups are not removed here). */
export function deleteTopup(id: unknown) {
  const n = Number(String(id).replace(/^t/, ''));
  const r = all<{ id: number; amount: number; lead_id: number | null }>('SELECT id, amount, lead_id FROM topups WHERE id=?', n)[0];
  if (!r) throw new HttpError(404, 'Top-up not found');
  run('DELETE FROM topups WHERE id=?', n);
  if (r.lead_id) run("INSERT INTO messages(lead_id, dir, sender, text, created_at) VALUES(?, 'sys', 'system', ?, ?)", r.lead_id, `Top-up $${r.amount} removed (Admin)`, Date.now());
  return { ok: true };
}
