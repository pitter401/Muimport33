// v139: "See pricing" / "What's included" taps in the bot welcome (Telegram channel ads). Answered in the bot chat with the
// SAME reply texts as the WhatsApp buttons (Settings → WATI → button replies, wati_btn_replies), picked by meaning;
// no lead and no Meta event — those come only when they open the support chat with an action button and write there.
import { one, run } from './db';
import { getSettings, type Settings } from './settings';
import { tg } from './telegram';
import { now } from './util';
import { parseReplies, replyFor } from './btnreplies';
import { btnReplyText, showsAgencyPrice, waButtonsFor } from './wasync';
import { botInfoOn, infoRows, isPremiumPerson, lineFields, lineOfLetter, botError, INFO_LABEL, type ChanLine, type InfoKind } from './chanads';
import { imgOnReplies, offerImageUrl, offerLine, sendTgPhoto, tgBtnImgOn } from './offerimg';

/** Telegram defaults by meaning, used when the WhatsApp labels have nothing with that meaning (no emoji, prices as placeholders). */
export const TG_INFO_DEFAULTS: Record<ChanLine, Record<InfoKind, string>> = {
  agency: {
    p: 'Our agency ad account is ${price} ({price_inr} INR) per account, with no spending limit.\n⏱ Shared to your Business Manager within {delivery} after payment.\n\nTop-ups: fee only {fee}, minimum ${min_topup} ({min_topup_inr} INR).\nPayment: {payment}.',
    i: 'Every agency ad account comes with:\n✓ No spending limit from day one\n✓ No 18% GST on ad spend\n✓ Top-ups any time, fee only {fee}\n✓ Help from our team on WhatsApp and Telegram\n⏱ Shared to your Business Manager within {delivery} after payment.\n\nPrice: ${price} ({price_inr} INR) per account.',
  },
  premium: {
    p: 'The Premium ad account is ${price} ({price_inr} INR) per account.\n⏱ Ready in {delivery} after payment.\n\nTop-up fee only {fee}.\nPayment: {payment}.',
    i: 'Every Premium ad account comes with:\n✓ An aged, strong profile and a verified BM\n✓ No spending limit from day one, made for bigger budgets\n✓ No 18% GST on ad spend\n✓ Top-up fee only {fee}\n✓ Priority support\n⏱ Ready in {delivery} after payment.\n\nPrice: ${price} ({price_inr} INR) per account.',
  },
  funnel: {
    p: 'The complete funnel is ${price} ({price_inr} INR) per month: a landing page, Meta ads setup with tracking, leads to your WhatsApp, hosting and support.\n⏱ Setup takes 2 to 3 days.\nPayment: {payment}.',
    i: 'Your funnel includes:\n✓ A fast landing page for your business\n✓ Full Meta ads setup with tracking\n✓ Leads sent straight to your WhatsApp\n✓ Hosting and support\n⏱ Setup takes 2 to 3 days.\n\nPrice: ${price} ({price_inr} INR) per month.',
  },
};
const MEANING: Record<InfoKind, RegExp> = { p: /pric|cost|rate|fee/i, i: /includ|feature|detail|what/i };
const GET = /get|buy|start|order/i;
const FOOT = '\n\nReady? Tap a button below to chat with our team.';

/** The reply text for an info tap, by meaning: a WhatsApp label with that meaning (pricing → "See pricing", or the line's
 *  "Get account" / "Buy Premium" reply that carries the price) → its saved / built-in reply; else the Telegram default.
 *  Placeholders filled from the settings like on WhatsApp. Premium never shows the Agency price. */
export function botInfoText(s: Settings, ln: ChanLine, kind: InfoKind, name = ''): string {
  const L = { ...lineFields(ln), name };
  const labels = waButtonsFor(s, L);
  const map = parseReplies(s.wati_btn_replies);
  // v139: only a label that really means pricing / included — the "Get account" reply asks for the BM ID, which belongs in support, not the bot
  const pick = labels.find(l => MEANING[kind].test(l) && !GET.test(l));
  const saved = pick ? replyFor(map, ln, labels, pick)?.text || '' : '';
  const tryText = (tpl: string) => { const t = tpl ? btnReplyText(s, L, tpl) : ''; return t && !showsAgencyPrice(s, L, t) ? t : ''; };
  const t = tryText(saved) || tryText(TG_INFO_DEFAULTS[ln][kind]) || 'Please chat with our team for the current price.';
  return (t + FOOT).slice(0, 4000);
}

/** callback_query from the bot welcome buttons (data "bi:<A|P|F>:<p|i>"). Returns true when it was ours. */
export async function handleBotCallback(cq: any, s: Settings = getSettings()): Promise<boolean> {
  const m = /^bi:([APF]):([pi])$/.exec(String(cq?.data || ''));
  if (!m) return false;
  const uid = String(cq.from?.id || '');
  const chatId = cq.message?.chat?.id ?? cq.from?.id;
  let ln = lineOfLetter(m[1]) || 'agency';
  const kind = m[2] as InfoKind;
  // hard rule: a Premium person never sees the Agency account
  if (ln === 'agency' && uid && isPremiumPerson(uid)) ln = 'premium';
  await tg(s, 'answerCallbackQuery', { callback_query_id: cq.id }).catch(() => null); // stops the spinner
  if (!botInfoOn(s) || !chatId) return true;
  const key = `${ln}:${kind}`;
  const dup = !!one('SELECT 1 FROM bot_taps WHERE tg_user=? AND line=? AND button=? AND at>?', uid, ln, kind, now() - 10 * 60000);
  if (!dup) run('INSERT INTO bot_taps(tg_user, line, button, at) VALUES(?,?,?,?)', uid, ln, kind, now());
  const markup = { inline_keyboard: infoRows(s, ln, uid, dup ? null : kind) };
  const text = dup ? 'Here are the options again. Tap a button below to chat with our team.' : botInfoText(s, ln, kind, String(cq.from?.first_name || ''));
  // v140: plain text + the follow-up buttons; the line's image only when "image on replies" is ON (default OFF).
  // The image is this line's own (a Premium person → Premium, above) — never another line's.
  const image = !dup && imgOnReplies(s) && tgBtnImgOn(s) ? offerImageUrl(s, offerLine(ln)) : '';
  const r = image
    ? await sendTgPhoto(s, chatId, image, { caption: text, markup, short: INFO_LABEL[kind].replace(/^\S+\s/, ''), fallback: text })
    : await tg(s, 'sendMessage', { chat_id: chatId, text, reply_markup: markup, disable_web_page_preview: true });
  if (!r.ok) botError('info button ' + key + ': ' + (r.description || ''));
  return true;
}
