import { sha256 } from './util';
import { setSetting, type Settings } from './settings';

const API = () => process.env.TG_API_BASE || 'https://api.telegram.org';
export type TgResult = { ok: boolean; result?: any; description?: string };

export async function tg(s: Settings, method: string, body: Record<string, unknown>): Promise<TgResult> {
  // v131: a WhatsApp chat ('wa:<number>') → WATI. Typing / read marks have no WhatsApp step here → just OK.
  if (typeof body.chat_id === 'string' && body.chat_id.startsWith('wa:')) return waTg(s, method, body);
  if (!s.bot_token) return { ok: false, description: 'Bot token not set' };
  try {
    const r = await fetch(`${API()}/bot${s.bot_token}/${method}`, {
      method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body), signal: AbortSignal.timeout(20000),
    });
    const j = (await r.json()) as TgResult & { error_code?: number; parameters?: { retry_after?: number } };
    if (!j.ok && method.startsWith('send')) void limitSeen(j, !!body.business_connection_id);
    return j;
  } catch (e) { return { ok: false, description: String(e) }; }
}
/** v143: Telegram said "slow down" (429 retry after X) or PEER_FLOOD on a send → that channel's send queue waits
 *  (Business-connection sends = the chat account, others = the bot). Never touches WhatsApp. */
async function limitSeen(j: { description?: string; error_code?: number; parameters?: { retry_after?: number } }, viaAccount: boolean) {
  try {
    const P = await import('./pace');
    const ra = j.parameters?.retry_after ?? (j.error_code === 429 ? Number(/retry after (\d+)/i.exec(String(j.description || ''))?.[1] || 30) : null);
    if (ra != null) { P.paceFloodWait(viaAccount ? 'tga' : 'tgb', ra, Date.now(), 'RETRY_AFTER'); return; }
    if (viaAccount && /PEER_FLOOD/i.test(String(j.description || ''))) { const U = await import('./userbot'); U.handleLimit(new Error(String(j.description))); }
  } catch { /* best effort */ }
}

async function waTg(s: Settings, method: string, body: Record<string, unknown>): Promise<TgResult> {
  const W = await import('./wati');
  const chat = String(body.chat_id);
  if (method === 'sendMessage') return W.waSendText(s, chat, String(body.text || ''));
  const kind = Object.entries(SEND_METHOD).find(([, [m]]) => m === method);
  if (kind) {
    const f = body[kind[1][1]];
    if (typeof f === 'string') return W.waSendFileId(s, chat, kind[0], f, String(body.caption || ''));
  }
  return { ok: true, result: {} };
}

export const webhookSecret = (s: Settings) => sha256('adflow|' + s.bot_token).slice(0, 48);

export const WEBHOOK_UPDATES = ['message', 'business_connection', 'business_message', 'deleted_business_messages', 'chat_join_request', 'chat_member', 'callback_query', 'channel_post', 'edited_channel_post']; // v139: callback_query = info buttons in the bot welcome · chat_member: joined / left the channel (v113)

/** Older installs registered the webhook without 'deleted_business_messages': add it, keeping the same URL. */
export async function ensureWebhookUpdates(s: Settings) {
  if (!s.bot_token) return false;
  const info = await tg(s, 'getWebhookInfo', {}).catch(() => null);
  const url = info?.ok ? info.result?.url : '';
  if (!url) return false;
  const have: string[] = info?.result?.allowed_updates || [];
  if (WEBHOOK_UPDATES.every(u => have.includes(u))) return false;
  const r = await tg(s, 'setWebhook', { url, secret_token: webhookSecret(s), allowed_updates: WEBHOOK_UPDATES });
  return !!r.ok;
}

export async function setupWebhook(s: Settings, baseUrl: string) {
  const me = await tg(s, 'getMe', {});
  if (!me.ok) return { ok: false, error: 'Bot token invalid: ' + (me.description || '') };
  setSetting('bot_username', me.result.username);
  const url = `${baseUrl.replace(/\/$/, '')}/api/tg/webhook`;
  const wh = await tg(s, 'setWebhook', { url, secret_token: webhookSecret(s), allowed_updates: WEBHOOK_UPDATES });
  return { ok: !!wh.ok, bot_username: me.result.username as string, webhook: url, error: wh.ok ? null : wh.description };
}

export const SEND_METHOD: Record<string, [string, string]> = {
  photo: ['sendPhoto', 'photo'], video: ['sendVideo', 'video'], document: ['sendDocument', 'document'], voice: ['sendVoice', 'voice'],
  audio: ['sendAudio', 'audio'], video_note: ['sendVideoNote', 'video_note'], sticker: ['sendSticker', 'sticker'], animation: ['sendAnimation', 'animation'],
};

export function extractMedia(m: any): [string | null, string | null, string | null] {
  if (!m) return [null, null, null];
  if (m.photo?.length) return ['photo', m.photo[m.photo.length - 1].file_id, null];
  for (const t of ['video', 'animation', 'voice', 'audio', 'video_note', 'sticker', 'document']) if (m[t]) return [t, m[t].file_id, m[t].file_name || null];
  return [null, null, null];
}
export function msgText(m: any): string {
  if (m.location) return `📍 Location: https://maps.google.com/?q=${m.location.latitude},${m.location.longitude}`;
  if (m.contact) return `👤 Contact: ${[m.contact.first_name, m.contact.last_name].filter(Boolean).join(' ')} ${m.contact.phone_number || ''}`.trim();
  return m.text || m.caption || '';
}

export async function sendFileId(s: Settings, chat_id: string, conn: string | null, type: string, file_id: string, caption?: string) {
  const [meth, field] = SEND_METHOD[type] || SEND_METHOD.document;
  const body: Record<string, unknown> = { chat_id, [field]: file_id };
  if (caption && !['sticker', 'video_note'].includes(type)) body.caption = caption.slice(0, 1000);
  if (conn) body.business_connection_id = conn;
  return tg(s, meth, body);
}

export async function sendText(s: Settings, chat_id: string, conn: string | null, text: string, replyToTgId: number | null = null) {
  const body: Record<string, unknown> = { chat_id, text, disable_web_page_preview: true };
  if (conn) body.business_connection_id = conn;
  if (replyToTgId) body.reply_parameters = { message_id: replyToTgId, allow_sending_without_reply: true };
  return tg(s, 'sendMessage', body);
}

/** Upload a file (multipart) to a chat. Falls back to sending as document. */
export async function uploadFile(s: Settings, chat_id: string, conn: string | null, file: File, kind: string, caption: string): Promise<TgResult> {
  if (chat_id.startsWith('wa:')) return (await import('./wati')).waSendFile(s, chat_id, file, kind, caption);
  const send = async (k: string) => {
    const [meth, field] = SEND_METHOD[k];
    const fd = new FormData();
    fd.append('chat_id', chat_id);
    if (conn) fd.append('business_connection_id', conn);
    if (caption) fd.append('caption', caption);
    fd.append(field, file, file.name || 'file');
    try {
      const r = await fetch(`${API()}/bot${s.bot_token}/${meth}`, { method: 'POST', body: fd, signal: AbortSignal.timeout(120000) });
      return (await r.json()) as TgResult;
    } catch (e) { return { ok: false, description: String(e) }; }
  };
  let r = await send(kind);
  // a voice note goes only as a real voice note — never as a file (and a customer who turned voice off can't get it as a file either)
  if (!r.ok && kind !== 'document' && kind !== 'voice') r = await send('document');
  return r;
}

export async function downloadFile(s: Settings, fileId: string) {
  if (fileId.startsWith('wa:')) return (await import('./wati')).waDownload(fileId);
  const f = await tg(s, 'getFile', { file_id: fileId });
  if (!f.ok) return null;
  const r = await fetch(`${API()}/file/bot${s.bot_token}/${f.result.file_path}`);
  return { res: r, path: f.result.file_path as string };
}
