import type { Settings } from './settings';

/** Deterministic 0..1 value for a time slot (same for every visitor at the same moment). */
function rnd(slot: number) {
  let x = (slot ^ 0x5bd1e995) >>> 0;
  x = Math.imul(x ^ (x >>> 15), 0x2c1b3c6d) >>> 0; x = Math.imul(x ^ (x >>> 12), 0x297a2d39) >>> 0;
  return ((x ^ (x >>> 15)) >>> 0) / 4294967296;
}

/**
 * "X+ people are viewing this": a number between viewer_min and viewer_max (default 76–191) that moves slowly
 * and naturally over time (smooth curve, new target every 8 minutes), the same for everyone at the same moment.
 * 0 = badge switched off.
 */
export function viewerBase(s: Settings, t = Date.now()) {
  if (!(Number(s.viewer_floor) > 0)) return 0;
  let lo = Math.max(1, Math.round(Number(s.viewer_min) || 76)), hi = Math.round(Number(s.viewer_max) || 191);
  if (hi < lo) [lo, hi] = [hi, lo];
  const SLOT = 8 * 60 * 1000;
  const slot = Math.floor(t / SLOT), f = (t % SLOT) / SLOT;
  const e = f * f * (3 - 2 * f); // smoothstep between the two targets
  const v = rnd(slot) * (1 - e) + rnd(slot + 1) * e;
  return lo + Math.round(v * (hi - lo));
}
