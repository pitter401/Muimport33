// v131: the WhatsApp ad pages (/agency|premium|funnel/whatsapp = chat, …/community = join the community with your number)
import crypto from 'crypto';
import { one, run } from './db';
import { getSettings, type Settings } from './settings';
import { clickIds } from './capi';
import { clientIp, getCookie } from './http';
import { now, HOUR, HttpError, cleanPhone } from './util';
import { campOfReq, noteVisitCamp } from './camps';
import { chanLine, chanPrices, chanDelivery, type ChanLine } from './chanads';

export const waOn = (s: Settings = getSettings()) => s.wati_on === '1';
export const waNumber = (s: Settings) => String(s.wa_number || s.wa_agent_number || '').replace(/\D/g, '');
const WHAT: Record<ChanLine, string> = { agency: 'an agency ad account', premium: 'a Premium ad account', funnel: 'a landing page + funnel setup' };

/** Tap "Chat on WhatsApp" → a code for this visitor (their ad click data + campaign) inside the pre-typed message → WhatsApp. */
export function waChatLink(req: Request) {
  const s = getSettings();
  const num = waNumber(s);
  if (!waOn(s) || num.length < 8) return null;
  const url = new URL(req.url);
  const ln = chanLine(url.searchParams.get('line'));
  const page = req.headers.get('referer') || '';
  const ids = clickIds(req, page);
  const cmp = campOfReq(req, page);
  let code = '';
  // the same visitor tapping again within a day keeps the same code
  const old = ids.vid ? one<{ code: string }>('SELECT code FROM wa_clicks WHERE vid=? AND line=? AND created_at>? AND lead_id IS NULL ORDER BY created_at DESC LIMIT 1', ids.vid, ln, now() - 24 * HOUR) : undefined;
  if (old) code = old.code;
  else {
    if ((one<{ n: number }>('SELECT COUNT(*) n FROM wa_clicks WHERE ip=? AND created_at>?', clientIp(req), now() - HOUR)?.n || 0) > 40) code = '';
    else {
      code = crypto.randomBytes(6).toString('base64').replace(/[^A-Za-z0-9]/g, 'x').slice(0, 8);
      run('INSERT INTO wa_clicks(code, line, vid, ip, ua, fbc, fbp, page_url, camp, adset, ad, created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
        code, ln, ids.vid || null, clientIp(req), req.headers.get('user-agent') || '', ids.fbc || null, ids.fbp || null, page.slice(0, 500), cmp?.camp || null, cmp?.adset || null, cmp?.ad || null, now());
      noteVisitCamp(ids.vid, cmp);
    }
  }
  const text = String(s.wa_prefill || 'Hi! I want {what}. My code: {code}').replace(/\{what\}/g, WHAT[ln]).replace(/\{code\}/g, code ? 'W-' + code : '').replace(/\s*My code:\s*$/i, '').trim();
  return `https://wa.me/${num}?text=${encodeURIComponent(text)}`;
}

/** Community page: their WhatsApp number (so the chat they start later is matched to this ad click → Subscribe). */
export function waJoin(req: Request, b: Record<string, unknown>) {
  const s = getSettings();
  if (!waOn(s)) throw new HttpError(404, 'Not found');
  const link = String(s.wa_comm_link || '').trim();
  if (!link) throw new HttpError(400, 'Community link not set');
  const phone = cleanPhone(String(b.phone || '').slice(0, 30), s.default_cc || '91').replace(/\D/g, '');
  if (!phone) throw new HttpError(400, 'Enter your WhatsApp number with country code');
  if ((one<{ n: number }>('SELECT COUNT(*) n FROM wa_joins WHERE ip=? AND created_at>?', clientIp(req), now() - HOUR)?.n || 0) > 15) throw new HttpError(429, 'Too many tries, please wait a bit');
  const page = String(b.page_url || req.headers.get('referer') || '').slice(0, 500);
  const ids = clickIds(req, page);
  const cmp = campOfReq(req, page);
  const ln = chanLine(b.line);
  const old = one<{ id: number }>('SELECT id FROM wa_joins WHERE phone=? AND created_at>? AND sub_at IS NULL ORDER BY id DESC LIMIT 1', phone, now() - 24 * HOUR);
  if (old) run('UPDATE wa_joins SET line=?, vid=COALESCE(?, vid), fbc=COALESCE(?, fbc), fbp=COALESCE(?, fbp), page_url=?, camp=COALESCE(?, camp), adset=COALESCE(?, adset), ad=COALESCE(?, ad) WHERE id=?',
    ln, ids.vid || null, ids.fbc || null, ids.fbp || null, page, cmp?.camp || null, cmp?.adset || null, cmp?.ad || null, old.id);
  else run('INSERT INTO wa_joins(phone, line, vid, ip, ua, fbc, fbp, page_url, camp, adset, ad, created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
    phone, ln, ids.vid || null, clientIp(req), req.headers.get('user-agent') || '', ids.fbc || null, ids.fbp || null, page, cmp?.camp || null, cmp?.adset || null, cmp?.ad || null, now());
  noteVisitCamp(ids.vid, cmp);
  return { ok: true, link };
}

/** What the page shows (Telegram prices, same as the chats). */
export function waPageData(ln: ChanLine, mode: 'chat' | 'community') {
  const s = getSettings();
  const p = chanPrices(s);
  return {
    on: waOn(s) && (mode === 'chat' ? waNumber(s).length >= 8 : !!String(s.wa_comm_link || '').trim()),
    brand: s.brand_name || 'AdsBhai', ln, mode,
    title: mode === 'chat' ? s.wa_page_title : s.wa_comm_page_title, text: mode === 'chat' ? s.wa_page_text : s.wa_comm_page_text,
    price: ln === 'funnel' ? p.funnel : ln === 'premium' ? p.premium : p.agency, unit: ln === 'funnel' ? 'per month' : 'per account', fee: p.fee,
    what: ln === 'funnel' ? 'Landing page + funnel setup' : ln === 'premium' ? 'Premium ad account' : 'Agency ad account',
    delivery: chanDelivery(s, ln), cc: s.default_cc || '91', // v138: Premium → premium_delivery
  };
}
export const getVid = (req: Request) => getCookie(req, 'af_vid');
