/** v137: deterministic gender fix for team voice notes (Hindi in Devanagari + Roman). The team voice is a man (male=true) →
 *  first-person female verb forms become male ("मैं भेज देती हूँ" → "भेज देता हूँ", "mai kar rahi hu" → "kar raha hu",
 *  "aa jaungi" → "aa jaunga"); a woman's voice → the reverse. Only first-person clauses change: a clause with
 *  मैं / main / mai, or with हूँ / hun / hu, or a first-person future (-ungi / -ऊँगी). "wo aa rahi hai" stays as it is.
 *  Runs after the AI rewrite too, so the result never depends on the model alone. */
export type GenderFix = { text: string; changed: { from: string; to: string }[] };

const DEV = '\\u0900-\\u097F';
// Devanagari word boundary helpers (JS \b does not work for Devanagari)
const L = `(?<![${DEV}\\w])`, R = `(?![${DEV}\\w])`;
const FP_DEV = new RegExp(`${L}(मैं|मै|मेैं)${R}|${L}(हूँ|हूं|हुँ|हु|हूँगी|हूँगा)${R}|ूँगी${R}|ूँगा${R}|ुंगी${R}|ुंगा${R}|ऊंगी${R}|ऊंगा${R}`);
const FP_ROM = /\b(main|mai|hu|hun|hoon|hoo)\b|\b\w+(ungi|unga|oongi|oonga)\b/i;

type Pair = [RegExp, string];
// female → male (Devanagari)
const DEV_F2M: Pair[] = [
  [new RegExp(`([${DEV}]+?)ती(\\s+(?:हूँ|हूं|हुँ|हु|थी|था))`, 'g'), '$1ता$2'],
  [new RegExp(`${L}(दे|कर|भेज|ले|आ|जा|बोल|बता|देख|सोच|रख|सक)ती${R}`, 'g'), '$1ता'],
  [new RegExp(`${L}रही${R}`, 'g'), 'रहा'],
  [new RegExp(`${L}सकती${R}`, 'g'), 'सकता'],
  [new RegExp(`${L}(गई|गयी)${R}`, 'g'), 'गया'],
  [new RegExp(`([${DEV}]+)(ूँगी|ूंगी|ुंगी|ऊँगी|ऊंगी)${R}`, 'g'), (null as unknown as string)],
  [new RegExp(`(${L}(?:[${DEV}]+(?:ता|ा)\\s+))थी${R}`, 'g'), '$1था'],
  [new RegExp(`${L}थी${R}`, 'g'), 'था'],
];
// male → female (Devanagari)
const DEV_M2F: Pair[] = [
  [new RegExp(`([${DEV}]+?)ता(\\s+(?:हूँ|हूं|हुँ|हु|था|थी))`, 'g'), '$1ती$2'],
  [new RegExp(`${L}(दे|कर|भेज|ले|आ|जा|बोल|बता|देख|सोच|रख|सक)ता${R}`, 'g'), '$1ती'],
  [new RegExp(`${L}रहा${R}`, 'g'), 'रही'],
  [new RegExp(`${L}सकता${R}`, 'g'), 'सकती'],
  [new RegExp(`${L}गया${R}`, 'g'), 'गई'],
  [new RegExp(`([${DEV}]+)(ूँगा|ूंगा|ुंगा|ऊँगा|ऊंगा)${R}`, 'g'), (null as unknown as string)],
  [new RegExp(`${L}था${R}`, 'g'), 'थी'],
];
// Roman
const ROM_F2M: Pair[] = [
  [/\b(\w+?)ti(\s+(?:hu|hun|hoon|hoo|thi|tha))\b/gi, '$1ta$2'],
  [/\b(de|kar|bhej|le|aa|ja|bol|bata|dekh|soch|rakh|sak|kr|bhij)ti\b/gi, '$1ta'],
  [/\b(rahi|rhi)\b/gi, 'raha'],
  [/\bsakti\b/gi, 'sakta'],
  [/\b(gayi|gai)\b/gi, 'gaya'],
  [/\b(\w+?)(ungi|oongi|ugi)\b/gi, '$1$2M'],
  [/\bthi\b/gi, 'tha'],
];
const ROM_M2F: Pair[] = [
  [/\b(\w+?)ta(\s+(?:hu|hun|hoon|hoo|tha|thi))\b/gi, '$1ti$2'],
  [/\b(de|kar|bhej|le|aa|ja|bol|bata|dekh|soch|rakh|sak|kr|bhij)ta\b/gi, '$1ti'],
  [/\b(raha|rha)\b/gi, 'rahi'],
  [/\bsakta\b/gi, 'sakti'],
  [/\bgaya\b/gi, 'gayi'],
  [/\b(\w+?)(unga|oonga|uga)\b/gi, '$1$2F'],
  [/\btha\b/gi, 'thi'],
];
const futM = (w: string) => w.replace(/ूँगी$/, 'ूँगा').replace(/ूंगी$/, 'ूंगा').replace(/ुंगी$/, 'ुंगा').replace(/ऊँगी$/, 'ऊँगा').replace(/ऊंगी$/, 'ऊंगा');
const futF = (w: string) => w.replace(/ूँगा$/, 'ूँगी').replace(/ूंगा$/, 'ूंगी').replace(/ुंगा$/, 'ुंगी').replace(/ऊँगा$/, 'ऊँगी').replace(/ऊंगा$/, 'ऊंगी');

function fixClause(c: string, male: boolean): string {
  if (!(FP_DEV.test(c) || FP_ROM.test(c))) return c; // not about "I" → untouched ("wo aa rahi hai")
  let out = c;
  for (const [re, to] of male ? DEV_F2M : DEV_M2F) out = to === null ? out.replace(re, m => (male ? futM(m) : futF(m))) : out.replace(re, to);
  for (const [re, to] of male ? ROM_F2M : ROM_M2F) {
    if (/\$2M|\$2F/.test(to)) out = out.replace(re, (_m, a: string, b: string) => a + (male ? b.replace(/i$/i, 'a') : b.replace(/a$/i, 'i')));
    else out = out.replace(re, (m, ...g) => { const r = to.replace(/\$(\d)/g, (_x, n) => String(g[Number(n) - 1] ?? '')); return m[0] === m[0].toUpperCase() && m[0] !== m[0].toLowerCase() ? r[0].toUpperCase() + r.slice(1) : r; });
  }
  return out;
}

/** The text with first-person verb forms in the voice's gender, and which words changed. */
export function genderFix(text: string, male: boolean): GenderFix {
  const src = String(text || '');
  // clauses: split after , . ? ! । ; and keep the separators
  const parts = src.split(/([,.?!।;\n]+)/);
  const out = parts.map((p, i) => (i % 2 ? p : fixClause(p, male))).join('');
  const changed: GenderFix['changed'] = [];
  const a = src.split(/(\s+)/), b = out.split(/(\s+)/);
  if (a.length === b.length) a.forEach((w, i) => { if (w !== b[i]) changed.push({ from: w, to: b[i] }); });
  else if (src !== out) changed.push({ from: src, to: out });
  return { text: out, changed };
}
