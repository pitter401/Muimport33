/**
 * Small Meta Graph API client used by the BM / ad account system.
 *  - Every BM has its own System User token, optional App Secret (appsecret_proof) and optional proxy
 *  - Proxy formats: http://user:pass@host:port · socks5://user:pass@host:port · host:port:user:pass · host:port
 *  - META_GRAPH_URL in .env only for tests (default https://graph.facebook.com/v21.0)
 */
import crypto from 'crypto';
import http from 'http';
import https from 'https';
import tls from 'tls';
import net from 'net';

export const graphBase = () => (process.env.META_GRAPH_URL || 'https://graph.facebook.com/v21.0').replace(/\/$/, '');

/* ---------------- secrets at rest ---------------- */
const key = () => crypto.createHash('sha256').update('meta|' + (process.env.APP_SECRET || process.env.ADMIN_PASSWORD || 'adflow')).digest();
export function enc(v: string) {
  if (!v) return '';
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', key(), iv);
  const d = Buffer.concat([c.update(v, 'utf8'), c.final()]);
  return 'v1:' + Buffer.concat([iv, c.getAuthTag(), d]).toString('base64');
}
export function dec(v: string | null | undefined) {
  if (!v) return '';
  if (!v.startsWith('v1:')) return v;
  try {
    const b = Buffer.from(v.slice(3), 'base64');
    const d = crypto.createDecipheriv('aes-256-gcm', key(), b.subarray(0, 12));
    d.setAuthTag(b.subarray(12, 28));
    return Buffer.concat([d.update(b.subarray(28)), d.final()]).toString('utf8');
  } catch { return ''; }
}

/* ---------------- proxy ---------------- */
export type Proxy = { type: 'http' | 'socks5'; host: string; port: number; user?: string; pass?: string };
export function parseProxy(raw: string): Proxy | null {
  const s = String(raw || '').trim();
  if (!s) return null;
  if (/^[a-z0-9]+:\/\//i.test(s)) {
    const u = new URL(s);
    const type = /^socks/i.test(u.protocol) ? 'socks5' : 'http';
    if (!u.hostname || !u.port) throw new Error('Proxy needs host and port');
    return { type, host: u.hostname, port: +u.port, user: u.username ? decodeURIComponent(u.username) : undefined, pass: u.password ? decodeURIComponent(u.password) : undefined };
  }
  const p = s.split(':');
  if (p.length === 2 || p.length >= 4) {
    const port = +p[1];
    if (!p[0] || !(port > 0 && port < 65536)) throw new Error('Proxy port looks wrong');
    return { type: 'http', host: p[0], port, user: p[2], pass: p.slice(3).join(':') || undefined };
  }
  throw new Error('Proxy format: http://user:pass@host:port or host:port:user:pass');
}
export const maskProxy = (raw: string) => { try { const p = parseProxy(raw); return p ? `${p.type === 'socks5' ? 'socks5 ' : ''}${p.host}:${p.port}${p.user ? ' · ' + p.user.slice(0, 18) : ''}` : ''; } catch { return 'invalid'; } };

function tunnel(p: Proxy, host: string, port: number, timeout: number): Promise<net.Socket> {
  if (p.type === 'socks5') {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const { SocksClient } = require('socks') as typeof import('socks');
    return SocksClient.createConnection({ proxy: { host: p.host, port: p.port, type: 5, userId: p.user, password: p.pass }, command: 'connect', destination: { host, port }, timeout }).then(r => r.socket);
  }
  return new Promise((resolve, reject) => {
    const headers: Record<string, string> = { host: `${host}:${port}` };
    if (p.user) headers['proxy-authorization'] = 'Basic ' + Buffer.from(`${p.user}:${p.pass || ''}`).toString('base64');
    const req = http.request({ host: p.host, port: p.port, method: 'CONNECT', path: `${host}:${port}`, headers, timeout });
    req.on('connect', (res, socket) => {
      if (res.statusCode !== 200) { socket.destroy(); reject(new Error(`Proxy refused (${res.statusCode})`)); return; }
      resolve(socket);
    });
    req.on('timeout', () => { req.destroy(); reject(new Error('Proxy timeout')); });
    req.on('error', e => reject(new Error('Proxy not reachable: ' + e.message)));
    req.end();
  });
}

type Res = { status: number; text: string };
export async function request(method: string, url: string, form: string | null, proxyRaw: string, timeout = 30000): Promise<Res> {
  const p = proxyRaw ? parseProxy(proxyRaw) : null;
  const u = new URL(url);
  const secure = u.protocol === 'https:';
  const port = +(u.port || (secure ? 443 : 80));
  const headers: Record<string, string> = { accept: 'application/json' };
  if (form !== null) { headers['content-type'] = 'application/x-www-form-urlencoded'; headers['content-length'] = String(Buffer.byteLength(form)); }
  let sock: net.Socket | null = null;
  if (p) {
    const raw = await tunnel(p, u.hostname, port, timeout);
    sock = secure ? tls.connect({ socket: raw, servername: u.hostname }) : raw;
  }
  return new Promise((resolve, reject) => {
    const mod = secure ? https : http;
    const opts: https.RequestOptions = { method, hostname: u.hostname, port, path: u.pathname + u.search, headers, timeout };
    // v152 fix: the request must ride our tunnel. With `agent: false` Node makes a fresh Agent that IGNORES createConnection and
    // connects straight from the server — so no agent at all (undefined) + createConnection = the proxy socket.
    if (sock) { const s = sock; opts.createConnection = () => s as unknown as net.Socket; delete opts.agent; }
    const req = mod.request(opts, res => {
      const chunks: Buffer[] = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode || 0, text: Buffer.concat(chunks).toString('utf8') }));
    });
    req.on('timeout', () => { req.destroy(new Error('Meta did not answer in time')); });
    req.on('error', e => reject(e));
    if (form !== null) req.write(form);
    req.end();
  });
}

/* ---------------- Graph ---------------- */
export class MetaError extends Error {
  constructor(msg: string, public code = 0, public sub = 0, public kind: 'token' | 'perm' | 'limit' | 'net' | 'meta' = 'meta') { super(msg); }
}
export type Creds = { token: string; secret?: string; proxy?: string };

function classify(e: { message?: string; code?: number; error_subcode?: number; error_user_msg?: string; error_user_title?: string; type?: string }) {
  const code = Number(e.code || 0), sub = Number(e.error_subcode || 0);
  const msg = [e.error_user_title, e.error_user_msg || e.message].filter(Boolean).join(': ') || 'Meta error';
  // 190 = token invalid / expired / blocked; 102 session; 368 = blocked for policies; 459/464 checkpoint
  const kind = code === 190 || code === 102 || code === 368 || sub === 459 || sub === 464 || sub === 460 || sub === 463 ? 'token'
    : code === 10 || code === 200 || (code >= 200 && code < 300) ? 'perm' // v153: #3 (one call the app may not make, e.g. assign partner) is not a blocked BM
      : code === 4 || code === 17 || code === 32 || code === 613 || code === 80004 ? 'limit' : 'meta';
  return new MetaError(msg, code, sub, kind as MetaError['kind']);
}

const enc1 = (v: unknown) => (typeof v === 'object' && v !== null ? JSON.stringify(v) : String(v));

/** v152: count of write calls tried (POST/DELETE). The queue uses it to know if a job already changed something on Meta. */
export const WRITES = { n: 0, token: '', hook: null as null | (() => void) };
export async function graph<T = any>(c: Creds, method: 'GET' | 'POST' | 'DELETE', path: string, params: Record<string, unknown> = {}): Promise<T> {
  if (method !== 'GET' && WRITES.token && c.token === WRITES.token) { WRITES.n++; try { WRITES.hook?.(); } catch { /* */ } } // only the running queue job's profile
  const q = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) if (v !== undefined && v !== null) q.set(k, enc1(v));
  q.set('access_token', c.token);
  if (c.secret) q.set('appsecret_proof', crypto.createHmac('sha256', c.secret).update(c.token).digest('hex'));
  const full = /^https?:\/\//.test(path) ? path : `${graphBase()}/${path.replace(/^\//, '')}`;
  const url = method === 'GET' ? `${full}${full.includes('?') ? '&' : '?'}${q}` : full;
  let r: Res;
  try { r = await request(method, url, method === 'GET' ? null : q.toString(), c.proxy || ''); }
  catch (e) { throw new MetaError((e as Error).message || 'Network error', 0, 0, 'net'); }
  let j: any = null;
  try { j = JSON.parse(r.text); } catch { /* not json */ }
  if (j && j.error) throw classify(j.error);
  if (r.status >= 400 || j === null) throw new MetaError(`Meta answered ${r.status}${r.text ? ': ' + r.text.slice(0, 160) : ''}`, r.status, 0, r.status >= 500 ? 'net' : 'meta');
  return j as T;
}

/** GET that follows paging.next (max pages). The next URL already carries the token. */
export async function graphAll<T = any>(c: Creds, path: string, params: Record<string, unknown> = {}, maxPages = 20): Promise<T[]> {
  const out: T[] = [];
  let r = await graph<{ data: T[]; paging?: { next?: string } }>(c, 'GET', path, params);
  out.push(...(r.data || []));
  for (let i = 1; i < maxPages && r.paging?.next; i++) {
    const next = new URL(r.paging.next);
    const p = Object.fromEntries(next.searchParams.entries());
    delete p.access_token; delete p.appsecret_proof;
    const base = graphBase();
    const rel = next.toString().startsWith(base) ? next.pathname.slice(new URL(base).pathname.length) : next.pathname.replace(/^\/v\d+\.\d+/, '');
    r = await graph(c, 'GET', rel, p);
    out.push(...(r.data || []));
  }
  return out;
}
