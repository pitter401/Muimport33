/**
 * v152: proof images after an ad-account share, drawn on the server from LIVE Meta API data + our own records
 * (daily limit / billing threshold typed by the admin). Browser-window style, 16:9, HD.
 * Every image says "Live data via Meta API · AdsBhai records". Our own AdsBhai look — no Meta logo / artwork.
 *  1. Partner assigned  2. Billing (outstanding, you'll pay when, daily limit set by Meta, automatic payment card)
 *  → the client (chat) / our Saved Messages (client without a chat) + the Telegram channel post with buttons.
 */
import fs from 'fs';
import path from 'path';
import { one, run } from './db';
import { getSettings, setSetting } from './settings';
import { now, num, money } from './util';
import { graph, type Creds } from './metagraph';
import * as M from './meta';
import { leadById, displayName, addMsg, uploadToLead } from './crm';

// our Inter font for the drawing (fontconfig reads it; set once before sharp draws text)
const FONT_DIR = path.join(process.cwd(), 'assets', 'fonts');
if (!process.env.FONTCONFIG_FILE && fs.existsSync(path.join(FONT_DIR, 'fonts.conf'))) process.env.FONTCONFIG_FILE = path.join(FONT_DIR, 'fonts.conf');

const W = 1920, H = 1080;
const esc = (s: unknown) => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const usd = (n: number) => '$' + money(n).toFixed(2);
const FONT = `font-family="Inter, 'Helvetica Neue', Arial, sans-serif"`;
/** next day in IST (billing runs the next day) */
function nextDay(s = getSettings()) {
  const d = new Date(now() + num(s.tz_offset_min, 330) * 60000 + 86400000);
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', timeZone: 'UTC' });
}
const stamp = (s = getSettings()) => new Date(now() + num(s.tz_offset_min, 330) * 60000).toLocaleString('en-GB', { day: 'numeric', month: 'short', year: 'numeric', hour: 'numeric', minute: '2-digit', hour12: true, timeZone: 'UTC' }).replace(',', ',');
/** "act_2542••••5160" */
const maskAct = (a: string) => `act_${a.slice(0, 4)}••••${a.slice(-4)}`;
/** split a sentence into lines of about n characters */
function wrap(t: string, n: number) {
  const out: string[] = []; let cur = '';
  for (const w of t.split(/\s+/)) { if ((cur + ' ' + w).trim().length > n && cur) { out.push(cur); cur = w; } else cur = (cur + ' ' + w).trim(); }
  if (cur) out.push(cur);
  return out;
}

export type ProofData = { name: string; act: string; owner: string; partner: string; balance: number; threshold: number | null; dsl: number | null; card: string | null; currency: string; brand: string; site: string; at: string; billDate: string; logo?: string | null;
  topup?: number | null; capTotal?: number | null; remaining?: number | null; fee?: number | null };

/** v155: our uploaded logo (Admin → Brand) in a rounded square; no logo → the gradient square (+ first letter). */
function logoTag(d: ProofData, x: number, y: number, w: number, rx: number, letter = 0) {
  if (d.logo) {
    const id = `lc${x}_${y}`;
    return `<clipPath id="${id}"><rect x="${x}" y="${y}" width="${w}" height="${w}" rx="${rx}"/></clipPath><rect x="${x}" y="${y}" width="${w}" height="${w}" rx="${rx}" fill="#fff"/><image href="${d.logo}" x="${x}" y="${y}" width="${w}" height="${w}" preserveAspectRatio="xMidYMid meet" clip-path="url(#${id})"/>`;
  }
  return `<rect x="${x}" y="${y}" width="${w}" height="${w}" rx="${rx}" fill="url(#lg)"/>${letter ? `<text x="${x + w / 2}" y="${y + w * 0.705}" font-size="${letter}" font-weight="700" fill="#fff" text-anchor="middle">${esc(d.brand.slice(0, 1).toUpperCase())}</text>` : ''}`;
}

/* ---------------- frame: browser window + our app bar ---------------- */
function frame(d: ProofData, urlPath: string, inner: string) {
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" ${FONT}>
<defs><linearGradient id="bgp" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f4eff8"/><stop offset="1" stop-color="#eef3f8"/></linearGradient>
<linearGradient id="lg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#7c3aed"/><stop offset="1" stop-color="#c026d3"/></linearGradient>
<filter id="blur" x="-20%" y="-50%" width="140%" height="200%"><feGaussianBlur stdDeviation="5"/></filter>
<filter id="sh" x="-10%" y="-10%" width="120%" height="130%"><feDropShadow dx="0" dy="10" stdDeviation="22" flood-color="#000" flood-opacity="0.28"/></filter></defs>
<rect width="${W}" height="${H}" fill="url(#bgp)"/>
<rect width="${W}" height="62" fill="#e9eaee"/>
<circle cx="28" cy="31" r="9" fill="#ff5f57"/><circle cx="56" cy="31" r="9" fill="#febc2e"/><circle cx="84" cy="31" r="9" fill="#28c840"/>
<rect x="120" y="12" width="360" height="50" rx="12" fill="#fff"/>${logoTag(d, 140, 27, 20, 5)}
<text x="172" y="44" font-size="19" fill="#333">${esc(d.brand)} · Account delivery</text>
<rect y="62" width="${W}" height="54" fill="#f6f6f8"/><rect x="70" y="70" width="${W - 90}" height="38" rx="19" fill="#fff" stroke="#ddd"/>
<text x="22" y="96" font-size="20" fill="#888">‹ ›</text><text x="96" y="96" font-size="18" fill="#555">🔒 ${esc(d.site)}/delivery/${esc(maskAct(d.act).replace('act_', 'act_'))}${esc(urlPath)}</text>
<rect y="116" width="${W}" height="84" fill="#fff"/><line x1="0" y1="200" x2="${W}" y2="200" stroke="#e4e6eb" stroke-width="2"/>
${logoTag(d, 34, 136, 44, 11, 24)}
<text x="96" y="168" font-size="30" font-weight="700" fill="#1c2b33">${esc(d.brand)} Ad Accounts${urlPath ? ' · ' + esc(d.owner) : ''}</text>
<rect x="${W - 690}" y="136" width="656" height="44" rx="22" fill="#f1ecff" stroke="#ddd2ff"/>
<text x="${W - 362}" y="165" font-size="20" font-weight="600" fill="#6b4bd8" text-anchor="middle">Live data via Meta API · ${esc(d.brand)} records · ${esc(d.at)}</text>
${inner}
</svg>`;
}

/* ---------------- 1. Partner assigned ---------------- */
function gift(x: number, y: number) {
  return `<g transform="translate(${x},${y}) scale(1.35)">
<defs><linearGradient id="bx" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffd1ec"/><stop offset=".55" stop-color="#f59bd6"/><stop offset="1" stop-color="#c58cf0"/></linearGradient>
<linearGradient id="bxs" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#d98ae0"/><stop offset="1" stop-color="#b57be8"/></linearGradient>
<linearGradient id="ld" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#e9b6ff"/><stop offset="1" stop-color="#a67cf0"/></linearGradient>
<linearGradient id="rb" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2f7bff"/><stop offset="1" stop-color="#0a4fd6"/></linearGradient>
<radialGradient id="gl" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#fff6b0"/><stop offset="1" stop-color="#fff6b0" stop-opacity="0"/></radialGradient></defs>
<ellipse cx="135" cy="120" rx="55" ry="22" fill="url(#gl)"/>
<polygon points="78,120 140,100 192,122 130,145" fill="#fff3a8"/><polygon points="78,120 130,145 130,200 80,175" fill="url(#bx)"/><polygon points="130,145 192,122 190,177 130,200" fill="url(#bxs)"/>
<polygon points="101,131 112,136 112,192 101,186" fill="url(#rb)"/><polygon points="158,134 169,130 168,186 158,190" fill="url(#rb)"/>
<g transform="rotate(-14 85 60)"><polygon points="35,62 92,44 140,62 83,82" fill="url(#ld)"/><polygon points="35,62 83,82 83,98 35,78" fill="#c58cf0"/><polygon points="83,82 140,62 140,78 83,98" fill="#9b6ee6"/>
<polygon points="58,55 68,52 116,70 106,74" fill="url(#rb)"/><path d="M88,58 C62,30 44,40 56,56 C64,66 80,62 88,58 Z" fill="url(#rb)"/><path d="M90,58 C110,26 132,34 122,52 C114,64 98,62 90,58 Z" fill="#1e63f0"/></g>
<path d="M175,40 c8,10 -6,16 2,26 s-4,18 4,26" stroke="#f9a8e8" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M190,22 c-6,8 6,12 0,20" stroke="#fcd34d" stroke-width="4" fill="none" stroke-linecap="round"/>
<path d="M60,150 c-10,6 -2,14 -12,20" stroke="#fde68a" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M168,95 c10,-4 10,8 20,4" stroke="#c4b5fd" stroke-width="4" fill="none" stroke-linecap="round"/>
<rect x="45" y="105" width="8" height="8" fill="#a78bfa" transform="rotate(25 49 109)"/><rect x="200" y="140" width="7" height="7" fill="#c4b5fd"/><rect x="150" y="30" width="7" height="7" fill="#f472b6" transform="rotate(40 153 33)"/><circle cx="205" cy="70" r="3" fill="#fbbf24"/></g>`;
}
export function partnerSvg(d: ProofData) {
  const lines = wrap(`Partner ${d.partner} assigned to ${d.name} from ${d.owner}.`, 62);
  const mx = 560, my = 300, mw = 800;
  const mh = 560 + lines.length * 34;
  const inner = `<rect y="200" width="${W}" height="${H - 200}" fill="#8a8d91"/>
<rect y="200" width="640" height="${H - 200}" fill="#9a9da1"/><text x="40" y="262" font-size="34" font-weight="700" fill="#1f2328">Ad accounts</text>
<text x="40" y="330" font-size="24" fill="#1f2328">${esc(d.name.slice(0, 38))}</text><line x1="40" y1="362" x2="600" y2="362" stroke="#8d9094"/>
<rect x="${mx}" y="${my}" width="${mw}" height="${mh}" rx="14" fill="#fff" filter="url(#sh)"/>
<text x="${mx + 32}" y="${my + 52}" font-size="27" font-weight="600" fill="#1c2b33">Ad account shared with partner</text><text x="${mx + mw - 42}" y="${my + 52}" font-size="30" fill="#333">×</text>
<line x1="${mx}" y1="${my + 82}" x2="${mx + mw}" y2="${my + 82}" stroke="#eceef1" stroke-width="2"/>
${gift(mx + mw / 2 - 175, my + 100)}
<text x="${mx + mw / 2}" y="${my + 430}" font-size="29" font-weight="700" fill="#1c2b33" text-anchor="middle">Partner assigned</text>
${lines.map((l, i) => `<text x="${mx + mw / 2}" y="${my + 476 + i * 34}" font-size="23" fill="#1c2b33" text-anchor="middle">${esc(l)}</text>`).join('')}
<rect x="${mx + mw - 150}" y="${my + mh - 78}" width="120" height="54" rx="9" fill="#0a78be"/><text x="${mx + mw - 90}" y="${my + mh - 43}" font-size="23" font-weight="600" fill="#fff" text-anchor="middle">Done</text>`;
  return frame(d, '', inner);
}

/* ---------------- 2. Billing ---------------- */
export function billingSvg(d: ProofData) {
  const L = 40, R = W - 40, cw = R - L;
  const card = d.card ? d.card.replace(/^\s*(\w+)\s*\*?(\d{4})$/, '$1 $2') : null;
  const [brand, last4] = card ? [card.split(' ')[0].toUpperCase(), card.split(' ').pop() || ''] : ['', ''];
  const hasYp = d.threshold != null;
  let y = 290;
  let inner = `<rect x="${L}" y="232" width="62" height="62" rx="10" fill="#fff" stroke="#d6d8dd"/><text x="${L + 31}" y="273" font-size="28" fill="#1c2b33" text-anchor="middle">‹</text>
<text x="${L + 86}" y="275" font-size="36" font-weight="700" fill="#1c2b33">${esc(d.name.slice(0, 60))}</text>`;
  // card 1
  const c1h = (hasYp ? 520 : 360) + (d.dsl != null ? 0 : -90);
  y = 320;
  inner += `<rect x="${L}" y="${y}" width="${cw}" height="${c1h}" rx="14" fill="#fff"/>
<text x="${L + 32}" y="${y + 56}" font-size="27" font-weight="600" fill="#1c2b33">Outstanding balance</text>
<text x="${L + 32}" y="${y + 130}" font-size="58" fill="#1c2b33">${esc(usd(d.balance))}</text><text x="${L + 32 + 34 * usd(d.balance).length + 10}" y="${y + 128}" font-size="20" fill="#606770">+ any applicable fees</text>
<text x="${L + 32}" y="${y + 168}" font-size="21" fill="#606770">No payment due at this time.</text>`;
  let cy = y + 200;
  if (hasYp) {
    inner += `<line x1="${L + 32}" y1="${cy}" x2="${R - 32}" y2="${cy}" stroke="#e4e6eb" stroke-width="2"/>
<text x="${L + 32}" y="${cy + 50}" font-size="25" font-weight="600" fill="#1c2b33">You'll pay when</text>
<rect x="${L + 32}" y="${cy + 72}" width="${cw / 2 - 40}" height="96" fill="#f5f6f7"/><rect x="${L + cw / 2 + 8}" y="${cy + 72}" width="${cw / 2 - 40}" height="96" fill="#f5f6f7"/>
<text x="${L + 56}" y="${cy + 110}" font-size="20" fill="#606770">Your balance reaches</text><text x="${L + 56}" y="${cy + 146}" font-size="26" fill="#1c2b33">${esc(usd(d.threshold || 0))}</text>
<text x="${L + cw / 2 + 32}" y="${cy + 110}" font-size="20" fill="#606770">And on this date</text><text x="${L + cw / 2 + 32}" y="${cy + 146}" font-size="26" fill="#1c2b33">${esc(d.billDate)}</text>`;
    cy += 200;
  }
  if (d.dsl != null) {
    const lab = 'Daily spending limit (set by Meta): ';
    const lx = L + 32 + lab.length * 11.9;
    inner += `<line x1="${L + 32}" y1="${cy}" x2="${R - 32}" y2="${cy}" stroke="#e4e6eb" stroke-width="2"/>
<text x="${L + 32}" y="${cy + 52}" font-size="25" fill="#1c2b33">${esc(lab)}</text>
<rect x="${lx - 6}" y="${cy + 38}" width="${usd(d.dsl).length * 15.5 + 12}" height="18" fill="#fde68a"/><text x="${lx}" y="${cy + 52}" font-size="25" font-weight="700" fill="#1c2b33">${esc(usd(d.dsl))}</text>
<circle cx="${L + 38}" cy="${cy + 86}" r="5" fill="#0b6e4f"/><text x="${L + 52}" y="${cy + 93}" font-size="20" fill="#606770">Your projected spend today is within this limit</text>`;
  }
  // card 2
  const y2 = y + c1h + 20;
  if (card) inner += `<rect x="${L}" y="${y2}" width="${cw}" height="190" rx="14" fill="#fff"/>
<text x="${L + 32}" y="${y2 + 54}" font-size="27" font-weight="600" fill="#1c2b33">How you'll pay</text>
<rect x="${L + 32}" y="${y2 + 76}" width="${cw - 64}" height="92" rx="10" fill="#fff" stroke="#e4e6eb" stroke-width="2"/>
<text x="${L + 56}" y="${y2 + 112}" font-size="22" font-weight="700" fill="#1c2b33">Automatic payments</text>
<rect x="${L + 56}" y="${y2 + 126}" width="54" height="30" rx="4" fill="#1a1f71"/><text x="${L + 83}" y="${y2 + 148}" font-size="15" font-weight="800" fill="#fff" text-anchor="middle">${esc(brand.slice(0, 4))}</text>
<text x="${L + 122}" y="${y2 + 149}" font-size="22" fill="#1c2b33">${esc(brand.charAt(0) + brand.slice(1).toLowerCase())} ····</text>
<text x="${L + 122 + (brand.length + 5) * 11.6}" y="${y2 + 149}" font-size="22" fill="#1c2b33" filter="url(#blur)">${esc(last4)}</text>
<text x="${L + 122 + (brand.length + 5) * 11.6 + 64}" y="${y2 + 149}" font-size="22" fill="#1c2b33">will be charged to pay your balance.</text>`;
  return frame(d, '/billing', inner);
}

/* ---------------- 3. Top-up (v157): only when money was put on the account with the share ---------------- */
export function topupSvg(d: ProofData) {
  const mx = 200, my = 236, mw = 1520, mh = 810, cx = mx + mw / 2;
  const amt = usd(d.topup || 0).replace(/\.00$/, '');
  const row = (y: number, k: string, v: string, hi = false) => `<text x="${mx + 90}" y="${y}" font-size="36" fill="#606770">${esc(k)}</text><text x="${mx + mw - 90}" y="${y}" font-size="38" font-weight="${hi ? 800 : 700}" fill="${hi ? '#0b6e4f' : '#1c2b33'}" text-anchor="end">${esc(v)}</text>`;
  const rows: [string, string, boolean?][] = [['Top-up added', usd(d.topup || 0), true]];
  if (d.capTotal != null) rows.push(['Account spending limit', usd(d.capTotal)]);
  if (d.remaining != null) rows.push(['Remaining amount', usd(d.remaining)]);
  if (d.fee) rows.push(['Top-up fee', `${usd(d.fee)} (${num(getSettings().topup_comm_pct, 3)}%)`]);
  const inner = `<rect y="200" width="${W}" height="${H - 200}" fill="#eef0f4"/>
<rect x="${mx}" y="${my}" width="${mw}" height="${mh}" rx="26" fill="#fff" filter="url(#sh)"/>
<circle cx="${mx + 150}" cy="${my + 140}" r="74" fill="#e7f7ef"/><circle cx="${mx + 150}" cy="${my + 140}" r="56" fill="none" stroke="#0b6e4f" stroke-width="9"/>
<path d="M${mx + 124} ${my + 140} l18 19 l36 -38" fill="none" stroke="#0b6e4f" stroke-width="10" stroke-linecap="round" stroke-linejoin="round"/>
<text x="${mx + 260}" y="${my + 130}" font-size="64" font-weight="800" fill="#1c2b33">Top-up added: ${esc(amt)}</text>
<text x="${mx + 260}" y="${my + 186}" font-size="30" fill="#606770">${esc(d.name.slice(0, 52))}</text>
<line x1="${mx + 60}" y1="${my + 260}" x2="${mx + mw - 60}" y2="${my + 260}" stroke="#eceef1" stroke-width="3"/>
${rows.map(([k, v, hi], i) => row(my + 340 + i * 112, k, v, !!hi) + (i < rows.length - 1 ? `<line x1="${mx + 90}" y1="${my + 384 + i * 112}" x2="${mx + mw - 90}" y2="${my + 384 + i * 112}" stroke="#f1f2f5" stroke-width="3"/>` : '')).join('')}`;
  return frame(d, '/top-up', inner);
}

/* ---------------- channel post image ---------------- */
export function postBgSvg(d: ProofData, o: { client: number; premium: boolean; verified: string | null; topup?: number | null }) {
  const chip = (x: number, y: number, w: number, k: string, v: string) => `<rect x="${x}" y="${y}" width="${w}" height="104" rx="16" fill="#ffffff" fill-opacity="0.08" stroke="#ffffff" stroke-opacity="0.16"/>
<text x="${x + 22}" y="${y + 38}" font-size="16" font-weight="700" fill="#c4b5fd" letter-spacing="1.5">${esc(k)}</text><text x="${x + 22}" y="${y + 80}" font-size="30" font-weight="800" fill="#fff">${esc(v)}</text>`;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" ${FONT}>
<defs><radialGradient id="a" cx="0.85" cy="-0.1" r="0.7"><stop offset="0" stop-color="#7c3aed"/><stop offset="1" stop-color="#160b2e" stop-opacity="0"/></radialGradient>
<radialGradient id="b" cx="0" cy="1.1" r="0.6"><stop offset="0" stop-color="#4c1d95"/><stop offset="1" stop-color="#160b2e" stop-opacity="0"/></radialGradient>
<linearGradient id="lg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#8b5cf6"/><stop offset="1" stop-color="#d946ef"/></linearGradient></defs>
<rect width="${W}" height="${H}" fill="#160b2e"/><rect width="${W}" height="${H}" fill="url(#a)"/><rect width="${W}" height="${H}" fill="url(#b)"/>
${logoTag(d, 50, 36, 50, 13)}<text x="116" y="74" font-size="31" font-weight="800" fill="#fff" letter-spacing="1">${esc(d.brand.toUpperCase())}</text>
<rect x="${120 + d.brand.length * 25}" y="40" width="330" height="42" rx="21" fill="none" stroke="#22c55e" stroke-width="2.5"/>
<text x="${120 + d.brand.length * 25 + 165}" y="68" font-size="19" font-weight="700" fill="#86efac" text-anchor="middle">● DELIVERED · CLIENT #${o.client}</text>
<text x="${W - 50}" y="76" font-size="42" font-weight="800" fill="#fff" text-anchor="end">${o.premium ? 'Premium ad account' : 'Ad account'} <tspan fill="#e9a8ff">delivered</tspan></text>
<text x="76" y="146" font-size="21" font-weight="700" fill="#fff">✓  Billing · daily limit set by Meta</text>
<text x="1410" y="296" font-size="21" font-weight="700" fill="#fff">✓  Shared to the client BM (partner)</text>
${o.topup ? `<text x="1410" y="606" font-size="21" font-weight="700" fill="#fff">✓  Top-up added: <tspan fill="#86efac">${esc(usd(o.topup).replace(/\.00$/, ''))}</tspan></text>
<rect x="${W - 50 - 300}" y="96" width="300" height="44" rx="22" fill="#16a34a"/><text x="${W - 200}" y="126" font-size="22" font-weight="800" fill="#fff" text-anchor="middle">+ ${esc(usd(o.topup).replace(/\.00$/, ''))} TOP-UP</text>`
  : `${chip(1410, 620, 222, 'DAILY LIMIT', d.dsl != null ? usd(d.dsl) : '—')}${chip(1648, 620, 222, o.verified ? 'VERIFIED SINCE' : 'BUSINESS', o.verified || 'Verified')}
${chip(1410, 740, 222, 'ACCESS', 'Partner')}${chip(1648, 740, 222, 'TOP-UP FEE', `${num(getSettings().topup_comm_pct, 3)}%`)}`}
<text x="1410" y="900" font-size="24" font-weight="700" fill="#fff">${esc(d.site)}${getSettings().bot_username ? ' · @' + esc(getSettings().bot_username) : ''}</text>
<text x="1410" y="934" font-size="19" fill="#d8ccff">Live data via Meta API · ${esc(d.brand)} records</text><text x="1410" y="962" font-size="19" fill="#d8ccff">${esc(d.at)}</text>
</svg>`;
}

/* ---------------- render ---------------- */
async function sharpLib() { return (await import('sharp')).default; }
/** SVG → PNG at 4K, then HD for Telegram (2560 wide, sharpened). */
export async function render(svg: string, width = 2560) {
  const sharp = await sharpLib();
  const big = await sharp(Buffer.from(svg), { density: 144 }).png().toBuffer();
  return sharp(big).resize({ width, kernel: 'lanczos3' }).sharpen({ sigma: 0.6 }).png({ compressionLevel: 8 }).toBuffer();
}
export async function postImage(d: ProofData, o: { client: number; premium: boolean; verified: string | null; topup?: number | null }, partner: Buffer, billing: Buffer, topup?: Buffer | null) {
  const sharp = await sharpLib();
  const bg = await sharp(Buffer.from(postBgSvg(d, o)), { density: 144 }).png().toBuffer(); // 3840×2160
  const round = async (buf: Buffer, w: number) => {
    const h = Math.round(w * 9 / 16);
    const mask = Buffer.from(`<svg width="${w}" height="${h}"><rect width="${w}" height="${h}" rx="28" fill="#fff"/></svg>`);
    return sharp(buf).resize({ width: w }).composite([{ input: mask, blend: 'dest-in' }]).png().toBuffer();
  };
  const bill = await round(billing, 2600), part = await round(partner, 920);
  // v157: with a top-up → its image under the partner one (the chips move out, the amount is in the header)
  const out = await sharp(bg).composite([{ input: bill, left: 104, top: 320 }, { input: part, left: 2820, top: 640 },
    ...(topup ? [{ input: await round(topup, 920), left: 2820, top: 1240 }] : [])]).png().toBuffer();
  return sharp(out).resize({ width: 2560, kernel: 'lanczos3' }).sharpen({ sigma: 0.6 }).png({ compressionLevel: 8 }).toBuffer();
}

/* ---------------- data + delivery ---------------- */
export async function proofData(act: string): Promise<ProofData> {
  const s = getSettings();
  const a = M.acctOf(act);
  if (!a) throw new Error('Account not found');
  const bm = M.bmOf(a.bm_id);
  let capC = a.cap || 0, spentC = a.spent || 0;
  let balance = 0, card = a.card, owner = bm?.name || '', name = a.name || '', currency = a.currency || 'USD';
  if (bm?.profile_id && M.JOB.active) {
    // live from Meta (we are inside the queue, after the IP change)
    const p = M.profileById(bm.profile_id)!;
    const { dec } = await import('./metagraph');
    const c: Creds = { token: dec(p.token_enc), secret: dec(p.secret_enc) || undefined, proxy: s.mq_proxy };
    const r = await graph<{ name?: string; balance?: string; currency?: string; spend_cap?: string; amount_spent?: string; funding_source_details?: { display_string?: string }; business?: { name?: string } }>(c, 'GET', 'act_' + a.act_id, { fields: 'name,balance,currency,spend_cap,amount_spent,funding_source_details,business{name}' });
    if (r.spend_cap != null && num(r.spend_cap) > 0) { capC = num(r.spend_cap); spentC = num(r.amount_spent); }
    balance = num(r.balance) / 100; card = r.funding_source_details?.display_string || card; owner = r.business?.name || owner; name = r.name || name; currency = r.currency || currency;
  }
  const site = ((await import('./email')).publicUrl() || 'adsbhai.com').replace(/^https?:\/\//, '').replace(/\/$/, '');
  return { name, act: a.act_id, owner, partner: a.partner_name || a.biz_name || `BM ${a.client_bm || ''}`.trim(), balance, threshold: a.bill_threshold ?? null, dsl: a.dsl ?? null,
    card, currency, brand: s.brand_name || 'AdsBhai', site, at: stamp(s), billDate: nextDay(s), logo: await logoData(),
    ...topupOf(a.act_id, capC, spentC) };
}
/** v157: the top-up given with this share (with the account + the client's credit), and the limit after it. */
function topupOf(act: string, capC: number, spentC: number) {
  const r = one<{ assigned_at: number | null }>('SELECT assigned_at FROM meta_accounts WHERE act_id=?', act);
  if (!r?.assigned_at) return { topup: null };
  const x = one<{ v: number; f: number }>("SELECT COALESCE(SUM(amount),0) v, COALESCE(SUM(CASE WHEN kind='topup' THEN fee ELSE 0 END),0) f FROM meta_log WHERE act_id=? AND kind IN ('topup','share') AND created_at>=? AND created_at<=?", act, r.assigned_at - 5000, r.assigned_at + 15 * 60000);
  const v = money(x?.v || 0);
  return v > 0 ? { topup: v, fee: money(x?.f || 0) || null, capTotal: capC > 0 ? capC / 100 : null, remaining: capC > 0 ? Math.max(0, capC - spentC) / 100 : null } : { topup: null };
}

async function tgPhoto(chat: string, png: Buffer, caption: string, markup?: unknown) {
  const s = getSettings();
  const fd = new FormData();
  fd.append('chat_id', chat);
  if (caption) fd.append('caption', caption);
  if (markup) fd.append('reply_markup', JSON.stringify(markup));
  fd.append('photo', new File([new Uint8Array(png)], 'proof.png', { type: 'image/png' }), 'proof.png');
  const r = await fetch(`${process.env.TG_API_BASE || 'https://api.telegram.org'}/bot${s.bot_token}/sendPhoto`, { method: 'POST', body: fd, signal: AbortSignal.timeout(120000) });
  const j = await r.json() as { ok: boolean; description?: string };
  if (!j.ok) throw new Error(j.description || 'Telegram refused the photo');
  return j;
}

/** v155: several photos as one Telegram album; the caption sits on the album (one message for the reader). */
async function tgAlbum(chat: string, pngs: { name: string; data: Buffer }[], caption: string, conn?: string | null) {
  const s = getSettings();
  const fd = new FormData();
  fd.append('chat_id', chat);
  if (conn) fd.append('business_connection_id', conn);
  fd.append('media', JSON.stringify(pngs.map((p, i) => ({ type: 'photo', media: `attach://p${i}`, ...(i === 0 && caption ? { caption } : {}) }))));
  pngs.forEach((p, i) => fd.append(`p${i}`, new File([new Uint8Array(p.data)], p.name, { type: 'image/png' }), p.name));
  const r = await fetch(`${process.env.TG_API_BASE || 'https://api.telegram.org'}/bot${s.bot_token}/sendMediaGroup`, { method: 'POST', body: fd, signal: AbortSignal.timeout(120000) });
  const j = await r.json() as { ok: boolean; description?: string; result?: { message_id: number; photo?: { file_id: string }[] }[] };
  if (!j.ok) throw new Error(j.description || 'Telegram refused the album');
  return j.result || [];
}

/** Channel caption in our usual format (English; the client named as in the chat). */
export function postCaption(o: { client: number; name: string; premium: boolean; verified: string | null; dsl: number | null; topup?: number | null }) {
  const s = getSettings();
  const site = '';
  void site;
  const pct = num(s.topup_comm_pct, 3);
  return [`✅ Delivered — Client #${o.client}`, '', `${o.name} got:`, '',
    `🔷 ${o.premium ? 'Premium agency' : 'Agency'} ad account, shared to his Business Manager`,
    `🔷 Verified business${o.verified ? `, verified since ${o.verified}` : ''}`,
    `🔷 No 18% GST, top-ups at just ${pct}% fee`, '',
    ...(o.topup ? [`💰 Top-up added: ${usd(o.topup).replace(/\.00$/, '')}`] : []),
    ...(o.dsl != null ? [`💳 Daily limit ${usd(o.dsl).replace(/\.00$/, '')}`] : []),
    '🚀 Ready to run ads from day one', '', 'Your next account is one message away ❤️', '',
  ].join('\n');
}
/** v156: story caption (stories allow only 200 characters on a normal account). */
export function storyCaption(o: { client: number; premium: boolean; verified: string | null; dsl: number | null; bot: string; site: string; topup?: number | null }) {
  return [`✅ Delivered — Client #${o.client}`, o.premium ? 'Premium ad account' : 'Ad account',
    ...(o.topup ? [`💰 Top-up added ${usd(o.topup).replace(/\.00$/, '')}`] : []),
    ...(o.dsl != null ? [`💳 Daily limit ${usd(o.dsl).replace(/\.00$/, '')}`] : []),
    ...(o.verified ? [`✔️ Verified since ${o.verified}`] : []),
    `💬 ${o.bot ? '@' + o.bot + ' · ' : ''}${o.site}`].join('\n').slice(0, 200);
}
const fmtDate = (v: string | null | undefined) => { if (!v) return null; const d = new Date(v + 'T00:00:00Z'); return isNaN(+d) ? null : d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' }); };

/** 9:16 version of the post (story / WhatsApp status): billing on top, partner below, chips, footer. HD 1440×2560. */
export function storyBgSvg(d: ProofData, o: { client: number; premium: boolean; verified: string | null; topup?: number | null }) {
  // v157: everything above y 1770 — Telegram puts the story caption over the bottom part
  const SW = 1080, SH = 1920;
  const chip = (x: number, y: number, k: string, v: string) => `<rect x="${x}" y="${y}" width="474" height="108" rx="18" fill="#fff" fill-opacity="0.08" stroke="#fff" stroke-opacity="0.16"/>
<text x="${x + 26}" y="${y + 40}" font-size="19" font-weight="700" fill="#c4b5fd" letter-spacing="1.5">${esc(k)}</text><text x="${x + 26}" y="${y + 86}" font-size="34" font-weight="800" fill="#fff">${esc(v)}</text>`;
  const amt = o.topup ? usd(o.topup).replace(/\.00$/, '') : '';
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${SW}" height="${SH}" viewBox="0 0 ${SW} ${SH}" ${FONT}>
<defs><radialGradient id="a" cx="0.9" cy="0" r="0.8"><stop offset="0" stop-color="#7c3aed"/><stop offset="1" stop-color="#160b2e" stop-opacity="0"/></radialGradient>
<radialGradient id="b" cx="0" cy="1" r="0.7"><stop offset="0" stop-color="#4c1d95"/><stop offset="1" stop-color="#160b2e" stop-opacity="0"/></radialGradient>
<linearGradient id="lg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#8b5cf6"/><stop offset="1" stop-color="#d946ef"/></linearGradient></defs>
<rect width="${SW}" height="${SH}" fill="#160b2e"/><rect width="${SW}" height="${SH}" fill="url(#a)"/><rect width="${SW}" height="${SH}" fill="url(#b)"/>
${logoTag(d, 60, 80, 56, 14)}<text x="134" y="122" font-size="34" font-weight="800" fill="#fff" letter-spacing="1">${esc(d.brand.toUpperCase())}</text>
<rect x="60" y="168" width="380" height="50" rx="25" fill="none" stroke="#22c55e" stroke-width="3"/><text x="250" y="201" font-size="22" font-weight="700" fill="#86efac" text-anchor="middle">● DELIVERED · CLIENT #${o.client}</text>
<rect x="560" y="168" width="460" height="50" rx="25" fill="#fff" fill-opacity="0.1" stroke="#c4b5fd" stroke-opacity="0.5"/><text x="790" y="201" font-size="21" font-weight="700" fill="#e9d5ff" text-anchor="middle">● Live data fetched via Meta API</text>
<text x="1020" y="252" font-size="19" fill="#d8ccff" text-anchor="end">${esc(d.site)} · ${esc(d.at)}</text>
<text x="60" y="320" font-size="62" font-weight="800" fill="#fff">${o.premium ? 'Premium ad account' : 'Ad account'}</text><text x="60" y="396" font-size="62" font-weight="800" fill="#e9a8ff">delivered${amt ? ` <tspan fill="#86efac">+ ${esc(amt)}</tspan>` : ''}</text>
<text x="90" y="452" font-size="24" font-weight="700" fill="#fff">✓  Billing · daily limit set by Meta</text>
${o.topup ? `<text x="90" y="1012" font-size="22" font-weight="700" fill="#fff">✓  Shared to the client BM</text><text x="560" y="1012" font-size="22" font-weight="700" fill="#fff">✓  Top-up added: ${esc(amt)}</text>
<text x="540" y="1370" font-size="84" font-weight="900" fill="#86efac" text-anchor="middle">+ ${esc(amt)}</text><text x="540" y="1420" font-size="28" font-weight="700" fill="#fff" text-anchor="middle">top-up added with the account</text>`
  : `<text x="90" y="1012" font-size="24" font-weight="700" fill="#fff">✓  Shared to the client BM (partner)</text>`}
${chip(60, 1550, 'DAILY LIMIT', d.dsl != null ? usd(d.dsl) : '—')}${chip(546, 1550, o.verified ? 'VERIFIED SINCE' : 'BUSINESS', o.verified || 'Verified')}
<text x="540" y="1716" font-size="30" font-weight="700" fill="#d8ccff" text-anchor="middle">${esc(d.site)}${getSettings().bot_username ? ' · @' + esc(getSettings().bot_username) : ''}</text>
</svg>`;
}
export async function storyImage(d: ProofData, o: { client: number; premium: boolean; verified: string | null; topup?: number | null }, partner: Buffer, billing: Buffer, topup?: Buffer | null) {
  const sharp = await sharpLib();
  const bg = await sharp(Buffer.from(storyBgSvg(d, o)), { density: 144 }).png().toBuffer(); // 2160×3840
  const round = async (buf: Buffer, w: number) => {
    const h = Math.round(w * 9 / 16);
    const mask = Buffer.from(`<svg width="${w}" height="${h}"><rect width="${w}" height="${h}" rx="28" fill="#fff"/></svg>`);
    return sharp(buf).resize({ width: w }).composite([{ input: mask, blend: 'dest-in' }]).png().toBuffer();
  };
  // px = 2 × svg: billing 960 wide at svg (60,470); partner below (or partner + top-up side by side)
  const out = await sharp(bg).composite(topup
    ? [{ input: await round(billing, 1800), left: 180, top: 940 }, { input: await round(partner, 880), left: 180, top: 2050 }, { input: await round(topup, 880), left: 1100, top: 2050 }]
    : [{ input: await round(billing, 1800), left: 180, top: 940 }, { input: await round(partner, 1800), left: 180, top: 2050 }]).png().toBuffer();
  return sharp(out).resize({ width: 1440, kernel: 'lanczos3' }).sharpen({ sigma: 0.6 }).png({ compressionLevel: 8 }).toBuffer();
}

/** Make the images and send them:
 *  - the client's chat (Telegram or WhatsApp) gets the 2 proof images (a client without a chat: nothing — it is in our Saved Messages)
 *  - our Telegram Saved Messages (chat account) always get the post: 16:9 + 9:16 + the caption (manual clients also the 2 raw images)
 *  - the Telegram channel gets the 16:9 post with buttons (WhatsApp sales too). */
export async function deliverProof(act: string, o: { manual?: boolean; force?: boolean; noWait?: boolean; step?: (t: string) => void } = {}) {
  const s = getSettings();
  const say = o.step || (() => {});
  const a = M.acctOf(act);
  if (!a) return { ok: false };
  const lead = a.lead_id ? leadById(a.lead_id) : undefined;
  // v155: one album + one channel post per sale. A restart / re-run never sends them twice ("Send again" forces it).
  const claimed = o.force || run('UPDATE meta_accounts SET proof_at=? WHERE act_id=? AND COALESCE(proof_at,0)<=0', now(), act).changes > 0;
  if (!claimed) { say('Proof images were already sent for this sale'); await shareMsgNow(act, lead, say); return { ok: true, skipped: true }; }
  let topImg: Buffer | null = null;
  let d!: Awaited<ReturnType<typeof proofData>>, partner!: Buffer, billing!: Buffer, files!: { name: string; data: Buffer }[], manual = false; // eslint-disable-line prefer-const
  try {
  d = await proofData(act);
  say('Drawing the proof images');
  partner = await render(partnerSvg(d)); billing = await render(billingSvg(d));
  topImg = d.topup ? await render(topupSvg(d)) : null;
  if (topImg) { const a1 = M.acctOf(act); void import('./digest').then(D => D.saveTopupImg(act, topImg!, { since: (a1?.assigned_at || now()) - 5000 })).catch(() => 0); } // v158: kept for the daily post
  files = [{ name: 'partner-assigned.png', data: partner }, { name: 'billing.png', data: billing }, ...(topImg ? [{ name: 'top-up.png', data: topImg }] : [])];
  manual = o.manual || !!(lead as { manual_client?: number } | undefined)?.manual_client || !lead?.tg_chat_id;
  if (!manual && lead && s.meta_proof_client !== '0') {
    // v155: Telegram → one album (the 2 images together); WhatsApp (no albums) or a refused album → one by one
    let albumOk = false;
    if (lead.tg_chat_id && !lead.tg_chat_id.startsWith('wa:')) {
      try {
        const res = await tgAlbum(lead.tg_chat_id, files, '', lead.biz_conn);
        res.forEach((m, i) => addMsg(lead, { dir: 'out', sender: 'agent', agent_id: lead.agent_id, text: '', file_id: m.photo?.[m.photo.length - 1]?.file_id || null, file_type: 'photo', file_name: files[i]?.name || 'proof.png', tg_msg_id: m.message_id }));
        albumOk = true;
      } catch (e) { say('Album: ' + (e as Error).message + ' → one by one'); }
    }
    if (!albumOk) for (const f of files) {
      try { const fd = new FormData(); fd.append('file', new File([new Uint8Array(f.data)], f.name, { type: 'image/png' })); fd.append('kind', 'photo'); await uploadToLead(lead, fd, 'agent', lead.agent_id); }
      catch (e) { addMsg(lead, { dir: 'sys', sender: 'system', text: `⚠️ Proof image not sent to the client (${(e as Error).message}). Send it yourself from Ad accounts.` }); break; }
    }
    say('Proof images sent to the client');
  }
  } catch (e) {
    // nothing reached the client yet (Meta / drawing failed) → the next try (or Send again) may send them
    run('UPDATE meta_accounts SET proof_at=0 WHERE act_id=? AND proof_at>0', act);
    throw e;
  } finally {
    // v155: the "account ready" message comes right after the images (also when the images failed)
    await shareMsgNow(act, lead, say);
  }
  // v156: a replacement is not a new delivery → no channel post, no story, no client number
  if (a.repl_of) { say('Replacement: no channel post / story'); return { ok: true, client: null }; }
  // v159: "Wait for the chat screenshot" ON → everything is kept (live data already read) and the post waits for the upload
  if (s.meta_shot_wait === '1' && !o.noWait) {
    await (await import('./shotpost')).holdPost(act, { d, partner, billing, topImg, manual }, say);
    return { ok: true, client: null, waiting: true };
  }
  return postDelivery({ act, d, partner, billing, topImg, manual, say });
}

export type PostParts = { act: string; d: ProofData; partner: Buffer; billing: Buffer; topImg: Buffer | null; manual: boolean; shot?: Buffer | null; say?: (t: string) => void };
/** The post of one delivery: channel (16:9 + caption + buttons), our Saved Messages (16:9 + 9:16), the story (9:16, no button).
 *  With a chat screenshot (v159) the images are the screenshot layout. No Meta call here. */
export async function postDelivery(x: PostParts) {
  const s = getSettings();
  const say = x.say || (() => {});
  const { d, partner, billing, topImg, manual } = x;
  const a = M.acctOf(x.act);
  if (!a) return { ok: false, client: null };
  const lead = a.lead_id ? leadById(a.lead_id) : undefined;
  const files = [{ name: 'partner-assigned.png', data: partner }, { name: 'billing.png', data: billing }, ...(topImg ? [{ name: 'top-up.png', data: topImg }] : [])];
  // the post (channel + Saved Messages): one client number per delivery
  // v157: the number moves on only when the channel really got the post (a failed / not-posted try never eats a number)
  const n = Math.max(1, Math.round(num(getSettings().meta_post_next, 151)));
  const channelOn = s.meta_post_on === '1' && !!s.meta_post_chat;
  const useNo = () => { if (Math.round(num(getSettings().meta_post_next, 151)) <= n) setSetting('meta_post_next', String(n + 1)); };
  const premium = M.catOf(a) === 'premium';
  const verified = fmtDate(M.bmOf(a.bm_id)?.verified_since);
  const bot = s.bot_username || '';
  const name = lead ? displayName(lead).split(/\s+/)[0] : 'Our client';
  const { autoFooter } = await import('./clientmsg');
  const cap = postCaption({ client: n, name, premium, verified, dsl: a.dsl ?? d.dsl ?? null, topup: d.topup ?? null }) + `🌐 ${d.site}${bot ? ` 💬 @${bot}` : ''}` + autoFooter();
  let wide: Buffer | null = null, tall: Buffer | null = null;
  const po = { client: n, premium, verified, topup: d.topup };
  try {
    if (x.shot) { wide = await shotPostImage(d, po, x.shot, partner, billing); tall = await shotStoryImage(d, po, x.shot, partner, billing); }
    else { wide = await postImage(d, po, partner, billing, topImg); tall = await storyImage(d, po, partner, billing, topImg); }
  } catch (e) { say('Post images: ' + (e as Error).message); }
  let used = false;
  if (wide && channelOn) {
    try {
      // one message: the 16:9 image (both proofs inside) + the whole caption + the buttons
      const kb = { inline_keyboard: [[...(bot ? [{ text: '💬 Get your account', url: `https://t.me/${bot}` }] : []), { text: '🌐 Order on website', url: `https://${d.site}` }],
        ...(bot ? [[{ text: '👉 Get Premium account', url: `https://t.me/${bot}?start=premium` }]] : [])] };
      await tgPhoto(s.meta_post_chat, wide, cap.slice(0, 1024), kb);
      run('INSERT INTO meta_log(act_id, lead_id, kind, note, by, created_at) VALUES(?,?,?,?,?,?)', a.act_id, a.lead_id, 'post', `Client #${n} posted to ${s.meta_post_chat}`, 'system', now());
      say(`Posted to the channel: Client #${n}`);
      used = true; useNo();
    } catch (e) { say('Channel post failed: ' + (e as Error).message); }
  }
  const save = [...(manual ? files : []), ...(x.shot ? [{ name: 'client-chat.png', data: x.shot }] : []), ...(wide ? [{ name: `client-${n}-16x9.png`, data: wide }] : []), ...(tall ? [{ name: `client-${n}-9x16.png`, data: tall }] : [])];
  const note = `${manual ? `✅ Ad account shared${lead ? ' · ' + displayName(lead) : ''} · ${d.name} (act_${a.act_id}) · partner ${d.partner}\n\n` : ''}${cap}`;
  let saved = false;
  if (save.length) {
    try { saved = await (await import('./userbot')).ubSaveToSelf(save.slice(0, 10), note.slice(0, 1024)); } catch (e) { say('Saved Messages: ' + (e as Error).message); }
    if (!saved && s.owner_id) { let i = 0; for (const f of save) { try { await tgPhoto(s.owner_id, f.data, i++ === 0 ? note.slice(0, 1024) : ''); saved = true; } catch { /* */ } } }
    say(saved ? 'Post saved to Telegram (16:9 + 9:16)' : 'Could not save the post to Telegram');
  }
  // v156: the 9:16 image as a Telegram story (chat account), short caption; v158: no button on stories
  if (tall && s.meta_story_on !== '0') {
    const scap = storyCaption({ client: n, premium, verified, dsl: d.dsl ?? a.dsl ?? null, bot, site: d.site, topup: d.topup ?? null });
    try {
      const r = await (await import('./userbot')).ubPostStory(tall, scap, null);
      if (r.ok) { say('Story posted'); used = true; run('INSERT INTO meta_log(act_id, lead_id, kind, note, by, created_at) VALUES(?,?,?,?,?,?)', a.act_id, a.lead_id, 'story', `Client #${n} story`, 'system', now()); }
      else say('Story: ' + r.error);
    } catch (e) { say('Story failed: ' + (e as Error).message); }
  }
  if (!channelOn && (used || saved)) useNo(); // no channel: the Saved Messages / story copy counts
  return { ok: true, client: used || saved ? n : null, channel: channelOn ? used : null };
}

/* ---------------- v159: posts with the client-chat screenshot ---------------- */
const roundBox = async (buf: Buffer, w: number, rx = 28) => {
  const sharp = await sharpLib();
  const im = await sharp(buf).resize({ width: w }).png().toBuffer();
  const m = await sharp(im).metadata();
  const mask = Buffer.from(`<svg width="${w}" height="${m.height}"><rect width="${w}" height="${m.height}" rx="${rx}" fill="#fff"/></svg>`);
  return { buf: await sharp(im).composite([{ input: mask, blend: 'dest-in' }]).png().toBuffer(), w, h: m.height as number };
};
/** The whole screenshot inside a box (never cropped): fit by height, narrower when it is wide. */
const fitWhole = async (buf: Buffer, maxW: number, maxH: number, rx = 28) => {
  const sharp = await sharpLib();
  const im = await sharp(buf).rotate().resize({ width: maxW, height: maxH, fit: 'inside' }).png().toBuffer();
  const m = await sharp(im).metadata();
  const w = m.width as number, h = m.height as number;
  const mask = Buffer.from(`<svg width="${w}" height="${h}"><rect width="${w}" height="${h}" rx="${rx}" fill="#fff"/></svg>`);
  return { buf: await sharp(im).composite([{ input: mask, blend: 'dest-in' }]).png().toBuffer(), w, h };
};
const BG_DEFS = `<defs><radialGradient id="a" cx="0.85" cy="-0.1" r="0.8"><stop offset="0" stop-color="#7c3aed"/><stop offset="1" stop-color="#160b2e" stop-opacity="0"/></radialGradient>
<radialGradient id="b" cx="0" cy="1.1" r="0.6"><stop offset="0" stop-color="#4c1d95"/><stop offset="1" stop-color="#160b2e" stop-opacity="0"/></radialGradient>
<linearGradient id="lg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#8b5cf6"/><stop offset="1" stop-color="#d946ef"/></linearGradient></defs>`;
const chipS = (x: number, y: number, w: number, k: string, v: string, sc = 1) => `<rect x="${x}" y="${y}" width="${w}" height="${104 * sc}" rx="16" fill="#fff" fill-opacity="0.08" stroke="#fff" stroke-opacity="0.16"/>
<text x="${x + 22}" y="${y + 38 * sc}" font-size="${16 * sc}" font-weight="700" fill="#c4b5fd" letter-spacing="1.5">${esc(k)}</text><text x="${x + 22}" y="${y + 80 * sc}" font-size="${30 * sc}" font-weight="800" fill="#fff">${esc(v)}</text>`;
type PO = { client: number; premium: boolean; verified: string | null; topup?: number | null };
const amtOf = (v: number) => usd(v).replace(/\.00$/, '');
export function shotPostSvg(d: ProofData, o: PO) {
  const s = getSettings();
  const pct = `${num(s.topup_comm_pct, 3)}%`;
  const bot = s.bot_username || '';
  const chips = [['DAILY LIMIT', d.dsl != null ? usd(d.dsl) : '—'], [o.verified ? 'VERIFIED' : 'BUSINESS', o.verified || 'Verified'],
    o.topup ? ['TOP-UP ADDED', amtOf(o.topup)] : ['ACCESS', 'Partner'], ['TOP-UP FEE', pct]];
  const pill = `${d.site}${bot ? ' · @' + bot : ''}`;
  const pw = Math.min(800, Math.max(380, pill.length * 16 + 80));
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" ${FONT}>${BG_DEFS}
<rect width="${W}" height="${H}" fill="#160b2e"/><rect width="${W}" height="${H}" fill="url(#a)"/><rect width="${W}" height="${H}" fill="url(#b)"/>
${logoTag(d, 50, 36, 50, 13)}<text x="116" y="74" font-size="31" font-weight="800" fill="#fff" letter-spacing="1">${esc(d.brand.toUpperCase())}</text>
<rect x="${120 + d.brand.length * 25}" y="40" width="330" height="42" rx="21" fill="none" stroke="#22c55e" stroke-width="2.5"/>
<text x="${120 + d.brand.length * 25 + 165}" y="68" font-size="19" font-weight="700" fill="#86efac" text-anchor="middle">● DELIVERED · CLIENT #${o.client}</text>
<text x="${W - 50}" y="76" font-size="42" font-weight="800" fill="#fff" text-anchor="end">${o.premium ? 'Premium ad account' : 'Ad account'} <tspan fill="#e9a8ff">delivered</tspan></text>
<text x="56" y="140" font-size="21" font-weight="700" fill="#fff">✓  In the client's chat</text>
<text x="512" y="140" font-size="21" font-weight="700" fill="#fff">✓  Billing · daily limit set by Meta</text>
<text x="1472" y="140" font-size="21" font-weight="700" fill="#fff">✓  Partner assigned</text>
${chipS(1472, 420, 196, chips[0][0], chips[0][1], 0.95)}${chipS(1676, 420, 196, chips[1][0], chips[1][1], 0.95)}${chipS(1472, 538, 196, chips[2][0], chips[2][1], 0.95)}${chipS(1676, 538, 196, chips[3][0], chips[3][1], 0.95)}
<rect x="512" y="744" width="1360" height="290" rx="24" fill="#fff" fill-opacity="0.06" stroke="#fff" stroke-opacity="0.12"/>
<text x="540" y="820" font-size="48" font-weight="900" fill="#fff">🚀 Ready to run ads from day one</text>
<text x="540" y="880" font-size="28" fill="#d8ccff">Verified business · no 18% GST · top-ups at just ${esc(pct)} fee</text>
<rect x="540" y="920" width="${pw}" height="70" rx="35" fill="#16a34a"/><text x="${540 + pw / 2}" y="966" font-size="28" font-weight="800" fill="#fff" text-anchor="middle">${esc(pill)}</text>
<text x="1846" y="958" font-size="19" fill="#d8ccff" text-anchor="end">Live data via Meta API</text><text x="1846" y="988" font-size="19" fill="#d8ccff" text-anchor="end">${esc(d.at)}</text>
</svg>`;
}
export async function shotPostImage(d: ProofData, o: PO, shot: Buffer, partner: Buffer, billing: Buffer) {
  const sharp = await sharpLib();
  const bg = await sharp(Buffer.from(shotPostSvg(d, o)), { density: 144 }).png().toBuffer(); // 3840×2160
  // px = 2 × svg. Chat column x 112..1000, y 336..2096 (whole screenshot, centred); billing 1024..2884; partner 2944..3744
  const c = await fitWhole(shot, 888, 1760);
  const bill = await roundBox(billing, 1860), part = await roundBox(partner, 800);
  const out = await sharp(bg).composite([
    { input: c.buf, left: 112 + Math.round((888 - c.w) / 2), top: 336 },
    { input: bill.buf, left: 1024, top: 336 }, { input: part.buf, left: 2944, top: 336 },
  ]).png().toBuffer();
  return sharp(out).resize({ width: 2560, kernel: 'lanczos3' }).sharpen({ sigma: 0.6 }).png({ compressionLevel: 8 }).toBuffer();
}
export function shotStorySvg(d: ProofData, o: PO) {
  const s = getSettings();
  const SW = 1080, SH = 1920;
  const bot = s.bot_username || '';
  const chips = [['DAILY LIMIT', d.dsl != null ? usd(d.dsl) : '—'], [o.verified ? 'VERIFIED SINCE' : 'BUSINESS', o.verified || 'Verified'],
    o.topup ? ['TOP-UP ADDED', amtOf(o.topup)] : ['TOP-UP FEE', `${num(s.topup_comm_pct, 3)}%`]];
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${SW}" height="${SH}" viewBox="0 0 ${SW} ${SH}" ${FONT}>${BG_DEFS}
<rect width="${SW}" height="${SH}" fill="#160b2e"/><rect width="${SW}" height="${SH}" fill="url(#a)"/><rect width="${SW}" height="${SH}" fill="url(#b)"/>
${logoTag(d, 60, 80, 56, 14)}<text x="134" y="122" font-size="34" font-weight="800" fill="#fff" letter-spacing="1">${esc(d.brand.toUpperCase())}</text>
<rect x="60" y="168" width="380" height="50" rx="25" fill="none" stroke="#22c55e" stroke-width="3"/><text x="250" y="201" font-size="22" font-weight="700" fill="#86efac" text-anchor="middle">● DELIVERED · CLIENT #${o.client}</text>
<rect x="560" y="168" width="460" height="50" rx="25" fill="#fff" fill-opacity="0.1" stroke="#c4b5fd" stroke-opacity="0.5"/><text x="790" y="201" font-size="21" font-weight="700" fill="#e9d5ff" text-anchor="middle">● Live data fetched via Meta API</text>
<text x="1020" y="252" font-size="19" fill="#d8ccff" text-anchor="end">${esc(d.site)} · ${esc(d.at)}</text>
<text x="60" y="330" font-size="62" font-weight="800" fill="#fff">${o.premium ? 'Premium ad account' : 'Ad account'}</text><text x="60" y="404" font-size="62" font-weight="800" fill="#e9a8ff">delivered${o.topup ? ` <tspan fill="#86efac">+ ${esc(amtOf(o.topup))}</tspan>` : ''}</text>
<text x="52" y="476" font-size="23" font-weight="700" fill="#fff">✓  In the client's chat</text>
<text x="512" y="476" font-size="23" font-weight="700" fill="#fff">✓  Billing (Meta)</text>
<text x="512" y="826" font-size="23" font-weight="700" fill="#fff">✓  Partner assigned</text>
${chips.map((c, i) => chipS(512, 1150 + i * 122, 518, c[0], c[1], 1)).join('')}
<text x="540" y="1630" font-size="30" font-weight="700" fill="#d8ccff" text-anchor="middle">${esc(d.site)}${bot ? ' · @' + esc(bot) : ''}</text>
</svg>`;
}
export async function shotStoryImage(d: ProofData, o: PO, shot: Buffer, partner: Buffer, billing: Buffer) {
  const sharp = await sharpLib();
  const bg = await sharp(Buffer.from(shotStorySvg(d, o)), { density: 144 }).png().toBuffer(); // 2160×3840
  // chat column x 100..1000, y 990..2890 (whole screenshot); billing + partner on the right
  const c = await fitWhole(shot, 900, 1900);
  const out = await sharp(bg).composite([
    { input: c.buf, left: 100 + Math.round((900 - c.w) / 2), top: 990 },
    { input: (await roundBox(billing, 1040)).buf, left: 1020, top: 990 }, { input: (await roundBox(partner, 1040)).buf, left: 1020, top: 1680 },
  ]).png().toBuffer();
  return sharp(out).resize({ width: 1440, kernel: 'lanczos3' }).sharpen({ sigma: 0.6 }).png({ compressionLevel: 8 }).toBuffer();
}

/** v157: a top-up on its own (not with a share) → one "Top-up added" image to the client's chat. */
export async function deliverTopupProof(act: string, amount: number, fee: number, say: (t: string) => void = () => {}, caption = ''): Promise<{ ok: boolean; captioned?: boolean }> {
  // v158: the image is always made and saved to our Saved Messages (to forward on WhatsApp / to a client without a chat);
  // the client's own chat gets it only when the chat is in the app and "Proof images to the client" is ON
  const s = getSettings();
  const a = M.acctOf(act);
  if (!a || !(amount > 0)) return { ok: false };
  const lead = a.lead_id ? leadById(a.lead_id) : undefined;
  say('Drawing the top-up image');
  const d = await proofData(act);
  const cur = M.acctOf(act)!;
  const img = await render(topupSvg({ ...d, topup: amount, fee: fee || null, capTotal: d.capTotal ?? (cur.cap > 0 ? cur.cap / 100 : null), remaining: d.remaining ?? (cur.cap > 0 ? Math.max(0, cur.cap - cur.spent) / 100 : null) }));
  try { (await import('./digest')).saveTopupImg(act, img); } catch { /* */ } // kept for the daily post
  const toClient = !!lead?.tg_chat_id && !(lead as { manual_client?: number }).manual_client && s.meta_proof_client !== '0';
  let captioned = false;
  if (toClient && lead) {
    try {
      const fd = new FormData(); fd.append('file', new File([new Uint8Array(img)], 'top-up.png', { type: 'image/png' })); fd.append('kind', 'photo');
      if (caption) fd.append('caption', caption.slice(0, 1000));
      await uploadToLead(lead, fd, 'agent', lead.agent_id);
      captioned = !!caption;
      say(caption ? 'Top-up image + message sent to the client' : 'Top-up image sent to the client');
    } catch (e) { say('Top-up image to the client: ' + (e as Error).message); }
  } else say(lead?.tg_chat_id ? 'Proof images to the client are OFF: not sent to the client' : 'Client has no chat in the app: forward it from Saved Messages');
  try {
    const ok = await (await import('./userbot')).ubSaveToSelf([{ name: `top-up-act_${act}.png`, data: img }], `💰 Top-up ${usd(amount)} · ${lead ? displayName(lead) : 'client'} · ${cur.name || 'act_' + act} (act_${act})`);
    say(ok ? 'Top-up image saved to Telegram Saved Messages' : 'Could not save to Saved Messages (chat account not logged in?)');
    if (!ok && s.owner_id) { await tgPhoto(s.owner_id, img, `💰 Top-up ${usd(amount)} · ${cur.name || 'act_' + act}`); say('Sent to the owner chat instead'); }
  } catch (e) { say('Saved Messages: ' + (e as Error).message); }
  return { ok: true, captioned };
}

async function shareMsgNow(act: string, lead: ReturnType<typeof leadById>, say: (t: string) => void) {
  const af = M.acctOf(act) as (M.Acct & { share_msg?: number }) | undefined;
  if (!lead || !af?.share_msg) return;
  run('UPDATE meta_accounts SET share_msg=0 WHERE act_id=?', act);
  try {
    const { tellClient } = await import('./clientmsg');
    await tellClient(leadById(lead.id), af.repl_of ? 'meta_msg_replace' : 'meta_msg_share', { acts: [act], bm: af.client_bm, balance: Math.max(0, af.locked ? 0 : af.cap - af.spent) / 100 });
    say('Message sent to the client');
  } catch (e) { say('Message: ' + (e as Error).message); }
}

/** Admin "Send proof images again" (needs the queue for live data when the BM is a profile BM). */
export async function proofPreview(act: string) {
  const d = await proofData(act);
  return { partner: await render(partnerSvg(d), 1280), billing: await render(billingSvg(d), 1280) };
}
export const _test = { one };

/** v153: a post in our channel (ours or one typed by hand) → the next "Client #" follows it. Only moves forward. */
export function syncClientNo(post: { chat?: { id?: number | string; username?: string }; text?: string; caption?: string } | null | undefined) {
  if (!post?.chat) return null;
  const want = String(getSettings().meta_post_chat || '').trim().toLowerCase();
  if (!want) return null;
  const chatOk = want.startsWith('@') ? !!post.chat.username && '@' + String(post.chat.username).toLowerCase() === want : String(post.chat.id) === want;
  if (!chatOk) return null;
  const txt = `${post.text || ''}\n${post.caption || ''}`;
  let max = 0;
  for (const m of txt.matchAll(/Client\s*#\s*(\d{1,6})/gi)) max = Math.max(max, Number(m[1]));
  if (!max) return null;
  const next = Math.max(1, Math.round(num(getSettings().meta_post_next, 151)));
  if (max + 1 > next) { setSetting('meta_post_next', String(max + 1)); return max + 1; }
  return null;
}

/** v155: the uploaded logo as a small PNG data URL for the drawings (null = none uploaded). */
async function logoData() {
  try {
    const { usesUploadedLogo } = await import('./settings');
    const sharp = await sharpLib();
    if (usesUploadedLogo(getSettings())) {
      const { readLogo } = await import('./logo');
      const l = readLogo();
      if (l) {
        const png = await sharp(l.buf, { density: 300 }).resize(256, 256, { fit: 'contain', background: { r: 255, g: 255, b: 255, alpha: 1 } }).png().toBuffer();
        return 'data:image/png;base64,' + png.toString('base64');
      }
    }
    // no uploaded logo → the same logo the site / app uses (Admin → Brand theme)
    const { logoImage } = await import('./brandkit');
    const res = logoImage(getSettings(), 256);
    const buf = Buffer.from(await res.arrayBuffer());
    return buf.length > 100 ? 'data:image/png;base64,' + buf.toString('base64') : null;
  } catch { return null; }
}
