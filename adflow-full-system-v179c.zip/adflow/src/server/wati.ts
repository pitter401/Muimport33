// v131: WhatsApp chats through WATI (Cloud API + coexistence: the WhatsApp Business app keeps working on the same number).
// A WhatsApp chat is a normal lead with ch='wa' and tg_chat_id 'wa:<number>' — so every chat list, follow-up, AI reply,
// sale and reminder works as for Telegram. telegram.ts hands every send to a 'wa:' chat to this file.
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { one, all, run, tx } from './db';
import { getSettings, setSetting, type Settings } from './settings';
import { now, HOUR } from './util';
import { oggDuration } from './audiodur';
import { imageSendKind, imageMime, isImageFile, looksImage } from './imgsend'; // v168

export type WaResult = { ok: boolean; result?: any; description?: string };
export const isWa = (chatId: unknown) => typeof chatId === 'string' && chatId.startsWith('wa:');
export const waDigits = (chatId: string) => chatId.replace(/^wa:/, '').replace(/\D/g, '');
export const waReady = (s: Settings = getSettings()) => s.wati_on === '1' && !!String(s.wati_token || '').trim();
export const WINDOW = 24 * HOUR;
/** v137: automation texts of the WhatsApp vendor (WATI default / keyword rules) — never a real message from us or the customer. */
export const isVendorAuto = (t: string | null | undefined) => /triggered an automation rule|live\.wati\.io|app\.wati\.io\/rules|wati\.io\/rules/i.test(String(t || ''));

/** Our webhook path secret (made once). */
export function hookKey(s: Settings = getSettings()) {
  if (s.wati_hook) return s.wati_hook;
  const k = crypto.randomBytes(12).toString('hex');
  setSetting('wati_hook' as never, k);
  return k;
}
const base = (s: Settings) => {
  const u = String(s.wati_url || 'https://live-mt-server.wati.io').trim().replace(/\/+$/, '');
  try { const x = new URL(u); return { origin: x.origin, full: u }; } catch { return { origin: 'https://live-mt-server.wati.io', full: u }; }
};
const auth = (s: Settings) => 'Bearer ' + String(s.wati_token || '').trim().replace(/^Bearer\s+/i, '');
const API = () => process.env.WATI_API_BASE || ''; // tests

/** The 24-hour customer-service window: time left (ms) for this chat, 0 = closed. */
export function windowLeft(lastInAt: number | null | undefined, t = now()) {
  return lastInAt ? Math.max(0, lastInAt + WINDOW - t) : 0;
}
const leadOfChat = (chatId: string) => one<{ id: number; last_in_at: number | null }>("SELECT id, last_in_at FROM leads WHERE tg_chat_id=? AND status!='merged' ORDER BY id DESC LIMIT 1", chatId);

/** Messages we sent through the API come back on the webhook as "owner" messages → don't add them twice. */
const recent = new Map<string, { text: string; t: number }[]>();
function remember(wa: string, text: string) {
  const t = now(), l = (recent.get(wa) || []).filter(x => x.t > t - 5 * 60000);
  l.push({ text: text.trim(), t }); recent.set(wa, l);
}
export function isOurEcho(wa: string, text: string) {
  const l = recent.get(wa) || [], x = text.trim(), t = now();
  const i = l.findIndex(m => m.text === x && m.t > t - 5 * 60000);
  if (i < 0) return false;
  l.splice(i, 1);
  return true;
}

function closedMsg() { return 'WA_WINDOW_CLOSED: WhatsApp allows replies only within 24 hours of the customer’s last message. Message them from the WhatsApp Business app on the phone — when they reply, the chat opens again.'; }
function check(s: Settings, chatId: string): WaResult | null {
  if (s.wati_on !== '1') return { ok: false, description: 'WhatsApp is switched off (Admin → Settings → WhatsApp chats)' };
  if (!String(s.wati_token || '').trim()) return { ok: false, description: 'WATI API key not set (Admin → Settings → WhatsApp chats)' };
  const l = leadOfChat(chatId);
  if (l && !windowLeft(l.last_in_at)) return { ok: false, description: closedMsg() };
  return null;
}
async function call(s: Settings, p: string, init: RequestInit, tenant = false): Promise<WaResult> {
  const { origin, full } = base(s);
  const url = (API() || (tenant ? full : origin)) + p;
  try {
    const r = await fetch(url, { ...init, headers: { ...(init.headers || {}), authorization: auth(s) }, signal: AbortSignal.timeout(60000) });
    const txt = await r.text();
    let j: any = null; try { j = JSON.parse(txt); } catch { /* not json */ }
    logWati('send', `${r.status} ${p} ${txt.slice(0, 400)}`);
    // v143: WATI / WhatsApp rate limit → only the WhatsApp send queue waits (Retry-After, else 60 s)
    if (r.status === 429) void import('./pace').then(P => P.paceFloodWait('wa', Number(r.headers.get('retry-after')) || 60, Date.now(), 'WATI_429')).catch(() => null);
    if (!r.ok || (j && (j.result === false || j.ok === false || j.success === false))) return { ok: false, description: `WATI ${r.status}: ${String(j?.info || j?.message || j?.error || txt).slice(0, 200)}` };
    const waId = j && (j.message?.whatsappMessageId || j.whatsappMessageId || j.message?.id || j.messageId || j.id || null);
    return { ok: true, result: { message_id: null, wa: j, wa_id: waId ? String(waId) : null } };
  } catch (e) { return { ok: false, description: 'WATI: ' + (e as Error).message }; }
}

/** v134: blue ticks for the customer + read in the WhatsApp Business app — WATI's typing indicator also marks the last
 *  incoming message as read. Called when a chat with new messages is opened in our apps, and when we reply. Max once / 20 s per chat. */
const lastRead = new Map<string, number>();
export async function waMarkRead(s: Settings, chatId: string) {
  if (s.wati_on !== '1' || !String(s.wati_token || '').trim()) return;
  const wa = waDigits(chatId), t = now();
  if ((lastRead.get(wa) || 0) > t - 20000) return;
  lastRead.set(wa, t);
  await call(s, '/api/ext/v3/conversations/typingIndicator', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ target: wa }) }).catch(() => null);
}
/** v134: WhatsApp ids of what we just sent (per number) → put on our saved message (for the ticks). */
const sentIds = new Map<string, { id: string; t: number }[]>();
function noteSent(wa: string, id: string) { const t = now(); sentIds.set(wa, [...(sentIds.get(wa) || []).filter(x => x.t > t - 120000), { id, t }]); }
export function takeSentId(chatId: string) { const l = sentIds.get(waDigits(chatId)) || []; const x = l.shift(); return x && x.t > now() - 120000 ? x.id : null; }
/** v168: one WhatsApp message (all its ids) is ADDED once, across the webhook, the phone sync and both processes (web + worker).
 *  Synchronous: called right before the first await of the path that will insert it. false = someone already took it. */
export function waClaimIds(ids: (string | null | undefined)[]) {
  const l = [...new Set(ids.filter(Boolean).map(String))];
  if (!l.length) return true;
  try {
    return tx(() => {
      if (one(`SELECT 1 FROM wa_seen WHERE msg_id IN (${l.map(() => '?').join(',')})`, ...l)) return false;
      for (const x of l) run('INSERT OR IGNORE INTO wa_seen(msg_id, at) VALUES(?,?)', x, now());
      return true;
    });
  } catch { return true; } // table missing in a unit test → the unique index still guards
}
/** v168: same kind of media for echo matching — an image sent as a document and the photo WhatsApp makes of it are one. */
export function sameMediaKind(rowType: string | null | undefined, rowName: string | null | undefined, kind: string, ref?: string | null) {
  const k = (x: string | null | undefined) => (x === 'voice' || x === 'audio' ? 'voice' : x === 'photo' || x === 'image' ? 'photo' : x ? 'file' : '');
  if (k(rowType) === k(kind)) return true;
  const visual = (t: string | null | undefined) => t === 'photo' || t === 'image' || t === 'document';
  return visual(rowType) && visual(kind) && looksImage(rowType, rowName) && looksImage(kind, ref);
}
/** v168: a file we are sending right now (DB: the web and the worker both send). WhatsApp's echo of it can come in BEFORE
 *  WATI answers our upload, so before our row exists → the echo waits for our row instead of becoming "Owner (phone)". */
export function pendingMediaAdd(wa: string, kind: string, name: string): number | null {
  try {
    if (Math.random() < 0.05) run('DELETE FROM wa_out_pending WHERE at<?', now() - 3600000);
    return Number(run('INSERT INTO wa_out_pending(wa, kind, name, at) VALUES(?,?,?,?)', wa, kind, name, now()).lastInsertRowid);
  } catch { return null; }
}
export function pendingMediaDone(id: number | null, ok: boolean) {
  if (!id) return;
  try { if (ok) run('UPDATE wa_out_pending SET sent_at=? WHERE id=?', now(), id); else run('DELETE FROM wa_out_pending WHERE id=?', id); } catch { /* */ }
}
/** Is a file of this kind being sent to this number (or was it sent in the last 5 s, its row about to be saved)? */
export function waMediaInFlight(wa: string, kind: string, ref?: string | null) {
  try {
    const t = now();
    return all<{ kind: string; name: string }>('SELECT kind, name FROM wa_out_pending WHERE wa=? AND ((sent_at IS NULL AND at>?) OR sent_at>?)', wa, t - 150000, t - 5000)
      .some(p => sameMediaKind(p.kind, p.name, kind, ref));
  } catch { return false; }
}
/** v168: the id was put on the row directly → it leaves the queue (the next message must not get it). */
export function dropSentId(chatId: string, id: string) { const l = sentIds.get(waDigits(chatId)); if (l) { const i = l.findIndex(x => x.id === id); if (i >= 0) l.splice(i, 1); } }
export async function waSendText(s: Settings, chatId: string, text: string): Promise<WaResult> {
  const bad = check(s, chatId);
  if (bad) return bad;
  const wa = waDigits(chatId);
  remember(wa, text);
  const r = await call(s, '/api/ext/v3/conversations/messages/text', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ target: wa, text }) });
  if (r.ok && r.result?.wa_id) noteSent(wa, r.result.wa_id);
  return r;
}

/* ---------- files: kept on our server so the apps can show / play them (file_id 'wa:<name>') ---------- */
export const mediaDir = () => {
  const d = path.join(path.dirname(process.env.DB_PATH || path.join(process.cwd(), 'data', 'adflow.db')), 'wa_media');
  fs.mkdirSync(d, { recursive: true });
  return d;
};
const EXT: Record<string, string> = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/heic': 'heic', 'image/heif': 'heic', 'image/gif': 'gif', // v168: heic / gif
  'video/mp4': 'mp4', 'audio/ogg': 'ogg', 'audio/mpeg': 'mp3', 'audio/mp4': 'm4a', 'audio/aac': 'aac', 'audio/amr': 'amr', 'application/pdf': 'pdf' };
export function saveMedia(data: Buffer, nameOrType: string) {
  const ext = (nameOrType.includes('/') ? EXT[nameOrType.split(';')[0].trim()] : nameOrType.split('.').pop()) || 'bin';
  const name = crypto.randomBytes(9).toString('hex') + '.' + ext.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 5);
  fs.writeFileSync(path.join(mediaDir(), name), data);
  return 'wa:' + name;
}
/** v139: length of one of our stored WhatsApp media files (wa:… ids live on our disk); null when unknown. */
export function localDur(fileId: string | null | undefined): number | null {
  if (!fileId || !isWa(fileId)) return null;
  try { const p = mediaPath(fileId); if (!p) return null; const d = oggDuration(fs.readFileSync(p)); return d > 0 ? d : null; } catch { return null; }
}
export function mediaPath(fileId: string) {
  const n = fileId.replace(/^wa:/, '');
  if (!/^[a-f0-9]{18}\.[a-z0-9]{1,5}$/.test(n)) return null;
  const p = path.join(mediaDir(), n);
  return fs.existsSync(p) ? p : null;
}
/** Same shape telegram.ts downloadFile() returns, for 'wa:' files. */
export function waDownload(fileId: string) {
  const p = mediaPath(fileId);
  if (!p) return null;
  return { res: new Response(new Uint8Array(fs.readFileSync(p))), path: p };
}
const TG_KIND: Record<string, string> = { photo: 'photo', video: 'video', voice: 'voice', audio: 'audio', document: 'document', sticker: 'document', animation: 'video', video_note: 'video' };
/** Upload a file to a WhatsApp chat. A voice note goes as OGG/Opus (WhatsApp shows the microphone, like a recorded voice note). */
export async function waSendFile(s: Settings, chatId: string, file: File, kindIn: string, caption: string): Promise<WaResult> {
  const bad = check(s, chatId);
  if (bad) return bad;
  let kind = TG_KIND[kindIn] || 'document';
  const data = Buffer.from(await file.arrayBuffer()); // v168: the ORIGINAL bytes are sent and kept (never resized / recompressed)
  // v168: a JPEG / PNG ≤ 5 MB goes (and is stored) as a photo — WhatsApp delivers it as an image, so its echo matches our row.
  // WebP / HEIC / > 5 MB go as a document (full resolution, original file).
  if (kind === 'photo' || kind === 'document') { const ik = imageSendKind('wa', data, file.name, file.type, kind); if (ik) kind = ik; }
  const ct = kind === 'voice' ? 'audio/ogg; codecs=opus' : (isImageFile(file.name, file.type) ? imageMime(data, file.name, file.type) : '') || file.type || 'application/octet-stream';
  const fname = kind === 'voice' ? 'voice.ogg' : file.name || 'file';
  const fid = saveMedia(data, kind === 'voice' ? 'x.ogg' : (/\.[a-z0-9]{2,5}$/i.test(fname) && !file.type ? fname : file.type || ct || fname)); // v168: an image with no mime keeps its extension
  const fd = new FormData();
  fd.append('target', waDigits(chatId));
  if (caption) fd.append('caption', caption.slice(0, 1000));
  fd.append('file', new Blob([new Uint8Array(data)], { type: ct }), fname);
  if (caption) remember(waDigits(chatId), caption);
  const pend = pendingMediaAdd(waDigits(chatId), kind, fname); // v168: its echo may arrive before WATI answers us
  let r: WaResult | null = null;
  // v133: a real voice note (mic icon, plays like a recorded voice) — WhatsApp needs "voice": true, which WATI has only on
  // the older sendSessionFile endpoint (needs the endpoint with your account number, e.g. https://live-mt-server.wati.io/10300419)
  if (kind === 'voice' && (API() || /\/\d+$/.test(base(s).full))) {
    const fv = new FormData();
    fv.append('file', new Blob([new Uint8Array(data)], { type: 'audio/ogg; codecs=opus' }), 'voice.ogg');
    r = await call(s, `/api/v1/sendSessionFile/${waDigits(chatId)}?voice=true`, { method: 'POST', body: fv }, true);
    if (!r.ok) logWati('error', 'voice note as voice failed, sending as audio: ' + (r.description || ''));
  }
  if (!r || !r.ok) r = await call(s, '/api/ext/v3/conversations/messages/file', { method: 'POST', body: fd });
  pendingMediaDone(pend, r.ok); // v168
  if (!r.ok) return r;
  // v139: + the voice note's length (read from the OGG), like Telegram's result has it
  const dur = kind === 'voice' || kind === 'audio' ? oggDuration(data) : 0;
  const media = kind === 'photo' ? { photo: [{ file_id: fid }] } : { [kind]: { file_id: fid, file_name: fname, ...(dur > 0 ? { duration: dur } : {}) } };
  if (r.result?.wa_id) noteSent(waDigits(chatId), r.result.wa_id);
  return { ok: true, result: { message_id: null, wa_id: r.result?.wa_id || null, ...media } };
}
/** Re-send a file we already have (our 'wa:' copy, or a Telegram file id — e.g. the cached welcome voice note). */
export async function waSendFileId(s: Settings, chatId: string, type: string, fileId: string, caption?: string): Promise<WaResult> {
  let data: Buffer | null = null, name = 'file';
  if (isWa(fileId)) { const p = mediaPath(fileId); if (p) { data = fs.readFileSync(p); name = path.basename(p); } }
  else {
    const { downloadFile } = await import('./telegram');
    const f = await downloadFile(s, fileId).catch(() => null);
    if (f?.res.ok) { data = Buffer.from(await f.res.arrayBuffer()); name = path.basename(f.path); }
  }
  if (!data) return { ok: false, description: 'file not found' };
  return waSendFile(s, chatId, new File([new Uint8Array(data)], type === 'voice' ? 'voice.ogg' : name), type, caption || '');
}

/** Raw webhook / API log (last 300) — Admin → Settings → WhatsApp chats shows it, so a new payload shape is easy to see. */
export function logWati(kind: string, body: string) {
  try {
    run('INSERT INTO wati_log(at, kind, body) VALUES(?,?,?)', now(), kind, body.slice(0, 4000));
    run('DELETE FROM wati_log WHERE id < (SELECT MAX(id) - 300 FROM wati_log)');
  } catch { /* table missing in a unit test */ }
}
export const watiLog = (n = 40) => all<{ id: number; at: number; kind: string; body: string }>('SELECT * FROM wati_log ORDER BY id DESC LIMIT ?', n);

/* ---------- incoming (webhook) ---------- */
export type WaIn = {
  wa: string; name: string; text: string; type: string; owner: boolean; msgId: string;
  media: { kind: string; ref: string } | null; src: { id: string; url: string; type: string } | null; replyTo: string | null;
  ids?: string[]; // v168: every id of the message (WhatsApp wamid + WATI's own id) — the echo of our send is matched by any of them
};
const KIND: Record<string, string> = { image: 'photo', video: 'video', audio: 'audio', voice: 'voice', ptt: 'voice', document: 'document', sticker: 'sticker' };
/** Event name without version / BSUID suffix: "sessionMessageSent_v2" → "sessionmessagesent". */
export const waEvent = (e: unknown) => String(e || '').toLowerCase().replace(/_(v\d+|bsuid)\b/g, '').replace(/_(v\d+|bsuid)\b/g, '').replace(/[^a-z]/g, '');
/** v134: "Sent message is DELIVERED / READ" → which of our messages and what happened. */
export function parseStatus(b: any): { ids: string[]; st: 'delivered' | 'read' | 'failed' } | null {
  if (!b || typeof b !== 'object') return null;
  const ev = waEvent(b.eventType || b.event);
  const ss = String(b.statusString || '').toLowerCase();
  const st = /sentmessageread|messageread/.test(ev) || (ev === '' && ss === 'read') ? 'read'
    : /sentmessagedelivered|messagedelivered/.test(ev) || (ev === '' && ss === 'delivered') ? 'delivered'
    : /messagefailed/.test(ev) ? 'failed' : null;
  if (!st) return null;
  const ids = [b.whatsappMessageId, b.id, b.localMessageId].filter(Boolean).map(String);
  return ids.length ? { ids, st } : null;
}
/** WATI "message" event → our shape (null = not a chat message we use). */
export function parseHook(b0: any): WaIn | null {
  if (!b0 || typeof b0 !== 'object') return null;
  // v133: some WATI webhook versions wrap the message ({ data | message | payload: {...} }) — use the inner object, keep the event name
  const inner = ['data', 'message', 'payload'].map(k => b0[k]).find(x => x && typeof x === 'object' && !Array.isArray(x) && (x.waId || x.wa_id || x.from || x.whatsappMessageId));
  const b: any = inner && !(b0.waId || b0.wa_id) ? { eventType: b0.eventType || b0.event || b0.type, ...inner } : b0;
  const ev = waEvent(b.eventType || b.event);
  if (ev && !['message', 'messagereceived', 'sessionmessagesent', 'newcontactmessagereceived', 'newcontactmessage', 'messagesent'].includes(ev)) return null;
  const wa = String(b.waId || b.wa_id || b.from || b.contact?.waId || '').replace(/\D/g, '');
  if (wa.length < 8) return null;
  const type = String(b.type || 'text').toLowerCase();
  const owner = b.owner === true || b.owner === 'true' || /sessionmessagesent|messagesent/.test(ev);
  let text = typeof b.text === 'object' && b.text ? String(b.text.body ?? '') : String(b.text ?? b.finalText ?? '');
  if (type === 'location' && b.data) text = '📍 Location: ' + (typeof b.data === 'string' ? b.data : JSON.stringify(b.data)).slice(0, 200);
  if (type === 'button' || type === 'interactive') text = String(b.buttonReply?.text || b.listReply?.title || b.interactiveButtonReply?.title || text);
  let media: WaIn['media'] = null;
  if (KIND[type]) {
    const d = b.data;
    const ref = typeof d === 'string' ? d : d && typeof d === 'object' ? String(d.url || d.link || d.fileName || d.filename || d.mediaUrl || d.id || '') : '';
    media = { kind: KIND[type], ref };
    if (text === ref) text = '';
  }
  // v137: an event with nothing in it (no text, no file — e.g. a reaction or a WATI system event) is not a message: don't show an empty bubble
  if (!text.trim() && !media && !['location', 'contacts', 'button', 'interactive'].includes(type)) return null;
  const src = b.sourceId || b.sourceUrl ? { id: String(b.sourceId || ''), url: String(b.sourceUrl || ''), type: String(b.sourceType || '') } : null;
  return { wa, name: String(b.senderName || b.name || '').slice(0, 80), text: text.slice(0, 4000), type, owner, msgId: String(b.whatsappMessageId || b.id || ''), media, src, replyTo: b.replyContextId ? String(b.replyContextId) : null,
    ids: [...new Set([b.whatsappMessageId, b.id, b.localMessageId, b.messageId].filter(v => v != null && v !== '').map(String))] }; // v168
}
/** Download a customer's photo / voice note / file from WATI and keep it (returns our 'wa:' file id, or null). */
export async function fetchMedia(s: Settings, m: NonNullable<WaIn['media']>): Promise<string | null> {
  if (!m.ref) return null;
  const { origin, full } = base(s);
  const fileName = /^https?:\/\//.test(m.ref) ? (new URL(m.ref).searchParams.get('fileName') || '') : '';
  const tries = /^https?:\/\//.test(m.ref) ? [m.ref, ...(fileName ? [`${API() || origin}/api/v1/getMedia?fileName=${encodeURIComponent(fileName)}`, `${API() || full}/api/v1/getMedia?fileName=${encodeURIComponent(fileName)}`] : [])]
    : [`${API() || origin}/api/v1/getMedia?fileName=${encodeURIComponent(m.ref)}`, `${API() || full}/api/v1/getMedia?fileName=${encodeURIComponent(m.ref)}`];
  for (const u of [...new Set(tries)]) {
    try {
      const r = await fetch(u, { headers: { authorization: auth(s) }, signal: AbortSignal.timeout(60000) });
      if (!r.ok) { logWati('media', `${r.status} ${u.slice(0, 200)}`); continue; }
      const ct = r.headers.get('content-type') || '';
      if (/json|html/.test(ct)) { logWati('media', `not a file ${u.slice(0, 200)}`); continue; }
      const buf = Buffer.from(await r.arrayBuffer());
      return saveMedia(buf, m.kind === 'voice' ? 'x.ogg' : ct || m.ref);
    } catch (e) { logWati('media', `${(e as Error).message} ${u.slice(0, 200)}`); }
  }
  return null;
}

/* ======================= v137: WATI Pro extras + phone-reply sync ======================= */
/** Pro-plan features: every one is OFF while "We're on the WATI Pro plan" is off (no extra API calls at all). */
export const waPro = (s: Settings = getSettings()) => waReady(s) && s.wati_pro === '1';
export const waProButtons = (s: Settings = getSettings()) => waPro(s) && s.wati_buttons !== '0';
export const waProStatus = (s: Settings = getSettings()) => waPro(s) && s.wati_status_sync !== '0';
export const waProAttrs = (s: Settings = getSettings()) => waPro(s) && s.wati_attr_sync !== '0';
export const waPhoneSyncOn = (s: Settings = getSettings()) => waReady(s) && s.wati_sync_phone !== '0';

/** Same as call() but for the v1 endpoints that live under the tenant URL (…/123456/api/v1/…): tenant first, then the plain host. */
async function callV1(s: Settings, p: string, init: RequestInit, kind: string): Promise<WaResult> {
  const { origin, full } = base(s);
  const roots = API() ? [API()] : [...new Set([full, origin])];
  let last: WaResult = { ok: false, description: 'not sent' };
  for (const root of roots) {
    try {
      const r = await fetch(root + p, { ...init, headers: { ...(init.headers || {}), authorization: auth(s) }, signal: AbortSignal.timeout(20000) });
      const txt = await r.text();
      let j: any = null; try { j = JSON.parse(txt); } catch { /* not json */ }
      logWati(kind, `${r.status} ${init.method || 'GET'} ${p} ${txt.slice(0, 300)}`);
      if (r.ok && !(j && (j.result === false || j.ok === false || j.success === false))) {
        const waId = j && (j.message?.whatsappMessageId || j.whatsappMessageId || j.message?.id || j.messageId || j.id || null);
        return { ok: true, result: { wa: j, wa_id: waId ? String(waId) : null } };
      }
      last = { ok: false, description: `WATI ${r.status}: ${String(j?.info || j?.message || j?.error || txt).slice(0, 200)}` };
      if (r.status !== 404 && r.status !== 405) return last; // a real answer (e.g. 401 / 400) → the other host won't help
    } catch (e) { logWati(kind, `error ${p} ${(e as Error).message}`); last = { ok: false, description: 'WATI: ' + (e as Error).message }; }
  }
  return last;
}
const jsonInit = (body: unknown): RequestInit => ({ method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });

export type WaListRow = { title: string; description?: string };
/** Interactive LIST message (session message, needs the 24-hour window). Customer's tap comes back as type "interactive". */
export async function waSendList(s: Settings, chatId: string, m: { header?: string; body: string; footer?: string; buttonText: string; sectionTitle?: string; rows: WaListRow[] }): Promise<WaResult> {
  const bad = check(s, chatId);
  if (bad) return bad;
  const wa = waDigits(chatId);
  const body = {
    header: m.header ? { type: 'Text', text: m.header.slice(0, 60) } : undefined, body: m.body.slice(0, 1024), footer: (m.footer || '').slice(0, 60), buttonText: m.buttonText.slice(0, 20),
    sections: [{ title: (m.sectionTitle || 'Options').slice(0, 24), rows: m.rows.slice(0, 10).map(r => ({ title: r.title.slice(0, 24), description: (r.description || '').slice(0, 72) })) }],
  };
  remember(wa, m.body);
  const r = await callV1(s, `/api/v1/sendInteractiveListMessage?whatsappNumber=${wa}`, jsonInit(body), 'pro');
  if (r.ok && r.result?.wa_id) noteSent(wa, r.result.wa_id);
  return r;
}
/** Interactive BUTTONS message (max 3 buttons, 20 characters each). Their tap comes back as type "button" / "interactive".
 *  v140: image = a public https URL → the header is that image (WATI header type Image + media url). WATI refuses it →
 *  sent again without the header (both tries are in the WATI API log). result.img = the image went. */
export async function waSendButtons(s: Settings, chatId: string, m: { header?: string; body: string; footer?: string; buttons: string[]; image?: string }): Promise<WaResult & { img?: boolean }> {
  const bad = check(s, chatId);
  if (bad) return bad;
  const wa = waDigits(chatId);
  const textHeader = m.header ? { header: { type: 'Text', text: m.header.slice(0, 60) } } : {};
  const base0 = { body: m.body.slice(0, 1024), ...(m.footer ? { footer: m.footer.slice(0, 60) } : {}), buttons: m.buttons.slice(0, 3).map(t => ({ text: t.slice(0, 20) })) };
  remember(wa, m.body);
  const url = `/api/v1/sendInteractiveButtonsMessage?whatsappNumber=${wa}`;
  if (m.image && /^https?:\/\//.test(m.image)) {
    const file = (m.image.split('?')[0].split('/').pop() || 'offer.png').replace(/[^\w.-]/g, '') || 'offer.png';
    const r1 = await callV1(s, url, jsonInit({ header: { type: 'Image', media: { url: m.image, fileName: file } }, ...base0 }), 'pro');
    if (r1.ok) { if (r1.result?.wa_id) noteSent(wa, r1.result.wa_id); return { ...r1, img: true }; }
    logWati('pro', `image header refused (${String(r1.description || '').slice(0, 160)}) → sending the buttons again without the image`);
  }
  const r = await callV1(s, url, jsonInit({ ...textHeader, ...base0 }), 'pro');
  if (r.ok && r.result?.wa_id) noteSent(wa, r.result.wa_id);
  return { ...r, img: false };
}
export type WaTicket = 'OPEN' | 'PENDING' | 'SOLVED' | 'BLOCK';
/** Chat status in the WATI Team Inbox. UNCONFIRMED path → tries the most likely v1 path, then one fallback; never throws. */
export async function waSetChatStatus(s: Settings, wa: string, st: WaTicket): Promise<boolean> {
  try {
    const num = wa.replace(/\D/g, '');
    let r = await callV1(s, '/api/v1/updateChatStatus', jsonInit({ whatsappNumber: num, ticketStatus: st }), 'status');
    if (!r.ok) r = await callV1(s, `/api/v1/updateChatStatus/${num}`, jsonInit({ ticketStatus: st, status: st }), 'status');
    logWati('status', `${st} +${num} → ${r.ok ? 'ok' : 'failed: ' + (r.description || '')}`);
    return r.ok;
  } catch (e) { logWati('status', 'error ' + (e as Error).message); return false; }
}
/** Contact attributes (custom params) on the WATI contact. Never throws. */
export async function waSetAttrs(s: Settings, wa: string, attrs: Record<string, string>): Promise<boolean> {
  try {
    const num = wa.replace(/\D/g, '');
    const r = await callV1(s, `/api/v1/updateContactAttributes/${num}`, jsonInit({ customParams: Object.entries(attrs).map(([name, value]) => ({ name, value: String(value ?? '') })) }), 'attrs');
    return r.ok;
  } catch (e) { logWati('attrs', 'error ' + (e as Error).message); return false; }
}

/** One message from GET /api/v1/getMessages, parsed defensively (the Team Inbox also returns ticket / assignment notes → null). */
export type WaHist = { ids: string[]; text: string; owner: boolean; at: number | null; type: string; media: { kind: string; ref: string } | null; status: string };
const OK_EV = ['', 'message', 'messagereceived', 'sessionmessagesent', 'messagesent', 'templatemessagesent', 'broadcastmessage', 'broadcastmessagesent'];
function histTime(v: unknown): number | null {
  if (v == null || v === '') return null;
  if (typeof v === 'number' || /^\d+(\.\d+)?$/.test(String(v))) { const n = Number(v); return n < 1e12 ? Math.round(n * 1000) : Math.round(n); }
  const t = Date.parse(String(v));
  return Number.isFinite(t) ? t : null;
}
export function parseHistItem(x: any): WaHist | null {
  if (!x || typeof x !== 'object') return null;
  const ev = waEvent(x.eventType || x.event);
  if (!OK_EV.includes(ev)) return null; // ticket, assignment, note, broadcast status…
  const type = String(x.type || 'text').toLowerCase();
  if (['ticket', 'assignment', 'note', 'system', 'notes', 'internal'].includes(type) || x.isNote === true || x.eventDescription) return null;
  const owner = x.owner === true || x.owner === 'true' || /sessionmessagesent|messagesent|templatemessagesent/.test(ev);
  let text = typeof x.text === 'object' && x.text ? String(x.text.body ?? '') : String(x.text ?? x.finalText ?? '');
  if (!text && typeof x.finalText === 'string') text = x.finalText;
  let media: WaHist['media'] = null;
  if (KIND[type]) {
    const d = x.data;
    const ref = typeof d === 'string' ? d : d && typeof d === 'object' ? String(d.url || d.link || d.fileName || d.filename || d.mediaUrl || d.id || '') : String(x.mediaUrl || '');
    media = { kind: KIND[type], ref };
    if (text === ref) text = '';
  }
  if (!text.trim() && !media) return null;
  if (owner && isVendorAuto(text)) return null; // v137: WATI rule text → not imported
  const status = String(x.statusString || x.status || '').toLowerCase();
  if (/fail|error|delet/.test(status)) return null; // never reached the customer
  const ids = [x.whatsappMessageId, x.id, x.localMessageId].filter(v => v != null && v !== '').map(String);
  return { ids, text: text.slice(0, 4000), owner, at: histTime(x.created ?? x.timestamp ?? x.createdDate ?? x.time), type, media, status };
}
/** Last messages of one chat from the Team Inbox (incl. replies typed in the WhatsApp Business app — WATI sends no webhook for those). */
export async function waGetMessages(s: Settings, wa: string, pageSize = 20): Promise<WaHist[] | null> {
  const num = wa.replace(/\D/g, '');
  const { origin, full } = base(s);
  const roots = API() ? [API()] : [...new Set([full, origin])];
  for (const root of roots) {
    const u = `${root}/api/v1/getMessages/${num}?pageSize=${pageSize}&pageNumber=1`;
    try {
      const r = await fetch(u, { headers: { authorization: auth(s) }, signal: AbortSignal.timeout(6000) });
      const txt = await r.text();
      if (!r.ok) { logWati('sync', `${r.status} GET /api/v1/getMessages/${num} ${txt.slice(0, 200)}`); if (r.status === 404 || r.status === 405) continue; return null; }
      let j: any = null; try { j = JSON.parse(txt); } catch { logWati('sync', `not json GET /api/v1/getMessages/${num}`); continue; }
      const raw = Array.isArray(j?.messages?.items) ? j.messages.items : Array.isArray(j?.messages) ? j.messages : Array.isArray(j?.items) ? j.items : Array.isArray(j?.data?.items) ? j.data.items : Array.isArray(j) ? j : [];
      const out = (raw as unknown[]).map(parseHistItem).filter(Boolean) as WaHist[];
      logWati('sync', `200 GET /api/v1/getMessages/${num} items=${raw.length} messages=${out.length} owner=${out.filter(m => m.owner).length}`);
      return out;
    } catch (e) { logWati('sync', `error GET /api/v1/getMessages/${num} ${(e as Error).message}`); }
  }
  return null;
}
/** Admin → Settings → WATI: the last API results (not the raw webhooks). */
export const watiApiLog = (n = 10) => all<{ id: number; at: number; kind: string; body: string }>("SELECT * FROM wati_log WHERE kind IN ('send','pro','status','attrs','sync','media','error') ORDER BY id DESC LIMIT ?", n);
