// v139: length of a voice note / audio file in seconds, read from the file itself (no ffmpeg needed for OGG).
// OGG (Opus or Vorbis): the granule position of the last page ÷ the sample rate (Opus: 48 kHz, minus the pre-skip).
// Used when a voice note is saved, so the chat shows its real length instead of 0:00.

/** Seconds of an OGG/Opus or OGG/Vorbis file; 0 when it is not OGG or can't be read. */
export function oggDuration(buf: Buffer | Uint8Array | null | undefined): number {
  if (!buf || buf.length < 64) return 0;
  const b = Buffer.isBuffer(buf) ? buf : Buffer.from(buf);
  if (b.toString('latin1', 0, 4) !== 'OggS') return 0;
  // first page: the codec header packet starts after the segment table
  const segs = b[26];
  const p0 = 27 + segs;
  let rate = 48000, preSkip = 0;
  if (b.toString('latin1', p0, p0 + 8) === 'OpusHead') preSkip = b.readUInt16LE(p0 + 10);
  else if (b.toString('latin1', p0 + 1, p0 + 7) === 'vorbis') rate = b.readUInt32LE(p0 + 12) || 48000;
  else return 0;
  // last page: search "OggS" backwards and take a sane granule position
  for (let i = b.length - 27; i >= 0; i--) {
    if (b[i] !== 0x4f || b[i + 1] !== 0x67 || b[i + 2] !== 0x67 || b[i + 3] !== 0x53) continue;
    const lo = b.readUInt32LE(i + 6), hi = b.readUInt32LE(i + 10);
    if (hi === 0xffffffff && lo === 0xffffffff) continue; // -1 = no packet ends on this page
    const g = hi * 4294967296 + lo;
    const sec = (g - preSkip) / rate;
    return Number.isFinite(sec) && sec > 0 && sec < 6 * 3600 ? Math.round(sec * 10) / 10 : 0;
  }
  return 0;
}

/** Length from a Telegram-style send result ({ voice: { duration } }) or, else, from the bytes. */
export function mediaDuration(result: any, buf?: Buffer | Uint8Array | null): number | null {
  for (const k of ['voice', 'audio', 'video', 'video_note']) {
    const d = Number(result?.[k]?.duration);
    if (d > 0) return d;
  }
  const d = oggDuration(buf || null);
  return d > 0 ? d : null;
}
