/* v167: Daily reel — a short motivation video shown full screen when staff open the app.
 *
 *  Rules (owner):
 *   - Master switch (reel_on). Off → nothing reel-related runs (next / prefetch return nothing).
 *   - Who sees it: every normal agent, or a picked list of people (agents, managers, the admin). The agent's
 *     "receiving leads" online / offline switch does not matter.
 *   - Per person per reel day (IST, Asia/Kolkata — owner's rule): at most reel_max showings. Showing 1 = the first open of
 *     the day and must be watched fully (no skip; leaving midway replays it on the next open). Showing N+1 = the next fresh
 *     open at least reel_gap_h hours after showing N. Showings 2+ may be skipped.
 *   - Videos are scheduled per day; several per day → each showing picks one the person has not seen today (when possible).
 *     No ready video for the day → no reel.
 *   The server decides the showing number, the gap and the max — the client clock is never trusted for the rules.
 *
 *  Files live next to the database (…/data/reels), never in public/, served by an authenticated route with Range support.
 *  Uploads come in 4 MB chunks streamed to disk (each request is far under nginx's 50 MB body limit; total up to 200 MB).
 *  With ffmpeg (scripts/update.sh installs it) a background job makes the file phone-ready WITHOUT visible / audible loss:
 *  original resolution (only above 1080p is capped), H.264 High CRF 20, original frame rate; H.264 that is already
 *  reasonable is only remuxed (-c:v copy); AAC audio is copied bit for bit. The reel shows to staff only when ready.
 *  A day's video files are deleted from disk once that IST day is over (the row, poster and the views stay for the report). */
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { spawn } from 'child_process';
import { Readable } from 'stream';
import type Database from 'better-sqlite3';
import { db, one, all, run, commSql } from './db';
import { num, money, HttpError } from './util';
import { json } from './http';
import { ffmpegPath } from './voicefx';
import { REEL_QUOTES } from './reelquotes';

/* ---------------- schema ---------------- */

const REEL_SCHEMA = `
CREATE TABLE IF NOT EXISTS reels(id INTEGER PRIMARY KEY AUTOINCREMENT, day TEXT, title TEXT, line TEXT, file TEXT, poster TEXT, mime TEXT,
  duration REAL, luma REAL, theme_auto TEXT, theme_override TEXT, size INTEGER, created_at INTEGER, deleted INTEGER DEFAULT 0);
CREATE INDEX IF NOT EXISTS i_reels_day ON reels(day, deleted);
CREATE TABLE IF NOT EXISTS reel_views(id INTEGER PRIMARY KEY AUTOINCREMENT, who_role TEXT, who_id INTEGER, day TEXT, showing_no INTEGER, reel_id INTEGER,
  style TEXT, started_at INTEGER, ended_at INTEGER, completed INTEGER DEFAULT 0, skipped INTEGER DEFAULT 0,
  UNIQUE(who_role, who_id, day, showing_no));
CREATE INDEX IF NOT EXISTS i_reel_views_day ON reel_views(day, who_role, who_id);
CREATE TABLE IF NOT EXISTS reel_qcursor(k TEXT PRIMARY KEY, start INTEGER NOT NULL, pos INTEGER NOT NULL DEFAULT 0, at INTEGER);
CREATE TABLE IF NOT EXISTS reel_cached(who_role TEXT, who_id INTEGER, reel_id INTEGER, via TEXT, app_build INTEGER, at INTEGER, UNIQUE(who_role, who_id, reel_id));
`; // v168: reel_cached = this person's phone has the reel fully downloaded + sha-verified (native worker or web cache) // v168: reel_qcursor = each person's (or the status video's) place in the quote pool — see takeQuotes
// columns beyond the spec'd ones (added the same way as db.ts ADD_COLUMNS: safe on every start)
const REEL_COLS: [string, string, string][] = [
  ['reels', 'width', 'INTEGER'], ['reels', 'height', 'INTEGER'], ['reels', 'state', "TEXT DEFAULT 'ready'"], ['reels', 'progress', 'INTEGER DEFAULT 0'],
  ['reels', 'playable', 'INTEGER DEFAULT 1'], ['reels', 'sha256', 'TEXT'], ['reels', 'purged', 'INTEGER DEFAULT 0'], ['reels', 'note', 'TEXT'],
  ['reels', 'vcodec', 'TEXT'], ['reels', 'orig_size', 'INTEGER'], ['reels', 'seed', 'INTEGER DEFAULT 0'],
  ['reel_views', 'watched', 'REAL DEFAULT 0'], ['reel_views', 'plays', 'INTEGER DEFAULT 1'],
];

/** v167: creates the reel tables + columns (idempotent). Called by db.ts on start; every reel function also makes sure once. */
export function ensureReelTables(d?: Database.Database) {
  const x = d || db();
  x.exec(REEL_SCHEMA);
  for (const [t, c, type] of REEL_COLS) {
    const cols = x.prepare(`PRAGMA table_xinfo(${t})`).all() as { name: string }[];
    if (!cols.some(k => k.name === c)) { try { x.exec(`ALTER TABLE ${t} ADD COLUMN ${c} ${type}`); } catch { /* added by the other process */ } }
  }
}
let booted = false;
/** First use in this process: tables, the seed video, old files out, interrupted optimise jobs started again. */
const ensure = () => {
  if (booted) return;
  booted = true;
  ensureReelTables();
  try { reelTick(); } catch (e) { console.warn('[reel] boot', (e as Error).message); }
  try { resumeJobs(); } catch (e) { console.warn('[reel] resume', (e as Error).message); }
};

/* ---------------- settings ---------------- */

/** v167: the reel's settings keys (also declared in settings.ts DEFAULTS; read here straight from the table). */
export const REEL_DEFAULTS = {
  reel_on: '0',
  reel_max: '4',            // showings per person per day
  reel_gap_h: '3',          // hours between showings
  reel_first_full: '1',     // showing 1 must be watched fully (no skip, replays until finished)
  reel_skip_later: '1',     // "Skip & open chats" on showings 2+
  reel_styles: 'A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,AA,AB,AC,AD', // player looks, one picked per showing (v168: + the 16 agent formats E–T, all on)
  reel_who: 'agents',       // 'agents' = every normal agent; 'pick' = only reel_people
  reel_people: '',          // picked people: 'admin', 'a:<agent id>' (comma separated)
  reel_seeded: '',          // the shipped seed video was added once
};
export type ReelCfg = { on: boolean; max: number; gapH: number; firstFull: boolean; skipLater: boolean; styles: Style[]; who: 'agents' | 'pick'; people: string[] };
// v168: E–T = the agent daily-reel formats, played in the app by TemplatePlayer (public/reel-tpl/<ID>)
type Style = 'A' | 'B' | 'C' | 'D' | 'E' | 'F' | 'G' | 'H' | 'I' | 'J' | 'K' | 'L' | 'M' | 'N' | 'O' | 'P' | 'Q' | 'R' | 'S' | 'T' | 'U' | 'V' | 'W' | 'X' | 'Y' | 'Z' | 'AA' | 'AB' | 'AC' | 'AD';
const ALL_STYLES: Style[] = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'AA', 'AB', 'AC', 'AD']; // v174: + U–AD
const NEW_174: Style[] = ['U', 'V', 'W', 'X', 'Y', 'Z', 'AA', 'AB', 'AC', 'AD'];
const getS = (k: string) => one<{ v: string }>('SELECT v FROM settings WHERE k=?', k)?.v;
const putSetting = (k: string, v: string) => run('INSERT INTO settings(k, v) VALUES(?, ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v', k, v);

export function reelCfg(): ReelCfg {
  ensure();
  const raw: Record<string, string> = { ...REEL_DEFAULTS };
  for (const r of all<{ k: string; v: string }>(`SELECT k, v FROM settings WHERE k IN (${Object.keys(REEL_DEFAULTS).map(() => '?').join(',')})`, ...Object.keys(REEL_DEFAULTS))) raw[r.k] = r.v ?? '';
  // v168: once, a stored v167 set (A–D, the only ones there were) becomes all 20; any choice saved from v168 on is kept
  if (raw.reel_styles === 'A,B,C,D' && getS('reel_styles_v168') !== '1') { raw.reel_styles = REEL_DEFAULTS.reel_styles; putSetting('reel_styles', raw.reel_styles); putSetting('reel_styles_v168', '1'); }
  // v174: once, the 10 new agent formats (U–AD) are switched ON in a stored list (new formats default ON)
  if (getS('reel_styles_v174') !== '1') { const cur = String(raw.reel_styles || '').split(',').map(x => x.trim().toUpperCase()).filter(Boolean); if (cur.length) { raw.reel_styles = [...new Set([...cur, ...NEW_174])].join(','); putSetting('reel_styles', raw.reel_styles); } putSetting('reel_styles_v174', '1'); }
  const styles = String(raw.reel_styles).split(',').map(x => x.trim().toUpperCase()).filter((x): x is Style => (ALL_STYLES as string[]).includes(x));
  return {
    on: raw.reel_on === '1',
    max: Math.min(10, Math.max(1, Math.round(num(raw.reel_max, 4)))),
    gapH: Math.min(24, Math.max(0.25, num(raw.reel_gap_h, 3))),
    firstFull: raw.reel_first_full !== '0',
    skipLater: raw.reel_skip_later !== '0',
    styles: styles.length ? styles : ALL_STYLES,
    who: raw.reel_who === 'pick' ? 'pick' : 'agents',
    people: String(raw.reel_people || '').split(',').map(x => x.trim()).filter(x => x === 'admin' || /^a:\d+$/.test(x)),
  };
}

/* ---------------- people + time ---------------- */

/** Who is asking: the admin (id 0), or a row of the agents table (normal agent or the manager). */
export type ReelWho = { role: 'admin' } | { role: 'agent' | 'manager'; id: number; name: string };
const whoRole = (w: ReelWho) => (w.role === 'admin' ? 'admin' : 'agent');
const whoId = (w: ReelWho) => (w.role === 'admin' ? 0 : w.id);
const whoKey = (w: ReelWho) => (w.role === 'admin' ? 'admin' : `a:${w.id}`);

function eligible(w: ReelWho, c: ReelCfg) {
  if (c.who === 'pick') return c.people.includes(whoKey(w));
  return w.role === 'agent'; // "All agents" = normal agents only (the manager / admin only when picked)
}

/** Server clock. REEL_TEST_NOW=1 (tests only — never set in production) lets a request carry x-reel-now (ms) to move it. */
export function reelNow(req?: Request) {
  if (process.env.REEL_TEST_NOW === '1' && req) {
    const h = Number(req.headers.get('x-reel-now'));
    if (Number.isFinite(h) && h > 1e12) return h;
  }
  return Date.now();
}
/** The reel day is always IST (UTC+5:30), whatever tz_offset_min says (owner's rule; the default setting is 330 anyway). */
export const IST_MS = 330 * 60000;
export const reelDay = (ms: number) => new Date(ms + IST_MS).toISOString().slice(0, 10);
const dayStart = (ms: number) => Math.floor((ms + IST_MS) / 86400000) * 86400000 - IST_MS; // 00:00 IST of that day (UTC ms)
const addDays = (day: string, n: number) => new Date(Date.parse(day + 'T00:00:00Z') + n * 86400000).toISOString().slice(0, 10);
const isDay = (d: unknown) => typeof d === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(d) && new Date(Date.parse(d + 'T00:00:00Z')).toISOString().slice(0, 10) === d;

/** Stable "random" number from a string (FNV-1a) — the same open asks twice, gets the same answer. */
function hash(s: string) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
const quoteFor = (seed: string) => REEL_QUOTES[hash(seed) % REEL_QUOTES.length];

/* ---------------- v168: quote rotation (guaranteed, per person, stored in the DB) ----------------
 *  Every key (a person: 'reel:admin' / 'reel:a:<id>'; the admin status video: e.g. 'status:admin') walks the pool from its
 *  own start offset: quote #i of that key = REEL_QUOTES[(start + i × stride) % length] (stride: see qStride). Each quote shown moves the cursor
 *  one step, so nothing repeats until the whole pool was used, the 4 showings of a day always differ, and a reinstall
 *  changes nothing (the cursor is on the server). The start comes from a hash of the key, nudged so it stays clear of the
 *  other keys of the same family (two agents never begin on the same quote). */
type QCur = { k: string; start: number; pos: number };
const qLen = () => REEL_QUOTES.length;
let qReady = false;
function qCursor(key: string): QCur {
  if (!qReady) { ensureReelTables(); qReady = true; }
  const got = one<QCur>('SELECT k, start, pos FROM reel_qcursor WHERE k=?', key);
  if (got) return got;
  const L = qLen(), fam = key.slice(0, key.indexOf(':') + 1);
  const others = all<{ start: number }>('SELECT start FROM reel_qcursor WHERE substr(k, 1, ?)=?', fam.length, fam).map(x => ((x.start % L) + L) % L);
  const gap = Math.max(1, Math.min(24, Math.floor(L / (others.length + 1) / 2)));
  const dist = (a: number, b: number) => { const x = Math.abs(a - b) % L; return Math.min(x, L - x); };
  let s = hash(`q|${key}`) % L;
  const step = Math.max(1, Math.round(L * 0.381966)) | 1; // golden-ratio hop; odd so it walks the whole ring for most lengths
  for (let i = 0; i < L && others.some(o => dist(o, s) < gap); i++) s = (s + step) % L;
  run('INSERT INTO reel_qcursor(k, start, pos, at) VALUES(?,?,0,?) ON CONFLICT(k) DO NOTHING', key, s, Date.now());
  return one<QCur>('SELECT k, start, pos FROM reel_qcursor WHERE k=?', key)!;
}
/** v168: the walk takes big hops (≈ 0.38 × the pool, coprime with its length) instead of +1: the pool has neighbouring
 *  English / Hinglish lines on the same idea, and they must not show one after the other. Coprime → every quote exactly
 *  once per lap, so still no repeat until the whole pool was used. */
function qStride(L: number) {
  const gcd = (a: number, b: number): number => (b ? gcd(b, a % b) : a);
  let s = Math.max(1, Math.round(L * 0.382));
  while (L > 1 && gcd(s, L) !== 1) s++;
  return s % Math.max(1, L) || 1;
}
const quotesAt = (c: QCur, from: number, n: number) => { const L = qLen(), st = qStride(L); return Array.from({ length: n }, (_, i) => REEL_QUOTES[(c.start + ((from + i) % L) * st) % L]); };
/** v168: the next `n` quotes of a key WITHOUT using them (reel/next stays read-only; reel/start uses them). */
export function peekQuotes(key: string, n: number) {
  const c = qCursor(key);
  return { at: c.pos, quotes: quotesAt(c, c.pos, Math.max(0, Math.min(qLen(), Math.round(n)))) };
}
/** v168: takes the next `n` quotes of a key and moves its cursor past them (atomic). For the admin status video use its own
 *  key, e.g. takeQuotes('status:admin', 6). */
export function takeQuotes(key: string, n: number): string[] {
  n = Math.max(0, Math.min(qLen(), Math.round(n)));
  return db().transaction(() => {
    const c = qCursor(key);
    run('UPDATE reel_qcursor SET pos=pos+?, at=? WHERE k=?', n, Date.now(), key);
    return quotesAt(c, c.pos, n);
  })();
}
/** v168: marks `n` quotes from `from` as shown (what reel/next offered). Idempotent: the cursor only ever moves forward,
 *  never beyond what was really offered, and a stale / bogus `from` counts from the current place instead. */
function markQuotesShown(key: string, from: unknown, n: number) {
  const c = qCursor(key);
  const f = Number.isInteger(from) && (from as number) >= 0 && (from as number) <= c.pos ? (from as number) : c.pos;
  run('UPDATE reel_qcursor SET pos=MAX(pos, ?), at=? WHERE k=?', f + n, Date.now(), key);
}
/** v168: how many quotes one showing uses: the intro quote, one per ~9 s of video (cycled during playback; for a reel
 *  without a title the first of them is the title), and one for the end card of showing 1. */
export const quotesNeeded = (durationSec: number, showing: number) => 1 + Math.max(1, Math.ceil((Number(durationSec) || 0) / 9)) + (showing === 1 ? 1 : 0);
const qKey = (w: ReelWho) => `reel:${whoKey(w)}`;

/* ---------------- rows ---------------- */

type ReelRow = { id: number; day: string; title: string | null; line: string | null; file: string; poster: string | null; mime: string; duration: number; luma: number | null;
  theme_auto: string | null; theme_override: string | null; size: number; created_at: number; deleted: number; width: number | null; height: number | null;
  state: string | null; progress: number | null; playable: number | null; sha256: string | null; purged: number | null; note: string | null; vcodec: string | null; orig_size: number | null; seed: number | null };
type ViewRow = { id: number; who_role: string; who_id: number; day: string; showing_no: number; reel_id: number; style: string; started_at: number; ended_at: number | null; completed: number; skipped: number; watched: number; plays: number };

const themeOf = (r: Pick<ReelRow, 'theme_auto' | 'theme_override'>) => (r.theme_override === 'dark' || r.theme_override === 'light' ? r.theme_override : r.theme_auto === 'light' ? 'light' : 'dark');
const autoTheme = (luma: number | null) => (luma !== null && luma >= 0.40 ? 'light' : 'dark'); // mean luma < 0.40 = dark
const reelsOf = (day: string) => all<ReelRow>('SELECT * FROM reels WHERE day=? AND deleted=0 ORDER BY id', day);
/** Only what staff may get: finished, not deleted, file still on disk. */
const readyOf = (day: string) => reelsOf(day).filter(r => r.state === 'ready' && !r.purged && r.file && r.sha256);
const viewsOf = (w: ReelWho, day: string) => all<ViewRow>('SELECT * FROM reel_views WHERE who_role=? AND who_id=? AND day=? ORDER BY showing_no', whoRole(w), whoId(w), day);

/** What the client needs to play a reel (file names only; the app builds /api/<app>/reel/media/<file>). */
function pub(r: ReelRow, day: string) {
  const title = String(r.title || '').trim();
  return { id: r.id, day: r.day, title: title || quoteFor(`title|${r.id}|${day}`), title_is_quote: !title, line: String(r.line || '').trim() || null,
    duration: r.duration, theme: themeOf(r), file: r.file, poster: r.poster, mime: r.mime, size: r.size, sha256: r.sha256, width: r.width, height: r.height };
}

/* ---------------- the decision: what to show now ---------------- */

type Decision = { show: false; why: string } | { show: true; showing: number; resume: boolean; reel: ReelRow; style: Style; view?: ViewRow };

function decide(w: ReelWho, now: number): Decision {
  const c = reelCfg();
  if (!c.on) return { show: false, why: 'off' };
  if (!eligible(w, c)) return { show: false, why: 'not_selected' };
  const day = reelDay(now);
  const reels = readyOf(day);
  if (!reels.length) return { show: false, why: 'no_video' };
  const views = viewsOf(w, day);
  const pickStyle = (n: number): Style => c.styles[hash(`style|${whoKey(w)}|${day}|${n}`) % c.styles.length];
  // showing 1 left before the end → it plays again from the top (same video, same look), no gap
  const first = views.find(v => v.showing_no === 1);
  if (c.firstFull && first && !first.completed) {
    const r = reels.find(x => x.id === first.reel_id) || reels[hash(`reel|${whoKey(w)}|${day}|1`) % reels.length];
    const style = (c.styles as string[]).includes(first.style) ? first.style as Style : pickStyle(1);
    return { show: true, showing: 1, resume: true, reel: r, style, view: first };
  }
  const n = views.length;
  if (n >= c.max) return { show: false, why: 'max' };
  if (n > 0) {
    const last = Math.max(...views.map(v => Math.max(v.started_at || 0, v.ended_at || 0)));
    if (now - last < c.gapH * 3600000) return { show: false, why: 'gap' };
  }
  const showing = n + 1;
  const seen = new Set(views.map(v => v.reel_id));
  const pool = reels.filter(r => !seen.has(r.id));
  const from = pool.length ? pool : reels;
  return { show: true, showing, resume: false, reel: from[hash(`reel|${whoKey(w)}|${day}|${showing}`) % from.length], style: pickStyle(showing) };
}

/** v169: the video + style this person gets (or got) at showing 1 of `day`, so their downloadable reel can be made ahead, at night.
 *  Same picks as decide(): a started showing 1 keeps its own; else the same hashes. null = not eligible / no video / reel off. */
export function firstShowingPick(w: ReelWho, day: string): { reel_id: number; style: string } | null {
  const c = reelCfg();
  if (!c.on || !eligible(w, c)) return null;
  const reels = readyOf(day);
  if (!reels.length) return null;
  const first = viewsOf(w, day).find(v => v.showing_no === 1);
  const style = first && (c.styles as string[]).includes(first.style) ? first.style : c.styles[hash(`style|${whoKey(w)}|${day}|1`) % c.styles.length];
  const reel = (first && reels.find(r => r.id === first.reel_id)) || reels[hash(`reel|${whoKey(w)}|${day}|1`) % reels.length];
  return { reel_id: reel.id, style };
}

/** Days in a row (up to `upTo`, inclusive) on which this person watched showing 1 fully. */
function streak(w: ReelWho, upTo: string) {
  const days = new Set(all<{ day: string }>('SELECT day FROM reel_views WHERE who_role=? AND who_id=? AND showing_no=1 AND completed=1 AND day<=? AND day>=?', whoRole(w), whoId(w), upTo, addDays(upTo, -400)).map(r => r.day));
  let n = 0, d = upTo;
  while (days.has(d)) { n++; d = addDays(d, -1); }
  return n;
}

/** Yesterday's earnings of a normal agent: commission (split sales by share) + incentive — the same sums as the agent
 *  dashboard (bonus.ts agentDashboard: earned = commission + incentive; top-up fees belong to the business). Never negative. */
function yesterdayOf(agentId: number, now: number) {
  const t = dayStart(now), f = t - 86400000;
  const comm = one<{ c: number }>(`SELECT ${commSql('?', 'x.created_at>=? AND x.created_at<?')} c`, agentId, f, t, agentId, f, t)?.c || 0;
  const bonus = one<{ v: number }>('SELECT COALESCE(SUM(amount),0) v FROM agent_bonus WHERE agent_id=? AND created_at>=? AND created_at<?', agentId, f, t)?.v || 0;
  const sales = one<{ n: number }>('SELECT COUNT(*) n FROM sales WHERE agent_id=? AND created_at>=? AND created_at<?', agentId, f, t)?.n || 0;
  const earned = money(Math.max(0, comm + bonus));
  const weekday = new Date(f + IST_MS).toLocaleDateString('en-US', { weekday: 'long', timeZone: 'UTC' });
  return earned > 0 ? { earned, sales, weekday } : null;
}

/** v173 (owner): the manager (no commission) and the admin see yesterday's SALES instead: how many + the revenue (never profit).
 *  Manager = his own sales; admin = the whole team's. Hidden when there were none. */
export function yesterdaySalesOf(w: ReelWho, now: number) {
  const t = dayStart(now), f = t - 86400000;
  const r = w.role === 'admin'
    ? one<{ n: number; v: number }>('SELECT COUNT(*) n, COALESCE(SUM(amount),0) v FROM sales WHERE created_at>=? AND created_at<?', f, t)
    : one<{ n: number; v: number }>('SELECT COUNT(*) n, COALESCE(SUM(amount),0) v FROM sales WHERE agent_id=? AND created_at>=? AND created_at<?', w.id, f, t);
  const sales = r?.n || 0, revenue = money(Math.max(0, r?.v || 0));
  const weekday = new Date(f + IST_MS).toLocaleDateString('en-US', { weekday: 'long', timeZone: 'UTC' });
  return sales > 0 && revenue > 0 ? { earned: revenue, sales, weekday, label: w.role === 'admin' ? 'Yesterday the team sold' : 'Yesterday you sold', kind: 'sales' as const } : null;
}

/** Positive numbers for style C's "Your day so far" chips (normal agents only; zero values are left out). */
async function chipsOf(w: ReelWho, now: number) {
  if (w.role !== 'agent') return null;
  const today = one<{ n: number }>('SELECT COUNT(*) n FROM sales WHERE agent_id=? AND created_at>=? AND created_at<?', w.id, dayStart(now), now + 1)?.n || 0;
  let wallet = 0;
  try { wallet = (await import('./crm')).wallet(w.id).available; } catch { /* no wallet */ }
  const out: { today_sales?: number; wallet?: number } = {};
  if (today > 0) out.today_sales = today;
  if (wallet > 0) out.wallet = money(wallet);
  return Object.keys(out).length ? out : null;
}

/** GET reel/next — what to show on this open (or nothing). Read-only: the showing is recorded by reel/start. */
export async function reelNext(w: ReelWho, req: Request) {
  const now = reelNow(req);
  const d = decide(w, now);
  if (!d.show) return { show: false, why: d.why };
  const c = reelCfg();
  const day = reelDay(now);
  const first = d.showing === 1;
  const q = peekQuotes(qKey(w), quotesNeeded(d.reel.duration, d.showing)); // v168: read-only here; reel/start uses them
  const reel = pub(d.reel, day);
  if (reel.title_is_quote) reel.title = q.quotes[1]; // v168: a reel without a title shows the first playback quote, not a per-day hash
  return {
    show: true, day, showing: d.showing, of: c.max, resume: d.resume,
    skip: c.skipLater && !(first && c.firstFull),
    must_finish: first && c.firstFull,
    style: d.style, reel,
    // v177: the day's other videos — when the picked one is not on the phone yet, the app plays one that is (showings 2+)
    alts: d.resume || first ? [] : readyOf(day).filter(r => r.id !== d.reel.id).map(r => pub(r, day)),
    // v168: quotes[] from this person's rotation: [0] = intro, then one per ~9 s (cycled while it plays), then the end card's
    quote: q.quotes[0], quotes: q.quotes, q_at: q.at,
    yesterday: !first || d.resume ? null : w.role === 'agent' ? yesterdayOf(w.id, now) : yesterdaySalesOf(w, now), // v173: manager / admin → sales
    streak_prev: streak(w, addDays(day, -1)), // the end card adds today once it is finished
    chips: await chipsOf(w, now),
    name: w.role === 'admin' ? '' : String(w.name || '').trim().split(/\s+/)[0] || '',
  };
}

/** Real (wall clock) start of each showing, for the "really watched" check (the test clock can't fake it). */
type GS = typeof globalThis & { __reelStarts?: Map<number, number> };
const realStarts = () => { const g = globalThis as GS; const m = (g.__reelStarts ||= new Map()); if (m.size > 5000) m.clear(); return m; };

/** POST reel/start {showing, reel_id, style} — the reel started playing: the showing is counted now. */
export function reelStart(w: ReelWho, b: Record<string, unknown>, req: Request) {
  const now = reelNow(req);
  const d = decide(w, now);
  if (!d.show) throw new HttpError(409, 'No reel to show now');
  if (num(b.showing) !== d.showing) throw new HttpError(409, 'This reel is out of date. Reopen the app.');
  const day = reelDay(now);
  const reel = readyOf(day).find(r => r.id === num(b.reel_id)) || d.reel; // any of today's videos (the client may have had another cached)
  const style = (ALL_STYLES as string[]).includes(String(b.style)) ? String(b.style) : d.style;
  markQuotesShown(qKey(w), b.q_at, quotesNeeded(reel.duration, d.showing)); // v168: the quotes offered by reel/next are now shown
  if (d.resume && d.view) {
    run('UPDATE reel_views SET started_at=?, ended_at=NULL, watched=0, plays=COALESCE(plays,1)+1, reel_id=?, style=? WHERE id=?', now, reel.id, style, d.view.id);
    realStarts().set(d.view.id, Date.now());
    return { ok: true, view_id: d.view.id, showing: 1 };
  }
  run('INSERT OR IGNORE INTO reel_views(who_role, who_id, day, showing_no, reel_id, style, started_at) VALUES(?,?,?,?,?,?,?)', whoRole(w), whoId(w), day, d.showing, reel.id, style, now);
  const v = one<{ id: number }>('SELECT id FROM reel_views WHERE who_role=? AND who_id=? AND day=? AND showing_no=?', whoRole(w), whoId(w), day, d.showing)!;
  realStarts().set(v.id, Date.now());
  return { ok: true, view_id: v.id, showing: d.showing };
}

const ownView = (w: ReelWho, id: unknown) => {
  const v = one<ViewRow>('SELECT * FROM reel_views WHERE id=?', num(id));
  if (!v || v.who_role !== whoRole(w) || v.who_id !== whoId(w)) throw new HttpError(404, 'Reel showing not found');
  return v;
};

/** POST reel/pos {view_id, pos} — how far they got (sent when the app goes to the background; for the report). */
export function reelPos(w: ReelWho, b: Record<string, unknown>) {
  const v = ownView(w, b.view_id);
  if (!v.completed) run('UPDATE reel_views SET watched=MAX(COALESCE(watched,0), ?) WHERE id=?', Math.max(0, Math.min(600, num(b.pos))), v.id);
  return { ok: true };
}

/** POST reel/done {view_id, watched} — the video reached its end. Counts only when ≥ 90% was really watched. */
export function reelDone(w: ReelWho, b: Record<string, unknown>, req: Request) {
  const now = reelNow(req);
  const v = ownView(w, b.view_id);
  const r = one<ReelRow>('SELECT * FROM reels WHERE id=?', v.reel_id);
  const dur = r?.duration || 0;
  const watched = Math.max(0, num(b.watched));
  if (!v.completed) {
    // real watching time on the server clock too (a 45 s reel can't be "finished" 3 s after it started)
    const t0 = realStarts().get(v.id);
    const elapsed = (t0 ? Date.now() - t0 : now - v.started_at) / 1000;
    if (dur > 0 && (watched < dur * 0.9 || elapsed < dur * 0.8)) throw new HttpError(400, 'The reel did not play to the end');
    run('UPDATE reel_views SET completed=1, skipped=0, ended_at=?, watched=? WHERE id=?', now, Math.min(watched, dur || watched), v.id);
  }
  return { ok: true, streak: v.showing_no === 1 ? streak(w, v.day) : null };
}

/** POST reel/skip {view_id} — "Skip & open chats" (showings 2+ only). */
export function reelSkip(w: ReelWho, b: Record<string, unknown>, req: Request) {
  const v = ownView(w, b.view_id);
  const c = reelCfg();
  if ((v.showing_no === 1 && c.firstFull) || !c.skipLater) throw new HttpError(403, 'This reel can’t be skipped');
  if (!v.completed) run('UPDATE reel_views SET skipped=1, ended_at=?, watched=MAX(COALESCE(watched,0), ?) WHERE id=?', reelNow(req), Math.max(0, num(b.watched)), v.id);
  return { ok: true };
}

/** GET reel/prefetch — today's and tomorrow's ready files for this person (the app downloads them in the background). */
export function reelPrefetch(w: ReelWho, req: Request) {
  const c = reelCfg();
  if (!c.on || !eligible(w, c)) return { files: [] };
  const today = reelDay(reelNow(req));
  const seen = new Set(viewsOf(w, today).map(v => v.reel_id));
  const t = readyOf(today);
  const rows = [...t.filter(r => !seen.has(r.id)), ...t.filter(r => seen.has(r.id)), ...readyOf(addDays(today, 1))];
  const media = new URL(req.url).pathname.replace(/prefetch\/?$/, 'media/'); // v168: url = path on this site (the app's native downloader uses it)
  return { today, files: rows.map(r => ({ id: r.id, day: r.day, file: r.file, poster: r.poster, size: r.size, sha256: r.sha256, url: media + encodeURIComponent(r.file) })) };
}

/** v168: POST reel/cached {reel_id, sha256, via:'native'|'web', app_build} — the phone has this reel complete and verified
 *  (silent; for Admin → Daily reel → report "Ready on phone"). Only a current, ready reel with the same sha256 counts. */
export function reelCached(w: ReelWho, b: Record<string, unknown>) {
  const r = one<ReelRow>('SELECT * FROM reels WHERE id=? AND deleted=0', num(b.reel_id));
  if (!r || r.state !== 'ready' || !r.sha256 || String(b.sha256 || '').toLowerCase() !== r.sha256) return { ok: false };
  const via = b.via === 'native' ? 'native' : 'web';
  const build = Math.max(0, Math.min(1e6, Math.round(num(b.app_build)))) || null;
  run(`INSERT INTO reel_cached(who_role, who_id, reel_id, via, app_build, at) VALUES(?,?,?,?,?,?)
    ON CONFLICT(who_role, who_id, reel_id) DO UPDATE SET via=excluded.via, app_build=excluded.app_build, at=excluded.at`, whoRole(w), whoId(w), r.id, via, build, Date.now());
  return { ok: true };
}

/* ---------------- media files ---------------- */

export const reelDir = () => {
  const d = path.join(path.dirname(process.env.DB_PATH || path.join(process.cwd(), 'data', 'adflow.db')), 'reels');
  fs.mkdirSync(d, { recursive: true });
  return d;
};
const MEDIA_RE = /^r\d+-[a-z0-9]{6,16}\.(mp4|mov|m4v|webm|jpg)$/;
const CT: Record<string, string> = { mp4: 'video/mp4', m4v: 'video/mp4', mov: 'video/quicktime', webm: 'video/webm', jpg: 'image/jpeg' };

/** GET reel/media/<file> — a reel video or poster for a logged-in staff member. Byte ranges → 206 (resumable downloads). */
export function serveReelMedia(name: string, req: Request) {
  ensure();
  if (!MEDIA_RE.test(name)) return new Response('not found', { status: 404 });
  const known = one('SELECT 1 FROM reels WHERE ((file=? AND COALESCE(purged,0)=0) OR poster=?) AND deleted=0', name, name);
  const p = path.join(reelDir(), name);
  if (!known || !fs.existsSync(p)) return new Response('not found', { status: 404 });
  const size = fs.statSync(p).size;
  const type = CT[name.split('.').pop()!] || 'application/octet-stream';
  // file names change with every new version of a reel → safe to keep for a long time (private: logged-in only)
  const base: Record<string, string> = { 'content-type': type, 'accept-ranges': 'bytes', 'cache-control': 'private, max-age=31536000, immutable', 'x-content-type-options': 'nosniff' };
  const stream = (a: number, b: number) => Readable.toWeb(fs.createReadStream(p, { start: a, end: b })) as unknown as ReadableStream;
  const rg = /^bytes=(\d*)-(\d*)$/.exec(req.headers.get('range') || '');
  if (rg && (rg[1] || rg[2])) {
    let a = rg[1] ? Number(rg[1]) : Math.max(0, size - Number(rg[2]));
    let b = rg[1] && rg[2] ? Math.min(Number(rg[2]), size - 1) : size - 1;
    if (a >= size || a > b) return new Response(null, { status: 416, headers: { ...base, 'content-range': `bytes */${size}` } });
    a = Math.max(0, a); b = Math.max(a, b);
    return new Response(req.method === 'HEAD' ? null : stream(a, b), { status: 206, headers: { ...base, 'content-range': `bytes ${a}-${b}/${size}`, 'content-length': String(b - a + 1) } });
  }
  return new Response(req.method === 'HEAD' ? null : stream(0, size - 1), { headers: { ...base, 'content-length': String(size) } });
}

const fileSha = (p: string) => new Promise<string>((res, rej) => {
  const h = crypto.createHash('sha256');
  fs.createReadStream(p).on('data', c => h.update(c)).on('error', rej).on('end', () => res(h.digest('hex')));
});
const fileShaSync = (p: string) => { const h = crypto.createHash('sha256'); const fd = fs.openSync(p, 'r'); const buf = Buffer.alloc(1 << 20); try { let n; while ((n = fs.readSync(fd, buf, 0, buf.length, null)) > 0) h.update(buf.subarray(0, n)); } finally { fs.closeSync(fd); } return h.digest('hex'); };

/* ---------------- ffmpeg: probe + the optimise job ---------------- */

/** ffmpeg's view of a file (from `ffmpeg -i` text; no ffprobe needed). */
type Probe = { duration: number; vcodec: string; acodec: string; w: number; h: number; vkbps: number; pix: string; profile: string };
function ffRun(args: string[], ms: number, onOut?: (s: string) => void): Promise<string> {
  const bin = ffmpegPath();
  if (!bin) return Promise.reject(new Error('ffmpeg is not installed'));
  return new Promise((res, rej) => {
    const p = spawn(bin, ['-hide_banner', '-nostdin', ...args], { stdio: ['ignore', 'pipe', 'pipe'] });
    let err = '';
    p.stdout.on('data', d => onOut?.(String(d)));
    p.stderr.on('data', d => { err = (err + d).slice(-12000); });
    const t = setTimeout(() => { p.kill('SIGKILL'); rej(new Error('ffmpeg took too long')); }, ms);
    p.on('error', e => { clearTimeout(t); rej(e); });
    p.on('close', code => { clearTimeout(t); code === 0 ? res(err) : rej(Object.assign(new Error('ffmpeg: ' + (err.trim().split('\n').pop() || 'exit ' + code)), { log: err })); });
  });
}
async function probe(file: string): Promise<Probe | null> {
  let out = '';
  try { out = await ffRun(['-i', file], 30000); } catch (e) { out = String((e as { log?: string }).log || (e as Error).message); }
  const d = /Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)/.exec(out);
  const v = /Stream #\d+:\d+[^\n]*?: Video: ([^\n]+)/.exec(out);
  if (!d || !v) return null;
  const vl = v[1];
  const a = /Stream #\d+:\d+[^\n]*?: Audio: (\w+)/.exec(out);
  const sz = /\b(\d{2,5})x(\d{2,5})\b/.exec(vl);
  return { duration: Number(d[1]) * 3600 + Number(d[2]) * 60 + Number(d[3]), vcodec: (/^(\w+)/.exec(vl)?.[1] || '').toLowerCase(), acodec: (a?.[1] || '').toLowerCase(),
    w: sz ? Number(sz[1]) : 0, h: sz ? Number(sz[2]) : 0, vkbps: Number(/(\d+) kb\/s/.exec(vl)?.[1] || 0), pix: /\b(yuv\w+|nv12|gray\w*)\b/.exec(vl)?.[1] || '', profile: /^\w+ \(([^)]+)\)/.exec(vl)?.[1] || '' };
}
/** Mean luma 0..1 of ~1 frame/s at 64 px (grey). */
function ffLuma(file: string): Promise<number | null> {
  const bin = ffmpegPath();
  if (!bin) return Promise.resolve(null);
  return new Promise(res => {
    const p = spawn(bin, ['-hide_banner', '-nostdin', '-loglevel', 'error', '-i', file, '-vf', 'fps=1,scale=64:-2,format=gray', '-f', 'rawvideo', '-'], { stdio: ['ignore', 'pipe', 'ignore'] });
    let sum = 0, n = 0;
    p.stdout.on('data', (b: Buffer) => { for (let i = 0; i < b.length; i++) sum += b[i]; n += b.length; });
    const t = setTimeout(() => p.kill('SIGKILL'), 120000);
    p.on('close', () => { clearTimeout(t); res(n ? Math.round(sum / n / 255 * 1000) / 1000 : null); });
    p.on('error', () => { clearTimeout(t); res(null); });
  });
}

/** The encode plan (owner: NO visible or audible loss). Exported for the tests. */
export function encodePlan(pr: Probe) {
  const land = pr.w >= pr.h;
  const tooBig = land ? pr.w > 1920 || pr.h > 1080 : pr.w > 1080 || pr.h > 1920; // only above 1080p is capped
  const okH264 = pr.vcodec === 'h264' && !tooBig && (pr.pix === '' || pr.pix === 'yuv420p') && !/10|4:4|high 4/i.test(pr.profile) && (pr.vkbps === 0 || pr.vkbps <= 6500);
  const vf = land ? "scale='min(1920,iw)':-2" : "scale=-2:'min(1920,ih)'";
  const v = okH264 ? ['-c:v', 'copy'] : ['-c:v', 'libx264', '-profile:v', 'high', '-preset', 'medium', '-crf', '20', '-pix_fmt', 'yuv420p', ...(tooBig ? ['-vf', vf] : [])];
  const a = pr.acodec === 'aac' ? ['-c:a', 'copy'] : pr.acodec ? ['-c:a', 'aac', '-b:a', '192k'] : [];
  return { copyVideo: okH264, args: ['-map', '0:v:0', '-map', '0:a:0?', ...v, ...a, '-movflags', '+faststart'] };
}

type GJ = typeof globalThis & { __reelJobs?: Set<number> };
const jobs = () => { const g = globalThis as GJ; return (g.__reelJobs ||= new Set()); };

/** Background: make the upload phone-ready (see encodePlan), poster at 25%, brightness, sha256 → state 'ready'.
 *  Progress (0..100) is saved on the row for the admin ("Optimising video… 60%"). */
async function optimise(id: number) {
  if (jobs().has(id)) return;
  jobs().add(id);
  const dir = reelDir();
  const tag = crypto.randomBytes(5).toString('hex');
  const outName = `r${id}-${tag}.mp4`, posName = `r${id}-${tag}p.jpg`;
  const out = path.join(dir, outName), pos = path.join(dir, posName);
  try {
    const r = one<ReelRow>('SELECT * FROM reels WHERE id=?', id);
    if (!r || r.deleted) return;
    const src = path.join(dir, r.file);
    const origSize = fs.statSync(src).size;
    let finalName = r.file, mime = r.mime, size = origSize, dur = r.duration, w = r.width, h = r.height, note: string | null = null, vcodec = r.vcodec;
    if (ffmpegPath()) {
      run("UPDATE reels SET state='processing', progress=1 WHERE id=?", id);
      const pr = await probe(src);
      if (!pr) throw new Error('ffmpeg could not read this video');
      if (pr.duration > 45.5) { run("UPDATE reels SET state='failed', note=? WHERE id=?", `The video is ${Math.round(pr.duration)} s. The limit is 45 s.`, id); return; }
      vcodec = pr.vcodec; dur = pr.duration || dur; w = pr.w || w; h = pr.h || h;
      const plan = encodePlan(pr);
      let last = 0;
      await ffRun(['-y', '-i', src, ...plan.args, '-progress', 'pipe:1', '-nostats', out], 20 * 60000, s => {
        const m = /out_time_(?:ms|us)=(\d+)/.exec(s);
        if (!m || !dur) return;
        const pct = Math.max(1, Math.min(99, Math.round(Number(m[1]) / 1e6 / dur * 100)));
        if (pct >= last + 3) { last = pct; run('UPDATE reels SET progress=? WHERE id=?', pct, id); }
      });
      const outSize = fs.statSync(out).size;
      // keep the smaller one — unless the original is not H.264 / AAC (phones need the new file then)
      const origFine = pr.vcodec === 'h264' && (pr.acodec === 'aac' || !pr.acodec);
      if (!origFine || outSize <= origSize * 1.02) { finalName = outName; mime = 'video/mp4'; size = outSize; } else { try { fs.unlinkSync(out); } catch { /* gone */ } }
      const fp = path.join(dir, finalName);
      await ffRun(['-y', '-ss', String(Math.max(0, dur * 0.25)), '-i', fp, '-frames:v', '1', '-vf', 'scale=640:-2', '-q:v', '3', pos], 60000).catch(() => null);
      const luma = r.luma ?? await ffLuma(fp);
      if (luma !== r.luma) run('UPDATE reels SET luma=?, theme_auto=? WHERE id=?', luma, autoTheme(luma), id);
    } else {
      // no ffmpeg: the original as it is; warn when it is not H.264 (many phones can't play HEVC)
      vcodec = codecHint(src);
      if (vcodec && vcodec !== 'h264') note = 'This video is not H.264. Many phones can\u2019t play it. Install ffmpeg on the server (scripts/update.sh does it) or export it as MP4 H.264.';
    }
    const sha = await fileSha(path.join(dir, finalName));
    const cur = one<ReelRow>('SELECT * FROM reels WHERE id=?', id);
    if (!cur || cur.deleted) { for (const f of [out, pos]) try { fs.unlinkSync(f); } catch { /* gone */ } return; }
    const hasPos = fs.existsSync(pos);
    run("UPDATE reels SET file=?, mime=?, size=?, duration=?, width=?, height=?, poster=COALESCE(?, poster), sha256=?, state='ready', progress=100, note=?, vcodec=?, orig_size=? WHERE id=?",
      finalName, mime, size, dur, w, h, hasPos ? posName : null, sha, note, vcodec, origSize, id);
    if (finalName !== r.file) try { fs.unlinkSync(src); } catch { /* gone */ }
    notifyReady(id); // v168: silent push → the phones download it in the background
    if (hasPos && cur.poster && cur.poster !== posName) try { fs.unlinkSync(path.join(dir, cur.poster)); } catch { /* gone */ }
  } catch (e) {
    console.warn('[reel] optimise', id, (e as Error).message);
    for (const f of [out, pos]) try { fs.unlinkSync(f); } catch { /* gone */ }
    // the original stays usable when the admin's browser could play it; otherwise nobody gets a broken reel
    const r = one<ReelRow>('SELECT * FROM reels WHERE id=?', id);
    if (r && !r.deleted && r.playable) {
      const sha = await fileSha(path.join(dir, r.file)).catch(() => null);
      run("UPDATE reels SET state=?, sha256=?, progress=100, note=? WHERE id=?", sha ? 'ready' : 'failed', sha, 'Could not optimise this video. The original is used.', id);
      if (sha) notifyReady(id); // v168
    } else run("UPDATE reels SET state='failed', note=? WHERE id=?", 'This video could not be converted. Export it as MP4 H.264 (720p or 1080p) and upload it again.', id);
  } finally { jobs().delete(id); }
}
/** v168: a reel became ready → silent data push {type:'reel_ready'} to the phones of the people who see reels (today's /
 *  tomorrow's videos only). Never shows anything on the phone; old apps ignore it. Best effort. */
function notifyReady(id: number) {
  try {
    const r = one<ReelRow>('SELECT * FROM reels WHERE id=?', id);
    const today = reelDay(Date.now());
    if (!r || r.deleted || (r.day !== today && r.day !== addDays(today, 1))) return;
    const c = reelCfg();
    if (!c.on) return;
    void import('./push').then(m => m.pushReelReady(c.who === 'pick' ? c.people : 'agents', id)).catch(e => console.warn('[reel] push', (e as Error).message));
  } catch (e) { console.warn('[reel] push', (e as Error).message); }
}
/** Without ffmpeg: a quick look at the MP4 sample description for the codec name. */
function codecHint(file: string) {
  try {
    const fd = fs.openSync(file, 'r'), size = fs.fstatSync(fd).size, n = Math.min(size, 4 << 20);
    const a = Buffer.alloc(n); fs.readSync(fd, a, 0, n, 0);
    const b = Buffer.alloc(n); fs.readSync(fd, b, 0, n, Math.max(0, size - n)); fs.closeSync(fd);
    const s = a.toString('latin1') + b.toString('latin1');
    return /avc1|avc3/.test(s) ? 'h264' : /hvc1|hev1/.test(s) ? 'hevc' : /vp09/.test(s) ? 'vp9' : /av01/.test(s) ? 'av1' : '';
  } catch { return ''; }
}
/** Jobs cut short by a restart start again (this process only runs them; the worker never does). */
function resumeJobs() {
  for (const r of all<{ id: number }>("SELECT id FROM reels WHERE deleted=0 AND state='processing'")) void optimise(r.id);
}

/* ---------------- seed video + daily clean-up ---------------- */

/** The video shipped in the update zip (seed/reel-seed.mp4 + .jpg + .json). Added once, for the IST day the update first runs. */
const seedDir = () => process.env.REEL_SEED_DIR || path.join(process.cwd(), 'seed');
function seedOnce(now = Date.now()) {
  if (getS('reel_seeded')) return;
  const mp4 = path.join(seedDir(), 'reel-seed.mp4');
  if (!fs.existsSync(mp4)) return;
  // claim it first (the web app and the worker both start) — only one of them adds the video
  const claim = run("INSERT INTO settings(k, v) VALUES('reel_seeded', ?) ON CONFLICT(k) DO NOTHING", String(now));
  if (!claim.changes) return;
  try {
    let meta: { duration?: number; luma?: number; sha256?: string; width?: number; height?: number } = {};
    try { meta = JSON.parse(fs.readFileSync(path.join(seedDir(), 'reel-seed.json'), 'utf8')); } catch { /* measured below */ }
    const day = reelDay(now);
    const ins = run("INSERT INTO reels(day, title, line, file, poster, mime, duration, luma, theme_auto, size, created_at, deleted, width, height, state, progress, playable, seed) VALUES(?, NULL, NULL, '', NULL, 'video/mp4', ?, ?, ?, ?, ?, 0, ?, ?, 'processing', 0, 1, 1)",
      day, num(meta.duration, 43), meta.luma ?? null, autoTheme(meta.luma ?? null), fs.statSync(mp4).size, now, meta.width || null, meta.height || null);
    const id = Number(ins.lastInsertRowid), tag = crypto.randomBytes(5).toString('hex');
    const file = `r${id}-${tag}.mp4`;
    fs.copyFileSync(mp4, path.join(reelDir(), file));
    let poster: string | null = null;
    const jpg = path.join(seedDir(), 'reel-seed.jpg');
    if (fs.existsSync(jpg)) { poster = `r${id}-${tag}p.jpg`; fs.copyFileSync(jpg, path.join(reelDir(), poster)); }
    const sha = fileShaSync(path.join(reelDir(), file));
    if (meta.sha256 && meta.sha256 !== sha) throw new Error('seed video checksum does not match');
    run("UPDATE reels SET file=?, poster=?, sha256=?, state='ready', progress=100, vcodec='h264' WHERE id=?", file, poster, sha, id);
    // after the update the video plays right away: master ON, all agents (owner)
    putSetting('reel_on', '1'); putSetting('reel_who', 'agents');
    console.log('[reel] seed video added for', day);
  } catch (e) {
    console.warn('[reel] seed failed', (e as Error).message);
    run("DELETE FROM settings WHERE k='reel_seeded'"); // try again next start
  }
}

/** Video files of finished IST days are deleted (from 00:00 IST of the next day). Today's and future files are never touched.
 *  The row (title, poster, duration) and the views stay for the report. Returns how many files went. */
export function purgePast(now = Date.now()) {
  const today = reelDay(now);
  let n = 0;
  for (const r of all<ReelRow>('SELECT * FROM reels WHERE day < ? AND COALESCE(purged,0)=0 AND file != \'\'', today)) {
    if (!(r.day < today)) continue; // belt and braces: never today / future
    try { fs.unlinkSync(path.join(reelDir(), r.file)); } catch { /* already gone */ }
    run('UPDATE reels SET purged=1 WHERE id=?', r.id);
    n++;
  }
  // unfinished uploads older than 3 hours
  try { for (const f of fs.readdirSync(reelDir())) if (f.startsWith('tmp-') && Date.now() - fs.statSync(path.join(reelDir(), f)).mtimeMs > 3 * 3600000) fs.unlinkSync(path.join(reelDir(), f)); } catch { /* none */ }
  return n;
}

/** v167: periodic job (web app boot + the worker's tick): seed once, delete finished days' files. */
export function reelTick(now = Date.now()) {
  ensureReelTables();
  seedOnce(now);
  return { purged: purgePast(now) };
}

/* ---------------- admin ---------------- */

const MAX_BYTES = 200 * 1024 * 1024, MAX_SEC = 45.5, CHUNK = 4 * 1024 * 1024;
type Up = { id: string; meta: { day: string; title: string; line: string; theme_override: string | null; duration: number; luma: number | null; mime: string; size: number; playable: boolean; width: number | null; height: number | null; ext: string }; got: number; at: number; busy: boolean };
type G = typeof globalThis & { __reelUploads?: Map<string, Up> };
const uploads = () => { const g = globalThis as G; return (g.__reelUploads ||= new Map()); };
const tmpPath = (id: string) => path.join(reelDir(), `tmp-${id}.part`);
function sweepUploads() {
  for (const [k, u] of uploads()) if (Date.now() - u.at > 3600000) { uploads().delete(k); try { fs.unlinkSync(tmpPath(k)); } catch { /* gone */ } }
}
const clean = (v: unknown, n: number) => String(v ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, n);
const people = () => all<{ id: number; name: string; username: string; role: string | null }>("SELECT id, name, username, role FROM agents WHERE deleted=0 ORDER BY CASE WHEN role='manager' THEN 0 ELSE 1 END, name");

function adminRow(r: ReelRow, today: string) {
  return { ...pub(r, r.day), title_raw: r.title || '', line_raw: r.line || '', luma: r.luma, theme_auto: r.theme_auto, theme_override: r.theme_override || 'auto',
    state: r.purged ? 'purged' : r.state || 'ready', progress: r.progress || 0, note: r.note, width: r.width, height: r.height, created_at: r.created_at, vcodec: r.vcodec, orig_size: r.orig_size, seed: !!r.seed, past: r.day < today };
}

/** Report for one day: per person showings, watched fully, skipped, not yet. */
function report(day: string) {
  const c = reelCfg();
  const ppl: { key: string; role: string; id: number; name: string }[] = [];
  if (c.who === 'pick' && c.people.includes('admin')) ppl.push({ key: 'admin', role: 'admin', id: 0, name: 'Admin' });
  for (const a of people()) {
    const key = `a:${a.id}`, role = a.role === 'manager' ? 'manager' : 'agent';
    if (c.who === 'pick' ? c.people.includes(key) : role === 'agent') ppl.push({ key, role, id: a.id, name: a.name });
  }
  const views = all<ViewRow & { duration: number | null }>('SELECT v.*, r.duration FROM reel_views v LEFT JOIN reels r ON r.id=v.reel_id WHERE v.day=? ORDER BY v.showing_no', day);
  // anyone who watched that day but is not in today's list (settings changed later) still shows
  for (const v of views) {
    const key = v.who_role === 'admin' ? 'admin' : `a:${v.who_id}`;
    if (!ppl.some(p => p.key === key)) { const a = v.who_role === 'admin' ? null : people().find(x => x.id === v.who_id); ppl.push({ key, role: v.who_role === 'admin' ? 'admin' : a?.role === 'manager' ? 'manager' : 'agent', id: v.who_id, name: v.who_role === 'admin' ? 'Admin' : a?.name || `Agent ${v.who_id}` }); }
  }
  // v168: which of the day's videos each phone has complete + verified (reel/cached); only versions with the current sha256
  const dayReels = reelsOf(day).filter(r => r.sha256);
  const cached = dayReels.length ? all<{ who_role: string; who_id: number; reel_id: number; via: string; app_build: number | null; at: number }>(`SELECT * FROM reel_cached WHERE reel_id IN (${dayReels.map(() => '?').join(',')}) ORDER BY at DESC`, ...dayReels.map(r => r.id)) : [];
  const rows = ppl.map(p => {
    const vs = views.filter(v => v.who_role === (p.role === 'admin' ? 'admin' : 'agent') && v.who_id === p.id);
    const cs = cached.filter(x => x.who_role === (p.role === 'admin' ? 'admin' : 'agent') && x.who_id === p.id); // v168
    const first = vs.find(v => v.showing_no === 1);
    return {
      key: p.key, role: p.role, id: p.id, name: p.name,
      showings: vs.map(v => ({ n: v.showing_no, state: v.completed ? 'watched' : v.skipped ? 'skipped' : 'open', at: v.started_at, ended_at: v.ended_at, watched: Math.round(v.watched || 0), duration: v.duration || 0, reel_id: v.reel_id, style: v.style, plays: v.plays || 1 })),
      watched: vs.filter(v => v.completed).length, skipped: vs.filter(v => v.skipped).length,
      first_done: !!first?.completed, first_at: first?.completed ? first.ended_at : null, first_left: first && !first.completed ? Math.round(first.watched || 0) : null, opened: !!first,
      // v168: "Ready on phone" — at least one of the day's videos is downloaded and verified on this person's phone
      ready_on_phone: cs.length > 0, via: cs[0]?.via || null, app_build: cs[0]?.app_build ?? null, ready_at: cs[0]?.at || null, ready_videos: new Set(cs.map(x => x.reel_id)).size,
    };
  });
  return { day, max: c.max, total: rows.length, first_done: rows.filter(r => r.first_done).length,
    watched: rows.reduce((a, r) => a + r.watched, 0), skipped: rows.reduce((a, r) => a + r.skipped, 0), not_yet: rows.filter(r => !r.first_done).length, rows,
    videos: reelsOf(day).length };
}

/** Writes one upload chunk from the request body straight to disk (streamed, never the whole file in memory). */
async function writeChunk(req: Request, file: string, off: number, max: number) {
  if (!req.body) return 0;
  const fd = fs.openSync(file, 'r+');
  let pos = off, n = 0;
  try {
    const rd = req.body.getReader();
    for (;;) {
      const { done, value } = await rd.read();
      if (done) break;
      n += value.length;
      if (n > max) { void rd.cancel(); throw new HttpError(400, 'Chunk too large'); }
      fs.writeSync(fd, value, 0, value.length, pos);
      pos += value.length;
    }
  } finally { fs.closeSync(fd); }
  return n;
}

/** Admin API for the reel: `p` = the path after "reel/". GET = reads, POST = actions (every change is POST-only). */
export async function reelAdminApi(p: string, req: Request): Promise<Response> {
  ensure();
  const post = req.method === 'POST';
  const url = new URL(req.url);
  const today = reelDay(reelNow(req));
  if (post && req.headers.get('sec-fetch-site') === 'cross-site') return json({ error: 'Cross-site request refused' }, 403);
  if (p.startsWith('media/')) return serveReelMedia(decodeURIComponent(p.slice(6)), req);
  if (p === 'upload_chunk') { // raw bytes (application/octet-stream), ?id=&off=
    if (!post) return json({ error: 'Use POST' }, 405);
    const u = uploads().get(String(url.searchParams.get('id') || ''));
    if (!u) throw new HttpError(404, 'Upload expired. Start again.');
    const off = num(url.searchParams.get('off'), -1);
    if (off !== u.got) return json({ error: 'Out of order', got: u.got }, 409);
    if (u.busy) return json({ error: 'Busy', got: u.got }, 409);
    u.busy = true;
    try {
      const n = await writeChunk(req, tmpPath(u.id), off, Math.min(CHUNK + 1024, u.meta.size - u.got));
      if (!n) throw new HttpError(400, 'Empty chunk');
      u.got += n; u.at = Date.now();
    } catch (e) {
      try { fs.truncateSync(tmpPath(u.id), u.got); } catch { /* gone */ } // a broken chunk is dropped; the client sends it again
      throw e;
    } finally { u.busy = false; }
    return json({ ok: true, got: u.got });
  }
  const b: Record<string, any> = post ? await req.json().catch(() => ({})) : {};
  const needPost = () => { if (!post) throw new HttpError(405, 'Use POST'); };
  switch (p) {
    case 'settings': {
      const c = reelCfg();
      return json({ cfg: { on: c.on, max: c.max, gap_h: c.gapH, first_full: c.firstFull, skip_later: c.skipLater, styles: c.styles, who: c.who, people: c.people },
        people: [{ key: 'admin', name: 'You (admin)', role: 'admin', username: '' }, ...people().map(a => ({ key: `a:${a.id}`, name: a.name, role: a.role === 'manager' ? 'manager' : 'agent', username: a.username }))],
        today, ffmpeg: !!ffmpegPath(), today_videos: readyOf(today).length });
    }
    case 'settings_save': {
      needPost();
      const put: [string, string][] = [];
      if ('on' in b) put.push(['reel_on', b.on ? '1' : '0']);
      if ('max' in b) { const n = Math.round(num(b.max)); if (n < 1 || n > 10) throw new HttpError(400, 'Times per day: 1 to 10'); put.push(['reel_max', String(n)]); }
      if ('gap_h' in b) { const n = num(b.gap_h); if (!(n >= 0.25 && n <= 24)) throw new HttpError(400, 'Gap: 15 minutes to 24 hours'); put.push(['reel_gap_h', String(Math.round(n * 4) / 4)]); }
      if ('first_full' in b) put.push(['reel_first_full', b.first_full ? '1' : '0']);
      if ('skip_later' in b) put.push(['reel_skip_later', b.skip_later ? '1' : '0']);
      if ('styles' in b) { const st = (Array.isArray(b.styles) ? b.styles : []).map((x: unknown) => String(x).toUpperCase()).filter((x: string) => (ALL_STYLES as string[]).includes(x)); if (!st.length) throw new HttpError(400, 'Pick at least one player style'); put.push(['reel_styles', ALL_STYLES.filter(x => st.includes(x)).join(',')], ['reel_styles_v168', '1']); } // v168: marks a deliberate choice
      if ('who' in b) put.push(['reel_who', b.who === 'pick' ? 'pick' : 'agents']);
      if ('people' in b) { const ids = new Set(people().map(a => `a:${a.id}`)); const ps = [...new Set((Array.isArray(b.people) ? b.people : []).map(String))].filter(k => k === 'admin' || ids.has(k)); put.push(['reel_people', ps.join(',')]); }
      for (const [k, v] of put) putSetting(k, v);
      return json({ ok: true });
    }
    case 'schedule': {
      // today + the next 7 days (empty ones show "No reel") + any later day with videos, plus the last 3 days
      const from = addDays(today, -3);
      const rows = all<ReelRow>('SELECT * FROM reels WHERE deleted=0 AND day>=? ORDER BY day, id', from);
      const days = new Set<string>(rows.map(r => r.day));
      for (let i = 0; i < 7; i++) days.add(addDays(today, i));
      return json({ today, ffmpeg: !!ffmpegPath(), days: [...days].sort().map(d => ({ day: d, past: d < today, videos: rows.filter(r => r.day === d).map(r => adminRow(r, today)) })) });
    }
    case 'report': {
      const d = url.searchParams.get('day') || today;
      if (!isDay(d)) throw new HttpError(400, 'Pick a date');
      return json({ today, ...report(d) });
    }
    case 'update': {
      needPost();
      const r = one<ReelRow>('SELECT * FROM reels WHERE id=? AND deleted=0', num(b.id));
      if (!r) throw new HttpError(404, 'Video not found');
      const th = b.theme === 'dark' || b.theme === 'light' ? b.theme : 'auto';
      if (b.day !== undefined && (!isDay(b.day) || b.day < today)) throw new HttpError(400, 'Pick today or a later day');
      run('UPDATE reels SET title=?, line=?, theme_override=?, day=? WHERE id=?', 'title' in b ? clean(b.title, 80) || null : r.title, 'line' in b ? clean(b.line, 90) || null : r.line, th === 'auto' ? null : th, b.day || r.day, r.id);
      return json({ ok: true });
    }
    case 'delete': {
      needPost();
      const r = one<ReelRow>('SELECT * FROM reels WHERE id=? AND deleted=0', num(b.id));
      if (!r) throw new HttpError(404, 'Video not found');
      run('UPDATE reels SET deleted=1 WHERE id=?', r.id);
      // the files go; the row stays (marked deleted) so the report keeps its history
      for (const f of [r.file, r.poster]) if (f) try { fs.unlinkSync(path.join(reelDir(), f)); } catch { /* gone */ }
      return json({ ok: true });
    }
    case 'upload_init': {
      needPost();
      sweepUploads();
      const day = String(b.day || '');
      if (!isDay(day)) throw new HttpError(400, 'Pick the day');
      if (day < today) throw new HttpError(400, 'Pick today or a later day');
      const size = Math.round(num(b.size));
      if (!(size > 0)) throw new HttpError(400, 'Choose a video');
      if (size > MAX_BYTES) throw new HttpError(400, 'The video is larger than 200 MB');
      const duration = num(b.duration);
      if (!(duration > 0)) throw new HttpError(400, 'Could not read the video length. Export it as MP4 H.264 and try again.');
      if (duration > MAX_SEC) throw new HttpError(400, `The video is ${Math.round(duration)} s. The limit is 45 s.`);
      const playable = b.playable !== false;
      if (!playable && !ffmpegPath()) throw new HttpError(400, 'This video format won\u2019t play on many phones. Export it as MP4 H.264 (720p or 1080p).');
      const ext = /\.mov$/i.test(String(b.name || '')) || b.mime === 'video/quicktime' ? 'mov' : /webm/i.test(String(b.mime)) ? 'webm' : 'mp4';
      const id = crypto.randomBytes(9).toString('hex');
      fs.writeFileSync(tmpPath(id), Buffer.alloc(0));
      const luma = b.luma === null || b.luma === undefined || !Number.isFinite(Number(b.luma)) ? null : Math.max(0, Math.min(1, num(b.luma)));
      uploads().set(id, { id, got: 0, at: Date.now(), busy: false, meta: { day, title: clean(b.title, 80), line: clean(b.line, 90), theme_override: b.theme === 'dark' || b.theme === 'light' ? b.theme : null,
        duration, luma, mime: CT[ext], size, playable, width: num(b.width) || null, height: num(b.height) || null, ext } });
      return json({ upload_id: id, chunk: CHUNK, ffmpeg: !!ffmpegPath() });
    }
    case 'upload_done': {
      needPost();
      const u = uploads().get(String(b.upload_id || ''));
      if (!u) throw new HttpError(404, 'Upload expired. Start again.');
      if (u.got !== u.meta.size) throw new HttpError(400, 'The upload is incomplete. Try again.');
      const tmp = tmpPath(u.id);
      // a video container? (MP4 / MOV "ftyp" box, or WebM / Matroska)
      const head = Buffer.alloc(12); const fd = fs.openSync(tmp, 'r'); fs.readSync(fd, head, 0, 12, 0); fs.closeSync(fd);
      const isMp4 = head.subarray(4, 8).toString('latin1') === 'ftyp', isWebm = head.readUInt32BE(0) === 0x1A45DFA3;
      if (!isMp4 && !isWebm) { uploads().delete(u.id); try { fs.unlinkSync(tmp); } catch { /* gone */ } throw new HttpError(400, 'This file is not an MP4 / MOV / WebM video'); }
      const m = u.meta;
      const ins = run("INSERT INTO reels(day, title, line, file, poster, mime, duration, luma, theme_auto, theme_override, size, created_at, deleted, width, height, state, progress, playable, orig_size) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,0,?,?,'processing',0,?,?)",
        m.day, m.title || null, m.line || null, '', null, m.mime, m.duration, m.luma, autoTheme(m.luma), m.theme_override, m.size, Date.now(), m.width, m.height, m.playable ? 1 : 0, m.size);
      const id = Number(ins.lastInsertRowid), tag = crypto.randomBytes(5).toString('hex');
      const file = `r${id}-${tag}.${isWebm ? 'webm' : m.ext}`;
      fs.renameSync(tmp, path.join(reelDir(), file));
      uploads().delete(u.id);
      // poster from the admin's browser (JPEG data URL, frame at 25%) — replaced by ffmpeg's when it can
      let poster: string | null = null;
      const pm = /^data:image\/jpeg;base64,([A-Za-z0-9+/=]+)$/.exec(String(b.poster || ''));
      if (pm && pm[1].length < 1_500_000) { poster = `r${id}-${tag}q.jpg`; fs.writeFileSync(path.join(reelDir(), poster), Buffer.from(pm[1], 'base64')); }
      run('UPDATE reels SET file=?, poster=? WHERE id=?', file, poster, id);
      void optimise(id); // background: ready for staff only when this finishes
      return json({ ok: true, reel: adminRow(one<ReelRow>('SELECT * FROM reels WHERE id=?', id)!, today) });
    }
    case 'upload_cancel': {
      needPost();
      const id = String(b.upload_id || '');
      uploads().delete(id);
      try { fs.unlinkSync(tmpPath(id)); } catch { /* gone */ }
      return json({ ok: true });
    }
  }
  return json({ error: 'Not found' }, 404);
}

/** v179: what the phone's reel player saw (stall, video error, JS error) → one line in the server log (pm2 logs), so a
 *  "reel did not play" report has an exact reason. At most 40 lines per person per hour; text only, no tokens. */
const diagSeen = new Map<string, { n: number; at: number }>();
function reelDiag(w: ReelWho, b: Record<string, unknown>) {
  const k = whoKey(w), now = Date.now(), c = diagSeen.get(k);
  if (c && now - c.at < 3600000) { if (++c.n > 40) return { ok: true }; } else diagSeen.set(k, { n: 1, at: now });
  const clean = (v: unknown, n = 300) => String(v ?? '').replace(/[\r\n\t]+/g, ' ').replace(/[^\x20-\x7e]/g, '?').slice(0, n);
  const who = w.role === 'admin' ? 'admin' : `${w.role}#${w.id} ${clean(w.name, 40)}`;
  console.log(`[reel-diag] ${new Date(now).toISOString()} ${who} style=${clean(b.style, 4)} showing=${clean(b.showing, 3)} reel=${clean(b.reel_id, 10)} src=${clean(b.src, 12)} what=${clean(b.what, 40)} ${clean(b.info)}`);
  return { ok: true };
}

/** Staff API (agent / manager / admin as a viewer): next, start, pos, done, skip, prefetch, media. */
export async function reelUserApi(p: string, w: ReelWho, req: Request): Promise<Response> {
  ensure();
  if (p.startsWith('media/')) return serveReelMedia(decodeURIComponent(p.slice(6)), req);
  const post = req.method === 'POST';
  if (post && req.headers.get('sec-fetch-site') === 'cross-site') return json({ error: 'Cross-site request refused' }, 403);
  const b: Record<string, unknown> = post ? await req.json().catch(() => ({})) : {};
  const act = (f: () => unknown) => (post ? json(f()) : json({ error: 'Use POST' }, 405));
  switch (p) {
    case 'next': return json(await reelNext(w, req));
    case 'prefetch': return json(reelPrefetch(w, req));
    case 'start': return act(() => reelStart(w, b, req));
    case 'pos': return act(() => reelPos(w, b));
    case 'done': return act(() => reelDone(w, b, req));
    case 'skip': return act(() => reelSkip(w, b, req));
    case 'cached': return act(() => reelCached(w, b)); // v168
    case 'diag': return act(() => reelDiag(w, b)); // v179
  }
  return json({ error: 'Not found' }, 404);
}
