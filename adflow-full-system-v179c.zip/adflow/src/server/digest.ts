/** v158: daily top-up post (default 10 PM, India time).
 *  Channel: albums of 10 top-up images → the last album = cover + the rest (≤9) with all the details under it → a small message with 4 buttons.
 *  When the count is a round 10 / 20 / 30 …, the smallest top-up's image is left out (it is still in the cover, the list and the story).
 *  Story (9:16, no button): all the top-up screenshots as a collage. A copy goes to our Saved Messages. No top-ups that day → nothing. */
import fs from 'fs';
import path from 'path';
import { one, all, run } from './db';
import { getSettings, setSetting } from './settings';
import { now, num, money } from './util';
import { leadById, displayName } from './crm';
import * as M from './meta';
import { publicUrl } from './email';
const siteHost = () => (publicUrl() || 'adsbhai.com').replace(/^https?:\/\//, '').replace(/\/$/, '');

const tzMs = () => num(getSettings().tz_offset_min, 330) * 60000; // v166: business time zone (Settings), India by default
const usd = (n: number) => '$' + money(n).toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
const esc = (t: string) => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const FONT = `font-family="Inter, 'Helvetica Neue', Arial, sans-serif"`;

/** Folder next to the database for the top-up images (kept, never in the update zip). */
export function topupDir() {
  const db = process.env.DB_PATH || path.join(process.cwd(), 'data', 'adflow.db');
  const d = path.join(path.dirname(db), 'topups');
  try { fs.mkdirSync(d, { recursive: true }); } catch { /* */ }
  return d;
}
/** Keep the image made at the top-up for tonight's post (the newest top-up of this account that has none yet). */
export function saveTopupImg(act: string, img: Buffer, opts: { since?: number } = {}) {
  try {
    const rows = all<{ id: number }>("SELECT id FROM meta_log WHERE act_id=? AND kind='topup' AND amount>0 AND img IS NULL AND created_at>=? ORDER BY id DESC", act, opts.since ?? now() - 2 * 3600000);
    if (!rows.length) return;
    const f = path.join(topupDir(), `topup-${rows[0].id}.png`);
    fs.writeFileSync(f, img);
    run('UPDATE meta_log SET img=? WHERE id=?', path.basename(f), rows[0].id);
  } catch (e) { console.warn('[digest] save image', (e as Error).message); }
}

type Row = { id: number; act: string; lead_id: number | null; amount: number; fee: number; at: number; img: string | null; name: string; acct: string };
const dayOf = (t: number) => new Date(t + tzMs()).toISOString().slice(0, 10);
const dayStart = (d: string) => Date.parse(d + 'T00:00:00Z') - tzMs();
const dayLabel = (d: string) => new Date(d + 'T00:00:00Z').toLocaleDateString('en-GB', { day: 'numeric', month: 'short', timeZone: 'UTC' });

export function topupsOf(day: string): Row[] {
  const f = dayStart(day), t = f + 86400000;
  return topupsIn(f, t);
}
/** v166: the post covers the top-ups since the last post before this day (e.g. 22:30–24:00 yesterday), at most from the day before; no earlier post → the day. */
export function digestWindow(day: string): [number, number] {
  const f = dayStart(day);
  const last = one<{ at: number }>("SELECT MAX(created_at) at FROM meta_log WHERE kind='digest' AND created_at<?", f)?.at;
  return [last ? Math.max(last, f - 86400000) : f, Math.min(now() + 1, f + 86400000)];
}
export const digestRows = (day: string) => topupsIn(...digestWindow(day));
function topupsIn(f: number, t: number): Row[] {
  const rows = all<{ id: number; act_id: string; lead_id: number | null; amount: number; fee: number | null; created_at: number; img: string | null }>(
    "SELECT id, act_id, lead_id, amount, fee, created_at, img FROM meta_log WHERE kind='topup' AND amount>0 AND created_at>=? AND created_at<? ORDER BY id", f, t);
  const out: Row[] = [];
  for (const r of rows) {
    const a = M.acctOf(r.act_id);
    if (!a) continue;
    const lead = r.lead_id ? leadById(r.lead_id) : a.lead_id ? leadById(a.lead_id) : undefined;
    out.push({ id: r.id, act: r.act_id, lead_id: r.lead_id, amount: money(r.amount), fee: money(r.fee || 0), at: r.created_at, img: r.img,
      name: lead ? displayName(lead).slice(0, 24) : 'Client', acct: a.name || 'act_' + a.act_id });
  }
  return out.sort((x, y) => y.amount - x.amount || x.at - y.at);
}

async function topupImage(r: Row) {
  if (r.img) { try { return fs.readFileSync(path.join(topupDir(), r.img)); } catch { /* make it again */ } }
  const P = await import('./proof');
  const d = await P.proofData(r.act); // not in a queue job → from our records only (no Meta call)
  const a = M.acctOf(r.act)!;
  const img = await P.render(P.topupSvg({ ...d, name: r.acct, topup: r.amount, fee: r.fee || null, capTotal: a.cap > 0 ? a.cap / 100 : null, remaining: a.cap > 0 ? Math.max(0, a.cap - a.spent) / 100 : null }), 1600);
  try { const f = `topup-${r.id}.png`; fs.writeFileSync(path.join(topupDir(), f), img); run('UPDATE meta_log SET img=? WHERE id=?', f, r.id); } catch { /* */ }
  return img;
}

/** Channel caption under the last album (Telegram allows 1024 characters): with the account names when they fit. */
export function digestCaption(rows: Row[], day: string) {
  const s = getSettings();
  const total = rows.reduce((t, r) => t + r.amount, 0);
  const clients = new Set(rows.map(r => r.lead_id || r.act)).size;
  const head = `✅ Today's top-ups — ${dayLabel(day)}\n\n💰 ${rows.length === clients ? `${clients} client${clients > 1 ? 's' : ''} topped up their ad accounts` : `${rows.length} top-ups for ${clients} clients`}\n💵 Total added: ${usd(total)}\n\n`;
  const bot = s.bot_username || '';
  const site = siteHost();
  const foot = `\n\n🔷 Top-ups at just ${num(s.topup_comm_pct, 3)}% fee · No 18% GST\n🔷 Live data from the Meta API\n\n🌐 ${site}${bot ? ` 💬 @${bot}` : ''}\n🤖 Automatic message`;
  const long = rows.map((r, i) => `${i + 1}. ${r.name} — ${usd(r.amount)} · ${r.acct}`).join('\n');
  if ((head + long + foot).length <= 1024) return head + long + foot;
  const short = rows.map((r, i) => `${i + 1}. ${r.name} — ${usd(r.amount)}`);
  let list = short.join('\n');
  for (let k = short.length; (head + list + foot).length > 1024 && k > 0; k--) list = short.slice(0, k - 1).join('\n') + `\n… + ${short.length - k + 1} more`;
  return head + list + foot;
}
export function storyCaptionDigest(rows: Row[], day: string) {
  const s = getSettings();
  const total = rows.reduce((t, r) => t + r.amount, 0), clients = new Set(rows.map(r => r.lead_id || r.act)).size;
  const site = siteHost();
  return `💰 Today's top-ups — ${dayLabel(day)}\n${clients} client${clients > 1 ? 's' : ''} · ${usd(total)} added\n✅ ${num(s.topup_comm_pct, 3)}% fee · No 18% GST\n💬 ${s.bot_username ? '@' + s.bot_username + ' · ' : ''}${site}`.slice(0, 200);
}

async function logoHref() {
  try { const B = await import('./brandkit'); return 'data:image/png;base64,' + Buffer.from(await (await B.logoImage(undefined as never, 256)).arrayBuffer()).toString('base64'); } catch { return ''; }
}
function bgDefs() {
  return `<defs><radialGradient id="a" cx="0.85" cy="-0.1" r="0.8"><stop offset="0" stop-color="#7c3aed"/><stop offset="1" stop-color="#160b2e" stop-opacity="0"/></radialGradient></defs>`;
}
/** 16:9 cover: count, total, every client's amount (up to 30 boxes). */
export function coverSvg(rows: Row[], day: string, logo: string) {
  const s = getSettings();
  const total = rows.reduce((t, r) => t + r.amount, 0), brand = s.brand_name || 'Adsbhai';
  const show = rows.length > 30 ? rows.slice(0, 29) : rows;
  // v163: boxes sized to the count (5 top-ups fill the picture, 30 still fit)
  const n = show.length + (rows.length > 30 ? 1 : 0), AW = 1780, AH = 790, G = 20;
  let best = { cols: 6, bw: 285, bh: 142 };
  for (let c = 1; c <= 6; c++) {
    const r = Math.ceil(n / c), w = (AW - (c - 1) * G) / c, h = Math.min((AH - (r - 1) * G) / r, w * 0.55, 300);
    if (h >= 100 && h * Math.min(w, h * 2.6) > best.bh * Math.min(best.bw, best.bh * 2.6)) best = { cols: c, bw: Math.min(w, h * 2.6), bh: h };
  }
  const { cols, bw, bh } = best;
  const gridW = cols * bw + (cols - 1) * G, gridH = Math.ceil(n / cols) * (bh + G) - G;
  const gx0 = 70 + (AW - gridW) / 2, gy0 = 225 + Math.max(0, (AH - gridH) / 2);
  const fName = Math.round(Math.min(bh * 0.19, 34)), fAmt = Math.round(Math.min(bh * 0.33, 76));
  const rowsN = Math.ceil(n / cols), inLast = n - (rowsN - 1) * cols;
  const at = (i: number) => ({ x: gx0 + (i % cols) * (bw + G) + (Math.floor(i / cols) === rowsN - 1 ? (cols - inLast) * (bw + G) / 2 : 0), y: gy0 + Math.floor(i / cols) * (bh + G) }); // last row centred
  let svg = `<svg xmlns="http://www.w3.org/2000/svg" width="1920" height="1080" ${FONT}>${bgDefs()}<rect width="1920" height="1080" fill="#160b2e"/><rect width="1920" height="1080" fill="url(#a)"/>
${logo ? `<image href="${logo}" x="70" y="50" width="60" height="60"/>` : ''}<text x="146" y="94" font-size="34" font-weight="800" fill="#fff">${esc(brand.toUpperCase())}</text>
<rect x="${170 + brand.length * 26}" y="56" width="440" height="50" rx="25" fill="none" stroke="#22c55e" stroke-width="3"/><text x="${390 + brand.length * 26}" y="90" font-size="23" font-weight="700" fill="#86efac" text-anchor="middle">● TODAY'S TOP-UPS · ${esc(dayLabel(day).toUpperCase())}</text>
<text x="1850" y="96" font-size="54" font-weight="900" fill="#86efac" text-anchor="end">+ ${esc(usd(total))}</text>
<text x="70" y="190" font-size="56" font-weight="900" fill="#fff">${rows.length} top-up${rows.length > 1 ? 's' : ''} today</text><text x="1850" y="190" font-size="26" fill="#d8ccff" text-anchor="end">${num(s.topup_comm_pct, 3)}% fee · no 18% GST</text>`;
  show.forEach((r, i) => {
    const { x, y } = at(i), pad = Math.round(bh * 0.14), amt = '+ ' + usd(r.amount), fA = Math.round(Math.min(fAmt, (bw - 2 * pad) / (amt.length * 0.6))), maxCh = Math.max(8, Math.floor((bw - 2 * pad) / (fName * 0.56)));
    svg += `<rect x="${x}" y="${y}" width="${bw}" height="${bh}" rx="${Math.round(bh * 0.1)}" fill="#fff" fill-opacity="0.08" stroke="#fff" stroke-opacity="0.15"/><text x="${x + pad}" y="${y + pad + fName}" font-size="${fName}" fill="#c4b5fd">${esc(r.name.length > maxCh ? r.name.slice(0, maxCh - 1) + '…' : r.name)}</text><text x="${x + pad}" y="${y + bh - pad}" font-size="${fA}" font-weight="800" fill="#fff">${esc(amt)}</text>`;
  });
  if (rows.length > 30) { const { x, y } = at(29); svg += `<rect x="${x}" y="${y}" width="${bw}" height="${bh}" rx="14" fill="#fff" fill-opacity="0.12"/><text x="${x + bw / 2}" y="${y + bh / 2 + 12}" font-size="34" font-weight="800" fill="#fff" text-anchor="middle">+ ${rows.length - 29} more</text>`; }
  return svg + `<text x="70" y="1050" font-size="22" fill="#d8ccff">Live data via Meta API · ${esc(brand)} records${s.bot_username ? ' · @' + esc(s.bot_username) : ''}</text></svg>`;
}
/** v164: 16:9 cover with the real top-up screenshots (as big as they fit), each with the client's name and a green amount badge.
 *  Up to 30; more → 29 + "+N more". */
export async function coverShots(rows: Row[], imgs: Buffer[], day: string, logo: string) {
  const sharp = (await import('sharp')).default;
  const s = getSettings();
  const total = rows.reduce((t, r) => t + r.amount, 0), brand = s.brand_name || 'Adsbhai';
  const W = 1920, H = 1080, AX = 70, AY = 228, AW = 1780, AH = 790;
  const more = rows.length > 30 ? rows.length - 29 : 0, n = more ? 30 : rows.length;
  const meta = await sharp(imgs[0]).metadata(); const AR = (meta.height || 900) / (meta.width || 1600);
  let best = { c: 1, w: 0, h: 0, g: 24 };
  for (let c = 1; c <= 8; c++) {
    const g = c <= 3 ? 28 : 18, r = Math.ceil(n / c);
    let w = (AW - (c - 1) * g) / c, h = w * AR;
    if (r * h + (r - 1) * g > AH) { h = (AH - (r - 1) * g) / r; w = h / AR; }
    if (w > best.w) best = { c, w, h, g };
  }
  const cols = best.c, g = best.g, w = Math.floor(best.w), h = Math.floor(best.h);
  const rN = Math.ceil(n / cols), inLast = n - (rN - 1) * cols, gridH = rN * h + (rN - 1) * g, y0 = AY + (AH - gridH) / 2;
  const pos = (i: number) => { const r = Math.floor(i / cols), k = r === rN - 1 ? inLast : cols, rowW = k * w + (k - 1) * g; return { x: Math.round(AX + (AW - rowW) / 2 + (i % cols) * (w + g)), y: Math.round(y0 + r * (h + g)) }; };
  const bg = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" ${FONT}>${bgDefs()}<rect width="${W}" height="${H}" fill="#160b2e"/><rect width="${W}" height="${H}" fill="url(#a)"/>
${logo ? `<image href="${logo}" x="70" y="50" width="60" height="60"/>` : ''}<text x="146" y="94" font-size="34" font-weight="800" fill="#fff">${esc(brand.toUpperCase())}</text>
<rect x="${170 + brand.length * 26}" y="56" width="440" height="50" rx="25" fill="none" stroke="#22c55e" stroke-width="3"/><text x="${390 + brand.length * 26}" y="90" font-size="23" font-weight="700" fill="#86efac" text-anchor="middle">● TODAY'S TOP-UPS · ${esc(dayLabel(day).toUpperCase())}</text>
<text x="1850" y="96" font-size="54" font-weight="900" fill="#86efac" text-anchor="end">+ ${esc(usd(total))}</text>
<text x="70" y="190" font-size="56" font-weight="900" fill="#fff">${rows.length} top-up${rows.length > 1 ? 's' : ''} today</text><text x="1850" y="190" font-size="26" fill="#d8ccff" text-anchor="end">${num(s.topup_comm_pct, 3)}% fee · no 18% GST</text>
<text x="70" y="1055" font-size="22" fill="#d8ccff">Live data via Meta API · ${esc(brand)} records${s.bot_username ? ' · @' + esc(s.bot_username) : ''}</text></svg>`;
  const rad = Math.max(8, Math.round(w * 0.025));
  const mask = Buffer.from(`<svg width="${w}" height="${h}"><rect width="${w}" height="${h}" rx="${rad}" fill="#fff"/></svg>`);
  const fs1 = Math.round(Math.max(15, Math.min(34, w * 0.055))), bh = Math.round(fs1 * 1.7);
  let frames = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" ${FONT}>`, tags = frames;
  const comps: { input: Buffer; left: number; top: number }[] = [];
  for (let i = 0; i < n; i++) {
    const { x, y } = pos(i);
    frames += `<rect x="${x - 3}" y="${y - 3}" width="${w + 6}" height="${h + 6}" rx="${rad + 3}" fill="#fff" fill-opacity="0.18"/>`;
    if (more && i === 29) { tags += `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${rad}" fill="#2a1a52"/><text x="${x + w / 2}" y="${y + h / 2 + fs1 * 0.4}" font-size="${Math.round(fs1 * 1.2)}" font-weight="800" fill="#fff" text-anchor="middle">+ ${more} more</text>`; continue; }
    comps.push({ input: await sharp(imgs[i]).resize({ width: w, height: h, fit: 'cover', position: 'top' }).composite([{ input: mask, blend: 'dest-in' }]).png().toBuffer(), left: x, top: y });
    const t = '+' + usd(rows[i].amount), bw = Math.round(fs1 * 0.9 + t.length * fs1 * 0.62), m = Math.round(fs1 * 0.45);
    const maxCh = Math.max(6, Math.floor((w - bw - 3 * m) / (fs1 * 0.5)) - 1);
    const nm = rows[i].name.length > Math.min(16, maxCh) ? rows[i].name.slice(0, Math.min(16, maxCh) - 1) + '…' : rows[i].name, nw = Math.round(fs1 * 1.1 + nm.length * fs1 * 0.52);
    tags += `<rect x="${x + m}" y="${y + h - bh - m}" width="${nw}" height="${bh}" rx="${bh / 2}" fill="#160b2e" fill-opacity="0.85"/><text x="${x + m + nw / 2}" y="${y + h - m - bh * 0.32}" font-size="${Math.round(fs1 * 0.82)}" font-weight="700" fill="#e9d5ff" text-anchor="middle">${esc(nm)}</text>`;
    tags += `<rect x="${x + w - bw - m}" y="${y + h - bh - m}" width="${bw}" height="${bh}" rx="${bh / 2}" fill="#16a34a"/><text x="${x + w - m - bw / 2}" y="${y + h - m - bh * 0.3}" font-size="${fs1}" font-weight="800" fill="#fff" text-anchor="middle">${esc(t)}</text>`;
  }
  const out = await sharp(Buffer.from(bg)).composite([{ input: Buffer.from(frames + '</svg>'), left: 0, top: 0 }, ...comps, { input: Buffer.from(tags + '</svg>'), left: 0, top: 0 }]).png().toBuffer();
  return sharp(out).png({ compressionLevel: 8 }).toBuffer();
}
/** 9:16 story: the real top-up screenshots as a collage (no button). */
async function storyCollage(rows: Row[], imgs: Buffer[], day: string, logo: string) {
  const sharp = (await import('sharp')).default;
  const s = getSettings();
  const total = rows.reduce((t, r) => t + r.amount, 0), brand = s.brand_name || 'Adsbhai';
  // v163: the fewest columns that still fit → few top-ups = big screenshots (5 → 2 columns), centred in the free space
  const n = rows.length, W = 1080, H = 1920, AREA = 1620 - 480;
  let cols = 6;
  for (let c = 1; c <= 6; c++) { const g = c <= 2 ? 22 : 16, w = Math.floor((960 - (c - 1) * g) / c), h = Math.round(w * 9 / 16); if (Math.ceil(n / c) * (h + g) - g <= AREA) { cols = c; break; } }
  const gx = cols <= 2 ? 22 : 16, gw = Math.floor((960 - (cols - 1) * gx) / cols), gh = Math.round(gw * 9 / 16), maxRows = Math.max(1, Math.floor((AREA + gx) / (gh + gx)));
  const shown = Math.min(n, cols * maxRows);
  const usedRows = Math.ceil(shown / cols), gridH = usedRows * (gh + gx) - gx;
  const x0 = (W - (cols * gw + (cols - 1) * gx)) / 2, y0 = 480 + Math.max(0, Math.round((AREA - gridH) / 2));
  const lastRow = (i: number) => Math.floor(i / cols) === usedRows - 1, inLast = shown - (usedRows - 1) * cols;
  const xOf = (i: number) => x0 + (i % cols) * (gw + gx) + (lastRow(i) ? (cols - inLast) * (gw + gx) / 2 : 0); // last row centred
  const site = siteHost();
  const bg = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" ${FONT}>${bgDefs()}<rect width="${W}" height="${H}" fill="#160b2e"/><rect width="${W}" height="${H}" fill="url(#a)"/>
${logo ? `<image href="${logo}" x="60" y="80" width="56" height="56"/>` : ''}<text x="134" y="122" font-size="34" font-weight="800" fill="#fff">${esc(brand.toUpperCase())}</text>
<rect x="60" y="168" width="440" height="50" rx="25" fill="none" stroke="#22c55e" stroke-width="3"/><text x="280" y="201" font-size="22" font-weight="700" fill="#86efac" text-anchor="middle">● TODAY'S TOP-UPS · ${esc(dayLabel(day).toUpperCase())}</text>
<rect x="560" y="168" width="460" height="50" rx="25" fill="#fff" fill-opacity="0.1" stroke="#c4b5fd" stroke-opacity="0.5"/><text x="790" y="201" font-size="21" font-weight="700" fill="#e9d5ff" text-anchor="middle">● Live data fetched via Meta API</text>
<text x="60" y="320" font-size="62" font-weight="900" fill="#fff">${n} top-up${n > 1 ? 's' : ''} today</text>
<text x="60" y="420" font-size="96" font-weight="900" fill="#86efac">+ ${esc(usd(total))}</text><text x="1020" y="420" font-size="24" fill="#d8ccff" text-anchor="end">${num(s.topup_comm_pct, 3)}% fee · no 18% GST</text>
<text x="540" y="1690" font-size="30" font-weight="700" fill="#d8ccff" text-anchor="middle">${esc(site)}${s.bot_username ? ' · @' + esc(s.bot_username) : ''}</text></svg>`;
  const comps: { input: Buffer; left: number; top: number }[] = [];
  const mask = Buffer.from(`<svg width="${gw}" height="${gh}"><rect width="${gw}" height="${gh}" rx="${cols <= 2 ? 18 : 10}" fill="#fff"/></svg>`);
  for (let i = 0; i < shown; i++) {
    const x = Math.round(xOf(i)), y = Math.round(y0 + Math.floor(i / cols) * (gh + gx));
    comps.push({ input: await sharp(imgs[i]).resize({ width: gw, height: gh, fit: 'cover' }).composite([{ input: mask, blend: 'dest-in' }]).png().toBuffer(), left: x, top: y });
  }
  let ov = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" ${FONT}>`;
  for (let i = 0; i < shown; i++) {
    const x = Math.round(xOf(i)), y = y0 + Math.floor(i / cols) * (gh + gx), t = '+' + usd(rows[i].amount);
    const fs = cols <= 1 ? 40 : cols <= 2 ? 30 : cols <= 3 ? 22 : 17, bh = Math.round(fs * 1.65), bw = Math.round(fs * 0.85 + t.length * fs * 0.64), m = Math.round(fs * 0.4);
    ov += `<rect x="${x + gw - bw - m}" y="${y + gh - bh - m}" width="${bw}" height="${bh}" rx="${bh / 2}" fill="#16a34a"/><text x="${x + gw - m - bw / 2}" y="${y + gh - m - bh * 0.3}" font-size="${fs}" font-weight="800" fill="#fff" text-anchor="middle">${esc(t)}</text>`;
  }
  if (shown < n) ov += `<text x="540" y="1640" font-size="30" font-weight="800" fill="#fff" text-anchor="middle">+ ${n - shown} more top-ups</text>`;
  comps.push({ input: Buffer.from(ov + '</svg>'), left: 0, top: 0 });
  const out = await sharp(Buffer.from(bg)).composite(comps).png().toBuffer();
  return sharp(out).resize({ width: 1080 }).png({ compressionLevel: 8 }).toBuffer();
}

async function tgSend(method: string, fd: FormData) {
  const s = getSettings();
  const r = await fetch(`${process.env.TG_API_BASE || 'https://api.telegram.org'}/bot${s.bot_token}/${method}`, { method: 'POST', body: fd, signal: AbortSignal.timeout(180000) });
  const j = await r.json() as { ok: boolean; description?: string };
  if (!j.ok) throw new Error(j.description || 'Telegram refused it');
  return j;
}
async function album(chat: string, pngs: Buffer[], caption = '') {
  const fd = new FormData();
  fd.append('chat_id', chat);
  fd.append('media', JSON.stringify(pngs.map((_, i) => ({ type: 'photo', media: `attach://p${i}`, ...(i === 0 && caption ? { caption } : {}) }))));
  pngs.forEach((p, i) => fd.append(`p${i}`, new File([new Uint8Array(p)], `topup-${i}.png`, { type: 'image/png' }), `topup-${i}.png`));
  return tgSend('sendMediaGroup', fd);
}
export function digestButtons() {
  const s = getSettings();
  const bot = s.bot_username || '';
  const site = 'https://' + siteHost();
  const b = (text: string, url: string) => ({ text, url });
  return { inline_keyboard: [
    ...(bot ? [[b('💬 Get agency account', `https://t.me/${bot}`), b('👉 Get Premium account', `https://t.me/${bot}?start=premium`)]] : []),
    [...(bot ? [b('💰 Top up now', `https://t.me/${bot}`)] : []), b('🌐 Order on website', /^https?:/.test(site) ? site : 'https://' + site)],
  ] };
}

/** Albums: 10 photos each, the last one = cover + the rest. A round count (10, 20, 30 …) leaves the smallest top-up's photo out. */
export function albumPlan(n: number) {
  const photos = n % 10 === 0 ? n - 1 : n;
  const r = photos % 10;
  const groups: number[][] = [];
  for (let i = 0; i < photos - r; i += 10) groups.push(Array.from({ length: 10 }, (_, k) => i + k));
  return { full: groups, last: Array.from({ length: r }, (_, k) => photos - r + k) };
}

let posting = 0;
/** v163: one post at a time (a 2nd tap / the night timer while it is still posting is refused), and not twice the same day unless asked again. */
export function digestBusy() {
  const b = num(getSettings().meta_digest_busy);
  return posting > 0 || (b > 0 && now() - b < 15 * 60000);
}
export async function postTopupDigest(o: { day?: string; force?: boolean; say?: (t: string) => void } = {}) {
  if (digestBusy()) return { ok: false, error: 'Already posting. Wait a minute and check the channel.' };
  posting++; setSetting('meta_digest_busy', String(now()));
  try { return await postTopupDigest0(o); } finally { posting--; setSetting('meta_digest_busy', ''); }
}
async function postTopupDigest0(o: { day?: string; force?: boolean; say?: (t: string) => void } = {}) {
  const s = getSettings();
  const say = o.say || ((t: string) => console.log('[digest]', t));
  const day = o.day || dayOf(now());
  if (!s.meta_post_chat) return { ok: false, error: 'Set the Telegram channel first (Ad accounts → Profiles → Edit)' };
  const rows = digestRows(day); // v166: since the last post
  if (!rows.length) { say('No top-ups today: nothing posted'); return { ok: true, posted: 0 }; }
  const at = postedAt(day);
  if (at && !o.force) return { ok: false, already: true, error: `Already posted today at ${at}.` };
  const P = await import('./proof');
  const logo = await logoHref();
  say(`Drawing ${rows.length} top-up images`);
  const imgs: Buffer[] = [];
  for (const r of rows) imgs.push(await topupImage(r));
  let cover: Buffer;
  try { cover = await coverShots(rows, imgs, day, logo); } // v164: with the real top-up screenshots
  catch (e) { say('Cover with screenshots: ' + (e as Error).message); cover = await P.render(coverSvg(rows, day, logo), 2560); }
  const plan = albumPlan(rows.length);
  const cap = digestCaption(rows, day);
  for (const g of plan.full) await album(s.meta_post_chat, g.map(i => imgs[i]));
  await album(s.meta_post_chat, [cover, ...plan.last.map(i => imgs[i])], cap);
  const fd = new FormData();
  fd.append('chat_id', s.meta_post_chat);
  fd.append('text', '👇 Top up your ad account or get a new one');
  fd.append('reply_markup', JSON.stringify(digestButtons()));
  await tgSend('sendMessage', fd);
  say(`Posted to the channel: ${rows.length} top-ups`);
  let story: Buffer | null = null;
  try { story = await storyCollage(rows, imgs, day, logo); } catch (e) { say('Story image: ' + (e as Error).message); }
  const U = await import('./userbot');
  if (story && s.meta_story_on !== '0') {
    try { const r = await U.ubPostStory(story, storyCaptionDigest(rows, day), null); say(r.ok ? 'Story posted' : 'Story: ' + r.error); } catch (e) { say('Story: ' + (e as Error).message); }
  }
  try { await U.ubSaveToSelf([{ name: `topups-${day}.png`, data: cover }, ...(story ? [{ name: `topups-${day}-9x16.png`, data: story }] : [])], cap); } catch { /* */ }
  run('INSERT INTO meta_log(act_id, lead_id, kind, note, by, created_at) VALUES(NULL,NULL,?,?,?,?)', 'digest', `${day}: ${rows.length} top-ups posted`, 'system', now());
  if (day === dayOf(now())) markPostedToday(); // v166: the day counts as posted only after a post that went out
  return { ok: true, posted: rows.length };
}

/** Posted by hand today → the automatic post at night does not go again. */
/** v163: when today's post went out (HH:MM, business time), or null. */
export function postedAt(day = dayOf(now())) {
  const l = one<{ created_at: number }>("SELECT created_at FROM meta_log WHERE kind='digest' AND note LIKE ? ORDER BY id DESC LIMIT 1", `${day}:%`);
  return l ? new Date(l.created_at + num(getSettings().tz_offset_min, 330) * 60000).toISOString().slice(11, 16) : null;
}
export function markPostedToday() { setSetting('meta_digest_last', dayOf(now())); }
let running = false;
/** Called every minute by the worker: posts once a day at the set time (India time). */
export async function digestTick() {
  const s = getSettings();
  if (s.meta_digest_on === '0' || !s.meta_post_chat || running) return;
  const t = now(), day = dayOf(t);
  const [hh, mm] = String(s.meta_digest_time || '22:00').split(':').map(x => num(x));
  if (t < dayStart(day) + (hh * 60 + mm) * 60000) return;
  if (s.meta_digest_last === day || digestBusy()) return;
  setSetting('meta_digest_last', day); // claim first: never twice the same day
  running = true;
  try { await postTopupDigest({ day }); } catch (e) { console.warn('[digest]', (e as Error).message); try { await M.alertTeam('⚠️ Daily top-up post failed', (e as Error).message.slice(0, 200)); } catch { /* */ } }
  finally { running = false; }
}
export const _digestTest = { dayOf, dayStart, one, storyCollage, logoHref };
