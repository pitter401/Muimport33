/**
 * Call list: people who filled the form but never messaged on Telegram.
 * After CALL_WAIT they are shared out so someone phones them: Funnel → the manager (or Funnel agents when
 * "Funnel leads to agents" is on), Agency → the Agency agents in turn. Own rotation, so the chat rotation is not touched.
 * They leave the list by themselves once they message on Telegram.
 */
import { all, one, run } from './db';
import { getSettings, setSetting, routeOf, type Route } from './settings';
import { bizAgents, funnelToAgents, managerId } from './crm';
import { pushTo } from './push';
import { now, num } from './util';

export const CALL_WAIT = 10 * 60000;          // give them 10 min to open Telegram first
const CALL_DAYS = 30;
export const CALL_STATES = ['called', 'no_answer', 'interested', 'converted', 'not_interested'] as const; // interested = talked, check later if they buy
export type CallState = (typeof CALL_STATES)[number];

/** SQL: a form-only lead that belongs on the call list. */
export const callSql = (a = 'l', t = now()) =>
  `(${a}.source='form' AND ${a}.tg_chat_id IS NULL AND ${a}.status='new' AND ${a}.created_at<${t - CALL_WAIT} AND ${a}.created_at>${t - CALL_DAYS * 86400000})`;

function pickCaller(biz: Route): number | null {
  if (biz === 'funnel' && !funnelToAgents()) { const m = managerId(); if (m) return m; }
  let rows = bizAgents(biz);
  if (!rows.length && biz === 'premium') { const m = managerId(); if (m) return m; } // Premium: the manager unless agents are tagged
  if (!rows.length && biz === 'funnel') rows = bizAgents('agency');
  if (!rows.length) return managerId();
  const key = biz === 'funnel' ? 'rr_call_f' : biz === 'premium' ? 'rr_call_p' : 'rr_call';
  const last = num((getSettings() as Record<string, string>)[key]);
  const next = rows.find(a => a.id > last) || rows[0];
  setSetting(key as 'rr_call', String(next.id));
  return next.id;
}

/** Give every waiting form-only lead a caller (also when their caller was removed). Returns how many were given out. */
export function assignCalls() {
  const rows = all<{ id: number; name: string | null; service: string | null; line: string | null }>(
    `SELECT l.id, l.name, l.service, l.line FROM leads l WHERE ${callSql('l')} AND (l.call_agent_id IS NULL OR l.call_agent_id NOT IN (SELECT id FROM agents WHERE deleted=0)) ORDER BY l.id LIMIT 200`);
  for (const l of rows) {
    const who = pickCaller(routeOf(l));
    if (!who) continue;
    run('UPDATE leads SET call_agent_id=? WHERE id=?', who, l.id);
    void pushTo('agent', who, '📞 New lead to call', `${l.name || 'Lead #' + l.id} filled the form but didn’t message. Give them a call.`, {}).catch(() => {});
  }
  return rows.length;
}

/** Mark the call result ('' = undo). */
export function markCall(leadId: number, state: string, note: string, by: string) {
  const st = (CALL_STATES as readonly string[]).includes(state) ? state : null;
  run('UPDATE leads SET call_state=?, call_at=?, call_by=?, call_note=? WHERE id=?', st, st ? now() : null, st ? by : null, st ? (note || '').slice(0, 300) || null : null, leadId);
  return one('SELECT id, call_state, call_at, call_by, call_note FROM leads WHERE id=?', leadId);
}

/** Hot leads: they really talked with us on Telegram, then went quiet — our message is the last one, their last message is
 *  6 h – 14 days old. Someone should call them. "Really talked" = AFTER our first message (welcome / warm-up / agent)
 *  they answered at least twice, or once with a real sentence (4+ words), or with a voice note / photo. Their first message
 *  (the automatic one from the landing page) and replies like "?", "ok", "hmm" don't count.
 *  Leaves the list when they write again, are sold / dead, or are marked Converted / Not interested. */
export const HOT_QUIET_H = 6, HOT_DAYS = 14;
const realReply = (a: string, extra = '') =>
  `SELECT 1 FROM messages hm WHERE hm.lead_id=${a}.id AND hm.dir='in'` +
  ` AND hm.id>(SELECT COALESCE(MIN(o.id), 9e18) FROM messages o WHERE o.lead_id=${a}.id AND o.dir='out')` +
  ` AND (hm.file_type IN ('voice','audio','photo','video','video_note') OR (length(trim(COALESCE(hm.text,'')))>=2 AND lower(trim(hm.text)) NOT IN ('??','???','..','...','ok','okk','k','hmm','hm','hmmm','ji','haa','han','haan','hi','hii','hello','👍')))${extra}`;
const talked = (a: string) =>
  `((SELECT COUNT(*) FROM (${realReply(a)}))>=2 OR EXISTS(${realReply(a, ` AND (length(trim(hm.text))-length(replace(trim(hm.text),' ','')))>=3`)}) OR EXISTS(${realReply(a, ` AND hm.file_type IN ('voice','audio','photo','video','video_note')`)}))`;
export const hotSql = (a = 'l', t = now()) =>
  `(${a}.tg_chat_id IS NOT NULL AND ${a}.status='active' AND ${a}.last_in_at<${t - HOT_QUIET_H * 3600000} AND ${a}.last_in_at>${t - HOT_DAYS * 86400000}` +
  ` AND ${talked(a)}` +
  ` AND (SELECT hm2.dir FROM messages hm2 WHERE hm2.lead_id=${a}.id AND hm2.dir!='sys' ORDER BY hm2.created_at DESC, hm2.id DESC LIMIT 1)='out'` +
  ` AND COALESCE(${a}.call_state,'') NOT IN ('converted','not_interested'))`;

/** Waiting to be called (not called yet, or "no answer" → try again). */
export const callTodoSql = (a = 'l') => `(${callSql(a)} AND (${a}.call_state IS NULL OR ${a}.call_state='no_answer'))`;
