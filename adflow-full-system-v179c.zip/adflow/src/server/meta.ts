/**
 * Our Meta Business Managers and their ad accounts (Admin → Ad accounts, Manager app → Ad accounts).
 *
 *  - Each BM: System User token (+ optional App Secret, proxy). Read every `meta_sync_min` minutes by the worker.
 *  - Accounts: free → assigned (shared to the client's BM, or the client invited by email with only this account)
 *    → unshare: access removed, client's campaigns deleted, balance left saved as the client's credit, spend reset.
 *  - Clients never get MANAGE: only ADVERTISE + ANALYZE (no card, no billing, no sharing to other BMs).
 *  - Top-up = spend limit raised by (paid − fee). Amounts from Meta are in cents.
 *  - Disabled account: balance left → client's credit, added automatically to the next account they get.
 *  - Agents ask (Requests). Auto-approved when the agent has the permission and paid by crypto link; else the manager approves.
 *  - If Meta blocks the BM's API (token), the request becomes "Do manually" and the manager is told.
 */
import { one, all, run, tx } from './db';
import { getSettings, setSetting, type Settings } from './settings';
import { now, num, money, HttpError, dayRange, localDate } from './util';
import { graph, graphAll, enc, dec, MetaError, parseProxy, maskProxy, type Creds } from './metagraph';
import { addMsg, agentById, notifyAgent, displayName, leadById, recordSale, addTopup, topupFee, type Lead } from './crm';
import { tellClient, clientText } from './clientmsg';
import { managers, saveLeadAccounts } from './shop';
import { pushTo } from './push';

/** v157: name of a client's account: "Adsbhai {our BM} X {client} {iX} {client's BM name}" (e.g. Adsbhai Krishna Industries X Gabbar IX6 Diamond247_Original). */
export function clientAcctName(ourBm: string | null | undefined, client: string, ix: string | null | undefined, biz: string | null | undefined) {
  return [getSettings().brand_name || 'Adsbhai', (ourBm || '').slice(0, 30), 'X', client.slice(0, 30), ix || '', biz || ''].filter(Boolean).join(' ').replace(/\s+/g, ' ').trim().slice(0, 100);
}
/** Meta #3: this app may not assign / remove partners. */
export const is3 = (e: unknown) => (e instanceof MetaError && e.code === 3) || /\(#3\)|capability to make this API call/i.test((e as Error)?.message || '');
export type Bm = {
  id: number; bm_id: string; name: string | null; label: string | null; token_enc: string; secret_enc: string | null; proxy_enc: string | null;
  su_id: string | null; su_name: string | null; verification: string | null; created_time: number | null; acct_limit: number | null; status: string; error: string | null;
  error_at: number | null; alerted: number; synced_at: number | null; deleted: number; created_at: number; profile_id?: number | null; verified_since?: string | null;
};
export type Acct = { card_set?: string | null; card_guess?: number | null;
  act_id: string; bm_id: string; no: number; name: string | null; status: number; disable_reason: number; currency: string | null; tz: string | null; created_time: number | null;
  spent: number; cap: number; today: number; card: string | null; state: string; lead_id: number | null; share_mode: string | null; client_bm: string | null; client_email: string | null; extra_bms?: string | null;
  invite_id: string | null; buser_id: string | null; assigned_at: number | null; disabled_at: number | null; low_sent: number; busy: number; step: string | null; err: string | null;
  synced_at: number | null; seen_at: number | null; locked?: number; repl_of?: string | null; post_wait?: number | null; post_ready?: number | null; post_mode?: string | null;
  dsl?: number | null; bill_threshold?: number | null; base_name?: string | null; partner_name?: string | null; biz_name?: string | null;
};
export type Req = {
  id: number; kind: 'account' | 'topup' | 'replace'; lead_id: number; agent_id: number | null; act_id: string | null; tier: string | null; mode: string | null; client_bm: string | null; client_email: string | null;
  paid: number | null; fee: number | null; amount: number | null; method: string; pay_code: string | null; note: string | null; status: string; error: string | null;
  created_at: number; done_at: number | null; done_by: string | null; biz_name?: string | null; manual?: number; job_id?: number | null;
  add_paid?: number | null; add_fee?: number | null; add_amount?: number | null; rec_at?: number | null; old_act?: string | null; ext?: number | null; by_role?: string | null;
};
export type Actor = { role: 'admin' | 'manager' | 'agent'; id: number | null; name: string };

const TASKS = ['ADVERTISE', 'ANALYZE', 'DRAFT']; // Manage campaigns + View performance + Creative Hub mockups. Never MANAGE: the client can't add a card, top up himself or share the account on
const DISABLED = [2, 100, 101];
export const STATUS: Record<number, string> = { 1: 'Active', 2: 'Disabled', 3: 'Unsettled', 7: 'Risk review', 8: 'Pending settlement', 9: 'Grace period', 100: 'Closing', 101: 'Closed' };
/** v166: why Meta disabled an ad account (AdAccount.disable_reason) in plain words */
export const DISABLE_REASON: Record<number, string> = {
  1: 'Ads integrity policy', 2: 'Intellectual property review', 3: 'Payment risk (card problem)', 4: 'Shut down (grey account)', 5: 'AFC review',
  6: 'Business integrity review', 7: 'Closed permanently', 8: 'Unused reseller account', 9: 'Unused account', 10: 'Umbrella ad account',
  11: 'Business Manager integrity policy', 12: 'Misrepresented ad account', 13: 'Removed from legal entity', 14: 'Thread review', 15: 'Compromised (hacked) account',
};
export const disableText = (status: number, reason: number) => (!DISABLED.includes(status) && status !== 7) ? null : (reason ? DISABLE_REASON[reason] || `Reason code ${reason}` : null);
/** v166: Meta could not charge the card: unsettled / pending settlement / grace period, or disabled for payment risk */
export const payFailed = (status: number, reason: number) => [3, 8, 9].includes(status) || (DISABLED.includes(status) && reason === 3);
const usd = (n: number) => '$' + money(n).toFixed(2).replace(/\.00$/, '');
const cents = (usdV: number) => Math.round(num(usdV) * 100);
export const cleanAct = (v: unknown) => String(v || '').trim().replace(/^act_/i, '').replace(/\D/g, '');
const by = (a: Actor) => `${a.role}${a.id ? ':' + a.id : ''}`;
export const metaEnabled = () => getSettings().meta_enabled !== '0';
export const metaOn = () => metaEnabled() && !!one("SELECT 1 FROM meta_bms WHERE deleted=0 LIMIT 1");
/** v160: BMs are set up (the master switch may be OFF): chats still show the client's accounts and top-ups go to the manager. */
export const metaHas = () => !!one("SELECT 1 FROM meta_bms WHERE deleted=0 LIMIT 1");
/** v153: a BM with a 'verified since' date typed by the admin counts as verified everywhere. */
export const bmVer = (b: { verification?: string | null; verified_since?: string | null } | undefined | null) => (b?.verified_since ? 'verified' : b?.verification ?? null);
export const tierOf = (v: string | null) => v === 'verified' ? 'verified' : /^pending/.test(v || '') ? 'review' : 'unverified';
export const TIER_LABEL: Record<string, string> = { verified: 'Verified', review: 'In review', unverified: 'Unverified', any: 'Any' };
// `locked` = shared with no balance yet: the tiny lock limit is ours, not the client's money
const remaining = (a: Pick<Acct, 'cap' | 'spent'> & { locked?: number }) => (a.locked ? 0 : a.cap > 0 ? Math.max(0, a.cap - a.spent) : 0);
export const emailInvitesOn = () => getSettings().meta_email_invites === '1';

export const bmById = (id: unknown) => one<Bm>('SELECT * FROM meta_bms WHERE id=? AND deleted=0', num(id));
export const bmOf = (bmId: string) => one<Bm>('SELECT * FROM meta_bms WHERE bm_id=? AND deleted=0', bmId);
export const acctOf = (act: unknown) => one<Acct>('SELECT * FROM meta_accounts WHERE act_id=?', cleanAct(act));
/** v152: a BM that came from a profile uses that profile's token + the one iProxy line (never the server IP). */
export type Profile = { id: number; name: string; ix: string | null; app_id: string | null; secret_enc: string | null; token_enc: string | null; token_exp: number | null;
  fb_name: string | null; status: string; error: string | null; last_ip: string | null; last_sync: number | null; alerted_at: number | null; deleted: number; created_at: number };
export const profileById = (id: unknown) => one<Profile>('SELECT * FROM meta_profiles WHERE id=? AND deleted=0', num(id));
/** review166: a token BM with no proxy of its own → the ad-account (iProxy) line, else the Comments / Ads-data proxy (as camps.ts) — never the server IP */
const fallbackProxy = () => { const s = getSettings(); return String(s.mq_proxy || '').trim() || String(s.cm_proxy || '').trim(); };
const creds = (b: Bm): Creds => {
  if (b.profile_id) {
    const p = profileById(b.profile_id);
    const proxy = getSettings().mq_proxy;
    if (!p) throw new MetaError('This BM’s profile was removed', 0, 0, 'token');
    // only inside the queue (after the IP change for THIS profile)
    if (!JOB.active) throw new MetaError('Profile accounts work only through the queue (IP change first)', 0, 0, 'net');
    if (JOB.profileId && JOB.profileId !== b.profile_id) throw new Error('This account is on another profile (its IP was not changed). Run it again.');
    if (!proxy) throw new MetaError('Add the iProxy proxy first (Ad accounts → Profiles → iProxy line → Edit). Meta is never called from the server IP.', 0, 0, 'net');
    return { token: dec(p.token_enc), secret: dec(p.secret_enc) || undefined, proxy };
  }
  // v166: a token BM with no proxy of its own → the ad-account proxy; none at all → never called (not from the server IP)
  const proxy = dec(b.proxy_enc) || fallbackProxy();
  if (!proxy) throw new MetaError('Add a proxy for this BM (Ad accounts → BMs → Edit) or the iProxy line (Profiles). Meta is never called from the server IP.', 0, 0, 'net');
  return { token: dec(b.token_enc), secret: dec(b.secret_enc) || undefined, proxy };
};
/** v152: profile BMs work only inside the queue (after the IP change). The worker sets this while it runs a job. */
export const JOB = { active: false, profileId: 0, step: (_t: string) => { /* set by the queue */ } };
const viaQueue = (bm: Bm | undefined) => !!bm?.profile_id && !JOB.active;
function enqueueFor(bm: Bm, kind: string, ref: string, payload: Record<string, unknown>, actor: Actor, prio = 3) {
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const Q = require('./metaq') as typeof import('./metaq');
  return Q.enqueue(bm.profile_id!, kind, ref, payload, actor, prio);
}
/** Category from the Meta daily limit the admin typed: premium (≥ line) / std ($25) / null (not set yet). */
export const catOf = (a: { dsl?: number | null }) => (a.dsl == null || !(a.dsl > 0) ? null : a.dsl >= num(getSettings().meta_cat_usd, 100) ? 'premium' : 'std');
export const CAT_LABEL: Record<string, string> = { premium: 'Premium', std: '$25 account' };
const bmName = (b: Bm | undefined) => (b ? b.label ? `${b.name || b.bm_id} (${b.label})` : b.name || b.bm_id : 'BM');
const acctName = (a: Pick<Acct, 'name' | 'no' | 'act_id'>) => a.name || `#${a.no} act_${a.act_id}`;

function log(kind: string, a: { act_id?: string | null; lead_id?: number | null; agent_id?: number | null; paid?: number | null; fee?: number | null; amount?: number | null; note?: string; by?: string }) {
  const id = Number(run('INSERT INTO meta_log(act_id, lead_id, agent_id, kind, paid, fee, amount, note, by, created_at) VALUES(?,?,?,?,?,?,?,?,?,?)',
    a.act_id ?? null, a.lead_id ?? null, a.agent_id ?? null, kind, a.paid ?? null, a.fee ?? null, a.amount ?? null, a.note ?? null, a.by ?? null, now()).lastInsertRowid);
  if (kind === 'topup') { try { crmTopupFromLog(id); } catch (e) { console.warn('[meta] top-up record', (e as Error).message); } } // v165
  return id;
}

/** v165: every top-up put on a client's account (request, by hand, with the share, admin or manager) is in Sales → top-ups once, with our fee.
 *  Already saved there (chat "Add top-up", a paid link, a WhatsApp top-up) → that row is linked, never a second one. Website top-ups have their own table. */
export function crmTopupFromLog(id: number) {
  const l = one<{ id: number; act_id: string | null; lead_id: number | null; agent_id: number | null; kind: string; fee: number | null; amount: number | null; note: string | null; created_at: number }>('SELECT * FROM meta_log WHERE id=?', id);
  if (!l || l.kind !== 'topup' || !(num(l.amount) > 0) || !l.lead_id || /^website /i.test(l.note || '')) return null;
  if (one('SELECT 1 FROM topups WHERE meta_log_id=?', id)) return null;
  const lead = leadById(l.lead_id);
  if (!lead) return null;
  const amount = money(l.amount), H = 3600_000, act = l.act_id || '';
  // a website order's top-up done by hand → it is in the website's records already
  if (act && one("SELECT 1 FROM web_topups WHERE act_id=? AND ABS(amount-?)<0.01 AND status IN ('paid','done') AND created_at BETWEEN ? AND ?", act, amount, l.created_at - 24 * H, l.created_at + 24 * H)) return null;
  // the same money already saved: the chat's "Add top-up" / a paid link (not tied to another account's request), or a WhatsApp top-up naming this account
  const same = one<{ id: number }>(`SELECT t.id FROM topups t WHERE t.meta_log_id IS NULL AND ABS(t.amount-?)<0.01 AND (
      (t.lead_id=? AND t.created_at BETWEEN ? AND ? AND (t.meta_req_id IS NULL OR EXISTS(SELECT 1 FROM meta_requests q WHERE q.id=t.meta_req_id AND COALESCE(q.ext,0)=0 AND q.act_id=?)))
      OR (t.lead_id IS NULL AND COALESCE(t.wa,0)=1 AND ?!='' AND t.note LIKE '%act_' || ? || '%' AND t.created_at BETWEEN ? AND ?)) ORDER BY ABS(t.created_at-?) LIMIT 1`,
    amount, lead.id, l.created_at - 24 * H, l.created_at + 24 * H, act, act, act, l.created_at - 6 * H, l.created_at + 6 * H, l.created_at);
  if (same) { run('UPDATE topups SET meta_log_id=? WHERE id=?', id, same.id); return { linked: same.id }; }
  const fee = l.fee != null ? money(l.fee) : money(amount * topupFee(lead, amount).pct / 100); // the fee always goes on top (v166: an explicit 0 stays 0; NULL = not given)
  const agentId = lead.agent_id ?? l.agent_id ?? null; // stats: the chat's agent (as the chat's "Add top-up"); agents never earn on top-ups
  const r = run('INSERT INTO topups(lead_id, agent_id, amount, commission, note, created_at, owner_agent_id, meta_log_id) VALUES(?,?,?,?,?,?,?,?)',
    lead.id, agentId, amount, fee, `Ad account act_${l.act_id || ''} · ${l.note || 'top-up'}`.slice(0, 200), l.created_at, lead.agent_id ?? null, id);
  return { added: Number(r.lastInsertRowid) };
}
/** v165: once — the top-ups done before (by hand, with the share, by the admin) go into Sales → top-ups. */
export function backfillCrmTopups() {
  if (getSettings().v165_topups === '1') return 0;
  let n = 0;
  // only the ones that never got a Sales row: done by the admin, or by hand on the account (agent / manager requests were saved before)
  for (const l of all<{ id: number }>("SELECT id FROM meta_log WHERE kind='topup' AND amount>0 AND lead_id IS NOT NULL AND (LOWER(COALESCE(by,''))='admin' OR note='done by hand') ORDER BY id")) { try { if (crmTopupFromLog(l.id)?.added) n++; } catch { /* next */ } }
  setSetting('v165_topups', '1');
  if (n) console.log(`[meta] v165: ${n} earlier top-ups saved in Sales`);
  return n;
}

/** Tell the managers (Telegram + app push) and the admin (push). */
export async function alertTeam(title: string, body: string, leadId: number | null = null) {
  for (const m of managers()) { try { await notifyAgent(agentById(m.id), `${title}\n${body}`, leadId, { title, body }); } catch { /* ignore */ } }
  void pushTo('admin', null, title, body, leadId ? { lead_id: String(leadId) } : {});
}

/* ======================= BMs ======================= */
export async function addBm(b: Record<string, unknown>) {
  const token = String(b.token || '').trim();
  const bmId = String(b.bm_id || '').replace(/\D/g, '');
  if (token.length < 30) throw new HttpError(400, 'Paste the System User token (starts with EAA…)');
  if (bmId.length < 8) throw new HttpError(400, 'Enter the Business ID (Business settings → Business info)');
  const proxy = String(b.proxy || '').trim();
  try { parseProxy(proxy); } catch (e) { throw new HttpError(400, (e as Error).message); }
  const mqp = fallbackProxy();
  if (!proxy && !mqp) throw new HttpError(400, 'Add the proxy for this BM — Meta is never called from the server IP'); // v166
  const secret = String(b.secret || '').trim();
  const c: Creds = { token, secret: secret || undefined, proxy: proxy || mqp };
  let me: { id: string; name: string }, info: { id: string; name: string; verification_status?: string; created_time?: string };
  try {
    me = await graph(c, 'GET', 'me', { fields: 'id,name' });
    info = await graph(c, 'GET', bmId, { fields: 'id,name,verification_status,created_time' });
  } catch (e) { throw new HttpError(400, `Meta: ${(e as Error).message}`); }
  const ex = one<Bm>('SELECT * FROM meta_bms WHERE bm_id=?', bmId);
  const label = String(b.label || '').trim().slice(0, 60) || null;
  const limit = num(b.acct_limit) > 0 ? Math.floor(num(b.acct_limit)) : null;
  if (ex) {
    run("UPDATE meta_bms SET token_enc=?, secret_enc=?, proxy_enc=?, su_id=?, su_name=?, name=?, verification=?, label=COALESCE(?, label), acct_limit=COALESCE(?, acct_limit), status='ok', error=NULL, alerted=0, deleted=0 WHERE id=?",
      enc(token), enc(secret), enc(proxy), me.id, me.name, info.name, info.verification_status || null, label, limit, ex.id);
  } else {
    run("INSERT INTO meta_bms(bm_id, name, label, token_enc, secret_enc, proxy_enc, su_id, su_name, verification, created_time, acct_limit, status, created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,'ok',?)",
      bmId, info.name, label, enc(token), enc(secret), enc(proxy), me.id, me.name, info.verification_status || null, info.created_time ? Date.parse(info.created_time) : null, limit, now());
  }
  const bm = bmOf(bmId)!;
  await syncBm(bm.id);
  return { ok: true, bm: pubBm(bmById(bm.id)!) };
}

export function updateBm(id: unknown, b: Record<string, unknown>) {
  const bm = bmById(id);
  if (!bm) throw new HttpError(404, 'BM not found');
  if (b.label !== undefined) run('UPDATE meta_bms SET label=? WHERE id=?', String(b.label || '').trim().slice(0, 60) || null, bm.id);
  if (b.acct_limit !== undefined) run('UPDATE meta_bms SET acct_limit=? WHERE id=?', num(b.acct_limit) > 0 ? Math.floor(num(b.acct_limit)) : null, bm.id);
  if (b.proxy !== undefined) {
    const p = String(b.proxy || '').trim();
    try { parseProxy(p); } catch (e) { throw new HttpError(400, (e as Error).message); }
    if (!p && !bm.profile_id && !fallbackProxy()) throw new HttpError(400, 'Add the proxy for this BM — Meta is never called from the server IP'); // v166
    run('UPDATE meta_bms SET proxy_enc=? WHERE id=?', enc(p), bm.id);
  }
  if (b.secret !== undefined) run('UPDATE meta_bms SET secret_enc=? WHERE id=?', enc(String(b.secret || '').trim()), bm.id);
  if (b.verified_since !== undefined) {
    const v = String(b.verified_since || '').trim();
    if (v && !/^\d{4}-\d{2}-\d{2}$/.test(v)) throw new HttpError(400, 'Pick the verified date');
    run('UPDATE meta_bms SET verified_since=? WHERE id=?', v || null, bm.id);
  }
  return { ok: true };
}
export function deleteBm(id: unknown) {
  const bm = bmById(id);
  if (!bm) throw new HttpError(404, 'BM not found');
  const used = one<{ n: number }>("SELECT COUNT(*) n FROM meta_accounts WHERE bm_id=? AND state IN ('assigned','invited')", bm.bm_id)!.n;
  if (used) throw new HttpError(400, `${used} account${used > 1 ? 's are' : ' is'} still with clients. Unshare first.`);
  run("UPDATE meta_bms SET deleted=1, token_enc='', secret_enc='', proxy_enc='' WHERE id=?", bm.id);
  run("UPDATE meta_accounts SET state='gone' WHERE bm_id=?", bm.bm_id);
  return { ok: true };
}

/** BM banned / lost: every client account on it → balance (last read) saved as the client's credit, account marked disabled. */
export async function banBm(id: unknown, actor: Actor) {
  const bm = bmById(id);
  if (!bm) throw new HttpError(404, 'BM not found');
  const accts = all<Acct>("SELECT * FROM meta_accounts WHERE bm_id=? AND state IN ('assigned','invited','free')", bm.bm_id);
  let credit = 0, clients = 0;
  for (const a of accts) {
    if (a.state === 'free') { run("UPDATE meta_accounts SET state='disabled', disabled_at=? WHERE act_id=?", now(), a.act_id); continue; }
    const left = remaining(a) / 100;
    clients++; credit += left;
    tx(() => {
      run("UPDATE meta_accounts SET state='disabled', disabled_at=? WHERE act_id=?", now(), a.act_id);
      if (a.lead_id && left > 0) run("INSERT INTO meta_credits(lead_id, amount, act_id, reason, status, created_at) VALUES(?,?,?,'bm_banned','open',?)", a.lead_id, money(left), a.act_id, now());
      log('disabled', { act_id: a.act_id, lead_id: a.lead_id, amount: money(left), note: 'BM banned', by: by(actor) });
    });
    const lead = a.lead_id ? leadById(a.lead_id) : undefined;
    if (lead) {
      addMsg(lead, { dir: 'sys', sender: 'system', text: `⛔ BM of ${acctName(a)} was banned. The balance left was saved as this client's credit for the next account.` });
      void notifyAgent(agentById(lead.agent_id), `⛔ ${displayName(lead)}: the BM of act_${a.act_id} was banned. The balance was saved as credit. Give a new account.`, lead.id, { title: '⛔ BM banned', body: displayName(lead) });
    }
  }
  run("UPDATE meta_bms SET status='banned', error='Marked banned' WHERE id=?", bm.id);
  return { ok: true, clients, credit: money(credit) };
}

async function bmFailed(bm: Bm, e: unknown) {
  const me = e instanceof MetaError ? e : new MetaError((e as Error).message || 'Error', 0, 0, 'net');
  const blocked = me.kind === 'token' || me.kind === 'perm';
  if (bm.status === 'banned') { run('UPDATE meta_bms SET error=?, error_at=? WHERE id=?', me.message.slice(0, 300), now(), bm.id); return me; }
  run('UPDATE meta_bms SET status=?, error=?, error_at=? WHERE id=?', blocked ? 'blocked' : 'error', me.message.slice(0, 300), now(), bm.id);
  if (blocked && !bm.alerted) {
    run('UPDATE meta_bms SET alerted=1 WHERE id=?', bm.id);
    const onIt = all<Acct>("SELECT * FROM meta_accounts WHERE bm_id=? AND state IN ('assigned','invited')", bm.bm_id);
    const who = onIt.length ? `\n${onIt.length} client account${onIt.length > 1 ? 's' : ''} on it: ${onIt.slice(0, 8).map(a => `${acctName(a)} → ${a.lead_id ? displayName(leadById(a.lead_id) || {}) : '?'}`).join(', ')}${onIt.length > 8 ? '…' : ''}` : '';
    // v155 profile BMs: Meta does not say "this BM is banned" in the API → say plainly that it is not sure and what to check
    if (bm.profile_id) {
      const p = profileById(bm.profile_id);
      await alertTeam(`❓ Check ${bmName(bm)} (not sure what happened)`, `Meta refused to read this BM: ${me.message.slice(0, 160)}${who}\nIt can be: the FB profile ${p?.ix || p?.name || ''} got a checkpoint / logged out, the token ended, or the BM was restricted / banned. Open the profile in iX and check Business Settings.\nIf the BM is really banned: Ad accounts → BMs → Mark banned (clients' balance → credit). If only the token is gone: Profiles → New token.`);
      return me;
    }
    await alertTeam(`🔑 API blocked: ${bmName(bm)}`, `Meta: ${me.message.slice(0, 160)}${who}\nIf the BM itself is banned: Ad accounts → BMs → Mark banned (moves the clients' balance to credit). Otherwise make a new System User token for this BM and paste it in Ad accounts → BMs → ${bm.name || bm.bm_id} → Update token. Until then top-ups and shares on this BM must be done by hand.`);
  }
  return me;
}

const ACC_FIELDS = 'id,name,account_status,disable_reason,currency,timezone_name,created_time,amount_spent,spend_cap,funding_source_details,balance'; // v166: balance = bill amount due

export async function syncBm(id: number, actor: Actor = { role: 'admin', id: null, name: 'Admin' }) {
  const bm = bmById(id);
  if (!bm) return { ok: false };
  if (viaQueue(bm)) return { ok: true, queued: true, job: enqueueFor(bm, 'sync', String(bm.profile_id), {}, actor, 4) };
  const start = now();
  try {
    const c = creds(bm); // v166: inside the try — no proxy = this BM shows the error, the others still sync
    const info = await graph(c, 'GET', bm.bm_id, { fields: 'id,name,verification_status,created_time' });
    run('UPDATE meta_bms SET name=?, verification=?, created_time=COALESCE(created_time, ?) WHERE id=?', info.name, info.verification_status || null, info.created_time ? Date.parse(info.created_time) : null, bm.id);
    let rows: any[];
    try { rows = await graphAll(c, `${bm.bm_id}/owned_ad_accounts`, { fields: ACC_FIELDS + ',insights.date_preset(today){spend}', limit: 100 }); }
    catch (e) { if (e instanceof MetaError && (e.kind === 'token' || e.kind === 'perm')) throw e; rows = await graphAll(c, `${bm.bm_id}/owned_ad_accounts`, { fields: ACC_FIELDS, limit: 100 }); }
    for (const r of rows) await upsertAcct(bm, r, c);
    run("UPDATE meta_accounts SET state='gone' WHERE bm_id=? AND (seen_at IS NULL OR seen_at<?) AND state!='gone' AND state NOT IN ('assigned','invited')", bm.bm_id, start);
    try { await checkInvites(bm); } catch (e) { console.warn('[meta] invites', bm.bm_id, (e as Error).message); }
    run("UPDATE meta_bms SET status='ok', error=NULL, alerted=0, synced_at=? WHERE id=?", now(), bm.id);
    // v155: every ad account on the BM disabled by Meta → the BM itself is very likely restricted / banned (Meta says so only for the accounts)
    if (bm.profile_id && rows.length > 0 && rows.every(r => DISABLED.includes(num(r.account_status, 1))) && !one("SELECT 1 FROM meta_log WHERE kind='bm_alldis' AND note=? AND created_at>?", bm.bm_id, now() - 86400000)) {
      run("INSERT INTO meta_log(act_id, lead_id, kind, note, by, created_at) VALUES(NULL,NULL,'bm_alldis',?, 'system', ?)", bm.bm_id, now());
      await alertTeam(`⛔ ${bmName(bm)}: all ${rows.length} ad accounts disabled by Meta (sure)`, `Meta says every ad account on this BM is disabled, so the BM is very likely restricted or banned. Check Business Settings → Account quality. If the BM is banned: Ad accounts → BMs → Mark banned (clients' balance → credit).`);
    }
    return { ok: true, accounts: rows.length };
  } catch (e) {
    const me = await bmFailed(bm, e);
    run('UPDATE meta_bms SET synced_at=? WHERE id=?', now(), bm.id);
    return { ok: false, error: me.message };
  }
}

/** One account read from Meta: save it and react to changes (disabled, low balance, card spend). */
async function upsertAcct(bm: Bm, r: any, c?: Creds) {
  const s = getSettings();
  const act = cleanAct(r.id);
  const prev = acctOf(act);
  const spent = Math.round(num(r.amount_spent)), cap = Math.round(num(r.spend_cap));
  const today = money(r.insights?.data?.[0]?.spend);
  // v165: a card from the business portfolio comes without its number (only "a card is on it") → the card the admin set, else the BM's usual card
  const real = r.funding_source_details?.display_string || null;
  const hasCard = !real && !!r.funding_source_details && num(r.funding_source_details.type) === 1;
  const own = prev?.card && !prev.card_guess && !prev.card_set ? prev.card : null; // the account showed its own real card before
  const guess = hasCard && !prev?.card_set && !own ? one<{ card: string }>("SELECT card FROM meta_accounts WHERE bm_id=? AND act_id!=? AND card IS NOT NULL AND COALESCE(card_guess,0)=0 AND state!='gone' GROUP BY card ORDER BY COUNT(*) DESC LIMIT 1", bm.bm_id, act)?.card || null : null;
  const card = real || (hasCard ? prev?.card_set || own || guess : prev?.card_set || null);
  if (real && prev?.card_set) run('UPDATE meta_accounts SET card_set=NULL WHERE act_id=?', act); // Meta sends the number now
  const cardGuess = !real && !prev?.card_set && !!guess ? 1 : 0;
  const status = num(r.account_status, 1);
  const t = now();
  // v170 (owner): an account removed from the system stays out — sync only notes it was seen; no alerts, no state change
  if (prev && (prev as Acct & { removed_at?: number | null }).removed_at) { run('UPDATE meta_accounts SET synced_at=?, seen_at=? WHERE act_id=?', t, t, act); return; }
  if (card) run('INSERT OR IGNORE INTO meta_cards(card, used_since) VALUES(?,0)', card);
  if (!prev) {
    const no = (one<{ m: number | null }>('SELECT MAX(no) m FROM meta_accounts')!.m || 0) + 1;
    run(`INSERT INTO meta_accounts(act_id, bm_id, no, name, status, disable_reason, currency, tz, created_time, spent, cap, today, card, state, synced_at, seen_at)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, act, bm.bm_id, no, r.name || null, status, num(r.disable_reason), r.currency || null, r.timezone_name || null,
      r.created_time ? Date.parse(r.created_time) : null, spent, cap, today, card, DISABLED.includes(status) ? 'disabled' : 'free', t, t);
    if (cardGuess) run('UPDATE meta_accounts SET card_guess=1 WHERE act_id=?', act); // v165
    if (payFailed(status, num(r.disable_reason))) run('UPDATE meta_accounts SET pay_due=?, pay_fail_at=? WHERE act_id=?', r.balance != null ? Math.max(0, Math.round(num(r.balance))) : null, t, act); // v166
    if (s.meta_rename_new === '1') { try { await renameAcct(act, null); } catch { /* next time */ } }
    return;
  }
  // card spend since the manager last entered the card balance
  if (card && prev.card === card && spent > prev.spent) run('UPDATE meta_cards SET used_since=used_since+? WHERE card=?', spent - prev.spent, card);
  run(`UPDATE meta_accounts SET bm_id=?, name=?, status=?, disable_reason=?, currency=?, tz=?, created_time=COALESCE(?, created_time), spent=?, cap=?, today=?, card=?, synced_at=?, seen_at=?,
    state=CASE WHEN state='gone' THEN 'free' ELSE state END WHERE act_id=?`,
    bm.bm_id, r.name || null, status, num(r.disable_reason), r.currency || null, r.timezone_name || null, r.created_time ? Date.parse(r.created_time) : null, spent, cap, today, card, t, t, act);
  run('UPDATE meta_accounts SET card_guess=? WHERE act_id=?', cardGuess, act); // v165
  if (prev.state === 'free' && !prev.step && prev.err) run('UPDATE meta_accounts SET err=NULL WHERE act_id=?', act); // v173: an old error from a share that never happened clears on a good sync
  // v166: payment failed (Meta could not charge our card) → show it with the amount due, tell the team once
  const reason = num(r.disable_reason);
  const due = r.balance != null ? Math.max(0, Math.round(num(r.balance))) : null;
  if (payFailed(status, reason)) {
    run('UPDATE meta_accounts SET pay_due=? WHERE act_id=?', due, act);
    // review166: claimed in one UPDATE (two syncs at once — tick + "Sync" tap — never alert twice)
    const first = run('UPDATE meta_accounts SET pay_fail_at=? WHERE act_id=? AND pay_fail_at IS NULL', t, act).changes > 0;
    // review166: an account that was already disabled before (first sync after the update) is only marked, no alert for old dead accounts
    const oldDead = DISABLED.includes(status) && prev.state === 'disabled' && DISABLED.includes(prev.status);
    if (first && !oldDead) {
      const a0 = acctOf(act)!;
      const lead0 = a0.lead_id ? leadById(a0.lead_id) : undefined;
      log('pay_failed', { act_id: act, lead_id: a0.lead_id || null, amount: due != null ? money(due / 100) : 0, note: `${STATUS[status] || status}${disableText(status, reason) ? ' · ' + disableText(status, reason) : ''}${card ? ' · card ' + card : ''}`, by: 'meta' });
      await alertTeam(`💳 Payment failed: ${acctName(a0)}`, `Meta could not charge the card${card ? ` ${card}` : ''}${due ? ` · ${usd(due / 100)} due` : ''} · status ${STATUS[status] || status}.${lead0 ? ` Client: ${displayName(lead0)}.` : ''} Pay it from the BM's billing (iX profile ${profTag(bm.bm_id) || ''}). It clears here by itself on the next sync.`, a0.lead_id || null);
    }
  } else if (run('UPDATE meta_accounts SET pay_due=NULL, pay_fail_at=NULL WHERE act_id=? AND pay_fail_at IS NOT NULL', act).changes) { // review166: cleared once
    if (status === 1) await alertTeam(`✅ Payment done: ${acctName(acctOf(act)!)}`, 'Meta charged the card, the account is active again.');
  }
  let a = acctOf(act)!;
  // v152: Meta reset the spend by itself (limit set to "Automatically, on the 1st of every month",
  // or reset by hand in Ads Manager). Our own resets save the new spend at once, so a drop here is not ours.
  // Put the limit back so the client gets no extra money, and tell the team.
  if (prev.spent > 0 && spent < prev.spent && prev.cap > 0 && cap > 0 && !DISABLED.includes(status) && !prev.step) { // not in the middle of a take-back
    const left = Math.max(0, prev.cap - prev.spent);
    const target = Math.max(1, spent + left);
    let fixed = false;
    if (c) { try { await setCap(c, act, target); run('UPDATE meta_accounts SET cap=? WHERE act_id=?', target, act); fixed = true; } catch (e) { console.warn('[meta] re-cap', act, (e as Error).message); } }
    a = acctOf(act)!;
    await alertTeam(`⚠️ Spend reset by Meta: ${acctName(a)}`, `Spent went from ${usd(prev.spent / 100)} to ${usd(spent / 100)} without AdsBhai doing it. ${fixed ? `Limit set back to ${usd(target / 100)} so the balance stays ${usd(left / 100)}.` : `Could not fix the limit, set it to ${usd(target / 100)} by hand.`} In Ads Manager → Billing → Account spending limit, set "When the limit resets" to "Manually, only when I change it".`, a.lead_id || null);
  }
  if (DISABLED.includes(status) && a.state !== 'disabled') await onDisabled(a, prev.state);
  else if (!DISABLED.includes(status) && a.state === 'disabled' && a.step !== 'active_again' && DISABLED.includes(prev.status)) {
    run("UPDATE meta_accounts SET step='active_again' WHERE act_id=?", act);
    await alertTeam(`✅ ${acctName(a)} is active again`, a.lead_id ? `It was with ${displayName(leadById(a.lead_id) || {})}. Their balance was already moved to credit, so check access and use “Unshare & reset”.` : 'Tap “Mark free” to use it again.');
  }
  // low balance (assigned accounts with a limit)
  if (a.state === 'assigned' && a.lead_id && a.cap > 0 && !a.locked) {
    const left = remaining(a) / 100;
    const low = num(s.meta_low_usd, 15);
    // v155: at most once a day per account (a new day while still low → one reminder again); a top-up starts over
    const lowAt = num((a as Acct & { low_at?: number | null }).low_at);
    if (left < low && (!a.low_sent || !lowAt || localDate(lowAt, s) !== localDate(now(), s))) {
      run('UPDATE meta_accounts SET low_sent=1, low_at=? WHERE act_id=?', now(), act);
      const lead = leadById(a.lead_id);
      if (lead) {
        addMsg(lead, { dir: 'sys', sender: 'system', text: `⚡ Low balance on ${acctName(a)}: ${usd(left)} left. Offer a top-up.` });
        // v155: the client is told too (automatic message) — only for accounts delivered by this system (not "Already sold" ones)
        if ((a as Acct & { partner_name?: string | null }).partner_name !== '') void tellClient(lead, 'meta_msg_low', { acts: [a.act_id], balance: left });
        await notifyAgent(agentById(lead.agent_id), `⚡ ${displayName(lead)}: only ${usd(left)} left on ${acctName(a)}. Offer a top-up.`, lead.id, { title: '⚡ Low balance', body: `${displayName(lead)} · ${usd(left)} left` });
      }
    } else if (left >= low && a.low_sent) run('UPDATE meta_accounts SET low_sent=0 WHERE act_id=?', act);
  }
}

async function onDisabled(a: Acct, prevState: string) {
  const left = remaining(a) / 100;
  const withClient = prevState === 'assigned' || prevState === 'invited';
  tx(() => {
    run("UPDATE meta_accounts SET state='disabled', disabled_at=?, step=NULL WHERE act_id=?", now(), a.act_id);
    if (withClient && a.lead_id && left > 0) run("INSERT INTO meta_credits(lead_id, amount, act_id, reason, status, created_at) VALUES(?,?,?,'disabled','open',?)", a.lead_id, money(left), a.act_id, now());
    log('disabled', { act_id: a.act_id, lead_id: a.lead_id, amount: withClient ? money(left) : 0, note: `${STATUS[a.status] || String(a.status)}${disableText(a.status, a.disable_reason) ? ' · ' + disableText(a.status, a.disable_reason) : ''}`, by: 'meta' });
  });
  const lead = withClient && a.lead_id ? leadById(a.lead_id) : undefined;
  if (lead) {
    addMsg(lead, { dir: 'sys', sender: 'system', text: `⛔ ${acctName(a)} was disabled by Meta. The balance left was saved as this client's credit. It is added automatically to the next account.` });
    void notifyAgent(agentById(lead.agent_id), `⛔ ${displayName(lead)}'s ad account ${acctName(a)} was disabled. The balance was saved as credit for the next account.`, lead.id, { title: '⛔ Ad account disabled', body: displayName(lead) });
  }
  await alertTeam(`⛔ ${acctName(a)} disabled${disableText(a.status, a.disable_reason) ? ` · ${disableText(a.status, a.disable_reason)}` : ''}`, lead ? `Client ${displayName(lead)} · ${usd(left)} left saved as credit. Give a new account from Ad accounts → Credits.` : `Free account on ${bmName(bmOf(a.bm_id))}.`, lead?.id ?? null);
}

/* ======================= spend limit ======================= */
async function readAcct(c: Creds, act: string) {
  const r = await graph(c, 'GET', 'act_' + act, { fields: 'id,account_status,amount_spent,spend_cap,name' });
  return { spent: Math.round(num(r.amount_spent)), cap: Math.round(num(r.spend_cap)), status: num(r.account_status, 1), name: r.name as string };
}

/** Set the spend limit to `target` cents and check it. Meta reads it back in cents; writes are learnt once (usd vs cents). */
async function setCap(c: Creds, act: string, target: number) {
  if (!(target >= 1)) throw new MetaError('Spend limit must be at least 1 cent');
  const unit = getSettings().meta_cap_unit;
  const write = (u: string) => graph(c, 'POST', 'act_' + act, { spend_cap: u === 'cents' ? target : (target / 100).toFixed(2) });
  await write(unit === 'cents' ? 'cents' : 'usd');
  let r = await readAcct(c, act);
  if (Math.abs(r.cap - target) <= 1) { if (!unit) setSetting('meta_cap_unit', 'usd'); return r; }
  if (unit !== 'cents' && Math.abs(r.cap - Math.round(target / 100)) <= 1) {
    // Meta took the dollar value as cents (limit ended up lower = safe) → write in cents and remember
    await write('cents');
    r = await readAcct(c, act);
    if (Math.abs(r.cap - target) <= 1) { setSetting('meta_cap_unit', 'cents'); return r; }
  }
  throw new MetaError(`Spend limit check failed: asked ${usd(target / 100)}, Meta shows ${usd(r.cap / 100)}. Check it in Ads Manager.`);
}
const lockCents = () => Math.max(1, cents(num(getSettings().meta_lock_usd, 0.1)));

/* ======================= operations ======================= */
async function withLock<T>(act: string, fn: (a: Acct, bm: Bm) => Promise<T>): Promise<T> {
  const a = acctOf(act);
  if (!a) throw new HttpError(404, 'Ad account not found. Sync the BM first.');
  const bm = bmOf(a.bm_id);
  if (!bm) throw new HttpError(400, 'This account’s BM was removed');
  if (!run('UPDATE meta_accounts SET busy=? WHERE act_id=? AND (busy IS NULL OR busy<?)', now(), act, now() - 120000).changes) throw new HttpError(409, 'Another action is running on this account. Try again in a moment.');
  try { return await fn(a, bm); }
  catch (e) {
    if (e instanceof MetaError) {
      run('UPDATE meta_accounts SET err=? WHERE act_id=?', e.message.slice(0, 300), act);
      if (e.kind === 'token' || e.kind === 'perm') await bmFailed(bm, e);
    }
    throw e;
  } finally { run('UPDATE meta_accounts SET busy=0 WHERE act_id=?', act); }
}

/** v177: use `amount` of the client's open credit (oldest first; a partly used entry keeps the rest open). Returns what was used. */
export function useCredit(leadId: number, amount: number, act: string) {
  let left = money(amount); let used = 0;
  tx(() => {
    for (const c of all<{ id: number; amount: number; act_id: string | null; reason: string | null }>("SELECT id, amount, act_id, reason FROM meta_credits WHERE lead_id=? AND status='open' ORDER BY id", leadId)) {
      if (left <= 0.004) break;
      if (c.amount <= left + 0.004) { run("UPDATE meta_credits SET status='used', used_act=?, used_at=? WHERE id=?", act || null, now(), c.id); left = money(left - c.amount); used = money(used + c.amount); }
      else {
        run('UPDATE meta_credits SET amount=? WHERE id=?', money(c.amount - left), c.id);
        run("INSERT INTO meta_credits(lead_id, amount, act_id, reason, status, used_act, created_at, used_at) VALUES(?,?,?,?,'used',?,?,?)", leadId, left, c.act_id, c.reason, act || null, now(), now());
        used = money(used + left); left = 0;
      }
    }
  });
  return used;
}
export const openCredit = (leadId: number) => money(one<{ v: number }>("SELECT COALESCE(SUM(amount),0) v FROM meta_credits WHERE lead_id=? AND status='open'", leadId)!.v);

/** Share a free account with a client. `add` = extra balance (usd) on top of the client's open credit. */
export async function shareAcct(act: string, o: { lead_id: number; mode: 'bm' | 'email'; client_bm?: string; client_email?: string; add?: number; paid?: number; fee?: number; agent_id?: number | null; biz_name?: string | null; replace?: string | null }, actor: Actor) {
  const lead = leadById(o.lead_id);
  if (!lead) throw new HttpError(404, 'Client chat not found');
  const clientBm = String(o.client_bm || '').replace(/\D/g, '');
  const email = String(o.client_email || '').trim().toLowerCase();
  if (o.mode === 'bm' && (clientBm.length < 8 || clientBm.length > 20)) throw new HttpError(400, 'Enter the client’s Business Manager ID (numbers only)');
  if (o.mode === 'email' && !emailInvitesOn()) throw new HttpError(400, 'Email invites are switched off (Ad accounts → Settings)');
  if (o.mode === 'email' && !/^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(email)) throw new HttpError(400, 'Enter the client’s Facebook email');
  return withLock(cleanAct(act), async (a, bm) => {
    if (a.state !== 'free') throw new HttpError(400, `${acctName(a)} is not free (${a.state})`);
    // v166: kept out of stock (old client may still be a partner) → never shared to a new client until checked and marked free
    if (a.step === 'check' || a.step === 'partner_by_hand') throw new HttpError(400, `${acctName(a)} is kept out of stock${a.err ? ` (${a.err})` : ''}. Check it on Meta, then Mark free.`);
    if (DISABLED.includes(a.status)) throw new HttpError(400, `${acctName(a)} is ${STATUS[a.status] || 'not active'}`);
    if (o.mode === 'bm' && clientBm === bm.bm_id) throw new HttpError(400, 'That is our own BM ID. Ask the client for their Business Manager ID.');
    const c = creds(bm);
    const credit = openCredit(lead.id);
    const add = money(o.add || 0);
    const fresh = await readAcct(c, a.act_id);
    // v153 partner-by-hand mode: the manager assigned the partner in Business Settings → check it on Meta before anything else
    const handMode = !!bm.profile_id && o.mode === 'bm' && getSettings().mq_partner_hand !== '0';
    let handPartner: string | null = null;
    if (handMode) {
      JOB.step(`Checking partner BM ${clientBm} on Meta`);
      try {
        const ag = await graphAll<{ id: string; name?: string }>(c, `act_${a.act_id}/agencies`, { fields: 'id,name', limit: 50 }, 2);
        const hit = ag.find(x => String(x.id) === clientBm);
        if (!hit) throw new MetaError(`Partner not assigned yet: BM ${clientBm} is not a partner of ${acctName(a)} on Meta. Business Settings → Ad accounts → ${acctName(a)} → Assign partner → BM ${clientBm}, then approve again.`, 0, 0, 'meta');
        handPartner = hit.name || null;
        JOB.step(`Partner found: ${hit.name || 'BM ' + clientBm}`);
        // v155: an old client's BM still on the account → never share it on top of them
        const others = ag.filter(x => String(x.id) !== clientBm && String(x.id) !== String(bm.bm_id));
        if (others.length) throw new MetaError(`Fix partners by hand: ${acctName(a)} still has ${others.map(x => (x.name ? x.name + ' ' : '') + 'BM ' + x.id).join(', ')} as partner. Remove it in Business Settings → Ad accounts → Partners, then approve again.`, 0, 0, 'meta');
      } catch (e) {
        if (e instanceof MetaError && /Partner not assigned yet|Fix partners by hand/.test(e.message)) throw e;
        if ((e instanceof MetaError && e.kind === 'net') || /timeout|timed out|ECONN|socket hang up|fetch failed|network/i.test((e as Error).message || '')) throw e;
        // v155: not checked = not shared (nothing was changed on Meta yet)
        throw new MetaError(`Partner could not be checked on Meta (${((e as Error).message || '').slice(0, 120)}). Nothing was changed. Try again, or finish by hand.`, 0, 0, 'meta');
      }
    }
    // v166: API mode too — the partners on Meta are read before anything is written; another client's BM there → not shared
    if (!handMode) {
      let ag: { id: string; name?: string }[];
      try { ag = await graphAll<{ id: string; name?: string }>(c, `act_${a.act_id}/agencies`, { fields: 'id,name', limit: 50 }, 2); }
      catch (e) {
        if ((e instanceof MetaError && e.kind === 'net') || /timeout|timed out|ECONN|socket hang up|fetch failed|network/i.test((e as Error).message || '')) throw e;
        throw new MetaError(`Partners could not be checked on Meta (${((e as Error).message || '').slice(0, 120)}). Nothing was changed. Try again, or finish by hand.`, 0, 0, 'meta');
      }
      const others = ag.filter(x => String(x.id) !== clientBm && String(x.id) !== String(bm.bm_id));
      if (others.length) {
        run("UPDATE meta_accounts SET step='check', err=? WHERE act_id=?", `Remove partner ${others.map(x => 'BM ' + x.id).join(', ')} by hand, then Mark free`, a.act_id);
        throw new MetaError(`Fix partners by hand: ${acctName(a)} still has ${others.map(x => (x.name ? x.name + ' ' : '') + 'BM ' + x.id).join(', ')} as partner. Remove it in Business Settings → Ad accounts → Partners, then Mark free.`, 0, 0, 'meta');
      }
    }
    // v152: the client's own money (old credit / paid top-up) sets the limit. With no money:
    // an account that already has a spending limit keeps it as it is; one with no limit gets the $0.10 lock.
    let capR: { spent: number; cap: number };
    if (credit + add > 0) {
      const target = fresh.spent + cents(credit + add);
      JOB.step(`Spending limit ${usd(target / 100)}`);
      capR = await setCap(c, a.act_id, target);
    } else if (fresh.cap > 0) {
      JOB.step(`Spending limit already set (${usd(fresh.cap / 100)}), left as it is`);
      capR = { spent: fresh.spent, cap: fresh.cap };
    } else {
      const target = Math.max(fresh.spent, lockCents());
      JOB.step(`No spending limit, set to ${usd(target / 100)}`);
      capR = await setCap(c, a.act_id, target);
    }
    let inviteId: string | null = null;
    // v153 (profile BMs): the new name is set BEFORE the client gets access, so the client never sees "Adsbhai 3"
    const nameFor = (biz: string) => { const p = profileById(bm.profile_id); return clientAcctName(bm.name, displayName(lead), p?.ix, biz); };
    let preName: string | null = null;
    if (bm.profile_id && o.mode === 'bm') {
      const nm = nameFor(String(o.biz_name || '').trim().slice(0, 40));
      try { await graph(c, 'POST', 'act_' + a.act_id, { name: nm }); JOB.step(`Renamed: ${nm}`); preName = nm; run('UPDATE meta_accounts SET base_name=COALESCE(base_name, name), name=? WHERE act_id=?', nm, a.act_id); }
      catch (e) { JOB.step(`Rename failed: ${(e as Error).message}`); }
    }
    let partnerByHand = false;
    try {
      if (o.mode === 'bm' && handMode) { /* assigned by hand, checked above */ }
      else if (o.mode === 'bm') { JOB.step(`Assigning partner: BM ${clientBm}`); await graph(c, 'POST', `act_${a.act_id}/agencies`, { business: clientBm, permitted_tasks: TASKS }); JOB.step(`Partner assigned: BM ${clientBm}`); }
      else {
        const r = await graph<{ id?: string }>(c, 'POST', `${bm.bm_id}/business_users`, { email, role: 'EMPLOYEE' });
        inviteId = r.id ? String(r.id) : null;
      }
    } catch (e) {
      // v153: Meta does not let this app assign partners (#3) → everything else is done, the manager assigns the partner by hand
      if (o.mode === 'bm' && is3(e)) {
        partnerByHand = true;
        JOB.step('Meta does not let this app assign partners: assign the partner by hand, then tap “Done by hand”');
      } else {
      // v152: the share failed → the account stays free, so take the client's money back off its limit (the next client must not get it)
      if (preName) { try { const st = getSettings(); const back = (st.meta_name_pattern || '{brand} {n}').replace(/\{brand\}/g, st.brand_name || 'Adsbhai').replace(/\{n\}/g, String(a.no)); await graph(c, 'POST', 'act_' + a.act_id, { name: back }); run('UPDATE meta_accounts SET name=?, base_name=NULL WHERE act_id=?', back, a.act_id); } catch { /* sync shows it */ } }
      let rolledBack = capR.cap === fresh.cap;
      if (!rolledBack) { try { JOB.step('Share failed, limit set back'); await setCap(c, a.act_id, fresh.cap > 0 ? fresh.cap : Math.max(fresh.spent, lockCents())); rolledBack = true; } catch { /* below */ } }
      // network drop (Meta may have added the partner) or the limit could not be set back → keep it out of stock until a person checks
      const netDrop = (e instanceof MetaError && e.kind === 'net') || /timeout|timed out|ECONN|socket hang up|network|did not answer/i.test((e as Error).message || '');
      if (netDrop || !rolledBack) {
        run("UPDATE meta_accounts SET step='check' WHERE act_id=?", a.act_id);
        await alertTeam(`✋ Check ${acctName(a)} by hand`, `The share to ${o.mode === 'bm' ? 'BM ' + clientBm : email} stopped half way (${((e as Error).message || '').slice(0, 120)}).${netDrop ? ' The client may already have access.' : ''}${!rolledBack ? ' The spending limit could not be set back.' : ''} It is kept out of stock: check it in Ads Manager, then Ad accounts → the account → Mark free (or finish the share by hand).`, lead.id);
      }
      throw e;
      }
    }
    tx(() => {
      run(`UPDATE meta_accounts SET state=?, lead_id=?, share_mode=?, client_bm=?, client_email=?, invite_id=?, buser_id=NULL, assigned_at=?, low_sent=0, step=?, err=NULL, spent=?, cap=?, locked=? WHERE act_id=?`,
        o.mode === 'bm' ? 'assigned' : 'invited', lead.id, o.mode, o.mode === 'bm' ? clientBm : null, o.mode === 'email' ? email : null, inviteId, now(), partnerByHand ? 'partner_by_hand' : null, capR.spent, capR.cap, credit + add > 0 ? 0 : 1, a.act_id);
      if (credit > 0) run("UPDATE meta_credits SET status='used', used_act=?, used_at=? WHERE lead_id=? AND status='open'", a.act_id, now(), lead.id);
      log('share', { act_id: a.act_id, lead_id: lead.id, agent_id: o.agent_id ?? lead.agent_id, amount: credit, note: o.mode === 'bm' ? `BM ${clientBm}` : `Invite ${email}`, by: by(actor) });
      if (add > 0) log(o.replace ? 'old_balance' : 'topup', { act_id: a.act_id, lead_id: lead.id, agent_id: o.agent_id ?? lead.agent_id, paid: o.replace ? 0 : o.paid ?? add, fee: o.replace ? null : o.fee ?? null, amount: add, note: o.replace ? 'client’s old balance with the replacement (no fee, no sale)' : 'with the share', by: by(actor) }); // v173 QA: a replacement's old balance is never a top-up
    });
    saveLeadAccounts(lead.id, [a.act_id], { bm: o.mode === 'bm' ? clientBm : null, source: 'meta' });
    if (partnerByHand) {
      if (preName) run('UPDATE meta_accounts SET biz_name=? WHERE act_id=?', String(o.biz_name || '').trim().slice(0, 40) || null, a.act_id);
      const af = acctOf(a.act_id)!;
      addMsg(lead, { dir: 'sys', sender: 'system', text: `⏳ ${acctName(af)} (act_${a.act_id}) is ready for this client (limit ${usd(remaining(af) / 100)}). The partner (BM ${clientBm}) must be assigned by hand: Business Settings → Ad accounts → Assign partner, then “Done by hand”.` });
      await alertTeam(`✋ Assign partner by hand: ${acctName(af)}`, `${displayName(lead)} · BM ${clientBm}\nMeta does not let the app assign partners. Business Settings → Ad accounts → ${acctName(af)} → Assign partner → BM ${clientBm} (Advertise + Analyze). Then Requests → “Done by hand in Ads Manager”.`, lead.id);
      throw new MetaError('(#3) Meta does not let this app assign partners. Assign the partner by hand, then tap “Done by hand”.', 3, 0, 'meta');
    }
    // v152 (profile BMs): the partner's real BM name from Meta, then the name "Adsbhai X {client} {iX} {business}"
    if (bm.profile_id && o.mode === 'bm') {
      let partner: string | null = null;
      if (handPartner) partner = handPartner;
      else { try { const ag = await graphAll<{ id: string; name?: string }>(c, `act_${a.act_id}/agencies`, { fields: 'id,name', limit: 50 }, 2); partner = ag.find(x => String(x.id) === clientBm)?.name || null; } catch { /* name stays empty */ } }
      const biz = String(o.biz_name || '').trim().slice(0, 40) || partner || '';
      const nm = nameFor(biz);
      run('UPDATE meta_accounts SET base_name=COALESCE(base_name, name), partner_name=?, biz_name=? WHERE act_id=?', partner || 'BM ' + clientBm, biz || null, a.act_id);
      // the business name is known only now (read from Meta) → name once more with it
      if (nm !== preName) {
        try { await graph(c, 'POST', 'act_' + a.act_id, { name: nm }); JOB.step(`Renamed: ${nm}`); run('UPDATE meta_accounts SET name=? WHERE act_id=?', nm, a.act_id); }
        catch (e) { JOB.step(`Rename failed: ${(e as Error).message}`); }
      }
    }
    // first try: the invited person may already be in our BM (invited before)
    if (o.mode === 'email') { try { await checkInvites(bm); } catch { /* worker retries */ } }
    // v156: a replacement → the new account remembers the old one (client message, no channel post / story)
    if (o.replace) { run('UPDATE meta_accounts SET repl_of=? WHERE act_id=?', o.replace, a.act_id); log('replace', { act_id: a.act_id, lead_id: lead.id, note: `replaces act_${o.replace}`, by: by(actor) }); if (acctOf(o.replace)) log('replaced', { act_id: o.replace, lead_id: lead.id, note: `replaced by act_${a.act_id}`, by: by(actor) }); }
    const after = acctOf(a.act_id)!;
    const lim = usd(remaining(after) / 100);
    addMsg(lead, { dir: 'sys', sender: 'system', agent_id: o.agent_id ?? null, text: o.mode === 'bm'
      ? `${o.replace ? `🔁 Replacement for act_${o.replace}: ` : '🎉 '}${acctName(after)} (act_${a.act_id}) shared to BM ${clientBm} · campaigns + performance + Creative Hub · balance ${lim}${credit ? ' (old credit added)' : ''}`
      : `✉️ ${acctName(after)} (act_${a.act_id}): invite sent to ${email}. Ask the client to accept the email from Meta. Access to this account is given automatically after that. Balance ${lim}${credit ? ' (old credit added)' : ''}` });
    // v155: with proof images on, the client gets the images first (album) and then this message → sent by the proof step
    if (bm.profile_id && o.mode === 'bm' && getSettings().meta_proof_client !== '0' && lead.tg_chat_id) run('UPDATE meta_accounts SET share_msg=1 WHERE act_id=?', a.act_id);
    else await tellClient(leadById(lead.id), o.mode === 'bm' ? (o.replace ? 'meta_msg_replace' : 'meta_msg_share') : 'meta_msg_invite', { acts: [a.act_id], bm: o.mode === 'bm' ? clientBm : null, email, balance: remaining(after) / 100 });
    const ag = agentById(lead.agent_id);
    if (ag && ag.id !== actor.id) void notifyAgent(ag, `🎉 Ad account for ${displayName(lead)}: ${acctName(after)} (act_${a.act_id}) ${o.mode === 'bm' ? 'shared to BM ' + clientBm : 'invite sent to ' + email}. Balance ${lim}.`, lead.id); // v155: no phone push
    return { ok: true, act_id: a.act_id, name: acctName(after), balance: remaining(after) / 100, credit_used: credit, invited: o.mode === 'email' };
  });
}

/** Email invites: once the person accepted (is a business user), give them only this ad account. */
async function checkInvites(bm: Bm) {
  const waiting = all<Acct>("SELECT * FROM meta_accounts WHERE bm_id=? AND state='invited'", bm.bm_id);
  if (!waiting.length) return;
  const c = creds(bm);
  const users = await graphAll<{ id: string; email?: string; name?: string }>(c, `${bm.bm_id}/business_users`, { fields: 'id,email,name', limit: 200 });
  for (const a of waiting) {
    const u = users.find(x => (x.email || '').toLowerCase() === (a.client_email || '').toLowerCase());
    if (!u) continue;
    await graph(c, 'POST', `act_${a.act_id}/assigned_users`, { user: u.id, tasks: TASKS, business: bm.bm_id });
    run("UPDATE meta_accounts SET state='assigned', buser_id=? WHERE act_id=?", u.id, a.act_id);
    log('invite_ok', { act_id: a.act_id, lead_id: a.lead_id, note: a.client_email || '', by: 'meta' });
    const lead = a.lead_id ? leadById(a.lead_id) : undefined;
    if (lead) {
      addMsg(lead, { dir: 'sys', sender: 'system', text: `✅ ${a.client_email} accepted the invite. ${acctName(a)} (act_${a.act_id}) is now in their Ads Manager.` });
      await tellClient(lead, 'meta_msg_invite_ok', { acts: [a.act_id], email: a.client_email });
      void notifyAgent(agentById(lead.agent_id), `✅ ${displayName(lead)} accepted the invite. act_${a.act_id} is ready in their Ads Manager.`, lead.id, { title: '✅ Invite accepted', body: displayName(lead) });
    }
  }
}

/** Top-up: spend limit + amount (usd, after our fee). */
/** v159: a top-up from the queue → the "Top-up done" message waits for the top-up image (sent right after it, see metaq afterRequest). */
export const laterMsg = new Map<string, { send: () => Promise<unknown>; text: string }>();
export async function topupAcct(act: string, o: { amount: number; paid?: number; fee?: number; agent_id?: number | null; note?: string; imageFirst?: boolean; credit?: boolean }, actor: Actor) {
  const amount = money(o.amount);
  if (!(amount > 0)) throw new HttpError(400, 'Enter the top-up amount');
  return withLock(cleanAct(act), async (a, bm) => {
    if (!['assigned', 'invited'].includes(a.state)) throw new HttpError(400, `${acctName(a)} is not with a client`);
    if (DISABLED.includes(a.status)) throw new HttpError(400, `${acctName(a)} is ${STATUS[a.status] || 'not active'}. Give the client a new account (the balance is in their credit).`);
    const c = creds(bm);
    const fresh = await readAcct(c, a.act_id);
    // no limit (0) or only our lock on it → start from what is spent
    const base = a.locked || !(fresh.cap > 0) ? fresh.spent : Math.max(fresh.cap, fresh.spent);
    JOB.step(`Top-up ${usd(amount)}: limit ${usd(fresh.cap / 100)} → ${usd((base + cents(amount)) / 100)} (spent ${usd(fresh.spent / 100)})`);
    const r = await setCap(c, a.act_id, base + cents(amount));
    JOB.step(`Limit set on Meta: ${usd(r.cap / 100)} · balance ${usd(Math.max(0, r.cap - r.spent) / 100)}`);
    run('UPDATE meta_accounts SET spent=?, cap=?, low_sent=0, err=NULL, locked=0 WHERE act_id=?', r.spent, r.cap, a.act_id);
    log(o.credit ? 'credit_in' : 'topup', { act_id: a.act_id, lead_id: a.lead_id, agent_id: o.agent_id ?? null, paid: o.credit ? 0 : o.paid ?? amount, fee: o.fee ?? null, amount, note: o.note, by: by(actor) }); // v166: no fee given → NULL
    const lead = a.lead_id ? leadById(a.lead_id) : undefined;
    const left = Math.max(0, r.cap - r.spent) / 100;
    if (lead) addMsg(lead, { dir: 'sys', sender: 'system', agent_id: o.agent_id ?? null, text: `💰 ${usd(amount)} added to ${acctName(a)} (act_${a.act_id}) · balance now ${usd(left)}` });
    const send = () => tellClient(lead, 'meta_msg_topup', { acts: [a.act_id], amount, balance: left });
    if (o.imageFirst && lead) laterMsg.set(a.act_id, { send, text: clientText('meta_msg_topup', { acts: [a.act_id], amount, balance: left }) }); else await send();
    return { ok: true, added: amount, balance: left, cap: r.cap / 100 };
  });
}

/** v161: take a top-up back (done by mistake). last = the whole last top-up; else `amount` (at most the last top-up).
 *  Meta: the spend limit goes down by that much (never below what is already spent).
 *  Our numbers: the last top-up (Ad accounts log + Sales top-ups: amount, fee, commission) goes down by the same share,
 *  or is removed when the whole of it is taken back. The client gets no message. */
export async function cutTopup(act: string, b: { last?: unknown; amount?: unknown; log_id?: unknown }, actor: Actor) {
  const a0 = acctOf(act), bm0 = a0 ? bmOf(a0.bm_id) : undefined;
  const lastOf = (id: string) => one<{ id: number; amount: number; fee: number | null; paid: number | null; lead_id: number | null; created_at: number; note: string | null }>("SELECT id, amount, fee, paid, lead_id, created_at, note FROM meta_log WHERE act_id=? AND kind='topup' AND amount>0 ORDER BY id DESC LIMIT 1", id);
  if (!a0) throw new HttpError(404, 'Ad account not found');
  const l0 = lastOf(a0.act_id);
  if (!l0) throw new HttpError(400, 'No top-up on this account to take back');
  const want = b.last ? money(l0.amount) : money(b.amount);
  if (!(want > 0)) throw new HttpError(400, 'Enter the amount to take back');
  if (want > money(l0.amount) + 0.004) throw new HttpError(400, `The last top-up was ${usd(l0.amount)}. You can take back at most that.`);
  if (bm0 && viaQueue(bm0)) return { ok: true, queued: true, job: enqueueFor(bm0, 'cut', a0.act_id, { amount: want, log_id: l0.id }, actor, 1) };
  return withLock(cleanAct(act), async (a, bm) => {
    const l = lastOf(a.act_id);
    if (!l || l.id !== (b.log_id != null ? num(b.log_id) : l0.id)) throw new HttpError(409, 'The last top-up changed after this was asked. Nothing was taken back.');
    const c = creds(bm);
    const fresh = await readAcct(c, a.act_id);
    if (!(fresh.cap > 0)) throw new HttpError(400, 'This account has no spend limit on Meta. Nothing to take back.');
    const target = Math.max(fresh.spent, fresh.cap - cents(want), 1);
    const cut = money((fresh.cap - target) / 100);
    if (!(cut > 0)) throw new HttpError(400, `Nothing left to take back: ${usd(fresh.spent / 100)} is already spent (limit ${usd(fresh.cap / 100)}).`);
    JOB.step(`Take back ${usd(want)}: limit ${usd(fresh.cap / 100)} → ${usd(target / 100)} (spent ${usd(fresh.spent / 100)})`);
    const r = await setCap(c, a.act_id, target);
    run('UPDATE meta_accounts SET spent=?, cap=?, err=NULL WHERE act_id=?', r.spent, r.cap, a.act_id);
    // our numbers follow what really came off the limit
    const k = Math.min(1, cut / l.amount), whole = k >= 0.9999;
    tx(() => {
      const t = one<{ id: number; amount: number; commission: number }>('SELECT id, amount, commission FROM topups WHERE meta_log_id=?', l.id)
        ?? (l.lead_id && !/^website /i.test(l.note || '') ? one<{ id: number; amount: number; commission: number }>('SELECT id, amount, commission FROM topups WHERE lead_id=? AND meta_log_id IS NULL AND ABS(amount-?)<0.01 AND created_at>=? ORDER BY id DESC LIMIT 1', l.lead_id, l.amount, l.created_at - 6 * 3600_000) : undefined);
      if (whole) {
        run("UPDATE meta_log SET kind='topup_removed', note=TRIM(COALESCE(note,'') || ' · taken back') WHERE id=?", l.id);
        if (t) run('DELETE FROM topups WHERE id=?', t.id);
      } else {
        run('UPDATE meta_log SET amount=?, fee=?, paid=? WHERE id=?', money(l.amount - cut), l.fee == null ? null : money(l.fee * (1 - k)), l.paid == null ? null : money(l.paid * (1 - k)), l.id);
        if (t) run('UPDATE topups SET amount=?, commission=? WHERE id=?', money(t.amount - cut), money(t.commission * (1 - k)), t.id);
      }
      log('topup_cut', { act_id: a.act_id, lead_id: a.lead_id, amount: cut, note: whole ? `last top-up ${usd(l.amount)} taken back` : `${usd(cut)} taken back from the ${usd(l.amount)} top-up`, by: by(actor) });
    });
    const lead = a.lead_id ? leadById(a.lead_id) : undefined;
    const left = Math.max(0, r.cap - r.spent) / 100;
    if (lead) addMsg(lead, { dir: 'sys', sender: 'system', text: `↩️ ${usd(cut)} taken back from ${acctName(a)} (act_${a.act_id}) by ${by(actor)} · balance now ${usd(left)}` });
    return { ok: true, cut, whole, balance: left, short: cut < want - 0.004 };
  });
}

/** Take an account back: remove access, delete campaigns, save balance as credit, reset spend, back to Free. Resumes where it stopped. */
export async function unshareAcct(act: string, actor: Actor) {
  const a0 = acctOf(act), bm0 = a0 ? bmOf(a0.bm_id) : undefined;
  if (a0 && bm0 && viaQueue(bm0)) {
    if (!a0.lead_id && !['assigned', 'invited', 'disabled'].includes(a0.state)) throw new HttpError(400, `${acctName(a0)} is already free`);
    return { ok: true, queued: true, job: enqueueFor(bm0, 'unshare', a0.act_id, {}, actor, 2) };
  }
  return withLock(cleanAct(act), async (a, bm) => {
    if (!a.lead_id && !['assigned', 'invited', 'disabled'].includes(a.state)) throw new HttpError(400, `${acctName(a)} is already free`);
    const c = creds(bm);
    const steps = ['revoke', 'campaigns', 'credit', 'reset'];
    let i = Math.max(0, steps.indexOf(a.step || 'revoke'));
    let leftByHand: string[] = [];
    const done: string[] = [];
    for (; i < steps.length; i++) {
      const st = steps[i];
      run('UPDATE meta_accounts SET step=? WHERE act_id=?', st, a.act_id);
      JOB.step({ revoke: 'Removing access', campaigns: 'Deleting the client’s campaigns', credit: 'Saving money left as credit', reset: 'Reset limit + $0.10 lock' }[st] || st);
      if (st === 'revoke') {
        if (a.share_mode === 'bm' && a.client_bm) {
          // v153: if Meta does not let the app remove partners (#3), the rest still runs and the manager removes it by hand
          const handLeft: string[] = [];
          for (const x of [a.client_bm, ...extraBms(a)]) {
            JOB.step(`Removing access: BM ${x}`);
            try { await ignoreGone(() => graph(c, 'DELETE', `act_${a.act_id}/agencies`, { business: x }), false); }
            catch (e) { if (is3(e) || noPermRemove(e)) handLeft.push(x); else throw e; } // v166: no permission → removed by hand, kept out of stock
          }
          leftByHand = handLeft;
          if (handLeft.length) {
            JOB.step(`Meta does not let the app remove partners: remove ${handLeft.map(x => 'BM ' + x).join(', ')} by hand`);
            await alertTeam(`✋ Remove partner by hand: ${acctName(a)}`, `Business Settings → Ad accounts → ${acctName(a)} → Partners → remove ${handLeft.map(x => 'BM ' + x).join(', ')}. Campaigns, credit, limit and name are done by the system.`, null);
          }
        } else if (a.share_mode === 'email') {
          const others = a.buser_id ? one<{ n: number }>("SELECT COUNT(*) n FROM meta_accounts WHERE buser_id=? AND act_id!=? AND state IN ('assigned','invited')", a.buser_id, a.act_id)!.n : 0;
          if (a.buser_id && others) await ignoreGone(() => graph(c, 'DELETE', `act_${a.act_id}/assigned_users`, { user: a.buser_id, business: bm.bm_id }));
          else if (a.buser_id) await ignoreGone(() => graph(c, 'DELETE', a.buser_id!));
          else if (a.invite_id) await ignoreGone(() => graph(c, 'DELETE', a.invite_id!));
        }
        done.push('access removed');
      } else if (st === 'campaigns') {
        const camps = await graphAll<{ id: string }>(c, `act_${a.act_id}/campaigns`, { fields: 'id', limit: 200, effective_status: ['ACTIVE', 'PAUSED', 'ARCHIVED', 'IN_PROCESS', 'WITH_ISSUES'] });
        for (const cp of camps) await ignoreGone(() => graph(c, 'POST', cp.id, { status: 'DELETED' }));
        done.push(`${camps.length} campaign${camps.length === 1 ? '' : 's'} deleted`);
      } else if (st === 'credit') {
        const fresh = await readAcct(c, a.act_id);
        const left = a.state === 'disabled' ? 0 : remaining({ ...fresh, locked: a.locked }) / 100; // disabled: credit was saved when it was disabled
        if (a.lead_id && left > 0) run("INSERT INTO meta_credits(lead_id, amount, act_id, reason, status, created_at) VALUES(?,?,?,'unshared','open',?)", a.lead_id, money(left), a.act_id, now());
        run('UPDATE meta_accounts SET spent=?, cap=? WHERE act_id=?', fresh.spent, fresh.cap, a.act_id);
        done.push(left > 0 ? `${usd(left)} saved as credit` : 'no balance left');
        a.step = 'credit';
        (a as Acct & { _credit?: number })._credit = left;
      } else if (st === 'reset') {
        if (!DISABLED.includes(a.status)) {
          await graph(c, 'POST', `act_${a.act_id}`, { spend_cap_action: 'reset' });
          await setCap(c, a.act_id, lockCents());
          const fresh = await readAcct(c, a.act_id);
          run('UPDATE meta_accounts SET spent=?, cap=? WHERE act_id=?', fresh.spent, fresh.cap, a.act_id);
          done.push('spend reset');
        }
      }
    }
    const credit = (a as Acct & { _credit?: number })._credit || 0;
    // v152: the name goes back to "Adsbhai N"
    const back = (bm.profile_id ? (() => { const st = getSettings(); return (st.meta_name_pattern || '{brand} {n}').replace(/\{brand\}/g, st.brand_name || 'Adsbhai').replace(/\{n\}/g, String(a.no)); })() : a.base_name || null); // v153: profile accounts always go back to the pattern ("Adsbhai 3")
    if (back && back !== a.name) {
      try { JOB.step(`Renamed back: ${back}`); await graph(c, 'POST', 'act_' + a.act_id, { name: back.slice(0, 100) }); run('UPDATE meta_accounts SET name=?, base_name=NULL, partner_name=NULL, biz_name=NULL WHERE act_id=?', back.slice(0, 100), a.act_id); done.push('renamed back'); }
      catch (e) { done.push('rename failed: ' + (e as Error).message.slice(0, 80)); }
    }
    finishUnshare(a, actor, `${done.join(' · ')}`, credit);
    // v155: the old client is still a partner (Meta #3) → out of stock until a manager removed it and taps Mark free
    if (leftByHand.length) run("UPDATE meta_accounts SET step='check', err=? WHERE act_id=?", `Remove partner ${leftByHand.map(x => 'BM ' + x).join(', ')} by hand, then Mark free`, a.act_id);
    return { ok: true, done, credit };
  });
}

function finishUnshare(a: Acct, actor: Actor, note: string, credit: number) {
  const disabledNow = DISABLED.includes(a.status);
  tx(() => {
    run(`UPDATE meta_accounts SET locked=0, state=?, lead_id=NULL, post_wait=NULL, post_ready=0, share_mode=NULL, client_bm=NULL, extra_bms=NULL, client_email=NULL, invite_id=NULL, buser_id=NULL, assigned_at=NULL, low_sent=0, step=NULL, err=NULL, partner_name=NULL, biz_name=NULL, proof_at=NULL, share_msg=0, repl_of=NULL WHERE act_id=?`,
      disabledNow ? 'disabled' : 'free', a.act_id);
    log('unshare', { act_id: a.act_id, lead_id: a.lead_id, amount: credit, note, by: by(actor) });
  });
  const lead = a.lead_id ? leadById(a.lead_id) : undefined;
  if (lead) addMsg(lead, { dir: 'sys', sender: 'system', text: `↩️ ${acctName(a)} (act_${a.act_id}) taken back: ${note.replace(/\$[\d,.]+ saved as credit/g, 'balance saved as credit')}` });
}

/** v166: Meta refused to remove it (permission) — not the same as "already gone" for a partner BM */
const noPermRemove = (e: unknown) => e instanceof MetaError && /no permission to remove/i.test(e.message);
async function ignoreGone<T>(fn: () => Promise<T>, permIsGone = true) {
  try { return await fn(); }
  catch (e) {
    // already removed / not found → fine
    if (!permIsGone && noPermRemove(e)) throw e; // v166: a partner Meta would not let us remove is still there
    if (e instanceof MetaError && (e.code === 100 || /does not exist|not found|cannot be loaded|not associated|no permission to remove/i.test(e.message)) && e.kind === 'meta') return null;
    throw e;
  }
}

export async function renameAcct(act: string, name: string | null) {
  const a = acctOf(act);
  if (!a) throw new HttpError(404, 'Ad account not found');
  const bm = bmOf(a.bm_id);
  if (!bm) throw new HttpError(400, 'BM removed');
  if (viaQueue(bm)) return { ok: true, queued: true, job: enqueueFor(bm, 'rename', a.act_id, { name }, { role: 'admin', id: null, name: 'Admin' }, 6) };
  const s = getSettings();
  const n = (name || '').trim() || s.meta_name_pattern.replace(/\{brand\}/g, s.brand_name).replace(/\{n\}/g, String(a.no));
  await graph(creds(bm), 'POST', 'act_' + a.act_id, { name: n.slice(0, 100) });
  run('UPDATE meta_accounts SET name=? WHERE act_id=?', n.slice(0, 100), a.act_id);
  return { ok: true, name: n };
}

/** v153: the client's other BMs that also have this account. */
export const extraBms = (a: { extra_bms?: string | null }) => { try { const v = JSON.parse(a.extra_bms || '[]'); return Array.isArray(v) ? v.map(String) : []; } catch { return []; } };
/** v153: share an account the client already has to one more of their BMs (same account, same limit). */
export async function addBmAcct(act: string, bmIdRaw: unknown, actor: Actor) {
  const bmId = String(bmIdRaw || '').replace(/\D/g, '');
  if (bmId.length < 8 || bmId.length > 20) throw new HttpError(400, 'Enter the client’s other Business Manager ID (numbers only)');
  const a0 = acctOf(act);
  if (!a0) throw new HttpError(404, 'Ad account not found');
  const bm0 = bmOf(a0.bm_id);
  if (!bm0) throw new HttpError(400, 'BM removed');
  if (a0.state !== 'assigned' || a0.share_mode !== 'bm') throw new HttpError(400, 'This account is not shared to a client BM');
  if (bmId === a0.client_bm || extraBms(a0).includes(bmId)) throw new HttpError(400, 'Already shared to that BM');
  if (bmId === bm0.bm_id) throw new HttpError(400, 'That is our own BM ID');
  if (viaQueue(bm0)) return { ok: true, queued: true, job: enqueueFor(bm0, 'add_bm', a0.act_id, { bm: bmId }, actor, 2) };
  return withLock(cleanAct(act), async (a, bm) => {
    if (a.state !== 'assigned') throw new HttpError(400, `${acctName(a)} is not with a client`);
    if (bmId === a.client_bm || extraBms(a).includes(bmId)) return { ok: true, bms: [a.client_bm, ...extraBms(a)] };
    const c = creds(bm);
    if (bm.profile_id && getSettings().mq_partner_hand !== '0') {
      JOB.step(`Checking partner BM ${bmId} on Meta`);
      const ag = await graphAll<{ id: string; name?: string }>(c, `act_${a.act_id}/agencies`, { fields: 'id,name', limit: 50 }, 2);
      if (!ag.some(x => String(x.id) === bmId)) throw new HttpError(400, `BM ${bmId} is not a partner of ${acctName(a)} yet. Assign it in Business Settings first, then tap Share again.`);
      JOB.step(`Partner found: BM ${bmId}`);
    } else {
      JOB.step(`Assigning partner: BM ${bmId}`);
      await graph(c, 'POST', `act_${a.act_id}/agencies`, { business: bmId, permitted_tasks: TASKS });
      JOB.step(`Partner assigned: BM ${bmId}`);
    }
    const list = [...extraBms(a), bmId];
    run('UPDATE meta_accounts SET extra_bms=? WHERE act_id=?', JSON.stringify(list), a.act_id);
    log('share', { act_id: a.act_id, lead_id: a.lead_id, agent_id: null, amount: 0, note: `also to BM ${bmId}`, by: by(actor) });
    const lead = a.lead_id ? leadById(a.lead_id) : undefined;
    if (lead) addMsg(lead, { dir: 'sys', sender: 'system', text: `🎉 ${acctName(a)} (act_${a.act_id}) also shared to BM ${bmId}` });
    return { ok: true, bms: [a.client_bm, ...list] };
  });
}

/** v153: an account already with the client (shared by hand): read the partner's name on Meta, set the name "Adsbhai X …", proof images + post. Inside the queue. */
export async function finishShare(act: string, actor: Actor) {
  const a0 = acctOf(act);
  if (!a0) throw new HttpError(404, 'Ad account not found');
  const bm0 = bmOf(a0.bm_id);
  if (!bm0) throw new HttpError(400, 'BM removed');
  if (a0.state !== 'assigned' || !a0.lead_id) throw new HttpError(400, `${acctName(a0)} is not with a client`);
  if (viaQueue(bm0)) return { ok: true, queued: true, job: enqueueFor(bm0, 'finish', a0.act_id, {}, actor, 2) };
  const c = creds(bm0);
  const lead = leadById(a0.lead_id)!;
  let partner: string | null = null;
  if (a0.client_bm) {
    JOB.step(`Checking partner BM ${a0.client_bm} on Meta`);
    const ag = await graphAll<{ id: string; name?: string }>(c, `act_${a0.act_id}/agencies`, { fields: 'id,name', limit: 50 }, 2);
    const hit = ag.find(x => String(x.id) === a0.client_bm);
    if (!hit) throw new HttpError(400, `BM ${a0.client_bm} is not a partner of ${acctName(a0)} on Meta yet. Assign it in Business Settings, then tap Finish again.`);
    partner = hit.name || null;
    JOB.step(`Partner found: ${partner || 'BM ' + a0.client_bm}`);
  }
  const p = profileById(bm0.profile_id);
  const biz = (a0.biz_name || partner || '').slice(0, 40);
  const nm = clientAcctName(bm0.name, displayName(lead), p?.ix, biz);
  run('UPDATE meta_accounts SET base_name=COALESCE(base_name, name), partner_name=?, biz_name=? WHERE act_id=?', partner || (a0.client_bm ? 'BM ' + a0.client_bm : null), biz || null, a0.act_id);
  if (nm !== a0.name) { await graph(c, 'POST', 'act_' + a0.act_id, { name: nm }); run('UPDATE meta_accounts SET name=? WHERE act_id=?', nm, a0.act_id); JOB.step(`Renamed: ${nm}`); }
  const fresh = await readAcct(c, a0.act_id);
  run('UPDATE meta_accounts SET spent=?, cap=? WHERE act_id=?', fresh.spent, fresh.cap, a0.act_id);
  log('share', { act_id: a0.act_id, lead_id: a0.lead_id, agent_id: null, amount: 0, note: 'finished (partner by hand)', by: by(actor) });
  return { ok: true, name: nm };
}

/** Manager did it by hand in Ads Manager (API blocked): update our records only. */
export function manualAction(act: string, b: Record<string, unknown>, actor: Actor) {
  const a = acctOf(act);
  if (!a) throw new HttpError(404, 'Ad account not found');
  const kind = String(b.kind);
  if (kind === 'free') {
    if (a.lead_id && a.state !== 'disabled') {
      const credit = money(b.credit ?? remaining(a) / 100);
      if (credit > 0) run("INSERT INTO meta_credits(lead_id, amount, act_id, reason, status, created_at) VALUES(?,?,?,'unshared','open',?)", a.lead_id, credit, a.act_id, now());
      finishUnshare(a, actor, `done by hand${credit > 0 ? ` · ${usd(credit)} saved as credit` : ''}`, credit);
    } else {
      run("UPDATE meta_accounts SET state=CASE WHEN status IN (2,100,101) THEN 'disabled' ELSE 'free' END, lead_id=NULL, post_wait=NULL, post_ready=0, share_mode=NULL, client_bm=NULL, extra_bms=NULL, client_email=NULL, invite_id=NULL, buser_id=NULL, step=NULL, err=NULL, partner_name=NULL, biz_name=NULL, proof_at=NULL, share_msg=0, repl_of=NULL WHERE act_id=?", a.act_id);
      log('unshare', { act_id: a.act_id, lead_id: a.lead_id, note: 'marked free by hand', by: by(actor) });
    }
    return { ok: true };
  }
  if (kind === 'topup') {
    const amount = money(b.amount);
    if (!(amount > 0)) throw new HttpError(400, 'Enter the amount you added');
    run('UPDATE meta_accounts SET cap=CASE WHEN locked=1 THEN spent ELSE MAX(cap, spent) END+?, locked=0 WHERE act_id=?', cents(amount), a.act_id);
    log(b.credit ? 'credit_in' : 'topup', { act_id: a.act_id, lead_id: a.lead_id, paid: b.credit ? 0 : num(b.paid) || amount, fee: b.credit ? null : b.fee === '' || b.fee == null ? null : num(b.fee), amount, note: b.credit ? 'client credit, done by hand' : 'done by hand', by: by(actor) }); // v177: credit is not a new top-up
    const after = acctOf(a.act_id)!;
    if (b.notify !== false && a.lead_id) void tellClient(leadById(a.lead_id), 'meta_msg_topup', { acts: [a.act_id], amount, balance: remaining(after) / 100 });
    return { ok: true };
  }
  if (kind === 'share') {
    const lead = leadById(num(b.lead_id));
    if (!lead) throw new HttpError(404, 'Client chat not found');
    // v155: never take an account away from another client (or a disabled one)
    if (!(a.state === 'free' || (a.lead_id === lead.id && ['assigned', 'invited'].includes(a.state)))) throw new HttpError(400, `${acctName(a)} is ${a.state === 'disabled' ? 'disabled' : 'with another client'}. Pick a free account.`);
    if (a.state === 'free' && (a.step === 'check' || a.step === 'partner_by_hand')) throw new HttpError(400, `${acctName(a)} is kept out of stock${a.err ? ` (${a.err})` : ''}. Check it on Meta, then Mark free.`); // v166
    const mode = b.mode === 'email' ? 'email' : 'bm';
    const credit = openCredit(lead.id);
    tx(() => {
      run("UPDATE meta_accounts SET state='assigned', lead_id=?, share_mode=?, client_bm=?, client_email=?, assigned_at=?, low_sent=0, step=NULL, err=NULL, locked=? WHERE act_id=?",
        lead.id, mode, mode === 'bm' ? String(b.client_bm || '').replace(/\D/g, '') : null, mode === 'email' ? String(b.client_email || '').trim() : null, now(), credit > 0 ? 0 : 1, a.act_id);
      if (credit > 0) run("UPDATE meta_credits SET status='used', used_act=?, used_at=? WHERE lead_id=? AND status='open'", a.act_id, now(), lead.id);
      log('share', { act_id: a.act_id, lead_id: lead.id, agent_id: lead.agent_id, amount: credit, note: 'done by hand', by: by(actor) });
    });
    saveLeadAccounts(lead.id, [a.act_id], { source: 'meta' });
    const repl = b.replace ? String(b.replace) : null; // v156
    if (repl) run('UPDATE meta_accounts SET repl_of=? WHERE act_id=?', repl, a.act_id);
    addMsg(lead, { dir: 'sys', sender: 'system', text: `${repl ? `🔁 Replacement for act_${repl}: ` : '🎉 '}${acctName(a)} (act_${a.act_id}) given to this client (done by hand)` });
    const after = acctOf(a.act_id)!;
    if (b.notify !== false) void tellClient(leadById(lead.id), mode === 'bm' ? (repl ? 'meta_msg_replace' : 'meta_msg_share') : 'meta_msg_invite', { acts: [a.act_id], bm: after.client_bm, email: after.client_email, balance: remaining(after) / 100 });
    return { ok: true };
  }
  if (kind === 'sold_before') {
    // v153: an account sold by hand before this system → recorded as the client's. Nothing is sent to Meta or to the client.
    if (a.state !== 'free') throw new HttpError(400, `${acctName(a)} is not free (${a.state})`);
    const bmId = String(b.client_bm || '').replace(/\D/g, '');
    if (bmId.length < 8 || bmId.length > 20) throw new HttpError(400, 'Enter the client’s Business Manager ID (numbers only)');
    let lead = b.lead_id ? leadById(num(b.lead_id)) : undefined;
    if (b.lead_id && !lead) throw new HttpError(404, 'Client chat not found');
    if (!lead) {
      const name = String(b.client_name || '').trim();
      if (!name) throw new HttpError(400, 'Enter the client’s name');
      // eslint-disable-next-line @typescript-eslint/no-require-imports
      const Q = require('./metaq') as typeof import('./metaq');
      lead = leadById(Q.clientLead(name, 'manual'))!;
    }
    tx(() => {
      // partner_name '' = not ours to rename (the automatic "finish" after an update skips it)
      run("UPDATE meta_accounts SET state='assigned', lead_id=?, share_mode='bm', client_bm=?, client_email=NULL, invite_id=NULL, assigned_at=?, low_sent=0, step=NULL, err=NULL, locked=0, partner_name='' WHERE act_id=?", lead!.id, bmId, now(), a.act_id);
      log('share', { act_id: a.act_id, lead_id: lead!.id, agent_id: lead!.agent_id, amount: 0, note: `sold before this system · BM ${bmId}`, by: by(actor) });
    });
    saveLeadAccounts(lead.id, [a.act_id], { bm: bmId, source: 'meta' });
    return { ok: true, lead_id: lead.id };
  }
  throw new HttpError(400, 'Unknown action');
}

/* ======================= picking a free account ======================= */
export function freeAccounts(tier = 'any') {
  const rows = all<Acct & { verification: string | null; bstatus: string }>(
    `SELECT a.*, CASE WHEN COALESCE(b.verified_since,'')!='' THEN 'verified' ELSE b.verification END verification, b.status bstatus FROM meta_accounts a JOIN meta_bms b ON b.bm_id=a.bm_id AND b.deleted=0
     WHERE a.state='free' AND a.status NOT IN (2,100,101) AND COALESCE(a.busy,0)=0 AND COALESCE(a.step,'')!='check' ORDER BY (b.status='ok') DESC, a.no`);
  return rows.filter(r => tier === 'any' || (tier === 'premium' || tier === 'std' ? catOf(r) === tier : tierOf(r.verification) === tier));
}

/* ======================= requests (agent → manager approval) ======================= */
const reqById = (id: unknown) => one<Req>('SELECT * FROM meta_requests WHERE id=?', num(id));

export async function createRequest(actor: Actor, b: Record<string, unknown>, lead: Lead) {
  const s = getSettings();
  const kind = b.kind === 'topup' ? 'topup' : b.kind === 'replace' ? 'replace' : 'account';
  // v160: master switch OFF → agents can still ask for a top-up (it always goes to the manager); new accounts / replacements stay off
  if (!metaEnabled() && actor.role === 'agent' && kind !== 'topup') throw new HttpError(400, 'The ad account system is switched off (Admin → Ad accounts)');
  if (kind === 'replace') return createReplace(actor, b, lead);
  // link = our crypto payment link (checked automatically) · upi / crypto = paid by hand (UPI or crypto straight to our wallet): the manager checks it
  const method = ['link', 'upi', 'crypto', 'manual', 'credit'].includes(String(b.method)) ? String(b.method) : 'upi';
  if (actor.role === 'agent' && method === 'manual') throw new HttpError(400, 'Choose how the client paid');
  let paid = 0, fee = 0, amount = 0, payCode: string | null = null;
  let act = cleanAct(b.act_id);
  const pct = topupFee(lead, 0, s).pct; // v166: the chat's fee % (Premium has its own); the fee itself comes from topupFee (+ the offer's free part)
  if (method === 'link') {
    const l = one<{ id: number; code: string; kind: string; status: string; amount: number; fee: number; total: number; lead_id: number; act_id: string | null }>('SELECT * FROM pay_links WHERE code=?', String(b.pay_code || '').trim().toUpperCase());
    if (!l || l.lead_id !== lead.id) throw new HttpError(400, 'Choose a payment link of this chat');
    if (l.status !== 'paid') throw new HttpError(400, 'That payment link is not paid yet');
    if ((kind === 'topup') !== (l.kind === 'topup')) throw new HttpError(400, kind === 'topup' ? 'Choose a top-up payment link' : 'Choose an ad account payment link');
    if (one("SELECT 1 FROM meta_requests WHERE pay_code=? AND status NOT IN ('rejected')", l.code)) throw new HttpError(400, 'That payment was already used');
    payCode = l.code; paid = l.total;
    if (kind === 'topup') { amount = l.amount; fee = l.fee; if (!act && l.act_id) act = l.act_id; }
  } else if (kind === 'topup' && method === 'credit') {
    // v177 (owner): the client's credit (old balance) put on one of their accounts: no fee, no new top-up record, the credit is used up
    const cr = openCredit(lead.id);
    if (!(cr > 0)) throw new HttpError(400, 'This client has no credit');
    amount = money(b.amount) > 0 ? money(b.amount) : cr;
    if (amount > cr + 0.004) throw new HttpError(400, `The client has only ${usd(cr)} credit`);
    fee = 0; paid = 0;
  } else if (kind === 'topup') {
    // v157: the amount typed = what goes on the account; the fee comes on top (client pays amount + fee)
    if (money(b.amount) > 0) { amount = money(b.amount); fee = topupFee(lead, amount, s).fee; paid = money(amount + fee); }
    else { paid = money(b.paid); fee = money(paid * pct / 100); amount = money(paid - fee); }
    if (!(amount > 0)) throw new HttpError(400, 'Enter the top-up amount (USD)');
  } else if (method !== 'credit') paid = money(b.paid);
  // v156: an account not in our system (sold before / other BM) → the manager tops it up by hand in Ads Manager, then Done by hand
  let ext = 0;
  if (kind === 'topup') {
    const a = acctOf(act);
    if (!a && b.ext && act.length >= 6) ext = 1;
    else if (!a || (actor.role === 'agent' && a.lead_id !== lead.id)) throw new HttpError(400, 'Choose one of this client’s ad accounts');
  }
  const mode = b.mode === 'email' ? 'email' : 'bm';
  const clientBm = String(b.client_bm || '').replace(/\D/g, '');
  const email = String(b.client_email || '').trim().toLowerCase();
  if (kind === 'account') {
    if (mode === 'bm' && (clientBm.length < 8 || clientBm.length > 20)) throw new HttpError(400, 'Enter the client’s Business Manager ID (numbers only)');
    if (mode === 'email' && !emailInvitesOn()) throw new HttpError(400, 'Email invites are switched off. Ask the client for their Business Manager ID.');
    if (mode === 'email' && !/^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(email)) throw new HttpError(400, 'Enter the client’s Facebook email');
    if (method === 'credit' && !(openCredit(lead.id) > 0)) throw new HttpError(400, 'This client has no credit');
  }
  const tier = actor.role === 'agent' && mode === 'email' ? 'any' : ['verified', 'review', 'unverified', 'premium', 'std'].includes(String(b.tier)) ? String(b.tier) : 'any';
  const agentId = actor.role === 'agent' || actor.role === 'manager' ? actor.id : lead.agent_id;
  // v165: the account was sold in the chat already (its request waits in Requests) → this Give fills that request, never a 2nd one
  // first a not-yet-filled one (one per sold account), else one that failed / waits for a hand finish; one being given right now → wait
  const fromSale = kind === 'account' ? one<{ id: number }>(`SELECT id FROM meta_requests WHERE lead_id=? AND kind='account' AND sale_id IS NOT NULL
      AND ((by_role='sale' AND status='pending') OR status IN ('failed','manual')) ORDER BY (by_role='sale') DESC, id LIMIT 1`, lead.id) : undefined;
  if (kind === 'account' && !fromSale && method !== 'credit' && method !== 'link' && one("SELECT 1 FROM meta_requests WHERE lead_id=? AND kind='account' AND sale_id IS NOT NULL AND status IN ('queued','running')", lead.id)
    && !one("SELECT 1 FROM sales x WHERE x.lead_id=? AND x.service='account' AND x.created_at>? AND NOT EXISTS(SELECT 1 FROM meta_requests r WHERE r.sale_id=x.id)", lead.id, now() - 6 * 3600_000))
    throw new HttpError(409, 'The account for this sale is being given right now (Ad accounts → Requests / Queue). Wait for it; for a NEW account mark the sale first.');
  let reqId: number;
  if (fromSale) {
    run('UPDATE meta_requests SET act_id=COALESCE(?, act_id), tier=?, mode=?, client_bm=?, client_email=?, method=?, pay_code=?, paid=COALESCE(?, paid), biz_name=COALESCE(?, biz_name), by_role=? WHERE id=?',
      act || null, tier, mode, mode === 'bm' ? clientBm : null, mode === 'email' ? email : null, method, payCode, paid || null, String(b.biz_name || '').trim().slice(0, 40) || null, actor.role, fromSale.id);
    reqId = fromSale.id;
  } else reqId = Number(run(`INSERT INTO meta_requests(kind, lead_id, agent_id, act_id, tier, mode, client_bm, client_email, paid, fee, amount, method, pay_code, note, status, created_at, biz_name, manual, ext, by_role)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,'pending',?,?,?,?,?)`, kind, lead.id, agentId, act || null, kind === 'account' ? tier : null, kind === 'account' ? mode : null,
    kind === 'account' && mode === 'bm' ? clientBm : null, kind === 'account' && mode === 'email' ? email : null, paid || null, kind === 'topup' ? fee : fee || null, amount || null, method, payCode, String(b.note || '').slice(0, 300) || null, now(),
    String(b.biz_name || '').trim().slice(0, 40) || null, (lead as Lead & { manual_client?: number }).manual_client ? 1 : 0, ext, actor.role).lastInsertRowid);
  // v153: a top-up the client paid together with the account → added to the limit at the share
  if (kind === 'account' && (money(b.topup_amount) > 0 || money(b.topup_paid) > 0)) {
    // v157: topup_amount = what goes on the account (fee on top); old topup_paid = what the client paid (fee taken out)
    const ta = money(b.topup_amount);
    const tf = ta > 0 ? topupFee(lead, ta, s).fee : money(money(b.topup_paid) * pct / 100);
    const tp = ta > 0 ? money(ta + tf) : money(b.topup_paid);
    run('UPDATE meta_requests SET add_paid=?, add_fee=?, add_amount=? WHERE id=?', tp, tf, money(tp - tf), reqId);
  }
  const req = reqById(reqId)!;
  // v171 (owner): Give with a picked account that the manager / admin already shared in Meta by hand → no share again, Done by hand
  if (kind === 'account' && b.hand && act && actor.role !== 'agent') { const out = await requestDoneByHand(req.id, actor, { act_id: act }); return { done: true, name: acctName(acctOf(act)!), ...(out as object) }; }
  const what = reqSummary(req);
  // who can do it right away
  const ag = actor.role === 'agent' ? one<{ auto_acct: number; auto_topup: number }>('SELECT auto_acct, auto_topup FROM agents WHERE id=?', actor.id) : null;
  // Email invites put the client inside our BM (they can see if it is verified), so only the manager sends them: never auto for agents.
  const emailShare = kind === 'account' && mode === 'email';
  // v152: master "Auto approve" (Ad accounts → Settings) must be ON for an agent's request to go without the manager
  // v156: top-ups: master Auto approve ON + the agent's "auto top-up" → done right away for every payment (link, UPI, crypto direct).
  // An account not in the system always goes to the manager (done by hand in Ads Manager).
  // v160: the admin's top-up from a chat goes to the manager (b.to_manager); master switch OFF → an agent's request always waits for the manager
  const toMgr = actor.role === 'admin' && kind === 'topup' && !!b.to_manager && managers().length > 0;
  // v173 (owner): Give from a CHAT with no account picked → Requests (the account is chosen there), for the admin and the manager too
  const toReq = kind === 'account' && !!b.chat; // v173 (owner + QA): from a chat EVERY role only makes the request; the account is chosen in Requests
  const auto = !ext && !toMgr && !toReq && (actor.role !== 'agent' || (metaEnabled() && s.mq_auto_approve !== '0' && !emailShare && ((kind === 'topup' && !!ag?.auto_topup) || (method === 'link' && kind === 'account' && !!ag?.auto_acct) || (method === 'credit' && kind === 'account' && !!ag?.auto_acct))));
  if (auto) return runRequest(req.id, actor);
  addMsg(lead, { dir: 'sys', sender: 'system', agent_id: agentId, text: `📤 Sent to manager for approval: ${what}` });
  // v160: the client is told which account and that the top-up request went to the manager (the "Top-up done" message + image follow on approval)
  if (kind === 'topup' && !ext && act && b.tell_client !== false) { try { await tellClient(lead, 'meta_msg_topup_req', { acts: [act], amount }); } catch { /* */ } }
  await alertTeam(ext ? '✋ Top-up by hand (account not in the system)' : `📥 Approve: ${kind === 'account' ? 'ad account' : 'top-up'}`, `${displayName(lead)} · ${what}${actor.role === 'agent' ? ' · by ' + actor.name : ''}${ext ? ' · add it in Ads Manager, then Done by hand' : ''}${method === 'upi' ? ' · check the UPI payment' : method === 'crypto' ? ' · check the crypto payment in the wallet' : ''}${emailShare ? ' · email invite: choose the account type yourself' : ''}`, lead.id);
  return { ok: true, pending: true, request: pubReq(reqById(req.id)!) };
}

function reqSummary(r: Req) {
  const pay = r.method === 'replace' ? 'replacement' : r.method === 'link' ? `paid ${usd(r.paid || 0)} by crypto (${r.pay_code})` : r.method === 'upi' ? `UPI ${r.paid ? usd(r.paid) : ''}`.trim() : r.method === 'crypto' ? `crypto direct ${r.paid ? usd(r.paid) : ''}`.trim() : r.method === 'credit' ? 'from credit' : 'paid';
  if (r.kind === 'topup') return `Top-up ${usd(r.amount || 0)} → act_${r.act_id}${r.ext ? ' (not in the system: by hand)' : ''} (${pay}${r.fee ? `, fee ${usd(r.fee)}` : ''})`;
  if (r.kind === 'replace') return `Replacement for ${r.old_act ? 'act_' + r.old_act : 'old account'} → ${r.client_bm ? 'BM ' + r.client_bm : 'no BM yet'}${r.tier && r.tier !== 'any' ? ` (${CAT_LABEL[r.tier] || TIER_LABEL[r.tier] || r.tier})` : ''}`;
  const kind = r.tier === 'std' ? '$25 ad account' : r.tier === 'premium' ? 'Premium ad account' : r.tier && TIER_LABEL[r.tier] && r.tier !== 'any' ? `${TIER_LABEL[r.tier]} ad account` : 'Ad account';
  return `${kind} → ${r.mode === 'email' ? r.client_email : r.client_bm ? 'BM ' + r.client_bm : 'no BM yet'} (${pay})`;
}

/** Do the request (manager approved / auto). API blocked → "Do manually". */
/** v173 (owner): Requests → set / change the top-up that goes on WITH the account (USD on the account; the fee comes on top). */
function setReqTopup(r: Req, v: unknown) {
  if (v === undefined || v === null || v === '' || !['account', 'replace'].includes(r.kind) || r.rec_at) return;
  if (!Number.isFinite(Number(v))) throw new HttpError(400, 'Enter the top-up amount in USD');
  const ta = money(v);
  if (!(ta >= 0) || ta > 100000) throw new HttpError(400, 'Enter the top-up amount in USD');
  const lead = leadById(r.lead_id);
  // replace: the client's old balance typed by hand → goes on the new account's limit; no fee, no sale (not a top-up)
  const tf = ta > 0 && lead && r.kind === 'account' ? topupFee(lead, ta).fee : 0;
  run('UPDATE meta_requests SET add_paid=?, add_fee=?, add_amount=? WHERE id=?', ta > 0 ? money(ta + tf) : null, ta > 0 ? tf : null, ta > 0 ? ta : null, r.id);
}

export async function runRequest(id: unknown, actor: Actor, edit: Record<string, unknown> = {}) {
  let r = reqById(id);
  if (!r) throw new HttpError(404, 'Request not found');
  if (['pending', 'failed', 'manual'].includes(r.status) && edit.add_amount !== undefined) { setReqTopup(r, edit.add_amount); r = reqById(r.id)!; }
  if (!['pending', 'failed', 'manual', 'queued'].includes(r.status)) throw new HttpError(400, `Already ${r.status}`);
  if (r.status === 'queued' && !JOB.active) throw new HttpError(400, 'Already in the queue');
  if (edit.act_id !== undefined || edit.client_bm !== undefined || edit.client_email !== undefined || edit.tier !== undefined) {
    run('UPDATE meta_requests SET act_id=COALESCE(?, act_id), client_bm=COALESCE(?, client_bm), client_email=COALESCE(?, client_email), tier=COALESCE(?, tier) WHERE id=?',
      cleanAct(edit.act_id) || null, String(edit.client_bm || '').replace(/\D/g, '') || null, String(edit.client_email || '').trim().toLowerCase() || null, edit.tier ? String(edit.tier) : null, r.id);
    r = reqById(r.id)!;
  }
  const lead = leadById(r.lead_id)!;
  // v156: an account not in the system → only by hand
  if (r.kind === 'topup' && r.ext) {
    run("UPDATE meta_requests SET status='manual', error=? WHERE id=?", 'This account is not in the system: add the top-up in Ads Manager, then tap Done by hand (records + client message follow).', r.id);
    return { ok: true, done: false, status: 'manual', error: reqById(r.id)!.error, request: pubReq(reqById(r.id)!) };
  }
  let act = r.kind === 'replace' ? (r.act_id && r.act_id !== r.old_act ? r.act_id : '') : r.act_id || '';
  // v152: an account of a profile BM → into the queue (the IP changes first); the worker comes back here with JOB.active
  {
    let pick = act;
    if (!pick && r.kind !== 'topup') pick = freeAccounts(r.tier || 'any').filter(x => x.bstatus === 'ok')[0]?.act_id || '';
    const pa = pick ? acctOf(pick) : undefined, pbm = pa ? bmOf(pa.bm_id) : undefined;
    if (pbm && viaQueue(pbm)) {
      const job = enqueueFor(pbm, 'request', String(r.id), {}, actor, r.kind === 'topup' ? 1 : 2);
      run("UPDATE meta_requests SET status='queued', job_id=?, error=NULL WHERE id=?", job.id, r.id);
      if (lead) addMsg(lead, { dir: 'sys', sender: 'system', text: `⏳ In the queue: ${reqSummary(reqById(r.id)!)} · about ${job.eta_min} min` });
      if (r.kind === 'topup' && !r.ext) void import('./topupq').then(T => T.topupQueued(r.id, job.eta_min)).catch(() => 0); // v160: the client sees it is in the queue
      return { ok: true, done: false, queued: true, job, request: pubReq(reqById(r.id)!) };
    }
  }
  if (!run("UPDATE meta_requests SET status='running' WHERE id=? AND status IN ('pending','failed','manual','queued')", r.id).changes) throw new HttpError(409, 'Already running');
  try {
    let res: Record<string, unknown>;
    if (r.kind === 'account' || r.kind === 'replace') {
      if (!act) {
        const free = freeAccounts(r.tier || 'any').filter(x => x.bstatus === 'ok' && (!JOB.active || !JOB.profileId || bmOf(x.bm_id)?.profile_id === JOB.profileId));
        if (!free.length) throw new HttpError(400, `No free ${r.tier && r.tier !== 'any' ? (CAT_LABEL[r.tier] || TIER_LABEL[r.tier] || '').toLowerCase() + ' ' : ''}ad account. Add accounts or pick another type.`);
        act = free[0].act_id;
        run('UPDATE meta_requests SET act_id=? WHERE id=?', act, r.id);
      }
      const rr = r as Req & { add_paid?: number | null; add_fee?: number | null; add_amount?: number | null };
      res = await shareAcct(act, { lead_id: lead.id, mode: r.mode === 'email' ? 'email' : 'bm', client_bm: r.client_bm || '', client_email: r.client_email || '', agent_id: r.agent_id, biz_name: r.biz_name, add: rr.add_amount || 0, paid: rr.add_paid || undefined, fee: rr.add_fee ?? undefined, replace: r.kind === 'replace' ? (r.old_act || 'old') : null }, actor);
    } else {
      res = await topupAcct(act, { amount: r.amount || 0, paid: r.paid || 0, fee: r.fee ?? undefined, agent_id: r.agent_id, imageFirst: JOB.active, note: r.method === 'link' ? `crypto ${r.pay_code}` : r.method === 'credit' ? 'client credit' : r.method, credit: r.method === 'credit' }, actor);
    }
    run("UPDATE meta_requests SET status='done', error=NULL, done_at=?, done_by=? WHERE id=?", now(), by(actor), r.id);
    await recordReq(r.id);
    const ag = agentById(r.agent_id);
    if (ag && ag.id !== actor.id) void notifyAgent(ag, `✅ Done: ${reqSummary(reqById(r.id)!)} for ${displayName(lead)}`, lead.id); // v155: no phone push for system work (the chat shows it)
    return { ok: true, done: true, ...res, request: pubReq(reqById(r.id)!) };
  } catch (e) {
    // v152: inside the queue the worker decides (retry once on a network drop, then fail + alert)
    if (JOB.active) { run("UPDATE meta_requests SET error=? WHERE id=?", ((e as Error).message || 'Error').slice(0, 300), r.id); throw e; }
    const blocked = e instanceof MetaError && (e.kind === 'token' || e.kind === 'perm' || e.kind === 'net');
    const msg = (e as Error).message || 'Error';
    const a = act ? acctOf(act) : undefined;
    const bm = a ? bmOf(a.bm_id) : undefined;
    run('UPDATE meta_requests SET status=?, error=? WHERE id=?', blocked ? 'manual' : 'failed', blocked ? `API not working on ${bmName(bm)}: ${msg}. Fix the token or do it by hand in Ads Manager, then tap “Done by hand”.` : msg, r.id);
    if (blocked || actor.role === 'agent') await alertTeam(blocked ? `✋ Do by hand: ${r.kind === 'topup' ? 'top-up' : r.kind === 'replace' ? 'replacement' : 'ad account'}` : '⚠️ Request failed', `${displayName(lead)} · ${reqSummary(reqById(r.id)!)}\n${blocked ? `API not working on ${bmName(bm)}: either update its token or do it in Ads Manager and tap “Done by hand”.` : msg}`, lead.id);
    if (e instanceof HttpError && !blocked && actor.role !== 'agent') throw e;
    return { ok: true, done: false, status: blocked ? 'manual' : 'failed', error: reqById(r.id)!.error, request: pubReq(reqById(r.id)!) };
  }
}

export function rejectRequest(id: unknown, actor: Actor, note: unknown) {
  const r = reqById(id);
  if (!r || !['pending', 'failed', 'manual'].includes(r.status)) throw new HttpError(400, 'Request not open');
  run("UPDATE meta_requests SET status='rejected', error=?, done_at=?, done_by=? WHERE id=?", String(note || '').slice(0, 300) || null, now(), by(actor), r.id);
  const lead = leadById(r.lead_id);
  if (lead) {
    addMsg(lead, { dir: 'sys', sender: 'system', text: `🚫 Manager rejected: ${reqSummary(r)}${note ? ' · ' + note : ''}` });
    void notifyAgent(agentById(r.agent_id), `🚫 Rejected: ${reqSummary(r)} for ${displayName(lead)}${note ? ' · ' + note : ''}`, lead.id, { title: '🚫 Request rejected', body: displayName(lead) });
  }
  return { ok: true };
}

/** Manager did it in Ads Manager by hand. */
export function requestDoneByHand(id: unknown, actor: Actor, b: Record<string, unknown>) {
  let r = reqById(id);
  if (!r || !['pending', 'failed', 'manual'].includes(r.status)) throw new HttpError(400, 'Request not open');
  if (b.add_amount !== undefined) { setReqTopup(r, b.add_amount); r = reqById(r.id)!; } // v173
  // v156: top-up on an account that is not in our system: added by hand in Ads Manager → records + client message here
  if (r.kind === 'topup' && r.ext) {
    run("UPDATE meta_requests SET status='done', error='done by hand', done_at=?, done_by=? WHERE id=?", now(), by(actor), r.id);
    const lead = leadById(r.lead_id);
    if (lead) {
      addMsg(lead, { dir: 'sys', sender: 'system', text: `💰 ${usd(r.amount || 0)} added to act_${r.act_id} by hand (account not in the system)` });
      void tellClient(lead, 'meta_msg_topup_hand', { acts: [String(r.act_id)], amount: r.amount || 0 });
    }
    return recordReq(r.id).then(() => ({ ok: true }));
  }
  const act = cleanAct(b.act_id) || (r.kind === 'replace' && r.act_id === r.old_act ? '' : r.act_id) || '';
  if (!acctOf(act)) throw new HttpError(400, 'Choose the ad account you used');
  const pa = acctOf(act)!;
  const pbm = bmOf(pa.bm_id);
  // v153 (profile accounts): "Done by hand" = the partner was assigned by hand → the queue checks it and does all the rest
  if (r.kind !== 'topup' && r.mode !== 'email' && pbm?.profile_id && pa.step !== 'partner_by_hand') {
    if (pa.state === 'free') {
      run("UPDATE meta_requests SET act_id=?, status=CASE WHEN status IN ('manual','failed') THEN 'pending' ELSE status END, error=NULL WHERE id=?", act, r.id);
      return runRequest(r.id, actor);
    }
    if (pa.state === 'assigned' && pa.lead_id === r.lead_id) {
      run("UPDATE meta_requests SET status='done', act_id=?, error='done by hand', done_at=?, done_by=? WHERE id=?", act, now(), by(actor), r.id);
      void recordReq(r.id);
      return { ok: true, queued: true, job: enqueueFor(pbm, 'finish', act, {}, actor, 2) };
    }
  }
  if (r.kind !== 'topup' && pa.step === 'partner_by_hand' && pa.lead_id === r.lead_id) {
    // v153: limit, name and records were done by the queue; only the partner was assigned by hand
    run("UPDATE meta_accounts SET step=NULL WHERE act_id=?", act);
    run("UPDATE meta_requests SET status='done', act_id=?, error='partner assigned by hand', done_at=?, done_by=? WHERE id=?", act, now(), by(actor), r.id);
    void recordReq(r.id);
    const lead = leadById(r.lead_id);
    const af = acctOf(act)!;
    if (lead) { addMsg(lead, { dir: 'sys', sender: 'system', text: `🎉 ${acctName(af)} (act_${act}) shared to BM ${af.client_bm} (partner assigned by hand) · balance ${usd(remaining(af) / 100)}` }); if (getSettings().meta_proof_client !== '0' && lead.tg_chat_id) run('UPDATE meta_accounts SET share_msg=1 WHERE act_id=?', act); else void tellClient(lead, af.repl_of ? 'meta_msg_replace' : 'meta_msg_share', { acts: [act], bm: af.client_bm, balance: remaining(af) / 100 }); }
    const bmx = bmOf(af.bm_id);
    if (bmx?.profile_id) enqueueFor(bmx, 'proof', act, {}, actor, 3); // proof images + channel post (live data → queue)
    return { ok: true };
  }
  if (r.kind !== 'topup') manualAction(act, { kind: 'share', lead_id: r.lead_id, mode: r.mode, client_bm: r.client_bm, client_email: r.client_email, replace: r.kind === 'replace' ? (r.old_act || 'old') : null }, actor);
  else manualAction(act, { kind: 'topup', amount: r.amount, paid: r.paid, fee: r.fee, credit: r.method === 'credit' }, actor);
  if (r.kind === 'topup') void import('./topupq').then(T => T.topupQueueDone(r.id)).catch(() => 0); // v160: the queue message goes away
  run("UPDATE meta_requests SET status='done', act_id=?, error='done by hand', done_at=?, done_by=? WHERE id=?", act, now(), by(actor), r.id);
  return recordReq(r.id).then(() => ({ ok: true }));
}

/** v171: the free accounts the manager / admin can pick in the chat (Replace / Give): every free one, also on a BM whose API is
 *  blocked (for "shared by hand"); api_ok tells if the system can share it itself. */
export const freePickList = () => freeAccounts('any').map(a => ({ act_id: a.act_id, no: a.no, name: a.name, cat: catOf(a), api_ok: a.bstatus === 'ok', bm_name: bmOf(a.bm_id)?.name || a.bm_id }));

/** v156: replacement account (the client's account stopped working / was restricted). Agent → manager; manager → done now.
 *  Same client BM, same type. The old account's balance comes over by itself (it is in the client's credit when Meta disabled it).
 *  Records: only our account cost — no sale, no profit, no agent commission (the first sale already paid it). */
async function createReplace(actor: Actor, b: Record<string, unknown>, lead: Lead) {
  if (!metaEnabled() && actor.role === 'agent') throw new HttpError(400, 'The ad account system is switched off (Admin → Ad accounts)');
  // v170 (owner): the old account is OPTIONAL. If it is in the system with another chat (e.g. the same client's other chat, or an
  // account removed from the system), it is kept only as a note: nothing is taken from it and nothing is blocked.
  const oldAct = cleanAct(b.old_act || b.act_id) || null;
  if (oldAct && !acctOf(oldAct) && oldAct.length < 6) throw new HttpError(400, 'That old ad account ID doesn’t look right. Check it, or leave it empty.');
  const old0 = oldAct ? acctOf(oldAct) : undefined;
  const old = old0 && (!old0.lead_id || old0.lead_id === lead.id) ? old0 : undefined;
  const clientBm = String(b.client_bm || old?.client_bm || '').replace(/\D/g, '');
  if (clientBm.length < 8 || clientBm.length > 20) throw new HttpError(400, 'Enter the client’s Business Manager ID (numbers only)');
  if (oldAct && one("SELECT 1 FROM meta_requests WHERE kind='replace' AND lead_id=? AND old_act=? AND status IN ('pending','queued','running','manual','failed')", lead.id, oldAct)) throw new HttpError(400, 'A replacement for this account is already waiting (Requests)');
  const tier = ['premium', 'std', 'verified', 'review', 'unverified'].includes(String(b.tier)) ? String(b.tier) : (old ? catOf(old) : null) || 'any';
  // v171 (owner): the manager / admin picks the NEW account (else the system picks one); "hand" = already shared in Meta by hand →
  // nothing is shared again: it goes straight to "Done by hand" (client message, records, account saved to this client)
  const newAct = actor.role === 'agent' ? '' : cleanAct(b.new_act);
  const hand = !!newAct && !!b.hand;
  if (newAct) {
    const na = acctOf(newAct);
    if (!na) throw new HttpError(400, 'That new ad account is not in the system');
    if (newAct === oldAct) throw new HttpError(400, 'The new account can’t be the old one');
    const mineAlready = hand && na.lead_id === lead.id && ['assigned', 'invited'].includes(na.state);
    if (na.state !== 'free' && !mineAlready) throw new HttpError(400, `${acctName(na)} is not free${na.lead_id && na.lead_id !== lead.id ? ' (it is with another client)' : ''}. Pick a free account.`);
  }
  const agentId = actor.role === 'agent' || actor.role === 'manager' ? actor.id : lead.agent_id;
  const id = Number(run(`INSERT INTO meta_requests(kind, lead_id, agent_id, act_id, old_act, tier, mode, client_bm, method, note, status, created_at, manual, by_role)
    VALUES('replace',?,?,?,?,?,'bm',?,'replace',?,'pending',?,?,?)`, lead.id, agentId, newAct || null, oldAct, tier, clientBm, String(b.note || '').slice(0, 300) || null, now(),
    (lead as Lead & { manual_client?: number }).manual_client ? 1 : 0, actor.role).lastInsertRowid);
  // v173 (owner): the client's old balance (credit) typed by hand → added to the new account's limit (no fee, no sale)
  if (b.credit_amount !== undefined && b.credit_amount !== '' && Number(b.credit_amount) > 0) setReqTopup(reqById(id)!, b.credit_amount);
  const req = reqById(id)!;
  if (actor.role !== 'agent' && hand) { const out = await requestDoneByHand(id, actor, { act_id: newAct }); return { done: true, name: acctName(acctOf(newAct)!), ...(out as object) }; }
  // v173 (owner): no account picked → it waits in Requests for EVERYONE (admin, manager, agent); the account is chosen there.
  // Only a picked account is done at once.
  if (actor.role !== 'agent' && newAct) return runRequest(id, actor);
  addMsg(lead, { dir: 'sys', sender: 'system', agent_id: agentId, text: actor.role === 'agent' ? `📤 Sent to manager: ${reqSummary(req)}` : `📥 In Requests: ${reqSummary(req)} · choose the account there` });
  await alertTeam('🔁 Replacement account', `${displayName(lead)} · ${reqSummary(req)} · by ${actor.name}${b.note ? ' · ' + String(b.note).slice(0, 120) : ''}`, lead.id);
  return { ok: true, pending: true, request: pubReq(req) };
}

/** v156: a request done (system or by hand) → Records, once. Payment links are already recorded when paid. */
export async function recordReq(id: number) {
  const r = reqById(id);
  if (!r || r.rec_at || !run('UPDATE meta_requests SET rec_at=? WHERE id=? AND rec_at IS NULL', now(), r.id).changes) return;
  // v165: the admin's requests are recorded like the manager's (sale / replacement / top-up). Only "Give to client" from the Accounts page
  // (method manual, no payment asked) is a free give: no sale.
  const freeGive = (r.by_role === 'admin' || r.by_role === 'manager') && r.kind === 'account' && r.method === 'manual' && !(num(r.paid) > 0); // v166: the same for the manager (the page, not the role). review166: a paid amount typed (Manual share sheet) = a sale, never a free give
  const lead = leadById(r.lead_id);
  if (!lead) return;
  const s = getSettings();
  try {
    if (r.kind === 'replace') {
      const cost = money(num(s.acct_cost, 3));
      run('INSERT INTO meta_replacements(req_id, lead_id, agent_id, old_act, new_act, cost, by, created_at) VALUES(?,?,?,?,?,?,?,?)', r.id, lead.id, r.agent_id, r.old_act, r.act_id, cost, r.done_by, now());
      const old = r.old_act ? acctOf(r.old_act) : undefined;
      addMsg(lead, { dir: 'sys', sender: 'system', text: `🔁 Replacement saved in records: account cost ${usd(cost)} · no sale, no commission${old && old.lead_id === lead.id && ['assigned', 'invited'].includes(old.state) ? ` · old act_${old.act_id} is still with the client: Take back to move its balance` : ''}` });
      return;
    }
    const ag = agentById(r.agent_id) ?? (managers()[0] ? agentById(managers()[0].id) : undefined); // v165: admin in a chat with no agent → the manager
    if (!ag || r.method === 'link') return; // a paid payment link saved it already
    const own = ag.role === 'manager' && lead.agent_id && lead.agent_id !== ag.id ? agentById(lead.agent_id) : undefined;
    const seller = own && !own.deleted ? own : ag;
    const top = (amount: number, fee: number, note: string) => {
      if (!(amount > 0)) return;
      // already saved by hand a little before → that one becomes this top-up (never two)
      const hand = one<{ id: number }>('SELECT id FROM topups WHERE lead_id=? AND meta_req_id IS NULL AND ABS(amount-?)<0.01 AND created_at>? ORDER BY id DESC LIMIT 1', lead.id, amount, now() - 6 * 3600_000);
      if (hand) { // v165: the row the ad account log made → who sold it / closed it, and the chat line
        run('UPDATE topups SET meta_req_id=?, agent_id=?, closed_by=? WHERE id=?', r.id, seller.id, ag.id, hand.id);
        const t = one<{ commission: number }>('SELECT commission FROM topups WHERE id=?', hand.id);
        addMsg(lead, { dir: 'sys', sender: 'system', agent_id: seller.id, text: `💰 Topup ${usd(amount)} recorded · fee ${usd(t?.commission || 0)} · client pays ${usd(amount + (t?.commission || 0))}` });
        return;
      }
      addTopup(lead, seller, amount, note, { fee }, true);
      run('UPDATE topups SET meta_req_id=? WHERE id=(SELECT MAX(id) FROM topups WHERE lead_id=?)', r.id, lead.id);
    };
    if (r.kind === 'topup' && r.method === 'credit') { // v177: the client's credit went on the account → the credit is used, no top-up record / fee
      const used = useCredit(lead.id, money(r.amount || 0), String(r.act_id || ''));
      addMsg(lead, { dir: 'sys', sender: 'system', text: `💳 Credit ${usd(used)} added to act_${r.act_id} · no fee, no new top-up` });
      return;
    }
    if (r.kind === 'topup') return top(r.amount || 0, r.fee || 0, `Ad account system · act_${r.act_id}${r.ext ? ' (by hand)' : ''} · ${r.method}`);
    if (r.method !== 'credit' && !freeGive && !(r as Req & { sale_id?: number | null }).sale_id) { // v165: made from a sale (Sell again) → that sale is it
      const hand = one<{ id: number }>("SELECT id FROM sales WHERE lead_id=? AND meta_req_id IS NULL AND pay_link_id IS NULL AND service='account' AND created_at>? ORDER BY id DESC LIMIT 1", lead.id, now() - 6 * 3600_000);
      if (hand) run('UPDATE sales SET meta_req_id=? WHERE id=?', r.id, hand.id);
      else await recordSale(lead, { ...seller, deleted: 0 }, { service: 'account', qty: 1, paid: r.paid && r.paid > 0 ? r.paid : undefined, closed_by: ag.id, force: 1, meta_req: r.id, tier: r.tier === 'premium' ? 'premium' : r.tier === 'std' ? 'agency' : undefined }, { check: r.by_role === 'agent' });
    }
    top(r.add_amount || 0, r.add_fee || 0, `Ad account system · with the account act_${r.act_id}`);
  } catch (e) {
    addMsg(lead, { dir: 'sys', sender: 'system', text: `⚠️ Not saved in records (${(e as Error).message}). Mark it by hand.` });
  }
}

/** A crypto payment link was paid: make the request (auto-runs if the agent may). Returns false when there is nothing to do here. */
export async function requestFromPayLink(l: { code: string; kind: string; lead_id: number; agent_id: number; bm_id: string | null; act_id: string | null; tier?: string | null; share_mode?: string | null; client_email?: string | null; qty: number }, lead: Lead) {
  if (!metaOn() || (l.kind !== 'account' && l.kind !== 'topup')) return false;
  if (l.kind === 'topup' && (!l.act_id || !acctOf(l.act_id))) return false; // not one of ours → old manager task
  const ag = agentById(l.agent_id);
  const actor: Actor = { role: ag?.role === 'manager' ? 'manager' : 'agent', id: l.agent_id, name: ag?.name || 'agent' };
  const n = l.kind === 'account' ? Math.max(1, l.qty || 1) : 1;
  const hasTarget = l.kind === 'topup' || (l.share_mode === 'email' ? !!l.client_email : !!l.bm_id);
  for (let i = 0; i < n; i++) {
    const unfilled = l.kind === 'account' ? one<{ id: number }>("SELECT id FROM meta_requests WHERE lead_id=? AND kind='account' AND sale_id IS NOT NULL AND by_role='sale' AND status='pending' ORDER BY id LIMIT 1", lead.id) : undefined;
    if (!hasTarget && unfilled) { // v165: the sale was marked by hand first → its request becomes this payment's
      run("UPDATE meta_requests SET method='link', pay_code=?, tier=COALESCE(?, tier), by_role='link' WHERE id=?", l.code, l.tier || null, unfilled.id);
      continue;
    }
    if (!hasTarget) {
      // no BM ID / email yet: waits for the manager, who fills it in
      run(`INSERT INTO meta_requests(kind, lead_id, agent_id, tier, mode, paid, method, pay_code, note, status, created_at) VALUES('account',?,?,?,?,?,'link',?,?,'pending',?)`,
        lead.id, l.agent_id, l.tier || 'any', l.share_mode === 'email' ? 'email' : 'bm', null, l.code, 'Client’s BM ID / email missing', now());
      continue;
    }
    try {
      await createRequest(actor, { kind: l.kind, method: 'link', pay_code: l.code, act_id: l.act_id, mode: l.share_mode === 'email' ? 'email' : 'bm', client_bm: l.bm_id, client_email: l.client_email, tier: l.tier || 'any' }, lead);
    } catch (e) {
      // "already used" for 2nd+ account of the same link: add as plain pending (v165: or fill a not-yet-filled sale request)
      const un2 = l.kind === 'account' ? one<{ id: number }>("SELECT id FROM meta_requests WHERE lead_id=? AND kind='account' AND sale_id IS NOT NULL AND by_role='sale' AND status='pending' ORDER BY id LIMIT 1", lead.id) : undefined;
      if (un2) { run("UPDATE meta_requests SET method='link', pay_code=?, mode=?, client_bm=?, client_email=?, tier=COALESCE(?, tier), by_role='link' WHERE id=?", l.code, l.share_mode === 'email' ? 'email' : 'bm', l.bm_id, l.client_email || null, l.tier || null, un2.id); continue; }
      run(`INSERT INTO meta_requests(kind, lead_id, agent_id, tier, mode, client_bm, client_email, method, pay_code, note, status, created_at) VALUES(?,?,?,?,?,?,?,'link',?,?,'pending',?)`,
        l.kind, lead.id, l.agent_id, l.tier || 'any', l.share_mode === 'email' ? 'email' : 'bm', l.bm_id, l.client_email || null, l.code, (e as Error).message.slice(0, 200), now());
    }
  }
  if (!hasTarget) await alertTeam('📥 Ad account paid, BM ID missing', `${displayName(lead)} paid ${l.code}. Ask for the BM ID / email and approve in Ad accounts → Requests.`, lead.id);
  return true;
}

/* ======================= lists for the apps ======================= */
export const pubBm = (b: Bm) => {
  const n = one<{ total: number; free: number; assigned: number; disabled: number }>(`SELECT COUNT(*) total, SUM(state='free') free, SUM(state IN ('assigned','invited')) assigned, SUM(state='disabled') disabled FROM meta_accounts WHERE bm_id=? AND state!='gone'`, b.bm_id)!;
  return {
    id: b.id, bm_id: b.bm_id, name: b.name, label: b.label, su_name: b.su_name, verification: b.verification, tier: tierOf(bmVer(b)), created_time: b.created_time,
    acct_limit: b.acct_limit, status: b.status, error: b.error, error_at: b.error_at, synced_at: b.synced_at, proxy: maskProxy(dec(b.proxy_enc)), has_secret: !!dec(b.secret_enc),
    accounts: n.total || 0, free: n.free || 0, assigned: n.assigned || 0, disabled: n.disabled || 0, profile_id: b.profile_id ?? null, verified_since: b.verified_since ?? null,
    profile: b.profile_id ? (() => { const p = profileById(b.profile_id); return p ? [p.ix, p.name].filter(Boolean).join(' · ') : null; })() : null,
  };
};

export function pubAcct(a: Acct & { verification?: string | null; bm_name?: string | null; bm_status?: string | null }) {
  const lead = a.lead_id ? leadById(a.lead_id) : undefined;
  return {
    act_id: a.act_id, no: a.no, name: a.name, status: a.status, status_label: STATUS[a.status] || String(a.status), status_text: STATUS[a.status] || String(a.status), disable_reason: a.disable_reason, disable_text: disableText(a.status, a.disable_reason),
    pay_fail: !!(a as Acct & { pay_fail_at?: number | null }).pay_fail_at, pay_due: (a as Acct & { pay_due?: number | null }).pay_due != null ? (a as Acct & { pay_due?: number | null }).pay_due! / 100 : null, pay_fail_at: (a as Acct & { pay_fail_at?: number | null }).pay_fail_at ?? null, currency: a.currency,
    removed_at: (a as Acct & { removed_at?: number | null }).removed_at ?? null, created_time: a.created_time, spent: a.spent / 100, cap: a.cap / 100, left: remaining(a) / 100, today: a.today, card: a.card, card_guess: !!a.card_guess && !a.card_set, card_set: a.card_set ?? null, profile: profTag(a.bm_id), state: a.state, step: a.step, err: a.err,
    bm_id: a.bm_id, bm_name: a.bm_id === 'hand' ? 'Given by hand (not in our BMs)' : a.bm_name ?? bmOf(a.bm_id)?.name ?? null, bm_status: a.bm_status ?? bmOf(a.bm_id)?.status ?? null, tier: tierOf(a.verification ?? bmVer(bmOf(a.bm_id))),
    post_wait: a.post_wait && !a.post_ready ? a.post_wait : null, post_sending: (a.post_ready || 0) > 0, share_mode: a.share_mode, client_bm: a.client_bm, client_email: a.client_email, assigned_at: a.assigned_at, disabled_at: a.disabled_at, synced_at: a.synced_at,
    lead: lead ? { id: lead.id, name: displayName(lead), agent: agentById(lead.agent_id)?.name || null } : null,
    dsl: a.dsl ?? null, bill_threshold: a.bill_threshold ?? null, cat: catOf(a), partner_name: a.partner_name ?? null, biz_name: a.biz_name ?? null, base_name: a.base_name ?? null, verified_since: bmOf(a.bm_id)?.verified_since ?? null, extra_bms: extraBms(a),
  };
}
/** v165: an ad account sold in the chat (Sell again / Mark sold) → its "give" request is made by itself (Ad accounts → Requests),
 *  one per account, waiting for the client's BM ID + the account. A Give made in the last 6 h without a sale → that one is linked instead. */
export function requestFromSale(leadId: number, saleId: number, qty: number, tier: 'premium' | 'std', byName: string) {
  if (!one('SELECT 1 FROM meta_bms WHERE deleted=0')) return null; // the ad account system is not set up
  const lead = leadById(leadId);
  if (!lead) return null;
  const open = one<{ id: number }>(`SELECT r.id FROM meta_requests r WHERE r.lead_id=? AND r.kind='account' AND r.created_at>? AND r.status NOT IN ('rejected','cancelled')
      AND r.sale_id IS NULL AND COALESCE(r.method,'') NOT IN ('link','credit') AND r.pay_code IS NULL
      AND NOT EXISTS(SELECT 1 FROM sales x WHERE x.meta_req_id=r.id) ORDER BY r.id DESC LIMIT 1`, leadId, now() - 6 * 3600_000);
  if (open) { run('UPDATE meta_requests SET sale_id=? WHERE id=?', saleId, open.id); run('UPDATE sales SET meta_req_id=? WHERE id=?', open.id, saleId); return { linked: open.id }; }
  const bm = one<{ b: string }>("SELECT client_bm b FROM meta_accounts WHERE lead_id=? AND client_bm IS NOT NULL ORDER BY assigned_at DESC LIMIT 1", leadId)?.b
    || one<{ b: string }>("SELECT client_bm b FROM meta_requests WHERE lead_id=? AND client_bm IS NOT NULL AND client_bm!='' ORDER BY id DESC LIMIT 1", leadId)?.b || null;
  const ids: number[] = [];
  for (let i = 0; i < Math.max(1, Math.min(10, Math.floor(qty) || 1)); i++) {
    ids.push(Number(run(`INSERT INTO meta_requests(kind, lead_id, agent_id, tier, mode, client_bm, method, note, status, created_at, by_role, sale_id)
      VALUES('account',?,?,?,?,?,?,?,'pending',?,?,?)`, leadId, lead.agent_id ?? null, tier, 'bm', bm, 'upi', `Sold in the chat by ${byName} (sale #${saleId})`, now(), 'sale', saleId).lastInsertRowid));
  }
  run('UPDATE sales SET meta_req_id=? WHERE id=?', ids[0], saleId);
  addMsg(lead, { dir: 'sys', sender: 'system', text: `📋 Ad account to give: request #${ids.join(', #')} in Ad accounts → Requests${bm ? ` · BM ${bm}` : ' · add the client’s BM ID there'}` });
  void alertTeam(`🆕 Ad account to give: ${displayName(lead)}`, `Sold in the chat${qty > 1 ? ` (${qty} accounts)` : ''} · Ad accounts → Requests${bm ? '' : ' · BM ID needed'}`, leadId);
  return { requests: ids };
}

/** v165: the card on an account, set by hand (a business-portfolio card: Meta does not send its number). '' = back to automatic. */
export function setAcctCard(act: unknown, cardIn: unknown) {
  const a = acctOf(String(act || ''));
  if (!a) throw new HttpError(404, 'Ad account not found');
  const card = String(cardIn || '').trim().replace(/\s+/g, ' ').slice(0, 40);
  if (!card) { run('UPDATE meta_accounts SET card_set=NULL WHERE act_id=?', a.act_id); return { ok: true, card: a.card, auto: true }; }
  if (!one('SELECT 1 FROM meta_cards WHERE card=?', card) && !/^[A-Za-z ]{2,20}\*\d{4}$/.test(card)) throw new HttpError(400, 'Choose a card, or type it like VISA *9975');
  run('INSERT OR IGNORE INTO meta_cards(card, used_since) VALUES(?,0)', card);
  run('UPDATE meta_accounts SET card_set=?, card=?, card_guess=0 WHERE act_id=?', card, card, a.act_id);
  return { ok: true, card };
}
/** v165: short profile name for an account's BM ("GLP5"). */
export function profTag(bmId: string | null | undefined) {
  const b = bmId ? bmOf(bmId) : undefined;
  if (!b?.profile_id) return null;
  const p = profileById(b.profile_id);
  return p ? (p.ix || p.name || null) : null;
}
/** v152: the Meta daily spending limit and the billing threshold ("You'll pay when") the admin reads off Meta once (the API doesn't give them). */
export function setAcctLimits(act: unknown, b: Record<string, unknown>) {
  const a = acctOf(act);
  if (!a) throw new HttpError(404, 'Ad account not found');
  const v = (x: unknown) => (x === '' || x === null ? null : money(x));
  if (b.dsl !== undefined) { const d = v(b.dsl); if (d !== null && !(d > 0)) throw new HttpError(400, 'Enter the daily spending limit (USD)'); run('UPDATE meta_accounts SET dsl=? WHERE act_id=?', d, a.act_id); }
  if (b.bill_threshold !== undefined) { const t = v(b.bill_threshold); if (t !== null && !(t > 0)) throw new HttpError(400, 'Enter the billing threshold (USD)'); run('UPDATE meta_accounts SET bill_threshold=? WHERE act_id=?', t, a.act_id); }
  return { ok: true, account: pubAcct(acctOf(a.act_id)!) };
}

/** v161: list order. With clients: the last one sold on top. Free: the one that is given next on top (same order as the share pick:
 *  BM ok, account active and not busy, then the account number); not ready ones after. Disabled: the last disabled on top.
 *  All: with clients → free → disabled. */
const GROUP: Record<string, number> = { assigned: 0, invited: 0, free: 1, disabled: 2 };
type Ord = Acct & { bm_status?: string | null };
const freeReady = (a: Ord) => a.bm_status === 'ok' && ![2, 100, 101].includes(Number(a.status)) && !a.busy && a.step !== 'check';
function acctOrder(a: Ord, b: Ord) {
  const g = (GROUP[a.state] ?? 3) - (GROUP[b.state] ?? 3);
  if (g) return g;
  if (a.state === 'free') return (freeReady(a) ? 0 : 1) - (freeReady(b) ? 0 : 1) || a.no - b.no;
  if (a.state === 'disabled') return (b.disabled_at || 0) - (a.disabled_at || 0) || b.no - a.no;
  return (b.assigned_at || 0) - (a.assigned_at || 0) || b.no - a.no;
}
export const removedCount = () => one<{ n: number }>('SELECT COUNT(*) n FROM meta_accounts WHERE removed_at IS NOT NULL')!.n;
export function listAccounts(f: { state?: string | null; q?: string | null; bm?: string | null; lead?: number | null }) {
  const rm = f.state === 'removed'; // v170: the accounts removed from the system, only on their own list
  const rows = all<Acct & { verification: string | null; bm_name: string | null; bm_status: string | null }>(
    `SELECT a.*, CASE WHEN COALESCE(b.verified_since,'')!='' THEN 'verified' ELSE b.verification END verification, b.name bm_name, b.status bm_status FROM meta_accounts a LEFT JOIN meta_bms b ON b.bm_id=a.bm_id WHERE ${rm ? 'a.removed_at IS NOT NULL' : "a.state!='gone'"} ORDER BY ${rm ? 'a.removed_at DESC' : 'a.no'}`);
  const q = (f.q || '').trim().toLowerCase();
  if (rm) return rows.filter(a => !q || `${a.name || ''} ${a.act_id} #${a.no} ${a.client_bm || ''}`.toLowerCase().includes(q)).map(pubAcct);
  return rows.filter(a => (!f.state || f.state === 'all' || (f.state === 'assigned' ? ['assigned', 'invited'].includes(a.state) : a.state === f.state))
    && (!f.bm || a.bm_id === f.bm) && (!f.lead || a.lead_id === f.lead)
    && (!q || `${a.name || ''} ${a.act_id} #${a.no} ${a.client_bm || ''} ${a.client_email || ''} ${a.lead_id ? displayName(leadById(a.lead_id) || {}) : ''}`.toLowerCase().includes(q))).sort(acctOrder).map(pubAcct);
}

/** v170 (owner): take ONE account out of the system (lists, stock, alerts, sync) without touching it on Meta. Its sales and history stay.
 *  Nothing is moved: the client keeps access, no credit is made (do "Take back access" first if that is wanted). Restore brings it back as it was. */
export function removeAcct(act: unknown, actor: Actor) {
  const a = acctOf(act);
  if (!a) throw new HttpError(404, 'Ad account not found');
  if ((a as Acct & { removed_at?: number | null }).removed_at) return { ok: true, already: true };
  if (a.busy && a.busy > now() - 120000) throw new HttpError(409, 'Another action is running on this account. Try again in a moment.');
  const open = one<{ n: number }>("SELECT COUNT(*) n FROM meta_requests WHERE act_id=? AND status IN ('open','pending','queued','running','failed','manual')", a.act_id)?.n || 0;
  let jobs = 0; try { jobs = one<{ n: number }>("SELECT COUNT(*) n FROM meta_jobs WHERE ref=? AND status IN ('queued','running')", a.act_id)?.n || 0; } catch { /* older table */ }
  if (open || jobs) throw new HttpError(409, 'This account has an open request or a job in the queue. Finish or reject it first.');
  run("UPDATE meta_accounts SET removed_at=?, removed_state=state, removed_by=?, state='gone', low_sent=0 WHERE act_id=?", now(), by(actor), a.act_id);
  log('removed', { act_id: a.act_id, lead_id: a.lead_id || null, note: 'Removed from the system (nothing changed on Meta)', by: by(actor) });
  return { ok: true };
}
export function restoreAcct(act: unknown, actor: Actor) {
  const a = acctOf(act) as (Acct & { removed_at?: number | null; removed_state?: string | null }) | undefined;
  if (!a) throw new HttpError(404, 'Ad account not found');
  if (!a.removed_at) return { ok: true, already: true };
  const back = DISABLED.includes(a.status) ? 'disabled' : a.removed_state && a.removed_state !== 'gone' ? a.removed_state : 'free';
  run('UPDATE meta_accounts SET removed_at=NULL, removed_state=NULL, removed_by=NULL, state=? WHERE act_id=?', back, a.act_id);
  log('restored', { act_id: a.act_id, lead_id: a.lead_id || null, note: `Back in the system (${back}); the next sync reads it fresh`, by: by(actor) });
  return { ok: true, state: back };
}

export function accountDetail(act: unknown) {
  const a = acctOf(act);
  if (!a) throw new HttpError(404, 'Ad account not found');
  return { account: pubAcct(a), log: all('SELECT * FROM meta_log WHERE act_id=? ORDER BY id DESC LIMIT 50', a.act_id), credit: a.lead_id ? openCredit(a.lead_id) : 0 };
}

export const pubReq = (r: Req) => {
  const lead = leadById(r.lead_id);
  return { ...r, summary: reqSummary(r), lead: lead ? { id: lead.id, name: displayName(lead) } : null, agent: agentById(r.agent_id)?.name || null, credit: openCredit(r.lead_id) };
};
export const listRequests = (status: string) => all<Req>(status === 'open'
  ? "SELECT * FROM meta_requests WHERE status IN ('pending','failed','manual','running') ORDER BY id DESC LIMIT 200"
  : 'SELECT * FROM meta_requests ORDER BY id DESC LIMIT 200').map(pubReq);

export function listCredits() {
  return all<{ lead_id: number; amount: number; n: number; last: number; acts: string }>(
    "SELECT lead_id, SUM(amount) amount, COUNT(*) n, MAX(created_at) last, GROUP_CONCAT(act_id) acts FROM meta_credits WHERE status='open' GROUP BY lead_id ORDER BY last DESC")
    .map(c => { const l = leadById(c.lead_id); return { ...c, amount: money(c.amount), lead: l ? { id: l.id, name: displayName(l), agent: agentById(l.agent_id)?.name || null } : null, from: all("SELECT id, act_id, amount, reason, created_at FROM meta_credits WHERE lead_id=? AND status='open' ORDER BY id", c.lead_id) }; });
}
/** v165 (admin): remove a client's credit (refunded by hand / not owed) — all of it, or one entry (id). */
export function cancelCredit(leadId: unknown, actor: Actor, creditId?: unknown, note?: unknown) {
  if (actor.role !== 'admin') throw new HttpError(403, 'Only the admin can remove a credit');
  const cid = num(creditId);
  const amt = one<{ v: number }>(`SELECT COALESCE(SUM(amount),0) v FROM meta_credits WHERE lead_id=? AND status='open'${cid ? ' AND id=?' : ''}`, ...(cid ? [num(leadId), cid] : [num(leadId)]))!.v;
  const n = run(`UPDATE meta_credits SET status='cancelled', used_at=? WHERE lead_id=? AND status='open'${cid ? ' AND id=?' : ''}`, ...(cid ? [now(), num(leadId), cid] : [now(), num(leadId)])).changes;
  if (!n) throw new HttpError(404, 'No open credit to remove');
  const why = String(note || '').trim().slice(0, 120);
  log('credit_cancel', { lead_id: num(leadId), amount: money(amt), note: why || 'removed', by: by(actor) });
  const lead = leadById(num(leadId));
  if (lead) addMsg(lead, { dir: 'sys', sender: 'system', text: `🧾 Credit ${usd(amt)} removed by ${by(actor)}${why ? ' · ' + why : ''}` });
  return { ok: true, n, amount: money(amt) };
}

export function listCards() {
  const s = getSettings();
  const [f] = dayRange('today', s);
  const cards = all<{ card: string; balance: number | null; bal_at: number | null; used_since: number }>('SELECT * FROM meta_cards ORDER BY card');
  return cards.map(c => {
    const accts = all<Acct>("SELECT * FROM meta_accounts WHERE card=? AND state!='gone'", c.card);
    if (!accts.length) return null;
    const left = accts.filter(a => ['assigned', 'invited'].includes(a.state) && !DISABLED.includes(a.status)).reduce((x, a) => x + remaining(a), 0) / 100;
    const topToday = money(one<{ v: number }>("SELECT COALESCE(SUM(l.amount),0) v FROM meta_log l JOIN meta_accounts a ON a.act_id=l.act_id WHERE l.kind='topup' AND a.card=? AND l.created_at>=?", c.card, f)!.v);
    const est = c.balance === null ? null : money(c.balance - c.used_since / 100);
    return {
      card: c.card, accounts: accts.length, bms: new Set(accts.map(a => a.bm_id)).size,
      bm_list: [...new Set(accts.map(a => a.bm_id))].map(id => ({ bm_id: id, name: bmOf(id)?.name || id, accounts: accts.filter(a => a.bm_id === id).map(a => ({ act_id: a.act_id, name: a.name || `Account ${a.no}`, state: a.state })) })), client_left: money(left), topups_today: topToday, spend_today: money(accts.reduce((x, a) => x + (a.today || 0), 0)),
      balance: c.balance, bal_at: c.bal_at, used_since: c.used_since / 100, est_balance: est, load: est === null ? null : money(Math.max(0, left - est)),
    };
  }).filter(Boolean);
}
export function setCardBalance(card: unknown, bal: unknown) {
  const c = String(card || '');
  if (!one('SELECT 1 FROM meta_cards WHERE card=?', c)) throw new HttpError(404, 'Card not found');
  const v = money(bal);
  if (!(v >= 0)) throw new HttpError(400, 'Enter the card balance');
  run('UPDATE meta_cards SET balance=?, bal_at=?, used_since=0 WHERE card=?', v, now(), c);
  return { ok: true };
}

export function overview() {
  const bms = all<Bm>('SELECT * FROM meta_bms WHERE deleted=0');
  const accts = all<Acct>("SELECT * FROM meta_accounts WHERE state!='gone'");
  const tiers = { verified: 0, review: 0, unverified: 0 } as Record<string, number>;
  for (const b of bms) tiers[tierOf(bmVer(b))]++;
  const withClient = accts.filter(a => ['assigned', 'invited'].includes(a.state));
  const lows = withClient.filter(a => a.cap > 0 && !a.locked && remaining(a) / 100 < num(getSettings().meta_low_usd, 15) && !DISABLED.includes(a.status));
  const freeBy = { verified: 0, review: 0, unverified: 0 } as Record<string, number>;
  for (const a of freeAccounts('any')) freeBy[tierOf(a.verification)]++;
  return {
    bms: bms.length, tiers, blocked: bms.filter(b => b.status !== 'ok').map(b => ({ id: b.id, name: b.name || b.bm_id, label: b.label, status: b.status, error: b.error })),
    accounts: accts.length, assigned: withClient.length, invited: accts.filter(a => a.state === 'invited').length, free: accts.filter(a => a.state === 'free').length, free_by: freeBy,
    disabled: accts.filter(a => a.state === 'disabled').length, spend_today: money(accts.reduce((x, a) => x + (a.today || 0), 0)),
    client_left: money(withClient.filter(a => !DISABLED.includes(a.status)).reduce((x, a) => x + remaining(a), 0) / 100),
    low: lows.map(a => ({ act_id: a.act_id, name: acctName(a), left: remaining(a) / 100, lead: a.lead_id ? displayName(leadById(a.lead_id) || {}) : null })),
    recent_disabled: all<Acct>("SELECT * FROM meta_accounts WHERE state='disabled' AND disabled_at>? ORDER BY disabled_at DESC LIMIT 10", now() - 3 * 86400000).map(a => ({ act_id: a.act_id, name: acctName(a), at: a.disabled_at, step: a.step })),
    requests: one<{ n: number }>("SELECT COUNT(*) n FROM meta_requests WHERE status IN ('pending','failed','manual')")!.n,
    credits: money(one<{ v: number }>("SELECT COALESCE(SUM(amount),0) v FROM meta_credits WHERE status='open'")!.v),
    cards_low: (listCards() as { card: string; load: number | null }[]).filter(c => c && (c.load || 0) > 0).map(c => ({ card: c.card, load: c.load })),
    last_sync: Math.max(0, ...bms.map(b => b.synced_at || 0)) || null, sync_min: num(getSettings().meta_sync_min, 360),
  };
}

export function report(range: string | null) {
  const s = getSettings();
  const [f, t] = dayRange(range, s);
  const n = (sql: string, ...a: unknown[]) => one<any>(sql, ...a)!;
  const shares = n("SELECT COUNT(*) n FROM meta_log WHERE kind='share' AND created_at>=? AND created_at<?", f, t).n;
  const tops = n("SELECT COUNT(*) n, COALESCE(SUM(paid),0) paid, COALESCE(SUM(fee),0) fee, COALESCE(SUM(amount),0) amount FROM meta_log WHERE kind='topup' AND created_at>=? AND created_at<?", f, t);
  const sales = n("SELECT COUNT(*) n, COALESCE(SUM(qty),0) q, COALESCE(SUM(amount),0) v FROM sales WHERE service='account' AND created_at>=? AND created_at<?", f, t);
  const unshares = n("SELECT COUNT(*) n FROM meta_log WHERE kind='unshare' AND created_at>=? AND created_at<?", f, t).n;
  const disabled = n("SELECT COUNT(*) n FROM meta_log WHERE kind='disabled' AND created_at>=? AND created_at<?", f, t).n;
  const repl = n("SELECT COUNT(*) n, COALESCE(SUM(cost),0) c FROM meta_replacements WHERE created_at>=? AND created_at<?", f, t); // v156
  return {
    replacements: repl.n, replace_cost: money(repl.c),
    shares, unshares, disabled, topups: tops.n, topup_paid: money(tops.paid), topup_fee: money(tops.fee), topup_added: money(tops.amount),
    sold: sales.q, sold_revenue: money(sales.v), earned: money(sales.v + tops.fee),
    credits: money(n("SELECT COALESCE(SUM(amount),0) v FROM meta_credits WHERE status='open'").v),
    recent: all("SELECT l.*, a.name acct_name, a.no FROM meta_log l LEFT JOIN meta_accounts a ON a.act_id=l.act_id WHERE l.created_at>=? AND l.created_at<? ORDER BY l.id DESC LIMIT 60", f, t)
      .map((r: any) => ({ ...r, lead: r.lead_id ? displayName(leadById(r.lead_id) || {}) : null })),
  };
}

export function searchLeads(q: string, ch = '') {
  const t = q.trim();
  const like = `%${t}%`;
  // v153: Telegram and WhatsApp chats, newest message first; ch = 'tg' | 'wa' filters
  const chWhere = ch === 'wa' ? "AND ch='wa'" : ch === 'tg' ? "AND COALESCE(ch,'tg')!='wa' AND tg_chat_id IS NOT NULL" : '';
  return all<Lead & { ch?: string | null }>(`SELECT * FROM leads WHERE (tg_chat_id IS NOT NULL OR ch='wa') AND COALESCE(manual_client,0)=0 AND status!='merged' ${chWhere}
    AND (? = '' OR name LIKE ? OR tg_name LIKE ? OR tg_username LIKE ? OR phone LIKE ? OR CAST(id AS TEXT)=?) ORDER BY COALESCE(last_at, last_in_at, created_at) DESC LIMIT 30`, t, like, like, like, like, t.replace(/^#/, ''))
    .map(l => ({ id: l.id, name: displayName(l), ch: l.ch === 'wa' ? 'wa' : 'tg', agent: agentById(l.agent_id)?.name || null, credit: openCredit(l.id), last_at: l.last_at || null }));
}

/** The client's accounts (agent chat view). */
export const leadMetaAccounts = (leadId: number) => all<Acct>("SELECT * FROM meta_accounts WHERE lead_id=? AND removed_at IS NULL ORDER BY assigned_at DESC", leadId).map(pubAcct);

/* ======================= worker ======================= */
let syncing = false;
const inviteChecked = new Map<number, number>();
export async function metaTick(force = false) {
  if (syncing || (!metaEnabled() && !force)) return 0; // OFF: no automatic reads (Sync now still works for setup)
  syncing = true;
  try {
    const every = Math.max(15, num(getSettings().meta_sync_min, 360)) * 60000;
    // v152: BMs of a profile are read only by the queue (after the IP change)
    const due = all<Bm>('SELECT * FROM meta_bms WHERE deleted=0 AND profile_id IS NULL AND (synced_at IS NULL OR synced_at<?) ORDER BY synced_at', force ? now() + 1 : now() - every);
    let n = 0;
    for (const b of due) { await syncBm(b.id); n++; }
    // invites wait for acceptance: check those BMs every few minutes even between full syncs
    // (only BMs with a pending invite, at most every 15 min, so the API is not hit often)
    const inv = all<Bm>("SELECT DISTINCT b.* FROM meta_bms b JOIN meta_accounts a ON a.bm_id=b.bm_id AND a.state='invited' WHERE b.deleted=0 AND b.status='ok' AND b.profile_id IS NULL");
    for (const b of inv) {
      if ((inviteChecked.get(b.id) || 0) > now() - 15 * 60000) continue;
      inviteChecked.set(b.id, now());
      try { await checkInvites(b); } catch (e) { console.warn('[meta] invites', (e as Error).message); }
    }
    return n;
  } finally { syncing = false; }
}

export type { Settings };
