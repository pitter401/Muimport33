// v138: WATI Pro — automatic replies to the WhatsApp welcome buttons ("Get account", "See pricing"…).
// Pure helpers (no database, no server imports) so the admin editor uses exactly the same rules as the server.
// Stored in ONE setting, wati_btn_replies = { agency: { "<label>": { text, voice, buttons } }, premium: {…}, funnel: {…} }.
// Empty setting / a label that is not in it → the built-in default for that label (or for its position).

export type BtnLine = 'agency' | 'premium' | 'funnel';
export const BTN_LINES: BtnLine[] = ['agency', 'premium', 'funnel'];
export type BtnReply = { text: string; voice: boolean; buttons: string[] };
export type BtnLineMap = Record<string, BtnReply>;
export type BtnReplies = Record<BtnLine, BtnLineMap>;

/** The welcome buttons when the admin left the labels empty (settings.ts has the same defaults in wati_btn_*).
 *  v140: See pricing / What's included / the line's action, with a small icon each (user-approved: icons on button labels only). */
export const BTN_DEFAULT: Record<BtnLine, string[]> = {
  agency: ['💰 See pricing', "📦 What's included", '✅ Get account'],
  premium: ['💰 See pricing', "📦 What's included", '💎 Buy Premium'],
  funnel: ['💰 See pricing', "📦 What's included", '📈 Start my funnel'],
};
/** The v137–v139 default labels (the v140 migration only replaces these). */
export const BTN_DEFAULT_V139: Record<BtnLine, string[]> = {
  agency: ['Get account', 'Top-up', 'Talk to agent'],
  premium: ['Buy Premium', "What's included", 'Talk to agent'],
  funnel: ['Start my funnel', 'See pricing', 'Talk to agent'],
};
/** The only icons allowed on button labels (v140, user-approved). Anything else is stripped. */
export const BTN_ICONS = ['💰', '📦', '✅', '💎', '📈', '💬'];
export const TALK_LABEL = '💬 Talk to agent';
export const TALK_DEFAULT = 'Sure sir, connecting you to an agent now. Please wait a minute.';

/** Placeholders for the reply texts (all filled from the current settings when the reply is sent). */
export const BTN_PLACEHOLDERS: [string, string][] = [
  ['{name}', "customer's first name"],
  ['{price}', "this line's price (Agency / Premium account, or the funnel per month)"],
  ['{price_inr}', 'the same in INR'],
  ['{fee}', 'top-up fee, e.g. 3%'],
  ['{min_topup}', 'minimum top-up (USD)'],
  ['{min_topup_inr}', 'minimum top-up in INR'],
  ['{premium_price}', 'Premium account price'],
  ['{funnel_price}', 'funnel price per month'],
  ['{delivery}', 'delivery time of this line'],
  ['{payment}', 'payment methods'],
  ['{brand}', 'brand name'],
];

const r = (text: string, buttons: string[] = [], voice = false): BtnReply => ({ text, voice, buttons });
const I = "📦 What's included", P = '💰 See pricing', T = TALK_LABEL;
/** Built-in replies: short, English, prices only through placeholders (never typed in). No emoji in the text; v140: the
 *  "What's included" lists use ✓ as the bullet and the delivery line starts with ⏱ (the only two marks allowed).
 *  Keys are matched without icons ("See pricing" = "💰 See pricing"). */
export const BTN_REPLY_DEFAULTS: BtnReplies = {
  agency: {
    'See pricing': r('Our agency ad account is ${price} ({price_inr} INR) per account, with no spending limit.\n⏱ Shared to your Business Manager within {delivery} after payment.\n\nTop-ups: fee only {fee}, minimum ${min_topup} ({min_topup_inr} INR).\nPayment: {payment}.', [I, '✅ Get account', T]),
    "What's included": r('Every agency ad account comes with:\n✓ No spending limit from day one\n✓ No 18% GST on ad spend\n✓ Top-ups any time, fee only {fee}\n✓ Help from our team on WhatsApp and Telegram\n⏱ Shared to your Business Manager within {delivery} after payment.\n\nPrice: ${price} ({price_inr} INR) per account.', [P, '✅ Get account', T]),
    'Get account': r('Sure {name}. Our agency ad account is ${price} ({price_inr} INR) per account, with no spending limit. It is shared to your Business Manager within {delivery} after payment.\n\nTo get started, please send your Business Manager (BM) ID. No BM yet? Just tell us and we will help you make one.', ['Top-up', T]),
    'Top-up': r('Top-ups are done right here in this chat. The fee is only {fee} of the amount, and the minimum top-up is ${min_topup} ({min_topup_inr} INR).\n\nTo top up, send your ad account ID and the amount. We share the payment details ({payment}) and add the funds as soon as the payment is confirmed.', ['✅ Get account', T]),
    'Talk to agent': r(TALK_DEFAULT),
  },
  premium: {
    'See pricing': r('The Premium ad account is ${price} ({price_inr} INR) per account.\n⏱ Ready in {delivery} after payment.\n\nTop-up fee only {fee}.\nPayment: {payment}.', [I, '💎 Buy Premium', T]),
    "What's included": r('Every Premium ad account comes with:\n✓ An aged, strong profile and a verified BM\n✓ No spending limit from day one, made for bigger budgets\n✓ No 18% GST on ad spend\n✓ Top-up fee only {fee}\n✓ Priority support\n⏱ Ready in {delivery} after payment.\n\nPrice: ${price} ({price_inr} INR) per account.', [P, '💎 Buy Premium', T]),
    'Buy Premium': r('Great choice {name}. The Premium ad account is ${price} ({price_inr} INR) per account, ready in {delivery}.\n\nTo get started, send your Business Manager (BM) ID and how many accounts you need. We will share the payment details ({payment}) right after.', [I, T]),
    'Talk to agent': r(TALK_DEFAULT),
  },
  funnel: {
    'See pricing': r('The complete funnel is ${price} ({price_inr} INR) per month: a landing page, Meta ads setup with tracking, leads to your WhatsApp, hosting and support.\n⏱ Setup takes 2 to 3 days.\nPayment: {payment}.', [I, '📈 Start my funnel', T]),
    "What's included": r('Your funnel includes:\n✓ A fast landing page for your business\n✓ Full Meta ads setup with tracking\n✓ Leads sent straight to your WhatsApp\n✓ Hosting and support\n⏱ Setup takes 2 to 3 days.\n\nPrice: ${price} ({price_inr} INR) per month.', [P, '📈 Start my funnel', T]),
    'Start my funnel': r('Great {name}. To start your funnel, please send us:\n1. What your business sells\n2. Which city or country you want customers from\n3. Your daily ad budget\n4. The WhatsApp number where the leads should go\n\nSetup takes 2 to 3 days after we have these details.', [P, T]),
    'Talk to agent': r(TALK_DEFAULT),
  },
};

const EMOJI = /[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{2300}-\u{23FF}\u{2B00}-\u{2BFF}\uFE0F\u200D]/gu;
const ICON_RE = new RegExp('^\\s*(' + BTN_ICONS.join('|') + ')\\uFE0F?\\s*', 'u');
/** A button label as WhatsApp / Telegram gets it: one allowed icon at the start (BTN_ICONS) or none, no other emoji,
 *  one space, max 20 characters (the icon counted). */
export const cleanLabel = (x: unknown) => {
  const s = String(x ?? '');
  const m = s.match(ICON_RE);
  const rest = (m ? s.slice(m[0].length) : s).replace(EMOJI, '').replace(/\s+/g, ' ').trim();
  if (!rest) return '';
  const icon = m ? m[1] + ' ' : '';
  return icon + rest.slice(0, 20 - icon.length);
};
/** The matching key of a label: icons / emoji / variation selectors stripped, lower case ("💰 See pricing" = "see pricing"). */
export const btnKey = (x: unknown) => String(x ?? '').replace(EMOJI, '').replace(/\s+/g, ' ').trim().slice(0, 20).toLowerCase();
/** Reply text: no emoji (hard rule for automatic messages) except the ⏱ delivery mark (✓ is a plain character), max 1000 characters. */
export const cleanReplyText = (x: unknown) => String(x ?? '').replace(/(?![←-⇿⏱])[\p{Extended_Pictographic}\u{1F3FB}-\u{1F3FF}\uFE0F\u200D]/gu, '').replace(/[ \t]{2,}/g, ' ').replace(/\r/g, '').trim().slice(0, 1000);
export const cleanButtons = (x: unknown) => {
  const arr = Array.isArray(x) ? x : String(x ?? '').split(/[,\n]/);
  return [...new Set(arr.map(cleanLabel).filter(Boolean))].slice(0, 3);
};
/** The labels of one line from its comma separated setting (max 3, no emoji, 20 characters). Empty → the defaults. */
export function parseLabels(raw: unknown, ln: BtnLine): string[] {
  const out = cleanButtons(String(raw ?? ''));
  return out.length ? out : [...BTN_DEFAULT[ln]];
}
/** "Talk to agent" (or similar) — the agent is alerted (with alarm) besides the reply. */
export const isTalkToAgent = (t0: string) => { const t = String(t0 || '').replace(EMOJI, ''); return /^\s*(4\s*[·.\-):]\s*)?talk to (an |our |the )?(agent|team|human|person)\b/i.test(t) || /^\s*talk to agent\s*$/i.test(t); };

/** Any input (the saved JSON, or what the editor sends) → a clean map. Unknown lines / bad rows are dropped. */
export function cleanReplies(x: unknown): BtnReplies {
  const out: BtnReplies = { agency: {}, premium: {}, funnel: {} };
  const o = x && typeof x === 'object' ? (x as Record<string, unknown>) : {};
  for (const ln of BTN_LINES) {
    const m = o[ln] && typeof o[ln] === 'object' ? (o[ln] as Record<string, unknown>) : {};
    for (const [k, v] of Object.entries(m)) {
      const label = cleanLabel(k);
      if (!label || Object.keys(out[ln]).some(e => btnKey(e) === btnKey(label))) continue;
      const row = v && typeof v === 'object' ? (v as Record<string, unknown>) : {};
      out[ln][label] = { text: cleanReplyText(row.text), voice: row.voice === true || row.voice === '1' || row.voice === 1, buttons: cleanButtons(row.buttons) };
      if (Object.keys(out[ln]).length >= 6) break;
    }
  }
  return out;
}
export function parseReplies(raw: unknown): BtnReplies {
  if (!raw || !String(raw).trim()) return { agency: {}, premium: {}, funnel: {} };
  try { return cleanReplies(JSON.parse(String(raw))); } catch { return { agency: {}, premium: {}, funnel: {} }; }
}
const findKey = (m: BtnLineMap, label: string) => Object.keys(m).find(k => btnKey(k) === btnKey(label));

/** The reply for one of the line's CURRENT labels:
 *  1. saved for that label (case-insensitive) · 2. saved at the same position under a label that no longer exists (renamed)
 *  3. built-in default for that label · 4. built-in default at the same position (renamed, never saved; not "Talk to agent").
 *  "Talk to agent" without anything saved → the default connecting text. null = no reply. */
export function replyFor(map: BtnReplies, ln: BtnLine, labels: string[], label: string): BtnReply | null {
  const saved = map[ln] || {};
  const k = findKey(saved, label);
  if (k) return saved[k];
  const idx = labels.findIndex(l => btnKey(l) === btnKey(label));
  const cur = new Set(labels.map(btnKey));
  if (idx >= 0) {
    const e = Object.entries(saved)[idx];
    // v140: only a label WITHOUT a built-in reply of its own takes over a renamed label's saved reply by position
    // (the new See pricing / What's included never inherit e.g. the old "Top-up" reply after the label update)
    if (e && !cur.has(btnKey(e[0])) && !findKey(BTN_REPLY_DEFAULTS[ln], label)) return e[1];
  }
  const dk = findKey(BTN_REPLY_DEFAULTS[ln], label);
  if (dk) return BTN_REPLY_DEFAULTS[ln][dk];
  if (isTalkToAgent(label)) return { text: TALK_DEFAULT, voice: false, buttons: [] };
  if (idx >= 0) {
    const dl = BTN_DEFAULT[ln][idx];
    if (dl && !cur.has(btnKey(dl)) && !isTalkToAgent(dl)) return BTN_REPLY_DEFAULTS[ln][dl] || null;
  }
  return null;
}
/** The full map for the line's current labels (what the editor shows and saves). */
export function effectiveLine(map: BtnReplies, ln: BtnLine, labels: string[]): BtnLineMap {
  const out: BtnLineMap = {};
  for (const l of labels) out[l] = { ...(replyFor(map, ln, labels, l) || { text: '', voice: false, buttons: [] }) };
  return out;
}
/** Labels edited in the editor: a label that is gone hands its reply to the new label at the same position
 *  (unless the new label has its own saved / default reply). Returns the map for the new labels. */
export function remapLine(map: BtnReplies, ln: BtnLine, prev: string[], next: string[]): BtnLineMap {
  const before = effectiveLine(map, ln, prev);
  const nextKeys = new Set(next.map(btnKey));
  const out: BtnLineMap = {};
  next.forEach((l, i) => {
    const own = findKey(before, l) ?? findKey(map[ln] || {}, l);
    if (own) { out[l] = { ...(before[own] || map[ln][own]) }; return; }
    const old = prev[i];
    if (old && !nextKeys.has(btnKey(old)) && before[old]) { out[l] = { ...before[old] }; return; }
    const d = replyFor({ agency: {}, premium: {}, funnel: {} }, ln, next, l);
    out[l] = d ? { ...d } : { text: '', voice: false, buttons: [] };
  });
  return out;
}

/** {placeholders} → values (unknown ones are left as they are), then empty INR bits are tidied away (no INR rate set). */
export function fillBtnText(tpl: string, v: Record<string, string>) {
  // v140: a "Payment: {payment}" line is left out while no payment methods are set (no invented claims)
  let t = String(tpl || '').split('\n').filter(l => !(/\{payment\}/.test(l) && /^\s*payment\b/i.test(l) && !String(v.payment || '').trim())).join('\n');
  t = t.replace(/\{(\w+)\}/g, (m, k) => (k in v ? v[k] : m));
  t = t.replace(/%%/g, '%').replace(/\s*\(\s*INR\s*\)/g, '').replace(/\s*\(\s*\)/g, '').replace(/\s*\/\s*INR\b/g, '')
    .replace(/[ \t]{2,}/g, ' ').replace(/ +([.,!?])/g, '$1');
  return t.trim();
}
