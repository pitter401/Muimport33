/** v159: incentive / bonus from the admin.
 *  The admin types a total (e.g. $30) → it is shared equally by the agents whose "Receiving leads" is ON (never the manager):
 *  3 agents → $10 each. It goes into their earnings (wallet, can be withdrawn) and they get a notification.
 *  It is a cost for us: taken off the net profit (Home, Team, daily). */
import { all, one, run, db, commSql } from './db';
import { now, money, HttpError } from './util';
import { agentById, notifyAgent, wallet } from './crm';
import { hotSql } from './calls';
import { agentSalesByProduct, bySource, activeByAgent } from './profit';

const ELIGIBLE = "deleted=0 AND receive=1 AND COALESCE(role,'agent')!='manager'";
export function bonusAgents() { return all<{ id: number; name: string }>(`SELECT id, name FROM agents WHERE ${ELIGIBLE} ORDER BY id`); }

/** Equal shares in cents; the leftover cent(s) go to the first agents so the total is exact. */
export function splitEqual(total: number, n: number) {
  const c = Math.round(total * 100);
  const base = Math.floor(c / n), extra = c - base * n;
  return Array.from({ length: n }, (_, i) => (base + (i < extra ? 1 : 0)) / 100);
}

export async function giveBonus(b: Record<string, unknown>, by = 'Admin') {
  const total = money(b.amount);
  if (!(total > 0)) throw new HttpError(400, 'Enter the incentive amount');
  if (total > 100000) throw new HttpError(400, 'Amount is too big');
  const note = String(b.note || '').trim().slice(0, 120);
  const ag = bonusAgents();
  if (!ag.length) throw new HttpError(400, 'No agent has receiving leads ON');
  // the admin saw this list → if it changed meanwhile, ask again (never pay someone not shown)
  if (!Array.isArray(b.ids)) throw new HttpError(400, 'Open the incentive screen again (the agent list is needed)');
  {
    const want = (b.ids as unknown[]).map(Number).sort((x, y) => x - y).join(',');
    if (want !== ag.map(a => a.id).join(',')) throw new HttpError(409, 'The agents with receiving leads changed. Check the list again.');
  }
  // one tap = one incentive (a double tap within 10 s with the same amount is refused); check + save in one locked step
  const parts = splitEqual(total, ag.length);
  const at = now();
  let batch = 0;
  db().transaction(() => {
    const dup = one<{ n: number }>('SELECT COUNT(*) n FROM (SELECT ROUND(SUM(amount),2) s, MAX(created_at) at FROM agent_bonus GROUP BY batch) WHERE at>? AND s=?', at - 10000, total)?.n || 0;
    if (dup) throw new HttpError(409, 'This incentive was just added');
    batch = (one<{ b: number }>('SELECT COALESCE(MAX(batch),0) b FROM agent_bonus')?.b || 0) + 1;
    ag.forEach((a, i) => run('INSERT INTO agent_bonus(batch, agent_id, amount, note, by, created_at) VALUES(?,?,?,?,?,?)', batch, a.id, parts[i], note || null, by, at));
  }).immediate();
  for (const [i, a] of ag.entries()) {
    const amt = '$' + parts[i].toLocaleString('en-US', { minimumFractionDigits: parts[i] % 1 ? 2 : 0, maximumFractionDigits: 2 });
    const t = `${amt} incentive added by manager`;
    try { await notifyAgent(agentById(a.id), `🎁 ${t}${note ? `\n${note}` : ''}`, null, { title: t, body: note || 'Added to your earnings' }); } catch { /* */ }
  }
  return { ok: true, batch, total, each: parts, agents: ag.map((a, i) => ({ ...a, amount: parts[i] })) };
}

export function bonusHistory(limit = 30) {
  const rows = all<{ batch: number; total: number; n: number; note: string | null; by: string | null; at: number; names: string }>(
    "SELECT batch, ROUND(SUM(amount),2) total, COUNT(*) n, MAX(note) note, MAX(by) by, MAX(created_at) at, GROUP_CONCAT(agent_id) names FROM agent_bonus GROUP BY batch ORDER BY batch DESC LIMIT ?", limit);
  return rows.map(r => ({ ...r, agents: all<{ name: string; amount: number }>('SELECT a.name, b.amount FROM agent_bonus b LEFT JOIN agents a ON a.id=b.agent_id WHERE b.batch=? ORDER BY b.id', r.batch), can_delete: now() - r.at < 24 * 3600000 }));
}
/** A mistake: remove the whole incentive (within 24 h, before it is withdrawn). */
export function deleteBonus(batch: unknown) {
  const b = Number(batch);
  const r = one<{ at: number }>('SELECT MAX(created_at) at FROM agent_bonus WHERE batch=?', b);
  if (!r?.at) throw new HttpError(404, 'Incentive not found');
  if (now() - r.at > 24 * 3600000) throw new HttpError(400, 'Only within 24 hours');
  db().transaction(() => {
    for (const x of all<{ agent_id: number; amount: number; name: string | null }>('SELECT b.agent_id, b.amount, a.name FROM agent_bonus b LEFT JOIN agents a ON a.id=b.agent_id WHERE b.batch=?', b))
      if (wallet(x.agent_id).available + 0.001 < x.amount) throw new HttpError(400, `${x.name || 'An agent'} already asked to withdraw this money. Remove it from their payout first.`);
    run('DELETE FROM agent_bonus WHERE batch=?', b);
  }).immediate();
  return { ok: true };
}

/** v160: buyers of a period, one row per chat: first purchase in the period, first purchase ever, first message of the chat.
 *  New buyer = first purchase ever is in the period; repeat = bought before. Days to buy = first message → first purchase (new buyers only);
 *  "old chat" = the chat started 7+ days before that first purchase. */
export function buyerStats(rows: { at: number; first_buy: number; first_msg: number | null }[], f: number) {
  const DAY = 86400000;
  const fresh = rows.filter(r => r.first_buy >= f);
  const days = fresh.filter(r => r.first_msg && r.first_msg > 0 && r.first_buy >= r.first_msg).map(r => (r.first_buy - (r.first_msg as number)) / DAY);
  const old = days.filter(d => d >= 7);
  const avg = (a: number[]) => a.length ? Math.round(a.reduce((x, y) => x + y, 0) / a.length * 10) / 10 : null;
  return { new_buyers: fresh.length, repeat_buyers: rows.length - fresh.length, old_buyers: old.length, avg_days_to_buy: avg(days), avg_days_old: avg(old) };
}
/** SQL: one row per chat that bought in [f,t) (alias x on sales; extra WHERE for the sales). Params: f, t, then the where's own. */
export const buyerRowsSql = (where: string) => `SELECT MIN(x.created_at) at, (SELECT MIN(y.created_at) FROM sales y WHERE y.lead_id=x.lead_id) first_buy,
  COALESCE((SELECT MIN(m.created_at) FROM messages m WHERE m.lead_id=x.lead_id AND m.dir='in'), (SELECT COALESCE(l.started_at, l.created_at) FROM leads l WHERE l.id=x.lead_id)) first_msg
  FROM sales x WHERE x.lead_id IS NOT NULL AND x.created_at>=? AND x.created_at<? AND (${where}) GROUP BY x.lead_id`;
export const bonusSum = (f: number, t: number, agent?: number) => money(one<{ v: number }>(`SELECT COALESCE(SUM(amount),0) v FROM agent_bonus WHERE created_at>=? AND created_at<?${agent ? ' AND agent_id=?' : ''}`, f, t, ...(agent ? [agent] : []))?.v || 0);
export const bonusTotal = (agent: number) => money(one<{ v: number }>('SELECT COALESCE(SUM(amount),0) v FROM agent_bonus WHERE agent_id=?', agent)?.v || 0);

/** The agent's own dashboard (Home of the agent app) for a range.
 *  v160: people (not messages) who wrote; hot = right now; buyers from old chats + average days from the first message to buying;
 *  the wallet (what can be withdrawn) for the payout request. */
export function agentDashboard(agentId: number, f: number, t: number) {
  const DAY = 86400000;
  const LEAD_AT = 'COALESCE(l.started_at, l.assigned_at, l.created_at)';
  const leads = one<{ n: number }>(`SELECT COUNT(*) n FROM leads l WHERE l.agent_id=? AND ${LEAD_AT}>=? AND ${LEAD_AT}<? AND l.status!='merged' AND l.tg_chat_id IS NOT NULL`, agentId, f, t)!.n;
  // people who wrote in the period (each chat once, old or new)
  const ppl = one<{ n: number; nw: number }>(`SELECT COUNT(*) n, COALESCE(SUM(${LEAD_AT}>=? AND ${LEAD_AT}<?),0) nw FROM leads l WHERE l.agent_id=? AND l.status!='merged'
      AND l.id IN (SELECT m.lead_id FROM messages m WHERE m.dir='in' AND m.created_at>=? AND m.created_at<?)`, f, t, agentId, f, t)!;
  const hot = one<{ n: number }>(`SELECT COUNT(*) n FROM leads l WHERE l.agent_id=? AND ${hotSql('l')}`, agentId)!.n;
  const sales = one<{ n: number; accts: number; rev: number }>("SELECT COUNT(*) n, COALESCE(SUM(CASE WHEN service='account' THEN qty ELSE 0 END),0) accts, COALESCE(SUM(amount),0) rev FROM sales WHERE agent_id=? AND created_at>=? AND created_at<?", agentId, f, t)!;
  // buyers: one row per chat + sales with no chat (each its own buyer)
  const buyers = all<{ at: number; first_buy: number; first_msg: number | null }>(buyerRowsSql('x.agent_id=?'), f, t, agentId);
  const noChat = one<{ n: number }>('SELECT COUNT(*) n FROM sales WHERE agent_id=? AND created_at>=? AND created_at<? AND lead_id IS NULL', agentId, f, t)!.n;
  const bs = buyerStats(buyers, f);
  const comm = money(one<{ c: number }>(`SELECT ${commSql('?', 'x.created_at>=? AND x.created_at<?')} c`, agentId, f, t, agentId, f, t)?.c || 0);
  const tops = one<{ n: number; v: number }>('SELECT COUNT(*) n, COALESCE(SUM(amount),0) v FROM topups WHERE agent_id=? AND created_at>=? AND created_at<?', agentId, f, t)!;
  const bonus = bonusSum(f, t, agentId);
  const bonusRows = all<{ amount: number; note: string | null; created_at: number }>('SELECT amount, note, created_at FROM agent_bonus WHERE agent_id=? AND created_at>=? AND created_at<? ORDER BY id DESC LIMIT 20', agentId, f, t);
  const w = wallet(agentId);
  // conversion: people who bought ÷ people who were active (wrote, or bought without writing) in the period
  // v162: same rule as Team: a chat counts for the last seller in the period, else its owner; bot-channel chats only when they bought
  const own = activeByAgent(f, t).get(agentId) || { act: 0, buy: 0 };
  const active = own.act + noChat;
  const newBought = one<{ n: number }>(`SELECT COUNT(*) n FROM leads l WHERE l.agent_id=? AND ${LEAD_AT}>=? AND ${LEAD_AT}<? AND l.status!='merged' AND l.tg_chat_id IS NOT NULL AND EXISTS(SELECT 1 FROM sales x WHERE x.lead_id=l.id AND x.created_at<?)`, agentId, f, t, t)!.n; // v161: bought by the end of the period
  const pct = (a: number, b: number) => b > 0 ? Math.round(a / b * 1000) / 10 : null;
  return {
    conv_pct: pct(own.buy + noChat, active), active, conv_buyers: own.buy + noChat, new_bought: newBought, new_conv_pct: pct(newBought, leads),
    leads, people: ppl.n, people_new: ppl.nw, people_old: ppl.n - ppl.nw, hot_now: hot,
    customers: buyers.length + noChat, sales: sales.n, accounts: sales.accts, revenue: money(sales.rev), topups: tops.n, topup_vol: money(tops.v),
    ...bs, no_chat: noChat, products: agentSalesByProduct(agentId, f, t) /* v166: by split share */, sources: bySource(f, t, 'x.agent_id=?', 'l.agent_id=?', [agentId], [agentId]),
    commission: comm, bonus, earned: money(comm + bonus), bonus_rows: bonusRows,
    wallet: { available: w.available, pending: w.pending, paid: w.paid },
  };
}
