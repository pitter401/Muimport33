/* v168: automatic STATUS VIDEOS (plan A) + agents' "download my reel" (plan D).
 *
 *  A. Admin status video
 *   - Stock: the admin uploads many 16:9 videos with a song (chunked, like the daily reel). Each is only checked (ffmpeg probe);
 *     the renderer reads it directly, so there is no re-encode. "N left" = ready, unused stock.
 *   - Night job (worker): from 01:00 IST it checks every 10 min whether the server is quiet (1-min load < 0.7 x CPU cores, no
 *     render running or queued, no Meta queue job running) and then queues yesterday's video in DARK and LIGHT, until 07:00 IST.
 *     It picks one random unused stock video (then marked used), and the next enabled admin format in turn (a different one each
 *     day). LIGHT uses the same format when it has a light design, else the next format that has one; if none has one, the
 *     dark render is used for both, labelled "Light not available for this format". No stock → nothing that day.
 *   - The numbers = exactly the admin Home for that day (range "d:<day>", all lines): see adminDayNumbers. Read-only.
 *   - The stock file is deleted once its renders are done. Renders are kept 14 days.
 *  D. Agent download (setting "Agents can download their reel", OFF by default)
 *   - On demand: the agent taps "Make video" on the Dashboard card after watching today's first reel (showing 1). One job is
 *     queued and rendered with an AGENT format (their day-start style when it is E–T, else the A–D → E–T map below), their
 *     name, their next quotes, "Yesterday you earned" (commission + incentive, only when > 0) and the same video.
 *   - The file is served only to that agent, only while the setting is ON. Kept 3 days.
 *  Jobs run one at a time in the WORKER (never in the web app), at low priority (see reelrender.ts). */
import fs from 'fs';
import os from 'os';
import path from 'path';
import crypto from 'crypto';
import { spawn } from 'child_process';
import { Readable } from 'stream';
import { one, all, run, commSql, db } from './db';
import { num, money, HttpError, dayRange, localDate } from './util';
import { json } from './http';
import { ffmpegPath } from './voicefx';
import { getSettings } from './settings';
import { ensureAutoSpend, costSql, replCost } from './profit';
import { reelDay, IST_MS, reelDir, takeQuotes, quotesNeeded, firstShowingPick } from './reel';
import { REEL_QUOTES } from './reelquotes';
import { scanTemplates, findChromium, chromiumInfo, svidDir, probeVideo, sweepWork, type Tpl } from './reelrender';

/* ---------------- schema ---------------- */

const SCHEMA = `
CREATE TABLE IF NOT EXISTS svid_stock(id INTEGER PRIMARY KEY AUTOINCREMENT, file TEXT, name TEXT, size INTEGER, duration REAL, width INTEGER, height INTEGER,
  audio INTEGER DEFAULT 1, state TEXT DEFAULT 'ready', note TEXT, created_at INTEGER, used_day TEXT, used_at INTEGER, file_gone INTEGER DEFAULT 0, deleted INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS svid_jobs(id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT, day TEXT, theme TEXT, fmt TEXT, agent_id INTEGER, stock_id INTEGER, reel_id INTEGER,
  state TEXT DEFAULT 'queued', progress INTEGER DEFAULT 0, file TEXT, size INTEGER, duration REAL, error TEXT, note TEXT, trig TEXT, data TEXT, prio INTEGER DEFAULT 5,
  fallback_of INTEGER, attempts INTEGER DEFAULT 0, created_at INTEGER, started_at INTEGER, done_at INTEGER, ms INTEGER, deleted INTEGER DEFAULT 0);
CREATE INDEX IF NOT EXISTS i_svid_jobs ON svid_jobs(kind, day, deleted);
CREATE INDEX IF NOT EXISTS i_svid_jobs_state ON svid_jobs(state);
`;
const COLS: [string, string][] = [['next_at', 'INTEGER'], ['fail_since', 'INTEGER'], ['fails', 'INTEGER DEFAULT 0']]; // v168: auto-retry
let ready = false;
export function ensureSvidTables() {
  if (ready) return;
  db().exec(SCHEMA);
  const have = (db().prepare('PRAGMA table_xinfo(svid_jobs)').all() as { name: string }[]).map(c => c.name);
  for (const [c, t] of COLS) if (!have.includes(c)) { try { db().exec(`ALTER TABLE svid_jobs ADD COLUMN ${c} ${t}`); } catch { /* added by the other process */ } }
  ready = true;
}

/* ---------------- settings ---------------- */

/** v168: settings keys (also in settings.ts DEFAULTS / AUTO_KEYS; read here straight from the table). */
export const SVID_DEFAULTS = {
  svid_on: '0',          // night job on/off
  svid_formats: '',      // enabled admin formats (comma list); empty = all installed
  svid_fmt_last: '',     // rotation: last dark format used
  svid_fmt_last_l: '',   // rotation: last light format used
  svid_agent_dl: '0',    // agents can download their reel
  svid_tall: '1',
  svid_formats_v175: '', // v175: '1' once S21–S30 were switched on in a saved list
  svid_redo: '',         // v169: '169' once the one-time re-make in the new quality was queued        // v169: full-screen 9:20 (1080x2400) for tall phones; '0' = 9:16 (1080x1920)
  svid_night: '',        // the data day the night job last handled (one try per night)
  svid_night_note: '',   // what the night job last said (shown in the admin)
  svid_worker: '',       // the worker's heartbeat {at, chromium, ffmpeg}
  svid_install: '',      // renderer install started at (ms)
  svid_install_n: '0',   // installs tried since the last time a Chromium was found (auto self-heal, at most once an hour)
};
const getS = (k: keyof typeof SVID_DEFAULTS) => one<{ v: string }>('SELECT v FROM settings WHERE k=?', k)?.v ?? SVID_DEFAULTS[k];
const putS = (k: keyof typeof SVID_DEFAULTS, v: string) => run('INSERT INTO settings(k, v) VALUES(?, ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v', k, v);

export const ADMIN_KEEP_DAYS = 14, AGENT_KEEP_DAYS = 3;
/** v169: a used stock video is kept this many days after its data day (was: deleted as soon as its renders were done), so a day can be
 *  made again (e.g. in better quality after an update). */
export const STOCK_KEEP_DAYS = 3;
export const NIGHT_FROM_H = 1, NIGHT_TO_H = 7;
const addDays = (day: string, n: number) => new Date(Date.parse(day + 'T00:00:00Z') + n * 86400000).toISOString().slice(0, 10);
const isDay = (d: unknown): d is string => typeof d === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(d) && new Date(Date.parse(d + 'T00:00:00Z')).toISOString().slice(0, 10) === d;
const dayStartIst = (day: string) => Date.parse(day + 'T00:00:00Z') - IST_MS;
/** Hour of the day in IST (0..23.99). */
export const istHour = (ms: number) => (((ms + IST_MS) % 86400000) + 86400000) % 86400000 / 3600000;
const hash = (s: string) => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };

export function adminFormats(): Tpl[] { return scanTemplates().filter(t => t.kind === 'admin'); }
export function agentFormats(): Tpl[] { return scanTemplates().filter(t => t.kind === 'agent'); }
export function svidCfg() {
  ensureSvidTables();
  const inst = adminFormats().map(t => t.id);
  let raw = String(getS('svid_formats') || '');
  // v175: once, the 10 new admin formats (S21–S30) are switched ON in a saved list
  if (getS('svid_formats_v175') !== '1') { if (raw) { raw = [...new Set([...raw.split(',').map(x => x.trim()).filter(Boolean), 'S21', 'S22', 'S23', 'S24', 'S25', 'S26', 'S27', 'S28', 'S29', 'S30'])].join(','); putS('svid_formats', raw); } putS('svid_formats_v175', '1'); }
  const picked = raw ? raw.split(',').map(x => x.trim()).filter(x => inst.includes(x)) : inst;
  // a format installed after the admin saved a list counts as ON (new formats drop in on); "none" is never stored
  return { on: getS('svid_on') === '1', agent_dl: getS('svid_agent_dl') === '1', tall: getS('svid_tall') !== '0', formats: raw ? picked : inst, installed: inst };
}

/* ---------------- the numbers (= admin Home for that day) ---------------- */

export type AdminDay = { earned: number; revenue: number; sales: number; tg: { sales: number; amount: number }; wa: { sales: number; amount: number }; fees: number; fees_on: number };
/** The admin Home numbers for one day (Home → chosen date, All lines; the same SQL as route `stats` with no line / rt filter):
 *  net profit = sales revenue + top-up fees + website revenue + website top-up fees − ad spend − commission − account cost;
 *  top-up fees shown = top-ups + website top-ups; Telegram / WhatsApp split as Home. Raw values (may be 0 / negative). */
export function adminDayNumbers(day: string) {
  const s = getSettings();
  const [f, t] = dayRange('d:' + day, s);
  const n = (sql: string, ...a: unknown[]) => one<any>(sql, ...a)!;
  ensureAutoSpend(s); // Home does this too before reading ad_spend
  const sales = n('SELECT COUNT(*) n, COALESCE(SUM(amount),0) rev, COALESCE(SUM(commission),0) c FROM sales WHERE created_at>=? AND created_at<? AND (1=1)', f, t);
  const tops = n('SELECT COALESCE(SUM(amount),0) v, COALESCE(SUM(commission),0) c FROM topups WHERE created_at>=? AND created_at<? AND (1=1)', f, t);
  const spend = money(n('SELECT COALESCE(SUM(amount),0) v FROM ad_spend WHERE date>=? AND date<=?', localDate(f, s), localDate(t - 1, s)).v);
  const acctCost = money(n(`SELECT COALESCE(SUM(${costSql(s)}),0) v FROM sales WHERE created_at>=? AND created_at<? AND (1=1)`, f, t).v
    + n("SELECT COALESCE(SUM(qty),0) v FROM web_orders WHERE kind='account' AND status='delivered' AND delivered_at>=? AND delivered_at<?", f, t).v * num(s.acct_cost, 3) + replCost(f, t, null));
  const web = n("SELECT COUNT(*) n, COALESCE(SUM(amount),0) rev FROM web_orders WHERE status='delivered' AND delivered_at>=? AND delivered_at<?", f, t);
  const webTop = n("SELECT COALESCE(SUM(amount),0) v, COALESCE(SUM(fee),0) fee FROM web_topups WHERE status='done' AND done_at>=? AND done_at<?", f, t);
  const W = (tb: string) => `(COALESCE(${tb}.wa,0)=1 OR EXISTS(SELECT 1 FROM leads lw WHERE lw.id=${tb}.lead_id AND (lw.ch='wa' OR lw.tg_chat_id LIKE 'wa:%')))`;
  const sx = n(`SELECT COUNT(*) n, COALESCE(SUM(amount),0) rev FROM sales WHERE ${W('sales')} AND created_at>=? AND created_at<? AND (1=1)`, f, t);
  return {
    profit: money(sales.rev + tops.c + web.rev + webTop.fee - spend - sales.c - acctCost), revenue: money(sales.rev), sales: sales.n as number,
    split: { wa: { n: sx.n as number, rev: money(sx.rev) }, tg: { n: (sales.n - sx.n) as number, rev: money(sales.rev - sx.rev) } },
    topup_fees: money(tops.c), web_topup_fees: money(webTop.fee), topup_vol: money(tops.v), web_topup_vol: money(webTop.v),
  };
}
/** Positive only: anything 0 / negative becomes 0 (the templates hide 0). */
export function positiveDay(x: ReturnType<typeof adminDayNumbers>): AdminDay {
  const p = (v: number) => (v > 0 ? money(v) : 0), c = (v: number) => (v > 0 ? Math.round(v) : 0);
  return { earned: p(x.profit), revenue: p(x.revenue), sales: c(x.sales), tg: { sales: c(x.split.tg.n), amount: p(x.split.tg.rev) }, wa: { sales: c(x.split.wa.n), amount: p(x.split.wa.rev) },
    fees: p(x.topup_fees + x.web_topup_fees), fees_on: x.topup_fees + x.web_topup_fees > 0 ? p(x.topup_vol + x.web_topup_vol) : 0 };
}

/** A normal agent's earnings on `day` (IST): commission (split sales by share) + incentive, the same sums as reel.ts
 *  yesterdayOf / the agent dashboard. Never negative; never the business profit. */
export function agentDayEarned(agentId: number, day: string) {
  const f = dayStartIst(day), t = f + 86400000;
  const comm = one<{ c: number }>(`SELECT ${commSql('?', 'x.created_at>=? AND x.created_at<?')} c`, agentId, f, t, agentId, f, t)?.c || 0;
  const bonus = one<{ v: number }>('SELECT COALESCE(SUM(amount),0) v FROM agent_bonus WHERE agent_id=? AND created_at>=? AND created_at<?', agentId, f, t)?.v || 0;
  const sales = one<{ n: number }>('SELECT COUNT(*) n FROM sales WHERE agent_id=? AND created_at>=? AND created_at<?', agentId, f, t)?.n || 0;
  const earned = money(Math.max(0, comm + bonus));
  return { earned, sales: earned > 0 ? sales : 0 };
}

/* ---------------- quotes ---------------- */

/** The next quotes of a rotation key (reel.ts takeQuotes: 'status:admin' for the status video, 'reel:a:<id>' for an agent).
 *  If the rotation is unavailable for any reason, a stable pick from the pool. */
export function quotesFor(key: string, n: number) {
  try { const q = takeQuotes(key, n).filter(Boolean); if (q.length) return q; } catch (e) { console.warn('[svid] quotes', (e as Error).message); }
  const L = REEL_QUOTES.length, s = hash(key + '|' + Date.now().toString().slice(0, -5));
  return Array.from({ length: Math.min(n, L) }, (_, i) => REEL_QUOTES[(s + i) % L]);
}
const greetingAt = (ms: number) => { const h = istHour(ms); return h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening'; };

/* ---------------- formats: rotation + A–D map ---------------- */

/** The next format after `last` in `list` (in order, wrapping) — a different one each day. */
export function nextInTurn(list: string[], last: string) {
  if (!list.length) return null;
  const i = list.indexOf(last);
  return list[(i + 1) % list.length]; // last not in the list (or empty) → the first
}
/** Agent styles A–D are in-app React only. For a download they map to the closest agent HTML format (documented in the
 *  report); if that one is not installed, a stable pick among the installed agent formats. */
// A Ambient (blurred glow) → M Aurora / J Glass Stack; B Cinema (projector) → L Film Strip / S Spotlight;
// C Story (story bars, colour card) → E Polaroid / P Bento; D Widescreen (whole frame, caption below) → R Swiss Minimal / H Magazine.
export const AGENT_MAP: Record<string, string[]> = { A: ['M', 'J'], B: ['L', 'S'], C: ['E', 'P'], D: ['R', 'H'] };
export function agentFormatFor(style: string, seed: string): string | null {
  const inst = agentFormats().map(t => t.id);
  if (!inst.length) return null;
  if (inst.includes(style)) return style;
  for (const c of AGENT_MAP[style] || []) if (inst.includes(c)) return c;
  return inst[hash(seed) % inst.length];
}

/* ---------------- jobs ---------------- */

type Job = { id: number; kind: 'admin' | 'agent'; day: string; theme: 'dark' | 'light'; fmt: string; agent_id: number | null; stock_id: number | null; reel_id: number | null;
  state: string; progress: number; file: string | null; size: number | null; duration: number | null; error: string | null; note: string | null; trig: string | null; data: string | null;
  prio: number; fallback_of: number | null; attempts: number; created_at: number; started_at: number | null; done_at: number | null; ms: number | null; deleted: number;
  next_at: number | null; fail_since: number | null; fails: number | null };
type Stock = { id: number; file: string; name: string; size: number; duration: number; width: number; height: number; audio: number; state: string; note: string | null; created_at: number; used_day: string | null; used_at: number | null; file_gone: number; deleted: number };

export const outDir = () => { const d = path.join(svidDir(), 'out'); fs.mkdirSync(d, { recursive: true }); return d; };
export const stockDir = () => { const d = path.join(svidDir(), 'stock'); fs.mkdirSync(d, { recursive: true }); return d; };
const activeJobs = () => one<{ n: number }>("SELECT COUNT(*) n FROM svid_jobs WHERE state IN ('queued','running') AND deleted=0")!.n;
/** Jobs still to be made (incl. ones waiting for their next automatic try). */
const pendingJobs = () => one<{ n: number }>("SELECT COUNT(*) n FROM svid_jobs WHERE state IN ('queued','running','retry','waiting') AND deleted=0")!.n;
const stockLeft = () => all<Stock>("SELECT * FROM svid_stock WHERE deleted=0 AND state='ready' AND used_day IS NULL AND file_gone=0 ORDER BY id");

/** Picks one random unused stock video and marks it used for `day` (atomic). null = no stock. */
export function pickStock(day: string, rnd = Math.random): Stock | null {
  return db().transaction(() => {
    const left = stockLeft().filter(s => fs.existsSync(path.join(stockDir(), s.file)));
    if (!left.length) return null;
    const s = left[Math.floor(rnd() * left.length) % left.length];
    run('UPDATE svid_stock SET used_day=?, used_at=? WHERE id=? AND used_day IS NULL', day, Date.now(), s.id);
    return one<Stock>('SELECT * FROM svid_stock WHERE id=?', s.id)!;
  })();
}

/** Queues the admin status video of `day` (dark + light). Returns the job ids (and why not, when nothing was queued). */
type Queued = { ok: true; jobs: number[]; stock: number; fmt: string; fmt_light: string | null } | { ok: false; why: string };
export function queueAdminDay(day: string, trig: 'night' | 'now', at = Date.now()): Queued {
  ensureSvidTables();
  // one write transaction (BEGIN IMMEDIATE): the web app's "Make now" and the worker's night job can never both queue a day
  return db().transaction(() => queueAdminDay0(day, trig, at)).immediate();
}
function queueAdminDay0(day: string, trig: 'night' | 'now', at: number): Queued {
  const c = svidCfg();
  if (one("SELECT 1 FROM svid_jobs WHERE kind='admin' AND day=? AND state IN ('queued','running','waiting','retry') AND deleted=0", day)) return { ok: false, why: 'busy' };
  const fmts = adminFormats().filter(t => c.formats.includes(t.id));
  if (!fmts.length) return { ok: false, why: 'no_format' };
  // the stock already used for this day (Make now again / a failed night), else a new random one
  let stock = one<Stock>("SELECT * FROM svid_stock WHERE used_day=? AND deleted=0 AND file_gone=0 AND state='ready' ORDER BY used_at DESC LIMIT 1", day);
  if (stock && !fs.existsSync(path.join(stockDir(), stock.file))) stock = undefined;
  if (!stock) stock = pickStock(day) || undefined;
  if (!stock) return { ok: false, why: 'no_stock' };
  const dark = nextInTurn(fmts.map(t => t.id), getS('svid_fmt_last'))!;
  // LIGHT = the same format when it has a light design (one look, two versions); else the next format with one, in turn
  const lights = fmts.filter(t => t.themes.includes('light')).map(t => t.id);
  const light = lights.includes(dark) ? dark : lights.length ? nextInTurn(lights, getS('svid_fmt_last_l')) : null;
  putS('svid_fmt_last', dark);
  if (light) putS('svid_fmt_last_l', light);
  const data = { name: 'AdsBhai Admin', greeting: 'Good morning', day, today: addDays(day, 1), streak: 0, showing: 1, line_of_day: '',
    quotes: quotesFor('status:admin', quotesNeeded(Math.min(45, stock.duration || 40), 1) + 1), yesterday: positiveDay(adminDayNumbers(day)) };
  const ins = (theme: string, fmt: string, fallback: number | null, state: string, note: string | null) => Number(run(
    'INSERT INTO svid_jobs(kind, day, theme, fmt, stock_id, state, trig, data, prio, fallback_of, note, created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
    'admin', day, theme, fmt, stock.id, state, trig, JSON.stringify(data), trig === 'now' ? 3 : 6, fallback, note, at).lastInsertRowid);
  const d = ins('dark', dark, null, 'queued', null);
  const l = light ? ins('light', light, null, 'queued', null) : ins('light', dark, d, 'waiting', 'Light not available for this format');
  return { ok: true, jobs: [d, l], stock: stock.id, fmt: dark, fmt_light: light };
}

/** What the night job does now. 01:00–07:00 IST: only when the server is quiet (1-min load < 0.7 x cores, no render running or
 *  queued, no Meta queue job running). After 07:00 it must not wait forever (owner: the video must be there in the morning):
 *  moderate load (< 1.5 x cores) is fine, and from 12:00 IST it is queued whatever the load (it renders at low priority).
 *  Returns 'window' (before 01:00), 'done' (already handled), 'busy', 'queued' or why not. */
export function nightTick(now = Date.now(), load = os.loadavg()[0], cores = os.cpus().length || 1) {
  ensureSvidTables();
  const c = svidCfg();
  if (!c.on) return { did: 'off' as const };
  const h = istHour(now), day = addDays(reelDay(now), -1);
  if (h < NIGHT_FROM_H) return { did: 'window' as const };
  if (getS('svid_night') === day) return { did: 'done' as const };
  if (one("SELECT 1 FROM svid_jobs WHERE kind='admin' AND day=? AND deleted=0 AND state!='failed'", day)) { putS('svid_night', day); return { did: 'done' as const }; }
  const mq = (() => { try { return one<{ n: number }>("SELECT COUNT(*) n FROM meta_jobs WHERE status='running'")!.n; } catch { return 0; } })();
  const night = h < NIGHT_TO_H;
  const quiet = night ? load < 0.7 * cores && activeJobs() === 0 && mq === 0 : load < 1.5 * cores || h >= 12;
  if (!quiet) {
    putS('svid_night_note', `Waiting for a quiet server (load ${load.toFixed(2)}, ${cores} cores${activeJobs() ? ', a render is running' : ''}${mq ? ', Meta queue busy' : ''}). Next check in 10 min.`);
    console.log('[svid] night: waiting, load', load.toFixed(2), 'cores', cores, 'active', activeJobs(), 'meta', mq);
    return { did: 'busy' as const, load };
  }
  const r = queueAdminDay(day, 'night', now);
  putS('svid_night', day);
  console.log('[svid] night', day, r.ok ? `queued ${r.fmt}/${r.fmt_light || 'same as dark'}${night ? '' : ' (after 07:00, moderate load allowed)'}` : r.why);
  putS('svid_night_note', r.ok ? `Queued ${day} at ${new Date(now + IST_MS).toISOString().slice(11, 16)} IST (${r.fmt}${r.fmt_light ? ' / ' + r.fmt_light : ''}).` : r.why === 'no_stock' ? `No video in stock: no status video for ${day}.` : r.why === 'no_format' ? 'No format is switched on.' : `Not queued: ${r.why}.`);
  return { did: r.ok ? 'queued' as const : r.why as 'no_stock', ...(r.ok ? { jobs: r.jobs } : {}) };
}

/** Clean-up (worker, hourly): old renders (admin 14 days, agent 3 days), stock files whose renders are done, used stock older
 *  than 14 days, the frame cache. Returns counts. */
export function svidCleanup(now = Date.now()) {
  ensureSvidTables();
  const today = reelDay(now);
  let renders = 0, stock = 0;
  for (const j of all<Job>("SELECT * FROM svid_jobs WHERE deleted=0 AND state NOT IN ('queued','running','waiting') AND ((kind='admin' AND day<?) OR (kind='agent' AND day<?))", addDays(today, -ADMIN_KEEP_DAYS), addDays(today, -AGENT_KEEP_DAYS + 1))) {
    if (j.file && !all<{ id: number }>('SELECT id FROM svid_jobs WHERE file=? AND deleted=0 AND id!=?', j.file, j.id).length) try { fs.unlinkSync(path.join(outDir(), j.file)); } catch { /* gone */ }
    run('UPDATE svid_jobs SET deleted=1 WHERE id=?', j.id); renders++;
  }
  for (const s of all<Stock>("SELECT * FROM svid_stock WHERE used_day IS NOT NULL AND file_gone=0")) {
    const js = all<Job>('SELECT * FROM svid_jobs WHERE stock_id=? AND deleted=0', s.id);
    const allDone = js.length > 0 && js.every(j => j.state === 'done');
    if ((allDone && s.used_day! < addDays(today, -STOCK_KEEP_DAYS)) || s.used_day! < addDays(today, -ADMIN_KEEP_DAYS) || s.deleted) {
      try { fs.unlinkSync(path.join(stockDir(), s.file)); } catch { /* gone */ }
      run('UPDATE svid_stock SET file_gone=1 WHERE id=?', s.id); stock++;
    }
  }
  try { for (const f of fs.readdirSync(stockDir())) if (f.startsWith('tmp-') && now - fs.statSync(path.join(stockDir(), f)).mtimeMs > 3 * 3600000) fs.unlinkSync(path.join(stockDir(), f)); } catch { /* none */ }
  let work = 0;
  try { work = sweepWork(); } catch { /* none */ }
  return { renders, stock, work };
}

/* ---------------- the runner (worker only) ---------------- */

type GR = typeof globalThis & { __svidBusy?: boolean };
/** Auto-retry (owner: he uploads, sleeps, and the video must be there in the morning): 1, 3, 10, 20 min, then every 30 min, until
 *  it is made. A failed try never needs the owner, except when nothing can fix it (no stock video left, the reel is gone). */
export const RETRY_MIN = [1, 3, 10, 20, 30];
export const retryDelay = (fails: number) => RETRY_MIN[Math.max(1, Math.min(fails, RETRY_MIN.length)) - 1] * 60000;
/** After this many failed tries with the same stock video, the next try uses another unused one (the video may be bad). */
export const SWITCH_STOCK_AFTER = 3;
class Permanent extends Error {}

/** The next job that may run now: new ones first (agents, then Make now, then the night), then retries whose time has come.
 *  An admin RETRY also waits for a quiet-enough server (night 0.7 x cores, day 1.5 x cores) but at most 60 min past its time. */
function nextJob(now: number, load: number, cores: number) {
  const q = one<Job>("SELECT * FROM svid_jobs WHERE state='queued' AND deleted=0 ORDER BY prio, id LIMIT 1");
  if (q) return q;
  for (const j of all<Job>("SELECT * FROM svid_jobs WHERE state='retry' AND deleted=0 AND COALESCE(next_at,0)<=? ORDER BY prio, next_at, id", now)) {
    if (j.kind === 'agent') return j;
    const lim = istHour(now) >= NIGHT_FROM_H && istHour(now) < NIGHT_TO_H ? 0.7 * cores : 1.5 * cores;
    if (load < lim || now - (j.next_at || 0) > 60 * 60000) return j;
    console.log('[svid] retry', j.id, 'held: load', load.toFixed(2));
  }
  return null;
}

/** Runs the next job (see nextJob). Returns the job id or null. The render itself is in reelrender.ts (imported lazily, so the
 *  web app never loads Playwright); tests pass a fake. Every try is logged. */
export async function runNext(render?: (o: any) => Promise<any>, now = Date.now(), load = os.loadavg()[0], cores = os.cpus().length || 1): Promise<number | null> {
  ensureSvidTables();
  const g = globalThis as GR;
  if (g.__svidBusy) return null;
  const j = nextJob(now, load, cores);
  if (!j) return null;
  if (!run("UPDATE svid_jobs SET state='running', started_at=?, progress=1, attempts=attempts+1 WHERE id=? AND state IN ('queued','retry')", Date.now(), j.id).changes) return null;
  g.__svidBusy = true;
  const file = `v${j.id}-${crypto.randomBytes(5).toString('hex')}.mp4`;
  const out = path.join(outDir(), file);
  console.log(`[svid] job ${j.id} try ${(j.attempts || 0) + 1}: ${j.kind} ${j.day} ${j.theme} ${j.fmt}`);
  try {
    let cur = j;
    // self-heal before the try: a format that is no longer installed → another one of that kind (and theme)
    const kindF = cur.kind === 'admin' ? adminFormats() : agentFormats();
    if (!kindF.some(t => t.id === cur.fmt)) {
      const alt = kindF.find(t => t.themes.includes(cur.theme)) || kindF[0];
      if (!alt) throw new Permanent('No format is installed');
      run('UPDATE svid_jobs SET fmt=? WHERE id=?', alt.id, cur.id); console.log(`[svid] job ${cur.id}: format ${cur.fmt} is gone, using ${alt.id}`);
      cur = { ...cur, fmt: alt.id };
    }
    let src: string | null = null;
    if (cur.kind === 'admin') {
      const s = one<Stock>('SELECT * FROM svid_stock WHERE id=?', cur.stock_id);
      src = s && !s.file_gone && fs.existsSync(path.join(stockDir(), s.file)) ? path.join(stockDir(), s.file) : null;
      // the stock video is gone, or keeps failing → another unused one (for this job and its light / dark sibling)
      if (!src || (cur.fails || 0) >= SWITCH_STOCK_AFTER && (cur.fails || 0) % SWITCH_STOCK_AFTER === 0) {
        const ns = pickStock(cur.day);
        if (ns) {
          if (s && src) run("UPDATE svid_stock SET note='This video could not be used' WHERE id=?", s.id);
          run("UPDATE svid_jobs SET stock_id=? WHERE kind='admin' AND day=? AND deleted=0 AND state IN ('running','retry','waiting','queued')", ns.id, cur.day);
          console.log(`[svid] job ${cur.id}: switching to stock video ${ns.id}`);
          cur = { ...cur, stock_id: ns.id }; src = path.join(stockDir(), ns.file);
        } else if (!src) throw new Permanent('No video left in stock');
      }
    } else {
      const r = one<{ file: string; purged: number; deleted: number }>('SELECT file, purged, deleted FROM reels WHERE id=?', cur.reel_id);
      src = r && !r.purged && !r.deleted && r.file && fs.existsSync(path.join(reelDir(), r.file)) ? path.join(reelDir(), r.file) : null;
      if (!src) throw new Permanent('Today’s reel video is gone');
    }
    const R = render ? { renderReel: render } : await import('./reelrender');
    let last = 0;
    const res = await R.renderReel({ tpl: cur.fmt, theme: cur.theme, data: JSON.parse(cur.data || '{}'), video: src, out, tall: svidCfg().tall,
      onProgress: (p: number) => { if (p >= last + 2 || p >= 99) { last = p; run('UPDATE svid_jobs SET progress=? WHERE id=?', p, cur.id); } } });
    const size = fs.statSync(out).size;
    run("UPDATE svid_jobs SET state='done', progress=100, file=?, size=?, duration=?, done_at=?, ms=?, error=NULL, next_at=NULL WHERE id=?", file, size, res.duration, Date.now(), res.ms, cur.id);
    // the light slot waiting for this dark render (no light design): the same file
    run("UPDATE svid_jobs SET state='done', progress=100, file=?, size=?, duration=?, done_at=?, ms=0 WHERE fallback_of=? AND state='waiting'", file, size, res.duration, Date.now(), cur.id);
    console.log(`[svid] job ${cur.id} done in ${Math.round(res.ms / 1000)} s (${(size / 1048576).toFixed(1)} MB)`);
    replaceOlder(cur);
    try { svidCleanup(); } catch { /* next hour */ }
    return cur.id;
  } catch (e) {
    const msg = String((e as Error).message || e).slice(0, 300);
    try { fs.unlinkSync(out); } catch { /* none */ }
    if (e instanceof Permanent) {
      console.warn(`[svid] job ${j.id} failed for good: ${msg}`);
      run("UPDATE svid_jobs SET state='failed', error=?, done_at=?, next_at=NULL, fail_since=COALESCE(fail_since, ?) WHERE id=?", msg, Date.now(), Date.now(), j.id);
      run("UPDATE svid_jobs SET state='failed', error=?, done_at=? WHERE fallback_of=? AND state='waiting'", msg, Date.now(), j.id);
    } else {
      const fails = (j.fails || 0) + 1, wait = retryDelay(fails);
      console.warn(`[svid] job ${j.id} try failed (${fails}): ${msg} — next try in ${wait / 60000} min`);
      run("UPDATE svid_jobs SET state='retry', error=?, fails=?, next_at=?, fail_since=COALESCE(fail_since, ?), progress=0 WHERE id=?", msg, fails, now + wait, now, j.id);
    }
    return j.id;
  } finally { g.__svidBusy = false; }
}

/** A new render of a day replaces the older ones: admin = per day + theme (the newest finished one stays), agent = per day.
 *  A file is deleted only when no other row uses it (a light slot without a light design shares the dark file). */
function replaceOlder(j: Job) {
  const drop = (o: Job) => {
    run('UPDATE svid_jobs SET deleted=1 WHERE id=?', o.id);
    if (o.file && !one('SELECT 1 FROM svid_jobs WHERE file=? AND deleted=0', o.file)) try { fs.unlinkSync(path.join(outDir(), o.file)); } catch { /* gone */ }
  };
  if (j.kind === 'agent') { for (const o of all<Job>("SELECT * FROM svid_jobs WHERE kind='agent' AND agent_id=? AND day=? AND deleted=0 AND id<? AND state IN ('done','failed')", j.agent_id, j.day, j.id)) drop(o); return; }
  for (const th of ['dark', 'light']) {
    const newest = one<{ id: number }>("SELECT MAX(id) id FROM svid_jobs WHERE kind='admin' AND day=? AND theme=? AND deleted=0 AND state='done'", j.day, th)?.id;
    if (newest) for (const o of all<Job>("SELECT * FROM svid_jobs WHERE kind='admin' AND day=? AND theme=? AND deleted=0 AND id<? AND state IN ('done','failed')", j.day, th, newest)) drop(o);
  }
}

/** Worker start: a render cut short by a restart (or by the worker running out of memory) counts as a failed try and is
 *  retried on the normal schedule. */
export function resumeStale(now = Date.now()) {
  ensureSvidTables();
  for (const j of all<Job>("SELECT * FROM svid_jobs WHERE state='running'")) {
    const fails = (j.fails || 0) + 1;
    console.warn(`[svid] job ${j.id} was cut short by a restart — next try in ${retryDelay(fails) / 60000} min`);
    run("UPDATE svid_jobs SET state='retry', error='Stopped by a restart', fails=?, next_at=?, fail_since=COALESCE(fail_since, ?), progress=0 WHERE id=?", fails, now + retryDelay(fails), now, j.id);
  }
}
/** Worker heartbeat (every tick): the admin page shows whether the renderer works. */
let loggedChromium = '';
export function heartbeat() {
  const ci = chromiumInfo();
  const k = ci ? `${ci.source} ${ci.path}` : 'none';
  if (ci && getS('svid_install_n') !== '0') putS('svid_install_n', '0');
  if (k !== loggedChromium) { loggedChromium = k; console.log('[svid] video maker:', ci ? `Chromium = ${ci.source} (${ci.path})` : 'NO Chromium found (Admin → Status video → Retry installs one)', '· ffmpeg', ffmpegPath() || 'missing'); }
  putS('svid_worker', JSON.stringify({ at: Date.now(), chromium: chromiumInfo()?.source || null, ffmpeg: !!ffmpegPath(), cores: os.cpus().length, load: Math.round(os.loadavg()[0] * 100) / 100 }));
}

/* ---------------- renderer status + install ---------------- */

const APP = () => process.cwd();
const installLog = () => path.join(svidDir(), 'install.log');
export function rendererStatus(now = Date.now()) {
  let hb: { at?: number; chromium?: string | null; ffmpeg?: boolean; load?: number; cores?: number } = {};
  try { hb = JSON.parse(getS('svid_worker') || '{}'); } catch { /* none */ }
  const ci = chromiumInfo();
  const chromium = ci?.path || null;
  const instAt = num(getS('svid_install'));
  const installing = instAt > 0 && now - instAt < 20 * 60000 && !fs.existsSync(installLog() + '.done');
  let log = '';
  try { log = fs.readFileSync(installLog(), 'utf8').split('\n').filter(Boolean).slice(-6).join('\n').slice(-800); } catch { /* none */ }
  return { ok: !!chromium && !!ffmpegPath(), chromium: !!chromium, chromium_source: ci?.source || null, chromium_path: chromium, ffmpeg: !!ffmpegPath(), worker: !!hb.at && now - hb.at < 3 * 60000, worker_at: hb.at || null, load: hb.load ?? null, cores: hb.cores ?? os.cpus().length, installing, log };
}
/** POST svid/install: installs Playwright's headless Chromium in the background (same command as scripts/update.sh). */
export function startInstall() {
  const st = rendererStatus();
  if (st.installing) throw new HttpError(409, 'Already installing. Wait a few minutes.');
  if (st.chromium) throw new HttpError(409, `A Chromium is already there (${st.chromium_source}). Nothing to install.`);
  putS('svid_install', String(Date.now()));
  putS('svid_install_n', String(num(getS('svid_install_n')) + 1));
  console.log('[svid] installing the video maker (headless Chromium) in the background, try', getS('svid_install_n'));
  try { fs.unlinkSync(installLog() + '.done'); } catch { /* none */ }
  const log = JSON.stringify(installLog());
  const sh = `cd ${JSON.stringify(APP())} || exit 1; export PLAYWRIGHT_SKIP_BROWSER_GC=1; { echo "==> $(date) installing the video renderer (Chromium)";
if [ "$(id -u)" = 0 ]; then timeout 600 npx --no-install playwright-core install-deps chromium-headless-shell || echo "(system libraries: skipped)"; fi
timeout 900 npx --no-install playwright-core install --no-remove --only-shell chromium && echo "==> done" || echo "==> FAILED"; } > ${log} 2>&1; touch ${JSON.stringify(installLog() + '.done')}`;
  const child = spawn('setsid', ['bash', '-c', `nohup bash -c ${JSON.stringify(sh)} >/dev/null 2>&1 &`], { detached: true, stdio: 'ignore', cwd: APP() });
  child.unref();
  return { ok: true };
}

/* ---------------- file serving (Range) ---------------- */

function serveFile(p: string, req: Request, dlName?: string) {
  if (!fs.existsSync(p)) return new Response('not found', { status: 404 });
  const size = fs.statSync(p).size;
  const base: Record<string, string> = { 'content-type': 'video/mp4', 'accept-ranges': 'bytes', 'cache-control': 'private, max-age=3600', 'x-content-type-options': 'nosniff',
    ...(dlName ? { 'content-disposition': `attachment; filename="${dlName.replace(/[^\w.\-]/g, '_')}"` } : {}) };
  const stream = (a: number, b: number) => Readable.toWeb(fs.createReadStream(p, { start: a, end: b })) as unknown as ReadableStream;
  const rg = /^bytes=(\d*)-(\d*)$/.exec(req.headers.get('range') || '');
  if (rg && (rg[1] || rg[2])) {
    let a = rg[1] ? Number(rg[1]) : Math.max(0, size - Number(rg[2]));
    let b = rg[1] && rg[2] ? Math.min(Number(rg[2]), size - 1) : size - 1;
    if (a >= size || a > b) return new Response(null, { status: 416, headers: { ...base, 'content-range': `bytes */${size}` } });
    a = Math.max(0, a); b = Math.max(a, b);
    return new Response(req.method === 'HEAD' ? null : stream(a, b), { status: 206, headers: { ...base, 'content-range': `bytes ${a}-${b}/${size}`, 'content-length': String(b - a + 1) } });
  }
  return new Response(req.method === 'HEAD' ? null : stream(0, size - 1), { headers: { ...base, 'content-length': String(size) } });
}

/* ---------------- download links (for the Android apps) ----------------
 *  The apps open downloads in the phone's browser, which has no login cookie. So a logged-in POST svid/link or reeldl/link
 *  returns a 10-minute link to /api/vfile?k=… that is signed for ONE file (job id + kind + agent), and is checked again when
 *  it is used (agent links: the setting must still be ON and the file still theirs). It is never a login token. */
const LINK_MS = 10 * 60000;
const vsign = (d: string) => {
  const sec = process.env.APP_SECRET;
  if (!sec || sec.length < 16) throw new HttpError(500, 'APP_SECRET is missing');
  return crypto.createHmac('sha256', sec).update('svid-file|' + d).digest('base64url');
};
export function fileLink(j: { id: number; kind: string; agent_id: number | null }, now = Date.now()) {
  const d = Buffer.from(JSON.stringify({ j: j.id, k: j.kind, a: j.agent_id || 0, e: now + LINK_MS })).toString('base64url');
  return `/api/vfile?k=${d}.${vsign(d)}`;
}
/** GET /api/vfile?k=… → the file (attachment), or 403 / 404. */
export function serveLink(req: Request) {
  ensureSvidTables();
  if (req.method !== 'GET' && req.method !== 'HEAD') return json({ error: 'Use GET' }, 405);
  const [d, sig] = String(new URL(req.url).searchParams.get('k') || '').split('.');
  let good = '';
  try { good = d ? vsign(d) : ''; } catch { return json({ error: 'Not available' }, 500); }
  if (!d || !sig || good.length !== sig.length || !crypto.timingSafeEqual(Buffer.from(good), Buffer.from(sig))) return json({ error: 'This link is not valid' }, 403);
  let x: { j: number; k: string; a: number; e: number };
  try { x = JSON.parse(Buffer.from(d, 'base64url').toString()); } catch { return json({ error: 'This link is not valid' }, 403); }
  if (!(x.e > Date.now())) return json({ error: 'This link has expired. Tap Download again.' }, 403);
  const j = one<Job>('SELECT * FROM svid_jobs WHERE id=? AND deleted=0', num(x.j));
  if (!j || j.kind !== x.k || (j.agent_id || 0) !== x.a) return json({ error: 'Not found' }, 404);
  if (j.kind === 'agent' && !svidCfg().agent_dl) return json({ error: 'Downloading the reel is switched off' }, 403);
  if (j.state !== 'done' || !j.file) return json({ error: 'Not ready yet' }, 409);
  return serveFile(path.join(outDir(), j.file), req, j.kind === 'admin' ? `adsbhai-status-${j.day}-${j.theme}.mp4` : `my-reel-${j.day}.mp4`);
}

/* ---------------- admin API ---------------- */

const MAX_BYTES = 200 * 1024 * 1024, MAX_SEC = 45.5, CHUNK = 4 * 1024 * 1024;
type Up = { id: string; name: string; size: number; got: number; at: number; busy: boolean; ext: string };
type GU = typeof globalThis & { __svidUploads?: Map<string, Up> };
const uploads = () => { const g = globalThis as GU; return (g.__svidUploads ||= new Map()); };
const tmpPath = (id: string) => path.join(stockDir(), `tmp-${id}.part`);
const clean = (v: unknown, n: number) => String(v ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, n);
const pubJob = (j: Job) => ({ id: j.id, kind: j.kind, day: j.day, theme: j.theme, fmt: j.fmt, state: j.state === 'waiting' || j.state === 'retry' ? 'queued' : j.state, progress: j.progress || 0, size: j.size, duration: j.duration,
  error: j.error ? 'failed' : null, note: j.note, trig: j.trig, created_at: j.created_at, done_at: j.done_at, ms: j.ms, same_as_dark: !!j.fallback_of });
/** v168: what the admin must do, or null. Owner: show NOTHING technical; one plain sentence only when automatic recovery cannot
 *  fix it without him. Everything else (retries, installs, waiting for a quiet server) happens on its own and is only logged. */
export function problemFor(now = Date.now()): { text: string; action: 'install' | 'make' | null } | null {
  const rs = rendererStatus(now);
  if (!rs.ffmpeg) return { text: 'The video maker needs ffmpeg. Run “bash scripts/update.sh” on the server once.', action: null };
  if (!rs.chromium && !rs.installing && num(getS('svid_install_n')) >= 2) return { text: 'The video maker could not be installed. Run “bash scripts/update.sh” on the server once as root.', action: 'install' };
  if (rs.worker_at && now - rs.worker_at > 30 * 60000 && pendingJobs() > 0) return { text: 'The video maker is stopped. Run “pm2 restart all” on the server.', action: null };
  const yday = addDays(reelDay(now), -1);
  const bad = one<Job>("SELECT * FROM svid_jobs WHERE kind='admin' AND day=? AND deleted=0 AND state IN ('retry','failed') AND fail_since IS NOT NULL ORDER BY id DESC LIMIT 1", yday);
  if (bad && !one("SELECT 1 FROM svid_jobs WHERE kind='admin' AND day=? AND theme=? AND deleted=0 AND state='done' AND id>?", yday, bad.theme, bad.id)) {
    if (bad.state === 'failed' && /stock/i.test(bad.error || '')) return { text: 'Yesterday’s video needs a stock video. Upload one, then tap Retry.', action: 'make' };
    if (bad.state === 'failed' || now - (bad.fail_since || now) >= 3 * 3600000) return { text: 'Yesterday’s video keeps failing. Upload another video, then tap Retry.', action: 'make' };
  }
  return null;
}
const pubStock = (s: Stock) => ({ id: s.id, name: s.name, size: s.size, duration: s.duration, width: s.width, height: s.height, audio: !!s.audio, state: s.used_day ? 'used' : s.state, used_day: s.used_day, note: s.note, created_at: s.created_at });

async function writeChunk(req: Request, file: string, off: number, max: number) {
  if (!req.body) return 0;
  const fd = fs.openSync(file, 'r+');
  let pos = off, n = 0;
  try {
    const rd = req.body.getReader();
    for (;;) {
      const { done, value } = await rd.read();
      if (done) break;
      n += value.length;
      if (n > max) { void rd.cancel(); throw new HttpError(400, 'Chunk too large'); }
      fs.writeSync(fd, value, 0, value.length, pos);
      pos += value.length;
    }
  } finally { fs.closeSync(fd); }
  return n;
}

/** Admin API: `p` = the path after "svid/". GET = reads (and file downloads), POST = every change. */
export async function svidAdminApi(p: string, req: Request, nowMs = Date.now()): Promise<Response> {
  ensureSvidTables();
  const post = req.method === 'POST';
  const url = new URL(req.url);
  if (post && req.headers.get('sec-fetch-site') === 'cross-site') return json({ error: 'Cross-site request refused' }, 403);
  const today = reelDay(nowMs), yday = addDays(today, -1);
  if (p.startsWith('file/')) { // GET svid/file/<id>[?dl=1]
    if (post) return json({ error: 'Use GET' }, 405);
    const j = one<Job>("SELECT * FROM svid_jobs WHERE id=? AND kind='admin' AND state='done' AND deleted=0", num(p.slice(5)));
    if (!j || !j.file) return new Response('not found', { status: 404 });
    return serveFile(path.join(outDir(), j.file), req, url.searchParams.get('dl') ? `adsbhai-status-${j.day}-${j.theme}.mp4` : undefined);
  }
  if (p === 'upload_chunk') {
    if (!post) return json({ error: 'Use POST' }, 405);
    const u = uploads().get(String(url.searchParams.get('id') || ''));
    if (!u) throw new HttpError(404, 'Upload expired. Start again.');
    const off = num(url.searchParams.get('off'), -1);
    if (off !== u.got) return json({ error: 'Out of order', got: u.got }, 409);
    if (u.busy) return json({ error: 'Busy', got: u.got }, 409);
    u.busy = true;
    try {
      const n = await writeChunk(req, tmpPath(u.id), off, Math.min(CHUNK + 1024, u.size - u.got));
      if (!n) throw new HttpError(400, 'Empty chunk');
      u.got += n; u.at = Date.now();
    } catch (e) { try { fs.truncateSync(tmpPath(u.id), u.got); } catch { /* gone */ } throw e; } finally { u.busy = false; }
    return json({ ok: true, got: u.got });
  }
  const b: Record<string, any> = post ? await req.json().catch(() => ({})) : {};
  const needPost = () => { if (!post) throw new HttpError(405, 'Use POST'); };
  switch (p) {
    case 'state': {
      const c = svidCfg();
      const fmts = adminFormats().map(t => ({ id: t.id, name: t.name, themes: t.themes, on: c.formats.includes(t.id), thumb: fs.existsSync(path.join(process.cwd(), 'public', 'reel', 'status', t.id + '.jpg')) ? `/reel/status/${t.id}.jpg` : null }));
      const jobs = all<Job>("SELECT * FROM svid_jobs WHERE kind='admin' AND deleted=0 AND day>=? ORDER BY day DESC, id DESC", addDays(today, -ADMIN_KEEP_DAYS));
      const days = [...new Set(jobs.map(j => j.day))].sort().reverse().map(d => {
        const js = jobs.filter(j => j.day === d);
        const pick = (th: string) => js.find(j => j.theme === th && j.state === 'done') || js.find(j => j.theme === th);
        return { day: d, dark: pick('dark') ? pubJob(pick('dark')!) : null, light: pick('light') ? pubJob(pick('light')!) : null };
      });
      const stock = all<Stock>('SELECT * FROM svid_stock WHERE deleted=0 AND (used_day IS NULL OR used_day>=?) ORDER BY used_day IS NOT NULL, id DESC', addDays(today, -ADMIN_KEEP_DAYS));
      // the details (which Chromium, worker heartbeat, install log, retries) stay in the server log; on screen only what he must do
      const rs = rendererStatus(nowMs);
      return json({ today, yday, cfg: { on: c.on, agent_dl: c.agent_dl, tall: c.tall, formats: c.formats }, formats: fmts, renderer: { ready: rs.ok, installing: rs.installing }, problem: problemFor(nowMs),
        stock: { left: stockLeft().length, items: stock.map(pubStock) }, days, active: activeJobs(),
        agent_formats: agentFormats().map(t => ({ id: t.id, name: t.name })) });
    }
    case 'settings': {
      needPost();
      if ('on' in b) putS('svid_on', b.on ? '1' : '0');
      if ('agent_dl' in b) putS('svid_agent_dl', b.agent_dl ? '1' : '0');
      if ('tall' in b) putS('svid_tall', b.tall ? '1' : '0');
      if ('formats' in b) {
        const inst = adminFormats().map(t => t.id);
        const f = (Array.isArray(b.formats) ? b.formats : []).map(String).filter((x: string) => inst.includes(x));
        if (!f.length) throw new HttpError(400, 'Keep at least one format on');
        putS('svid_formats', inst.filter(x => f.includes(x)).join(','));
      }
      return json({ ok: true });
    }
    case 'make': { // POST {day?} → yesterday (or the chosen day) now, in the background
      needPost();
      const day = b.day ? String(b.day) : yday;
      if (!isDay(day)) throw new HttpError(400, 'Pick a date');
      if (day >= today) throw new HttpError(400, 'Pick yesterday or an earlier day (a day must be over)');
      if (day < addDays(today, -60)) throw new HttpError(400, 'Pick a day in the last 60 days');
      // Retry while it is waiting for its next automatic try → try now (new stock video if one was uploaded)
      const waiting = all<Job>("SELECT * FROM svid_jobs WHERE kind='admin' AND day=? AND deleted=0 AND state='retry'", day);
      if (waiting.length) { run("UPDATE svid_jobs SET next_at=?, prio=3 WHERE kind='admin' AND day=? AND deleted=0 AND state='retry'", nowMs, day); return json({ ok: true, jobs: waiting.map(j => j.id), retry: true }); }
      const r = queueAdminDay(day, 'now', nowMs);
      if (!r.ok) throw new HttpError(r.why === 'busy' ? 409 : 400, r.why === 'busy' ? 'This day is already being made' : r.why === 'no_stock' ? 'No video in stock. Upload a video first.' : 'Switch on at least one format');
      console.log('[svid] make now', day, r.fmt, r.fmt_light || 'same as dark');
      return json({ ok: true, jobs: r.jobs, fmt: r.fmt, fmt_light: r.fmt_light });
    }
    case 'install': needPost(); return json(startInstall());
    case 'link': { // POST {id} → a 10-minute download link (the Android app opens it in the phone's browser)
      needPost();
      const j = one<Job>("SELECT * FROM svid_jobs WHERE id=? AND kind='admin' AND state='done' AND deleted=0", num(b.id));
      if (!j) throw new HttpError(404, 'Video not found');
      return json({ url: fileLink(j, nowMs) });
    }
    case 'stock_delete': {
      needPost();
      const s = one<Stock>('SELECT * FROM svid_stock WHERE id=? AND deleted=0', num(b.id));
      if (!s) throw new HttpError(404, 'Video not found');
      if (one("SELECT 1 FROM svid_jobs WHERE stock_id=? AND state IN ('queued','running','waiting')", s.id)) throw new HttpError(409, 'This video is being rendered now');
      run('UPDATE svid_stock SET deleted=1, file_gone=1 WHERE id=?', s.id);
      try { fs.unlinkSync(path.join(stockDir(), s.file)); } catch { /* gone */ }
      return json({ ok: true });
    }
    case 'upload_init': {
      needPost();
      for (const [k, u] of uploads()) if (Date.now() - u.at > 3600000) { uploads().delete(k); try { fs.unlinkSync(tmpPath(k)); } catch { /* gone */ } }
      const size = Math.round(num(b.size));
      if (!(size > 0)) throw new HttpError(400, 'Choose a video');
      if (size > MAX_BYTES) throw new HttpError(400, 'The video is larger than 200 MB');
      const dur = num(b.duration);
      if (dur > MAX_SEC) throw new HttpError(400, `The video is ${Math.round(dur)} s. The limit is 45 s.`);
      const ext = /\.mov$/i.test(String(b.name || '')) || b.mime === 'video/quicktime' ? 'mov' : /webm/i.test(String(b.mime)) ? 'webm' : 'mp4';
      const id = crypto.randomBytes(9).toString('hex');
      fs.writeFileSync(tmpPath(id), Buffer.alloc(0));
      uploads().set(id, { id, name: clean(b.name, 80) || 'video', size, got: 0, at: Date.now(), busy: false, ext });
      return json({ upload_id: id, chunk: CHUNK });
    }
    case 'upload_done': {
      needPost();
      const u = uploads().get(String(b.upload_id || ''));
      if (!u) throw new HttpError(404, 'Upload expired. Start again.');
      if (u.got !== u.size) throw new HttpError(400, 'The upload is incomplete. Try again.');
      const tmp = tmpPath(u.id);
      uploads().delete(u.id);
      const head = Buffer.alloc(12); const fd = fs.openSync(tmp, 'r'); fs.readSync(fd, head, 0, 12, 0); fs.closeSync(fd);
      const ok = head.subarray(4, 8).toString('latin1') === 'ftyp' || head.readUInt32BE(0) === 0x1A45DFA3;
      const bad = (m: string) => { try { fs.unlinkSync(tmp); } catch { /* gone */ } throw new HttpError(400, m); };
      if (!ok) bad('This file is not an MP4 / MOV / WebM video');
      const pr = ffmpegPath() ? await probeVideo(tmp) : null;
      if (ffmpegPath() && !pr) bad('ffmpeg could not read this video. Export it as MP4 H.264 and upload it again.');
      if (pr && pr.duration > MAX_SEC) bad(`The video is ${Math.round(pr.duration)} s. The limit is 45 s.`);
      if (pr && pr.duration < 8) bad('The video is shorter than 8 s');
      const note = !pr ? 'Could not check this video.' : !pr.audio ? 'This video has no sound. The status video will be silent.' : pr.w && pr.h && Math.abs(pr.w / pr.h - 16 / 9) > 0.08 ? 'Not 16:9: it is shown whole with bars.' : null;
      const ins = run("INSERT INTO svid_stock(file, name, size, duration, width, height, audio, state, note, created_at) VALUES('',?,?,?,?,?,?,'ready',?,?)",
        u.name, u.size, pr?.duration || num(b.duration), pr?.w || null, pr?.h || null, pr ? (pr.audio ? 1 : 0) : 1, note, Date.now());
      const id = Number(ins.lastInsertRowid);
      const file = `s${id}-${crypto.randomBytes(5).toString('hex')}.${u.ext}`;
      fs.renameSync(tmp, path.join(stockDir(), file));
      run('UPDATE svid_stock SET file=? WHERE id=?', file, id);
      return json({ ok: true, stock: pubStock(one<Stock>('SELECT * FROM svid_stock WHERE id=?', id)!), left: stockLeft().length });
    }
    case 'upload_cancel': {
      needPost();
      const id = String(b.upload_id || '');
      uploads().delete(id);
      try { fs.unlinkSync(tmpPath(id)); } catch { /* gone */ }
      return json({ ok: true });
    }
  }
  return json({ error: 'Not found' }, 404);
}

/* ---------------- agent API (download my reel) ---------------- */

export type DlWho = { id: number; name: string; role: 'agent' | 'manager' };
/** Agent API: `p` = the path after "reeldl/". GET state / file/<id>; POST make. The setting OFF → 403 for everything except
 *  state (which then says off, so the card is hidden). Only the agent's own files. Never any business number. */
export async function reelDlApi(p: string, w: DlWho, req: Request, nowMs = Date.now()): Promise<Response> {
  ensureSvidTables();
  const post = req.method === 'POST';
  if (post && req.headers.get('sec-fetch-site') === 'cross-site') return json({ error: 'Cross-site request refused' }, 403);
  const on = svidCfg().agent_dl;
  const today = reelDay(nowMs);
  const mine = () => all<Job>("SELECT * FROM svid_jobs WHERE kind='agent' AND agent_id=? AND deleted=0 AND day>=? ORDER BY id DESC", w.id, addDays(today, -AGENT_KEEP_DAYS + 1));
  const pubA = (j: Job) => ({ id: j.id, day: j.day, state: j.state === 'retry' ? 'queued' : j.state, progress: j.progress || 0, size: j.size, duration: j.duration, error: j.state === 'failed' ? 'Could not make the video. Try again.' : null, theme: j.theme });
  if (p === 'state') {
    if (post) return json({ error: 'Use GET' }, 405);
    if (!on) return json({ on: false });
    const first = one<{ completed: number; reel_id: number }>("SELECT completed, reel_id FROM reel_views WHERE who_role='agent' AND who_id=? AND day=? AND showing_no=1", w.id, today);
    const js = mine();
    const seen = new Set<string>();
    const latest = js.filter(j => (seen.has(j.day) ? false : (seen.add(j.day), true)));
    return json({ on: true, today, watched: !!first?.completed, can_make: !!agentFormats().length && !js.some(j => j.day === today && ['queued', 'running', 'retry'].includes(j.state)),
      // v173 QA: while a re-make waits, the finished one stays downloadable
      today_job: (() => { const t = js.filter(j => j.day === today); const pick = t.find(j => j.state === 'done' && t[0].trig === 'redo' && t[0].state !== 'done') || t[0]; return pick ? pubA(pick) : null; })(), recent: latest.filter(j => j.day !== today && j.state === 'done').map(pubA) });
  }
  if (!on) return json({ error: 'Downloading the reel is switched off' }, 403);
  if (p === 'make') {
    if (!post) return json({ error: 'Use POST' }, 405);
    const cur = one<Job>("SELECT * FROM svid_jobs WHERE kind='agent' AND agent_id=? AND day=? AND deleted=0 AND state IN ('queued','running','retry','done') ORDER BY id DESC LIMIT 1", w.id, today);
    const seenReel = one<{ reel_id: number }>("SELECT reel_id FROM reel_views WHERE who_role='agent' AND who_id=? AND day=? AND showing_no=1", w.id, today)?.reel_id;
    if (cur && !(cur.state === 'done' && seenReel && cur.reel_id !== seenReel)) return json({ ok: true, job: pubA(cur) }); // v173 QA: watched another video → make that one
    const id = queueAgentReel(w, today, nowMs, 'agent', 1);
    return json({ ok: true, job: pubA(one<Job>('SELECT * FROM svid_jobs WHERE id=?', id)!) });
  }
  if (p === 'link') { // POST {id} → a 10-minute link to their own file (the app opens it in the phone's browser)
    if (!post) return json({ error: 'Use POST' }, 405);
    const b = await req.json().catch(() => ({})) as Record<string, unknown>;
    const j = one<Job>("SELECT * FROM svid_jobs WHERE id=? AND kind='agent' AND deleted=0", num(b.id));
    if (!j || j.agent_id !== w.id) return json({ error: 'Not your video' }, 403);
    if (j.state !== 'done' || !j.file) return json({ error: 'Not ready yet' }, 409);
    return json({ url: fileLink(j, nowMs) });
  }
  if (p.startsWith('file/')) {
    if (post) return json({ error: 'Use GET' }, 405);
    const j = one<Job>("SELECT * FROM svid_jobs WHERE id=? AND kind='agent' AND deleted=0", num(p.slice(5)));
    if (!j || j.agent_id !== w.id) return json({ error: 'Not your video' }, 403);
    if (j.state !== 'done' || !j.file) return json({ error: 'Not ready yet' }, 409);
    return serveFile(path.join(outDir(), j.file), req, `my-reel-${j.day}.mp4`);
  }
  return json({ error: 'Not found' }, 404);
}

/** v169: queues one agent's day-start reel for `today` (their showing-1 video + style; their own data, never profit). Throws
 *  HttpError when it can't be made. trig 'agent' = they tapped Make (prio 1), 'auto' = made ahead at night (prio 8). */
export function queueAgentReel(w: DlWho, today: string, nowMs: number, trig: 'agent' | 'auto' | 'redo', prio: number): number {
    const v = firstShowingPick({ role: w.role, id: w.id, name: w.name }, today)
      || (() => { const x = one<{ reel_id: number; style: string }>("SELECT reel_id, style FROM reel_views WHERE who_role='agent' AND who_id=? AND day=? AND showing_no=1", w.id, today); return x ? { reel_id: x.reel_id, style: x.style } : null; })();
    if (!v) throw new HttpError(409, 'There is no reel for you today');
    const r = one<{ id: number; file: string; purged: number; deleted: number; duration: number; line: string | null; theme_auto: string | null; theme_override: string | null; state: string }>('SELECT * FROM reels WHERE id=?', v.reel_id);
    if (!r || r.deleted || r.purged || !r.file || r.state !== 'ready') throw new HttpError(409, 'Today’s reel video is not on the server any more');
    const fmt = agentFormatFor(String(v.style || 'A'), `${w.id}|${today}`);
    if (!fmt) throw new HttpError(503, 'No reel format is installed');
    const theme = r.theme_override === 'light' || r.theme_override === 'dark' ? r.theme_override : r.theme_auto === 'light' ? 'light' : 'dark';
    const tpl = agentFormats().find(t => t.id === fmt)!;
    const y = agentDayEarned(w.id, addDays(today, -1));
    const streak = (() => { const days = new Set(all<{ day: string }>("SELECT day FROM reel_views WHERE who_role='agent' AND who_id=? AND showing_no=1 AND completed=1 AND day<=? AND day>=?", w.id, today, addDays(today, -400)).map(x => x.day)); let n = 0, d = today; while (days.has(d)) { n++; d = addDays(d, -1); } return n; })();
    const data = { name: String(w.name || '').trim().split(/\s+/)[0] || '', greeting: trig === 'agent' ? greetingAt(nowMs) : 'Good morning', day: today, today, streak, showing: 1, line_of_day: String(r.line || '').trim(),
      quotes: quotesFor(`reel:a:${w.id}`, quotesNeeded(r.duration || 20, 1)), yesterday: y.earned > 0 ? { earned: y.earned, sales: y.sales } : {} };
    return Number(run("INSERT INTO svid_jobs(kind, day, theme, fmt, agent_id, reel_id, state, trig, data, prio, created_at) VALUES('agent',?,?,?,?,?,'queued',?,?,?,?)",
      today, tpl.themes.includes(theme) ? theme : 'dark', fmt, w.id, r.id, trig, JSON.stringify(data), prio, nowMs).lastInsertRowid);
}

/** v169 (owner): with "Agents can download their reel" ON, every agent's reel is made AHEAD (from 01:00 IST, after the admin's
 *  night job, one at a time at low priority), so the Dashboard card already shows Download. Re-checked every 10 min, so a reel
 *  uploaded later in the day is made then. Returns how many were queued. */
export function autoAgentReels(now = Date.now()) {
  ensureSvidTables();
  if (!svidCfg().agent_dl || !agentFormats().length || istHour(now) < NIGHT_FROM_H) return 0;
  const today = reelDay(now);
  let n = 0;
  for (const a of all<{ id: number; name: string; role: string | null }>('SELECT id, name, role FROM agents WHERE deleted=0 ORDER BY id')) {
    if (one("SELECT 1 FROM svid_jobs WHERE kind='agent' AND agent_id=? AND day=? AND deleted=0", a.id, today)) continue;
    const w: DlWho = { id: a.id, name: a.name, role: a.role === 'manager' ? 'manager' : 'agent' };
    if (!firstShowingPick({ role: w.role, id: w.id, name: w.name }, today)) continue;
    try { queueAgentReel(w, today, now, 'auto', 8); n++; } catch (e) { console.warn('[svid] auto reel', a.id, (e as Error).message); }
  }
  if (n) console.log(`[svid] auto: queued ${n} agent reel(s) for ${today}`);
  return n;
}

/** v169 (owner): once after this update, everything already made is made AGAIN in the new quality (sharp 1080p, full screen) when
 *  its source video is still on the server: admin days (stock kept) and today's agent reels. The new render replaces the old one
 *  only when it is done. Returns counts. */
export function redoAfterUpdate(now = Date.now()) {
  ensureSvidTables();
  if (getS('svid_redo') === '169') return null;
  putS('svid_redo', '169');
  let admin = 0, agent = 0, gone = 0;
  const today = reelDay(now);
  const cfg = svidCfg();
  const days = !cfg.on ? [] : all<{ day: string }>("SELECT DISTINCT day FROM svid_jobs WHERE kind='admin' AND deleted=0 AND state='done' AND day>=? ORDER BY day DESC", addDays(today, -ADMIN_KEEP_DAYS)).map(x => x.day);
  for (const day of days) {
    const rows = all<Job>("SELECT * FROM svid_jobs WHERE kind='admin' AND day=? AND deleted=0 AND state='done' AND fallback_of IS NULL ORDER BY id DESC", day);
    const st = rows[0]?.stock_id ? one<Stock>('SELECT * FROM svid_stock WHERE id=?', rows[0].stock_id) : undefined;
    if (!st || st.file_gone || !st.file || !fs.existsSync(path.join(stockDir(), st.file))) { gone++; continue; }
    const seen = new Set<string>();
    for (const j of rows) {
      if (seen.has(j.theme)) continue; seen.add(j.theme);
      run("INSERT INTO svid_jobs(kind, day, theme, fmt, stock_id, state, trig, data, prio, created_at) VALUES('admin',?,?,?,?,'queued','redo',?,7,?)", day, j.theme, j.fmt, j.stock_id, j.data, now);
      admin++;
    }
  }
  for (const j of !cfg.agent_dl ? [] : all<Job>("SELECT * FROM svid_jobs WHERE kind='agent' AND day=? AND deleted=0 AND state='done'", today)) {
    const r = one<{ purged: number; deleted: number; file: string }>('SELECT purged, deleted, file FROM reels WHERE id=?', j.reel_id);
    if (!r || r.purged || r.deleted || !r.file) { gone++; continue; }
    run("INSERT INTO svid_jobs(kind, day, theme, fmt, agent_id, reel_id, state, trig, data, prio, created_at) VALUES('agent',?,?,?,?,?,'queued','redo',?,5,?)", j.day, j.theme, j.fmt, j.agent_id, j.reel_id, j.data, now); // before the admin days (7)
    agent++;
  }
  console.log(`[svid] v169 re-make in the new quality: ${admin} admin, ${agent} agent video(s) queued; ${gone} could not (source video already deleted)`);
  return { admin, agent, gone };
}

/** Self-heal: no Chromium found (the reuse lookup is chromiumInfo, run on every check) while status videos are on or a video is
 *  waiting → install one in the background, at most once an hour. Returns what it did (logged). */
export function autoHeal(now = Date.now(), install: () => unknown = startInstall) {
  if (chromiumInfo()) return 'ok';
  if (!svidCfg().on && !pendingJobs() && !svidCfg().agent_dl) return 'idle';
  const rs = rendererStatus(now);
  if (rs.installing) return 'installing';
  if (now - num(getS('svid_install')) < 3600000) return 'wait';
  try { install(); return 'started'; } catch (e) { console.warn('[svid] auto install', (e as Error).message); return 'error'; }
}

/** Worker tick (every 15 s): heartbeat, the night job (its load check every 10 min), clean-up (hourly), the next render. */
type GT = typeof globalThis & { __svidT?: { night: number; clean: number; boot: boolean } };
export async function svidTick(now = Date.now()) {
  ensureSvidTables();
  const g = globalThis as GT;
  const t = (g.__svidT ||= { night: 0, clean: 0, boot: false });
  const out: Record<string, unknown> = {};
  if (!t.boot) { t.boot = true; resumeStale(); try { out.redo = redoAfterUpdate(now); } catch (e) { console.warn('[svid] redo', (e as Error).message); } }
  heartbeat();
  out.heal = autoHeal(now);
  if (now - t.night >= 10 * 60000) { t.night = now; out.night = nightTick(now); try { out.auto = autoAgentReels(now); } catch (e) { console.warn('[svid] auto', (e as Error).message); } }
  if (now - t.clean >= 3600000) { t.clean = now; out.clean = svidCleanup(now); }
  out.ran = (globalThis as GR).__svidBusy ? 'busy' : 'next';
  void runNext().catch(e => console.warn('[svid] run', (e as Error).message)); // a render takes minutes; the tick goes on
  return out;
}
