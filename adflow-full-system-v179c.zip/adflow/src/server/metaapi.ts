/** Ad accounts panel API (admin and manager share it): /api/admin/meta/* and /api/agent/meta/* */
import { all, one } from './db';
import { getSettings } from './settings';
import { num, HttpError } from './util';
import { leadById } from './crm';
import * as M from './meta';
import * as Q from './metaq';

const META_GET = new Set(['free_pick', 'overview', 'bms', 'bm', 'accounts', 'account', 'free', 'requests', 'credits', 'cards', 'report', 'leads', 'profiles', 'profile', 'q_settings', 'jobs', 'job', 'card_list', 'shot_waiting', 'shot_img', 'ip_check']);

export async function metaApi(path: string, req: Request, b: Record<string, any>, actor: M.Actor) {
  const url = new URL(req.url);
  const q = (k: string) => url.searchParams.get(k);
  if (actor.role === 'agent') throw new HttpError(403, 'Only the manager can do this');
  // v166: only these read; everything else is POST only (no action from a plain GET link)
  if (req.method !== 'POST' && !META_GET.has(path)) throw new HttpError(405, 'Use POST');
  const admin = () => { if (actor.role !== 'admin') throw new HttpError(403, 'Only the admin can change this'); };
  switch (path) {
    case 'overview': return { ...M.overview(), settings: pick(), can_toggle: actor.role === 'admin', off: !M.metaEnabled() };
    case 'bms': return { bms: all<M.Bm>('SELECT * FROM meta_bms WHERE deleted=0 ORDER BY id').map(M.pubBm) };
    case 'bm': {
      const bm = M.bmById(q('id'));
      if (!bm) throw new HttpError(404, 'BM not found');
      return { bm: M.pubBm(bm), accounts: M.listAccounts({ bm: bm.bm_id }) };
    }
    case 'bm_add': admin(); return M.addBm(b); // v166: BM add / token change / delete / ban are admin-only (like the profiles)
    case 'bm_update': {
      if (b.token) { admin(); const bm = M.bmById(b.id); if (!bm) throw new HttpError(404, 'BM not found'); return M.addBm({ ...b, bm_id: bm.bm_id }); }
      return M.updateBm(b.id, b);
    }
    case 'bm_delete': admin(); return M.deleteBm(b.id);
    case 'bm_sync': { // v173: also by the Meta BM id (the Accounts list syncs one BM from its group header)
      const id = num(b.id) || one<{ id: number }>('SELECT id FROM meta_bms WHERE bm_id=? AND deleted=0', String(b.bm_id || '').replace(/\D/g, ''))?.id || 0;
      if (!id) throw new HttpError(404, 'BM not found');
      return M.syncBm(id, actor);
    }
    case 'bm_ban': admin(); return M.banBm(b.id, actor);
    case 'sync_all': { // v161: + BMs of the profiles (they are read only through the queue, after the IP change)
      const n = await M.metaTick(true);
      const ps = all<{ id: number }>("SELECT id FROM meta_profiles WHERE deleted=0 AND status IN ('ok','error','ip_error')");
      let eta = 0;
      for (const p of ps) eta = Math.max(eta, Q.syncProfile(p.id, actor).job.eta_min || 0);
      return { ok: true, synced: n, profiles: ps.length, eta_min: eta };
    }
    case 'accounts': return { accounts: M.listAccounts({ state: q('state'), q: q('q'), bm: q('bm'), lead: num(q('lead')) || null }), removed: M.removedCount() };
    case 'acct_remove': admin(); return M.removeAcct(b.act_id, actor); // v170
    case 'acct_restore': admin(); return M.restoreAcct(b.act_id, actor);
    case 'account': return M.accountDetail(q('act'));
    case 'free_pick': return { accounts: M.freePickList() }; // v171: every free account to pick from
    case 'free': return { accounts: M.freeAccounts(q('tier') || 'any').map(a => M.pubAcct(a)) };
    case 'replace_give': { // v173 (owner): Ad accounts → a free account → Give as replacement (this account = the new one)
      const lead = leadById(num(b.lead_id));
      if (!lead) throw new HttpError(400, 'Choose the client (chat)');
      if (!M.cleanAct(b.new_act)) throw new HttpError(400, 'Choose the account');
      return M.createRequest(actor, { kind: 'replace', old_act: b.old_act, client_bm: b.client_bm, new_act: b.new_act, hand: !!b.hand, note: b.note, tier: 'any' }, lead);
    }
    case 'share': {
      const lead = leadById(num(b.lead_id));
      if (!lead) throw new HttpError(400, 'Choose the client (chat)');
      return M.createRequest(actor, { ...b, kind: 'account', method: b.method || 'manual' }, lead);
    }
    case 'topup': {
      const a = M.acctOf(b.act_id);
      if (!a || !a.lead_id) throw new HttpError(400, 'This account is not with a client');
      return M.createRequest(actor, { ...b, kind: 'topup', method: b.method || 'manual' }, leadById(a.lead_id)!);
    }
    case 'unshare': return M.unshareAcct(String(b.act_id), actor);
    case 'topup_cut': return M.cutTopup(String(b.act_id), { last: b.last, amount: b.amount }, actor); // v161
    case 'add_bm': return M.addBmAcct(String(b.act_id), b.client_bm, actor);
    case 'finish': return M.finishShare(String(b.act_id), actor);
    case 'rename': return M.renameAcct(String(b.act_id), b.name ? String(b.name) : null);
    case 'rename_all': {
      const rows = M.listAccounts({ bm: b.bm_id ? String(b.bm_id) : null }).filter(a => a.state === 'free'); // v153: only free accounts (a client's account keeps its name)
      let ok = 0; const errors: string[] = [];
      for (const a of rows) { try { await M.renameAcct(a.act_id, null); ok++; } catch (e) { errors.push(`act_${a.act_id}: ${(e as Error).message}`); } }
      return { ok: true, renamed: ok, errors };
    }
    case 'manual': return M.manualAction(String(b.act_id), b, actor);
    case 'requests': return { requests: M.listRequests(q('status') === 'all' ? 'all' : 'open') };
    case 'request_run': { // v173 QA: the account is always chosen by hand in Requests (no "first free" pick)
      const r0 = all<{ kind: string; act_id: string | null; method: string | null }>('SELECT kind, act_id, method FROM meta_requests WHERE id=?', num(b.id))[0];
      if (r0 && r0.kind !== 'topup' && !M.cleanAct(b.act_id) && !r0.act_id) throw new HttpError(400, 'Choose the account to give');
      return M.runRequest(b.id, actor, b);
    }
    case 'request_reject': return M.rejectRequest(b.id, actor, b.note);
    case 'request_hand': return M.requestDoneByHand(b.id, actor, b);
    case 'credits': return { credits: M.listCredits() };
    case 'credit_cancel': return M.cancelCredit(b.lead_id, actor, b.id, b.note); // v165: admin only, all or one entry
    case 'cards': return { cards: M.listCards() };
    case 'card_balance': return M.setCardBalance(b.card, b.balance);
    case 'report': return M.report(q('range'));
    case 'leads': return { leads: M.searchLeads(q('q') || '', q('ch') || '') };
    // v152: profiles + iProxy queue
    case 'profiles': return { profiles: Q.listProfiles(), q: Q.qSettings(), jobs: Q.listJobs() };
    case 'profile': return Q.profileDetail(q('id'));
    case 'profile_add': admin(); return Q.addProfile(b, actor);
    case 'profile_update': admin(); return Q.updateProfile(b.id, b, actor);
    case 'profile_delete': admin(); return Q.deleteProfile(b.id);
    case 'profile_sync': return Q.syncProfile(b.id, actor);
    case 'q_settings': return Q.qSettings();
    case 'ip_check': admin(); return Q.ipCheck();
    case 'q_save': admin(); return Q.saveQSettings(b);
    case 'jobs': return Q.listJobs();
    case 'job': return { job: Q.jobById(q('id')) };
    case 'job_cancel': return Q.cancelJob(b.id);
    case 'acct_limits': return M.setAcctLimits(b.act_id, b);
    case 'acct_card': return M.setAcctCard(b.act_id, b.card); // v165
    case 'card_list': return { cards: all<{ card: string }>('SELECT card FROM meta_cards ORDER BY card').map(c => c.card) };
    case 'manual_share': return Q.manualShare(actor, b);
    case 'proof_again': return Q.proofAgain(b.act_id, actor);
    case 'topup_img': { // v158: the last top-up's image again (client chat + Saved Messages)
      const act = String(b.act_id || '').replace(/\D/g, '');
      const l = one<{ amount: number; fee: number | null }>("SELECT amount, fee FROM meta_log WHERE act_id=? AND kind='topup' AND amount>0 ORDER BY id DESC LIMIT 1", act);
      if (!l) throw new HttpError(400, 'No top-up on this account yet');
      const P = await import('./proof'); const log: string[] = [];
      await P.deliverTopupProof(act, l.amount, l.fee || 0, t => log.push(t));
      return { ok: true, log };
    }
    // v159: channel post waiting for the client-chat screenshot
    case 'shot_waiting': return { posts: (await import('./shotpost')).waitingPosts() };
    case 'shot_upload': return (await import('./shotpost')).uploadShot(b.act_id, b.image);
    case 'shot_post': return (await import('./shotpost')).releasePost(b.act_id, true, actor);
    case 'shot_skip': return (await import('./shotpost')).releasePost(b.act_id, false, actor);
    case 'shot_img': {
      const f = (await import('./shotpost')).shotPreview(q('act'));
      if (!f) return { preview: null };
      const sharp = (await import('sharp')).default; const fs = await import('fs');
      return { preview: 'data:image/jpeg;base64,' + (await sharp(fs.readFileSync(f)).resize({ height: 1400, withoutEnlargement: true }).jpeg({ quality: 82 }).toBuffer()).toString('base64') };
    }
    case 'digest_now': { // v163: one at a time, asks before posting a 2nd time the same day, posts in the background (no long request to repeat)
      admin(); const D = await import('./digest');
      if (D.digestBusy()) throw new HttpError(409, 'Already posting. Wait a minute and check the channel.');
      const at = D.postedAt();
      if (at && !b.force) return { ok: false, already: true, at };
      const n = D.digestRows(D._digestTest.dayOf(Date.now())).length;
      if (!n) return { ok: true, posted: 0 };
      // v166: the day is marked posted by the post itself, after it went out (a failed post leaves the night post on)
      const p = D.postTopupDigest({ force: true });
      void p.then(r => { if (!r.ok) return M.alertTeam('⚠️ Top-up post not done', String((r as { error?: string }).error || '').slice(0, 200)); }).catch(e => M.alertTeam('⚠️ Top-up post failed', String((e as Error).message).slice(0, 200)).catch(() => 0));
      return { ok: true, started: true, n };
    }
  }
  throw new HttpError(404, 'Not found');
}

function pick() {
  const s = getSettings();
  return { topup_pct: num(s.topup_comm_pct, 3), low_usd: num(s.meta_low_usd, 15), lock_usd: num(s.meta_lock_usd, 0.1), sync_min: num(s.meta_sync_min, 360), partner_hand: s.mq_partner_hand !== '0', pattern: s.meta_name_pattern, brand: s.brand_name, msgs: s.meta_client_msgs, email_invites: s.meta_email_invites === '1', msg_share: s.meta_msg_share, msg_invite: s.meta_msg_invite, msg_invite_ok: s.meta_msg_invite_ok, msg_topup: s.meta_msg_topup, msg_low: s.meta_msg_low, auto_footer: s.meta_auto_footer, msg_replace: s.meta_msg_replace, msg_topup_hand: s.meta_msg_topup_hand, msg_topup_req: s.meta_msg_topup_req };
}
