/** v137: delete a message WE sent. Telegram → deleted for everyone (bot / Business connection: deleteMessage /
 *  deleteBusinessMessages; chat account: MTProto deleteMessages revoke). WhatsApp has no API for that → "delete for us" only
 *  (hidden in our apps, kept in the database). Agents: only their own messages, within 48 h. Admin / manager: any of ours
 *  (Telegram within 48 h too). Every delete is logged (msg_deletes) and the AI / coach never sees deleted messages. */
import { one, run } from './db';
import { getSettings } from './settings';
import { tg } from './telegram';
import { now, HOUR, HttpError } from './util';

export const DELETE_WINDOW = 48 * HOUR;
export const WA_NOTE = 'WhatsApp doesn\'t allow deleting for the customer through the API. Delete it from the WhatsApp Business app on the phone within 2 days.';
type Who = { role: 'agent' | 'manager' | 'admin'; id: number | null; name: string };
type Row = { id: number; lead_id: number; dir: string; sender: string; agent_id: number | null; text: string; tg_msg_id: number | null; via: string | null; created_at: number; deleted_at: number | null };

export async function deleteMessage(msgId: number, who: Who, leadOk: (leadId: number) => boolean) {
  const m = one<Row>('SELECT id, lead_id, dir, sender, agent_id, text, tg_msg_id, via, created_at, deleted_at FROM messages WHERE id=?', msgId);
  if (!m || !leadOk(m.lead_id)) throw new HttpError(404, 'Message not found');
  if (m.dir !== 'out') throw new HttpError(400, 'Only our own messages can be deleted');
  if (m.deleted_at) return { ok: true, mode: 'already' };
  const lead = one<{ id: number; tg_chat_id: string | null; biz_conn: string | null; ch: string | null; tg_access_hash: string | null }>('SELECT id, tg_chat_id, biz_conn, ch, tg_access_hash FROM leads WHERE id=?', m.lead_id)!;
  const old = now() - m.created_at > DELETE_WINDOW;
  if (who.role === 'agent' && !(m.sender === 'agent' && m.agent_id === who.id)) throw new HttpError(403, 'You can delete only your own messages');
  if (who.role === 'agent' && old) throw new HttpError(400, 'Messages older than 48 hours can’t be deleted');
  const wa = lead.ch === 'wa' || String(lead.tg_chat_id || '').startsWith('wa:');
  let mode: 'everyone' | 'us';
  if (wa) mode = 'us';
  else {
    if (old) throw new HttpError(400, 'Messages older than 48 hours can’t be deleted');
    const s = getSettings();
    if (m.via === 'ub') {
      if (!m.tg_msg_id) throw new HttpError(400, 'This message was sent by the chat account before v137 — delete it in the Telegram app');
      const { queueUserbotDelete } = await import('./userbot');
      const r = await queueUserbotDelete(lead.id, m.tg_msg_id);
      if (!r.ok) throw new HttpError(502, 'Telegram: ' + r.error);
    } else {
      if (!m.tg_msg_id || !lead.tg_chat_id) throw new HttpError(400, 'Telegram has no id for this message (it was never delivered) — nothing to delete there');
      const r = lead.biz_conn
        ? await tg(s, 'deleteBusinessMessages', { business_connection_id: lead.biz_conn, message_ids: [m.tg_msg_id] })
        : await tg(s, 'deleteMessage', { chat_id: lead.tg_chat_id, message_id: m.tg_msg_id });
      if (!r.ok) throw new HttpError(400, `Telegram: ${r.description || 'not deleted'}${lead.biz_conn ? '. Give the bot the "Delete messages" permission in Telegram → Settings → Business → Chatbots.' : ''}`);
    }
    mode = 'everyone';
  }
  const t = now();
  run('UPDATE messages SET deleted_at=?, deleted_by=? WHERE id=?', t, who.name, m.id);
  run('INSERT INTO msg_deletes(msg_id, lead_id, by_role, by_id, by_name, mode, text, at) VALUES(?,?,?,?,?,?,?,?)', m.id, m.lead_id, who.role, who.id, who.name, mode, String(m.text || '').slice(0, 1000), t);
  return { ok: true, mode, note: mode === 'us' ? WA_NOTE : null };
}
