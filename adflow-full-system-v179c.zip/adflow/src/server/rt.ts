import { cookies } from 'next/headers';

type SP = Promise<Record<string, string | string[] | undefined>> | undefined;
/** Landing pages: did this visitor come from a retargeting ad? (?rt=1 now, or the af_rt cookie set by an earlier ?rt=1 visit this week) */
export async function isRtVisit(searchParams: SP): Promise<boolean> {
  const sp = searchParams ? await searchParams : {};
  if (sp.rt === '1' || (Array.isArray(sp.rt) && sp.rt.includes('1'))) return true;
  try { return (await cookies()).get('af_rt')?.value === '1'; } catch { return false; }
}
