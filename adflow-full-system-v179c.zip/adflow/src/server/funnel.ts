// v168: Landing page funnel (admin Home) — one funnel per entry point (landing page / ad type), from our OWN tracking (not Meta).
// Read-only: it only counts. The only writes are the new step beacons (page_steps), which never send a Meta event.
import { one, all, run } from './db';
import { now } from './util';
import { tgPageStats } from './chanads';

type Line = 'agency' | 'premium' | 'funnel';
const LINES: Line[] = ['agency', 'premium', 'funnel'];
const LINE_NAME: Record<Line, string> = { agency: 'Agency', premium: 'Premium', funnel: 'Funnel' };
const LINE_PATH: Record<Line, string> = { agency: '', premium: '/premium', funnel: '/funnel' };

/* ---------------- tracking (v168): steps the pages did not store before ---------------- */
let ready = false;
/** page_steps: one row per visitor + page + step (first time only), like page_visits. funnel_meta.since = when tracking began. */
export function ensureSteps() {
  if (ready) return;
  run('CREATE TABLE IF NOT EXISTS page_steps(vid TEXT, page TEXT, step TEXT, created_at INTEGER, PRIMARY KEY(vid, page, step))');
  run('CREATE INDEX IF NOT EXISTS i_page_steps ON page_steps(page, step, created_at)');
  run('CREATE TABLE IF NOT EXISTS funnel_meta(k TEXT PRIMARY KEY, v TEXT)');
  run("INSERT OR IGNORE INTO funnel_meta(k, v) VALUES('since', ?)", String(now()));
  ready = true;
}
export const STEP_KINDS = ['view', 'cta', 'form'] as const;
export type StepKind = typeof STEP_KINDS[number];
/** The same page key as page_visits (api/vc), except the WhatsApp pages are split: wa_page_<line> (chat) and wa_comm_<line> (community). */
export function pageKey(path: string, line: string) {
  const wap = path.match(/^\/(agency|premium|funnel)\/(whatsapp|community)(\/|$)/);
  if (wap) return (wap[2] === 'community' ? 'wa_comm_' : 'wa_page_') + wap[1];
  const chp = path.match(/^\/(agency|premium|funnel)\/telegram(\/|$)/);
  if (chp) return 'ch_' + chp[1];
  if (/^\/telegram(\/|$)/.test(path)) return 'telegram';
  if (/^\/premium(\/|$)/.test(path)) return 'premium';
  return line === 'funnel' ? 'funnel' : 'agency';
}
export function noteStep(vid: string, page: string, step: StepKind) {
  if (!vid || !(STEP_KINDS as readonly string[]).includes(step)) return;
  try { ensureSteps(); run('INSERT OR IGNORE INTO page_steps(vid, page, step, created_at) VALUES(?,?,?,?)', String(vid).slice(0, 64), page.slice(0, 24), step, now()); } catch { /* never break the page */ }
}
export function trackingSince() {
  ensureSteps();
  const v = Number(one<{ v: string }>("SELECT v FROM funnel_meta WHERE k='since'")?.v);
  return Number.isFinite(v) ? v : now();
}

/* ---------------- the funnels ---------------- */
export type FStep = {
  k: string; label: string; sub?: string;
  n: number | null;          // null = not tracked in this period
  partial?: boolean;         // tracking began inside the period → count shown, no % from/to it
  step_pct: number | null;   // of the previous counted step
  overall_pct: number | null; // of the first counted step (the visitors)
  drop: number;              // people lost since the previous counted step (never negative)
  biggest?: boolean;         // the weakest step of this funnel
};
export type FEntry = { k: string; kind: 'form' | 'wa_page' | 'wa_comm' | 'tg_page' | 'ch_page'; line: Line | null; title: string; path: string; steps: FStep[];
  visitors: number | null; chats: number; buyers: number; buy_pct: number | null; left: { n: number; of: number; pct: number | null; after: string } | null; note?: string };

const pct = (a: number, b: number) => (b > 0 ? Math.round(a / b * 1000) / 10 : null);
const cnt = (sql: string, ...a: unknown[]) => Number(one<{ n: number }>(sql, ...a)?.n || 0);

type Raw = { k: string; label: string; sub?: string; n: number | null; tracked?: boolean };
/** Raw counts → percentages. A step tracked only from v168 (tracked: true) that began inside the period is "partial": shown, but not used for any %. */
function shape(raw: Raw[], f: number, since: number): FStep[] {
  const partialFrom = since > f;
  let prev: number | null = null, base: number | null = null;
  const out = raw.map(r => {
    const partial = !!r.tracked && partialFrom && r.n != null;
    const n = r.n == null ? null : Math.max(0, r.n);
    const counted = n != null && !partial;
    const step: FStep = { k: r.k, label: r.label, sub: r.sub, n, partial: partial || undefined, step_pct: null, overall_pct: null, drop: 0 };
    if (counted) {
      if (prev != null) { step.step_pct = pct(n!, prev); step.drop = Math.max(0, prev - n!); }
      if (base != null) step.overall_pct = pct(n!, base);
      if (base == null) { base = n; step.overall_pct = n! > 0 ? 100 : null; }
      prev = n;
    }
    return step;
  });
  // weakest step = the lowest step % (below 100), when there are at least two steps with a %
  const cands = out.filter(x => x.step_pct != null && x.step_pct < 100);
  if (out.filter(x => x.step_pct != null).length >= 1 && cands.length) {
    const w = cands.reduce((a, b) => (b.step_pct! < a.step_pct! ? b : a));
    if (w.drop > 0) w.biggest = true;
  }
  return out;
}

function entry(k: string, kind: FEntry['kind'], line: Line | null, title: string, path: string, raw: Raw[], f: number, since: number, chats: number, buyers: number, note?: string): FEntry {
  const steps = shape(raw, f, since);
  const first = steps.find(x => x.n != null && !x.partial);
  const visitors = steps[0].n != null && !steps[0].partial ? steps[0].n : null;
  // "left on the page": the visitors who did not take the very next counted step (the owner's key question)
  let left: FEntry['left'] = null;
  if (visitors != null) {
    const nx = steps.slice(1).find(x => x.n != null && !x.partial);
    if (nx) left = { n: Math.max(0, visitors - nx.n!), of: visitors, pct: visitors > 0 ? pct(Math.max(0, visitors - nx.n!), visitors) : null, after: nx.label };
  }
  return { k, kind, line, title, path, steps, visitors, chats, buyers, buy_pct: first && first.n ? pct(buyers, first.n) : null, left, note };
}

/** Every entry point with something in [f,t). line = Home's line pill (null = All lines). */
export function landingFunnels(f: number, t: number, lineQ?: string | null) {
  ensureSteps();
  const since = trackingSince();
  const ln = (LINES as string[]).includes(String(lineQ)) ? (lineQ as Line) : null;
  const lines = ln ? [ln] : LINES;
  const steps = (page: string, step: StepKind) => cnt('SELECT COUNT(*) n FROM page_steps WHERE page=? AND step=? AND created_at>=? AND created_at<?', page, step, f, t);
  const visits = (page: string) => cnt('SELECT COUNT(*) n FROM page_visits WHERE page=? AND created_at>=? AND created_at<?', page, f, t);
  // same line rule as Home's line tabs (stats → L())
  const LW = (l: Line, a = 'leads') => (l === 'funnel' ? `${a}.line='funnel'` : l === 'premium' ? `COALESCE(${a}.line,'agency')!='funnel' AND ${a}.tier='premium'` : `COALESCE(${a}.line,'agency')!='funnel' AND COALESCE(${a}.tier,'')!='premium'`);
  const out: FEntry[] = [];
  // before v168 one page_visits row covered both WhatsApp pages of a line → shown as a note while the split is partial
  const waNote = (l: Line) => (since > f ? `${visits('wa_' + l)} visits to the WhatsApp chat + community pages together` : undefined);

  for (const l of lines) {
    // 1) Lead form pages (/, /premium, /funnel): visit → tapped Order/Chat → reached name+number → sent the form → started the chat → bought
    const FW = `source='form' AND created_at>=? AND created_at<? AND ${LW(l)}`;
    const forms = cnt(`SELECT COUNT(*) n FROM leads WHERE ${FW}`, f, t);
    const chat = cnt(`SELECT COUNT(*) n FROM leads WHERE ${FW} AND started_at IS NOT NULL AND started_at<?`, f, t, t);
    const bought = cnt(`SELECT COUNT(*) n FROM leads WHERE ${FW} AND started_at IS NOT NULL AND started_at<? AND EXISTS(SELECT 1 FROM sales x WHERE x.lead_id=leads.id AND x.created_at<?)`, f, t, t, t);
    const chatBtn = cnt(`SELECT COUNT(*) n FROM leads WHERE ${FW} AND service='chat'`, f, t);
    out.push(entry('form_' + l, 'form', l, `${LINE_NAME[l]} landing page`, LINE_PATH[l] || '/', [
      { k: 'view', label: 'Visited the page', n: visits(l) },
      { k: 'cta', label: 'Tapped Order / Chat', n: steps(l, 'cta'), tracked: true },
      { k: 'form', label: 'Reached name & number', n: steps(l, 'form'), tracked: true },
      { k: 'sent', label: 'Sent the form', sub: chatBtn ? `${chatBtn} by the Chat button` : undefined, n: forms },
      { k: 'chat', label: 'Started the chat', n: chat },
      { k: 'bought', label: 'Bought', n: bought },
    ], f, since, chat, bought));

    // 2) WhatsApp ad page (/<line>/whatsapp): visit → tapped "Chat on WhatsApp" (wa_clicks) → messaged with the W- code → bought
    const cl = one<{ n: number; m: number }>('SELECT COUNT(*) n, COALESCE(SUM(lead_id IS NOT NULL),0) m FROM wa_clicks WHERE line=? AND created_at>=? AND created_at<?', l, f, t)!;
    const clB = cnt('SELECT COUNT(DISTINCT c.lead_id) n FROM wa_clicks c WHERE c.line=? AND c.created_at>=? AND c.created_at<? AND c.lead_id IS NOT NULL AND EXISTS(SELECT 1 FROM sales x WHERE x.lead_id=c.lead_id AND x.created_at<?)', l, f, t, t);
    out.push(entry('wa_page_' + l, 'wa_page', l, `${LINE_NAME[l]} WhatsApp page`, `/${l}/whatsapp`, [
      { k: 'view', label: 'Visited the page', n: steps('wa_page_' + l, 'view'), tracked: true },
      { k: 'tap', label: 'Tapped Chat on WhatsApp', n: cl.n },
      { k: 'chat', label: 'Messaged on WhatsApp', n: cl.m },
      { k: 'bought', label: 'Bought', n: clB },
    ], f, since, cl.m, clB, waNote(l)));

    // 3) WhatsApp community page (/<line>/community): visit → gave their number (wa_joins) → messaged → bought
    const jn = one<{ n: number; m: number; b: number }>('SELECT COUNT(*) n, COALESCE(SUM(msg_at IS NOT NULL),0) m, COALESCE(SUM(lead_id IS NOT NULL AND EXISTS(SELECT 1 FROM sales x WHERE x.lead_id=wa_joins.lead_id AND x.created_at<?)),0) b FROM wa_joins WHERE line=? AND created_at>=? AND created_at<?', t, l, f, t)!;
    out.push(entry('wa_comm_' + l, 'wa_comm', l, `${LINE_NAME[l]} WhatsApp community`, `/${l}/community`, [
      { k: 'view', label: 'Visited the page', n: steps('wa_comm_' + l, 'view'), tracked: true },
      { k: 'number', label: 'Gave their number', sub: 'Then the community link opens', n: jn.n },
      { k: 'chat', label: 'Messaged on WhatsApp', n: jn.m },
      { k: 'bought', label: 'Bought', n: jn.b },
    ], f, since, jn.m, jn.b, waNote(l)));

    // 4) Telegram channel-ad page (/<line>/telegram): visit → asked to join the channel → messaged us → bought
    const coh = "SELECT tg_user FROM channel_joins WHERE src='ad' AND line_x=? AND tg_user IS NOT NULL AND requested_at>=? AND requested_at<?";
    const cj = one<{ n: number; jn: number }>("SELECT COUNT(*) n, COALESCE(SUM(joined_at IS NOT NULL),0) jn FROM channel_joins WHERE src='ad' AND line_x=? AND requested_at>=? AND requested_at<?", l, f, t)!;
    const chM = cnt(`SELECT COUNT(DISTINCT l.tg_chat_id) n FROM leads l WHERE l.status!='merged' AND l.tg_chat_id IN (${coh})`, l, f, t);
    const chB = cnt(`SELECT COUNT(DISTINCT l.tg_chat_id) n FROM leads l WHERE l.tg_chat_id IN (${coh}) AND EXISTS(SELECT 1 FROM sales x WHERE x.lead_id=l.id AND x.created_at<?)`, l, f, t, t);
    const chBot = cnt(`SELECT COUNT(*) n FROM bot_subs WHERE tg_user IN (${coh})`, l, f, t);
    out.push(entry('ch_' + l, 'ch_page', l, `${LINE_NAME[l]} Telegram channel page`, `/${l}/telegram`, [
      { k: 'view', label: 'Visited the page', n: visits('ch_' + l) },
      { k: 'join', label: 'Asked to join the channel', sub: `${cj.jn} joined · ${chBot} started the bot`, n: cj.n },
      { k: 'chat', label: 'Messaged us', n: chM },
      { k: 'bought', label: 'Bought', n: chB },
    ], f, since, chM, chB));
  }
  // 5) /telegram page (Subscribe ads; no line) — the same numbers as Home → Telegram page ads
  if (!ln) {
    const tp = tgPageStats(f, t);
    const coh = "SELECT tg_user FROM channel_joins WHERE src='page' AND tg_user IS NOT NULL AND requested_at>=? AND requested_at<?";
    const tpB = cnt(`SELECT COUNT(DISTINCT l.tg_chat_id) n FROM leads l WHERE l.tg_chat_id IN (${coh}) AND EXISTS(SELECT 1 FROM sales x WHERE x.lead_id=l.id AND x.created_at<?)`, f, t, t);
    out.push(entry('tg_page', 'tg_page', null, 'Telegram page', '/telegram', [
      { k: 'view', label: 'Visited the page', n: visits('telegram') },
      { k: 'join', label: 'Asked to join the channel', sub: `${tp.joined} joined · ${tp.bot_starts} started the bot`, n: tp.joins },
      { k: 'chat', label: 'Messaged us', n: tp.messaged },
      { k: 'bought', label: 'Bought', n: tpB },
    ], f, since, tp.messaged, tpB));
  }
  const live = out.filter(e => e.steps.some(x => (x.n || 0) > 0));
  const first = (e: FEntry) => e.steps.find(x => x.n != null)?.n || 0;
  live.sort((a, b) => first(b) - first(a) || a.title.localeCompare(b.title));
  return { since, partial: since > f, entries: live, all: ln ? null : { visitors: cnt('SELECT COUNT(*) n FROM visits WHERE created_at>=? AND created_at<?', f, t) } };
}
