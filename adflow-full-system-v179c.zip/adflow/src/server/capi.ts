import { run, one, all } from './db';
import { now, sha256 } from './util';
import { pixelFor, type Settings } from './settings';

const GRAPH = () => process.env.GRAPH_API_BASE || 'https://graph.facebook.com';

export type LeadLike = { id?: number; name?: string | null; email?: string | null; phone?: string | null; ip?: string | null; ua?: string | null; fbc?: string | null; fbp?: string | null; vid?: string | null; fbclid?: string | null; page_url?: string | null; created_at?: number | null };

/** fbclid from a page URL (…?fbclid=XYZ) */
export function fbclidOf(url: string | null | undefined) {
  try { return url ? new URL(url, 'https://x.invalid').searchParams.get('fbclid') || '' : ''; } catch { return ''; }
}
/** Meta click/browser ids for a request: the cookies, else built the way Meta builds them (fbc from the ad's fbclid in the page URL). */
export function clickIds(req: Request, pageUrl?: string | null) {
  const ck = (n: string) => { const m = (req.headers.get('cookie') || '').match(new RegExp('(?:^|;\\s*)' + n + '=([^;]+)')); return m ? decodeURIComponent(m[1]) : ''; };
  let fbc = ck('_fbc');
  const id = fbclidOf(pageUrl) || fbclidOf(req.headers.get('referer'));
  if (id && !fbc.endsWith('.' + id)) fbc = `fb.1.${Date.now()}.${id}`;
  const fbp = ck('_fbp') || `fb.1.${Date.now()}.${Math.floor(1e9 + Math.random() * 9e9)}`;
  return { fbc, fbp, vid: ck('af_vid'), fbclid: id || fbc.split('.').slice(3).join('.') };
}
/** Country of the default phone code (all leads are from there) → hashed `country` for better matching. */
const CC_COUNTRY: Record<string, string> = { '91': 'in', '1': 'us', '55': 'br', '44': 'gb', '971': 'ae', '880': 'bd', '92': 'pk', '977': 'np', '62': 'id', '63': 'ph', '234': 'ng' };

export function normPhone(p: string | null | undefined, cc: string) {
  let d = String(p || '').replace(/\D/g, '').replace(/^0+/, '');
  if (d.length === 10 && cc) d = cc + d;
  return d;
}
const h = (v: string | null | undefined) => { const x = String(v || '').trim().toLowerCase(); return x ? [sha256(x)] : undefined; };

export function buildUserData(lead: LeadLike, s: Settings) {
  const parts = String(lead.name || '').trim().split(/\s+/).filter(Boolean);
  const ph = normPhone(lead.phone, s.default_cc);
  // fbc missing but we saved the ad's click id → build it (same format the pixel uses)
  const clickId = lead.fbclid || fbclidOf(lead.page_url);
  const fbc = lead.fbc || (clickId ? `fb.1.${lead.created_at || now()}.${clickId}` : undefined);
  // same visitor id on every event (ViewContent → Lead → Purchase) so Meta links them to one person
  const ext = [lead.vid ? sha256('v_' + lead.vid) : '', lead.id ? sha256('lead_' + lead.id) : ''].filter(Boolean);
  const country = CC_COUNTRY[String(s.default_cc || '91').replace(/\D/g, '')];
  const ud: Record<string, unknown> = {
    client_ip_address: lead.ip || undefined,
    client_user_agent: lead.ua || undefined,
    fbc,
    fbp: lead.fbp || undefined,
    em: h(lead.email),
    ph: ph ? [sha256(ph)] : undefined,
    fn: h(parts[0]),
    ln: parts.length > 1 ? h(parts[parts.length - 1]) : undefined,
    country: country ? [sha256(country)] : undefined,
    external_id: ext.length ? ext : undefined,
  };
  Object.keys(ud).forEach(k => ud[k] === undefined && delete ud[k]);
  return ud;
}

type Ev = { ch?: string | null; line?: string | null; event_id: string; event_name: string; lead_id?: number | null; user_data: Record<string, unknown>; custom_data?: Record<string, unknown>; source_url?: string | null;
  /** One per person: skip if any of these chats (same person) or event ids already sent this event to the same pixel. */
  once?: { leads?: number[]; events?: string[] } };

/** All chats of the same person: same Telegram ID or same phone number (merged chats included). */
export function samePerson(l: { id?: number | null; tg_chat_id?: string | null; phone?: string | null } | null | undefined): number[] {
  if (!l) return [];
  const ids = new Set<number>(l.id ? [l.id] : []);
  for (const r of all<{ id: number }>('SELECT id FROM leads WHERE (? IS NOT NULL AND tg_chat_id=?) OR (? IS NOT NULL AND ?!=\'\' AND phone=?)', l.tg_chat_id ?? null, l.tg_chat_id ?? null, l.phone ?? null, l.phone ?? '', l.phone ?? null)) ids.add(r.id);
  return [...ids];
}

/** Did this person already send this event to this pixel? (skipped = no pixel set then; dup = our own skip note) */
function sentBefore(name: string, line: string, once: NonNullable<Ev['once']>) {
  const leads = (once.leads || []).filter(Boolean), evs = (once.events || []).filter(Boolean);
  const q = (col: string, xs: unknown[]) => xs.length ? !!one(`SELECT 1 FROM capi_log WHERE event_name=? AND COALESCE(line,'agency')=? AND status NOT IN ('skipped','dup') AND ${col} IN (${xs.map(() => '?').join(',')}) LIMIT 1`, name, line, ...xs) : false;
  return q('lead_id', leads) || q('event_id', evs);
}

/**
 * Sends a server-side event. The event_id is stored first with INSERT OR IGNORE,
 * so the same event can never be sent twice (no duplicate Lead / Purchase).
 */
export async function sendCapi(s: Settings, ev: Ev) {
  const event = {
    event_name: ev.event_name, event_time: Math.floor(now() / 1000), event_id: ev.event_id,
    // v131: a WhatsApp chat that never came through our website (Click-to-WhatsApp, typed the number) is a 'chat' event
    action_source: ev.ch === 'wa' && !ev.source_url && !ev.user_data.fbc ? 'chat' : 'website',
    event_source_url: ev.source_url || undefined, user_data: ev.user_data, custom_data: ev.custom_data,
  };
  // v131: WhatsApp chats go to their own pixels (wa_agency = Agency + Premium, wa_funnel = Funnel)
  const line = ev.ch === 'wa' ? (ev.line === 'funnel' ? 'wa_funnel' : 'wa_agency') : ev.line === 'funnel' ? 'funnel' : 'agency';
  const src = capiSource(ev.event_id, ev.source_url || null, ev.lead_id ?? null); // v137: which page / chat sent it
  if (ev.once && sentBefore(ev.event_name, line, ev.once)) {
    run("INSERT OR IGNORE INTO capi_log(event_id, event_name, lead_id, status, response, payload, tries, created_at, line, source) VALUES(?,?,?,'dup',?,?,0,?,?,?)",
      ev.event_id, ev.event_name, ev.lead_id ?? null, `Not sent: this person already sent a ${ev.event_name} to this pixel`, JSON.stringify(event), now(), line, src);
    return { dedup: true as const };
  }
  const ins = run("INSERT OR IGNORE INTO capi_log(event_id, event_name, lead_id, status, payload, tries, created_at, line, source) VALUES(?,?,?,'pending',?,0,?,?,?)",
    ev.event_id, ev.event_name, ev.lead_id ?? null, JSON.stringify(event), now(), line, src);
  if (!ins.changes) return { dedup: true };
  return deliver(pixelFor(s, line), ev.event_id, event);
}

/** Used for first send and by the background worker for retries (same event_id → Meta dedups too). `s` must already be pixelFor(line). */
export async function deliver(s: Settings, event_id: string, event: unknown) {
  if (!s.pixel_id || !s.capi_token) {
    run("UPDATE capi_log SET status='skipped', response='Pixel ID / CAPI token not set in Admin → Settings' WHERE event_id=?", event_id);
    return { status: 'skipped' };
  }
  const body: Record<string, unknown> = { data: [event] };
  if (s.test_event_code) body.test_event_code = s.test_event_code;
  let status = 'error', resp = '';
  try {
    const r = await fetch(`${GRAPH()}/${s.graph_version || 'v23.0'}/${s.pixel_id}/events?access_token=${encodeURIComponent(s.capi_token)}`, {
      method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body), signal: AbortSignal.timeout(15000),
    });
    resp = await r.text();
    status = r.ok ? 'sent' : 'error';
  } catch (e) { resp = String(e); }
  run('UPDATE capi_log SET status=?, response=?, tries=tries+1 WHERE event_id=?', status, resp.slice(0, 600), event_id);
  return { status, resp };
}

export function capiStatus(event_id: string) { return one<{ status: string }>('SELECT status FROM capi_log WHERE event_id=?', event_id)?.status; }

/* ---------- v137: where each Meta event came from (Admin → Meta events summary) ---------- */
export const CAPI_SOURCES: [string, string][] = [['landing', 'Website landing pages'], ['tg_channel_page', 'Telegram channel pages'], ['wa_page', 'WhatsApp chat pages'], ['wa_comm', 'WhatsApp community pages'],
  ['tg_chat', 'Telegram bot / chats'], ['wa_chat', 'WhatsApp chats'], ['web_orders', 'Website orders'], ['test', 'Test events'], ['other', 'Other']];
export function capiSource(eventId: string, url: string | null, leadId: number | null): string {
  const id = String(eventId || '');
  if (/^test_/.test(id)) return 'test';
  if (/^walead_/.test(id)) return 'wa_chat';
  if (/^wasub_/.test(id)) return 'wa_comm';
  if (/^w(ic|lead_o|purchase)_/.test(id)) return 'web_orders';
  if (/^sub_/.test(id)) return 'tg_channel_page';
  if (/^(lead_|purchase_|ct_|pick_|chpick_)/.test(id) || (leadId && !/^(f_|p_)?(pv|vc|atc)_/.test(id) && !/^ic_/.test(id))) {
    const l = leadId ? one<{ ch: string | null; tg_chat_id: string | null }>('SELECT ch, tg_chat_id FROM leads WHERE id=?', leadId) : undefined;
    return l && (l.ch === 'wa' || String(l.tg_chat_id || '').startsWith('wa:')) ? 'wa_chat' : 'tg_chat';
  }
  let path = ''; try { path = url ? new URL(url).pathname : ''; } catch { /* not a url */ }
  if (/^\/(agency|premium|funnel)\/whatsapp(\/|$)/.test(path)) return 'wa_page';
  if (/^\/(agency|premium|funnel)\/community(\/|$)/.test(path)) return 'wa_comm';
  if (/^\/((agency|premium|funnel)\/)?telegram(\/|$)/.test(path)) return 'tg_channel_page';
  if (/^\/(shop|order|orders|products|pay|checkout)(\/|$)/.test(path)) return 'web_orders';
  if (path || /^(f_|p_)?(pv|vc|atc)_|^ic_/.test(id)) return 'landing';
  return 'other';
}
/** Old rows (before v137) get their source from the event id / the URL in the payload. */
export function backfillCapiSource(limit = 5000) {
  const rows = all<{ event_id: string; payload: string | null; lead_id: number | null }>('SELECT event_id, payload, lead_id FROM capi_log WHERE source IS NULL LIMIT ?', limit);
  for (const r of rows) { let url: string | null = null; try { url = JSON.parse(r.payload || '{}').event_source_url || null; } catch { /* */ } run('UPDATE capi_log SET source=? WHERE event_id=?', capiSource(r.event_id, url, r.lead_id), r.event_id); }
  return rows.length;
}
