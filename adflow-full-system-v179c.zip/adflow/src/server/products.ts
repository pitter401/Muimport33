import { type Settings, fmt, lines } from './settings';
import { num } from './util';
import type { ProductItem, OrderWays, ProductQ } from '@/components/site/designs/Premium';
import { waReady } from './wati';
import { waNumber } from './wapages';

/** /products — everything we sell at the TELEGRAM prices (this page is the link we give in Telegram / WhatsApp chats).
 *  Ad accounts + funnel order on the website (tg=1 → Telegram prices); Facebook account + Business Manager setup is ordered on Telegram. */
export function productList(s: Settings): ProductItem[] {
  const web = s.web_orders_on === '1';
  // v134: "Order now" → a few quick questions for that product, then the customer picks how: website, Telegram, or WhatsApp
  // (when WhatsApp chats are on). The answers go in their first message so the agent sees at once who is serious.
  const waN = waReady(s) ? waNumber(s) : '';
  const ways = (q: string | null, ask: string): OrderWays => ({
    web: web && q !== null ? `/order?tg=1${q ? '&' + q : ''}` : undefined,
    tg: s.owner_username ? `https://t.me/${s.owner_username}` : '/telegram',
    wa: waN.length >= 8 ? `https://wa.me/${waN}` : undefined,
    text: ask,
  });
  const RAN: ProductQ = { q: 'Have you run Facebook ads before?', a: ['Yes, regularly', 'A few times', 'Never'] };
  const BM: ProductQ = { q: 'Do you have a Business Manager?', a: ['Yes', 'No', 'Not sure'] };
  const qAcc: ProductQ[] = [RAN, BM, { q: 'Monthly ad budget?', a: ['Under $300', '$300 – $1,000', '$1,000+'] }, { q: 'How many ad accounts?', a: ['1', '2 – 3', '4+'] }];
  const qPrem: ProductQ[] = [RAN, { q: 'Daily ad spend you plan?', a: ['Under $100', '$100 – $500', '$500+'] }, BM, { q: 'What do you advertise?', a: ['E-commerce', 'Leads / services', 'Apps / games', 'Other'] }];
  const qFunnel: ProductQ[] = [{ q: 'What is your business?', a: ['E-commerce', 'Local service', 'Coaching / education', 'Other'] }, RAN, { q: 'Monthly ad budget?', a: ['Under $300', '$300 – $1,000', '$1,000+'] }, { q: 'Do you have a website?', a: ['Yes', 'No'] }];
  const qFb: ProductQ[] = [RAN, { q: 'What do you need?', a: ['Facebook account + BM', 'Only a Business Manager'] }];
  const cta = 'Order now';
  const prem = s.premium_on === '1';
  const fee = `${num(s.topup_comm_pct, 3)}%`;
  const min = `$${num(s.topup_min, 30)}`;
  const accB = lines(fmt(s.account_bullets || '', s)).slice(0, 4);
  const premB = lines(s.premium_bullets || '').slice(0, 4);
  const pPrem = num(s.price_premium || s.price_account), pAcc = num(s.price_account), pFull = num(s.price_account_full), pPremFull = num(s.price_premium_full);
  const viaAgent = `We top up for you · ${fee} fee (min ${min})`;
  const yourself = 'You top up yourself · no fee';
  const items: (ProductItem | false)[] = [
    prem && { id: 'premium', group: 'popular', qs: qPrem, title: s.premium_title || 'Premium ad account', price: pPrem, unit: 'per account', badge: 'Most popular', featured: true, topup: viaAgent,
      alt: pPremFull > 0 ? `Want to top up yourself? Full access Premium: $${pPremFull}` : undefined,
      bullets: premB.length ? premB : ['Aged profiles with a strong history', 'Handles higher daily spend', 'Priority delivery', 'Unlimited free replacements'], ways: ways('tier=premium', 'Hi, I want a Premium ad account'), cta },
    { id: 'agency', group: 'managed', qs: qAcc, title: 'Agency ad account', price: pAcc, unit: 'per account', badge: 'Agency', topup: viaAgent,
      alt: pFull > 0 ? `Want to top up yourself? Full access: $${pFull}` : undefined,
      bullets: accB.length ? accB : ['No spending limit', 'No 18% GST on your ad spend', 'Shared to your Business Manager', 'Free replacement if any issue'], ways: ways('', 'Hi, I want an agency ad account'), cta },
    prem && pPremFull > 0 && { id: 'full-access-premium', group: 'full', qs: qPrem, title: 'Full access Premium ad account', price: pPremFull, unit: 'per account', badge: 'Full access · Premium', topup: yourself,
      alt: `The same Premium account, but you add the budget yourself. Without full access it is $${pPrem}.`,
      bullets: ['Aged, strong-history profile', 'Add funds with your own card in Ads Manager', 'Handles higher daily spend', 'Includes the account + 2 free replacements'], ways: ways('tier=premium&kind=full', 'Hi, I want a full access Premium ad account'), cta },
    pFull > 0 && { id: 'full-access', group: 'full', qs: qAcc, title: 'Full access ad account', price: pFull, unit: 'per account', badge: 'Full access', topup: yourself,
      alt: `The same agency account, but you add the budget yourself. Without full access it is $${pAcc}.`,
      bullets: ['Add funds with your own card in Ads Manager', 'No top-up fee from us', 'Includes the account + 2 free replacements', 'Shared to your Business Manager'], ways: ways('kind=full', 'Hi, I want a full access ad account'), cta },
    // v126: for people with no Facebook account / Business Manager — we create them (was "Aged Facebook account")
    num(s.price_fb_old) > 0 && { id: 'facebook-account', group: 'other', qs: qFb, title: 'Facebook Account + Business Manager', price: num(s.price_fb_old), unit: 'one-time', badge: 'No Facebook? Start here',
      bullets: ['For you if you have no Facebook account or Business Manager', 'We create the Facebook account for you', 'Business Manager set up inside it, ready for your ad account', 'Delivered by your agent in the chat'], ways: ways(null, 'Hi, I need a Facebook account with Business Manager'), cta },
    { id: 'funnel', group: 'popular', qs: qFunnel, title: 'Landing page + funnel setup', price: num(s.price_funnel), unit: 'per month', badge: 'Most popular', featured: true,
      bullets: ['Landing page made for your business', 'Meta Pixel + Conversions API tracking', 'We build and run your ad campaign', 'Leads straight to your WhatsApp / Telegram', '1 reel video for your ads'], ways: ways('kind=funnel', 'Hi, I want a landing page + funnel setup'), cta },
    // v134: no separate "top-up" product here (it confused buyers) — each account says who tops it up
  ];
  return items.filter(Boolean) as ProductItem[];
}
