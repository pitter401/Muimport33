/* Watchdog events (written by worker/watchdog.mjs): the worker tells the admin, Admin → System lists them. */
import fs from 'fs';
import path from 'path';
import { pushTo } from './push';
import { HttpError } from './util';

export type WatchdogEvent = { at: number; kind: 'restarted' | 'restart_failed' | 'gave_up'; why?: string; report?: string };
const dir = () => path.join(path.dirname(process.env.DB_PATH || path.join(process.cwd(), 'data', 'adflow.db')), 'watchdog');

export function watchdogEvents(limit = 20): WatchdogEvent[] {
  try {
    return fs.readFileSync(path.join(dir(), 'events.jsonl'), 'utf8').trim().split('\n').filter(Boolean).slice(-limit)
      .map(l => { try { return JSON.parse(l) as WatchdogEvent; } catch { return null; } }).filter(Boolean).reverse() as WatchdogEvent[];
  } catch { return []; }
}

export function watchdogReport(name: unknown) {
  const n = String(name || '');
  if (!/^report-[\w-]+\.txt$/.test(n)) throw new HttpError(400, 'Bad report name');
  try { return fs.readFileSync(path.join(dir(), n), 'utf8').slice(0, 200_000); } catch { throw new HttpError(404, 'Report not found (only the last 30 are kept)'); }
}

const TITLE = { restarted: '⚠️ Website was stuck — restarted', restart_failed: '❌ Website is down — restart did not help', gave_up: '❌ Website keeps getting stuck' };
const BODY = { restarted: 'It did not answer, so it was restarted automatically. It is working again.', restart_failed: 'Restarted, but it still does not answer. Check the server (pm2 logs adflow-web).', gave_up: 'Restarted 3 times this hour. Not restarting again — check the server.' };

/** Worker: one admin notification per new event. */
export async function watchdogNotify() {
  const f = path.join(dir(), 'events.jsonl'), seenF = path.join(dir(), 'notified');
  if (!fs.existsSync(f)) return 0;
  const size = fs.statSync(f).size;
  let seen = -1;
  try { seen = Number(fs.readFileSync(seenF, 'utf8')) || 0; } catch { /* first run */ }
  if (seen < 0 || seen > size) { fs.writeFileSync(seenF, String(size)); return 0; } // first run: don't replay old events
  if (seen === size) return 0;
  const fd = fs.openSync(f, 'r'); const buf = Buffer.alloc(size - seen); fs.readSync(fd, buf, 0, buf.length, seen); fs.closeSync(fd);
  fs.writeFileSync(seenF, String(size));
  let n = 0;
  for (const l of buf.toString('utf8').split('\n').filter(Boolean)) {
    try {
      const e = JSON.parse(l) as WatchdogEvent;
      await pushTo('admin', null, TITLE[e.kind] || 'Website watchdog', `${BODY[e.kind] || ''}${e.why ? ` (${e.why})` : ''} Details: Admin → System.`);
      n++;
    } catch { /* bad line */ }
  }
  return n;
}
