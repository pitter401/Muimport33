/**
 * Makes the AI voice note sound like it was recorded on a phone in a room (v87):
 *  - soft room noise under the voice (ceiling-fan hum + air), a little different every time,
 *    or the admin's own room recording (Admin → AI → Voice notes → "Your room sound"),
 *  - phone-mic sound (no deep bass, no studio highs), a tiny room echo, a short pause before and after,
 *  - saved as OGG/Opus mono — the real Telegram voice-note format (shows the waveform).
 * Needs ffmpeg on the server (scripts/update.sh installs it). Without ffmpeg the clean audio is sent as before.
 */
import fs from 'fs';
import os from 'os';
import path from 'path';
import { spawn, execFileSync } from 'child_process';

export type NoiseLevel = 'off' | 'light' | 'medium';

let ffBin: string | null | undefined;
let ffMissAt = 0;
/** v149: the last ffmpeg problem (shown in the error, so the real reason is visible). */
export let lastFfError = '';
/** Path of ffmpeg, or null when it is not installed.
 *  v149: "not found" is NOT kept forever — right after an update the server is busy and the check could time out, and then
 *  every voice note failed until the next restart. A miss is re-checked after 30 s; a file that exists is trusted. */
export function ffmpegPath(): string | null {
  if (ffBin) return ffBin;
  if (ffBin === null && Date.now() - ffMissAt < 30000) return null;
  const cands = process.env.FFMPEG_PATH ? [process.env.FFMPEG_PATH] : ['/usr/bin/ffmpeg', '/usr/local/bin/ffmpeg', '/snap/bin/ffmpeg', 'ffmpeg']; // FFMPEG_PATH = use only that one
  ffBin = null;
  for (const c of cands) {
    try { execFileSync(c, ['-hide_banner', '-version'], { stdio: 'ignore', timeout: 20000 }); ffBin = c; break; }
    catch (e) {
      lastFfError = `${c}: ${(e as Error).message.split('\n')[0].slice(0, 120)}`;
      if (c.startsWith('/') && fs.existsSync(c) && /ETIMEDOUT|timed out|ENOMEM|EAGAIN/i.test(String((e as Error).message))) { ffBin = c; break; } // there, just slow
    }
  }
  if (!ffBin) ffMissAt = Date.now();
  return ffBin;
}
export const resetFfmpegCache = () => { ffBin = undefined; };

export const voiceDir = () => {
  const d = path.join(path.dirname(process.env.DB_PATH || path.join(process.cwd(), 'data', 'adflow.db')), 'voice');
  fs.mkdirSync(d, { recursive: true });
  return d;
};
/** The admin's own room recording (converted to ogg when uploaded). */
export const roomNoiseFile = () => path.join(voiceDir(), 'room.ogg');
export const hasRoomNoise = () => fs.existsSync(roomNoiseFile());
/** The ready-made office background (keyboard typing, girls talking on the phone far away, fan) — made once with ElevenLabs. */
export const officeBedFile = () => path.join(voiceDir(), 'office.ogg');
export const hasOfficeBed = () => fs.existsSync(officeBedFile());
const lenOf = (f: string, d = 20) => { try { return Math.max(1, Number(fs.readFileSync(f + '.len', 'utf8')) || d); } catch { return d; } };
export const officeBedSeconds = () => (hasOfficeBed() ? Math.round(lenOf(officeBedFile(), 0)) : 0);

function ff(args: string[], ms = 45000): Promise<void> {
  const bin = ffmpegPath();
  if (!bin) return Promise.reject(new Error('ffmpeg is not installed'));
  return new Promise((res, rej) => {
    const p = spawn(bin, ['-hide_banner', '-loglevel', 'error', '-y', ...args], { stdio: ['ignore', 'ignore', 'pipe'] });
    let err = '';
    p.stderr.on('data', d => { err = (err + d).slice(-2000); });
    const t = setTimeout(() => { p.kill('SIGKILL'); rej(new Error('ffmpeg took too long')); }, ms);
    p.on('error', e => { clearTimeout(t); rej(e); });
    p.on('close', code => { clearTimeout(t); if (code === 0) res(); else { const m = 'ffmpeg: ' + (err.trim().split('\n').pop() || 'exit ' + code); lastFfError = m.slice(0, 200); rej(new Error(m)); } });
  });
}
const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'vfx-'));
const r3 = (x: number) => Math.round(x * 1000) / 1000;

/** How loud the room is. Voice is ~-18 dB; light room ≈ -44 dB, medium ≈ -38 dB. */
const LEVEL: Record<Exclude<NoiseLevel, 'off'>, number> = { light: 1, medium: 2 };

/**
 * Speech (mp3/wav/ogg…) → voice-note ogg. `rnd` is only for tests.
 * Returns null when ffmpeg is missing or fails (the caller then sends the clean audio).
 */
export async function voiceFx(input: Buffer, level: NoiseLevel, rnd: () => number = Math.random, bg: 'fan' | 'office' = 'fan', speed = 1, gainDb = 0): Promise<Buffer | null> {
  if (!ffmpegPath()) return null;
  const dir = tmp();
  const inF = path.join(dir, 'in.audio'), outF = path.join(dir, 'out.ogg');
  try {
    fs.writeFileSync(inF, input);
    const pre = 0.25 + rnd() * 0.3, post = 0.3 + rnd() * 0.35; // seconds of "room" before / after the voice
    const enc = ['-c:a', 'libopus', '-b:a', '32k', '-vbr', 'on', '-application', 'voip', '-ar', '48000', '-ac', '1', outF];
    // phone mic: cut deep bass and the studio air, a small presence bump, a tiny room echo, a softer compressor
    // speed < 1 = a bit slower (same pitch) — AI voices talk too fast to sound like a person on the phone
    const tempo = Math.abs(speed - 1) > 0.01 ? `atempo=${Math.min(1.2, Math.max(0.7, speed)).toFixed(3)},` : '';
    const voice = `[0:a]aresample=48000,aformat=sample_fmts=fltp:channel_layouts=mono,${tempo}highpass=f=${Math.round(105 + rnd() * 40)},lowpass=f=${Math.round(6800 + rnd() * 900)},` +
      `equalizer=f=2600:t=q:w=1.2:g=2,volume=${(3 + Math.min(6, Math.max(-12, gainDb))).toFixed(1)}dB,aecho=0.85:0.55:${Math.round(18 + rnd() * 10)}|${Math.round(37 + rnd() * 12)}:0.09|0.05,` +
      `adelay=${Math.round(pre * 1000)}:all=1,apad=pad_dur=${r3(post)}[v]`;
    if (level === 'off') {
      await ff(['-i', inF, '-filter_complex', voice, '-map', '[v]', ...enc]); // phone sound + pauses, no room
      return fs.readFileSync(outF);
    }
    const k = LEVEL[level] * (0.8 + rnd() * 0.4); // a little different every time
    // the admin's own room recording, else the office background — a different random part every time, looped
    const bed = hasRoomNoise() ? roomNoiseFile() : bg === 'office' && hasOfficeBed() ? officeBedFile() : '';
    if (bed) {
      const dur = lenOf(bed);
      const ss = r3(rnd() * Math.max(0, dur - 8));
      await ff(['-i', inF, '-stream_loop', '-1', '-ss', String(ss), '-i', bed, '-filter_complex',
        `${voice};[1:a]aresample=48000,aformat=sample_fmts=fltp:channel_layouts=mono,volume=${r3(0.55 * k)}[n];[v][n]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.95[o]`,
        '-map', '[o]', ...enc]);
      return fs.readFileSync(outF);
    }
    // made-up room: fan air (brown noise that slowly "breathes" like blades), a soft hiss, and the fan motor hum
    const air = r3(0.04 * k), hiss = r3(0.006 * k), hum = r3(0.008 * k);
    const fan = r3(1.6 + rnd() * 2.6), humF = rnd() < 0.5 ? 100 : 150;
    await ff(['-i', inF,
      '-f', 'lavfi', '-i', `anoisesrc=color=brown:amplitude=${air}:sample_rate=48000:seed=${Math.floor(rnd() * 1e6)}`,
      '-f', 'lavfi', '-i', `anoisesrc=color=pink:amplitude=${hiss}:sample_rate=48000:seed=${Math.floor(rnd() * 1e6)}`,
      '-f', 'lavfi', '-i', `sine=frequency=${humF}:sample_rate=48000`,
      '-filter_complex',
      `${voice};[1:a]lowpass=f=900,tremolo=f=${fan}:d=0.18[a];[2:a]highpass=f=1800,lowpass=f=6500[h];[3:a]volume=${hum},tremolo=f=${fan}:d=0.3[m];` +
      `[a][h][m]amix=inputs=3:normalize=0[n];[v][n]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.95[o]`,
      '-map', '[o]', ...enc]);
    return fs.readFileSync(outF);
  } catch (e) {
    console.error('[voicefx]', (e as Error).message);
    lastFfError = (e as Error).message.slice(0, 200);
    // v149: the room sound / phone effect failed → still send the voice note, just plain (never block the message)
    try { await ff(['-i', inF, '-vn', '-c:a', 'libopus', '-b:a', '32k', '-vbr', 'on', '-application', 'voip', '-ar', '48000', '-ac', '1', outF]); return fs.readFileSync(outF); }
    catch (e2) { console.error('[voicefx plain]', (e2 as Error).message); lastFfError = (e2 as Error).message.slice(0, 200); return null; }
  } finally {
    try { fs.rmSync(dir, { recursive: true, force: true }); } catch { /* fine */ }
  }
}

/** Any recording (webm / m4a / ogg …) → a real Telegram voice note (OGG/Opus mono 48 kHz), sound unchanged. null when it fails. */
export async function toVoiceOgg(input: Buffer): Promise<Buffer | null> {
  if (!ffmpegPath()) return null;
  const dir = tmp();
  try {
    const inF = path.join(dir, 'in.media'), outF = path.join(dir, 'out.ogg');
    fs.writeFileSync(inF, input);
    await ff(['-i', inF, '-vn', '-c:a', 'libopus', '-b:a', '32k', '-vbr', 'on', '-application', 'voip', '-ar', '48000', '-ac', '1', outF]);
    return fs.readFileSync(outF);
  } catch (e) { console.error('[voicefx]', (e as Error).message); return null; }
  finally { try { fs.rmSync(dir, { recursive: true, force: true }); } catch { /* fine */ } }
}

/** Saves the admin's room recording (any audio/video) as the room sound: mono ogg, max 60 s, loudness evened out. */
export async function saveRoomNoise(input: Buffer): Promise<{ seconds: number }> {
  if (!ffmpegPath()) throw new Error('ffmpeg is not installed on the server yet — run the update again, or: apt-get install -y ffmpeg');
  const dir = tmp();
  try {
    const inF = path.join(dir, 'in.media'), outF = path.join(dir, 'room.ogg');
    fs.writeFileSync(inF, input);
    // the recording is only background: even it out to a quiet, steady level (the mix lowers it further)
    await ff(['-i', inF, '-vn', '-t', '60', '-af', 'aresample=48000,aformat=channel_layouts=mono,highpass=f=40,dynaudnorm=f=500:g=31:m=4,volume=-24dB', '-c:a', 'libopus', '-b:a', '32k', '-ac', '1', outF]);
    // length from the decoded result (phone recordings often carry no length in the file)
    const seconds = Math.max(await durationOf(outF), await durationOf(inF));
    if (seconds > 0 && seconds < 3) throw new Error(`The recording is only ${seconds.toFixed(1)} s — record 10-20 seconds of your room`);
    fs.copyFileSync(outF, roomNoiseFile());
    fs.writeFileSync(roomNoiseFile() + '.len', String(seconds));
    return { seconds: Math.round(seconds || 12) };
  } finally { try { fs.rmSync(dir, { recursive: true, force: true }); } catch { /* fine */ } }
}

/** Joins the generated office clips (each ~30 s) into one long background (2-4 min) with soft crossfades,
 *  evened-out loudness and a little "far away" sound, so it stays behind the voice. */
export async function buildOfficeBed(clips: Buffer[]): Promise<{ seconds: number }> {
  if (!ffmpegPath()) throw new Error('ffmpeg is not installed on the server yet — run the update again, or: apt-get install -y ffmpeg');
  if (clips.length < 2) throw new Error('Not enough background clips were made');
  const dir = tmp();
  try {
    const ins: string[] = [];
    clips.forEach((c, i) => { const f = path.join(dir, `c${i}.mp3`); fs.writeFileSync(f, c); ins.push('-i', f); });
    const n = clips.length;
    const prep = clips.map((_, i) => `[${i}:a]aresample=48000,aformat=sample_fmts=fltp:channel_layouts=mono[p${i}]`).join(';');
    let chain = '', last = 'p0';
    for (let i = 1; i < n; i++) { const o = i === n - 1 ? 'j' : `x${i}`; chain += `;[${last}][p${i}]acrossfade=d=1.5:c1=tri:c2=tri[${o}]`; last = o; }
    const outF = path.join(dir, 'office.ogg');
    await ff([...ins, '-filter_complex', `${prep}${chain};[j]highpass=f=60,lowpass=f=6000,loudnorm=I=-26:TP=-6:LRA=11,volume=-6dB[o]`, '-map', '[o]', '-c:a', 'libopus', '-b:a', '40k', '-ac', '1', outF], 180000);
    const seconds = await durationOf(outF);
    if (seconds < 20) throw new Error('The office background came out too short — try again');
    fs.copyFileSync(outF, officeBedFile());
    fs.writeFileSync(officeBedFile() + '.len', String(seconds));
    return { seconds: Math.round(seconds) };
  } finally { try { fs.rmSync(dir, { recursive: true, force: true }); } catch { /* fine */ } }
}
export function deleteRoomNoise() {
  for (const f of [roomNoiseFile(), roomNoiseFile() + '.len']) try { fs.unlinkSync(f); } catch { /* gone */ }
}

/** Length in seconds (decodes the file once with ffmpeg; no ffprobe needed). */
export async function durationOf(file: string): Promise<number> {
  const bin = ffmpegPath();
  if (!bin) return 0;
  return new Promise(res => {
    const p = spawn(bin, ['-hide_banner', '-i', file, '-f', 'null', '-'], { stdio: ['ignore', 'ignore', 'pipe'] });
    let err = '';
    p.stderr.on('data', d => { err = (err + d).slice(-6000); });
    p.on('error', () => res(0));
    p.on('close', () => {
      const m = [...err.matchAll(/time=(\d+):(\d+):([\d.]+)/g)].pop();
      res(m ? Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]) : 0);
    });
  });
}
