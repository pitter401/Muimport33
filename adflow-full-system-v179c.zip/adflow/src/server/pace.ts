/**
 * v143: sending speed for every AUTOMATIC message (follow-ups, welcomes, welcome voice, AI replies, reminders, dead-chat
 * messages, bot reminders, delivery messages, auto first messages). Human sends (an agent typing) never come through here.
 *
 * One pacing queue PER CHANNEL — the Telegram chat account ('tga': Business-connection and chat-account sends), the Telegram
 * bot ('tgb': Bot API to people who started the bot) and WhatsApp ('wa', WATI). A limit, pause or spam stop on one channel
 * never holds another one back.
 *
 * How it works: every automatic sender asks paceAsk(ch, key, kind, prio, t) right before it sends. The ask is written to
 * pace_q (the queue); it is granted only when the channel is free (gap + jitter since the last automatic message, under the
 * per-minute / hour / day caps, no pause) AND this item is the first in line (lowest prio number, then oldest). Items not
 * granted stay in line and are asked again on the next tick (welcomes every 4 s, follow-ups every 5 s …). Asks that nobody
 * repeats for 3 minutes drop out of the line (their chat no longer needs them).
 */
import { all, one, run, db } from './db';
import { getSettings, setSetting, type Settings } from './settings';
import { num, now, HOUR } from './util';

export type Ch = 'tga' | 'tgb' | 'wa';
export const CHS: Ch[] = ['tga', 'tgb', 'wa'];
export const CH_NAME: Record<Ch, string> = { tga: 'Telegram chat account', tgb: 'Telegram bot', wa: 'WhatsApp' };
/** Lower = sooner. Replies owed to people who wrote to us first, then follow-up 1 → 2 → 3, … stranger first messages last. */
export const PRIO = { reply: 0, remind: 1, delivery: 2, fu1: 11, fu2: 12, fu3: 13, botfu: 14, revive: 20, first: 90 } as const;
const STALE = 3 * 60_000;
const MIN = 60_000, DAY = 24 * HOUR;

/** Which channel a chat's automatic messages go out on. */
export function chOf(l: { tg_chat_id?: string | null; ch?: string | null; biz_conn?: string | null; tg_access_hash?: string | null } | null | undefined): Ch {
  if (!l) return 'tga';
  if (l.ch === 'wa' || String(l.tg_chat_id || '').startsWith('wa:')) return 'wa';
  if (l.biz_conn || l.tg_access_hash) return 'tga';
  return 'tgb';
}

export type Lim = { gap: number; jitter: number; min: number; hour: number; day: number };
const n0 = (v: unknown, d: number) => Math.max(0, num(v, d));
export function limits(s: Settings, ch: Ch): Lim {
  if (ch === 'tga') return { gap: n0(s.pace_tga_gap, 90), jitter: n0(s.pace_tga_jitter, 60), min: 0, hour: n0(s.pace_tga_hour, 20), day: n0(s.pace_tga_day, 120) };
  if (ch === 'tgb') return { gap: n0(s.pace_tgb_gap, 3), jitter: 0, min: n0(s.pace_tgb_min, 30), hour: 0, day: 0 };
  return { gap: n0(s.pace_wa_gap, 20), jitter: n0(s.pace_wa_jitter, 15), min: 0, hour: n0(s.pace_wa_hour, 60), day: 0 };
}
/** Stranger first messages (auto first message): own lower caps. The older "Max first messages per hour" still applies if lower. */
export function firstCaps(s: Settings) {
  const h = n0(s.pace_first_hour, 5), old = n0(s.auto_msg_hour_cap, 20);
  return { hour: old > 0 ? Math.min(h, old) : h, day: n0(s.pace_first_day, 30) };
}

type St = { ch: string; next_at: number; wait_until: number; why: string | null; at: number | null };
const st = (k: string): St => one<St>('SELECT ch, next_at, wait_until, why, at FROM pace_ch WHERE ch=?', k) || { ch: k, next_at: 0, wait_until: 0, why: null, at: null };
const put = (k: string, f: Partial<St>) => {
  const o = { ...st(k), ...f };
  run('INSERT INTO pace_ch(ch, next_at, wait_until, why, at) VALUES(?,?,?,?,?) ON CONFLICT(ch) DO UPDATE SET next_at=excluded.next_at, wait_until=excluded.wait_until, why=excluded.why, at=excluded.at', k, o.next_at || 0, o.wait_until || 0, o.why ?? null, o.at ?? null);
};

/** Before v143 a spam limit was a far-future ub_pause_until that blocked everything on the chat account (and, by mistake,
 *  WhatsApp follow-ups too). Seen → turned into the v143 pause: automatic chat-account messages 24 h, stranger first messages 48 h. */
function legacyStop(t: number, s: Settings) {
  if (num(s.ub_pause_until) < 9e15) return;
  setSetting('ub_pause_until', '0');
  const fh = Math.max(1, num(s.pace_flood_h, 24)), sh = Math.max(1, num(s.pace_first_flood_h, 48));
  put('auto_tga', { wait_until: t + fh * HOUR, why: 'PEER_FLOOD', at: t });
  put('first', { wait_until: Math.max(st('first').wait_until, t + sh * HOUR), why: 'PEER_FLOOD', at: t });
}

/** Telegram spam limit (PEER_FLOOD …) on the chat account: automatic chat-account messages paused until … (0 = not paused). */
export function tgaStopUntil(t = now(), s: Settings = getSettings()) {
  legacyStop(t, s);
  const w = st('auto_tga').wait_until;
  return w > t ? w : 0;
}
/** Is the Telegram chat account under a spam-limit pause right now (for chat-account chats only — never WhatsApp / the bot). */
export const tgaStopped = (t = now(), s: Settings = getSettings()) => tgaStopUntil(t, s) > 0;

/** v145: replies to a person who wrote first — never paused by a spam limit or the auto-message speed limits. */
export const REPLY_KINDS = new Set(['welcome', 'voice', 'ai']);
/** Why this channel can't send an automatic message of this kind now, and from when it could. null = free now. */
export function blockOf(ch: Ch, kind: string, t: number, s: Settings = getSettings()): { why: string; until: number } | null {
  legacyStop(t, s);
  const off = s.pace_on === '0'; // speed limits OFF: Telegram's own waits and the spam-limit pauses still count
  const L = limits(s, ch), c = st(ch);
  const cands: { why: string; until: number }[] = [];
  if (c.wait_until > t) cands.push({ why: `${CH_NAME[ch]}: Telegram asked to wait (${c.why || 'FLOOD_WAIT'})`, until: c.wait_until });
  // v145: replies owed to someone who just wrote to us (welcome, welcome voice, AI reply) are allowed by Telegram even under a
  // spam limit, and they must not wait behind the follow-up speed limits — only Telegram's own FLOOD_WAIT holds them.
  if (REPLY_KINDS.has(kind)) { if (!cands.length) return null; return cands.sort((a, b) => b.until - a.until)[0]; }
  if (ch === 'tga') { const a = st('auto_tga'); if (a.wait_until > t) cands.push({ why: `spam limit on the chat account (${a.why || 'PEER_FLOOD'})`, until: a.wait_until }); }
  if (kind === 'first') {
    const f = st('first'); if (f.wait_until > t) cands.push({ why: `first messages to new people paused after a Telegram limit (${f.why || 'limit'})`, until: f.wait_until });
    const fc = off ? { hour: 0, day: 0 } : firstCaps(s);
    const cap = (win: number, max: number, label: string) => {
      if (!(max > 0)) return;
      const r = all<{ at: number }>("SELECT at FROM pace_log WHERE ch='tga' AND kind='first' AND at>? ORDER BY at DESC LIMIT ?", t - win, max);
      if (r.length >= max) cands.push({ why: `first-message cap ${max}/${label}`, until: r[r.length - 1].at + win });
    };
    cap(HOUR, fc.hour, 'hour'); cap(DAY, fc.day, 'day');
  }
  if (!off && c.next_at > t) cands.push({ why: 'gap between automatic messages', until: c.next_at });
  const cap = (win: number, max: number, label: string) => {
    if (off || !(max > 0)) return;
    const r = all<{ at: number }>('SELECT at FROM pace_log WHERE ch=? AND at>? ORDER BY at DESC LIMIT ?', ch, t - win, max);
    if (r.length >= max) cands.push({ why: `${max} per ${label}`, until: r[r.length - 1].at + win });
  };
  cap(MIN, L.min, 'minute'); cap(HOUR, L.hour, 'hour'); cap(DAY, L.day, 'day');
  if (!cands.length) return null;
  return cands.sort((a, b) => b.until - a.until)[0];
}

/**
 * Ask for the next automatic send slot on a channel. true = send now (counted); false = wait in line, ask again later.
 * key: one queue entry per message (e.g. 'fu:12:2'); kind: fu / welcome / voice / ai / remind / revive / botfu / delivery / first.
 */
export function paceAsk(ch: Ch, key: string, kind: string, prio: number, t = now(), leadId: number | null = null): boolean {
  // one write transaction: the worker and the website process (it runs the follow-up check on page loads too) never both get
  // the same slot
  return db().transaction(() => askTx(ch, key, kind, prio, t, leadId)).immediate();
}
function askTx(ch: Ch, key: string, kind: string, prio: number, t: number, leadId: number | null): boolean {
  const s = getSettings();
  if (s.pace_on === '0') { if (blockOf(ch, kind, t, s)) return false; grant(ch, key, kind, t, leadId, s); return true; } // limits OFF: no line, no gap (pauses still count)
  run(`INSERT INTO pace_q(key, ch, kind, prio, lead_id, since, seen) VALUES(?,?,?,?,?,?,?)
       ON CONFLICT(key) DO UPDATE SET seen=excluded.seen, prio=excluded.prio, ch=excluded.ch`, key, ch, kind, prio, leadId, t, t);
  if (blockOf(ch, kind, t, s)) return false;
  // first in line? (asks not repeated for 3 min are dropped: nothing waits for them any more)
  run('DELETE FROM pace_q WHERE seen<?', t - STALE);
  const best = one<{ key: string }>('SELECT key FROM pace_q WHERE ch=? ORDER BY prio, since, key LIMIT 1', ch);
  if (best && best.key !== key) return false;
  grant(ch, key, kind, t, leadId, s);
  return true;
}
function grant(ch: Ch, key: string, kind: string, t: number, leadId: number | null, s: Settings) {
  run('DELETE FROM pace_q WHERE key=?', key);
  run('INSERT INTO pace_log(ch, kind, key, lead_id, at) VALUES(?,?,?,?,?)', ch, kind, key, leadId, t);
  if (s.pace_on !== '0') { const L = limits(s, ch); put(ch, { next_at: t + Math.round((L.gap + Math.random() * L.jitter) * 1000) }); }
  run('DELETE FROM pace_log WHERE at<?', t - 3 * DAY);
}
/** Same as paceAsk, but when the only thing in the way is a short gap (≤ maxWaitMs), waits for it (real time, worker only). */
export async function paceAskWait(ch: Ch, key: string, kind: string, prio: number, maxWaitMs: number, leadId: number | null = null) {
  if (paceAsk(ch, key, kind, prio, now(), leadId)) return true;
  const b = blockOf(ch, kind, now());
  if (!b || b.until - now() > maxWaitMs) return false;
  await new Promise(r => setTimeout(r, Math.max(0, b.until - now()) + 20));
  return paceAsk(ch, key, kind, prio, now(), leadId);
}
/** This message is no longer needed (the chat answered, was closed …) → out of the line. */
export function paceDrop(key: string) { run('DELETE FROM pace_q WHERE key=?', key); }
export function paceDropLike(prefix: string) { run('DELETE FROM pace_q WHERE key LIKE ?', prefix + '%'); }

/* ---------------- Telegram / WhatsApp limits ---------------- */
/** FLOOD_WAIT_X / "retry after X": that channel's queue sleeps exactly X seconds + a margin (Settings, default 30 s). */
export function paceFloodWait(ch: Ch, sec: number, t = now(), why = 'FLOOD_WAIT') {
  const s = getSettings();
  const until = t + (Math.max(0, sec) + n0(s.pace_fw_margin, 30)) * 1000;
  put(ch, { wait_until: Math.max(st(ch).wait_until, until), why: `${why}_${Math.round(sec)}`, at: t });
  // any Telegram limit → stranger first messages pause 48 h
  if (ch === 'tga') put('first', { wait_until: Math.max(st('first').wait_until, t + Math.max(1, num(s.pace_first_flood_h, 48)) * HOUR), why, at: t });
  return until;
}
/** PEER_FLOOD (spam limit) on the chat account: all AUTOMATIC chat-account messages pause for pace_flood_h (24 h), stranger
 *  first messages for 48 h. People can still send by hand. WhatsApp and the Telegram bot are not touched. true = new (alert). */
export function pacePeerFlood(code = 'PEER_FLOOD', t = now()) {
  const s = getSettings();
  legacyStop(t, s);
  const cur = st('auto_tga');
  const until = t + Math.max(1, num(s.pace_flood_h, 24)) * HOUR;
  put('first', { wait_until: Math.max(st('first').wait_until, t + Math.max(1, num(s.pace_first_flood_h, 48)) * HOUR), why: code, at: t });
  if (cur.wait_until > t) return false; // already paused: no new alert, the pause is not stretched again and again
  put('auto_tga', { wait_until: until, why: code, at: t });
  return true;
}
/** Admin → Resume: the spam-limit pause and Telegram's wait end, but the queue goes on at the normal speed (gap from NOW,
 *  hourly / daily caps keep counting) — never the whole backlog at once. Stranger first messages keep their own 48 h pause. */
export function paceResume(t = now()) {
  const s = getSettings();
  legacyStop(t, s);
  put('auto_tga', { wait_until: 0 });
  const L = limits(s, 'tga');
  put('tga', { wait_until: 0, next_at: Math.max(st('tga').next_at, t + Math.round(L.gap * 1000)) });
  return { first_until: st('first').wait_until > t ? st('first').wait_until : 0 };
}

/* ---------------- status (Admin → System → Follow-ups check, Auto first message) ---------------- */
export function paceStatus(t = now()) {
  const s = getSettings();
  legacyStop(t, s);
  run('DELETE FROM pace_q WHERE seen<?', t - STALE);
  const out = CHS.map(ch => {
    const L = limits(s, ch);
    const waiting = one<{ n: number }>('SELECT COUNT(*) n FROM pace_q WHERE ch=?', ch)!.n;
    const firstQ = one<{ k: string | null }>('SELECT kind k FROM pace_q WHERE ch=? ORDER BY prio, since, key LIMIT 1', ch)?.k || 'fu';
    const b = blockOf(ch, firstQ, t, s);
    const sent1h = one<{ n: number }>('SELECT COUNT(*) n FROM pace_log WHERE ch=? AND at>?', ch, t - HOUR)!.n;
    const sent24 = one<{ n: number }>('SELECT COUNT(*) n FROM pace_log WHERE ch=? AND at>?', ch, t - DAY)!.n;
    const rate = L.hour ? `${L.hour}/h` : L.min ? `${L.min}/min` : 'no cap';
    return { ch, name: CH_NAME[ch], waiting, next_at: waiting ? (b ? b.until : t) : 0, why: b?.why || '', rate, sent_1h: sent1h, sent_24h: sent24, limits: L };
  });
  const a = st('auto_tga'), f = st('first');
  return { on: s.pace_on !== '0', ch: out, tga_stop_until: a.wait_until > t ? a.wait_until : 0, tga_stop_why: a.why || '', first_until: f.wait_until > t ? f.wait_until : 0 };
}
