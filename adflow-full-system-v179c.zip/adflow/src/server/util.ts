import crypto from 'crypto';
import type { Settings } from './settings';

export const now = () => Date.now();
/** v141: "online" = the agent's app made a request (agents.last_seen, updated on every agent API call) in the last 30 minutes. */
export const ONLINE_MS = 30 * 60000;
export const presence = (lastSeen: number | null | undefined, at = Date.now()) => ({ last_seen_at: lastSeen || null, online_now: !!lastSeen && at - lastSeen < ONLINE_MS });
export const HOUR = 3600000;
export const num = (v: unknown, d = 0) => { const n = parseFloat(String(v)); return Number.isFinite(n) ? n : d; };
export const money = (v: unknown) => Math.round(num(v) * 100) / 100;
export const sha256 = (s: string) => crypto.createHash('sha256').update(String(s)).digest('hex');
export function rnd(n = 16) {
  const a = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
  return [...crypto.randomBytes(n)].map(x => a[x % a.length]).join('');
}
export const csvq = (v: unknown) => '"' + String(v ?? '').replace(/"/g, '""') + '"';
export const isBot = (ua: string) => /bot|crawl|spider|facebookexternalhit|preview|curl|wget|python|headless|monitor|scan/i.test(ua || '');

/** Personalise follow-up / welcome templates. */
export const fillName = (tpl: string, lead?: { name?: string | null; tg_name?: string | null }) => {
  const n = (lead?.name || lead?.tg_name || '').trim();
  return String(tpl || '').replace(/\{name\}/g, n ? n.split(/\s+/)[0] : 'there');
};

export function dayRange(range: string | null, s: Settings): [number, number] {
  const off = num(s.tz_offset_min, 330) * 60000, t = now();
  const start = Math.floor((t + off) / 86400000) * 86400000 - off;
  // v135: a chosen day ("d:2026-11-20") or days ("d:2026-11-01:2026-11-20"), in the business time zone
  const m = String(range || '').match(/^d:(\d{4}-\d{2}-\d{2})(?::(\d{4}-\d{2}-\d{2}))?$/);
  if (m) {
    const day = (d: string) => Date.parse(d + 'T00:00:00Z') - off;
    const real = (d: string) => { const x = Date.parse(d + 'T00:00:00Z'); return Number.isFinite(x) && new Date(x).toISOString().slice(0, 10) === d; }; // 2026-02-31 → not a date
    let a = day(m[1]), b = day(m[2] || m[1]);
    if (b < a) [a, b] = [b, a];
    if (real(m[1]) && (!m[2] || real(m[2]))) return [a, Math.min(b + 86400000, t + 1)];
  }
  switch (range) {
    case 'yesterday': return [start - 86400000, start];
    case '7d': return [start - 6 * 86400000, t + 1];
    case '30d': return [start - 29 * 86400000, t + 1];
    case 'all': return [0, t + 1];
    case 'month': case 'lastmonth': { // v159: this / last calendar month (business time zone)
      const d = new Date(t + off);
      const m0 = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1) - off;
      if (range === 'month') return [m0, t + 1];
      return [Date.UTC(d.getUTCFullYear(), d.getUTCMonth() - 1, 1) - off, m0];
    }
    default: return [start, t + 1];
  }
}
export const localDate = (ms: number, s: Settings) => new Date(ms + num(s.tz_offset_min) * 60000).toISOString().slice(0, 10);

/** Indian-first phone cleanup: "98765 43210" / "09876543210" / "919876543210" → "+919876543210". Returns '' if invalid. */
export function cleanPhone(raw: unknown, cc = '91') {
  const s = String(raw ?? '').trim();
  let d = s.replace(/\D/g, '');
  if (d.startsWith('00')) d = d.slice(2);
  if (d.length === 11 && d.startsWith('0')) d = d.slice(1);
  if (d.length === 10) d = cc + d;
  if (cc === '91' && d.startsWith('91') && d.length === 12) return /^[6-9]/.test(d.slice(2)) ? '+' + d : '';
  return d.length >= 11 && d.length <= 15 && (s.startsWith('+') || s.startsWith('00')) ? '+' + d : '';
}

export class HttpError extends Error { constructor(public status: number, msg: string, public data?: Record<string, unknown>) { super(msg); } }
/** Telegram refused a voice note: the customer turned off voice messages in their privacy settings (Premium) */
export const voiceBlocked = (desc?: string | null) => /VOICE_MESSAGES_FORBIDDEN/i.test(String(desc || ''));

/** v135: time between two moments that falls inside the working hours (Settings → work_hours "9-22", business time zone; "22-6" = overnight;
 *  empty / invalid = all hours). Used for reply times, so a message at 1 am answered at 9:10 am counts 10 minutes, not 8 hours. */
export function workMs(a: number, b: number, s: { work_hours?: string; tz_offset_min?: string }) {
  if (!(b > a)) return 0;
  const m = String(s.work_hours || '').match(/^\s*(\d{1,2})\s*-\s*(\d{1,2})\s*$/);
  if (!m) return b - a;
  const h1 = Math.min(24, +m[1]), h2 = Math.min(24, +m[2]);
  if (h1 === h2) return b - a;
  const off = num(s.tz_offset_min, 330) * 60000, H = 3600000, D = 86400000;
  let total = 0;
  for (let day = Math.floor((a + off) / D) * D - off - D; day < b; day += D) { // local midnights (one day back for overnight windows)
    const wins: [number, number][] = h1 < h2 ? [[day + h1 * H, day + h2 * H]] : [[day + h1 * H, day + D + h2 * H]];
    for (const [x, y] of wins) total += Math.max(0, Math.min(b, y) - Math.max(a, x));
  }
  return total;
}
/** Average working-hours reply time (ms) for rows of { start, reply }; start = when the chat reached the agent. */
export function avgReplyMs(rows: { started_at: number | null; assigned_at?: number | null; first_reply_at: number | null }[], s: { work_hours?: string; tz_offset_min?: string }) {
  const v = rows.filter(r => r.started_at && r.first_reply_at).map(r => {
    const st = r.assigned_at && r.assigned_at > (r.started_at || 0) && r.assigned_at <= r.first_reply_at! ? r.assigned_at : r.started_at!;
    return workMs(st, r.first_reply_at!, s);
  });
  return v.length ? v.reduce((x, y) => x + y, 0) / v.length : null;
}
