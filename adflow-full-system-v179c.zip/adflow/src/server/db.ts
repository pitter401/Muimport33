import Database from 'better-sqlite3';
import fs from 'fs';
import path from 'path';
import { ensureReelTables } from './reel';
import { mig168 } from './mig168'; // v168: one WhatsApp id = one row

const SCHEMA = `
CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS agents(
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, username TEXT UNIQUE NOT NULL, pass_hash TEXT NOT NULL,
  session_ver INTEGER DEFAULT 1, tg_chat_id TEXT, comm_per_sale REAL DEFAULT 2, receive INTEGER DEFAULT 1,
  online INTEGER DEFAULT 1, deleted INTEGER DEFAULT 0, last_seen INTEGER, created_at INTEGER);
CREATE TABLE IF NOT EXISTS leads(
  id INTEGER PRIMARY KEY AUTOINCREMENT, token TEXT UNIQUE, source TEXT, theme TEXT, name TEXT, phone TEXT, email TEXT,
  service TEXT, has_bm TEXT, niche TEXT, budget TEXT, ip TEXT, ua TEXT, fbc TEXT, fbp TEXT, fbclid TEXT, page_url TEXT, vid TEXT,
  created_at INTEGER, tg_chat_id TEXT, tg_username TEXT, tg_name TEXT, biz_conn TEXT, started_at INTEGER, agent_id INTEGER,
  assigned_at INTEGER, status TEXT DEFAULT 'new', last_in_at INTEGER, last_out_at INTEGER, first_reply_at INTEGER,
  agent_read_at INTEGER DEFAULT 0, admin_read_at INTEGER DEFAULT 0, fu_stage INTEGER DEFAULT 0, fu_due INTEGER DEFAULT 0,
  sold_at INTEGER, last_text TEXT, last_at INTEGER);
CREATE INDEX IF NOT EXISTS i_leads_agent ON leads(agent_id, last_at);
CREATE INDEX IF NOT EXISTS i_leads_chat ON leads(tg_chat_id);
CREATE INDEX IF NOT EXISTS i_leads_created ON leads(created_at);
CREATE TABLE IF NOT EXISTS messages(
  id INTEGER PRIMARY KEY AUTOINCREMENT, lead_id INTEGER, dir TEXT, sender TEXT, agent_id INTEGER, text TEXT,
  file_id TEXT, file_type TEXT, file_name TEXT, created_at INTEGER);
CREATE INDEX IF NOT EXISTS i_msg_lead ON messages(lead_id, id);
CREATE TABLE IF NOT EXISTS sales(id INTEGER PRIMARY KEY AUTOINCREMENT, lead_id INTEGER, agent_id INTEGER, service TEXT, qty INTEGER, amount REAL, commission REAL, created_at INTEGER);
CREATE TABLE IF NOT EXISTS topups(id INTEGER PRIMARY KEY AUTOINCREMENT, lead_id INTEGER, agent_id INTEGER, amount REAL, commission REAL, note TEXT, created_at INTEGER);
CREATE TABLE IF NOT EXISTS payouts(id INTEGER PRIMARY KEY AUTOINCREMENT, agent_id INTEGER, amount REAL, method TEXT, details TEXT, status TEXT DEFAULT 'pending', note TEXT, created_at INTEGER, done_at INTEGER);
CREATE TABLE IF NOT EXISTS spend(date TEXT PRIMARY KEY, amount REAL, note TEXT);
CREATE TABLE IF NOT EXISTS capi_log(event_id TEXT PRIMARY KEY, event_name TEXT, lead_id INTEGER, status TEXT, response TEXT, payload TEXT, tries INTEGER DEFAULT 0, created_at INTEGER);
CREATE INDEX IF NOT EXISTS i_capi_created ON capi_log(created_at);
CREATE TABLE IF NOT EXISTS relay(agent_chat TEXT, msg_id INTEGER, lead_id INTEGER, PRIMARY KEY(agent_chat, msg_id));
CREATE TABLE IF NOT EXISTS push_tokens(token TEXT PRIMARY KEY, role TEXT, user_id INTEGER, platform TEXT, updated_at INTEGER);
CREATE TABLE IF NOT EXISTS sound_saves(k TEXT PRIMARY KEY, role TEXT, user_id INTEGER, device TEXT, ver TEXT, ok INTEGER, error TEXT, at INTEGER);
CREATE TABLE IF NOT EXISTS msg_deletes(id INTEGER PRIMARY KEY AUTOINCREMENT, msg_id INTEGER, lead_id INTEGER, by_role TEXT, by_id INTEGER, by_name TEXT, mode TEXT, text TEXT, at INTEGER);
CREATE TABLE IF NOT EXISTS btn_taps(lead_id INTEGER, k TEXT, at INTEGER, PRIMARY KEY(lead_id, k)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS tg_file_cache(url TEXT PRIMARY KEY, file_id TEXT, at INTEGER);
CREATE TABLE IF NOT EXISTS bot_taps(id INTEGER PRIMARY KEY AUTOINCREMENT, tg_user TEXT, line TEXT, button TEXT, at INTEGER);
CREATE INDEX IF NOT EXISTS bot_taps_user ON bot_taps(tg_user, line, button, at);
CREATE INDEX IF NOT EXISTS bot_taps_at ON bot_taps(at);
CREATE TABLE IF NOT EXISTS sale_splits(id INTEGER PRIMARY KEY AUTOINCREMENT, sale_id INTEGER, agent_id INTEGER, share REAL, reason TEXT, at INTEGER);
CREATE INDEX IF NOT EXISTS i_sale_splits ON sale_splits(sale_id);
CREATE INDEX IF NOT EXISTS i_sale_splits_agent ON sale_splits(agent_id);
CREATE TABLE IF NOT EXISTS agent_log(id INTEGER PRIMARY KEY AUTOINCREMENT, agent_id INTEGER, kind TEXT, text TEXT, lead_id INTEGER, at INTEGER);
CREATE INDEX IF NOT EXISTS i_agent_log ON agent_log(agent_id, at);
CREATE TABLE IF NOT EXISTS push_tests(k TEXT PRIMARY KEY, role TEXT, user_id INTEGER, at INTEGER);
CREATE TABLE IF NOT EXISTS push_debug(id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT, user_id INTEGER, stage TEXT, error TEXT, platform TEXT, perm TEXT, version TEXT, device TEXT, at INTEGER);
CREATE TABLE IF NOT EXISTS push_reports(k TEXT PRIMARY KEY, role TEXT, user_id INTEGER, device TEXT, at INTEGER, kind TEXT, played TEXT, reason TEXT, data TEXT);
CREATE TABLE IF NOT EXISTS visits(vid TEXT PRIMARY KEY, theme TEXT, created_at INTEGER);
CREATE TABLE IF NOT EXISTS ub_outbox(id INTEGER PRIMARY KEY AUTOINCREMENT, lead_id INTEGER, text TEXT, agent_id INTEGER, sender TEXT, status TEXT, error TEXT, created_at INTEGER);
CREATE TABLE IF NOT EXISTS echo_skip(chat_id TEXT, text TEXT, created_at INTEGER);
CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT UNIQUE, name TEXT, phone TEXT, session_ver INTEGER DEFAULT 1, created_at INTEGER, last_login INTEGER);
CREATE TABLE IF NOT EXISTS otp_codes(email TEXT PRIMARY KEY, code_hash TEXT, expires INTEGER, tries INTEGER DEFAULT 0, sent_at INTEGER, sends INTEGER DEFAULT 0, window_start INTEGER);
CREATE TABLE IF NOT EXISTS web_orders(id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE, customer_id INTEGER, kind TEXT, qty INTEGER, bm_id TEXT, unit_price REAL, amount REAL,
  status TEXT, pay_method TEXT, np_invoice_id TEXT, np_payment_id TEXT, np_status TEXT, pay_currency TEXT, inr_amount REAL, utr TEXT, paid_at INTEGER, delivered_at INTEGER,
  accounts TEXT, note TEXT, ip TEXT, ua TEXT, fbc TEXT, fbp TEXT, page_url TEXT, created_at INTEGER);
CREATE INDEX IF NOT EXISTS i_worders_cust ON web_orders(customer_id, id);
CREATE TABLE IF NOT EXISTS web_accounts(id INTEGER PRIMARY KEY AUTOINCREMENT, customer_id INTEGER, order_id INTEGER, act_id TEXT, created_at INTEGER);
CREATE INDEX IF NOT EXISTS i_waccts_cust ON web_accounts(customer_id);
CREATE TABLE IF NOT EXISTS web_topups(id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE, customer_id INTEGER, account_id INTEGER, act_id TEXT, amount REAL, fee REAL, total REAL,
  status TEXT, pay_method TEXT, np_invoice_id TEXT, np_payment_id TEXT, np_status TEXT, pay_currency TEXT, inr_amount REAL, utr TEXT, paid_at INTEGER, done_at INTEGER, note TEXT, created_at INTEGER);
CREATE INDEX IF NOT EXISTS i_wtopups_cust ON web_topups(customer_id, id);
CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT, source TEXT, lead_id INTEGER, order_id INTEGER, topup_id INTEGER, agent_id INTEGER,
  bm_id TEXT, act_id TEXT, qty INTEGER, amount REAL, note TEXT, status TEXT DEFAULT 'open', result TEXT, created_at INTEGER, done_at INTEGER, done_by TEXT);
CREATE INDEX IF NOT EXISTS i_tasks_status ON tasks(status, id);
CREATE TABLE IF NOT EXISTS ub_phone_jobs(id INTEGER PRIMARY KEY AUTOINCREMENT, phone TEXT, name TEXT, text TEXT, status TEXT DEFAULT 'queued', error TEXT, created_at INTEGER);
CREATE TABLE IF NOT EXISTS lead_accounts(id INTEGER PRIMARY KEY AUTOINCREMENT, lead_id INTEGER, act_id TEXT, bm_id TEXT, task_id INTEGER, source TEXT, created_at INTEGER, UNIQUE(lead_id, act_id));
CREATE TABLE IF NOT EXISTS pay_links(id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE, lead_id INTEGER, agent_id INTEGER, kind TEXT, qty INTEGER, bm_id TEXT, act_id TEXT,
  amount REAL, fee REAL, total REAL, label TEXT, status TEXT DEFAULT 'new', np_payment_id TEXT, np_status TEXT, pay_currency TEXT, pay_address TEXT, pay_amount REAL, pay_extra TEXT,
  np_expires INTEGER, np_checked INTEGER, paid_at INTEGER, created_at INTEGER);
CREATE INDEX IF NOT EXISTS i_paylinks_lead ON pay_links(lead_id, id);
CREATE TABLE IF NOT EXISTS agent_active(agent_id INTEGER, minute INTEGER, PRIMARY KEY(agent_id, minute)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS pay_parts(np_id TEXT, link_id INTEGER, usd REAL, coin TEXT, st TEXT, at INTEGER, PRIMARY KEY(np_id, link_id));
CREATE TABLE IF NOT EXISTS meta_bms(id INTEGER PRIMARY KEY AUTOINCREMENT, bm_id TEXT UNIQUE, name TEXT, label TEXT, token_enc TEXT, secret_enc TEXT, proxy_enc TEXT,
  su_id TEXT, su_name TEXT, verification TEXT, created_time INTEGER, acct_limit INTEGER, status TEXT DEFAULT 'ok', error TEXT, error_at INTEGER, alerted INTEGER DEFAULT 0,
  synced_at INTEGER, deleted INTEGER DEFAULT 0, created_at INTEGER);
CREATE TABLE IF NOT EXISTS meta_accounts(act_id TEXT PRIMARY KEY, bm_id TEXT, no INTEGER, name TEXT, status INTEGER, disable_reason INTEGER, currency TEXT, tz TEXT,
  created_time INTEGER, spent INTEGER DEFAULT 0, cap INTEGER DEFAULT 0, today REAL DEFAULT 0, card TEXT, state TEXT DEFAULT 'free', lead_id INTEGER, share_mode TEXT,
  client_bm TEXT, client_email TEXT, invite_id TEXT, buser_id TEXT, assigned_at INTEGER, disabled_at INTEGER, low_sent INTEGER DEFAULT 0, busy INTEGER DEFAULT 0,
  step TEXT, err TEXT, synced_at INTEGER, seen_at INTEGER);
CREATE INDEX IF NOT EXISTS i_macct_lead ON meta_accounts(lead_id);
CREATE TABLE IF NOT EXISTS meta_credits(id INTEGER PRIMARY KEY AUTOINCREMENT, lead_id INTEGER, amount REAL, act_id TEXT, reason TEXT, status TEXT DEFAULT 'open', used_act TEXT, created_at INTEGER, used_at INTEGER);
CREATE TABLE IF NOT EXISTS meta_log(id INTEGER PRIMARY KEY AUTOINCREMENT, act_id TEXT, lead_id INTEGER, agent_id INTEGER, kind TEXT, paid REAL, fee REAL, amount REAL, note TEXT, by TEXT, created_at INTEGER);
CREATE INDEX IF NOT EXISTS i_mlog_time ON meta_log(created_at);
CREATE TABLE IF NOT EXISTS meta_requests(id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT, lead_id INTEGER, agent_id INTEGER, act_id TEXT, tier TEXT, mode TEXT, client_bm TEXT, client_email TEXT,
  paid REAL, fee REAL, amount REAL, method TEXT, pay_code TEXT, note TEXT, status TEXT DEFAULT 'pending', error TEXT, created_at INTEGER, done_at INTEGER, done_by TEXT);
CREATE INDEX IF NOT EXISTS i_mreq_status ON meta_requests(status, id);
CREATE TABLE IF NOT EXISTS meta_cards(card TEXT PRIMARY KEY, balance REAL, bal_at INTEGER, used_since INTEGER DEFAULT 0, note TEXT);
CREATE TABLE IF NOT EXISTS ad_spend(date TEXT, line TEXT, amount REAL, note TEXT, auto INTEGER DEFAULT 0, PRIMARY KEY(date, line));
CREATE TABLE IF NOT EXISTS channel_joins(id INTEGER PRIMARY KEY AUTOINCREMENT, vid TEXT, line TEXT, ip TEXT, ua TEXT, fbc TEXT, fbp TEXT, page_url TEXT, link TEXT, tg_user TEXT, requested_at INTEGER, created_at INTEGER);
CREATE TABLE IF NOT EXISTS bot_subs(tg_user TEXT PRIMARY KEY, name TEXT, src TEXT, cj_id INTEGER, started_at INTEGER, last_at INTEGER);
CREATE INDEX IF NOT EXISTS channel_joins_vid ON channel_joins(vid, line);
CREATE TABLE IF NOT EXISTS tg_seen(update_id INTEGER PRIMARY KEY, at INTEGER);
CREATE TABLE IF NOT EXISTS ai_examples(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, biz TEXT, chat TEXT, source TEXT, on_ INTEGER DEFAULT 1, created_at INTEGER);
CREATE TABLE IF NOT EXISTS ai_cases(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, biz TEXT, turns TEXT, expect TEXT, facts TEXT, out TEXT, verdict TEXT, reason TEXT, mark TEXT, fix TEXT, run_at INTEGER, created_at INTEGER);
CREATE TABLE IF NOT EXISTS ai_usage(day TEXT, kind TEXT, calls INTEGER, tin INTEGER, tout INTEGER, cost REAL, PRIMARY KEY(day, kind));
CREATE TABLE IF NOT EXISTS ai_coach(lead_id INTEGER PRIMARY KEY, last_msg INTEGER, data TEXT, at INTEGER);
CREATE TABLE IF NOT EXISTS ai_feedback(id INTEGER PRIMARY KEY AUTOINCREMENT, lead_id INTEGER, agent_id INTEGER, suggested TEXT, sent TEXT, used INTEGER DEFAULT 0, created_at INTEGER);
CREATE TABLE IF NOT EXISTS ai_proofs(id INTEGER PRIMARY KEY AUTOINCREMENT, biz TEXT, kind TEXT, lead_id INTEGER, file TEXT, status TEXT, created_at INTEGER);
CREATE TABLE IF NOT EXISTS page_visits(vid TEXT, page TEXT, created_at INTEGER, PRIMARY KEY(vid, page));
CREATE INDEX IF NOT EXISTS page_visits_at ON page_visits(created_at);
CREATE TABLE IF NOT EXISTS delayed_msgs(id INTEGER PRIMARY KEY AUTOINCREMENT, lead_id INTEGER, text TEXT, due_at INTEGER, status TEXT DEFAULT 'queued', created_at INTEGER);
-- v143: sending speed for automatic messages (one line per channel: tga = Telegram chat account, tgb = bot, wa = WhatsApp)
CREATE TABLE IF NOT EXISTS pace_q(key TEXT PRIMARY KEY, ch TEXT, kind TEXT, prio INTEGER, lead_id INTEGER, since INTEGER, seen INTEGER);
CREATE INDEX IF NOT EXISTS i_pace_q ON pace_q(ch, prio, since);
CREATE TABLE IF NOT EXISTS pace_log(id INTEGER PRIMARY KEY AUTOINCREMENT, ch TEXT, kind TEXT, key TEXT, lead_id INTEGER, at INTEGER);
CREATE INDEX IF NOT EXISTS i_pace_log ON pace_log(ch, at);
CREATE TABLE IF NOT EXISTS app_seen(role TEXT, user_id INTEGER, at INTEGER, app_version TEXT, build TEXT, platform TEXT, native INTEGER, plugin INTEGER, ua TEXT, PRIMARY KEY(role, user_id));
CREATE TABLE IF NOT EXISTS pace_ch(ch TEXT PRIMARY KEY, next_at INTEGER, wait_until INTEGER, why TEXT, at INTEGER);
`;

// Columns added after the first release (safe to run on every start)
const ADD_COLUMNS: [string, string, string][] = [
  ['leads', 'fu_q', 'INTEGER'], // v143: an automatic follow-up waiting in the send queue (since when)
  ['agents', 'ring_off', 'INTEGER DEFAULT 0'], // v140: the admin turned "ring on silent / vibrate" off for this person
  // v141: a new chat stays hidden from its agent (and its alert is held) until the welcome text + welcome voice are done
  ['leads', 'hold_alert', 'TEXT'], ['leads', 'hold_since', 'INTEGER'], ['leads', 'hold_until', 'INTEGER'], ['leads', 'released_at', 'INTEGER'],
  // v141: temporary cover for an existing customer while the owner agent is off / did not answer in time (owner = agent_id never changes)
  ['leads', 'cover_agent_id', 'INTEGER'], ['leads', 'cover_since', 'INTEGER'], ['leads', 'cover_reason', 'TEXT'], ['leads', 'last_cover_id', 'INTEGER'], ['leads', 'last_cover_from', 'INTEGER'], ['leads', 'cover_split_used', 'INTEGER'],
  // v141: misses in a row (chats moved away by the no-reply rule) → auto-off after 3; when it happened (banner in the agent app)
  ['agents', 'comm_funnel', 'REAL'], // v141: funnel commission per sale (per month sold); NULL / 0 = none
  ['agents', 'miss_n', 'INTEGER DEFAULT 0'], ['agents', 'auto_off_at', 'INTEGER'],
  // v141: a sale / top-up made while a cover agent had the chat goes to the cover (agent_id); the chat's owner is kept here
  // v144: special price per account (list_price = the normal price per unit; discount = (list − sold) × qty); pay_links.ptier = product tier (premium / agency)
  ['sales', 'list_price', 'REAL'], ['sales', 'discount', 'REAL'], ['pay_links', 'list_price', 'REAL'], ['pay_links', 'ptier', 'TEXT'], ['pay_links', 'parts', 'TEXT'], ['pay_links', 'parent_id', 'INTEGER'],
  ['sales', 'owner_agent_id', 'INTEGER'], ['topups', 'owner_agent_id', 'INTEGER'], ['topups', 'meta_log_id', 'INTEGER'], ['meta_accounts', 'card_set', 'TEXT'], ['meta_accounts', 'card_guess', 'INTEGER DEFAULT 0'], ['meta_accounts', 'pay_due', 'INTEGER'], ['meta_accounts', 'pay_fail_at', 'INTEGER'], ['sales', 'closed_by', 'INTEGER'], ['topups', 'closed_by', 'INTEGER'],
  // v141: cash / offline payouts recorded by the manager or admin (status 'paid', kind 'cash'; amount = USD, orig_amount + cur as typed)
  ['payouts', 'kind', 'TEXT'], ['payouts', 'cur', 'TEXT'], ['payouts', 'orig_amount', 'REAL'], ['payouts', 'by_name', 'TEXT'], ['payouts', 'by_role', 'TEXT'], ['payouts', 'by_id', 'INTEGER'], ['payouts', 'pay_date', 'INTEGER'],
  ['leads', 'contact_state', 'TEXT'], ['leads', 'contact_at', 'INTEGER'], ['leads', 'contact_err', 'TEXT'], ['leads', 'tg_access_hash', 'TEXT'],
  ['agents', 'role', "TEXT DEFAULT 'agent'"], ['leads', 'remind_at', 'INTEGER'], ['leads', 'remind_note', 'TEXT'], ['leads', 'remind_due', 'INTEGER DEFAULT 0'], ['leads', 'remind_by', 'TEXT'], ['ub_phone_jobs', 'lead_json', 'TEXT'], ['leads', 'tg_muted', 'INTEGER'], ['web_orders', 'name', 'TEXT'], ['web_orders', 'phone', 'TEXT'], ['leads', 'tried_agents', 'TEXT'], ['web_orders', 'pay_address', 'TEXT'], ['web_orders', 'pay_amount', 'REAL'], ['web_orders', 'pay_extra', 'TEXT'], ['web_orders', 'np_expires', 'INTEGER'], ['web_orders', 'np_checked', 'INTEGER'], ['web_topups', 'pay_address', 'TEXT'], ['web_topups', 'pay_amount', 'REAL'], ['web_topups', 'pay_extra', 'TEXT'], ['web_topups', 'np_expires', 'INTEGER'], ['web_topups', 'np_checked', 'INTEGER'], ['leads', 'tg_contact', 'TEXT'], ['ub_phone_jobs', 'due_at', 'INTEGER'], ['delayed_msgs', 'notify', 'TEXT'], ['web_orders', 'lead_id', 'INTEGER'], ['leads', 'ask_sent', 'INTEGER'], ['leads', 'dead_at', 'INTEGER'], ['leads', 'dead_reason', 'TEXT'], ['leads', 'auto_stop', 'TEXT'], ['leads', 'revive_stage', 'INTEGER DEFAULT 0'], ['leads', 'revive_at', 'INTEGER'],
  // Agency vs Funnel: line = which landing page the person came from (decides the Meta pixel);
  // biz = which business the chat is about (decides routing, bot messages, contact names)
  ['leads', 'line', "TEXT DEFAULT 'agency'"], ['leads', 'biz', "TEXT GENERATED ALWAYS AS (CASE WHEN service='funnel' OR (service='chat' AND line='funnel') THEN 'funnel' ELSE 'agency' END) VIRTUAL"],
  ['leads', 'biz_no', 'INTEGER'],
  ['meta_accounts', 'locked', 'INTEGER DEFAULT 0'], ['agents', 'auto_acct', 'INTEGER DEFAULT 0'], ['agents', 'auto_topup', 'INTEGER DEFAULT 0'], ['pay_links', 'tier', 'TEXT'], ['pay_links', 'share_mode', 'TEXT'], ['pay_links', 'client_email', 'TEXT'], ['capi_log', 'line', 'TEXT'], ['channel_joins', 'src', 'TEXT'], ['messages', 'tg_msg_id', 'INTEGER'], ['messages', 'transcript', 'TEXT'], ['leads', 'ai_state', 'TEXT'], ['leads', 'ai_done_msg', 'INTEGER'], ['messages', 'read_at', 'INTEGER'], ['messages', 'reply_to', 'INTEGER'], ['leads', 'call_agent_id', 'INTEGER'], ['leads', 'call_state', 'TEXT'], ['leads', 'call_at', 'INTEGER'], ['leads', 'call_by', 'TEXT'], ['leads', 'call_note', 'TEXT'], ['agents', 'lines', "TEXT DEFAULT 'agency'"], ['sales', 'cost', 'REAL'], ['leads', 'tier', 'TEXT'], ['agents', 'comm_premium', 'REAL'], ['web_orders', 'tier', 'TEXT'], ['leads', 'offer_until', 'INTEGER'], ['web_orders', 'offer', 'TEXT'], ['topups', 'offer_free', 'REAL'], ['pay_links', 'offer_free', 'REAL'], ['web_topups', 'offer_free', 'REAL'], ['sales', 'offer', 'INTEGER'], ['leads', 'ai_replies', 'INTEGER DEFAULT 0'], ['leads', 'voice_off', 'INTEGER DEFAULT 0'], ['web_orders', 'full', 'INTEGER DEFAULT 0'], ['leads', 'seen_state', 'TEXT'], ['leads', 'seen_at', 'INTEGER'], ['pay_links', 'full', 'INTEGER DEFAULT 0'], ['pay_links', 'wa', 'INTEGER'], ['pay_links', 'item', 'TEXT'], ['pay_links', 'cust_name', 'TEXT'], ['pay_links', 'cust_phone', 'TEXT'], ['pay_links', 'wa_topup', 'REAL'], ['pay_links', 'wa_items', 'TEXT'], ['pay_links', 'wa_disc', 'REAL'], ['topups', 'wa', 'INTEGER'],
  // v109: WhatsApp sales (no lead, no Meta event) written down by the admin / manager
  // v111: channel ads (join → bot DM → bot chat lead), bot subscribers, website orders from the channel
  ['channel_joins', 'tok', 'TEXT'], ['channel_joins', 'line_x', 'TEXT'], ['channel_joins', 'dm_at', 'INTEGER'], ['channel_joins', 'dm_err', 'TEXT'], ['web_orders', 'src', 'TEXT'], ['web_orders', 'cj_id', 'INTEGER'],
  // v113: who stays in the channel → Subscribe only after the stay time
  ['channel_joins', 'joined_at', 'INTEGER'], ['channel_joins', 'left_at', 'INTEGER'], ['channel_joins', 'sub_due', 'INTEGER'], ['channel_joins', 'sub_at', 'INTEGER'], ['channel_joins', 'sub_state', 'TEXT'],
  ['sales', 'wa', 'INTEGER DEFAULT 0'], ['sales', 'item', 'TEXT'], ['sales', 'line', 'TEXT'], ['sales', 'tier', 'TEXT'], ['sales', 'cust_name', 'TEXT'], ['sales', 'cust_phone', 'TEXT'], ['sales', 'note', 'TEXT'], ['sales', 'by_name', 'TEXT'],
  // v130: which Meta campaign / ad set / ad brought the visitor, the channel join and the chat ('' = looked, untagged)
  ['visits', 'camp', 'TEXT'], ['visits', 'adset', 'TEXT'], ['visits', 'ad', 'TEXT'], ['visits', 'camp_at', 'INTEGER'],
  ['leads', 'camp', 'TEXT'], ['leads', 'adset', 'TEXT'], ['leads', 'ad', 'TEXT'], ['leads', 'camp_chk', 'INTEGER'], ['leads', 'camp_kind', 'TEXT'], // v142: WhatsApp: page / community / ctwa / direct / unknown
  ['channel_joins', 'camp', 'TEXT'], ['channel_joins', 'adset', 'TEXT'], ['channel_joins', 'ad', 'TEXT'], ['channel_joins', 'camp_chk', 'INTEGER'],
  // v131: WhatsApp chats (WATI): ch='wa' + tg_chat_id 'wa:<number>'; which agents may get WhatsApp / Telegram chats
  ['leads', 'ch', 'TEXT'], ['leads', 'menu', 'INTEGER'], ['messages', 'delivered_at', 'INTEGER'], ['messages', 'wa_id2', 'TEXT'], ['messages', 'wa_echo', 'INTEGER'], ['messages', 'wa_failed', 'INTEGER'], ['pay_links', 'paid_usd', 'REAL'], ['sales', 'full', 'INTEGER'], ['sales', 'pay_link_id', 'INTEGER'], ['leads', 'fu_ever', 'INTEGER DEFAULT 0'], ['leads', 'del_req_by', 'TEXT'], ['leads', 'del_req_at', 'INTEGER'], ['leads', 'del_req_note', 'TEXT'], ['pay_links', 'short_at', 'INTEGER'], ['pay_links', 'ok_by', 'TEXT'], ['leads', 'wa_ad', 'TEXT'], ['leads', 'wa_lead_at', 'INTEGER'], ['agents', 'chans', "TEXT DEFAULT 'tg'"], ['messages', 'wa_id', 'TEXT'],
  // v137: WATI Pro sync (last chat status / contact attributes we sent)
  // v137: delete a sent message (deleted_at / by; ub = sent by the chat account; ub_outbox jobs can be deletes)
  ['capi_log', 'source', 'TEXT'], // v137: which page / chat sent the event
  ['messages', 'deleted_at', 'INTEGER'], ['messages', 'deleted_by', 'TEXT'], ['messages', 'via', 'TEXT'], ['ub_outbox', 'kind', 'TEXT'], ['ub_outbox', 'tg_id', 'INTEGER'],
  ['messages', 'dur', 'REAL'],
  // v139: which app / phone registered a push token, and how (js = Capacitor event or the app's fcmToken call, native = Java)
  ['push_tokens', 'app_version', 'TEXT'], ['push_tokens', 'device', 'TEXT'], ['push_tokens', 'via', 'TEXT'], ['push_tokens', 'created_at', 'INTEGER'], // v139: voice / audio length in seconds (shown in the chat instead of 0:00)
  ['leads', 'wa_tstatus', 'TEXT'], ['leads', 'wa_tstatus_at', 'INTEGER'], ['leads', 'wa_attrs', 'TEXT'], ['leads', 'wa_attrs_err_at', 'INTEGER'],
];

/** v139: an inbound row with nothing to show — empty / whitespace text, no media, no special kind (taps keep via='tap';
 *  location / contacts / button / interactive are saved with their text). Hidden in the chat + AI context, removed once. */
export const EMPTY_IN_SQL = "dir='in' AND TRIM(COALESCE(text,''), ' '||char(9)||char(10)||char(13)) = '' AND file_id IS NULL AND file_type IS NULL AND COALESCE(via,'')=''";
/** …the same for a query with the messages table under an alias (e.g. 'm'). */
export const emptyInSql = (a: string) => EMPTY_IN_SQL.replace(/\b(dir|text|file_id|file_type|via)\b/g, a + '.$1');

/** v141: Commission an agent earned (sales), split sales counted by their share (sale_splits). `where` filters the sales (alias x). */
export const commSql = (agent: string, where = '1=1') => `((SELECT COALESCE(SUM(CASE WHEN EXISTS(SELECT 1 FROM sale_splits p WHERE p.sale_id=x.id) THEN 0 ELSE x.commission END),0) FROM sales x WHERE x.agent_id=${agent} AND ${where})
  + (SELECT COALESCE(SUM(p.share),0) FROM sale_splits p JOIN sales x ON x.id=p.sale_id WHERE p.agent_id=${agent} AND ${where}))`;

type G = typeof globalThis & { __adflowDb?: Database.Database };

export function db(): Database.Database {
  const g = globalThis as G;
  if (g.__adflowDb) return g.__adflowDb;
  const file = process.env.DB_PATH || path.join(process.cwd(), 'data', 'adflow.db');
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const d = new Database(file);
  d.pragma('journal_mode = WAL');
  d.pragma('busy_timeout = 5000');
  d.pragma('synchronous = NORMAL');
  d.exec(SCHEMA);
  for (const [t, c, type] of ADD_COLUMNS) {
    const cols = d.prepare(`PRAGMA table_xinfo(${t})`).all() as { name: string }[];
    if (!cols.some(x => x.name === c)) { try { d.exec(`ALTER TABLE ${t} ADD COLUMN ${c} ${type}`); } catch { /* added by the other process */ } }
  }
  // v135 one-time fixes (each runs once per database)
  d.exec('CREATE TABLE IF NOT EXISTS migs(k TEXT PRIMARY KEY, at INTEGER)');
  const once = (k: string, sql: string[]) => {
    if (d.prepare('SELECT 1 FROM migs WHERE k=?').get(k)) return;
    try { d.transaction(() => { for (const q of sql) d.exec(q); d.prepare('INSERT OR IGNORE INTO migs(k, at) VALUES(?,?)').run(k, Date.now()); })(); } catch (e) { console.warn('[db] mig', k, (e as Error).message); }
  };
  // reply time: a reply from the admin app or the owner's own phone counts too (before only the agent app did)
  // v137: WATI automation rule texts imported as "Owner (phone)" → system notes (out of the chat bubbles and the AI context)
  once('v137_vendor_auto', ["UPDATE messages SET dir='sys', sender='system', text='WATI automation rule message was sent to the customer (not shown). Turn it off in WATI → Automation.' WHERE dir='out' AND sender='owner' AND (text LIKE '%triggered an automation rule%' OR text LIKE '%wati.io/rules%')"]);
  // v139: old empty customer bubbles (WhatsApp, no text, no media, not a button tap) → removed
  once('v139_empty_in', [`DELETE FROM messages WHERE ${EMPTY_IN_SQL}`,
    // a chat whose preview was that empty bubble → the preview of its newest message (by time)
    `UPDATE leads SET last_text=(SELECT CASE WHEN TRIM(COALESCE(m.text,''))!='' THEN substr(m.text, 1, 140) WHEN m.file_type='voice' THEN 'Voice message' WHEN m.file_type='photo' THEN 'Photo' WHEN m.file_type='video' THEN 'Video' WHEN m.file_type IS NOT NULL THEN 'File' ELSE '' END
       FROM messages m WHERE m.lead_id=leads.id AND m.dir!='sys' ORDER BY m.created_at DESC, m.id DESC LIMIT 1)
     WHERE COALESCE(last_text,'')='' AND EXISTS(SELECT 1 FROM messages m WHERE m.lead_id=leads.id AND m.dir!='sys')`]);
  // v138: delivery time always from the settings — saved channel / Premium texts that still have the old default phrase → {delivery}
  once('v138_delivery', [
    "UPDATE settings SET v=replace(v, 'Shared to your Business Manager in 30 minutes', 'Shared to your Business Manager in {delivery}') WHERE k IN ('chan_join_dm_text','chan_dm_agency','chan_dm_premium','chan_dm_funnel') AND v LIKE '%Shared to your Business Manager in 30 minutes%'",
    "UPDATE settings SET v=replace(v, 'Priority delivery within 30 minutes', 'Priority delivery within {delivery}') WHERE k='premium_bullets' AND v LIKE '%Priority delivery within 30 minutes%'",
  ]);
  // v140: WhatsApp welcome buttons still on the old default labels → the new ones (See pricing / What's included / the action, with icons).
  //   Labels the admin changed are left as they are.
  once('v140_btn_labels', [
    "UPDATE settings SET v='💰 See pricing, 📦 What''s included, ✅ Get account' WHERE k='wati_btn_agency' AND lower(replace(v,' ',''))='getaccount,top-up,talktoagent'",
    "UPDATE settings SET v='💰 See pricing, 📦 What''s included, 💎 Buy Premium' WHERE k='wati_btn_premium' AND lower(replace(v,' ',''))='buypremium,what''sincluded,talktoagent'",
    "UPDATE settings SET v='💰 See pricing, 📦 What''s included, 📈 Start my funnel' WHERE k='wati_btn_funnel' AND lower(replace(v,' ',''))='startmyfunnel,seepricing,talktoagent'",
  ]);
  // v153: account names "Adsbhai 3" (not "Adsbhai Ad Account 3") — only if the admin never changed the pattern
  once('v153_msg_verified', ["UPDATE settings SET v=replace(v, 'Shared to your Business Manager ({bm}).' || char(10), 'Shared to your Business Manager ({bm}).' || char(10) || 'Verified business since {verified}' || char(10)) WHERE k='meta_msg_share' AND v NOT LIKE '%{verified}%'"]);
  // v153: BMs marked "API blocked" only because Meta refused the partner-assign call (#3) → OK again
  once('v135_first_reply', ["UPDATE leads SET first_reply_at=(SELECT MIN(m.created_at) FROM messages m WHERE m.lead_id=leads.id AND m.dir='out' AND m.sender IN ('agent','admin','owner') AND m.created_at>=leads.started_at) WHERE started_at IS NOT NULL"]);
  // WhatsApp sales / top-ups added by hand before the adder was saved → the agent with that name (one match only)
  once('v135_wa_owner', [
    "UPDATE sales SET agent_id=(SELECT a.id FROM agents a WHERE a.name=sales.by_name AND a.deleted=0) WHERE COALESCE(wa,0)=1 AND agent_id IS NULL AND by_name IS NOT NULL AND (SELECT COUNT(*) FROM agents a WHERE a.name=sales.by_name AND a.deleted=0)=1",
    "UPDATE topups SET agent_id=(SELECT a.id FROM agents a WHERE topups.note LIKE '% · by ' || a.name AND a.deleted=0) WHERE COALESCE(wa,0)=1 AND agent_id IS NULL AND (SELECT COUNT(*) FROM agents a WHERE topups.note LIKE '% · by ' || a.name AND a.deleted=0)=1",
  ]);
  // channel joins before v59 have no src: the /telegram page vs the landing top bar, from the page they came from
  try { d.exec("UPDATE channel_joins SET src=CASE WHEN vid LIKE 'chat%' THEN 'chat' WHEN page_url LIKE '%/telegram%' THEN 'page' ELSE 'bar' END WHERE src IS NULL"); } catch { /* next start */ }
  // ad spend is now per line (Agency / Funnel): old daily entries move to Agency once
  try { d.exec("INSERT OR IGNORE INTO ad_spend(date, line, amount, note, auto) SELECT date, 'agency', amount, note, 0 FROM spend; DELETE FROM spend;"); } catch { /* next start */ }
  // v107: deleting a chat in our own Telegram app no longer stops automatic messages → undo the old stops of that kind
  //   The follow-up that was due when it stopped never went (stage moved on, fu_due stayed 1) → step back so it goes again.
  try {
    const W = "auto_stop='the chat or messages were deleted'";
    d.transaction(() => {
      d.prepare(`INSERT INTO messages(lead_id, dir, sender, text, created_at) SELECT id, 'sys', 'system', ?, ? FROM leads WHERE ${W}`)
        .run('▶️ Automatic messages are on again (deleting a chat in the Telegram app no longer stops them)', Date.now());
      d.exec(`UPDATE leads SET fu_stage=fu_stage-1, fu_due=0 WHERE ${W} AND status='active' AND fu_due=1 AND fu_stage>0`);
      d.exec(`UPDATE leads SET auto_stop=NULL WHERE ${W}`);
    })();
  } catch { /* next start */ }
  d.exec('CREATE INDEX IF NOT EXISTS i_cj_tok ON channel_joins(tok)');
  d.exec('CREATE INDEX IF NOT EXISTS i_leads_contact ON leads(contact_state, created_at)');
  // Contact numbers per business: "AdsBhai Agency Lead 1", "AdsBhai Funnel Lead 1"
  d.exec(`CREATE TRIGGER IF NOT EXISTS t_lead_bizno AFTER INSERT ON leads BEGIN
    UPDATE leads SET biz_no=(SELECT COALESCE(MAX(biz_no),0)+1 FROM leads WHERE biz=NEW.biz AND id!=NEW.id) WHERE id=NEW.id; END`);
  if (d.prepare('SELECT 1 FROM leads WHERE biz_no IS NULL LIMIT 1').get()) {
    try {
      const rows = d.prepare('SELECT id, biz FROM leads WHERE biz_no IS NULL ORDER BY id').all() as { id: number; biz: string }[];
      const next: Record<string, number> = {};
      for (const b of ['agency', 'funnel']) next[b] = ((d.prepare('SELECT MAX(biz_no) m FROM leads WHERE biz=?').get(b) as { m: number | null }).m || 0);
      const up = d.prepare('UPDATE leads SET biz_no=? WHERE id=?');
      d.transaction(() => { for (const r of rows) up.run(++next[r.biz], r.id); })();
    } catch { /* next start */ }
  }
  // When a chat goes to Dead: remember when (for the 7-day / 15-day messages)
  d.exec(`CREATE TRIGGER IF NOT EXISTS t_lead_dead AFTER UPDATE OF status ON leads WHEN NEW.status='dead' AND OLD.status IS NOT 'dead'
    BEGIN UPDATE leads SET dead_at=CAST((julianday('now')-2440587.5)*86400000 AS INTEGER), revive_stage=0, revive_at=NULL WHERE id=NEW.id; END`);
  // chats that were already Dead before this update: count from now (so nobody gets a burst of messages on update day)
  d.prepare("UPDATE leads SET dead_at=?, revive_stage=0 WHERE status='dead' AND dead_at IS NULL").run(Date.now());
  // one-time: ad accounts the manager already delivered in Telegram chats (saved only as text before)
  if (!d.prepare("SELECT 1 FROM settings WHERE k='_lead_accts_backfill'").get()) {
    try {
      const rows = d.prepare("SELECT id, lead_id, bm_id, result, done_at FROM tasks WHERE kind='account' AND status='done' AND lead_id IS NOT NULL AND order_id IS NULL AND result IS NOT NULL").all() as { id: number; lead_id: number; bm_id: string | null; result: string; done_at: number }[];
      const ins = d.prepare("INSERT OR IGNORE INTO lead_accounts(lead_id, act_id, bm_id, task_id, source, created_at) VALUES(?,?,?,?,'manager',?)");
      for (const r of rows) for (const m of r.result.matchAll(/act_(\d{6,})/g)) ins.run(r.lead_id, m[1], r.bm_id, r.id, r.done_at || Date.now());
      d.prepare("INSERT OR IGNORE INTO settings(k, v) VALUES('_lead_accts_backfill', '1')").run();
    } catch { /* retried next start */ }
  }
  // v116 (one-time): every join request is approved by the bot now (admin can turn it off again in Settings → Telegram channel)
  if (!d.prepare("SELECT 1 FROM settings WHERE k='_auto_approve_v116'").get()) {
    d.prepare("INSERT INTO settings(k, v) VALUES('chan_auto_approve', '1') ON CONFLICT(k) DO UPDATE SET v='1'").run();
    d.prepare("INSERT OR IGNORE INTO settings(k, v) VALUES('_auto_approve_v116', '1')").run();
  }
  d.exec('CREATE TABLE IF NOT EXISTS join_dms(tg_user TEXT PRIMARY KEY, at INTEGER, ok INTEGER, err TEXT)');
  try { d.exec('ALTER TABLE bot_subs ADD COLUMN replied_at INTEGER'); } catch { /* already there */ }
  try { d.exec('ALTER TABLE bot_subs ADD COLUMN bfu_n INTEGER'); } catch { /* already there */ }
  try { d.exec('ALTER TABLE bot_subs ADD COLUMN bfu_at INTEGER'); } catch { /* already there */ }
  try { d.exec('ALTER TABLE delayed_msgs ADD COLUMN wtype TEXT'); } catch { /* already there */ }
  d.exec('CREATE TABLE IF NOT EXISTS bot_log(id INTEGER PRIMARY KEY AUTOINCREMENT, tg_user TEXT, kind TEXT, at INTEGER)'); // v120: bot reminders sent (Home → Bot tab)
  d.exec('CREATE INDEX IF NOT EXISTS i_bot_log ON bot_log(tg_user, at)');
  // v131 WhatsApp: page clicks (code in the pre-typed message), community sign-ups (number → Subscribe), raw webhook log
  d.exec('CREATE TABLE IF NOT EXISTS upload_ids(cid TEXT PRIMARY KEY, lead_id INTEGER, at INTEGER)'); // v134: one upload = one send (retries / double requests)
  d.exec(`CREATE TABLE IF NOT EXISTS wa_clicks(code TEXT PRIMARY KEY, line TEXT, vid TEXT, ip TEXT, ua TEXT, fbc TEXT, fbp TEXT, page_url TEXT, camp TEXT, adset TEXT, ad TEXT, created_at INTEGER, lead_id INTEGER)`);
  d.exec(`CREATE TABLE IF NOT EXISTS wa_joins(id INTEGER PRIMARY KEY AUTOINCREMENT, phone TEXT, line TEXT, vid TEXT, ip TEXT, ua TEXT, fbc TEXT, fbp TEXT, page_url TEXT, camp TEXT, adset TEXT, ad TEXT, created_at INTEGER, lead_id INTEGER, msg_at INTEGER, sub_due INTEGER, sub_at INTEGER, sub_state TEXT)`);
  // v137: WhatsApp ads switches: ON when such ads already ran (clicks / numbers exist), else OFF
  try {
    if (!d.prepare("SELECT 1 FROM settings WHERE k='wa_ads_on'").get()) d.prepare("INSERT INTO settings(k, v) VALUES('wa_ads_on', ?)").run(d.prepare('SELECT 1 FROM wa_clicks LIMIT 1').get() ? '1' : '0');
    if (!d.prepare("SELECT 1 FROM settings WHERE k='wa_comm_ads_on'").get()) d.prepare("INSERT INTO settings(k, v) VALUES('wa_comm_ads_on', ?)").run(d.prepare('SELECT 1 FROM wa_joins LIMIT 1').get() ? '1' : '0');
  } catch { /* next start */ }
  d.exec('CREATE INDEX IF NOT EXISTS i_wa_joins_phone ON wa_joins(phone)');
  d.exec('CREATE TABLE IF NOT EXISTS wati_log(id INTEGER PRIMARY KEY AUTOINCREMENT, at INTEGER, kind TEXT, body TEXT)');
  d.exec('CREATE INDEX IF NOT EXISTS i_leads_ch ON leads(ch)');
  d.exec('CREATE TABLE IF NOT EXISTS camp_plans(id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT, name TEXT, data TEXT, created_at INTEGER)'); // v131: campaign name planner
  // v130 campaign table
  d.exec('CREATE INDEX IF NOT EXISTS i_cj_user ON channel_joins(tg_user)');
  d.exec('CREATE INDEX IF NOT EXISTS i_cj_req ON channel_joins(requested_at)');
  d.exec('CREATE INDEX IF NOT EXISTS i_visits_camp ON visits(camp_at)');
  d.exec('CREATE INDEX IF NOT EXISTS i_leads_started ON leads(started_at)');
  d.exec('CREATE INDEX IF NOT EXISTS i_leads_camp ON leads(camp)');
  // v117: follow-ups that could not be sent are retried later (not stuck forever)
  try { d.exec('ALTER TABLE leads ADD COLUMN fu_retry_at INTEGER'); } catch { /* */ }
  try { d.exec('ALTER TABLE leads ADD COLUMN fu_fails INTEGER DEFAULT 0'); } catch { /* */ }
  // v147: "No reply needed" — the customer's messages up to this time need no answer (admin marked it, or a plain "Ok" / "Thanks")
  try { d.exec('ALTER TABLE leads ADD COLUMN noreply_at INTEGER'); } catch { /* */ }
  try { d.exec('ALTER TABLE leads ADD COLUMN noreply_by TEXT'); } catch { /* */ }
  // v148: files (voice notes, photos…) the chat account sends when Telegram Business can't (24 h after their last message)
  try { d.exec('ALTER TABLE ub_outbox ADD COLUMN file_id TEXT'); } catch { /* */ }
  try { d.exec('ALTER TABLE ub_outbox ADD COLUMN file_kind TEXT'); } catch { /* */ }
  // v150: Admin → Comments
  d.exec(`CREATE TABLE IF NOT EXISTS fb_comments(id TEXT PRIMARY KEY, src TEXT, target TEXT, ad_id TEXT, ad_name TEXT, kind TEXT, author TEXT, author_id TEXT, text TEXT,
    created_at INTEGER, seen_at INTEGER, label TEXT DEFAULT '', reason TEXT, status TEXT DEFAULT 'live', deleted_at INTEGER, deleted_by TEXT, permalink TEXT)`);
  d.exec('CREATE INDEX IF NOT EXISTS fb_comments_t ON fb_comments(created_at)');
  // v151: Ads data from Meta
  d.exec(`CREATE TABLE IF NOT EXISTS meta_insights(date TEXT, ad_id TEXT, acct TEXT, camp_id TEXT, camp TEXT, adset TEXT, ad TEXT,
    spend REAL, impr INTEGER, reach INTEGER, clicks INTEGER, link_clicks INTEGER, msgs INTEGER, leads INTEGER, subs INTEGER, purchases INTEGER, synced_at INTEGER, PRIMARY KEY(date, ad_id))`);
  try { d.exec('ALTER TABLE ad_spend ADD COLUMN meta REAL'); } catch { /* */ }
  try { d.exec('ALTER TABLE ad_spend ADD COLUMN extra REAL'); } catch { /* */ }
  d.exec('CREATE TABLE IF NOT EXISTS fb_ads(ad_id TEXT PRIMARY KEY, name TEXT, acct TEXT, fb_post TEXT, ig_media TEXT, ig_link TEXT, active INTEGER, seen_at INTEGER)');
  // v152: Ad accounts by profile (one FB profile = one user token = its BMs) + one-by-one queue behind the iProxy IP change
  d.exec(`CREATE TABLE IF NOT EXISTS meta_profiles(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, ix TEXT, app_id TEXT, secret_enc TEXT, token_enc TEXT, token_exp INTEGER,
    fb_name TEXT, status TEXT DEFAULT 'new', error TEXT, last_ip TEXT, last_sync INTEGER, alerted_at INTEGER, deleted INTEGER DEFAULT 0, created_at INTEGER)`);
  d.exec(`CREATE TABLE IF NOT EXISTS meta_jobs(id INTEGER PRIMARY KEY AUTOINCREMENT, profile_id INTEGER, kind TEXT, ref TEXT, payload TEXT, prio INTEGER DEFAULT 5,
    status TEXT DEFAULT 'queued', step TEXT, log TEXT, error TEXT, by TEXT, created_at INTEGER, started_at INTEGER, done_at INTEGER)`);
  d.exec('CREATE INDEX IF NOT EXISTS i_mjobs ON meta_jobs(status, prio, id)');
  // v156: replacement accounts — only our cost is recorded (no sale, no profit, no agent commission)
  // v159: incentive / bonus from the admin, shared by the agents with receiving leads ON (not the manager); part of the agent's earnings
  d.exec('CREATE TABLE IF NOT EXISTS agent_bonus(id INTEGER PRIMARY KEY AUTOINCREMENT, batch INTEGER, agent_id INTEGER, amount REAL, note TEXT, by TEXT, created_at INTEGER)');
  d.exec('CREATE INDEX IF NOT EXISTS i_bonus_agent ON agent_bonus(agent_id, created_at)');
  d.exec('CREATE INDEX IF NOT EXISTS i_bonus_batch ON agent_bonus(batch)');
  // v160: dashboards / conversion (people who wrote in a period, buyers per chat)
  d.exec('CREATE INDEX IF NOT EXISTS i_sales_lead ON sales(lead_id, created_at)');
  d.exec('CREATE INDEX IF NOT EXISTS i_topups_mlog ON topups(meta_log_id)'); // v165
  d.exec('CREATE INDEX IF NOT EXISTS i_sales_agent ON sales(agent_id, created_at)');
  d.exec('CREATE INDEX IF NOT EXISTS i_sales_created ON sales(created_at)');
  d.exec('CREATE INDEX IF NOT EXISTS i_msg_in ON messages(dir, created_at, lead_id)');
  d.exec('CREATE TABLE IF NOT EXISTS meta_replacements(id INTEGER PRIMARY KEY AUTOINCREMENT, req_id INTEGER, lead_id INTEGER, agent_id INTEGER, old_act TEXT, new_act TEXT, cost REAL, by TEXT, created_at INTEGER)');
  for (const [t, c, ty] of [['meta_bms', 'profile_id', 'INTEGER'], ['meta_bms', 'verified_since', 'TEXT'], ['meta_accounts', 'dsl', 'REAL'], ['meta_accounts', 'bill_threshold', 'REAL'],
    ['meta_accounts', 'extra_bms', 'TEXT'], ['meta_accounts', 'share_msg', 'INTEGER DEFAULT 0'], ['meta_accounts', 'low_at', 'INTEGER'], ['meta_accounts', 'proof_at', 'INTEGER'], ['meta_accounts', 'repl_of', 'TEXT'], ['meta_accounts', 'post_wait', 'INTEGER'], ['meta_requests', 'q_msg', 'INTEGER'], ['meta_requests', 'q_eta', 'INTEGER'], ['meta_requests', 'q_txt', 'TEXT'], ['meta_accounts', 'post_ready', 'INTEGER DEFAULT 0'], ['meta_accounts', 'post_mode', 'TEXT'], ['meta_requests', 'rec_at', 'INTEGER'], ['meta_requests', 'old_act', 'TEXT'], ['meta_requests', 'ext', 'INTEGER DEFAULT 0'], ['meta_requests', 'by_role', 'TEXT'], ['tasks', 'data', 'TEXT'], ['meta_log', 'img', 'TEXT'], ['sales', 'meta_req_id', 'INTEGER'], ['topups', 'meta_req_id', 'INTEGER'], ['meta_jobs', 'wrote', 'INTEGER DEFAULT 0'], ['meta_requests', 'add_paid', 'REAL'], ['meta_requests', 'add_fee', 'REAL'], ['meta_requests', 'add_amount', 'REAL'], ['meta_accounts', 'base_name', 'TEXT'], ['meta_accounts', 'partner_name', 'TEXT'], ['meta_accounts', 'biz_name', 'TEXT'], ['meta_requests', 'biz_name', 'TEXT'],
    ['meta_requests', 'manual', 'INTEGER DEFAULT 0'], ['meta_accounts', 'removed_at', 'INTEGER'], ['meta_accounts', 'removed_state', 'TEXT'], ['meta_accounts', 'removed_by', 'TEXT'], ['meta_requests', 'sale_id', 'INTEGER'], ['meta_requests', 'job_id', 'INTEGER'], ['leads', 'manual_client', 'INTEGER DEFAULT 0']] as const) {
    try { d.exec(`ALTER TABLE ${t} ADD COLUMN ${c} ${ty}`); } catch { /* already there */ }
  }
  once('v153_unblock_3', ["UPDATE meta_bms SET status='ok', error=NULL, alerted=0 WHERE status='blocked' AND error LIKE '%(#3)%'", "UPDATE meta_profiles SET status='ok', error=NULL WHERE status='blocked' AND error LIKE '%(#3)%'"]);
  once('v153_name_pattern', ["UPDATE settings SET v='{brand} {n}' WHERE k='meta_name_pattern' AND v='{brand} Ad Account {n}'"]);
  // v155: proof images / channel post sent once per sale (restarts never send them again)
  once('v155_proof_at', ["UPDATE meta_accounts SET proof_at=COALESCE(assigned_at,1) WHERE state IN ('assigned','invited') AND partner_name IS NOT NULL"]);
  // v143: WhatsApp follow-ups that were skipped because of the TELEGRAM chat account's spam limit (wrong channel) → back in the
  // send queue once, only chats still inside the 24-hour WhatsApp window. Stuck ones (agent asked) are queued; ones waiting for
  // a 3-hour retry are freed for the next run.
  once('v143_wa_requeue', [
    `UPDATE leads SET fu_q=${Date.now()}, fu_fails=0, fu_retry_at=NULL WHERE ch='wa' AND status='active' AND COALESCE(fu_due,0)=1 AND fu_stage>0 AND auto_stop IS NULL
       AND last_in_at > ${Date.now()} - 86400000 + 900000
       AND EXISTS (SELECT 1 FROM messages m WHERE m.lead_id=leads.id AND m.dir='sys' AND m.text LIKE '%not sent automatically: the chat account has a Telegram spam limit%' AND m.created_at > leads.last_in_at)`,
    `UPDATE leads SET fu_fails=0, fu_retry_at=NULL WHERE ch='wa' AND status='active' AND COALESCE(fu_due,0)=0 AND COALESCE(fu_retry_at,0) > 0 AND auto_stop IS NULL
       AND last_in_at > ${Date.now()} - 86400000 + 900000
       AND EXISTS (SELECT 1 FROM messages m WHERE m.lead_id=leads.id AND m.dir='sys' AND m.text LIKE '%not sent automatically: the chat account has a Telegram spam limit%' AND m.created_at > leads.last_in_at)`,
  ]);
  if (!d.prepare("SELECT 1 FROM settings WHERE k='_fu_restart_v117'").get()) {
    // chats whose follow-up got stuck (could not be sent) → that follow-up is tried again now
    const stuck = d.prepare("SELECT id FROM leads WHERE status='active' AND COALESCE(fu_due,0)=1 AND auto_stop IS NULL AND remind_at IS NULL AND COALESCE(remind_due,0)=0 AND last_out_at IS NOT NULL AND last_out_at > COALESCE(last_in_at,0)").all() as { id: number }[];
    const up = d.prepare('UPDATE leads SET fu_stage=MAX(COALESCE(fu_stage,1)-1,0), fu_due=0, fu_fails=0, fu_retry_at=NULL WHERE id=?');
    const note = d.prepare("INSERT INTO messages(lead_id, dir, sender, text, created_at) VALUES(?, 'sys', 'system', '▶️ Follow-ups restarted after the update (the last one could not be sent before).', ?)");
    d.transaction(() => { for (const r of stuck) { up.run(r.id); note.run(r.id, Date.now()); } d.prepare("INSERT OR IGNORE INTO settings(k, v) VALUES('_fu_restart_v117', '1')").run(); })();
  }
  // v166: WhatsApp webhook dedupe (claimed before any await); double-tap guard by the time the row was ADDED (back-dated sales)
  d.exec('CREATE TABLE IF NOT EXISTS wa_seen(msg_id TEXT PRIMARY KEY, at INTEGER)');
  for (const [t, c] of [['sales', 'added_at'], ['topups', 'added_at']] as const) { try { d.exec(`ALTER TABLE ${t} ADD COLUMN ${c} INTEGER`); } catch { /* already there */ } }
  // v168: files being sent to WhatsApp right now (their echo waits for our row); one WhatsApp id = one row per chat (once, in a tx)
  d.exec('CREATE TABLE IF NOT EXISTS wa_out_pending(id INTEGER PRIMARY KEY AUTOINCREMENT, wa TEXT, kind TEXT, name TEXT, at INTEGER, sent_at INTEGER)');
  d.exec('CREATE INDEX IF NOT EXISTS i_wa_out_pending ON wa_out_pending(wa, at)');
  mig168(d);
  try { ensureReelTables(d); } catch (e) { console.warn('[db] reel tables', (e as Error).message); } // v167: Daily reel tables (idempotent)
  g.__adflowDb = d;
  return d;
}

type P = unknown[];
// better-sqlite3 rejects undefined/boolean — normalise them.
const clean = (a: P) => a.map(v => (v === undefined ? null : typeof v === 'boolean' ? (v ? 1 : 0) : v));
export const one = <T = any>(sql: string, ...a: P): T | undefined => db().prepare(sql).get(...clean(a)) as T | undefined;
export const all = <T = any>(sql: string, ...a: P): T[] => db().prepare(sql).all(...clean(a)) as T[];
export const run = (sql: string, ...a: P) => db().prepare(sql).run(...clean(a));
export const tx = <T>(fn: () => T): T => db().transaction(fn)();
