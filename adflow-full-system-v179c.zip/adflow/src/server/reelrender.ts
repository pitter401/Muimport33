/* v168: status-video RENDERER: parameterised HTML templates (reel-templates/<ID>/index.html) → 1080x1920 H.264 MP4.
 *
 *  How a render works (one at a time, low priority: nice 19 + ionice idle for Chromium and ffmpeg):
 *   1. ffmpeg extracts the stock video's frames at 30 fps (sharp 1280x720 + a small blurred copy) into a job folder.
 *   2. A tiny HTTP server on 127.0.0.1 (random port) serves the templates and the job folder (same origin: fonts,
 *      canvas reads and images all work; nothing is reachable from outside).
 *   3. Headless Chromium (playwright-core) opens the template with window.__REEL = data, then for every frame
 *      t = i / 30 calls window.__seek(t) and takes a JPEG screenshot (CDP Page.captureScreenshot), piped into ffmpeg.
 *   4. ffmpeg encodes H.264 (CRF 20, veryfast, yuv420p, 30 fps, +faststart) and muxes the source video's ORIGINAL song:
 *      fade in 0.3 s, fade out over the last 1 s (with the end card), loudness normalised to -14 LUFS (two-pass loudnorm).
 *      Phone-shaped agent templates (e.g. 375x812) are fitted to the 1080x1920 height with a blurred fill at the sides.
 *   5. The job folder is always deleted (also stale ones from a crash).
 *
 *  This file is imported only by the worker (and the tests), never by a Next.js route: the web app only queues jobs. */
import fs from 'fs';
import os from 'os';
import path from 'path';
import http from 'http';
import { spawn, execFileSync } from 'child_process';
import { ffmpegPath } from './voicefx';

export const OUT_W = 1080, OUT_H = 1920, FPS = 30;
/** v169: "Full screen" status video for today's tall phones (9:20). The design stays in the middle 1080x1920 (safe on 9:16 phones);
 *  the extra 240 px top and bottom are a soft blurred extension of the same frame. */
export const TALL_H = 2400;
export const MAX_VIDEO_SEC = 45; // the templates scale their timeline to 10..45 s
/** v168 (senior review): the video encode. CRF 20 keeps the look; the VBV cap (3 Mbit/s, 6 Mbit buffer) keeps a 40 s status
 *  v169: sharp 1080p (CRF 18, up to 8 Mbps, ~30-40 MB for 40 s; the owner prefers quality over size). The song is the stock video's own (AAC 192k). */
export const X264_ARGS = ['-c:v', 'libx264', '-preset', 'veryfast', '-crf', '17', '-maxrate', '8M', '-bufsize', '16M', '-profile:v', 'high'];

/* ---------------- templates ---------------- */

export type Runtime = 'adminA' | 'adminB' | 'agentA' | 'agentB' | 'other';
export type Tpl = { id: string; kind: 'admin' | 'agent'; name: string; runtime: Runtime; themes: ('dark' | 'light')[]; dir: string };

/** Where the templates live: <app>/reel-templates (shipped in the zip). REEL_TEMPLATES_DIR overrides (tests). */
export const templatesDir = () => process.env.REEL_TEMPLATES_DIR || path.join(process.cwd(), 'reel-templates');

let cache: { at: number; key: string; list: Tpl[] } | null = null;
/** Folder scan + optional manifest.json (root: {"templates": {"S01": {"name": "...", "themes": ["dark","light"], "disabled": true}}}
 *  or per template <ID>/manifest.json). Admin = S01..S99, agent = one capital letter (A–D are the in-app React styles, so
 *  they have no folder). New template folders drop in without code changes. */
export function scanTemplates(dir = templatesDir()): Tpl[] {
  let key = '';
  try { key = dir + ':' + fs.statSync(dir).mtimeMs + ':' + (fs.existsSync(path.join(dir, 'manifest.json')) ? fs.statSync(path.join(dir, 'manifest.json')).mtimeMs : 0); } catch { return []; }
  if (cache && cache.key === key && Date.now() - cache.at < 30000) return cache.list;
  let root: { templates?: Record<string, Partial<Tpl> & { disabled?: boolean }> } = {};
  try { root = JSON.parse(fs.readFileSync(path.join(dir, 'manifest.json'), 'utf8')); } catch { /* none */ }
  const out: Tpl[] = [];
  for (const id of fs.readdirSync(dir).sort()) {
    if (!/^(S\d{2}|[A-Z]{1,2})$/.test(id)) continue; // v174: agent formats AA–AD
    const td = path.join(dir, id), f = path.join(td, 'index.html');
    if (!fs.existsSync(f)) continue;
    let own: Partial<Tpl> & { disabled?: boolean } = {};
    try { own = JSON.parse(fs.readFileSync(path.join(td, 'manifest.json'), 'utf8')); } catch { /* none */ }
    const m = { ...own, ...(root.templates?.[id] || {}) }; // the root manifest (deployment) wins over the designer's own
    if (m.disabled) continue;
    const html = fs.readFileSync(f, 'utf8');
    const rt = (/_shared\/(adminA|adminB|agentA|agentB)\//.exec(html)?.[1] || 'other') as Runtime;
    const title = /<title>([^<]*)<\/title>/i.exec(html)?.[1]?.trim() || id;
    const name = String(m.name || title.replace(new RegExp('^' + id + '\\s*[-·:]?\\s*'), '') || id).slice(0, 40);
    // light support: declared (manifest themes / <meta name="reel-themes">), else detected (light CSS or a theme check in the page)
    const metaT = /<meta\s+name=["']reel-themes["']\s+content=["']([^"']+)["']/i.exec(html)?.[1];
    const declared = Array.isArray(m.themes) ? m.themes : metaT ? metaT.split(',').map(s => s.trim()) : null;
    const light = declared ? declared.includes('light') : /body\.light|\.light[\s{.#,>]|theme\s*===?\s*['"]light['"]|E\.L\b|E\.DARK\b/.test(html);
    out.push({ id, kind: /^S\d{2}$/.test(id) ? 'admin' : 'agent', name, runtime: rt, themes: light ? ['dark', 'light'] : ['dark'], dir: td });
  }
  cache = { at: Date.now(), key, list: out };
  return out;
}
export const getTemplate = (id: string) => scanTemplates().find(t => t.id === id) || null;

/* ---------------- Chromium ---------------- */

const exists = (p: string) => { try { return fs.statSync(p).isFile(); } catch { return false; } };
const SHELL = ['chrome-headless-shell-linux64/chrome-headless-shell', 'chrome-linux/headless_shell'];
const FULL = ['chrome-linux64/chrome', 'chrome-linux/chrome'];
/** The headless Chromium to use, and where it came from (shown in the admin; same order as scripts/find-chromium.cjs, which
 *  scripts/update.sh uses). No playwright import needed, so the web app can show the status too. Order (the owner's VPS also runs
 *  other Playwright / Camoufox projects; nothing here deletes or upgrades their browsers):
 *   0. REEL_CHROMIUM_PATH  1. our playwright-core's own revision (browsers.json; headless shell first)
 *   2. any other Chromium in the Playwright cache, newest first  3. /usr/bin/chromium, chromium-browser, google-chrome. */
export function chromiumInfo(appDir = process.cwd()): { source: string; path: string } | null {
  const env = process.env.REEL_CHROMIUM_PATH;
  if (env) return exists(env) ? { source: 'REEL_CHROMIUM_PATH', path: env } : null;
  const roots = [...new Set([process.env.PLAYWRIGHT_BROWSERS_PATH, path.join(os.homedir(), '.cache', 'ms-playwright'), '/root/.cache/ms-playwright'].filter((x): x is string => !!x && x !== '0'))];
  let rev: { shell?: string; full?: string } = {};
  try {
    const j = JSON.parse(fs.readFileSync(path.join(appDir, 'node_modules', 'playwright-core', 'browsers.json'), 'utf8')) as { browsers: { name: string; revision: string }[] };
    rev = { shell: j.browsers.find(b => b.name === 'chromium-headless-shell')?.revision, full: j.browsers.find(b => b.name === 'chromium')?.revision };
  } catch { /* no playwright-core */ }
  for (const r of roots) {
    if (rev.shell) for (const c of SHELL) { const p = path.join(r, `chromium_headless_shell-${rev.shell}`, c); if (exists(p)) return { source: `playwright-core (own, headless shell ${rev.shell})`, path: p }; }
    if (rev.full) for (const c of FULL) { const p = path.join(r, `chromium-${rev.full}`, c); if (exists(p)) return { source: `playwright-core (own, chromium ${rev.full})`, path: p }; }
  }
  const ver = (n: string) => Number(/-(\d+)$/.exec(n)?.[1] || 0);
  for (const r of roots) {
    let names: string[] = [];
    try { names = fs.readdirSync(r); } catch { continue; }
    const pick = (re: RegExp, cands: string[], label: string) => {
      for (const n of names.filter(x => re.test(x)).sort((a, b) => ver(b) - ver(a))) for (const c of cands) { const p = path.join(r, n, c); if (exists(p)) return { source: `${label} ${n} (shared Playwright cache)`, path: p }; }
      return null;
    };
    const f = pick(/^chromium_headless_shell-\d+$/, SHELL, 'headless shell') || pick(/^chromium-\d+$/, FULL, 'chromium');
    if (f) return f;
  }
  for (const p of ['/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/google-chrome-stable', '/usr/bin/google-chrome', '/opt/google/chrome/chrome']) if (exists(p)) return { source: 'system', path: p };
  return null;
}
export const findChromium = () => chromiumInfo()?.path || null;
const hasBin = (b: string) => { try { execFileSync('sh', ['-c', `command -v ${b}`], { stdio: 'ignore' }); return true; } catch { return false; } };
/** "nice -n 19 ionice -c 3" when those exist (they do on Ubuntu), so a render never slows the website or the bots. */
export function lowPrio(): string[] {
  const p: string[] = [];
  if (process.env.REEL_NICE === '0') return p; // tests only: measure the render time on a busy shared box
  if (hasBin('nice')) p.push('nice', '-n', '19');
  if (hasBin('ionice')) p.push('ionice', '-c', '3');
  return p;
}
/** A tiny wrapper so Chromium (and every process it starts) runs at low priority. */
function niceWrapper(bin: string, dir: string) {
  const pre = lowPrio();
  if (!pre.length) return bin;
  const w = path.join(dir, 'chromium-low.sh');
  fs.writeFileSync(w, `#!/bin/sh\nexec ${pre.join(' ')} ${JSON.stringify(bin)} "$@"\n`, { mode: 0o755 });
  return w;
}

/* ---------------- work folders ---------------- */

export const svidDir = () => {
  const d = path.join(path.dirname(process.env.DB_PATH || path.join(process.cwd(), 'data', 'adflow.db')), 'svid');
  fs.mkdirSync(d, { recursive: true });
  return d;
};
export const workRoot = () => { const d = path.join(svidDir(), 'work'); fs.mkdirSync(d, { recursive: true }); return d; };
/** Frame-cache clean-up: job folders left by a crash (older than 2 h, or all with force). Returns how many went. */
export function sweepWork(force = false) {
  let n = 0;
  try {
    for (const f of fs.readdirSync(workRoot())) {
      const p = path.join(workRoot(), f);
      if (force || Date.now() - fs.statSync(p).mtimeMs > 2 * 3600000) { fs.rmSync(p, { recursive: true, force: true }); n++; }
    }
  } catch { /* none */ }
  return n;
}

/* ---------------- ffmpeg helpers ---------------- */

function ff(args: string[], ms: number, opts: { input?: boolean; low?: boolean } = {}) {
  const bin = ffmpegPath();
  if (!bin) throw new Error('ffmpeg is not installed');
  const pre = opts.low === false ? [] : lowPrio();
  const cmd = pre.length ? pre[0] : bin, argv = pre.length ? [...pre.slice(1), bin, '-hide_banner', '-nostdin', ...args] : ['-hide_banner', '-nostdin', ...args];
  if (opts.input) argv.splice(argv.indexOf('-nostdin'), 1);
  const p = spawn(cmd, argv, { stdio: [opts.input ? 'pipe' : 'ignore', 'ignore', 'pipe'] });
  let err = '';
  p.stderr!.on('data', d => { err = (err + d).slice(-16000); });
  const done = new Promise<string>((res, rej) => {
    const t = setTimeout(() => { p.kill('SIGKILL'); rej(new Error('ffmpeg took too long')); }, ms);
    p.on('error', e => { clearTimeout(t); rej(e); });
    p.on('close', code => { clearTimeout(t); code === 0 ? res(err) : rej(Object.assign(new Error('ffmpeg: ' + (err.trim().split('\n').pop() || 'exit ' + code)), { log: err })); });
  });
  return { p, done };
}
export type VProbe = { duration: number; w: number; h: number; audio: boolean; vcodec: string };
/** ffmpeg's view of a video (from `ffmpeg -i`; no ffprobe needed). */
export async function probeVideo(file: string): Promise<VProbe | null> {
  let out = '';
  try { out = await ff(['-i', file], 30000, { low: false }).done; } catch (e) { out = String((e as { log?: string }).log || ''); }
  const d = /Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)/.exec(out);
  const v = /Stream #\d+:\d+[^\n]*?: Video: ([^\n]+)/.exec(out);
  if (!d || !v) return null;
  const sz = /\b(\d{2,5})x(\d{2,5})\b/.exec(v[1]);
  return { duration: Number(d[1]) * 3600 + Number(d[2]) * 60 + Number(d[3]), w: sz ? Number(sz[1]) : 0, h: sz ? Number(sz[2]) : 0, audio: /Stream #\d+:\d+[^\n]*?: Audio:/.test(out), vcodec: (/^(\w+)/.exec(v[1])?.[1] || '').toLowerCase() };
}

/* ---------------- local server ---------------- */

const TYPES: Record<string, string> = { html: 'text/html; charset=utf-8', js: 'text/javascript', css: 'text/css', json: 'application/json', jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp', svg: 'image/svg+xml', woff2: 'font/woff2', woff: 'font/woff', ttf: 'font/ttf', otf: 'font/otf', mp4: 'video/mp4', wav: 'audio/wav' };
/** Serves /t/* from the templates folder and /j/* from the job folder, on 127.0.0.1 only. No path can leave those folders. */
function serve(roots: Record<string, string>): Promise<{ base: string; close: () => void }> {
  const srv = http.createServer((req, res) => {
    try {
      const u = decodeURIComponent(new URL(req.url || '/', 'http://x').pathname);
      const m = /^\/([a-z])\/(.*)$/.exec(u);
      const root = m && roots[m[1]];
      if (!root || !m) { res.writeHead(404).end(); return; }
      const p = path.resolve(root, m[2]);
      if (p !== root && !p.startsWith(root + path.sep)) { res.writeHead(403).end(); return; }
      if (!exists(p)) { res.writeHead(404).end(); return; }
      res.writeHead(200, { 'content-type': TYPES[p.split('.').pop()!.toLowerCase()] || 'application/octet-stream', 'cache-control': 'max-age=3600' });
      fs.createReadStream(p).pipe(res);
    } catch { res.writeHead(400).end(); }
  });
  return new Promise((res, rej) => {
    srv.on('error', rej);
    srv.listen(0, '127.0.0.1', () => { const a = srv.address() as { port: number }; res({ base: `http://127.0.0.1:${a.port}`, close: () => srv.close() }); });
  });
}

/* ---------------- the data each runtime expects ---------------- */

/** The designers' four shared runtimes read the video frames in different shapes; this gives each its own (and a superset
 *  for an unknown one). Frames: <base>s/f_0001.jpg (1920x1080, v169: was 1280x720) and <base>b/f_0001.jpg (256x144, blurred). */
export function framesFor(rt: Runtime, base: string, n: number): Record<string, unknown> {
  const A = { sharp: `${base}s/f_{n}.jpg`, blur: `${base}b/f_{n}.jpg`, fps: FPS, count: n };
  const B = { base: `${base}s/f_`, blur: `${base}b/f_`, ext: '.jpg', pad: 4, fps: FPS, count: n };
  const C = { dir: `${base}s/`, prefix: 'f_', pad: 4, ext: '.jpg', fps: FPS, count: n };
  switch (rt) {
    case 'adminA': return { frames: A };
    case 'adminB': return { frames: B };
    case 'agentA': return { frames: C };
    case 'agentB': return { frames: `${base}s/f_%04d.jpg`, frames_n: n, frames_fps: FPS };
    default: return { frames: { ...C, ...B, ...A } }; // A's blur ({n} pattern) wins
  }
}

/** Date strings in every shape the runtimes read (adminA "dates", adminB/agentA "date", agentB date_long/date_short).
 *  `day` = the day the numbers are about (admin: yesterday) or the reel day (agent); `today` = the day it is watched. */
export function dateStrings(day: string, today: string) {
  const d = new Date(day + 'T00:00:00Z'), t = new Date(today + 'T00:00:00Z');
  const f = (x: Date, o: Intl.DateTimeFormatOptions) => x.toLocaleDateString('en-GB', { timeZone: 'UTC', ...o });
  const wk = f(d, { weekday: 'long' }), mon = f(d, { month: 'long' }), dd = String(d.getUTCDate()), yy = String(d.getUTCFullYear());
  const short = `${f(d, { weekday: 'short' })} ${dd} ${f(d, { month: 'short' })}`;
  return {
    date: { weekday: wk, day: dd, month: mon, year: yy, short, long: `${wk}, ${dd} ${mon} ${yy}`, numeric: `${dd.padStart(2, '0')}.${String(d.getUTCMonth() + 1).padStart(2, '0')}.${yy}`,
      day_month: `${dd} ${mon}`, num: `${dd.padStart(2, '0')}.${String(d.getUTCMonth() + 1).padStart(2, '0')}` },
    dates: { today: `${f(t, { weekday: 'short' })} ${t.getUTCDate()} ${f(t, { month: 'short' })}`, today_short: `${t.getUTCDate()} ${f(t, { month: 'short' })}`, yesterday: short, yesterday_long: `${wk}, ${dd} ${mon}`,
      weekday_y: wk, weekday_t: f(t, { weekday: 'long' }), day_y: dd, day_t: String(t.getUTCDate()), month: mon, year: yy },
    date_long: `${wk}, ${dd} ${mon}`, date_short: `${f(d, { weekday: 'short' })}, ${dd} ${f(d, { month: 'short' })}`,
  };
}

/* ---------------- render ---------------- */

export type ReelData = {
  name: string; greeting: string; quotes: string[]; streak?: number; line_of_day?: string; showing?: number;
  yesterday: { earned?: number; sales?: number; revenue?: number; tg?: { sales?: number; amount?: number }; wa?: { sales?: number; amount?: number }; fees?: number; fees_on?: number };
  day: string; today: string; // YYYY-MM-DD
};
export type RenderOpts = { tpl: string; theme: 'dark' | 'light'; data: ReelData; video: string; out: string; logo?: string; onProgress?: (pct: number) => void; timeoutMs?: number; templates?: string; tall?: boolean };
export type RenderResult = { frames: number; duration: number; ms: number; size: number; w: number; h: number; audio: boolean; tpl: string; theme: string };

/** Renders one status video. Throws with a short, readable message on failure (the caller stores it on the job). */
export async function renderReel(o: RenderOpts): Promise<RenderResult> {
  const t0 = Date.now();
  const tdir = o.templates || templatesDir();
  const tpl = scanTemplates(tdir).find(t => t.id === o.tpl);
  if (!tpl) throw new Error(`Format ${o.tpl} is not installed`);
  const ci = chromiumInfo();
  if (!ci) throw new Error('The video renderer (Chromium) is not installed');
  const chrome = ci.path;
  console.log(`[reelrender] ${o.tpl} ${o.theme}: Chromium = ${ci.source} (${ci.path})`);
  if (!ffmpegPath()) throw new Error('ffmpeg is not installed');
  const pr = await probeVideo(o.video);
  if (!pr || pr.duration < 3) throw new Error('The stock video could not be read');
  const vdur = Math.min(pr.duration, MAX_VIDEO_SEC);
  const job = fs.mkdtempSync(path.join(workRoot(), 'job-'));
  const report = (p: number) => { try { o.onProgress?.(Math.max(0, Math.min(99, Math.round(p)))); } catch { /* ignore */ } };
  // the open browser, in a holder object (it is (re)assigned inside launch(); a plain `let` would be narrowed to never by TS)
  const held: { browser: { close: () => Promise<void> } | null } = { browser: null };
  let server: { close: () => void } | null = null;
  const deadline = t0 + (o.timeoutMs || 25 * 60000);
  try {
    // 1. frames (sharp + small blurred), low priority
    fs.mkdirSync(path.join(job, 's')); fs.mkdirSync(path.join(job, 'b'));
    report(1);
    await ff(['-y', '-t', vdur.toFixed(3), '-i', o.video, '-filter_complex',
      `[0:v]fps=${FPS},scale=1920:1080:force_original_aspect_ratio=decrease:flags=lanczos,pad=1920:1080:(ow-iw)/2:(oh-ih)/2:black,setsar=1,split=2[a][b];[b]scale=256:144,gblur=sigma=2[bb]`,
      '-map', '[a]', '-q:v', '1', path.join(job, 's', 'f_%04d.jpg'), '-map', '[bb]', '-q:v', '5', path.join(job, 'b', 'f_%04d.jpg')], 10 * 60000).done;
    const n = fs.readdirSync(path.join(job, 's')).filter(f => f.endsWith('.jpg')).length;
    if (n < FPS * 3) throw new Error('Too few frames in the stock video');
    fs.copyFileSync(o.logo && exists(o.logo) ? o.logo : path.join(tdir, '_shared', 'logo.png'), path.join(job, 'logo.png'));
    report(5);
    // 2. local server + data
    const srv = await serve({ t: path.resolve(tdir), j: path.resolve(job) });
    server = srv;
    const ds = dateStrings(o.data.day, o.data.today);
    const noTag = (x: unknown) => String(x ?? '').replace(/[<>]/g, ''); // v168 (senior review): some formats use innerHTML for the name / quotes
    const reel = {
      ...ds, name: noTag(o.data.name), greeting: noTag(o.data.greeting), quotes: o.data.quotes.filter(q => q && q.trim()).map(noTag), streak: Math.max(0, Math.round(o.data.streak || 0)),
      line_of_day: noTag(o.data.line_of_day || ''), showing: o.data.showing || 1, yesterday: o.data.yesterday, theme: o.theme,
      video_url: '', video_duration: n / FPS, logo_url: '/j/logo.png', ...framesFor(tpl.runtime, '/j/', n),
    };
    const url = `${srv.base}/t/${tpl.id}/index.html?theme=${o.theme}`;
    // 3. Chromium (low priority)
    const pw = await import('playwright-core');
    const exe = niceWrapper(chrome, job);
    type B = Awaited<ReturnType<typeof pw.chromium.launch>>;
    let b: B;
    const launch = async () => {
      b = await pw.chromium.launch({ executablePath: exe, headless: true, timeout: 60000,
        args: ['--disable-gpu', '--disable-dev-shm-usage', '--hide-scrollbars', '--mute-audio', '--font-render-hinting=none', '--disable-background-timer-throttling', '--disable-renderer-backgrounding', '--disable-extensions', '--js-flags=--max-old-space-size=256'] });
      held.browser = b;
    };
    await launch();
    const errors: string[] = [];
    const open = async (vp: { width: number; height: number }, dsf: number) => {
      const ctx = await b.newContext({ viewport: vp, deviceScaleFactor: dsf, colorScheme: o.theme });
      const page = await ctx.newPage();
      page.on('pageerror', e => errors.push(e.message));
      await page.addInitScript(`window.__REEL=${JSON.stringify(reel)};document.addEventListener('DOMContentLoaded',()=>{if(${JSON.stringify(o.theme)}==='light')document.body.classList.add('light');});`);
      await page.goto(url, { waitUntil: 'load', timeout: 60000 });
      await page.waitForFunction(() => document.body && document.body.dataset.ready === '1', null, { timeout: 90000 }).catch(() => { throw new Error(`Format ${tpl.id} did not load${errors.length ? ': ' + errors[0].slice(0, 160) : ''}`); });
      return { ctx, page };
    };
    // the template's own size: html/body or its stage sets it (e.g. 360x640, 1080x1920, 375x812)
    const pr0 = await open({ width: 64, height: 64 }, 1);
    const dim = await pr0.page.evaluate(() => {
      const d = document.documentElement, s = document.body;
      return { w: Math.max(d.scrollWidth, s.scrollWidth), h: Math.max(d.scrollHeight, s.scrollHeight) };
    });
    await pr0.ctx.close();
    if (!(dim.w >= 200 && dim.h >= 300 && dim.w <= 2200 && dim.h <= 4000)) throw new Error(`Format ${tpl.id} has an odd size (${dim.w}x${dim.h})`);
    const dsf = Math.min(OUT_W / dim.w, OUT_H / dim.h);
    const capW = Math.round(dim.w * dsf), capH = Math.round(dim.h * dsf);
    let { page, ctx } = await open({ width: dim.w, height: dim.h }, dsf);
    const total0 = await page.evaluate(`(() => { const T = window.TIMES || {}; const E = window.E || {}; return Number(T.TOTAL || T.T_TOTAL || window.__duration || E.TOTAL || 0); })()`) as number;
    const total = Math.min(60, Math.max(3, Number.isFinite(total0) && total0 > 0 ? total0 : n / FPS));
    const N = Math.round(total * FPS);
    // 4. audio: two-pass loudnorm to -14 LUFS of the trimmed, faded song
    const fadeOut = Math.min(1, total / 4); // the brief + the templates' manifests: fade in 0.3 s, out over the last 1 s (with the end card)
    const afx = `atrim=0:${total.toFixed(3)},asetpts=PTS-STARTPTS,apad=whole_dur=${total.toFixed(3)},afade=t=in:st=0:d=0.3,afade=t=out:st=${(total - fadeOut).toFixed(3)}:d=${fadeOut.toFixed(3)}`;
    let ln = 'loudnorm=I=-14:TP=-1.5:LRA=11';
    if (pr.audio) {
      try {
        const log = await ff(['-i', o.video, '-vn', '-af', `${afx},${ln}:print_format=json`, '-f', 'null', '-'], 3 * 60000).done;
        const j = JSON.parse(log.slice(log.lastIndexOf('{'), log.lastIndexOf('}') + 1));
        if (Number.isFinite(Number(j.input_i)) && Number(j.input_i) > -70) ln += `:measured_I=${j.input_i}:measured_TP=${j.input_tp}:measured_LRA=${j.input_lra}:measured_thresh=${j.input_thresh}:offset=${j.target_offset}:linear=true`;
      } catch { /* one-pass (dynamic) loudnorm is fine too */ }
    }
    const OH = o.tall ? TALL_H : OUT_H; // v169: the output height (the design itself is always fitted into 1080x1920)
    const fit = capW === OUT_W && capH === OUT_H && OH === OUT_H
      ? `[0:v]scale=${OUT_W}:${OUT_H}:flags=lanczos,setsar=1,format=yuv420p[v]`
      : `[0:v]split=2[fa][fb];[fb]scale=108:${Math.round(OH / 10)}:force_original_aspect_ratio=increase,crop=108:${Math.round(OH / 10)},gblur=sigma=5,scale=${OUT_W}:${OH}:flags=bicubic,eq=brightness=${o.theme === 'light' ? '0.02' : '-0.08'}[bg];[fa]scale=-2:${OUT_H}:flags=lanczos[fg];[bg][fg]overlay=(W-w)/2:(H-h)/2,setsar=1,format=yuv420p[v]`;
    const aIn = pr.audio ? ['-i', o.video] : ['-f', 'lavfi', '-t', total.toFixed(3), '-i', 'anullsrc=r=48000:cl=stereo'];
    const tmpOut = o.out + '.part.mp4';
    const enc = ff(['-y', '-f', 'image2pipe', '-framerate', String(FPS), '-c:v', 'mjpeg', '-i', '-', ...aIn,
      '-filter_complex', `${fit};[1:a:0]${afx}${pr.audio ? ',' + ln : ''},aresample=48000[a]`, '-map', '[v]', '-map', '[a]',
      ...X264_ARGS, '-pix_fmt', 'yuv420p', '-r', String(FPS), '-c:a', 'aac', '-b:a', '192k', '-ar', '48000',
      '-t', total.toFixed(3), '-movflags', '+faststart', tmpOut], 30 * 60000, { input: true });
    let encErr: Error | null = null;
    enc.done.catch(e => { encErr = e; });
    let cdp = await ctx.newCDPSession(page);
    // v169: the headless shell's CDP screenshot ignores deviceScaleFactor (a 360x640 format came out 360x640 and ffmpeg blew it up
    // to 1080x1920 - the soft "720p" look). Probe once and set clip.scale so every frame is captured at the full capW x capH.
    const jpegW = (buf: Buffer) => { for (let k = 2; k + 9 < buf.length;) { if (buf[k] !== 0xff) { k++; continue; } const m = buf[k + 1]; if (m >= 0xc0 && m <= 0xc3) return buf.readUInt16BE(k + 7); k += 2 + buf.readUInt16BE(k + 2); } return 0; };
    const clip = { x: 0, y: 0, width: dim.w, height: dim.h, scale: 1 };
    { const s0 = await cdp.send('Page.captureScreenshot', { format: 'jpeg', quality: 50, clip }) as { data: string }; const w0 = jpegW(Buffer.from(s0.data, 'base64')); if (w0 > 0) clip.scale = capW / w0; }
    const stdin = enc.p.stdin!;
    stdin.on('error', () => { /* ffmpeg exited; reported by enc.done */ });
    // Frames are deterministic (__seek(t)) and rendered IN ORDER (some formats ease a colour tint frame by frame). Chromium is
    // RECYCLED every RECYCLE frames (decoded frame images pile up; the adminA designer measured a crash every ~60–70 frames at
    // 1080x1920), and re-opened after a crash; after either, the frames just before are replayed without capturing (WARM) so
    // eased state settles. Up to 20 crashes per render; after that the job's own retry (1, 3, 10 … min) takes over.
    const RECYCLE = tpl.runtime === 'adminA' ? 60 : 240, WARM = 12;
    let crashes = 0;
    const reopen = async (at: number, why: string) => {
      await ctx.close().catch(() => {});
      await b!.close().catch(() => {});
      await launch();
      ({ page, ctx } = await open({ width: dim.w, height: dim.h }, dsf));
      cdp = await ctx.newCDPSession(page);
      for (let k = Math.max(0, at - WARM); k < at; k++) await page.evaluate(`window.__seek(${(k / FPS).toFixed(4)})`);
      if (why !== 'recycle') console.warn('[reelrender]', tpl.id, why, 'at frame', at, `- reopened (${crashes}/20)`);
    };
    for (let i = 0; i < N; i++) {
      if (encErr) throw encErr;
      if (Date.now() > deadline) throw new Error('The render took too long');
      let shot: { data: string };
      try {
        if (i > 0 && i % RECYCLE === 0) await reopen(i, 'recycle');
        await page.evaluate(`window.__seek(${(i / FPS).toFixed(4)})`);
        shot = await cdp.send('Page.captureScreenshot', { format: 'jpeg', quality: 92, optimizeForSpeed: true, clip }) as { data: string };
      } catch (e) {
        if (encErr || ++crashes > 20) throw e;
        await new Promise(r => setTimeout(r, Math.min(10000, 1500 * crashes))); // let the memory settle
        try { await reopen(i, 'page crashed: ' + String((e as Error).message).split('\n')[0].slice(0, 80)); } catch (e2) { console.warn('[reelrender] reopen failed', (e2 as Error).message.split('\n')[0]); }
        i--; continue;
      }
      if (!stdin.write(Buffer.from(shot.data, 'base64'))) await new Promise(r => stdin.once('drain', r));
      if (i % 15 === 0) report(5 + (i / N) * 93);
    }
    stdin.end();
    await b!.close().catch(() => {}); held.browser = null;
    await enc.done;
    if (errors.length > 20) console.warn('[reelrender]', tpl.id, 'page errors', errors.slice(0, 3));
    fs.renameSync(tmpOut, o.out);
    report(100);
    return { frames: N, duration: total, ms: Date.now() - t0, size: fs.statSync(o.out).size, w: OUT_W, h: OH, audio: pr.audio, tpl: tpl.id, theme: o.theme };
  } finally {
    if (held.browser) await held.browser.close().catch(() => {});
    server?.close();
    try { fs.unlinkSync(o.out + '.part.mp4'); } catch { /* gone or renamed */ }
    fs.rmSync(job, { recursive: true, force: true });
  }
}
