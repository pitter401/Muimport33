// v130: which Meta campaign / ad brought each visitor, channel join and chat — and what it led to (chats, sales, revenue).
// The ad's URL parameters carry the names: utm_campaign={{campaign.name}}&utm_term={{adset.name}}&utm_content={{ad.name}}
// Landing pages keep them in a cookie (af_cmp, set by the middleware) and on the visitor (visits.camp), so later pages,
// channel joins and the Telegram chat that follows all get the same campaign.
import { all, one, run } from './db';
import { getSettings, type Settings } from './settings';
import { dayRange, localDate, money, now, num, HttpError } from './util';
import { costSql } from './profit';
import { graphAll, dec, MetaError } from './metagraph';
import { OLD_ADS, campLabel, campAd, lineKey, type CampKind } from './chatchips';
export { OLD_ADS };

export type Camp = { camp: string; adset: string | null; ad: string | null };
export const CAMP_PARAMS = 'utm_source=fb&utm_campaign={{campaign.name}}&utm_term={{adset.name}}&utm_content={{ad.name}}';
const DAY = 86400000;

const clean = (v: unknown) => {
  const x = String(v ?? '').replace(/\+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 100);
  return x && !/\{\{.*\}\}/.test(x) ? x : ''; // "{{campaign.name}}" = a preview, not a real ad
};
// v131: Meta's own tags carry only IDs (ads made before our URL parameters) → one row "Old non-tracked ads"
export const BADGE = 'AdsBhai badge (client sites)';
const isId = (x: string | null | undefined) => !!x && /^\d{6,}$/.test(x);
const nice = (c: Camp | null): Camp | null => {
  if (!c) return c;
  // v161: the client (utm_source) is the "ad set" of the badge → the chip shows "AdsBhai badge (client sites) · alphatrader"
  if (c.camp === 'client_badge') { const cl = c.adset && !/^(client_badge|<.*>)$/.test(c.adset) ? c.adset : null; return { camp: BADGE, adset: cl, ad: cl }; }
  if (isId(c.camp)) return { camp: OLD_ADS, adset: null, ad: null };
  return { camp: c.camp, adset: isId(c.adset) ? null : c.adset, ad: isId(c.ad) ? null : c.ad };
};
let fixedOld = false;
/** Rows saved before v131 with ID-only names → the readable labels (once per process). */
function fixOldNames() {
  if (fixedOld) return; fixedOld = true;
  for (const tb of ['leads', 'channel_joins', 'visits']) {
    try {
      run(`UPDATE ${tb} SET camp=?, adset=NULL, ad=NULL WHERE camp IS NOT NULL AND camp!='' AND camp NOT GLOB '*[^0-9]*' AND length(camp)>=6`, OLD_ADS);
      run(`UPDATE ${tb} SET camp=?, adset=NULL, ad=NULL WHERE camp='client_badge'`, BADGE);
      run(`UPDATE ${tb} SET ad=NULL WHERE ad IS NOT NULL AND ad NOT GLOB '*[^0-9]*' AND length(ad)>=6`);
      run(`UPDATE ${tb} SET adset=NULL WHERE adset IS NOT NULL AND adset NOT GLOB '*[^0-9]*' AND length(adset)>=6`);
    } catch { /* column missing on a very old db */ }
  }
}
/** Campaign / ad set / ad from a page URL (?utm_campaign=…). */
export function utmOf(url: string | null | undefined): Camp | null {
  if (!url) return null;
  let p: URLSearchParams;
  try { p = new URL(url, 'https://x.invalid').searchParams; } catch { return null; }
  const camp = clean(p.get('utm_campaign') || p.get('campaign_name') || p.get('cmp'));
  if (!camp) return null;
  // v161: the "Ads by AdsBhai" badge on client sites: ?utm_source=<client>&utm_medium=popup&utm_campaign=client_badge → "Client badge" · <client>
  if (camp.toLowerCase() === 'client_badge') { const src = clean(p.get('utm_source')); return nice({ camp: 'client_badge', adset: src && !/^<.*>$/.test(src) ? src : null, ad: null }); }
  return nice({ camp, adset: clean(p.get('utm_term') || p.get('adset_name')) || null, ad: clean(p.get('utm_content') || p.get('ad_name')) || null });
}
/** The af_cmp cookie the middleware sets when someone lands from a tagged ad. */
export function campCookie(req: Request): Camp | null {
  const m = (req.headers.get('cookie') || '').match(/(?:^|;\s*)af_cmp=([^;]+)/);
  if (!m) return null;
  try {
    const a = JSON.parse(decodeURIComponent(m[1]));
    const camp = clean(a?.[0]);
    return camp ? nice({ camp, adset: clean(a[1]) || null, ad: clean(a[2]) || null }) : null;
  } catch { return null; }
}
/** This request's campaign: the page URL's tags, else the cookie. */
export const campOfReq = (req: Request, url?: string | null) => utmOf(url) || utmOf(req.headers.get('referer')) || campCookie(req);

/** Remember the campaign on the visitor (last tagged ad wins). */
export function noteVisitCamp(vid: string | null | undefined, c: Camp | null) {
  if (!vid || !c) return;
  run('INSERT OR IGNORE INTO visits(vid, theme, created_at) VALUES(?,?,?)', vid, '', now());
  run('UPDATE visits SET camp=?, adset=?, ad=?, camp_at=? WHERE vid=?', c.camp, c.adset, c.ad, now(), vid);
}
const fromVid = (vid: string | null | undefined): Camp | null => {
  if (!vid) return null;
  const v = one<Camp>("SELECT camp, adset, ad FROM visits WHERE vid=? AND COALESCE(camp,'')!=''", vid);
  return v || null;
};
type JoinRow = { id: number; vid: string | null; page_url: string | null; camp: string | null; adset: string | null; ad: string | null };
const joinCamp = (j: JoinRow | undefined): Camp | null => (j ? (j.camp ? { camp: j.camp, adset: j.adset, ad: j.ad } : fromVid(j.vid) || utmOf(j.page_url)) : null);
/** A lead's campaign: its visitor, its page URL, else the channel join of the same Telegram person (joined from an ad, wrote later). */
export function resolveLead(l: { vid?: string | null; page_url?: string | null; tg_chat_id?: string | null }): Camp | null {
  return fromVid(l.vid) || utmOf(l.page_url) || (l.tg_chat_id ? joinCamp(one<JoinRow>("SELECT id, vid, page_url, camp, adset, ad FROM channel_joins WHERE tg_user=? AND COALESCE(src,'bar')!='chat' ORDER BY (COALESCE(camp,'')!='') DESC, id DESC LIMIT 1", String(l.tg_chat_id))) : null);
}

/** Fill leads.camp / channel_joins.camp ('' = looked, none). Untagged recent ones are looked at again (a join or visit can come later). */
export function stampCamps() {
  fixOldNames();
  const t = now();
  const leads = all<{ id: number; vid: string | null; page_url: string | null; tg_chat_id: string | null }>(
    "SELECT id, vid, page_url, tg_chat_id FROM leads WHERE camp IS NULL OR (camp='' AND created_at>? AND COALESCE(camp_chk,0)<?) ORDER BY id DESC LIMIT 5000", t - 3 * DAY, t - 5 * 60000);
  for (const l of leads) {
    const c = resolveLead(l);
    run('UPDATE leads SET camp=?, adset=?, ad=?, camp_chk=? WHERE id=?', c?.camp || '', c?.adset || null, c?.ad || null, t, l.id);
  }
  const joins = all<JoinRow>("SELECT id, vid, page_url, camp, adset, ad FROM channel_joins WHERE COALESCE(src,'bar')!='chat' AND (camp IS NULL OR (camp='' AND created_at>? AND COALESCE(camp_chk,0)<?)) ORDER BY id DESC LIMIT 5000", t - 3 * DAY, t - 5 * 60000);
  for (const j of joins) {
    const c = fromVid(j.vid) || utmOf(j.page_url);
    run('UPDATE channel_joins SET camp=?, adset=?, ad=?, camp_chk=? WHERE id=?', c?.camp || '', c?.adset || null, c?.ad || null, t, j.id);
  }
  return leads.length + joins.length + stampWa();
}

/* ---- v142: WhatsApp chats — how they reached us (leads.camp_kind) + their campaign from the page click / community number ----
 * page      = tapped "chat" on a /…/whatsapp page (wa_clicks: the W-code in their first message, or linked by lead_id)
 * community = left their number on a /…/community page (wa_joins: linked by lead_id, or the same number within 2 days)
 * ctwa      = Click-to-WhatsApp ad (WATI's source id)
 * direct    = none of these, and our WhatsApp page tracking was already running when they wrote → messaged the number directly
 * unknown   = none of these, and we can't tell (chat older than the tracking) → "Old non-tracked ads"
 * A chat without a campaign gets the click's / number's campaign (camp, adset, ad), so the chip and the Campaigns page agree. */
const WA_WIN = 2 * DAY;
let lastWaRecheck = 0;
type WaL = { id: number; phone: string | null; created_at: number; camp: string | null; vid: string | null; page_url: string | null; wa_ad: string | null };
type WaSrc = { camp: string | null; adset: string | null; ad: string | null; vid: string | null; created_at?: number | null };
export function waKindOf(l: WaL): { kind: CampKind; src: WaSrc | null } {
  const digits = String(l.phone || '').replace(/\D/g, '');
  const ord = "ORDER BY (COALESCE(camp,'')!='') DESC, created_at DESC LIMIT 1";
  let click = one<WaSrc>(`SELECT camp, adset, ad, vid, created_at FROM wa_clicks WHERE lead_id=? ${ord}`, l.id);
  if (!click) {
    for (const m of all<{ text: string | null }>("SELECT text FROM messages WHERE lead_id=? AND dir='in' ORDER BY id LIMIT 3", l.id)) {
      const code = String(m.text || '').match(/\bW-([A-Za-z0-9]{8})\b/)?.[1];
      if (code) { click = one<WaSrc>('SELECT camp, adset, ad, vid, created_at FROM wa_clicks WHERE code=?', code); if (click) break; }
    }
  }
  if (click) return { kind: 'page', src: click };
  const join = one<WaSrc>(`SELECT camp, adset, ad, vid, created_at FROM wa_joins WHERE lead_id=? OR (?!='' AND phone=? AND created_at BETWEEN ? AND ?) ${ord}`, l.id, digits, digits, l.created_at - WA_WIN, l.created_at + WA_WIN);
  if (join) return { kind: 'community', src: join };
  if (l.wa_ad) return { kind: 'ctwa', src: null };
  if (l.vid || l.page_url) return { kind: 'page', src: null };
  const tracking = !!one('SELECT 1 FROM wa_clicks WHERE created_at<? LIMIT 1', l.created_at) || !!one('SELECT 1 FROM wa_joins WHERE created_at<? LIMIT 1', l.created_at);
  return { kind: tracking ? 'direct' : 'unknown', src: null };
}
function stampWaOne(l: WaL) {
  const { kind, src } = waKindOf(l);
  let c: Camp | null = null;
  if (!String(l.camp || '').trim() && src) c = src.camp ? nice({ camp: src.camp, adset: src.adset, ad: src.ad }) : fromVid(src.vid);
  if (c?.camp) run('UPDATE leads SET camp=?, adset=?, ad=?, camp_kind=? WHERE id=?', c.camp, c.adset || null, c.ad || null, kind, l.id);
  else run('UPDATE leads SET camp_kind=? WHERE id=?', kind, l.id);
}
/** New WhatsApp chats once; untagged ones of the last 3 days again (max every 5 minutes: a number / click can come later). */
export function stampWa() {
  const t = now();
  const recheck = t - lastWaRecheck > 5 * 60000;
  if (recheck) lastWaRecheck = t;
  const rows = all<WaL>(`SELECT id, phone, created_at, camp, vid, page_url, wa_ad FROM leads WHERE ch='wa' AND status!='merged' AND (camp_kind IS NULL${recheck ? " OR (COALESCE(camp,'')='' AND created_at>?)" : ''}) ORDER BY id DESC LIMIT 3000`, ...(recheck ? [t - 3 * DAY] : []));
  for (const l of rows) { try { stampWaOne(l); } catch { /* old db */ } }
  return rows.length;
}
/** v142: the chips of one chat row / chat header (the same helper the apps use). */
export function chipsOf(l: { ch?: string | null; camp?: string | null; ad?: string | null; camp_kind?: string | null; line?: string | null; tier?: string | null; biz?: string | null; service?: string | null; menu?: number | null }) {
  return { camp_label: campLabel(l), camp_ad: campAd(l), line_k: lineKey(l) };
}
/** One lead (chat screen). */
export function stampLead(id: number) {
  fixOldNames();
  const l = one<{ id: number; camp: string | null; created_at: number; camp_chk: number | null; vid: string | null; page_url: string | null; tg_chat_id: string | null }>('SELECT id, camp, created_at, camp_chk, vid, page_url, tg_chat_id FROM leads WHERE id=?', id);
  if (!l || (l.camp !== null && (l.camp !== '' || l.created_at < now() - 3 * DAY || num(l.camp_chk) > now() - 5 * 60000))) { stampWaLead(id); return; }
  const c = resolveLead(l);
  run('UPDATE leads SET camp=?, adset=?, ad=?, camp_chk=? WHERE id=?', c?.camp || '', c?.adset || null, c?.ad || null, now(), id);
  stampWaLead(id); // v142
}
/** v142: one WhatsApp chat (chat screen): how it reached us + the click's / number's campaign. */
export function stampWaLead(id: number) {
  const l = one<WaL & { ch: string | null; camp_kind: string | null }>('SELECT id, ch, phone, created_at, camp, vid, page_url, wa_ad, camp_kind FROM leads WHERE id=?', id);
  if (!l || l.ch !== 'wa' || (l.camp_kind && String(l.camp || '').trim())) return;
  try { stampWaOne(l); } catch { /* old db */ }
}

// ---- spend from Meta (optional): our ad accounts' insights per ad, in USD ----
type SpendRow = { camp: string; adset: string; ad: string; spend: number; msgs?: number };
const spendCache = new Map<string, { at: number; rows: SpendRow[]; err: string | null }>();
export const campActs = (s: Settings) => String(s.camp_acts || '').split(/[\s,]+/).map(x => x.replace(/^act_/i, '').replace(/\D/g, '')).filter(x => x.length >= 6).slice(0, 10);
async function metaSpend(s: Settings, f: number, t: number): Promise<{ rows: SpendRow[]; err: string | null }> {
  if (s.mads_on === '1') { // v151: the Meta switch — numbers already pulled into meta_insights (same app as Comments)
    const since = localDate(Math.max(f, Date.UTC(2020, 0, 1)), s), until = localDate(t - 1, s);
    const rows = all<{ camp: string; adset: string | null; ad: string | null; spend: number; msgs: number }>('SELECT camp, adset, ad, SUM(spend) spend, SUM(msgs) msgs FROM meta_insights WHERE date>=? AND date<=? GROUP BY camp, adset, ad', since, until)
      .map(r => ({ camp: clean(r.camp), adset: clean(r.adset || ''), ad: clean(r.ad || ''), spend: r.spend, msgs: r.msgs }));
    return { rows, err: s.mads_last_err || null };
  }
  const acts = campActs(s);
  if (!acts.length) return { rows: [], err: null };
  const since = localDate(Math.max(f, Date.UTC(2020, 0, 1)), s), until = localDate(t - 1, s);
  const key = `${acts.join(',')}|${since}|${until}`;
  const c = spendCache.get(key);
  if (c && c.at > now() - 10 * 60000) return c;
  const rows: SpendRow[] = [];
  const errs: string[] = [];
  const rate = num(s.inr_rate, 90) || 90;
  for (const act of acts) {
    let token = String(s.camp_token || '').trim();
    let secret: string | undefined, proxy: string | undefined;
    if (!token) { // the token of the BM this account is in (Ad accounts panel), if we have it
      const bm = one<{ token_enc: string; secret_enc: string | null; proxy_enc: string | null }>('SELECT b.token_enc, b.secret_enc, b.proxy_enc FROM meta_accounts a JOIN meta_bms b ON b.bm_id=a.bm_id WHERE a.act_id=? AND b.deleted=0', act);
      if (bm) { token = dec(bm.token_enc); secret = dec(bm.secret_enc) || undefined; proxy = dec(bm.proxy_enc) || undefined; }
    }
    if (!token) { errs.push(`act_${act}: no token`); continue; }
    // v166: never from the server IP — the BM's own proxy, else the Comments proxy, else the ad-account queue proxy
    proxy = proxy || String(s.cm_proxy || '').trim() || String(s.mq_proxy || '').trim() || undefined;
    if (!proxy) { errs.push(`act_${act}: add a proxy (Admin → Comments) — Meta is never called from the server IP`); continue; }
    try {
      const data = await graphAll<{ campaign_name?: string; adset_name?: string; ad_name?: string; spend?: string; account_currency?: string }>({ token, secret, proxy }, `act_${act}/insights`,
        { level: 'ad', fields: 'campaign_name,adset_name,ad_name,spend,account_currency', time_range: { since, until }, limit: 500 }, 10);
      for (const d of data) {
        const sp = num(d.spend);
        rows.push({ camp: clean(d.campaign_name), adset: clean(d.adset_name), ad: clean(d.ad_name), spend: d.account_currency === 'INR' ? sp / rate : sp });
      }
    } catch (e) { errs.push(`act_${act}: ${e instanceof MetaError ? e.message : (e as Error).message}`.slice(0, 160)); }
  }
  const out = { at: now(), rows, err: errs.length ? errs.join(' · ') : null };
  spendCache.set(key, out);
  if (spendCache.size > 50) spendCache.delete(spendCache.keys().next().value!);
  return out;
}

// ---- the Campaigns table ----
export type CampLine = 'all' | 'agency' | 'premium' | 'funnel';
type M = { visitors: number; forms: number; join_req: number; joined: number; still: number; join_chat: number; chats: number; sold: number; revenue: number; spend: number | null;
  // v137: sale-date mode extras
  topup_fees: number; web_sold: number; web_revenue: number; commission: number; acct_cost: number; earlier: number; wa_clicks: number; wa_comm: number; wa_comm_msg: number; manual_spend?: number; bot_info: number; bot_info_support: number; meta_msgs?: number };
const zero = (): M => ({ visitors: 0, forms: 0, join_req: 0, joined: 0, still: 0, join_chat: 0, chats: 0, sold: 0, revenue: 0, spend: null, topup_fees: 0, web_sold: 0, web_revenue: 0, commission: 0, acct_cost: 0, earlier: 0, wa_clicks: 0, wa_comm: 0, wa_comm_msg: 0, bot_info: 0, bot_info_support: 0 });
const NONE = '';
const WA = '\u0001wa'; // v137: "WhatsApp (no campaign)" card
export type CampMode = 'sales' | 'chats';
/** v137: the same line filter as Home (admin stats, no retargeting) for sales / topups — so the card totals equal Home. */
export function homeLineSql(ln: CampLine, tbl: 'sales' | 'topups') {
  if (ln === 'all') return '1=1';
  const NC = (a: string) => ` AND COALESCE(${a}.source,'')!='channel'`;
  const L = (a: string) => (ln === 'funnel' ? `${a}.line='funnel'${NC(a)}` : ln === 'agency' ? `COALESCE(${a}.line,'agency')!='funnel' AND COALESCE(${a}.tier,'')!='premium'${NC(a)}` : `COALESCE(${a}.line,'agency')!='funnel' AND ${a}.tier='premium'${NC(a)}`);
  const WAL = ln === 'funnel' ? "sales.line='funnel'" : ln === 'premium' ? "COALESCE(sales.line,'agency')!='funnel' AND sales.tier='premium'" : "COALESCE(sales.line,'agency')!='funnel' AND COALESCE(sales.tier,'')!='premium'";
  return `${tbl === 'sales' ? `(sales.lead_id IS NULL AND COALESCE(sales.wa,0)=1 AND ${WAL}) OR ` : ''}EXISTS(SELECT 1 FROM leads lx WHERE lx.id=${tbl}.lead_id AND ${L('lx')})${ln === 'agency' ? ` OR (${tbl}.lead_id IS NULL${tbl === 'sales' ? ' AND COALESCE(sales.wa,0)=0' : ''}) OR (${tbl}.lead_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM leads ly WHERE ly.id=${tbl}.lead_id))` : ''}`;
}
const LEAD_LINE = "(CASE WHEN l.line='funnel' OR l.biz='funnel' OR l.service='funnel' THEN 'funnel' WHEN l.tier='premium' THEN 'premium' ELSE 'agency' END)";
const PAGE_OF: Record<string, string[]> = { agency: ['agency', 'ch_agency', 'telegram'], premium: ['premium', 'ch_premium'], funnel: ['funnel', 'ch_funnel'] };

export type CampApp = 'all' | 'tg' | 'wa';
/** Campaigns page. mode 'sales' (default, v137): sold / revenue / fees = what was SOLD in the period (same rows as Home),
 *  credited to the campaign of the chat; 'chats': chats started in the period and their sales at any time (cohort).
 *  v137: every card is Telegram or WhatsApp (app filter). WhatsApp cards: visitors of the WhatsApp ad pages → chat taps →
 *  chats → community numbers → messaged → sold. Untagged: "No campaign tag" (Telegram) / "WhatsApp (no campaign)". */
export async function campaignStats(range: string | null, lineIn: unknown, modeIn: unknown = 'sales', appIn: unknown = 'all') {
  const s = getSettings();
  const mode: CampMode = modeIn === 'chats' ? 'chats' : 'sales';
  const app: CampApp = appIn === 'tg' || appIn === 'wa' ? appIn : 'all';
  const line: CampLine = lineIn === 'agency' || lineIn === 'premium' || lineIn === 'funnel' ? lineIn : 'all';
  stampCamps();
  const [f, t] = dayRange(range || 'today', s);
  // card key: Telegram "camp" / "" (no tag); WhatsApp "W|camp" / WA (no tag)
  const K = (camp: string | null, wa: unknown) => (wa ? (camp ? 'W|' + camp : WA) : camp || NONE);
  const camps = new Map<string, M & { ads: Map<string, M & { adset: string | null }> }>();
  const row = (k: string, ad: string | null, adset?: string | null) => {
    let c = camps.get(k);
    if (!c) { c = { ...zero(), ads: new Map() }; camps.set(k, c); }
    const ak = k && k !== WA ? ad || '' : '';
    let a = c.ads.get(ak);
    if (!a) { a = { ...zero(), adset: adset || null }; c.ads.set(ak, a); }
    return [c, a] as const;
  };
  const add = (k: string, ad: string | null, adset: string | null, key: keyof M, v = 1) => {
    for (const m of row(k, ad, adset)) (m[key] as number) = money(((m[key] as number) || 0) + v);
  };
  const LP = line === 'all' ? [] : [line];
  // visitors who landed from a tagged ad; WhatsApp = they saw a WhatsApp ad page (/…/whatsapp, /…/community)
  const pages = line === 'all' ? null : [...PAGE_OF[line], 'wa_' + line];
  const vis = all<Camp & { wa: number }>(`SELECT v.camp, v.adset, v.ad, EXISTS(SELECT 1 FROM page_visits p WHERE p.vid=v.vid AND p.page LIKE 'wa!_%' ESCAPE '!') wa FROM visits v
    WHERE v.camp_at>=? AND v.camp_at<? AND COALESCE(v.camp,'')!=''${pages ? ` AND EXISTS(SELECT 1 FROM page_visits p WHERE p.vid=v.vid AND p.page IN (${pages.map(() => '?').join(',')}))` : ''}`, f, t, ...(pages || []));
  for (const v of vis) add(K(v.camp, v.wa), v.ad, v.adset, 'visitors');
  // forms filled (website → Telegram)
  const lf = line === 'all' ? '' : ` AND ${LEAD_LINE}=?`;
  for (const l of all<Camp>(`SELECT l.camp, l.adset, l.ad FROM leads l WHERE l.source='form' AND l.created_at>=? AND l.created_at<? AND l.status!='merged'${lf}`, f, t, ...LP)) add(K(l.camp, 0), l.ad, l.adset, 'forms');
  // Telegram channel joins
  const jl = line === 'all' ? '' : ' AND COALESCE(j.line_x, j.line)=?';
  const joins = all<Camp & { tg_user: string; joined: number; still: number; wrote: number; info: number }>(`SELECT j.camp, j.adset, j.ad, j.tg_user, MAX(j.joined_at IS NOT NULL) joined, MAX(j.joined_at IS NOT NULL AND j.left_at IS NULL) still,
      EXISTS(SELECT 1 FROM leads l WHERE l.tg_chat_id=j.tg_user AND l.started_at IS NOT NULL AND l.status!='merged') wrote,
      EXISTS(SELECT 1 FROM bot_taps b WHERE b.tg_user=j.tg_user) info
    FROM channel_joins j WHERE j.requested_at>=? AND j.requested_at<? AND j.tg_user IS NOT NULL AND COALESCE(j.src,'bar')!='chat'${jl} GROUP BY COALESCE(j.camp,''), j.tg_user`, f, t, ...LP);
  for (const j of joins) {
    const k = K(j.camp, 0);
    add(k, j.ad, j.adset, 'join_req');
    if (j.joined) add(k, j.ad, j.adset, 'joined');
    if (j.still) add(k, j.ad, j.adset, 'still');
    if (j.wrote) add(k, j.ad, j.adset, 'join_chat');
    // v139: saw pricing / details in the bot (info buttons) → and of those, went on to message support
    if (j.info) { add(k, j.ad, j.adset, 'bot_info'); if (j.wrote) add(k, j.ad, j.adset, 'bot_info_support'); }
  }
  // WhatsApp: chat taps on the /…/whatsapp pages, numbers left on the /…/community pages and how many then messaged us
  const wl = line === 'all' ? '' : ' AND line=?';
  for (const x of all<Camp & { n: number }>(`SELECT camp, adset, ad, COUNT(*) n FROM wa_clicks WHERE created_at>=? AND created_at<?${wl} GROUP BY camp, adset, ad`, f, t, ...LP)) add(K(x.camp, 1), x.ad, x.adset, 'wa_clicks', x.n);
  for (const x of all<Camp & { n: number; m: number }>(`SELECT camp, adset, ad, COUNT(*) n, SUM(msg_at IS NOT NULL) m FROM wa_joins WHERE created_at>=? AND created_at<?${wl} GROUP BY camp, adset, ad`, f, t, ...LP)) {
    add(K(x.camp, 1), x.ad, x.adset, 'wa_comm', x.n);
    if (x.m) add(K(x.camp, 1), x.ad, x.adset, 'wa_comm_msg', x.m);
  }
  // chats that started in the range (cohort mode: + their sales at any time)
  const chats = all<Camp & { sold: number; revenue: number; wa: number }>(`SELECT l.camp, l.adset, l.ad, COALESCE(l.ch,'')='wa' wa, (l.status='sold' OR EXISTS(SELECT 1 FROM sales x WHERE x.lead_id=l.id)) sold,
      (SELECT COALESCE(SUM(x.amount),0) FROM sales x WHERE x.lead_id=l.id) + (SELECT COALESCE(SUM(o.amount),0) FROM web_orders o WHERE o.lead_id=l.id AND o.status='delivered') revenue
    FROM leads l WHERE l.started_at>=? AND l.started_at<? AND l.tg_chat_id IS NOT NULL AND l.status!='merged'${lf}`, f, t, ...LP);
  for (const c of chats) {
    const k = K(c.camp, c.wa);
    add(k, c.ad, c.adset, 'chats');
    if (mode === 'chats') {
      if (c.sold) add(k, c.ad, c.adset, 'sold');
      if (c.revenue > 0) add(k, c.ad, c.adset, 'revenue', c.revenue);
    }
  }
  if (mode === 'sales') {
    // sales MADE in the period (the same rows as Home), credited to the chat's campaign. WhatsApp = a WhatsApp sale or a WhatsApp chat.
    const SL = (tbl: 'sales' | 'topups') => `(${homeLineSql(line, tbl)})`;
    for (const x of all<Camp & { amount: number; commission: number; cost: number; wa: number; started: number | null }>(`SELECT l.camp, l.adset, l.ad, sales.amount, sales.commission, (SELECT ${costSql(s)} FROM sales s2 WHERE s2.id=sales.id) cost,
        ${WA_SALE('sales')} wa, l.started_at started
      FROM sales LEFT JOIN leads l ON l.id=sales.lead_id WHERE sales.created_at>=? AND sales.created_at<? AND ${SL('sales')}`, f, t)) {
      const k = K(x.camp, x.wa);
      add(k, x.ad, x.adset, 'sold'); add(k, x.ad, x.adset, 'revenue', num(x.amount)); add(k, x.ad, x.adset, 'commission', num(x.commission)); add(k, x.ad, x.adset, 'acct_cost', num(x.cost));
      if (x.started != null && x.started < f) add(k, x.ad, x.adset, 'earlier');
    }
    for (const x of all<Camp & { commission: number; wa: number }>(`SELECT l.camp, l.adset, l.ad, topups.commission, ${WA_SALE('topups')} wa
      FROM topups LEFT JOIN leads l ON l.id=topups.lead_id WHERE topups.created_at>=? AND topups.created_at<? AND ${SL('topups')}`, f, t))
      if (num(x.commission)) add(K(x.camp, x.wa), x.ad, x.adset, 'topup_fees', num(x.commission));
    if (line !== 'funnel') { // website orders (Agency business, like Home)
      const WT = line === 'premium' ? " AND o.tier='premium'" : line === 'agency' ? " AND COALESCE(o.tier,'')!='premium'" : '';
      for (const x of all<Camp & { amount: number; qty: number; kind: string }>(`SELECT l.camp, l.adset, l.ad, o.amount, o.qty, o.kind FROM web_orders o LEFT JOIN leads l ON l.id=o.lead_id
        WHERE o.status='delivered' AND o.delivered_at>=? AND o.delivered_at<?${WT}`, f, t)) {
        add(K(x.camp, 0), x.ad, x.adset, 'web_sold'); add(K(x.camp, 0), x.ad, x.adset, 'web_revenue', num(x.amount));
        if (x.kind === 'account') add(K(x.camp, 0), x.ad, x.adset, 'acct_cost', num(x.qty) * num(s.acct_cost, 3));
      }
    }
  }
  // spend (Meta, our ad accounts) — matched by campaign name and ad name (a WhatsApp campaign when only WhatsApp has it)
  const sp = await metaSpend(s, f, t).catch(e => ({ rows: [] as SpendRow[], err: (e as Error).message }));
  for (const r of sp.rows) {
    if (!r.camp || !(r.spend > 0)) continue;
    const k = !camps.has(r.camp) && camps.has('W|' + r.camp) ? 'W|' + r.camp : r.camp;
    if (line !== 'all' && !camps.has(k)) continue; // with a filter, only campaigns that brought that line
    for (const m of row(k, r.ad, r.adset)) { m.spend = money((m.spend || 0) + r.spend); if (r.msgs) m.meta_msgs = (m.meta_msgs || 0) + r.msgs; }
  }
  // WhatsApp ad spend typed by hand (Ad spend → WhatsApp lines) → the untagged WhatsApp card
  const manual = money(one<{ v: number }>(`SELECT COALESCE(SUM(amount),0) v FROM ad_spend WHERE line ${line === 'all' ? "IN ('wa_agency','wa_premium','wa_funnel')" : '= ?'} AND date>=? AND date<=?`, ...(line === 'all' ? [] : ['wa_' + line]), localDate(f, s), localDate(t - 1, s))?.v || 0);
  if (manual > 0) { const [c] = row(WA, null, null); c.spend = money((c.spend || 0) + manual); c.manual_spend = manual; }
  const prof = <T extends M>(m: T) => {
    const profit = m.spend != null ? money(m.revenue + m.topup_fees + m.web_revenue - m.commission - m.acct_cost - m.spend) : null;
    return { ...m, profit, roi: profit != null && m.spend ? Math.round(profit / m.spend * 100) : null };
  };
  const out = [...camps.entries()].map(([k, c]) => {
    const wa = k === WA || k.startsWith('W|');
    const camp = k === WA || k === NONE ? null : wa ? k.slice(2) : k;
    return {
      camp, app: wa ? 'wa' : 'tg', kind: camp ? 'camp' : wa ? 'wa' : 'none', ...prof(strip(c)),
      ads: camp ? [...c.ads.entries()].map(([ad, a]) => ({ ad: ad || null, ...prof(strip(a)) })).sort(byValue) : [],
    };
  }).filter(r => app === 'all' || r.app === app)
    .sort((a, b) => (a.camp ? 0 : 1) - (b.camp ? 0 : 1) || byValue(a, b));
  return { range: range || 'today', line, mode, app, wa_ads_on: s.wa_ads_on === '1' || s.wa_comm_ads_on === '1', from: f, to: t, rows: out, params: CAMP_PARAMS, spend_on: campActs(s).length > 0 || s.mads_on === '1', meta_on: s.mads_on === '1', spend_err: sp.err, inr_rate: num(s.inr_rate, 90) || 90 };
}
/** v137: a sale / top-up is WhatsApp when it was added as a WhatsApp sale or made in a WhatsApp chat (Home uses the same rule). */
export const WA_SALE = (tbl: 'sales' | 'topups') => `(COALESCE(${tbl}.wa,0)=1 OR EXISTS(SELECT 1 FROM leads lw WHERE lw.id=${tbl}.lead_id AND COALESCE(lw.ch,'')='wa'))`;
const strip = <T extends M>(m: T) => { const { ads: _a, ...r } = m as T & { ads?: unknown }; void _a; return r as Omit<T, 'ads'>; };
const byValue = (a: M, b: M) => b.revenue - a.revenue || b.sold - a.sold || b.chats - a.chats || b.join_req - a.join_req || b.visitors - a.visitors;

/** Admin settings for the spend pull. */
export function saveCampSpend(b: Record<string, unknown>, set: (k: string, v: string) => void) {
  const acts = String(b.camp_acts ?? '').split(/[\s,]+/).map(x => x.replace(/^act_/i, '').replace(/\D/g, '')).filter(Boolean);
  if (acts.some(a => a.length < 6)) throw new HttpError(400, 'Ad account ID looks wrong (numbers only)');
  set('camp_acts', acts.slice(0, 10).join(','));
  if (typeof b.camp_token === 'string' && b.camp_token.trim() && !/^•+$/.test(b.camp_token.trim())) set('camp_token', b.camp_token.trim());
  if (b.camp_token === '') set('camp_token', '');
  spendCache.clear();
  return { ok: true };
}

// ---- v131: campaign planner — pick the ad type, get every name (campaign / ad sets / ads), the link and the event ----
export const PLAN_KINDS: Record<string, { label: string; prefix: string; path: string | null; event: string; pixel: string; dest: string }> = {
  lead_agency: { label: 'Leads → Agency page', prefix: 'AG-LEAD', path: '/', event: 'Lead', pixel: 'Agency pixel', dest: 'Website' },
  lead_premium: { label: 'Leads → Premium page', prefix: 'PR-LEAD', path: '/premium', event: 'Lead', pixel: 'Agency pixel', dest: 'Website' },
  lead_funnel: { label: 'Leads → Funnel page', prefix: 'FN-LEAD', path: '/funnel', event: 'Lead', pixel: 'Funnel pixel', dest: 'Website' },
  tg_agency: { label: 'Telegram channel → Agency', prefix: 'AG-TG', path: '/agency/telegram', event: 'Subscribe', pixel: 'Agency pixel', dest: 'Website' },
  tg_premium: { label: 'Telegram channel → Premium', prefix: 'PR-TG', path: '/premium/telegram', event: 'Subscribe', pixel: 'Agency pixel', dest: 'Website' },
  tg_funnel: { label: 'Telegram channel → Funnel', prefix: 'FN-TG', path: '/funnel/telegram', event: 'Subscribe', pixel: 'Funnel pixel', dest: 'Website' },
  wa_agency: { label: 'WhatsApp chat → Agency', prefix: 'AG-WA', path: '/agency/whatsapp', event: 'Lead', pixel: 'WhatsApp pixel (Agency + Premium)', dest: 'Website' },
  wa_premium: { label: 'WhatsApp chat → Premium', prefix: 'PR-WA', path: '/premium/whatsapp', event: 'Lead', pixel: 'WhatsApp pixel (Agency + Premium)', dest: 'Website' },
  wa_funnel: { label: 'WhatsApp chat → Funnel', prefix: 'FN-WA', path: '/funnel/whatsapp', event: 'Lead', pixel: 'WhatsApp Funnel pixel', dest: 'Website' },
  wac_agency: { label: 'WhatsApp community → Agency', prefix: 'AG-WAC', path: '/agency/community', event: 'Subscribe', pixel: 'WhatsApp pixel (Agency + Premium)', dest: 'Website' },
  wac_premium: { label: 'WhatsApp community → Premium', prefix: 'PR-WAC', path: '/premium/community', event: 'Subscribe', pixel: 'WhatsApp pixel (Agency + Premium)', dest: 'Website' },
  wac_funnel: { label: 'WhatsApp community → Funnel', prefix: 'FN-WAC', path: '/funnel/community', event: 'Subscribe', pixel: 'WhatsApp Funnel pixel', dest: 'Website' },
  ctwa_agency: { label: 'Click-to-WhatsApp (straight to the number) → Agency', prefix: 'AG-CTWA', path: null, event: 'Conversations (messages)', pixel: 'none: Meta counts the chats', dest: 'WhatsApp' },
  ctwa_funnel: { label: 'Click-to-WhatsApp (straight to the number) → Funnel', prefix: 'FN-CTWA', path: null, event: 'Conversations (messages)', pixel: 'none: Meta counts the chats', dest: 'WhatsApp' },
};
const part = (v: unknown, max = 30) => String(v ?? '').replace(/[|&?=#{}]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max);
export function planNames(b: Record<string, unknown>, site: string) {
  const k = PLAN_KINDS[String(b.kind)];
  if (!k) throw new HttpError(400, 'Choose the ad type');
  const hook = part(b.hook) || 'Hook1', country = part(b.country, 12) || 'IN', creative = part(b.creative, 16) || 'Reel';
  const sets = Math.max(1, Math.min(10, Math.floor(num(b.adsets, 1)))), ads = Math.max(1, Math.min(10, Math.floor(num(b.ads, 2))));
  const auds = String(b.audiences || '').split(',').map(x => part(x, 24));
  const campaign = `${k.prefix} - ${hook} - ${country}`;
  const adsets = Array.from({ length: sets }, (_, i) => {
    const aud = auds[i] || auds[0] || '';
    return { name: `${campaign} - AS${i + 1}${aud ? ' ' + aud : ''}`, ads: Array.from({ length: ads }, (_, j) => `${k.prefix} - ${hook} - AS${i + 1} - ${creative} ${String.fromCharCode(65 + j)}`) };
  });
  const url = k.path ? site.replace(/\/$/, '') + k.path : null;
  return { kind: String(b.kind), label: k.label, campaign, adsets, url, params: k.path ? CAMP_PARAMS : null, event: k.event, pixel: k.pixel, dest: k.dest, hook, country, creative, audiences: auds.filter(Boolean).join(', '), n_adsets: sets, n_ads: ads };
}
export const listPlans = () => all<{ id: number; kind: string; name: string; data: string; created_at: number }>('SELECT * FROM camp_plans ORDER BY id DESC LIMIT 100').map(r => ({ ...JSON.parse(r.data), id: r.id, created_at: r.created_at }));
export function savePlan(b: Record<string, unknown>, site: string) {
  const p = planNames(b, site);
  if (one('SELECT 1 FROM camp_plans WHERE name=?', p.campaign)) throw new HttpError(409, `A plan named "${p.campaign}" is already saved. Change the hook name (e.g. Hook2).`);
  run('INSERT INTO camp_plans(kind, name, data, created_at) VALUES(?,?,?,?)', p.kind, p.campaign, JSON.stringify(p), now());
  return { ok: true, plan: p };
}
export const delPlan = (id: unknown) => { run('DELETE FROM camp_plans WHERE id=?', num(id)); return { ok: true }; };
