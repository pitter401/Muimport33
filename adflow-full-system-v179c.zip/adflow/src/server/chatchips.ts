// v142: the two chips every chat row and chat header shows, for Telegram AND WhatsApp — one helper for the server
// (chat lists, the chat screen) and the apps, so the text is the same everywhere.
//  1. the campaign chip: the lead's Meta campaign (leads.camp, the same value the Campaigns page counts the chat under),
//     else a fallback: "Old non-tracked ads" (no tag / can't tell), WhatsApp only: "Direct WhatsApp" (clearly messaged
//     the number with no page click), "Community" (left their number on the community page; + the campaign if any).
//  2. the line badge: Funnel / Premium / Agency, or a grey "Non-tracked" when the line is truly unknown.
// No database access here (the apps import it).

export const OLD_ADS = 'Old non-tracked ads';
export const DIRECT_WA = 'Direct WhatsApp';
export const COMMUNITY = 'Community';
/** leads.camp_kind (WhatsApp, set by stampCamps): how the chat reached us. */
export type CampKind = 'page' | 'community' | 'ctwa' | 'direct' | 'unknown';

export type ChipLead = { ch?: string | null; camp?: string | null; camp_kind?: string | null };
/** The campaign chip text. Never empty. */
export function campLabel(l: ChipLead): string {
  const camp = String(l.camp ?? '').trim();
  if (l.ch === 'wa') {
    if (l.camp_kind === 'community') return camp ? `${COMMUNITY} · ${camp}` : COMMUNITY;
    if (camp) return camp;
    return l.camp_kind === 'direct' ? DIRECT_WA : OLD_ADS;
  }
  return camp || OLD_ADS;
}
/** The ad shown after the campaign (only with a real campaign). */
export const campAd = (l: ChipLead & { ad?: string | null }) => (String(l.camp ?? '').trim() ? l.ad || null : null);

export type LineKey = 'funnel' | 'premium' | 'agency' | 'unknown';
export type LineLead = { line?: string | null; tier?: string | null; biz?: string | null; service?: string | null; menu?: number | null };
/** The same line rule as the Campaigns / Home filters: funnel, else premium, else agency.
 *  'unknown' = the line was never set, or a WhatsApp chat still has the "which one do you want?" menu open. */
export function lineKey(l: LineLead): LineKey {
  if (l.line === 'funnel' || l.biz === 'funnel' || l.service === 'funnel') return 'funnel';
  if (l.tier === 'premium') return 'premium';
  if (Number(l.menu) === 1) return 'unknown';
  if (!String(l.line ?? '').trim()) return 'unknown';
  return 'agency';
}
export const LINE_BADGE: Record<LineKey, string> = { funnel: 'Funnel', premium: 'Premium', agency: 'Agency', unknown: 'Non-tracked' };
