/** v135: Admin → "Telegram vs WhatsApp": what happened on each app in a period (chats, messages, sales) and which line earns the most
 *  (Agency / Premium / Funnel × Telegram / WhatsApp): revenue + top-up fees − ad spend − account cost − commission. Admin only. */
import { all, one } from './db';
import { getSettings } from './settings';
import { money, localDate, avgReplyMs } from './util';
import { costSql, ensureAutoSpend } from './profit';

type Ch = 'tg' | 'wa';
type Ln = 'agency' | 'premium' | 'funnel';
const CHS: Ch[] = ['tg', 'wa'];
const LNS: Ln[] = ['agency', 'premium', 'funnel'];
const CH = (a: string) => `CASE WHEN ${a}.ch='wa' OR ${a}.tg_chat_id LIKE 'wa:%' THEN 'wa' ELSE 'tg' END`;
const LN = (a: string) => `CASE WHEN ${a}.line='funnel' THEN 'funnel' WHEN ${a}.tier='premium' THEN 'premium' ELSE 'agency' END`;
const LEAD_AT = 'COALESCE(l.started_at, l.assigned_at, l.created_at)';
/** Ad spend lines that bring people to each app. Landing pages (Agency / Premium / Funnel) and the channel pages open Telegram; wa_* = WhatsApp ad pages. */
const SPEND: Record<Ch, Record<Ln, string[]>> = {
  tg: { agency: ['agency', 'telegram', 'ch_agency'], premium: ['premium', 'ch_premium'], funnel: ['funnel', 'ch_funnel'] },
  wa: { agency: ['wa_agency'], premium: ['wa_premium'], funnel: ['wa_funnel'] },
};

export function channelReport(f: number, t: number) {
  const s = getSettings();
  try { ensureAutoSpend(s); } catch { /* spend rows are best-effort */ }
  const z = () => ({ leads: 0, sales: 0, revenue: 0, fees: 0, topups: 0, spend: 0, acct: 0, comm: 0, profit: 0 });
  const grid: Record<Ch, Record<Ln, ReturnType<typeof z>>> = { tg: { agency: z(), premium: z(), funnel: z() }, wa: { agency: z(), premium: z(), funnel: z() } };
  // new chats
  for (const r of all<{ c: Ch; l: Ln; n: number }>(`SELECT ${CH('l')} c, ${LN('l')} l, COUNT(*) n FROM leads l WHERE ${LEAD_AT}>=? AND ${LEAD_AT}<? AND l.status!='merged' AND l.tg_chat_id IS NOT NULL GROUP BY c, l`, f, t)) grid[r.c][r.l].leads = r.n;
  // sales in the apps (by the chat they came from) + WhatsApp sales added by hand (WhatsApp Business number)
  for (const r of all<{ c: Ch; l: Ln; n: number; v: number; k: number; m: number }>(`SELECT CASE WHEN COALESCE(x.wa,0)=1 THEN 'wa' ELSE ${CH('l')} END c,
      CASE WHEN COALESCE(x.wa,0)=1 THEN (CASE WHEN x.line='funnel' THEN 'funnel' WHEN x.tier='premium' THEN 'premium' ELSE 'agency' END) ELSE ${LN('l')} END l,
      COUNT(*) n, COALESCE(SUM(x.amount),0) v, COALESCE(SUM(${costSql(s).replace(/\b(cost|service|qty)\b/g, 'x.$1')}),0) k, COALESCE(SUM(x.commission),0) m
    FROM sales x LEFT JOIN leads l ON l.id=x.lead_id WHERE x.created_at>=? AND x.created_at<? GROUP BY c, l`, f, t)) {
    const g = grid[r.c]?.[r.l]; if (!g) continue;
    g.sales += r.n; g.revenue += r.v; g.acct += r.k; g.comm += r.m;
  }
  // top-ups: our fee is the profit
  for (const r of all<{ c: Ch; l: Ln; v: number; fee: number }>(`SELECT CASE WHEN COALESCE(x.wa,0)=1 OR l.id IS NULL THEN (CASE WHEN COALESCE(x.wa,0)=1 THEN 'wa' ELSE 'tg' END) ELSE ${CH('l')} END c,
      CASE WHEN l.id IS NULL THEN 'agency' ELSE ${LN('l')} END l, COALESCE(SUM(x.amount),0) v, COALESCE(SUM(x.commission),0) fee
    FROM topups x LEFT JOIN leads l ON l.id=x.lead_id WHERE x.created_at>=? AND x.created_at<? GROUP BY c, l`, f, t)) {
    const g = grid[r.c]?.[r.l]; if (!g) continue;
    g.topups += r.v; g.fees += r.fee;
  }
  // ad spend per page
  const sp: Record<string, number> = {};
  for (const r of all<{ line: string; v: number }>('SELECT line, COALESCE(SUM(amount),0) v FROM ad_spend WHERE date>=? AND date<=? GROUP BY line', localDate(f, s), localDate(t - 1, s))) sp[r.line] = r.v;
  for (const c of CHS) for (const l of LNS) {
    const g = grid[c][l];
    g.spend = money(SPEND[c][l].reduce((a, k) => a + (sp[k] || 0), 0));
    for (const k of ['revenue', 'fees', 'topups', 'acct', 'comm'] as const) g[k] = money(g[k]);
    g.profit = money(g.revenue + g.fees - g.spend - g.acct - g.comm);
  }
  const sum = (c: Ch) => LNS.reduce((a, l) => { const g = grid[c][l]; for (const k of Object.keys(a) as (keyof typeof a)[]) a[k] = money(a[k] + g[k]); return a; }, z());
  const tot = { tg: sum('tg'), wa: sum('wa') };
  // what is going on in each app
  const act = (c: Ch) => {
    const w = `${CH('l')}='${c}'`;
    const msg = one<{ i: number; o: number; ch: number }>(`SELECT COALESCE(SUM(m.dir='in'),0) i, COALESCE(SUM(m.dir='out'),0) o, COUNT(DISTINCT CASE WHEN m.dir='in' THEN m.lead_id END) ch
      FROM messages m JOIN leads l ON l.id=m.lead_id WHERE ${w} AND m.created_at>=? AND m.created_at<?`, f, t)!;
    const open = one<{ n: number }>(`SELECT COUNT(*) n FROM leads l WHERE ${w} AND l.status='active'`)!.n;
    const unanswered = one<{ n: number }>(`SELECT COUNT(*) n FROM leads l WHERE ${w} AND l.status='active' AND COALESCE(l.last_in_at,0) > COALESCE(l.last_out_at,0) AND l.last_in_at>=?`, f)?.n || 0;
    const resp = avgReplyMs(all<{ started_at: number; assigned_at: number | null; first_reply_at: number }>(`SELECT l.started_at, l.assigned_at, l.first_reply_at FROM leads l WHERE ${w} AND l.first_reply_at IS NOT NULL AND l.started_at>=? AND l.started_at<?`, f, t), s); // working hours only
    return { msgs_in: msg.i, msgs_out: msg.o, chats_active: msg.ch, open, unanswered, avg_reply_min: resp == null ? null : Math.round(resp / 60000) };
  };
  // WhatsApp ad pages (/…/whatsapp = chat button, /…/community = join with your number) and Telegram channel pages
  const waPages = Object.fromEntries(LNS.map(l => {
    const c = one<{ n: number; lead: number }>('SELECT COUNT(*) n, COALESCE(SUM(lead_id IS NOT NULL),0) lead FROM wa_clicks WHERE line=? AND created_at>=? AND created_at<?', l, f, t)!;
    const j = one<{ n: number; m: number; sub: number }>("SELECT COUNT(*) n, COALESCE(SUM(msg_at IS NOT NULL),0) m, COALESCE(SUM(sub_state='sent'),0) sub FROM wa_joins WHERE line=? AND created_at>=? AND created_at<?", l, f, t)!;
    const v = one<{ n: number }>('SELECT COUNT(*) n FROM page_visits WHERE page=? AND created_at>=? AND created_at<?', 'wa_' + l, f, t)!.n;
    return [l, { visitors: v, chat_taps: c.n, chats: c.lead, community_numbers: j.n, messaged: j.m, subscribed: j.sub }];
  }));
  const tgPages = Object.fromEntries(LNS.map(l => {
    const j = one<{ n: number; jn: number }>("SELECT COUNT(*) n, COALESCE(SUM(joined_at IS NOT NULL),0) jn FROM channel_joins WHERE src='ad' AND line_x=? AND requested_at>=? AND requested_at<?", l, f, t);
    const v = one<{ n: number }>('SELECT COUNT(*) n FROM page_visits WHERE page=? AND created_at>=? AND created_at<?', 'ch_' + l, f, t)!.n;
    return [l, { visitors: v, join_requests: j?.n || 0, joined: j?.jn || 0 }];
  }));
  const rows = CHS.flatMap(c => LNS.map(l => ({ ch: c, line: l, ...grid[c][l] })));
  const best = [...rows].filter(r => r.profit > 0).sort((a, b) => b.profit - a.profit)[0] || null; // only a line that made money
  return { grid, total: tot, activity: { tg: act('tg'), wa: act('wa') }, wa_pages: waPages, tg_pages: tgPages, best: best ? { ch: best.ch, line: best.line, profit: best.profit } : null };
}
