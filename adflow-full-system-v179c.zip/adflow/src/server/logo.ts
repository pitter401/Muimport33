import fs from 'fs';
import path from 'path';
import { getSettings, setSetting } from './settings';
import { HttpError } from './util';

const DIR = () => path.join(path.dirname(process.env.DB_PATH || path.join(process.cwd(), 'data', 'adflow.db')), 'brand');
const TYPES: Record<string, string> = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp', 'image/svg+xml': 'svg' };

/** Saves the uploaded logo next to the database (data/brand/) — survives updates and rebuilds. */
export async function saveLogo(file: File | null) {
  const dir = DIR();
  fs.mkdirSync(dir, { recursive: true });
  const old = getSettings().logo_file;
  if (old) try { fs.unlinkSync(path.join(dir, old)); } catch { /* gone */ }
  if (!file) { setSetting('logo_file', ''); setSetting('logo_mode', 'auto'); setSetting('logo_ver', String(Date.now())); return; }
  const ext = TYPES[file.type];
  if (!ext) throw new HttpError(400, 'Logo must be PNG, JPG, WEBP or SVG');
  if (file.size > 2 * 1024 * 1024) throw new HttpError(400, 'Logo must be smaller than 2 MB');
  const buf = Buffer.from(await file.arrayBuffer());
  if (ext === 'svg' && /<script|on\w+\s*=|javascript:/i.test(buf.toString('utf8'))) throw new HttpError(400, 'This SVG contains scripts. Upload a PNG instead.');
  const name = `logo.${ext}`;
  fs.writeFileSync(path.join(dir, name), buf);
  setSetting('logo_file', name);
  setSetting('logo_mode', 'upload');
  setSetting('logo_ver', String(Date.now()));
}

export function readLogo(): { buf: Buffer; type: string } | null {
  const f = getSettings().logo_file;
  if (!f) return null;
  try {
    const buf = fs.readFileSync(path.join(DIR(), f));
    const ext = f.split('.').pop()!;
    return { buf, type: Object.entries(TYPES).find(([, e]) => e === ext)?.[0] || 'application/octet-stream' };
  } catch { return null; }
}
