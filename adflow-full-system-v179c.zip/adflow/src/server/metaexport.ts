/** v137: Meta-ready files per app (Admin → Export). Every file is in Meta's customer-list / offline-event format with the
 *  match keys SHA-256 hashed the way Meta wants them: lowercase + trimmed; phone = E.164 digits with the country code
 *  (Settings default_cc); external_id = the same hashed id we send with CAPI. No BM names, no notes — only match keys + value.
 *   apps: tg_chat (Telegram chats) · tg_channel (Telegram channel ads) · wa (WhatsApp) · web (website forms) · all */
import { all } from './db';
import { getSettings, type Settings } from './settings';
import { dayRange, sha256 } from './util';
import { normPhone } from './capi';

export type ExApp = 'all' | 'tg_chat' | 'tg_channel' | 'wa' | 'web';
export type ExKind = 'buyers' | 'people' | 'nonbuyers' | 'purchases' | 'wa_community' | 'wa_taps' | 'ch_nomsg' | 'ch_left' | 'ch_info_nomsg';
export const AUD_COLS = ['email', 'phone', 'fn', 'ln', 'ct', 'country', 'external_id', 'value'];
export const PUR_COLS = ['email', 'phone', 'fn', 'ln', 'ct', 'country', 'external_id', 'event_name', 'event_time', 'value', 'currency', 'order_id'];
const CC_COUNTRY: Record<string, string> = { '91': 'in', '1': 'us', '55': 'br', '44': 'gb', '971': 'ae', '880': 'bd', '92': 'pk', '977': 'np', '62': 'id', '63': 'ph', '234': 'ng' };

const hx = (v: unknown) => { const x = String(v ?? '').trim().toLowerCase(); return x ? sha256(x) : ''; };
/** Phone → E.164 digits (no +) → SHA-256. '' when not a phone. */
export function hashPhone(p: unknown, s: Settings) { const n = normPhone(String(p ?? ''), s.default_cc || '91'); return n ? sha256(n) : ''; }
export const e164 = (p: unknown, s: Settings) => normPhone(String(p ?? ''), s.default_cc || '91') || '';
/** The external_id we send with CAPI for this person (visitor id first, else the lead). */
export const extId = (x: { vid?: string | null; id?: number | null }) => (x.vid ? sha256('v_' + x.vid) : x.id ? sha256('lead_' + x.id) : '');
const country = (s: Settings) => { const c = CC_COUNTRY[String(s.default_cc || '91').replace(/\D/g, '')]; return c ? sha256(c) : ''; };

type P = { id?: number | null; vid?: string | null; name?: string | null; phone?: string | null; email?: string | null; value?: number | null };
function audRow(p: P, s: Settings): string[] {
  const parts = String(p.name || '').trim().split(/\s+/).filter(Boolean);
  return [hx(p.email), hashPhone(p.phone, s), hx(parts[0]), parts.length > 1 ? hx(parts[parts.length - 1]) : '', '', country(s), extId(p), String(Math.round((Number(p.value) || 0) * 100) / 100)];
}

export const EX_APPS: [ExApp, string][] = [['all', 'All'], ['tg_chat', 'Telegram chats'], ['tg_channel', 'Telegram channel'], ['wa', 'WhatsApp'], ['web', 'Website forms']];
export const EX_GUIDE: Record<ExApp, string> = {
  all: 'Everyone from every app in one list. Best for a broad lookalike when one app alone is too small (Meta needs about 100 matched people).',
  tg_chat: 'Running ads that open a Telegram chat? Download Buyers (lookalike seed), Non-buyers (retarget / exclude) and Offline purchases (teach Meta who buys).',
  tg_channel: 'Running Telegram channel ads? Download these 3 files: Everyone who asked to join (lookalike), Joined but never messaged (retarget them to chat), and Buyers.',
  wa: 'Running WhatsApp ads? WhatsApp always has the phone number, the strongest match. Download Buyers, Non-buyers, Community numbers and Offline purchases.',
  web: 'Running landing page ads with the form? Download Buyers, Non-buyers and Offline purchases (form phone + email match best).',
};
const USE_AUD = 'Meta → Audiences → Create audience → Custom audience → Customer list';
export const EX_CARDS: Record<ExKind, { title: string; use: string }> = {
  buyers: { title: 'Buyers (lookalike seed)', use: USE_AUD + ' (with value) → then Lookalike 1%' },
  people: { title: 'Everyone (retargeting / lookalike)', use: USE_AUD + ' → retarget, or Lookalike 1-3%' },
  nonbuyers: { title: 'Talked but never bought', use: USE_AUD + ' → retarget with an offer, or exclude from cold ads' },
  purchases: { title: 'Offline purchases', use: 'Meta → Events Manager → your dataset → Upload offline events (Purchase)' },
  wa_community: { title: 'WhatsApp community numbers', use: USE_AUD + ' → retarget people who left their number' },
  wa_taps: { title: 'Chat taps who never messaged', use: USE_AUD + ' (external_id only) → retarget' },
  ch_nomsg: { title: 'Joined the channel, never messaged', use: USE_AUD + ' → retarget them to start a chat' },
  ch_left: { title: 'Left the channel', use: USE_AUD + ' → exclude, or win back' },
  ch_info_nomsg: { title: 'Saw pricing in the bot, never messaged support', use: USE_AUD + ' → retarget them with an offer' }, // v139
};
export const kindsOf = (app: ExApp): ExKind[] => app === 'wa' ? ['buyers', 'people', 'nonbuyers', 'purchases', 'wa_community', 'wa_taps']
  : app === 'tg_channel' ? ['people', 'ch_nomsg', 'ch_info_nomsg', 'ch_left', 'buyers', 'nonbuyers', 'purchases'] : ['buyers', 'people', 'nonbuyers', 'purchases'];

/** One Meta file: header + rows (hashed). */
export function metaFile(app: ExApp, kind: ExKind, range: string | null, lineIn: string | null): { cols: string[]; rows: string[][] } {
  const s = getSettings();
  const [f, t] = dayRange(range || 'all', s);
  const ln = lineIn === 'agency' || lineIn === 'premium' || lineIn === 'funnel' ? lineIn : '';
  const LW = (a: string) => (ln === 'funnel' ? ` AND ${a}.line='funnel'` : ln === 'premium' ? ` AND COALESCE(${a}.line,'agency')!='funnel' AND ${a}.tier='premium'` : ln === 'agency' ? ` AND COALESCE(${a}.line,'agency')!='funnel' AND COALESCE(${a}.tier,'')!='premium'` : '');
  const isWa = (a: string) => `(COALESCE(${a}.ch,'')='wa' OR COALESCE(${a}.tg_chat_id,'') LIKE 'wa:%')`;
  const APPW = (a: string) => app === 'wa' ? ` AND ${isWa(a)}` : app === 'tg_chat' ? ` AND ${a}.tg_chat_id IS NOT NULL AND NOT ${isWa(a)}` : app === 'web' ? ` AND ${a}.source='form'`
    : app === 'tg_channel' ? ` AND (${a}.source='channel' OR EXISTS(SELECT 1 FROM channel_joins cj WHERE cj.tg_user=${a}.tg_chat_id))` : '';
  const VAL = (a: string) => `(SELECT COALESCE(SUM(amount),0) FROM sales WHERE lead_id=${a}.id) + (SELECT COALESCE(SUM(amount),0) FROM web_orders WHERE lead_id=${a}.id AND status='delivered')`;
  const BUY = (a: string) => `(${a}.status='sold' OR EXISTS(SELECT 1 FROM sales x WHERE x.lead_id=${a}.id))`;
  if (kind === 'purchases') {
    const rows = all<any>(`SELECT x.id sid, x.amount, x.created_at sat, x.cust_name, x.cust_phone, x.wa, l.id, l.vid, l.name, l.phone, l.email FROM sales x LEFT JOIN leads l ON l.id=x.lead_id
      WHERE x.created_at>=? AND x.created_at<? AND (l.id IS NOT NULL${APPW('l')}${LW('l')}${app === 'wa' && !ln ? " OR (x.lead_id IS NULL AND COALESCE(x.wa,0)=1)" : ''}) ORDER BY x.id`, f, t);
    return { cols: PUR_COLS, rows: rows.map(x => { const a = audRow({ id: x.id, vid: x.vid, name: x.name || x.cust_name, phone: x.phone || x.cust_phone, email: x.email }, s); return [...a.slice(0, 7), 'Purchase', String(Math.floor(x.sat / 1000)), String(x.amount), 'USD', 'S' + x.sid]; }) };
  }
  if (kind === 'wa_community') {
    const rows = all<any>(`SELECT DISTINCT phone, vid FROM wa_joins WHERE created_at>=? AND created_at<?${ln ? ' AND line=?' : ''}`, f, t, ...(ln ? [ln] : []));
    return { cols: AUD_COLS, rows: rows.map(x => audRow({ vid: x.vid, phone: x.phone }, s)) };
  }
  if (kind === 'wa_taps') {
    const rows = all<any>(`SELECT DISTINCT vid FROM wa_clicks WHERE created_at>=? AND created_at<? AND lead_id IS NULL AND vid IS NOT NULL${ln ? ' AND line=?' : ''}`, f, t, ...(ln ? [ln] : []));
    return { cols: AUD_COLS, rows: rows.map(x => audRow({ vid: x.vid }, s)) };
  }
  if (app === 'tg_channel' && (kind === 'people' || kind === 'ch_nomsg' || kind === 'ch_left' || kind === 'ch_info_nomsg')) {
    const lx = ln ? ' AND COALESCE(j.line_x, j.line)=?' : '';
    const w = kind === 'ch_nomsg' ? ' AND j.joined_at IS NOT NULL AND l.id IS NULL' : kind === 'ch_left' ? ' AND j.left_at IS NOT NULL'
      : kind === 'ch_info_nomsg' ? ' AND l.id IS NULL AND EXISTS(SELECT 1 FROM bot_taps b WHERE b.tg_user=j.tg_user)' : '';
    const rows = all<any>(`SELECT j.tg_user, MAX(j.vid) vid, l.id, l.name, l.phone, l.email, ${'(SELECT COALESCE(SUM(amount),0) FROM sales WHERE lead_id=l.id)'} value FROM channel_joins j
      LEFT JOIN leads l ON l.id=(SELECT id FROM leads WHERE tg_chat_id=j.tg_user AND status!='merged' ORDER BY id DESC LIMIT 1)
      WHERE j.tg_user IS NOT NULL AND j.requested_at>=? AND j.requested_at<?${lx}${w} GROUP BY j.tg_user ORDER BY MIN(j.id)`, f, t, ...(ln ? [ln] : []));
    // external_id = the hashed visitor id Meta got with Subscribe (else the lead's)
    return { cols: AUD_COLS, rows: rows.map(x => audRow({ id: x.vid ? null : x.id, vid: x.vid, name: x.name, phone: x.phone, email: x.email, value: x.value }, s)) };
  }
  const w = kind === 'buyers' ? ` AND ${BUY('l')}` : kind === 'nonbuyers' ? ` AND l.started_at IS NOT NULL AND NOT ${BUY('l')}` : '';
  const rows = all<any>(`SELECT l.id, l.vid, l.name, l.phone, l.email, ${VAL('l')} value FROM leads l WHERE l.created_at>=? AND l.created_at<? AND l.status!='merged'${APPW('l')}${LW('l')}${w} ORDER BY l.id`, f, t);
  // one row per person (same phone / email = same person)
  const seen = new Set<string>(); const out: string[][] = [];
  for (const x of rows) { const r = audRow(x, s); const k = r[1] || r[0] || r[6]; if (k && seen.has(k)) continue; if (k) seen.add(k); out.push(r); }
  return { cols: AUD_COLS, rows: out };
}
/** How many rows have each match key (% of rows). */
export function matchKeys(cols: string[], rows: string[][]) {
  const pc = (c: string) => { const i = cols.indexOf(c); return rows.length && i >= 0 ? Math.round(rows.filter(r => r[i]).length / rows.length * 100) : 0; };
  return { phone: pc('phone'), email: pc('email'), external_id: pc('external_id') };
}
export function metaCards(app: ExApp, range: string | null, line: string | null) {
  return kindsOf(app).map(kind => { const fl = metaFile(app, kind, range, line); return { kind, ...EX_CARDS[kind], total: fl.rows.length, keys: matchKeys(fl.cols, fl.rows) }; });
}
export const csvOf = (cols: string[], rows: string[][]) => [cols.join(','), ...rows.map(r => r.map(v => /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v).join(','))].join('\n');
