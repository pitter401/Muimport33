/**
 * AdsBhai AI (Claude): agent coach, auto-replies, Test Lab and voice notes.
 *  - Coach  : for every chat, suggests the next step + 2-3 ready replies to the agent (ON by default once the key is set).
 *  - Auto   : answers the chats of the agents/manager the admin picked (OFF by default). Waits until the customer stops
 *             typing, answers a burst of messages together, tags (reply_to) the message it answers, hands over to a person
 *             when needed (call, angry, paid, UPI, bot question, unknown), makes the crypto payment link, sets reminders.
 *  - Test Lab: question library + auto grading + the admin's corrections (which become examples).
 * Everything is driven by the knowledge sheet + examples in Admin → AI. Prices always come from Settings.
 */
import fs from 'fs';
import { isVendorAuto } from './wati';
export { isVendorAuto };
import path from 'path';
import { one, all, run, EMPTY_IN_SQL } from './db';
import { getSettings, setSetting, bizOf, priceFor, leadOffer, routeOf, type Settings, type Biz } from './settings';
import { addMsg, markVoiceOff, leadById, notifyAgent, agentById, setReminder, managerId, type Lead } from './crm';
import { tg, uploadFile, downloadFile, extractMedia, sendFileId } from './telegram';
import { mediaDuration } from './audiodur';
import { createHash } from 'crypto';
import { now, num, money, HttpError, voiceBlocked } from './util';
import { DEFAULT_KNOWLEDGE, SEED_EXAMPLES, SEED_EXAMPLES_V3, SEED_EXAMPLES_V9, SEED_EXAMPLES_V10, SEED_CASES, KNOWLEDGE_V9, KNOWLEDGE_V10, KNOWLEDGE_V11, KNOWLEDGE_V12 } from './ai_seed';
import { publicUrl } from './email';
import { voiceFx, buildOfficeBed, type NoiseLevel } from './voicefx';

export const DEFAULT_MODEL = 'claude-haiku-5-5';
const API = () => process.env.ANTHROPIC_BASE || 'https://api.anthropic.com';
const EL_API = () => process.env.ELEVENLABS_BASE || 'https://api.elevenlabs.io';
const DAY = 86400000;

/* ---------------- setup ---------------- */
let seeded = false;
/** tests only: run the seed / migrations again */
export const __reseed = () => { seeded = false; };
export function ensureSeed() {
  if (seeded) return;
  seeded = true;
  if (!one('SELECT 1 FROM ai_examples LIMIT 1'))
    for (const e of [...SEED_EXAMPLES, ...SEED_EXAMPLES_V3]) run("INSERT INTO ai_examples(title, biz, chat, source, on_, created_at) VALUES(?,?,?,'seed',1,?)", e.title, e.biz, e.chat, now());
  if (!one('SELECT 1 FROM ai_cases LIMIT 1'))
    for (const c of SEED_CASES) run('INSERT INTO ai_cases(title, biz, turns, expect, facts, created_at) VALUES(?,?,?,?,?,?)', c.title, c.biz, JSON.stringify(c.turns), c.expect, c.facts || CASE_FACTS[c.title] || '', now());
  // v65: follow-up cases added to an existing library (once)
  if (num(getSettings().ai_seed_ver) < 2) {
    for (const c of SEED_CASES.filter(x => x.title.startsWith('Follow-up:')))
      if (!one('SELECT 1 FROM ai_cases WHERE title=?', c.title)) run('INSERT INTO ai_cases(title, biz, turns, expect, facts, created_at) VALUES(?,?,?,?,?,?)', c.title, c.biz, JSON.stringify(c.turns), c.expect, CASE_FACTS[c.title] || '', now());
    setSetting('ai_seed_ver', '2');
  }
  if (num(getSettings().ai_seed_ver) < 4) {
    for (const c of SEED_CASES.filter(x => x.title === 'Normal price — no full access'))
      if (!one('SELECT 1 FROM ai_cases WHERE title=?', c.title)) run('INSERT INTO ai_cases(title, biz, turns, expect, facts, created_at) VALUES(?,?,?,?,?,?)', c.title, c.biz, JSON.stringify(c.turns), c.expect, '', now());
  }
  if (num(getSettings().ai_seed_ver) < 3) {
    for (const e of SEED_EXAMPLES_V3)
      if (!one('SELECT 1 FROM ai_examples WHERE title=?', e.title)) run("INSERT INTO ai_examples(title, biz, chat, source, on_, created_at) VALUES(?,?,?,'seed',1,?)", e.title, e.biz, e.chat, now());
    // rules Akash tightened: no disclaimers on niches; abusive customer → handoff
    for (const c of SEED_CASES.filter(x => ['Betting niche', 'Customer swears'].includes(x.title))) run('UPDATE ai_cases SET expect=? WHERE title=?', c.expect, c.title);
    run("DELETE FROM ai_examples WHERE source='seed' AND title='Abusive customer → calm + handoff'");
    for (const c of SEED_CASES.filter(x => ['Why free replacement', 'Full access ask', 'Scam fear with abuse'].includes(x.title)))
      if (!one('SELECT 1 FROM ai_cases WHERE title=?', c.title)) run('INSERT INTO ai_cases(title, biz, turns, expect, facts, created_at) VALUES(?,?,?,?,?,?)', c.title, c.biz, JSON.stringify(c.turns), c.expect, '', now());
    setSetting('ai_seed_ver', '3');
  }
  if (num(getSettings().ai_seed_ver) < 7) {
    for (const c of SEED_CASES.filter(x => x.title === 'Follow-up: hot lead asked payment method')) run('UPDATE ai_cases SET expect=? WHERE title=?', c.expect, c.title);
    if (num(getSettings().ai_seed_ver) >= 6) setSetting('ai_seed_ver', '7');
  }
  if (num(getSettings().ai_seed_ver) < 6) {
    for (const c of SEED_CASES.filter(x => x.title === 'Follow-up: hot lead asked payment method')) run('UPDATE ai_cases SET expect=? WHERE title=?', c.expect, c.title);
    if (num(getSettings().ai_seed_ver) >= 5) setSetting('ai_seed_ver', '7');
  }
  if (num(getSettings().ai_seed_ver) < 5) {
    for (const c of SEED_CASES.filter(x => x.title === 'Follow-up: hot lead asked payment method')) run('UPDATE ai_cases SET expect=? WHERE title=?', c.expect, c.title);
    setSetting('ai_seed_ver', '7');
  }
  // v86: Akash's reply rules — seed examples without emojis / "risk zero", new Test Lab cases, the price case expectation
  if (num(getSettings().ai_seed_ver) < 8) {
    const EMO = /\s?[👍🙂🙏😊😄🔥✅]/gu;
    const g = [...SEED_EXAMPLES, ...SEED_EXAMPLES_V3].find(e => e.title === 'Gambling niche + ban worry');
    if (g) run("UPDATE ai_examples SET chat=? WHERE source='seed' AND title=? AND chat LIKE '%risk zero%'", g.chat, g.title);
    for (const r of all<{ id: number; chat: string }>("SELECT id, chat FROM ai_examples WHERE source='seed'")) run('UPDATE ai_examples SET chat=? WHERE id=?', r.chat.replace(EMO, '').replace(/,? aapka risk zero hai/gi, ''), r.id);
    for (const c of SEED_CASES.filter(x => ['Price of ad account'].includes(x.title))) run('UPDATE ai_cases SET expect=? WHERE title=?', c.expect, c.title);
    for (const c of SEED_CASES.filter(x => ['Pain: sellers took money', 'Top-up fee before buying', 'Account first, top-up later', 'Wants account before paying'].includes(x.title)))
      if (!one('SELECT 1 FROM ai_cases WHERE title=?', c.title)) run('INSERT INTO ai_cases(title, biz, turns, expect, facts, created_at) VALUES(?,?,?,?,?,?)', c.title, c.biz, JSON.stringify(c.turns), c.expect, '', now());
    const k = getSettings().ai_knowledge || '';
    if (k.trim()) setSetting('ai_knowledge', k.replace(/,? aapka risk zero hai/gi, '').replace(/"Sir hamare accounts strong hote hai, aur kabhi koi issue aaye to replacement free hai"/g, '"Kabhi koi issue aaye to replacement free hai sir"'));
    setSetting('ai_seed_ver', '8');
  }
  // v87: Akash's Test Lab round 2 — competitor, bulk order, call, verified, swearing, English; no emojis at all; voice defaults
  if (num(getSettings().ai_seed_ver) < 9) {
    const ANY_EMO = /\s?(?:(?![\u2190-\u21FF])[\p{Extended_Pictographic}\u{1F3FB}-\u{1F3FF}\uFE0F\u200D])+/gu; // arrows (↪ = quoted reply) are not emojis
    for (const r of all<{ id: number; chat: string }>("SELECT id, chat FROM ai_examples WHERE source='seed'")) run('UPDATE ai_examples SET chat=? WHERE id=?', r.chat.replace(ANY_EMO, ''), r.id);
    const five = SEED_EXAMPLES.find(e => e.title === '5 accounts, no BM yet');
    if (five) run("UPDATE ai_examples SET chat=? WHERE source='seed' AND title=?", five.chat, five.title);
    for (const e of SEED_EXAMPLES_V9)
      if (!one('SELECT 1 FROM ai_examples WHERE title=?', e.title)) run("INSERT INTO ai_examples(title, biz, chat, source, on_, created_at) VALUES(?,?,?,'seed',1,?)", e.title, e.biz, e.chat, now());
    const changed = ['Competitor cheaper', 'Wants 5 accounts', 'Call request', 'Verified or not?', 'Customer swears', 'Our BM name?'];
    for (const c of SEED_CASES.filter(x => changed.includes(x.title))) {
      run('UPDATE ai_cases SET expect=? WHERE title=?', c.expect, c.title);
      run("UPDATE ai_cases SET out=NULL, verdict=NULL, reason=NULL, run_at=NULL WHERE title=? AND mark IS NULL AND fix IS NULL", c.title); // old result was graded against the old rule
    }
    for (const c of SEED_CASES.filter(x => ['Call: number confirmed', '5 accounts, ready to pay', 'English: ad account price'].includes(x.title)))
      if (!one('SELECT 1 FROM ai_cases WHERE title=?', c.title)) run('INSERT INTO ai_cases(title, biz, turns, expect, facts, created_at) VALUES(?,?,?,?,?,?)', c.title, c.biz, JSON.stringify(c.turns), c.expect, '', now());
    const k = getSettings().ai_knowledge || '';
    if (k.trim()) setSetting('ai_knowledge', KNOWLEDGE_V9(k));
    const s9 = getSettings();
    if (!String(s9.el_voice_id || '').trim()) setSetting('el_voice_id', 'IDtcuDsxYTOIGN7AjCvp');
    if (!String(s9.el_model || '').trim() || s9.el_model === 'eleven_multilingual_v2') setSetting('el_model', 'eleven_v4');
    setSetting('ai_seed_ver', '9');
  }
  // v95: Akash's Test Lab round 3 — soft payment ask, repeat buyer, top-up, profit in writing, "paid", funnel budget, own account
  if (num(getSettings().ai_seed_ver) < 10) {
    for (const e of SEED_EXAMPLES_V10)
      if (!one('SELECT 1 FROM ai_examples WHERE title=?', e.title)) run("INSERT INTO ai_examples(title, biz, chat, source, on_, created_at) VALUES(?,?,?,'seed',1,?)", e.title, e.biz, e.chat, now());
    const changed = ['Gives BM ID and ready', 'Repeat customer BM', 'Top-up below minimum', 'Profit guarantee in writing', 'Paid already', 'Ad budget question', 'Multiple questions English'];
    for (const c of SEED_CASES.filter(x => changed.includes(x.title))) {
      run('UPDATE ai_cases SET expect=? WHERE title=?', c.expect, c.title);
      run("UPDATE ai_cases SET out=NULL, verdict=NULL, reason=NULL, run_at=NULL WHERE title=? AND mark IS NULL AND fix IS NULL", c.title);
    }
    // v87's emoji clean-up also removed the ↪ quote marks from sample chats → put them back
    for (const e of [...SEED_EXAMPLES, ...SEED_EXAMPLES_V3].filter(x => x.chat.includes('↪')))
      run("UPDATE ai_examples SET chat=? WHERE source='seed' AND title=? AND chat NOT LIKE '%↪%'", e.chat.replace(/\s?(?:(?![\u2190-\u21FF])[\p{Extended_Pictographic}\uFE0F])+/gu, ''), e.title);
    const k = getSettings().ai_knowledge || '';
    if (k.trim()) setSetting('ai_knowledge', KNOWLEDGE_V10(k));
    setSetting('ai_seed_ver', '10');
  }
  // v102: full access prices — normal $45, Premium $70 (from settings, never typed in the text)
  if (num(getSettings().ai_seed_ver) < 11) {
    const fx = SEED_EXAMPLES_V3.concat(SEED_EXAMPLES).find(e => e.title === 'Full access account');
    if (fx) run("UPDATE ai_examples SET chat=? WHERE source='seed' AND title=?", fx.chat.replace(/\s?(?:(?![\u2190-\u21FF])[\p{Extended_Pictographic}\u{1F3FB}-\u{1F3FF}\uFE0F\u200D])+/gu, ''), fx.title);
    for (const c of SEED_CASES.filter(x => x.title === 'Full access ask')) {
      run('UPDATE ai_cases SET expect=? WHERE title=?', c.expect, c.title);
      run("UPDATE ai_cases SET out=NULL, verdict=NULL, reason=NULL, run_at=NULL WHERE title=? AND mark IS NULL AND fix IS NULL", c.title);
    }
    const k = getSettings().ai_knowledge || '';
    if (k.trim()) setSetting('ai_knowledge', KNOWLEDGE_V11(k));
    setSetting('ai_seed_ver', '11');
  }
  if (num(getSettings().ai_seed_ver) < 12) { // v134: sold / one-account / test-first / WhatsApp lab cases
    for (const c of SEED_CASES.filter(x => x.facts))
      if (!one('SELECT 1 FROM ai_cases WHERE title=?', c.title)) run('INSERT INTO ai_cases(title, biz, turns, expect, facts, created_at) VALUES(?,?,?,?,?,?)', c.title, c.biz, JSON.stringify(c.turns), c.expect, c.facts || '', now());
    setSetting('ai_seed_ver', '12');
  }
  if (num(getSettings().ai_seed_ver) < 13) { // v137: truth cases (greetings only, WATI rule text, short voice note)
    for (const c of SEED_CASES.filter(x => x.title.startsWith('Truth:')))
      if (!one('SELECT 1 FROM ai_cases WHERE title=?', c.title)) run('INSERT INTO ai_cases(title, biz, turns, expect, facts, created_at) VALUES(?,?,?,?,?,?)', c.title, c.biz, JSON.stringify(c.turns), c.expect, c.facts || '', now());
    setSetting('ai_seed_ver', '13');
  }
}
const CASE_FACTS: Record<string, string> = {
  'Repeat customer BM': 'Earlier purchase: 1 ad account. Their Business Manager ID used before: 98765432.',
  'Top-up old account': 'Their ad account from us: 1234567890 (in BM 98765432).',
};

export const aiReady = (s: Settings = getSettings()) => !!s.ai_key;
export const autoAgents = (s: Settings = getSettings()) => String(s.ai_auto_agents || '').split(',').map(x => num(x)).filter(Boolean);
/** Is the AI answering this chat by itself right now? */
export function aiActiveFor(lead: Pick<Lead, 'agent_id'> & { ai_state?: string | null }, s: Settings = getSettings()) {
  return s.ai_auto_on === '1' && aiReady(s) && !!lead.agent_id && autoAgents(s).includes(lead.agent_id) && lead.ai_state !== 'paused';
}

/* ---------------- Claude ---------------- */
type Tool = { name: string; description: string; input_schema: Record<string, unknown> };
const today = () => new Date(now() + num(getSettings().tz_offset_min, 330) * 60000).toISOString().slice(0, 10);
export function aiCostToday() { return one<{ v: number }>('SELECT COALESCE(SUM(cost),0) v FROM ai_usage WHERE day=?', today())!.v; }

/** v134: official prices ($ per 1M tokens) of the models we use — the cost meter stays right when the coach uses another model. */
const MODEL_PRICE: Record<string, [number, number]> = { 'claude-opus-5-5': [4, 20], 'claude-sonnet-5-5': [2, 10], 'claude-haiku-5-5': [0.1, 0.5] };
/** v136: models that refuse a forced tool_choice ("type tool and any are not supported for this model") → ask with auto + a clear instruction. */
const NO_FORCED_TOOL = new Set<string>();
async function claude(s: Settings, kind: string, system: string, user: unknown, tool: Tool, maxTokens = 900, modelIn?: string): Promise<any> {
  const model = (modelIn || '').trim() || s.ai_model || DEFAULT_MODEL;
  if (!s.ai_key) throw new HttpError(400, 'Add the Anthropic API key in Admin → AI → Setup');
  const cap = num(s.ai_daily_cap, 3);
  if (cap > 0 && aiCostToday() >= cap) throw new HttpError(429, `Today's AI budget ($${cap}) is used up — Admin → AI → Setup`);
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 60000);
  let r: Response;
  let j: any = {};
  for (let attempt = 0; ; attempt++) {
  const auto = NO_FORCED_TOOL.has(model);
  try {
    r = await fetch(API() + '/v1/messages', {
      method: 'POST', signal: ctl.signal,
      headers: { 'x-api-key': s.ai_key, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
      body: JSON.stringify({
        model, max_tokens: maxTokens,
        system: [{ type: 'text', text: system, cache_control: { type: 'ephemeral' } }, ...(auto ? [{ type: 'text', text: `Always answer by calling the ${tool.name} tool exactly once. Do not write any other text.` }] : [])],
        messages: [{ role: 'user', content: user }],
        tools: [tool], tool_choice: auto ? { type: 'auto' } : { type: 'tool', name: tool.name },
      }),
    });
  } catch (e) { clearTimeout(timer); throw new HttpError(502, 'AI did not answer: ' + ((e as Error).name === 'AbortError' ? 'timeout' : (e as Error).message)); }
  // busy / rate-limited → one more try after a short wait
  if ((r.status === 429 || r.status === 529 || r.status === 503) && attempt === 0) { await new Promise(res => setTimeout(res, 2500)); continue; }
  j = await r.json().catch(() => ({}));
  if (r.status === 400 && !auto && attempt < 3 && /tool_choice/i.test(String(j?.error?.message || ''))) { NO_FORCED_TOOL.add(model); continue; }
  break;
  }
  clearTimeout(timer);
  if (!r.ok) throw new HttpError(502, 'AI error: ' + (j?.error?.message || r.status));
  const u = j.usage || {};
  const pin = modelIn && MODEL_PRICE[model] ? MODEL_PRICE[model][0] : num(s.ai_price_in, 1), pout = modelIn && MODEL_PRICE[model] ? MODEL_PRICE[model][1] : num(s.ai_price_out, 5);
  const cost = ((u.input_tokens || 0) * pin + (u.cache_creation_input_tokens || 0) * pin * 1.25 + (u.cache_read_input_tokens || 0) * pin * 0.1 + (u.output_tokens || 0) * pout) / 1e6;
  run(`INSERT INTO ai_usage(day, kind, calls, tin, tout, cost) VALUES(?,?,1,?,?,?)
       ON CONFLICT(day, kind) DO UPDATE SET calls=calls+1, tin=tin+excluded.tin, tout=tout+excluded.tout, cost=cost+excluded.cost`,
    today(), kind, (u.input_tokens || 0) + (u.cache_read_input_tokens || 0) + (u.cache_creation_input_tokens || 0), u.output_tokens || 0, cost);
  const out = (j.content || []).find((c: any) => c.type === 'tool_use')?.input;
  if (!out) throw new HttpError(502, 'AI gave no answer');
  return out;
}

/* ---------------- prompt ---------------- */
export function knowledgeText(s: Settings = getSettings()) {
  const k = (s.ai_knowledge || '').trim() || DEFAULT_KNOWLEDGE;
  const site = publicUrl().replace(/^https?:\/\//, '').replace(/\/$/, '') || 'adsbhai.com';
  return k.replace(/\{brand\}/g, s.brand_name || 'AdsBhai').replace(/\{site\}/g, site)
    .replace(/\{price_account_full\}/g, String(num(s.price_account_full, 45))).replace(/\{price_premium_full\}/g, String(num(s.price_premium_full, 60))).replace(/\{price_account\}/g, String(num(s.price_account))).replace(/\{price_funnel\}/g, String(num(s.price_funnel)))
    .replace(/\{topup_pct\}/g, String(num(s.topup_comm_pct, 3))).replace(/\{topup_min\}/g, String(num(s.topup_min, 30)));
}

/** Premium chats (from /premium): their prices + what Premium includes. */
function premiumNote(s: Settings) {
  const items = String(s.premium_bullets || '').split('\n').map(x => x.trim()).filter(Boolean).join('; ');
  return `\n# PREMIUM customer\nThis customer came from our PREMIUM page (${s.premium_title || 'Premium agency ad account'}). Quote ONLY the Premium prices below, never the normal price. Premium includes: ${items}. Delivery within ${s.premium_delivery || s.delivery_time}.\n`;
}
type PLead = { tier?: string | null; offer_until?: number | null; service?: string | null; line?: string | null } | null | undefined;
function systemPrompt(s0: Settings, biz: Biz, lead?: PLead) {
  const tier = lead?.tier;
  const s = priceFor(s0, lead); // Premium prices + this chat's retargeting offer
  const o = leadOffer(s0, lead);
  const ex = all<{ title: string; chat: string; source: string }>(
    "SELECT title, chat, source FROM ai_examples WHERE on_=1 AND (biz=? OR biz='any' OR biz IS NULL) ORDER BY CASE source WHEN 'correction' THEN 0 WHEN 'agent' THEN 1 WHEN 'sold' THEN 2 WHEN 'admin' THEN 3 ELSE 4 END, id DESC LIMIT 60", biz).reverse();
  const chName = (lead as { ch?: string | null } | null | undefined)?.ch === 'wa' ? 'WhatsApp' : 'Telegram';
  // v135: an edited knowledge sheet gets the stage rules (sold = support, one account = never ask its ID, WhatsApp) at run time
  const k0 = String(s.ai_knowledge || '');
  const know = knowledgeText({ ...s, ai_knowledge: k0.trim() ? KNOWLEDGE_V12(k0) : '' });
  return `You write ${chName} chat replies to a customer for ${s.brand_name || 'AdsBhai'}, exactly like our best human sales agent would.
The customer is in a ${biz === 'funnel' ? 'FUNNEL (landing page + funnel setup)' : 'AGENCY (ad accounts + top-ups)'} chat on ${chName}.

# How to write
- Reply in the SAME language and script as the customer's latest message(s): Roman Hinglish → Roman Hinglish; Devanagari Hindi → Devanagari; English → English; Bengali → Bengali; any other language → that language.
- Sound like a real person on ${chName}: usually ONE short message (two only when really needed, never more), simple everyday words, no lists, no markdown, no headings, no long paragraphs. Always address the customer as "sir".
- When the customer writes Roman Hinglish: type like Indian agents really do — Hindi mixed with simple English words ("Sorry sir, but…", "within 1 hour", "provide kar denge", "payment", "account", "start karna hai?"). Not formal Hindi, not robotic. When the customer writes English, write simple, friendly English — no Hindi words at all.
- No chatbot phrases ("Great question", "I understand your concern", "Feel free to", "Rest assured", "Hope this helps") and no sales hype ("best in market", "amazing", "100% trusted"). Plain and direct, like a busy agent typing on his phone. Don't start every message the same way ("Thik hai sir…"), don't repeat the customer's question back, don't thank them for every message.
- Emojis: never. Not one.
- If the customer sent several short messages, read them all and answer together. When a message answers one specific question among several, set reply_to to that customer message's #id.
- Ask one thing at a time. Sale order: understand the need → price (when asked) → when to start → payment link (only when they say they are ready) → AFTER payment ask for the BM ID → the manager shares the account → top-ups later.
- First read the Facts and decide the stage: NEW LEAD (no purchase, still asking) / READY (said they want to start now) / PAYMENT LINK SENT / PAID, waiting for the account / SOLD (support mode) / complaint or disabled account. Answer for THAT stage only.

# HARD RULES — these override the knowledge sheet and the examples below
1. Answer ONLY what the customer asked in their latest message(s). Do not add facts they did not ask about.
2. Never repeat something WE already said earlier in this chat (price, "1 ghante mein", replacement, etc.) unless the customer asks for it again.
3. Customer shares a bad experience or fear (scam, "paisa leke block kar dete hai", account disabled before): first acknowledge it like a person ("Haan sir, market mein bahut logon ke saath aisa hua hai"), then give ONE reason to trust us (free replacement because we earn from the top-up fee, OR "chaho to pehle 1 account se try karo"). Never answer their pain with our rules.
4. Never say "risk zero", "100% safe", "guarantee", "ban nahi hoga", "fixed rule", "hamara rule hai" or anything that sounds like a guarantee or like ego.
5. Customer wants the account before paying / "pehle account do, ads chalake payment dunga": ONE short polite message, e.g. "Sorry sir, but payment se pehle hum account share nahi kar sakte. Aap payment kar dijiye, within 1 hour account provide kar denge." Do not ask for the BM ID here, do not repeat the price.
6. Know the stage. "No purchase yet" in the facts = we have no sale on THIS chat: if they only ask the top-up fee, give it and note that top-up is done after the account is live; never ask how much they want to top up. If they say "pehle account, top-up baad mein" → just "Thik hai sir, account kab lena hai aapko?". But if they ASK FOR a top-up, never tell them they have no account from us (they may have bought on another number). Which account: the facts say exactly ONE ad account from us → that is the account, never ask for its ID (just confirm the amount + fee); several accounts and they did not say which → ask which one; none known → ask for their ad account ID.
7. Ask for the Business Manager (BM) ID only after the customer has paid or clearly says they are paying now. Never before.
8. Prices: use ONLY the numbers under "Current prices" below. Never write any other price. Don't give a total for several accounts unless the customer asks for it.
9. Language: the LANGUAGE line in the request says which language the customer uses — every message must be in that language (an English customer gets English only, also in follow-ups).
10. No emojis at all.
11. Never sound pushy: no "karna hoga", "karna padega", "abhi karna" — ask softly ("aap payment kar dijiye", "jab aap ready ho").
12. Never doubt the customer or say "dikh nahi raha" about payments — you cannot see payments; the manager checks them.
13. STAGE: SOLD in the facts = support mode: answer their question, help with top-ups, the account, replacements and trust. Never restart the sale (no "kis cheez ke ads", no price pitch, no payment link unless they ask to pay), never ask again for the BM ID or the ad account ID. If THEY ask for another account → the repeat-customer flow (payment method → link → after payment confirm the old BM). A customer who wants to "test first" (the account, the service, a small top-up before a bigger one): agree warmly, suggest starting small (minimum top-up), no pressure, no deadline.
14. Never ask for anything the facts already give (BM ID, ad account ID, business, niche, phone number) — use it ("Pichli baar wala BM (ID …)").
15. This chat is on ${chName}. ${chName === 'WhatsApp' ? 'Calls and messages happen on WhatsApp — never ask them to move to Telegram; we already have their number.' : 'Calls: phone or Telegram call (see Knowledge).'}
- Never repeat a message we already sent. Never sound like a template. Never say you are an AI and never claim to be a human.

# Knowledge (the only facts you may use)
${know}

# Current prices (always use these — prices, fees and delivery times inside the examples may be old)
${tier === 'premium' ? premiumNote(s) : ''}${o ? `\n# OFFER for this customer (came from our retargeting ad)\n${o.text} Tell the customer about it when price comes up. The prices below already include it.\n` : ''}Ad account: $${num(s.price_account)} · Funnel: $${num(s.price_funnel)}/month · Top-up fee: ${num(s.topup_comm_pct, 3)}% (minimum top-up $${num(s.topup_min, 30)})
Ad account delivery: within ${s.delivery_time || '1 hour'} of payment (where the knowledge or examples say "1 hour" / "1 ghante", use this).
${tier === 'premium' || !(num(s0.price_premium) > 0) ? '' : `Premium ad account (only when they ask for Premium / a stronger, aged account / a big daily budget): $${num(s0.price_premium)} · delivery within ${s0.premium_delivery || s0.delivery_time}\n`}Full-access account (only when they ask for full / admin access): $${num(s.price_account_full, 45)}${tier === 'premium' ? '' : ` · Premium full-access: $${num(s0.price_premium_full, 60)}`}

# Actions (field "action")
- payment_link: only when the customer clearly says they are ready to pay/start now. Set pay_kind (account | funnel | topup), qty, bm_id (accounts), act_id + amount (top-up). Put {payment_link} where the link should go in a message, or leave it out and the link is sent after your messages.
- handoff: a person takes over (see Knowledge). Give handoff_reason. If they asked whether they talk to a bot/AI, messages must be EMPTY.
- reminder: the customer asked to be reminded at a time → remind_at "YYYY-MM-DD HH:MM" in the customer's local time + remind_note.
- send_proofs: the customer wants to see our work / proof.
- none: just reply.
${s0.ai_voice_mode === 'every' || s0.ai_voice_mode === 'mirror' ? 'Your first message may be sent as a voice note — write it so it sounds natural when spoken (no links, no long numbers).' : 'Set voice=true only when the customer is clearly interested (asked the price, said they want to start) — the first message is then sent as a voice note.'}

# Examples of our style (C = customer, A = us; ↪[...] = reply that quotes that customer message)
${ex.map(e => `## ${e.title}${e.source === 'correction' ? ' (admin correction — follow this exactly)' : ''}\n${e.chat}`).join('\n\n')}`;
}

const REPLY_TOOL: Tool = {
  name: 'reply', description: 'The messages to send to the customer now, plus an optional action.',
  input_schema: {
    type: 'object', required: ['messages', 'action', 'next_step', 'summary'],
    properties: {
      messages: { type: 'array', maxItems: 2, description: '0-2 short messages (usually 1), sent one after another', items: { type: 'object', required: ['text'], properties: { text: { type: 'string' }, reply_to: { type: ['integer', 'null'], description: '#id of the customer message this one answers (only when answering one of several)' } } } },
      voice: { type: 'boolean' },
      action: { type: 'string', enum: ['none', 'payment_link', 'handoff', 'reminder', 'send_proofs'] },
      pay_kind: { type: 'string', enum: ['account', 'funnel', 'topup'] }, qty: { type: 'integer' }, bm_id: { type: 'string' }, act_id: { type: 'string' }, amount: { type: 'number' },
      remind_at: { type: 'string' }, remind_note: { type: 'string' }, handoff_reason: { type: 'string' },
      next_step: { type: 'string', description: 'One short Hinglish hint for our agent: the next move for this stage (never "ask X" when the facts already have X)' },
      summary: { type: 'string', description: 'Max 2 short lines: the stage (new lead / ready / link sent / paid / SOLD support / complaint), their business, what they want now' },
    },
  },
};
const COACH_TOOL: Tool = {
  name: 'coach', description: 'Coach our (new) agent like a senior sales lead: read the stage from the facts, tell the one right move, give ready replies that fit that stage.',
  input_schema: {
    type: 'object', required: ['decision', 'next_step', 'summary', 'suggestions'],
    properties: {
      decision: { type: 'string', enum: ['reply_now', 'wait'], description: 'reply_now = the agent should send something now; wait = better to wait for the customer (say until when in wait_hint)' },
      wait_hint: { type: 'string', description: 'Only for wait: short Hinglish, e.g. "Kal subah 11 baje tak wait karo, phir halka follow-up"' },
      next_step: { type: 'string', description: 'ONE sharp, plain Hinglish INSTRUCTION to our agent, max 20 words: the exact move for this stage (e.g. "Sold customer hai, ek hi account hai — sirf top-up amount confirm karo, account ID mat maango" / "Price bata ke pucho kab start karna hai, link abhi nahi"). Never tell the agent to ask for something the facts already have (BM ID, ad account ID, business, number). Not a summary of the chat. Don\'t copy the customer\'s slang words. No #message numbers, no rule lists.' },
      summary: { type: 'string', description: 'Max 2 short lines: the stage (new lead / ready / link sent / paid, waiting / SOLD support / complaint), their business, what they want now' },
      warn: { type: 'string', description: 'Usually EMPTY. Only when this chat really needs it right now, one short line (e.g. "Ye chat manager ko do — UPI maang raha hai" / "Payment ho chuka hai — manager ko batao, account share karna hai"). Never hypothetical ("agar wo UPI maange to…").' },
      suggestions: { type: 'array', maxItems: 3, description: '2-3 different ready replies, ALL correct for this stage (e.g. one direct answer, one that also moves the chat one step forward). Never one that asks for what the facts already have, never a payment link or BM ID ask before they are ready / have paid, no sale pitch to a SOLD customer.', items: { type: 'object', required: ['label', 'text'], properties: { label: { type: 'string', description: '2-4 word label' }, text: { type: 'string', description: 'Ready-to-send reply in the customer\'s language, our style, 1-2 short lines, no emojis; use a new line between separate messages' } } } },
    },
  },
};
const GRADE_TOOL: Tool = {
  name: 'grade', description: 'Grade the AI reply against the expectation and the rules.',
  input_schema: { type: 'object', required: ['pass', 'reason'], properties: { pass: { type: 'boolean' }, reason: { type: 'string', description: 'One short sentence (Hinglish ok)' } } },
};

/* ---------------- chat context ---------------- */
type Turn = { id: number; who: 'c' | 'a' | 'sys'; text: string; sender?: string };
function fmtTurns(turns: Turn[]) {
  return turns.map(t => `[#${t.id}] ${t.who === 'c' ? 'CUSTOMER' : t.who === 'a' ? 'US (our side)' : 'SYSTEM'}: ${t.text}`).join('\n');
}
export function leadTurns(leadId: number, limit = 40): Turn[] {
  const rows = all<{ id: number; dir: string; sender: string; text: string; file_type: string | null; transcript: string | null; reply_to: number | null; via: string | null }>(
    `SELECT id, dir, sender, text, file_type, transcript, reply_to, via FROM messages WHERE lead_id=? AND deleted_at IS NULL AND NOT (${EMPTY_IN_SQL}) ORDER BY created_at DESC, id DESC LIMIT ?`, leadId, limit).reverse(); // v139: real time order, no empty bubbles
  // v137: vendor automation texts (WATI rules…) are not part of the conversation; an empty customer message is dropped
  return rows.filter(m => (m.dir !== 'sys' || /💳|✅|⏰/.test(m.text)) && !isVendorAuto(m.text) && !(m.dir === 'in' && !m.file_type && !String(m.text || '').trim())).map(m => {
    const vn = m.file_type === 'voice' || m.file_type === 'audio';
    const file = m.file_type ? (vn ? (m.transcript ? `[voice note: "${m.transcript}"]` : m.dir === 'out' ? '[our voice note — not transcribed; it answered the customer\'s questions above, so do NOT answer them again]' : '[customer voice note, not understood — do NOT guess what it said]') : `[${m.file_type}]`) : '';
    // v138: a tapped WhatsApp button + our automatic reply to it
    const auto = m.dir === 'out' && m.sender === 'bot' ? (m.via === 'btn' ? '[system auto-reply to the button the customer tapped, not typed by the agent] ' : '[auto welcome sent by system, not typed by the agent] ') : '';
    if (m.dir === 'in' && m.via === 'tap') return { id: m.id, who: 'c', sender: m.sender, text: `[customer tapped button: ${String(m.text || '').replace(/[\p{Extended_Pictographic}\uFE0F\u200D]/gu, '').replace(/\s+/g, ' ').trim()}]` } as Turn; // v140: label icons left out
    return { id: m.id, who: m.dir === 'in' ? 'c' : m.dir === 'out' ? 'a' : 'sys', sender: m.sender, text: auto + (m.reply_to ? `(replying to #${m.reply_to}) ` : '') + ([file, m.text].filter(Boolean).join(' ') || '(empty)') } as Turn;
  });
}
const GREET = /^(hi+|hii+|hello+|helo|hey+|hlo|bro|bhai|brother|sir|ok|okay|hmm+|namaste|namaskar|salam|assalamualaikum|good (morning|evening|afternoon|night)|gm|\?+|\.+|[\s\W]*)$/i;
/** v137: the customer has only greeted (hi / hello / bro), sent nothing, or voice notes we could not understand. */
export function onlyGreetings(turns: Turn[]) {
  const c = turns.filter(t => t.who === 'c');
  return c.length > 0 && c.every(t => GREET.test(t.text.replace(/\[customer voice note, not understood[^\]]*\]/g, '').replace(/\(replying to #\d+\)/g, '').trim()));
}
/** v137: hard truth rules for the reply AI and the coach (the source of a lead is a guess, not their words). */
export function truthRules(turns: Turn[]) {
  return `# Truth rules (hard)
- Never claim the customer said, asked or wants something unless it is in the customer's own lines above. Where they came from (ad page, line, form) is only a guess.
- Lines marked "[auto welcome sent by system…]" were sent automatically, not typed by our agent; don't treat them as a promise or a mistake of ours.
- "[customer tapped button: X]" = the customer tapped the button X under our WhatsApp message (that is all they said). Lines marked "[system auto-reply to the button…]" were sent automatically right after; don't repeat what they already say.
- No apology ("sorry", "maaf", "sorry for the confusion") unless the customer complained or pointed out a real mistake of ours.
- A customer voice note we could not understand: never guess what it said.${onlyGreetings(turns) ? `
- THIS CHAT: the customer has only greeted (hi / hello / bro) or sent nothing clear. So: greet back, mention the info we already sent (the welcome), and ask ONE simple open question about what they need. No price push, no payment, no "confirm ho jayega", no apology.` : ''}

`;
}
function leadFacts(lead: Lead, s: Settings) {
  const bms = all<{ b: string }>("SELECT DISTINCT b FROM (SELECT bm_id b FROM pay_links WHERE lead_id=? AND bm_id IS NOT NULL UNION SELECT bm_id b FROM lead_accounts WHERE lead_id=? AND bm_id IS NOT NULL)", lead.id, lead.id).map(r => r.b);
  const acts = all<{ act_id: string }>('SELECT act_id FROM lead_accounts WHERE lead_id=? ORDER BY id DESC LIMIT 5', lead.id).map(r => r.act_id);
  const sales = all<{ service: string; qty: number; amount: number; created_at: number }>('SELECT service, qty, amount, created_at FROM sales WHERE lead_id=? ORDER BY id', lead.id);
  // ad accounts they have from us: sold accounts (a 'custom' sale is not an account) or the saved account IDs, whichever is more
  const accts = Math.max(sales.filter(x => x.service === 'account').reduce((a, x) => a + (Number(x.qty) || 0), 0), acts.length);
  const tops = all<{ amount: number; created_at: number }>('SELECT amount, created_at FROM topups WHERE lead_id=? ORDER BY id DESC LIMIT 3', lead.id);
  const open = all<{ code: string; label: string; total: number }>("SELECT code, label, total FROM pay_links WHERE lead_id=? AND status IN ('new','pending_payment') ORDER BY id DESC LIMIT 3", lead.id);
  const lastSale = sales.length ? sales[sales.length - 1].created_at : 0;
  const paidOpen = one<{ label: string }>("SELECT label FROM pay_links WHERE lead_id=? AND status='paid' AND COALESCE(paid_at, created_at)>? ORDER BY id DESC LIMIT 1", lead.id, lastSale);
  const sold = lead.status === 'sold';
  const local = new Date(now() + num(s.tz_offset_min, 330) * 60000).toISOString().slice(0, 16).replace('T', ' ');
  return [
    `Customer: ${lead.name || lead.tg_name || 'unknown'}${lead.phone ? ` (form phone ending ${String(lead.phone).slice(-4)})` : ''}`,
    // v137: only a FORM is the customer's own answer; a chat's line comes from the ad page (a guess, not their words)
    lead.source === 'form' && (lead.service || lead.niche || lead.budget || lead.has_bm) ? `Form answers (typed by the customer): wants ${lead.service || '?'}, advertises ${lead.niche || '?'}, budget ${lead.budget || '?'}, has BM: ${lead.has_bm || '?'}` : '',
    lead.source !== 'form' ? `Source: ${lead.tier === 'premium' ? 'premium' : bizOf(lead) === 'funnel' ? 'funnel' : 'agency'} ad page / chat line (likely interest, NOT said by the customer)` : '',
    bms.length ? `Business Manager ID(s) used before: ${bms.join(', ')}` : '',
    acts.length ? `Their ad account(s) from us: ${acts.join(', ')}` : '',
    sales.length ? `Bought before: ${sales.map(x => `${x.qty}× ${x.service} $${x.amount}`).join('; ')}` : 'No purchase yet',
    lead.tier === 'premium' ? 'Premium customer (Premium account, Premium prices and delivery time).' : '',
    // v134: where the deal stands, said plainly so the coach never asks for what we already have
    sold ? `STAGE: SOLD — this customer already paid and got the service (support mode). Do NOT pitch or restart the sale, do NOT ask for the BM ID or account ID again. Help them (top-ups, questions, replacements) and build trust. If they ask for another account: repeat-customer flow (payment method → link → after payment confirm the old BM).` : '',
    !sold && paidOpen ? `STAGE: PAID (${paidOpen.label}) — waiting for the manager to deliver. Never send another link or doubt the payment; ask the BM ID only if it is not known below; "kab milega" → the team checks (handoff).` : '',
    !sold && !paidOpen && open.length ? 'STAGE: PAYMENT LINK SENT — waiting for their payment. Don\'t send a new link unless they ask; no pressure.' : '',
    accts === 1 ? `They have exactly ONE ad account from us${acts.length ? ` (ID ${acts[0]})` : ' (shared by the manager; its ID is not saved here)'}. A top-up always goes to THIS account — never ask them for the ad account ID; only ask the amount.` : accts > 1 ? `They have ${accts} ad accounts from us — for a top-up ask which account (ID) only if they did not say.` : '',
    tops.length ? `Top-ups done: ${tops.map(t => `$${t.amount}`).join(', ')}` : (sold && accts > 0 ? 'No top-up yet on this account.' : ''),
    open.length ? `Open payment links: ${open.map(o => `${o.code} ${o.label} $${o.total}`).join('; ')}` : '',
    lead.remind_at ? `A reminder is set (${new Date(lead.remind_at + num(s.tz_offset_min, 330) * 60000).toISOString().slice(0, 16).replace('T', ' ')})${lead.remind_note ? ': ' + lead.remind_note : ''}` : '',
    (lead as Lead & { ch?: string | null }).ch === 'wa' ? 'This chat is on WhatsApp (not Telegram): we already have their number; calls and messages happen on WhatsApp. Never ask them to move to Telegram.' : '',
    `Customer local time now: ${local}`,
  ].filter(Boolean).join('\n');
}
const MODE_NOTE: Record<string, string> = {
  reply: 'Answer the customer\'s latest message(s) (after our last message). Read the stage in the facts first (SOLD = support mode).',
  reminder: 'A reminder the customer asked for is due now. Write a short natural check-in about what they planned (no payment link unless they already said they are ready).',
  followup: 'The customer went quiet after our last message. Write ONE short, natural, soft check-in tied to the customer\'s own goal that is easy to answer (e.g. they want to start fresh → "Sir naye sire se setup ke liye koi doubt ho to bata dijiye, aap jab bolo hum start kar dete hai"). STRICT: if our unanswered message was about payment, do NOT mention payment, USDT, crypto, UPI, wallet, price or link — payment comes back only when the customer brings it up. Never go back to older settled topics, never copy an earlier message, never a generic "still interested?". If the customer said a time when they are free and that time is still ahead, use action reminder at that time (customer local time) instead of a message. A SOLD customer (facts) gets a support check-in about their account / ads (e.g. "Sir account sahi chal raha hai? Ads start ho gaye?"), never a sales push.',
};

/* ---------------- generate ---------------- */
export type AiReply = {
  messages: { text: string; reply_to?: number | null }[]; voice?: boolean; action: string; pay_kind?: string; qty?: number; bm_id?: string; act_id?: string;
  amount?: number; remind_at?: string; remind_note?: string; handoff_reason?: string; next_step: string; summary: string;
};
/** $ amounts in our text that are not one of our prices (settings, × quantity) and not built from a number the customer gave
 *  (their top-up amount, its fee / total) → the AI made the price up. */
export function badPrices(text: string, s0: Settings, lead: PLead, context: string): number[] {
  const s = priceFor(s0, lead);
  const base = [s.price_account, s.price_account_web, s.price_funnel, s.price_funnel_web, s.price_account_full, s.topup_min,
    s0.price_account, s0.price_account_web, s0.price_funnel, s0.price_funnel_web, s0.price_account_full, s0.price_premium_full, s0.price_premium, s0.price_premium_web,
    s0.offer_agency_price, s0.offer_funnel_price, s0.offer_premium_free].map(x => num(x)).filter(x => x > 0);
  const pct = num(s.topup_comm_pct, 3), r2 = (x: number) => Math.round(x * 100) / 100;
  const ok = new Set<number>();
  for (const b of base) for (let q = 1; q <= 50; q++) ok.add(r2(b * q));
  for (const m of context.matchAll(/(\d[\d,]*(?:\.\d+)?)/g)) {
    const n = num(m[1].replace(/,/g, ''));
    if (!(n > 0 && n < 1e7)) continue;
    ok.add(r2(n)); ok.add(r2(n * pct / 100)); ok.add(r2(n * (1 + pct / 100)));
    if (n <= 50) for (const b of base) ok.add(r2(n * b)); // "2 account" → 2 × price
  }
  const found = [...text.matchAll(/\$\s?(\d[\d,]*(?:\.\d+)?)|(\d[\d,]*(?:\.\d+)?)\s?(?:\$|usd\b|dollars?\b)/gi)].map(m => num(String(m[1] || m[2]).replace(/,/g, '')));
  return [...new Set(found.filter(x => x > 0 && !ok.has(r2(x))))];
}

/** Emojis out (Akash: never any emoji in a customer message). */
export const noEmoji = (t: string) => String(t || '').replace(/(?![\u2190-\u21FF])[\p{Extended_Pictographic}\u{1F3FB}-\u{1F3FF}\uFE0F\u200D]/gu, '').replace(/[ \t]{2,}/g, ' ').replace(/ +([.,!?])/g, '$1').trim();

const HI_WORDS = new Set(('hai hain hu hun hoon ho hoga hogi kya kyu kyun kaise kaisa kitna kitne kitni nahi nhi nai mujhe muje mujhko mera mere meri mai main hum ham humein tum tumhe aap ap apka aapka apki aapki apko aapko chahiye chaiye chahte chahta karna krna karo kro karunga karenge kar kr raha rahe rha rhe rahi sakte skte sakta skta bhai bhi abhi kal parso kab kaha kahan kidhar wala wale wali dena dedo lena lelo ka ki ke ko se mein haan han ha accha acha achha thik theek bata batao bolo boliye paisa paise lekin aur toh sab kuch koi yaar yar bhejo bhej dijiye karwa karwana chalega chalana chalane ji haa nahin hamara hamare hamari unka uska iska yeh ye woh wo').split(' '));
/** Which language the customer writes in (their last few messages) → the reply must use it. */
export function custLang(texts: string[]): string {
  const t = texts.slice(-3).join(' ').replace(/\[voice note: "([^"]*)"\]/g, '$1').replace(/\[[^\]]*\]/g, ' ');
  if (/[\u0980-\u09FF]/.test(t)) return 'Bengali';
  if (/[\u0900-\u097F]/.test(t)) return 'Hindi in Devanagari script';
  const words = t.toLowerCase().match(/[a-z']+/g) || [];
  if (!words.length) return '';
  const hi = words.filter(w => HI_WORDS.has(w)).length;
  if (hi >= 2 || (hi === 1 && words.length <= 4)) return 'Roman Hinglish (Hindi written in English letters, mixed with simple English words)';
  return words.length >= 2 ? 'English' : '';
}
const langLine = (turns: Turn[]) => {
  const l = custLang(turns.filter(t => t.who === 'c').map(t => t.text));
  return l ? `LANGUAGE: the customer writes ${l} — write your whole reply in ${l.startsWith('English') ? 'English only (no Hindi words)' : l}.\n\n` : '';
};
/** Numbers the customer gave (their messages + order facts) — not the clock or their phone number. */
export const priceCtx = (facts: string, turns: Turn[]) =>
  facts.split('\n').filter(l => !/^(Customer local time|Customer:)/.test(l)).join('\n') + '\n' + turns.filter(t => t.who === 'c').map(t => t.text).join('\n');

async function generate(s: Settings, biz: Biz, facts: string, turns: Turn[], mode: string, kind: string, lead?: PLead): Promise<AiReply> {
  ensureSeed();
  const user = `MODE: ${MODE_NOTE[mode] || MODE_NOTE.reply}\n\n${langLine(turns)}# Facts about this customer\n${facts}\n\n# Chat so far (oldest first)\n${fmtTurns(turns)}\n\n${truthRules(turns)}Now call the reply tool.`;
  const sys = systemPrompt(s, biz, lead);
  const clean = (o: AiReply) => { o.messages = (Array.isArray(o.messages) ? o.messages : []).map(m => ({ ...m, text: noEmoji(m?.text || '') })).filter(m => m.text).slice(0, 2); return o; };
  let out = clean(await claude(s, kind, sys, user, REPLY_TOOL, 900) as AiReply);
  // a price that is not ours → try once more with the correction; still wrong → never sent (a person answers)
  const ctx = priceCtx(facts, turns);
  let bad = badPrices(out.messages.map(m => m.text).join('\n'), s, lead, ctx);
  if (bad.length) {
    out = clean(await claude(s, kind, sys, `${user}\n\nIMPORTANT: your previous draft said $${bad.join(', $')} — that is NOT one of our prices. Use only the numbers under "Current prices".`, REPLY_TOOL, 900) as AiReply);
    bad = badPrices(out.messages.map(m => m.text).join('\n'), s, lead, ctx);
    if (bad.length) {
      if (kind === 'lab') out.next_step = `⚠️ Wrong price in this reply ($${bad.join(', $')}) — in a real chat it would NOT be sent. ${out.next_step || ''}`;
      else { out.messages = []; out.voice = false; out.action = 'handoff'; out.handoff_reason = `AI wrote a wrong price ($${bad.join(', $')}) — please answer this chat yourself`; }
    }
  }
  if (out.action === 'handoff' && /bot|ai\b|robot|machine/i.test(out.handoff_reason || '')) out.messages = [];
  return out;
}

/* ---------------- coach (agent copilot) ---------------- */
export type Coach = { decision?: 'reply_now' | 'wait'; wait_hint?: string; next_step: string; summary: string; warn?: string; suggestions: { label: string; text: string }[] };
// v139: called ONLY when the agent / admin taps "Coach" (or its refresh) in a chat — never on open, new messages or in the background.
export async function aiCoach(lead: Lead, force = false): Promise<{ coach: Coach | null; off?: string; saved?: boolean }> {
  const s = getSettings();
  if (s.ai_coach_on !== '1') return { coach: null, off: 'Coach is off' };
  if (!aiReady(s)) return { coach: null, off: 'AI key not set' };
  const last = one<{ id: number; dir: string; created_at: number }>(`SELECT id, dir, created_at FROM messages WHERE lead_id=? AND dir!='sys' AND deleted_at IS NULL AND NOT (${EMPTY_IN_SQL}) ORDER BY created_at DESC, id DESC LIMIT 1`, lead.id);
  if (!last) return { coach: null };
  const cached = one<{ last_msg: number; data: string }>('SELECT last_msg, data FROM ai_coach WHERE lead_id=?', lead.id);
  // Our message is the last one → WAIT or follow up is decided by fixed rules (not by the AI):
  //  • we wrote in the last 4 hours → wait for their answer  • 3+ of our messages in a row unanswered → wait a day
  //  • night (22:00–09:00 their time) → wait till morning. Only then the AI suggests a follow-up.
  const quietH = last.dir !== 'in' ? (now() - last.created_at) / 3600000 : 0;
  let waitHint = '';
  if (last.dir !== 'in') {
    const localH = new Date(now() + num(s.tz_offset_min, 330) * 60000).getUTCHours();
    const lastIn = one<{ at: number | null }>(`SELECT MAX(created_at) at FROM messages WHERE lead_id=? AND dir='in' AND NOT (${EMPTY_IN_SQL})`, lead.id)?.at || 0;
    const ours = one<{ n: number }>("SELECT COUNT(*) n FROM messages WHERE lead_id=? AND dir='out' AND deleted_at IS NULL AND created_at>?", lead.id, lastIn)?.n || 0;
    const ago = quietH < 1 ? `${Math.max(1, Math.round(quietH * 60))} min` : `${Math.round(quietH)} ghante`;
    if (quietH < 4) waitHint = `Aapne ${ago} pehle message kiya hai — abhi customer ke jawab ka wait karo.`;
    else if (ours >= 3 && quietH < 24) waitHint = `Customer ko bina jawab ke ${ours} message ja chuke hain — kal tak wait karo.`;
    else if (localH >= 22 || localH < 9) waitHint = 'Raat ka time hai — subah 10 baje ke baad follow-up bhejna.';
    if (waitHint && !force) return { coach: { decision: 'wait', wait_hint: waitHint, next_step: '', summary: '', suggestions: [] } };
  }
  const COACH_V = 10; // bump → old cached suggestions are made again (v137: truth rules, vendor texts out)
  if (cached && cached.last_msg === last.id && !force && JSON.parse(cached.data).v === COACH_V) return { coach: JSON.parse(cached.data), saved: true }; // no new message since → the saved advice, no AI call
  ensureSeed();
  await transcribePending(lead, s);
  const biz = bizOf(lead);
  const task = last.dir === 'in'
    ? 'Our agent must answer this chat. First read the stage from the Facts (new lead / ready to start / payment link sent / paid, waiting for the account / SOLD = support mode / complaint or disabled account). next_step = the one right move for that stage; suggestions = what the agent should send now (our style, the customer\'s language), all correct for that stage. Never suggest asking for anything the Facts already have (BM ID, ad account ID, business, number); exactly ONE account from us → a top-up goes to that account, only the amount matters. SOLD customer → help and build trust, no re-selling. Wants to test first → agree, start small, no pressure.'
    : `The customer has not replied for ${quietH >= 24 ? Math.round(quietH / 24) + ' day(s)' : Math.max(1, Math.round(quietH)) + ' hour(s)'} after OUR LAST message. It is time for a follow-up (set decision = reply_now). Suggest 2 follow-ups. STRICT: if our unanswered message was about payment (payment method, paying, link), do NOT mention payment, USDT, crypto, UPI, wallet, price or link again — the customer has not talked about payment, and pushing it looks like a scam. Payment comes back only when the customer brings it up. Instead: a soft friendly check-in tied to the customer's own goal that is easy to answer (e.g. they want to start from zero → "Sir setup ke liye koi doubt ho to bata dijiye, aap jab bolo hum start kar dete hai"). Never go back to older topics that are already settled, never copy an earlier message, never a generic "still interested?". If the Facts say STAGE: SOLD, the follow-up is a support check-in (account chal raha hai? ads start hue? top-up chahiye ho to bata dijiye) — no selling. 1-2 short lines each, the customer's language.`;
  const turns = leadTurns(lead.id);
  const lastC = [...turns].reverse().find(t => t.who === 'c'), lastA = [...turns].reverse().find(t => t.who === 'a');
  const lastOut = one<{ read_at: number | null; created_at: number }>("SELECT read_at, created_at FROM messages WHERE lead_id=? AND dir='out' ORDER BY created_at DESC, id DESC LIMIT 1", lead.id);
  const seen = lastOut ? (lastOut.read_at ? 'The customer HAS SEEN our last message (blue ticks).' : 'The customer has NOT seen our last message yet (no blue ticks).') : '';
  const who = `# Who said what (do not mix this up)\nLines marked CUSTOMER are the customer. Lines marked "US (our side)" were written by us — the customer did NOT write them.\n${lastA ? `Our last message: "${lastA.text.slice(0, 200)}"` : ''}${lastC ? `\nThe customer's last message: "${lastC.text.slice(0, 200)}"` : ''}\nThe very last message in the chat is from ${last.dir === 'in' ? 'the CUSTOMER — decision must be reply_now' : 'US — the customer has not answered it yet. ' + seen}`;
  const user = `${task} Follow the rules in the knowledge and the HARD RULES (handoff cases → tell the agent in next_step and warn).\n\n${langLine(turns)}# Facts\n${leadFacts(lead, s)}\n\n# Chat so far\n${fmtTurns(turns)}\n\n${who}\n\n${truthRules(turns)}`;
  const c = await claude(s, 'coach', systemPrompt(s, biz, lead), user, COACH_TOOL, 900, s.ai_coach_model || undefined) as Coach;
  const cctx = priceCtx(leadFacts(lead, s), turns);
  c.suggestions = (c.suggestions || []).map(x => ({ ...x, text: noEmoji(x?.text || '') })).filter(x => x.text && !badPrices(String(x.text), s, lead, cctx).length).slice(0, 3);
  // v137: greetings only → never an invented "wants an ad account" or an apology
  if (onlyGreetings(turns)) {
    const bad = (t: string) => /\bsorry\b|maaf|confusion|chahiye bola|bola hai|confirm (karo|ho)|ho jayega/i.test(t);
    c.suggestions = c.suggestions.filter(x => !bad(x.text));
    if (bad(c.next_step || '')) c.next_step = 'Customer ne abhi sirf greet kiya hai — wapas greet karo, welcome info yaad dilao, aur ek simple sawal pucho ki unko kya chahiye.';
    if (!c.suggestions.length) c.suggestions = [{ label: 'Greet + ask', text: 'Hello sir, kaise help kar sakte hai aapki? Upar maine details bheji hai, aapko kya chahiye bataiye' }];
  }
  if (last.dir === 'in') c.decision = 'reply_now';
  else if (waitHint) { c.decision = 'wait'; c.wait_hint = waitHint + ' (Ideas below are for later.)'; }
  else c.decision = 'reply_now';
  (c as Coach & { v?: number }).v = COACH_V;
  run('INSERT INTO ai_coach(lead_id, last_msg, data, at) VALUES(?,?,?,?) ON CONFLICT(lead_id) DO UPDATE SET last_msg=excluded.last_msg, data=excluded.data, at=excluded.at', lead.id, last.id, JSON.stringify(c), now());
  return { coach: c };
}
export function aiFeedback(leadId: number, agentId: number | null, suggested: string, sent: string) {
  if (!suggested || !sent || suggested.trim() === sent.trim()) return;
  run('INSERT INTO ai_feedback(lead_id, agent_id, suggested, sent, created_at) VALUES(?,?,?,?,?)', leadId, agentId, suggested.slice(0, 2000), sent.slice(0, 2000), now());
}

/* ---------------- voice (ElevenLabs) ---------------- */
/** Text → speech with Eleven v4 (Text-to-Dialogue API). No other model: if ElevenLabs fails, the reply is sent as text. */
export let ttsError = '';
export async function tts(s: Settings, text: string, voiceId?: string): Promise<Buffer | null> {
  const vid = String(voiceId || s.el_voice_id || '').trim();
  if (!s.el_key || !vid) { ttsError = 'Add the ElevenLabs key and voice ID'; return null; }
  let retried = false;
  const call = async (model: string): Promise<Buffer | null> => {
    const dialogue = /^eleven_v4/.test(model);
    const url = dialogue ? `${EL_API()}/v1/text-to-dialogue?output_format=mp3_44100_128` : `${EL_API()}/v1/text-to-speech/${encodeURIComponent(vid)}?output_format=mp3_44100_128`;
    const body = dialogue ? { inputs: [{ text, voice_id: vid }], model_id: model } : { text, model_id: model };
    const r = await fetch(url, { method: 'POST', headers: { 'xi-api-key': s.el_key, 'content-type': 'application/json', accept: 'audio/mpeg' }, body: JSON.stringify(body), signal: AbortSignal.timeout(60000) }).catch(e => { ttsError = String((e as Error).message); return null; });
    if (!r) return null;
    if (r.status === 429 && !retried) { retried = true; await new Promise(x => setTimeout(x, 2500 * (process.env.AI_DELAY_SCALE ? Number(process.env.AI_DELAY_SCALE) : 1))); return call(model); } // busy → once more
    if (!r.ok) { const j: any = await r.json().catch(() => ({})); ttsError = `ElevenLabs ${r.status}: ${String(j?.detail?.message || j?.detail || j?.message || '').slice(0, 160)}`; return null; }
    const b = Buffer.from(await r.arrayBuffer());
    return b.length > 500 ? b : null;
  };
  return call('eleven_v4'); // Akash: only v4, no other model — if it fails, the message goes as text
}
/** A team member's recorded voice note → the same words, emotion and pauses, but in our voice (ElevenLabs voice changer),
 *  with their background noise cleaned out and our room sound added. Throws when it can't be made — the caller must then
 *  NOT send the original (it would be the agent's own voice). */
export async function changeVoice(s: Settings, audio: Buffer, name = 'voice.ogg', voiceId?: string): Promise<Buffer> {
  const vid = String(voiceId || s.el_voice_id || '').trim();
  if (!s.el_key || !vid) throw new HttpError(400, 'Voice change is on, but the ElevenLabs key / voice ID is missing (Admin → AI → Setup)');
  const send = async (path: string) => {
    const fd = new FormData();
    fd.append('audio', new Blob([new Uint8Array(audio)]), name);
    fd.append('model_id', 'eleven_multilingual_sts_v2');
    fd.append('remove_background_noise', 'true');
    return fetch(`${EL_API()}${path}/${encodeURIComponent(vid)}?output_format=mp3_44100_128`, { method: 'POST', headers: { 'xi-api-key': s.el_key }, body: fd, signal: AbortSignal.timeout(90000) }).catch(e => { throw new HttpError(502, 'Voice change: ' + (e as Error).message); });
  };
  let r = await send('/v1/voice-changer');
  if (r.status === 404) r = await send('/v1/speech-to-speech'); // older name of the same API
  if (!r.ok) { const j: any = await r.json().catch(() => ({})); throw new HttpError(502, `Voice change failed (ElevenLabs ${r.status}${j?.detail?.message || j?.detail ? ': ' + String(j?.detail?.message || j?.detail).slice(0, 140) : ''}) — nothing was sent. Try again or type the message.`); }
  const mp3 = Buffer.from(await r.arrayBuffer());
  if (mp3.length < 500) throw new HttpError(502, 'Voice change gave no audio — nothing was sent. Try again.');
  const lvl = (['off', 'light', 'medium'].includes(String(s.ai_voice_noise)) ? s.ai_voice_noise : 'light') as NoiseLevel;
  const ogg = await voiceFx(mp3, lvl, Math.random, bgOf(s), speedOf(s), num(s.ai_voice_volume, -3));
  if (!ogg) throw new HttpError(502, `Could not make the voice note on the server (${(await import('./voicefx')).lastFfError || 'ffmpeg'}) — nothing was sent. Try again.`);
  return ogg; // always a real Telegram voice note (OGG/Opus), never mp3
}
const SAY_TOOL: Tool = { name: 'say', description: 'What our agent says.', input_schema: { type: 'object', required: ['text'], properties: { text: { type: 'string' } } } };
/** Same words, ignoring case, punctuation and filler sounds ("umm", "uh") → nothing needed fixing. */
export const sameWords = (a: string, b: string) => {
  const w = (x: string) => x.toLowerCase().normalize('NFKC').replace(/[^\p{L}\p{N}\s]/gu, ' ').split(/\s+/).filter(t => t && !/^(u+h*|u+m+|h?m+|uhh+|hmm+|aa+h?)$/.test(t)).join(' ');
  return w(a) === w(b);
};
/** Team voice notes: which ElevenLabs voice and whether it is a woman or a man (Admin → AI → Voice notes). */
export const teamVoiceId = (s: Settings) => String(s.team_voice_id || '').trim() || String(s.el_voice_id || '').trim();
export const teamMale = (s: Settings) => s.team_voice_gender === 'male';
/** Our agent's words → the same message as our FEMALE agent would say it (same language, same meaning).
 *  male = the team voice is a man's: keep male forms, only clean the words up. */
export async function femaleWords(s: Settings, heard: string, male = false): Promise<string> {
  const sys = male ? `You get the transcript of a short Telegram voice note that one of our sales agents recorded for a customer. The voice note will be re-spoken by our MALE agent's voice, so write it as he would say it.
Rules:
- STRICT: keep the SAME language as the transcript. English stays English (no Hindi words at all), Roman Hinglish stays Roman Hinglish, Devanagari stays Devanagari. Never translate.
- Every first-person form is MALE: "deti hun" → "deta hun", "kar rahi hun" → "kar raha hun", "karungi" → "karunga", "gayi thi" → "gaya tha". English has no such forms — keep English as it is.
- Do NOT change words about the customer (they are "sir": "aap karoge", "aapne bheja" stay as they are).
- Lightly fix transcription mistakes and broken grammar so it sounds natural, but keep the meaning and the content exactly: add nothing, remove nothing, keep every number, price, name and time as said. No greetings added, no emojis.
- Remove filler sounds ("uh", "umm", "mm", "uhh"). Short and natural, like an Indian guy talking to a customer on Telegram — in the transcript's language.
Return only what he says.` : `You get the transcript of a short Telegram voice note that one of our sales agents recorded for a customer. The voice note will be re-spoken by our FEMALE agent's voice, so rewrite it as she would say it.
Rules:
- STRICT: keep the SAME language as the transcript. English stays English (no Hindi words at all), Roman Hinglish stays Roman Hinglish, Devanagari stays Devanagari. Never translate.
- Change every first-person form to female: "deta hun" → "deti hun", "kar raha hun" → "kar rahi hun", "karunga" → "karungi", "bhejunga" → "bhejungi", "gaya tha" → "gayi thi", "main aa raha" → "main aa rahi". English has no such forms — keep English sentences as they are.
- Do NOT change words about the customer (they are "sir": "aap karoge", "aapne bheja" stay as they are).
- Lightly fix transcription mistakes and broken grammar so it sounds natural, but keep the meaning and the content exactly: add nothing, remove nothing, keep every number, price, name and time as said. No greetings added, no emojis.
- Remove filler sounds ("uh", "umm", "mm", "uhh"). Short and natural, like an Indian girl talking to a customer on Telegram — in the transcript's language.
Return only what she says.`;
  const lang = custLang([heard]);
  const r = await claude(s, 'voice', sys, `${lang ? `LANGUAGE: the transcript is ${lang} — answer in ${lang.startsWith('English') ? 'English only, no Hindi words' : lang}.\n\n` : ''}Transcript:\n${heard}\n\nNow call the say tool.`, SAY_TOOL, 400) as { text?: string };
  return noEmoji(String(r?.text || '').trim()) || heard;
}

/** A team member's recorded voice note → what the customer gets (Admin → AI → Voice notes → "Team voice notes in our voice").
 *  female_words: their words → female wording → Eleven v4 in our voice. same: voice changer (their exact way of speaking).
 *  Always an OGG voice note. Throws when it can't be made — the caller then sends NOTHING (never their own voice). */
export async function teamVoice(s: Settings, audio: Buffer, name = 'voice.ogg'): Promise<{ data: Buffer; text: string | null; heard: string | null; fixed?: { from: string; to: string }[] }> {
  const { genderFix } = await import('./genderfix');
  const male = teamMale(s);
  if (s.team_voice_style === 'same') {
    // v137: the gender fix runs here too — "deti hun" in a man's voice is re-spoken with the fixed words; nothing to fix → voice changer
    let heard = '';
    try { heard = await transcribeBuffer(s, audio, name); } catch { /* no transcript → the voice changer as before */ }
    const g = heard ? genderFix(heard, male) : null;
    if (!g || !g.changed.length) return { data: await changeVoice(s, audio, name, teamVoiceId(s)), text: heard || null, heard: heard || null, fixed: [] };
    return { ...(await speakTeam(s, g.text)), heard, fixed: g.changed };
  }
  if (!s.ai_key) throw new HttpError(400, 'Team voice needs the Anthropic key (AI → Setup) — nothing was sent');
  let heard = '';
  try { heard = await transcribeBuffer(s, audio, name); } catch (e) { throw new HttpError(502, (e as Error).message + ' — nothing was sent'); }
  if (!heard) throw new HttpError(400, 'Nothing was heard in the voice note — nothing was sent. Speak a bit louder and try again.');
  let text: string;
  try { text = await femaleWords(s, heard, male); } catch (e) { throw new HttpError(502, 'AI could not rewrite the voice note (' + (e as Error).message.slice(0, 80) + ') — nothing was sent'); }
  // v137: deterministic first-person gender fix after the AI (the model alone missed "भेज देती हूँ" in a man's voice)
  text = genderFix(text, male).text;
  const fixed = genderFix(heard, male).changed;
  // mix (human + AI): nothing had to be fixed → their own recording through the voice changer (real tone, pauses, emotion);
  // a word had to change (a mistake, or deta → deti) → that note is spoken fresh with the fixed words
  if (s.team_voice_style === 'mix' && !fixed.length && sameWords(heard, text)) return { data: await changeVoice(s, audio, name, teamVoiceId(s)), text: heard, heard, fixed: [] };
  return { ...(await speakTeam(s, text)), heard, fixed };
}
async function speakTeam(s: Settings, text: string): Promise<{ data: Buffer; text: string }> {
  const mp3 = await tts(s, text, teamVoiceId(s));
  if (!mp3) throw new HttpError(502, `Voice could not be made (${ttsError || 'ElevenLabs'}) — nothing was sent. Try again or type the message.`);
  const lvl = (['off', 'light', 'medium'].includes(String(s.ai_voice_noise)) ? s.ai_voice_noise : 'light') as NoiseLevel;
  const ogg = await voiceFx(mp3, lvl, Math.random, bgOf(s), speedOf(s), num(s.ai_voice_volume, -3));
  if (!ogg) throw new HttpError(502, `Could not make the voice note on the server (${(await import('./voicefx')).lastFfError || 'ffmpeg'}) — nothing was sent. Try again.`);
  return { data: ogg, text };
}

/** Voice speed (Admin → AI → Voice notes): slow 0.9 by default — a person on the phone talks slower than the AI. */
export const speedOf = (s: Settings) => Math.min(1.2, Math.max(0.7, num(s.ai_voice_speed, 0.9)));
const bgOf = (s: Settings) => (s.ai_voice_bg === 'fan' ? 'fan' : 'office') as 'fan' | 'office';
/** Prompts for the office background: small office, mechanical keyboard, one or two girls on phone calls far away, fan. */
export const OFFICE_PROMPTS = [
  'Small Indian office room tone, mechanical keyboard typing nearby in short bursts, a young woman talking on a phone call in Hindi far away in the background, muffled, ceiling fan hum',
  'Quiet office background, two women speaking softly on phone calls across the room, mechanical keyboard clicks, mouse clicks, ceiling fan',
  'Mechanical keyboard fast typing then pause, distant female voice on a phone call, office air conditioner hum, natural room tone',
  'Small call office ambience, a girl talking on the phone in the distance, keyboard typing, a chair creaks, ceiling fan',
  'Office room tone, faint chatter of women far away, occasional mechanical keyboard typing, a phone notification sound far away',
  'Mechanical keyboard typing steady, a woman laughing softly on a phone call in the background, distant, ceiling fan whoosh',
];
/** Office background is made in the background (takes 1-2 min; a web request would time out). */
export const officeJob = { running: false, error: '', seconds: 0, step: 0, total: 6 };
export function startOfficeBed(s: Settings) {
  if (officeJob.running) return officeJob;
  if (!s.el_key) throw new HttpError(400, 'Add the ElevenLabs key first');
  Object.assign(officeJob, { running: true, error: '', seconds: 0, step: 0, total: OFFICE_PROMPTS.length });
  void makeOfficeBed(s).then(r => { officeJob.seconds = r.seconds; }).catch(e => { officeJob.error = (e as Error).message; }).finally(() => { officeJob.running = false; });
  return officeJob;
}
/** Makes the office background once (6 × 30 s with ElevenLabs Sound Effects → ~3 min), saved on the server. */
export async function makeOfficeBed(s: Settings): Promise<{ seconds: number }> {
  if (!s.el_key) throw new HttpError(400, 'Add the ElevenLabs key first');
  const one1 = async (text: string, tries = 0): Promise<Buffer> => {
    const r = await fetch(`${EL_API()}/v1/sound-generation?output_format=mp3_44100_128`, { method: 'POST', headers: { 'xi-api-key': s.el_key, 'content-type': 'application/json' }, body: JSON.stringify({ text, duration_seconds: 30, prompt_influence: 0.45, model_id: 'eleven_text_to_sound_v3' }), signal: AbortSignal.timeout(120000) })
      .catch(e => { throw new HttpError(502, 'ElevenLabs: ' + (e as Error).message); });
    // busy (plan allows only a few requests at the same time, e.g. a voice note is being made) → wait and try again
    if (r.status === 429 && tries < 4) { await new Promise(x => setTimeout(x, 4000 * (tries + 1) * (process.env.AI_DELAY_SCALE ? Number(process.env.AI_DELAY_SCALE) : 1))); return one1(text, tries + 1); }
    if (!r.ok) { const j: any = await r.json().catch(() => ({})); throw new HttpError(502, `ElevenLabs ${r.status}: ${String(j?.detail?.message || j?.detail || '').slice(0, 160)}`); }
    return Buffer.from(await r.arrayBuffer());
  };
  // one clip at a time — ElevenLabs plans allow only 2-4 requests at once, and voice notes must keep working meanwhile
  const clips: Buffer[] = [];
  for (const p of OFFICE_PROMPTS) { clips.push(await one1(p)); officeJob.step = clips.length; }
  try { return await buildOfficeBed(clips); } catch (e) { throw new HttpError(500, (e as Error).message); }
}
/** The welcome voice note (a little after the welcome message). Same text for everyone → made once and the Telegram
 *  file is re-used (no cost per lead). {name} in the text → made for each lead. Hindi + English mix by default. */
/** Which text. "Chat with agent" people ("Hi! I have a question…") get their own text (agency / funnel) — empty = no voice for them. */
export function welcomeVoiceTpl(s: Settings, lead: { line?: string | null; service?: string | null; menu?: number | null }) {
  if (lead.menu && s.menu_on !== '0' && String(s.welcome_voice_text_m || '').trim()) return String(s.welcome_voice_text_m); // v133: got the menu
  const funnel = routeOf(lead as any) === 'funnel';
  if (lead.service === 'chat') return String((funnel ? s.welcome_voice_text_cf : s.welcome_voice_text_c) || '');
  return String((funnel ? s.welcome_voice_text_f : s.welcome_voice_text) || s.welcome_voice_text || '');
}
export function welcomeVoiceText(s: Settings, lead: Pick<Lead, 'name' | 'tg_name'> & { line?: string | null; service?: string | null; tier?: string | null }) {
  const t = welcomeVoiceTpl(s, lead).trim();
  const first = String(lead.name || lead.tg_name || '').trim().split(/\s+/)[0] || '';
  return noEmoji(t.replace(/\{brand\}/g, s.brand_name || 'AdsBhai').replace(/\{name\}/g, first ? first + ' ji' : '').replace(/\s{2,}/g, ' ').replace(/\s+([,.!?])/g, '$1'));
}
export async function sendWelcomeVoice(s: Settings, lead: Lead) {
  if (!lead.tg_chat_id || (lead as Lead & { voice_off?: number }).voice_off) return false;
  const text = welcomeVoiceText(s, lead);
  if (!text) return false;
  const tpl = welcomeVoiceTpl(s, lead);
  const reusable = !/\{name\}/.test(tpl || '');
  const key = createHash('sha1').update([text, String(lead.tg_chat_id).startsWith('wa:') ? 'wa' : 'tg', s.el_voice_id, s.ai_voice_bg, s.ai_voice_noise, s.ai_voice_speed, s.ai_voice_volume].join('|')).digest('hex').slice(0, 16);
  let cache: Record<string, string> = {};
  try { cache = JSON.parse(s.welcome_voice_cache || '{}'); } catch { /* fresh */ }
  await act(s, lead, 'record_voice');
  let r: { ok: boolean; result?: any; description?: string } | null = null;
  if (reusable && cache[key]) {
    r = await sendFileId(s, lead.tg_chat_id, lead.biz_conn, 'voice', cache[key], '');
    if (!r.ok && voiceBlocked(r.description)) { markVoiceOff(lead.id); return false; } // they turned voice notes off → skip quietly
    if (!r.ok) r = null; // file gone → make it again
  }
  if (!r) {
    const note = await makeVoiceNote(s, text);
    if (!note) throw new Error(ttsError || 'voice could not be made');
    r = await uploadFile(s, lead.tg_chat_id, lead.biz_conn, new File([new Uint8Array(note.data)], 'voice.ogg', { type: 'audio/ogg' }), 'voice', '');
    if (!r.ok && voiceBlocked(r.description)) { markVoiceOff(lead.id); return false; }
    if (!r.ok) throw new Error('Telegram: ' + (r.description || 'not sent'));
    const fid = extractMedia(r.result)[1];
    if (reusable && fid) setSetting('welcome_voice_cache', JSON.stringify({ [key]: fid, ...Object.fromEntries(Object.entries(cache).slice(0, 5)) }));
  }
  const [, fid, fn] = extractMedia(r.result);
  addMsg(lead, { dir: 'out', sender: 'bot', text, file_id: fid, file_type: 'voice', file_name: fn, tg_msg_id: r.result?.message_id, dur: mediaDuration(r.result) });
  run('UPDATE messages SET transcript=? WHERE id=(SELECT MAX(id) FROM messages WHERE lead_id=?)', text, lead.id);
  return true;
}

/** v138: the voice note of a WhatsApp button auto-reply — same voice, same real OGG/Opus note as the welcome voice note.
 *  The same text for everyone (no {name} in it) is made once and re-used. Throws when it can't be made / sent. */
export async function sendBtnVoice(s: Settings, lead: Lead, text: string, reusable = true) {
  if (!lead.tg_chat_id || (lead as Lead & { voice_off?: number }).voice_off) return false;
  const say = noEmoji(String(text || '').replace(/\[\s*[^\]]{1,24}\s*\]/g, ' ').replace(/https?:\/\/\S+/g, ' ').replace(/^\s*(?:[-•]|\d+\.)\s*/gm, '').replace(/\s*\n+\s*/g, '. ').replace(/([.!?:])\.\s/g, '$1 ')).slice(0, 700);
  if (!say) return false;
  const key = createHash('sha1').update(['btn', say, String(lead.tg_chat_id).startsWith('wa:') ? 'wa' : 'tg', s.el_voice_id, s.ai_voice_bg, s.ai_voice_noise, s.ai_voice_speed, s.ai_voice_volume].join('|')).digest('hex').slice(0, 16);
  let cache: Record<string, string> = {};
  try { cache = JSON.parse(s.btn_voice_cache || '{}'); } catch { /* fresh */ }
  let r: { ok: boolean; result?: any; description?: string } | null = null;
  if (reusable && cache[key]) {
    r = await sendFileId(s, lead.tg_chat_id, lead.biz_conn, 'voice', cache[key], '');
    if (!r.ok && voiceBlocked(r.description)) { markVoiceOff(lead.id); return false; }
    if (!r.ok) r = null;
  }
  if (!r) {
    const note = await makeVoiceNote(s, say);
    if (!note) throw new Error(ttsError || 'voice could not be made');
    r = await uploadFile(s, lead.tg_chat_id, lead.biz_conn, new File([new Uint8Array(note.data)], 'voice.ogg', { type: 'audio/ogg' }), 'voice', '');
    if (!r.ok && voiceBlocked(r.description)) { markVoiceOff(lead.id); return false; }
    if (!r.ok) throw new Error(String(r.description || 'not sent').replace(/^WA_WINDOW_CLOSED: /, ''));
    const fid = extractMedia(r.result)[1];
    if (reusable && fid) setSetting('btn_voice_cache', JSON.stringify({ [key]: fid, ...Object.fromEntries(Object.entries(cache).slice(0, 11)) }));
  }
  const [, fid, fn] = extractMedia(r.result);
  addMsg(lead, { dir: 'out', sender: 'bot', text: say, file_id: fid, file_type: 'voice', file_name: fn, tg_msg_id: r.result?.message_id, dur: mediaDuration(r.result) });
  run("UPDATE messages SET transcript=?, via='btn' WHERE id=(SELECT MAX(id) FROM messages WHERE lead_id=?)", say, lead.id);
  return true;
}

/** TTS + room sound → OGG/Opus voice note. Never mp3: if anything fails → null and the message goes as text. */
export async function makeVoiceNote(s: Settings, text: string): Promise<{ data: Buffer; ogg: true } | null> {
  const mp3 = await tts(s, text);
  if (!mp3) return null;
  const lvl = (['off', 'light', 'medium'].includes(String(s.ai_voice_noise)) ? s.ai_voice_noise : 'light') as NoiseLevel;
  const ogg = await voiceFx(mp3, lvl, Math.random, bgOf(s), speedOf(s), num(s.ai_voice_volume, -3));
  if (!ogg) { ttsError = 'Could not make the OGG voice note on the server (ffmpeg missing?)'; return null; }
  return { data: ogg, ogg: true };
}
/** Should this AI reply go as a voice note? (Admin → AI → Voice notes: when + how many per chat) */
export function voiceDue(s: Settings, o: { aiWants: boolean; replyNo: number; customerSentVoice: boolean; voicesSent: number; text: string }) {
  if (s.ai_voice_on !== '1' || !s.el_key || !o.text || /https?:\/\//.test(o.text)) return false;
  const max = num(s.ai_voice_max, 3);
  if (max > 0 && o.voicesSent >= max) return false;
  if (s.ai_voice_mode === 'every') { const n = Math.max(1, num(s.ai_voice_every, 3)); return o.replyNo % n === 0; }
  if (s.ai_voice_mode === 'mirror') return o.customerSentVoice;
  return o.aiWants;
}
/** Audio file (the admin's test recording) → text. */
export async function transcribeBuffer(s: Settings, data: Buffer, name = 'voice.ogg') {
  if (!s.el_key) throw new HttpError(400, 'Add the ElevenLabs API key first (AI → Setup → Voice notes)');
  const fd = new FormData();
  fd.append('model_id', 'scribe_v3');
  fd.append('file', new Blob([new Uint8Array(data)]), name);
  const r = await fetch(`${EL_API()}/v1/speech-to-text`, { method: 'POST', headers: { 'xi-api-key': s.el_key }, body: fd, signal: AbortSignal.timeout(60000) }).catch(() => null);
  const j: any = r ? await r.json().catch(() => ({})) : {};
  if (!r?.ok) throw new HttpError(502, 'Could not read the voice note: ' + String(j?.detail?.message || j?.detail || r?.status || 'no answer').slice(0, 160));
  return String(j.text || '').trim();
}
/** Customer voice notes → text (ElevenLabs speech-to-text), so the AI understands them. */
async function transcribePending(lead: Pick<Lead, 'id'>, s: Settings) {
  if (!s.el_key) return;
  const rows = all<{ id: number; file_id: string }>("SELECT id, file_id FROM messages WHERE lead_id=? AND dir IN ('in','out') AND file_type IN ('voice','audio') AND transcript IS NULL AND file_id IS NOT NULL ORDER BY id DESC LIMIT 4", lead.id);
  for (const m of rows) {
    try {
      const f = await downloadFile(s, m.file_id);
      if (!f?.res.ok) { run("UPDATE messages SET transcript='' WHERE id=?", m.id); continue; }
      const data = Buffer.from(await f.res.arrayBuffer());
      const fd = new FormData();
      fd.append('model_id', 'scribe_v3');
      fd.append('file', new Blob([new Uint8Array(data)]), 'voice.ogg');
      const r = await fetch(`${EL_API()}/v1/speech-to-text`, { method: 'POST', headers: { 'xi-api-key': s.el_key }, body: fd });
      const j: any = await r.json().catch(() => ({}));
      run('UPDATE messages SET transcript=? WHERE id=?', String(j.text || '').slice(0, 2000), m.id);
    } catch { run("UPDATE messages SET transcript='' WHERE id=?", m.id); }
  }
}

/* ---------------- sending (human-like) ---------------- */
const sleep = (ms: number) => new Promise(r => setTimeout(r, ms * (process.env.AI_DELAY_SCALE ? Number(process.env.AI_DELAY_SCALE) : 1)));
const typingMs = (text: string) => Math.min(9000, 1500 + text.length * 45);
async function act(s: Settings, lead: Lead, action: string) {
  const b: Record<string, unknown> = { chat_id: lead.tg_chat_id, action };
  if (lead.biz_conn) b.business_connection_id = lead.biz_conn;
  await tg(s, 'sendChatAction', b).catch(() => null);
}
async function sendAiText(s: Settings, lead: Lead, text: string, replyToMsg: number | null) {
  const body: Record<string, unknown> = { chat_id: lead.tg_chat_id, text, disable_web_page_preview: true };
  if (lead.biz_conn) body.business_connection_id = lead.biz_conn;
  if (replyToMsg) {
    const tid = one<{ tg_msg_id: number | null }>("SELECT tg_msg_id FROM messages WHERE id=? AND lead_id=? AND dir='in'", replyToMsg, lead.id)?.tg_msg_id;
    if (tid) body.reply_parameters = { message_id: tid, allow_sending_without_reply: true };
  }
  const r = await tg(s, 'sendMessage', body);
  if (r.ok) addMsg(lead, { dir: 'out', sender: 'ai', text, tg_msg_id: r.result?.message_id, reply_to: body.reply_parameters ? replyToMsg : null });
  return r.ok;
}
async function sendProofs(s: Settings, lead: Lead) {
  const rows = all<{ id: number; file: string }>("SELECT id, file FROM ai_proofs WHERE status='on' AND (biz=? OR biz='any') ORDER BY RANDOM() LIMIT 4", bizOf(lead));
  let n = 0;
  for (const p of rows) {
    const fp = path.join(proofDir(), p.file);
    if (!fs.existsSync(fp)) continue;
    const r = await uploadFile(s, lead.tg_chat_id!, lead.biz_conn, new File([new Uint8Array(fs.readFileSync(fp))], p.file, { type: 'image/png' }), 'photo', '');
    if (r.ok) { const [ft, fid, fn] = extractMedia(r.result); addMsg(lead, { dir: 'out', sender: 'ai', text: '', file_id: fid, file_type: ft || 'photo', file_name: fn, tg_msg_id: r.result?.message_id }); n++; }
  }
  return n;
}
export const proofDir = () => {
  const d = path.join(path.dirname(process.env.DB_PATH || path.join(process.cwd(), 'data', 'adflow.db')), 'proofs');
  fs.mkdirSync(d, { recursive: true });
  return d;
};
function localToUtc(str: string | undefined, s: Settings) {
  const m = String(str || '').match(/(\d{4})-(\d{2})-(\d{2})[ T](\d{1,2}):(\d{2})/);
  if (!m) return 0;
  return Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5]) - num(s.tz_offset_min, 330) * 60000;
}

/** Hand the chat to the person who owns it. */
export async function aiHandoff(lead: Lead, reason: string) {
  run("UPDATE leads SET ai_state='paused' WHERE id=?", lead.id);
  addMsg(lead, { dir: 'sys', sender: 'system', text: `🤖 AI handed this chat to you${reason ? ': ' + reason : ''}. AI is paused here until you resume it.` });
  const ag = agentById(lead.agent_id || managerId());
  await notifyAgent(ag, `🤖 #${lead.id} ${lead.name || lead.tg_name || ''} — AI needs you: ${reason || 'please take over'}\n\n↩️ Reply to this message to answer.`, lead.id, { title: '🤖 AI needs you', body: `${lead.name || lead.tg_name || 'Chat'}: ${reason || 'take over'}` }).catch(() => {});
}

/** Run the AI on one chat and send what it says (auto mode). */
export async function aiReplyToLead(lead0: Lead, mode: 'reply' | 'reminder' | 'followup' = 'reply') {
  const s = getSettings();
  const lead = leadById(lead0.id)!;
  if (!lead.tg_chat_id) return null;
  await transcribePending(lead, s);
  const out = await generate(s, bizOf(lead), leadFacts(lead, s), leadTurns(lead.id), mode, 'auto', lead);
  let linkUrl = '';
  if (out.action === 'payment_link') {
    try {
      const { createPayLink } = await import('./paylinks');
      const r = createPayLink(lead, lead.agent_id || managerId() || 0, { kind: out.pay_kind, qty: out.qty, bm_id: out.bm_id, act_id: out.act_id, amount: out.amount });
      linkUrl = r.url;
    } catch (e) { out.action = 'handoff'; out.handoff_reason = 'Payment link could not be made: ' + (e as Error).message; }
  }
  // voice note first (only when the customer showed interest)
  let msgs = out.messages.map(m => ({ ...m, text: linkUrl ? m.text.replace(/\{payment_link\}/g, linkUrl) : m.text.replace(/\{payment_link\}/g, '') }));
  const replyNo = msgs.length ? (num((lead as Lead & { ai_replies?: number }).ai_replies) + 1) : 0;
  if (msgs.length) run('UPDATE leads SET ai_replies=? WHERE id=?', replyNo, lead.id);
  const lastIn = one<{ file_type: string | null }>(`SELECT file_type FROM messages WHERE lead_id=? AND dir='in' AND NOT (${EMPTY_IN_SQL}) ORDER BY created_at DESC, id DESC LIMIT 1`, lead.id);
  const voicesSent = one<{ n: number }>("SELECT COUNT(*) n FROM messages WHERE lead_id=? AND dir='out' AND sender='ai' AND file_type='voice'", lead.id)!.n;
  if (msgs.length && !(lead as Lead & { voice_off?: number }).voice_off && voiceDue(s, { aiWants: !!out.voice, replyNo, customerSentVoice: ['voice', 'audio'].includes(lastIn?.file_type || ''), voicesSent, text: msgs[0].text })) {
    const v = msgs[0];
    await act(s, lead, 'record_voice');
    const note = await makeVoiceNote(s, v.text);
    if (note) {
      await sleep(Math.min(6000, 1500 + v.text.length * 30));
      const r = await uploadFile(s, lead.tg_chat_id, lead.biz_conn, new File([new Uint8Array(note.data)], 'voice.ogg', { type: 'audio/ogg' }), 'voice', '');
      if (r.ok) {
        const [, fid, fn] = extractMedia(r.result);
        addMsg(lead, { dir: 'out', sender: 'ai', text: v.text, file_id: fid, file_type: 'voice', file_name: fn, tg_msg_id: r.result?.message_id, dur: mediaDuration(r.result, note.data) });
        run('UPDATE messages SET transcript=? WHERE id=(SELECT MAX(id) FROM messages WHERE lead_id=?)', v.text, lead.id);
        msgs = msgs.slice(1);
      } else if (voiceBlocked(r.description)) markVoiceOff(lead.id); // goes as text below
    }
  }
  for (const m of msgs) {
    await act(s, lead, 'typing');
    await sleep(typingMs(m.text));
    await sendAiText(s, lead, m.text, m.reply_to || null);
  }
  if (linkUrl && !out.messages.some(m => m.text.includes('{payment_link}'))) { await act(s, lead, 'typing'); await sleep(1200); await sendAiText(s, lead, linkUrl, null); }
  if (out.action === 'send_proofs') await sendProofs(s, lead);
  if (out.action === 'reminder') {
    const at = localToUtc(out.remind_at, s);
    try { if (at) setReminder(lead, at, out.remind_note || 'AI reminder', 'ai'); } catch { /* bad time */ }
  }
  if (out.action === 'handoff') await aiHandoff(leadById(lead.id)!, out.handoff_reason || '');
  run('INSERT INTO ai_coach(lead_id, last_msg, data, at) VALUES(?,?,?,?) ON CONFLICT(lead_id) DO UPDATE SET last_msg=excluded.last_msg, data=excluded.data, at=excluded.at',
    lead.id, one<{ id: number }>("SELECT MAX(id) id FROM messages WHERE lead_id=? AND dir!='sys'", lead.id)!.id, JSON.stringify({ next_step: out.next_step, summary: out.summary, suggestions: [] }), now());
  return out;
}

/** AI follow-ups for hot leads are on: switch + key + Test Lab score. */
export function aiFuActive(s: Settings = getSettings()) {
  if (s.ai_fu_on !== '1' || !aiReady(s)) return false;
  const sc = labScore();
  return sc !== null && sc >= num(s.ai_min_score, 90);
}
/** Writes follow-up #stage for a hot lead. Returns the text, or { reminded } when the customer named a time (a reminder is set instead), or null → use the template. */
export async function aiFollowup(lead: Lead, stage: number): Promise<{ text?: string; reminded?: boolean } | null> {
  const s = getSettings();
  try {
    await transcribePending(lead, s);
    const out = await generate(s, bizOf(lead), leadFacts(lead, s) + `\nThis is follow-up ${stage} of 3.`, leadTurns(lead.id), 'followup', 'followup', lead);
    if (out.action === 'reminder') {
      const at = localToUtc(out.remind_at, s);
      if (at > now() + 60000) { setReminder(lead, at, out.remind_note || 'Customer said they are free', 'ai'); return { reminded: true }; }
    }
    const text = out.messages.map(m => m.text.replace(/\{payment_link\}/g, '').trim()).filter(Boolean).join('\n').slice(0, 1500);
    return text ? { text } : null;
  } catch (e) {
    addMsg(lead, { dir: 'sys', sender: 'system', text: `⚠️ AI follow-up not written (${(e as Error).message.slice(0, 80)}) — the normal follow-up was used.` });
    return null;
  }
}

/** Worker: answer the chats of the agents picked in Admin → AI (every few seconds). */
let busy = false;
export async function aiAutoTick(t = now()) {
  const s = getSettings();
  if (busy || s.ai_auto_on !== '1' || !aiReady(s)) return 0;
  const ids = autoAgents(s);
  if (!ids.length) return 0;
  busy = true;
  let n = 0;
  try {
    const wait = Math.max(5, num(s.ai_wait_sec, 25)) * 1000, hold = num(s.ai_human_hold_min, 30) * 60000;
    const rows = all<Lead & { ai_state: string | null; ai_done_msg: number | null; last_id: number; last_dir: string; last_t: number }>(
      `SELECT l.*, x.id last_id, x.dir last_dir, x.created_at last_t FROM leads l
       JOIN messages x ON x.id=(SELECT MAX(id) FROM messages m WHERE m.lead_id=l.id AND m.dir!='sys')
       WHERE l.agent_id IN (${ids.join(',')}) AND l.tg_chat_id IS NOT NULL AND l.status!='merged' AND COALESCE(l.ai_state,'')!='paused'
         AND (COALESCE(l.ch,'tg')!='wa' OR (${s.wa_ai_on !== '0' && s.wati_on === '1' ? 1 : 0}=1 AND x.created_at>${t - 23 * 3600000}))
         AND x.dir='in' AND x.created_at<? AND x.created_at>? AND COALESCE(l.ai_done_msg,0)<x.id ORDER BY x.created_at LIMIT 5`, t - wait, t - 3 * DAY);
    for (const r of rows) {
      const human = one<{ v: number | null }>("SELECT MAX(created_at) v FROM messages WHERE lead_id=? AND dir='out' AND sender IN ('agent','admin','owner')", r.id)?.v || 0;
      if (human > t - hold) continue; // a person is talking in this chat right now
      // v143: an AI answer is a reply owed (front of the line) but still goes through its channel's send queue
      const P = await import('./pace');
      if (!P.paceAsk(P.chOf(r), `ai:${r.id}:${r.last_id}`, 'ai', P.PRIO.reply, t, r.id)) continue;
      run('UPDATE leads SET ai_done_msg=? WHERE id=?', r.last_id, r.id);
      try { await aiReplyToLead(r, 'reply'); n++; } catch (e) { addMsg(r, { dir: 'sys', sender: 'system', text: `⚠️ AI could not answer: ${(e as Error).message}` }); }
    }
    // reminders the customer asked for, in AI chats
    const due = all<Lead & { ai_state: string | null }>(`SELECT * FROM leads WHERE remind_due=1 AND agent_id IN (${ids.join(',')}) AND tg_chat_id IS NOT NULL AND COALESCE(ai_state,'')!='paused' LIMIT 3`);
    for (const l of due) {
      const P = await import('./pace');
      if (!P.paceAsk(P.chOf(l), `air:${l.id}`, 'remind', P.PRIO.remind, t, l.id)) continue; // v143: send queue
      run('UPDATE leads SET remind_due=0, remind_at=NULL WHERE id=?', l.id);
      try { await aiReplyToLead(l, 'reminder'); n++; } catch { /* next time */ }
    }
  } finally { busy = false; }
  return n;
}

/* ---------------- Test Lab ---------------- */
type CaseRow = { id: number; title: string; biz: Biz; turns: string; expect: string; facts: string | null };
function caseTurns(c: CaseRow): Turn[] { return (JSON.parse(c.turns || '[]') as { from: 'c' | 'a'; text: string }[]).filter(t => !isVendorAuto(t.text)).map((t, i) => ({ id: i + 1, who: t.from === 'a' ? 'a' : 'c', text: t.text })); }
export async function simulate(biz: Biz, turnsIn: { from: 'c' | 'a'; text: string }[], facts = '', mode = 'reply', opt: { voice?: 'auto' | 'always' | 'never'; audio?: boolean } = {}) {
  const s = getSettings();
  const turns = turnsIn.filter(t => !isVendorAuto(t.text)).map((t, i) => ({ id: i + 1, who: t.from === 'a' ? 'a' : 'c', text: String(t.text || '').slice(0, 2000) } as Turn)); // v137: vendor automation texts out
  const local = new Date(now() + num(s.tz_offset_min, 330) * 60000).toISOString().slice(0, 16).replace('T', ' ');
  const out: AiReply & { voice_audio?: string; voice_error?: string } = await generate(s, biz, `${facts || 'New customer, no purchase yet.'}\nCustomer local time now: ${local}`, turns, mode, 'lab');
  // would this reply go as a voice note? (same rules as a real chat; "always" = the admin's voice test)
  const ours = turns.filter((t, i) => t.who === 'a' && turns[i - 1]?.who !== 'a').length;
  const lastC = [...turns].reverse().find(t => t.who === 'c');
  const text = out.messages[0]?.text || '';
  out.voice = !!text && (opt.voice === 'always' ? true : opt.voice === 'never' ? false
    : voiceDue({ ...s, ai_voice_on: '1', el_key: s.el_key || 'x' }, { aiWants: !!out.voice, replyNo: ours + 1, customerSentVoice: /^\[voice note/.test(lastC?.text || ''), voicesSent: 0, text }));
  if (out.voice && opt.audio) {
    try { const n = await makeVoiceNote(s, text); if (n) out.voice_audio = `data:audio/ogg;base64,${n.data.toString('base64')}`; else out.voice_error = ttsError || 'Voice could not be made'; }
    catch (e) { out.voice_error = (e as Error).message; }
  }
  return out;
}
async function grade(s: Settings, c: CaseRow, out: AiReply) {
  const sys = `You check replies written by our sales AI. Be strict but fair. A reply PASSES only if it does what the expectation says AND follows these rules: correct prices, same language/script as the customer (customer wrote English → the reply must be English), short and human (no lists/markdown), no invented facts, no early payment link, never reveals our BM name or ID (saying our accounts are USA / Indian verified is allowed and correct), never claims to be human, hands off when the rules say so. Also FAIL when it: answers more than was asked or repeats something we already said (price, 1 hour…), sends more than 2 messages, uses any emoji, says "risk zero" / guarantee / "fixed rule", asks for the BM ID before the customer pays, asks about top-up amount before they bought an account, or answers a customer's bad experience without empathy. Notes: "voice": true only means the first message is sent as a voice note — it is not an emoji and not a mistake. For a call request the FIRST reply only confirms the number (action none is right); the handoff comes after the customer confirms the number. A confident positive line like "profitable toh hum aapko karke hi chhodenge" is allowed (it is not a written guarantee or a money-back promise). If the customer gave their BM ID themselves, noting it is fine. In a FUNNEL chat the top-up fee must not come up unless they take an ad account from us. Use the LANGUAGE line below to judge the language — don't guess it yourself. Judge the meaning, not the exact words of the expectation.\n\n# Knowledge\n${knowledgeText(s)}\n\n# Current prices\nAd account $${num(s.price_account)} · Funnel $${num(s.price_funnel)}/month · Top-up fee ${num(s.topup_comm_pct, 3)}% (min $${num(s.topup_min, 30)})`;
  const lang = custLang(caseTurns(c).filter(t => t.who === 'c').map(t => t.text));
  const user = `${lang ? `LANGUAGE: the customer writes ${lang}. A reply in that language is correct.\n\n` : ''}# Chat\n${fmtTurns(caseTurns(c))}\n\n# Expectation\n${c.expect}\n\n# AI reply\n${JSON.stringify({ messages: out.messages, action: out.action, pay_kind: out.pay_kind, qty: out.qty, bm_id: out.bm_id, act_id: out.act_id, amount: out.amount, remind_at: out.remind_at, handoff_reason: out.handoff_reason, voice: out.voice })}`;
  return claude(s, 'grade', sys, user, GRADE_TOOL, 300) as Promise<{ pass: boolean; reason: string }>;
}
export async function runCase(id: number) {
  const s = getSettings();
  const c = one<CaseRow>('SELECT * FROM ai_cases WHERE id=?', id);
  if (!c) throw new HttpError(404, 'Case not found');
  const mode = /^MODE follow-up/i.test(c.expect) ? 'followup' : 'reply';
  const out = await simulate(c.biz, JSON.parse(c.turns || '[]'), c.facts || '', mode);
  let g = await grade(s, c, out);
  // v137: hard checks for the truth cases (no apology, no invented wants, asks what they need)
  if (c.title.startsWith('Truth:')) {
    const t = out.messages.map(m => m.text).join('\n');
    const why = /\bsorry\b|maaf/i.test(t) ? 'says sorry' : /chahiye bola|bola hai/i.test(t) ? 'claims the customer said what they want' : !/\?/.test(t) ? 'does not ask what they need' : '';
    if (why) g = { pass: false, reason: 'Hard check: ' + why };
  }
  run('UPDATE ai_cases SET out=?, verdict=?, reason=?, mark=NULL, run_at=? WHERE id=?', JSON.stringify(out), g.pass ? 'pass' : 'fail', String(g.reason || '').slice(0, 400), now(), id);
  return one('SELECT * FROM ai_cases WHERE id=?', id);
}
export const labState = { running: false, done: 0, total: 0, failed: 0, started: 0, error: '' };
export function labScore() {
  const r = one<{ total: number; ok: number }>("SELECT COUNT(*) total, SUM(CASE WHEN COALESCE(mark, CASE verdict WHEN 'pass' THEN 'ok' ELSE 'bad' END)='ok' THEN 1 ELSE 0 END) ok FROM ai_cases WHERE run_at IS NOT NULL")!;
  return r.total ? Math.round((r.ok || 0) / r.total * 100) : null;
}
export function startLabRun(ids?: number[]) {
  if (labState.running) throw new HttpError(409, 'A test run is already going');
  ensureSeed();
  const list = ids?.length ? ids : all<{ id: number }>('SELECT id FROM ai_cases ORDER BY id').map(r => r.id);
  Object.assign(labState, { running: true, done: 0, total: list.length, failed: 0, started: now(), error: '' });
  void (async () => {
    const queue = [...list];
    const worker = async () => { for (let id = queue.shift(); id; id = queue.shift()) { try { await runCase(id); } catch (e) { labState.failed++; labState.error = (e as Error).message; if (/budget|key/i.test(labState.error)) queue.length = 0; } labState.done++; } };
    await Promise.all([worker(), worker(), worker()]);
    labState.running = false;
    const sc = labScore();
    if (sc !== null) setSetting('ai_last_score', String(sc));
  })();
  return { ok: true, total: list.length };
}
/** The admin marks a Test Lab answer right/wrong; a corrected answer becomes an example the AI follows. */
export function markCase(id: number, mark: string, fix: string) {
  const c = one<CaseRow>('SELECT * FROM ai_cases WHERE id=?', id);
  if (!c) throw new HttpError(404, 'Case not found');
  const m = mark === 'ok' ? 'ok' : mark === 'bad' ? 'bad' : null;
  const f = String(fix || '').trim().slice(0, 3000);
  run('UPDATE ai_cases SET mark=?, fix=? WHERE id=?', m, f || null, id);
  if (f) {
    const chat = caseTurns(c).map(t => `${t.who === 'c' ? 'C' : 'A'}: ${t.text}`).join('\n') + '\n' + f.split('\n').filter(Boolean).map(l => /^(A|C):/.test(l) ? l : 'A: ' + l).join('\n');
    run("DELETE FROM ai_examples WHERE source='correction' AND title=?", 'Lab: ' + c.title);
    run("INSERT INTO ai_examples(title, biz, chat, source, on_, created_at) VALUES(?,?,?,'correction',1,?)", 'Lab: ' + c.title, c.biz, chat, now());
  }
  const sc = labScore();
  if (sc !== null) setSetting('ai_last_score', String(sc));
  return { ok: true, score: sc };
}

/** A real chat → an example (names, numbers and IDs hidden). */
export function maskText(t: string, names: string[]) {
  let x = t.replace(/https?:\/\/\S+/g, '[link]').replace(/@[A-Za-z0-9_]{4,}/g, '@user').replace(/[\w.+-]+@[\w-]+\.[\w.]+/g, '[email]').replace(/\+?\d[\d\s-]{5,}\d/g, m => m.replace(/\d/g, '•').slice(0, 12)).replace(/\bL-[A-Za-z0-9]{12}\b/g, 'L-••••');
  const esc = (n: string) => n.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  for (const n of [...new Set(names.map(n => String(n || '').trim()).filter(n => n.length > 2))].sort((a, b) => b.length - a.length)) x = x.replace(new RegExp(`(^|[^\\p{L}])${esc(n)}(?=$|[^\\p{L}])`, 'giu'), '$1Sir');
  return x;
}
export function exampleFromLead(leadId: number, title: string) {
  const l = leadById(leadId);
  if (!l) throw new HttpError(404, 'Chat not found');
  const names = [l.name, l.tg_name, ...(String(l.name || '').split(' ')), ...(String(l.tg_name || '').split(' '))].filter(Boolean) as string[];
  const rows = all<{ dir: string; text: string; file_type: string | null }>(`SELECT dir, text, file_type FROM messages WHERE lead_id=? AND dir!='sys' AND NOT (${EMPTY_IN_SQL}) ORDER BY created_at, id LIMIT 80`, leadId);
  const chat = rows.map(m => `${m.dir === 'in' ? 'C' : 'A'}: ${m.file_type && !m.text ? `[${m.file_type}]` : maskText(m.text, names)}`).join('\n');
  run("INSERT INTO ai_examples(title, biz, chat, source, on_, created_at) VALUES(?,?,?,'sold',1,?)", (title || `Real chat #${leadId}`).slice(0, 80), bizOf(l), chat, now());
  return { ok: true };
}

export function aiUsage(days = 7) {
  return all('SELECT day, kind, calls, tin, tout, ROUND(cost, 4) cost FROM ai_usage ORDER BY day DESC LIMIT ?', days * 6);
}
export const moneyFmt = (n: number) => '$' + money(n).toFixed(2);

/** v150: Admin → Comments — sort Facebook / Instagram comments: bad (delete), doubt (admin checks), ok. */
export async function aiCommentLabels(s: Settings, items: { id: string; text: string }[]): Promise<Record<string, { label: 'bad' | 'doubt' | 'ok'; reason: string }>> {
  const out: Record<string, { label: 'bad' | 'doubt' | 'ok'; reason: string }> = {};
  for (let i = 0; i < items.length; i += 30) {
    const part = items.slice(i, i + 30);
    const r = await claude(s, 'comments',
      `You moderate comments on the Facebook / Instagram ads and posts of ${s.brand_name || 'our agency'} (we sell Meta agency ad accounts, top-ups and funnel setup in India; Hindi / Hinglish / English).
Label every comment:
- bad: calls us scam / fake / fraud / chor / cheater, abuse or gaali, hate, competitor promotion (another seller, "mujhse lo / sasta milega", links, phone numbers, Telegram / WhatsApp handles), spam, sexual content.
- doubt: unclear negative tone, or a worried question that could scare buyers ("ye fake to nahi?", "kisi ne liya hai?"), complaints that might be a real customer.
- ok: real questions (price, how to buy, details), praise, tags, emojis, neutral talk.
When in doubt between bad and doubt, pick doubt. reason: 2-5 words.`,
      [{ type: 'text', text: JSON.stringify(part.map(x => ({ id: x.id, text: x.text.slice(0, 500) }))) }],
      { name: 'labels', description: 'Label for every comment', input_schema: { type: 'object', properties: { items: { type: 'array', items: { type: 'object', properties: { id: { type: 'string' }, label: { type: 'string', enum: ['bad', 'doubt', 'ok'] }, reason: { type: 'string' } }, required: ['id', 'label'] } } }, required: ['items'] } },
      1200, 'claude-haiku-5-5');
    for (const x of (r?.items || []) as { id: string; label: 'bad' | 'doubt' | 'ok'; reason?: string }[]) if (part.some(p => p.id === x.id)) out[x.id] = { label: x.label, reason: String(x.reason || '').slice(0, 60) };
  }
  return out;
}
