// WhatsApp sales: sold on WhatsApp (no Telegram chat, no Meta event) — the admin or the manager writes them down here
// so revenue / profit include them. Stored in `sales` with wa=1 and no lead (so they never count as leads or chats).
import { all, one, run } from './db';
import { getSettings, tierFor, priceFor, type Settings } from './settings';
import { HttpError, money, now, num } from './util';

export const WA_ITEMS = [
  { k: 'account', label: 'Ad account', service: 'account', line: 'agency', tier: null },
  { k: 'premium', label: 'Premium ad account', service: 'account', line: 'agency', tier: 'premium' },
  { k: 'full', label: 'Full access ad account', service: 'account', line: 'agency', tier: null },
  { k: 'premium_full', label: 'Premium full access account', service: 'account', line: 'agency', tier: 'premium' },
  { k: 'funnel', label: 'Landing page + funnel', service: 'funnel', line: 'funnel', tier: null },
  { k: 'fb_old', label: 'Facebook account + BM', service: 'custom', line: 'agency', tier: null },
  { k: 'other', label: 'Other', service: 'custom', line: 'agency', tier: null },
] as const;
type Item = (typeof WA_ITEMS)[number];

/** Price for one unit (prefilled in the form, can be changed). */
export function waPrice(s: Settings, k: string) {
  const p = tierFor(s, 'premium');
  return money(({
    account: s.price_account, premium: p.price_account, full: s.price_account_full, premium_full: p.price_account_full,
    funnel: s.price_funnel, fb_old: s.price_fb_old,
  } as Record<string, unknown>)[k] ?? 0);
}

/** v144: what can be sold in ONE chat (payment link sheet, Mark as sold) — the same products and setting prices as WA_ITEMS / waPrice
 *  and /products. The chat's own prices apply (retargeting offer price). Premium chats: never the Agency ($25) account. */
export type CatItem = { k: 'account' | 'full' | 'premium' | 'premium_full' | 'fb_old' | 'funnel'; group: 'agency' | 'premium' | 'fb' | 'funnel'; label: string; short: string;
  kind: 'account' | 'funnel' | 'custom'; tier: 'premium' | 'agency' | null; full: 0 | 1; price: number; unit: 'per account' | 'per month' | 'one-time' };
export function chatCatalog(s0: Settings, lead: { tier?: string | null; line?: string | null; service?: string | null; offer_until?: number | null } | null | undefined): CatItem[] {
  const premChat = lead?.tier === 'premium';
  const own = priceFor(s0, lead); // this chat's prices (Premium price in a Premium chat, offer price in an offer chat)
  const P = tierFor(s0, 'premium');
  const out: CatItem[] = [];
  if (!premChat) {
    out.push({ k: 'account', group: 'agency', label: 'Agency ad account', short: 'Normal', kind: 'account', tier: 'agency', full: 0, price: money(own.price_account), unit: 'per account' });
    if (num(s0.price_account_full) > 0) out.push({ k: 'full', group: 'agency', label: 'Full access ad account', short: 'Full access', kind: 'account', tier: 'agency', full: 1, price: money(s0.price_account_full), unit: 'per account' });
  }
  if (premChat || s0.premium_on === '1') {
    out.push({ k: 'premium', group: 'premium', label: 'Premium ad account', short: 'Normal', kind: 'account', tier: 'premium', full: 0, price: money(premChat ? own.price_account : P.price_account), unit: 'per account' });
    if (num(s0.price_premium_full) > 0) out.push({ k: 'premium_full', group: 'premium', label: 'Full access Premium ad account', short: 'Full access', kind: 'account', tier: 'premium', full: 1, price: money(s0.price_premium_full), unit: 'per account' });
  }
  if (num(s0.price_fb_old) > 0) out.push({ k: 'fb_old', group: 'fb', label: 'Facebook account + Business Manager', short: 'Facebook account + BM', kind: 'custom', tier: null, full: 0, price: money(s0.price_fb_old), unit: 'one-time' });
  out.push({ k: 'funnel', group: 'funnel', label: 'Landing page + funnel', short: 'Funnel', kind: 'funnel', tier: null, full: 0, price: money(own.price_funnel), unit: 'per month' });
  return out.filter(x => x.price > 0);
}

/** v144: the lowest price per unit a person may set. Agents: at most max_discount_pct below the normal price; manager / admin: any price > 0. */
export function checkUnitPrice(s: Settings, unit: unknown, list: number, free: boolean, what = 'account') {
  const up = money(unit);
  if (!(up > 0)) throw new HttpError(400, `Enter a price above $0 per ${what}`);
  if (up > 50000) throw new HttpError(400, 'Price looks too big');
  if (!free && list > 0) {
    const pct = Math.min(100, Math.max(0, num(s.max_discount_pct, 40)));
    const min = money(list * (1 - pct / 100));
    if (up + 0.004 < min) throw new HttpError(403, `You can lower the price by at most ${pct}%: the lowest is $${min} per ${what} (normal $${list}). Ask the manager or the admin for a lower price.`, { code: 'max_discount', min });
  }
  return up;
}

/** The day a sale happened: 'YYYY-MM-DD' (local) → that day 12:00; today / empty → now. */
function saleTime(s: Settings, date: unknown) {
  const off = num(s.tz_offset_min, 330) * 60000;
  const today = new Date(now() + off).toISOString().slice(0, 10);
  const d = String(date || '').trim();
  if (!d || d === today) return now();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(d) || d > today) throw new HttpError(400, 'Pick a valid date (not in the future)');
  return Date.parse(d + 'T12:00:00Z') - off;
}

export function addWaSale(b: Record<string, unknown>, by: { name: string; agent_id?: number | null }, opt: { link?: boolean; link_id?: number } = {}) {
  const s = getSettings();
  const it: Item = WA_ITEMS.find(x => x.k === b.item) || WA_ITEMS[0];
  const qty = Math.max(1, Math.min(100, parseInt(String(b.qty)) || 1));
  // v144: price per account / month (special price): amount = price × quantity; the normal price is kept to show "special price"
  const listU = waPrice(s, it.k);
  const hasUnit = b.unit_price != null && String(b.unit_price).trim() !== '';
  const amount = hasUnit ? money(checkUnitPrice(s, b.unit_price, listU, true, it.service === 'funnel' ? 'month' : 'account') * qty) : money(b.amount);
  if (!(amount > 0)) throw new HttpError(400, 'Enter the amount the customer paid');
  const listP = it.service !== 'custom' && listU > 0 && Math.abs(amount - listU * qty) > 0.004 && !opt.link ? listU : null;
  const name = String(b.name || '').trim().slice(0, 80), phone = String(b.phone || '').replace(/[^\d+ ]/g, '').trim().slice(0, 24);
  const note = String(b.note || '').trim().slice(0, 300);
  const at = saleTime(s, b.date);
  // v129: a paid link saves one sale per service — two $10 services for one customer are not a double tap
  if (!opt.link && one('SELECT 1 FROM sales WHERE wa=1 AND amount=? AND COALESCE(cust_phone,\'\')=? AND COALESCE(cust_name,\'\')=? AND COALESCE(added_at, created_at)>?', amount, phone, name, now() - 30000)) // v166: by when it was added (back-dated too)
    throw new HttpError(409, 'This sale was already added a moment ago');
  const cost = it.service === 'account' ? money(num(s.acct_cost, 3) * qty) : 0; // what the ad accounts cost us
  // v135: an agent's account sold through a paid WhatsApp link earns the same commission as on Telegram (manager: none; hand-added sales: none)
  const ag = opt.link && by.agent_id ? one<{ role: string; comm_per_sale: number; comm_premium: number | null; comm_funnel: number | null }>('SELECT role, comm_per_sale, comm_premium, comm_funnel FROM agents WHERE id=?', by.agent_id) : undefined;
  // v141: + the agent's funnel commission (per month sold) when the admin set one
  const commission = ag && ag.role !== 'manager' && it.service === 'account' ? money((it.tier === 'premium' && ag.comm_premium != null ? num(ag.comm_premium) : num(ag.comm_per_sale)) * qty)
    : ag && ag.role !== 'manager' && it.service === 'funnel' && num(ag.comm_funnel) > 0 ? money(num(ag.comm_funnel) * qty) : 0;
  const r = one<{ id: number }>(`INSERT INTO sales(lead_id, agent_id, service, qty, amount, commission, cost, created_at, wa, item, line, tier, cust_name, cust_phone, note, by_name, full, pay_link_id, list_price, discount, added_at)
    VALUES(NULL, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) RETURNING id`,
    by.agent_id ?? null, it.service, qty, amount, commission, cost, at, it.k, it.line, it.tier, name || null, phone || null, note || null, by.name.slice(0, 60), /full/.test(it.k) ? 1 : null, opt.link_id || null,
    listP, listP != null ? money(listP * qty - amount) : null, now())!;
  return { ok: true, id: r.id, amount, ...(listP != null ? { special: { list: listP, unit: money(amount / qty) } } : {}) };
}

/** v115: fix the amount of a WhatsApp sale (typed wrong). */
/** v161: the agent a hand-added WhatsApp sale belongs to (Team + the agent's dashboard count it; no commission is added). */
export function waSaleAgent(id: unknown, agentId: unknown) {
  const aid = num(agentId) || null;
  if (aid && !one('SELECT 1 FROM agents WHERE id=? AND deleted=0', aid)) throw new HttpError(400, 'Agent not found');
  if (!run('UPDATE sales SET agent_id=? WHERE id=? AND wa=1', aid, num(id)).changes) throw new HttpError(404, 'Sale not found');
  return { ok: true };
}
/** v161: the admin picks who made a hand-added WhatsApp sale. */
export const pickAgent = (v: unknown) => { const aid = num(v); return aid && one('SELECT 1 FROM agents WHERE id=? AND deleted=0', aid) ? aid : null; };

export function editWaSale(id: unknown, amount: unknown) {
  const a = money(amount);
  if (!(a > 0)) throw new HttpError(400, 'Enter the amount the customer paid');
  const x = one<{ qty: number; item: string; service: string }>('SELECT qty, item, service FROM sales WHERE id=? AND wa=1', num(id));
  if (!x) throw new HttpError(404, 'Sale not found');
  const listU = x.service === 'custom' ? 0 : waPrice(getSettings(), x.item), q = Math.max(1, x.qty || 1);
  const sp = listU > 0 && Math.abs(a - listU * q) > 0.004; // v144: keep "special price" right after a fix
  run('UPDATE sales SET amount=?, list_price=?, discount=? WHERE id=? AND wa=1', a, sp ? listU : null, sp ? money(listU * q - a) : null, num(id));
  return { ok: true, amount: a };
}

export function delWaSale(id: unknown) {
  if (!run('DELETE FROM sales WHERE id=? AND wa=1', num(id)).changes) throw new HttpError(404, 'Sale not found');
  return { ok: true };
}

/** v129: a top-up sold on WhatsApp (any amount). The fee is our income; saved in top-ups with wa=1, no Meta event. */
export function addWaTopup(b: Record<string, unknown>, by: { name: string; agent_id?: number | null }) {
  const s = getSettings();
  const amount = money(b.amount);
  if (!(amount > 0)) throw new HttpError(400, 'Enter the top-up amount');
  if (amount > 100000) throw new HttpError(400, 'Top-up looks too big');
  const pct = b.tier === 'premium' ? num(tierFor(s, 'premium').topup_comm_pct, 3) : num(s.topup_comm_pct, 3); // v135: Premium customers pay the Premium fee
  const fee = b.fee === '' || b.fee == null ? money(amount * pct / 100) : money(b.fee);
  if (fee < 0 || fee > amount) throw new HttpError(400, 'Fee looks wrong');
  const name = String(b.name || '').replace(/\s+/g, ' ').trim().slice(0, 80), phone = String(b.phone || '').replace(/[^\d+ ]/g, '').trim().slice(0, 24);
  const act = String(b.act_id || '').trim().replace(/^act_/i, '').replace(/\D/g, '');
  const note = String(b.note || '').replace(/\s+/g, ' ').trim().slice(0, 120);
  const at = saleTime(s, b.date);
  const who = [name, phone].filter(Boolean).join(' · ') || 'WhatsApp customer';
  const text = `WhatsApp · ${who}${act ? ' · act_' + act : ''}${note ? ' · ' + note : ''} · by ${by.name}`.slice(0, 200);
  if (one('SELECT 1 FROM topups WHERE wa=1 AND amount=? AND note=? AND COALESCE(added_at, created_at)>?', amount, text, now() - 30000)) throw new HttpError(409, 'This top-up was already added a moment ago'); // v166: by when it was added
  const r = one<{ id: number }>('INSERT INTO topups(lead_id, agent_id, amount, commission, note, created_at, wa, added_at) VALUES(NULL,?,?,?,?,?,1,?) RETURNING id', by.agent_id ?? null, amount, fee, text, at, now())!;
  return { ok: true, id: r.id, amount, fee };
}
export function delWaTopup(id: unknown) {
  if (!run('DELETE FROM topups WHERE id=? AND wa=1', num(id)).changes) throw new HttpError(404, 'Top-up not found');
  return { ok: true };
}

export function listWaSales(withAgents = false) {
  const s = getSettings();
  const off = num(s.tz_offset_min, 330) * 60000;
  const dayStart = (t: number) => { const d = new Date(t + off); d.setUTCHours(0, 0, 0, 0); return d.getTime() - off; };
  const today = dayStart(now());
  const m = new Date(now() + off); const month = Date.UTC(m.getUTCFullYear(), m.getUTCMonth(), 1) - off;
  const tot = (f: number) => one<{ n: number; v: number }>('SELECT COUNT(*) n, COALESCE(SUM(amount),0) v FROM sales WHERE wa=1 AND created_at>=?', f)!;
  const T = tot(today), M = tot(month), A = tot(0);
  return {
    items: WA_ITEMS.map(x => ({ k: x.k, label: x.label, price: waPrice(s, x.k) })),
    totals: { today: { n: T.n, v: money(T.v) }, month: { n: M.n, v: money(M.v) }, all: { n: A.n, v: money(A.v) } },
    today: new Date(now() + off).toISOString().slice(0, 10),
    rows: all('SELECT id, item, qty, amount, list_price, cust_name, cust_phone, note, by_name, agent_id, created_at FROM sales WHERE wa=1 ORDER BY created_at DESC, id DESC LIMIT 200'),
    agents: withAgents ? all("SELECT id, name, role FROM agents WHERE deleted=0 ORDER BY (role='manager') DESC, name") : undefined, // v161
    topup_pct: num(s.topup_comm_pct, 3), premium_pct: num(tierFor(s, 'premium').topup_comm_pct, 3), // v136
    topups: all('SELECT id, amount, commission fee, note, created_at FROM topups WHERE wa=1 ORDER BY created_at DESC, id DESC LIMIT 100'),
  };
}
