/**
 * v143: automatic texts (follow-ups, bot reminders, dead-chat messages, auto first message) are templates — so after a
 * night 30 chats could get the very same words. vary() keeps the admin's template as the base and:
 *  1) picks one of the versions when the box holds 2–3 of them separated by `||` (on its own line, or " || " in a line);
 *  2) makes small natural word swaps (Hi / Hello / Hey, "just checking in" / "just following up" …) from a fixed list.
 * Nothing is added (no emojis, no new sentences); placeholders, links and prices are never touched.
 */
const GROUPS: string[][] = [
  ['just checking in', 'just following up', 'quickly checking in'],
  ['do you still need', 'do you still want'],
  ['right now', 'at the moment', 'today'],
  ['want me to', 'should I', 'shall I'],
  ['reserve one for you', 'keep one aside for you', 'hold one for you'],
  ['book it for you', 'reserve it for you'],
  ['last reminder from my side', 'one last reminder from my side', 'a final reminder from my side'],
  ['reply here anytime', 'just reply here anytime', 'reply here whenever you like'],
  ['ready to help you', 'here to help you'],
  ['whenever you are ready', 'when you are ready'],
  ['we reply fast', 'we reply quickly'],
  ['thanks for', 'thank you for'],
  ['let me know', 'just let me know'],
  ['bata dijiye', 'bataiye'],
];
const esc = (x: string) => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

/** The versions in one box: lines with only `||`, or " || " inside the text. */
export function versions(tpl: string): string[] {
  const v = String(tpl || '').split(/\n[ \t]*\|\|[ \t]*\n|[ \t]+\|\|[ \t]+/).map(x => x.trim()).filter(Boolean);
  return v.length ? v : [String(tpl || '').trim()];
}

export function vary(tpl: string, rnd: () => number = Math.random, light = true): string {
  const vs = versions(tpl);
  let t = vs[Math.floor(rnd() * vs.length) % vs.length];
  if (!light) return t;
  // greeting at the start
  t = t.replace(/^(Hi|Hello|Hey)\b/, () => ['Hi', 'Hello', 'Hey'][Math.floor(rnd() * 3) % 3]);
  // word swaps, outside {placeholders} and links
  const parts = t.split(/(\{[^}]*\}|https?:\/\/\S+|@\w+)/);
  for (let i = 0; i < parts.length; i += 2) {
    let p = parts[i];
    for (const g of GROUPS) {
      const re = new RegExp('\\b(' + g.map(esc).join('|') + ')\\b', 'gi');
      p = p.replace(re, (m: string) => {
        const pick = g[Math.floor(rnd() * g.length) % g.length];
        return m[0] === m[0].toUpperCase() && m[0] !== m[0].toLowerCase() ? pick[0].toUpperCase() + pick.slice(1) : pick;
      });
    }
    parts[i] = p;
  }
  return parts.join('');
}
