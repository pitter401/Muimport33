/**
 * v151 — Ads data from Meta (master switch).
 *  ON  → spend + results come from the Meta Insights API (same app / token / proxy as Admin → Comments), per day per ad.
 *        Every page that shows ad spend (Home, Ad spend, Campaigns, Leaderboard, channel / WhatsApp blocks) reads it,
 *        because the daily total of each spend line is written into ad_spend (auto=2, source "Meta").
 *        The daily budget rows are not used while ON. Manual entries are only for OTHER ad accounts (column "extra").
 *  OFF → as before: daily budgets + manual entries.
 */
import { all, one, run } from './db';
import { getSettings, setSetting, type Settings } from './settings';
import { graphAll, MetaError, type Creds } from './metagraph';
import { now, money, num, localDate, HttpError } from './util';
import { SPEND_LINES, restartBudgetsFrom } from './profit';

const DAY = 86400000;
export const RT_LINES = ['rt_agency', 'rt_premium', 'rt_funnel'] as const;
export const MAP_LINES = [...SPEND_LINES, ...RT_LINES, 'skip'] as const;
export type MapLine = (typeof MAP_LINES)[number];
export const LINE_LABEL: Record<string, string> = {
  agency: 'Agency page', premium: 'Premium page', funnel: 'Funnel page', telegram: 'Telegram page (old)',
  ch_agency: 'Channel ads · Agency', ch_premium: 'Channel ads · Premium', ch_funnel: 'Channel ads · Funnel',
  wa_agency: 'WhatsApp · Agency', wa_premium: 'WhatsApp · Premium', wa_funnel: 'WhatsApp · Funnel',
  rt_agency: 'Retargeting · Agency', rt_premium: 'Retargeting · Premium', rt_funnel: 'Retargeting · Funnel', skip: 'Not ours (skip)',
};

export function ensureMetaTables() {
  run(`CREATE TABLE IF NOT EXISTS meta_insights(date TEXT, ad_id TEXT, acct TEXT, camp_id TEXT, camp TEXT, adset TEXT, ad TEXT,
       spend REAL, impr INTEGER, reach INTEGER, clicks INTEGER, link_clicks INTEGER, msgs INTEGER, leads INTEGER, subs INTEGER, purchases INTEGER, synced_at INTEGER, PRIMARY KEY(date, ad_id))`);
  run('CREATE INDEX IF NOT EXISTS meta_insights_c ON meta_insights(camp, date)');
  try { run('ALTER TABLE ad_spend ADD COLUMN meta REAL'); } catch { /* there */ }
  try { run('ALTER TABLE ad_spend ADD COLUMN extra REAL'); } catch { /* there */ }
}

export const metaOn = (s: Settings = getSettings()) => s.mads_on === '1';
/** First day whose spend comes from Meta (days before keep their old numbers). */
export const metaSince = (s: Settings = getSettings()) => (metaOn(s) && /^\d{4}-\d{2}-\d{2}$/.test(s.mads_since) ? s.mads_since : null);
/** Is this day's spend from Meta? */
export const isMetaDay = (date: string, s: Settings = getSettings()) => { const d = metaSince(s); return !!d && date >= d; };

function creds(s: Settings): Creds {
  if (!s.cm_user_token) throw new HttpError(400, 'Connect Meta first: Admin → Comments → token (the same app gives the ads data)');
  if (!String(s.cm_proxy || '').trim()) throw new HttpError(400, 'Add the proxy in Admin → Comments — Meta calls never go from the server IP');
  return { token: s.cm_user_token, secret: s.cm_app_secret || undefined, proxy: s.cm_proxy };
}
function accounts(s: Settings): string[] {
  let a: { id: string }[] = []; try { a = JSON.parse(s.cm_accts || '[]'); } catch { /* */ }
  const skip = new Set(String(s.mads_skip_accts || '').split(',').filter(Boolean));
  return a.map(x => x.id).filter(id => !skip.has(id));
}

/* ---------------- campaign → spend line ---------------- */
const PREFIX: [RegExp, MapLine][] = [
  [/^AG-LEAD\b/i, 'agency'], [/^PR-LEAD\b/i, 'premium'], [/^FN-LEAD\b/i, 'funnel'],
  [/^AG-TG\b/i, 'ch_agency'], [/^PR-TG\b/i, 'ch_premium'], [/^FN-TG\b/i, 'ch_funnel'],
  [/^AG-(WA|WAC|CTWA)\b/i, 'wa_agency'], [/^PR-(WA|WAC|CTWA)\b/i, 'wa_premium'], [/^FN-(WA|WAC|CTWA)\b/i, 'wa_funnel'],
];
const lineMap = (s: Settings): Record<string, MapLine> => { try { return JSON.parse(s.mads_line_map || '{}') || {}; } catch { return {}; } };
/** How a campaign's spend is counted: the admin's choice → the planner prefix → words in the name → its chats → Agency. */
export function guessLine(camp: string, s: Settings = getSettings()): { line: MapLine; how: 'set' | 'name' | 'chats' | 'default' } {
  const set = lineMap(s)[camp];
  if (set && (MAP_LINES as readonly string[]).includes(set)) return { line: set, how: 'set' };
  for (const [re, l] of PREFIX) if (re.test(camp.trim())) return { line: l, how: 'name' };
  const n = camp.toLowerCase();
  const biz = /funnel|\bfn\b/.test(n) ? 'funnel' : /prem|\bpr\b/.test(n) ? 'premium' : 'agency';
  if (/retarget|\brt\b|remarket/.test(n)) return { line: `rt_${biz}` as MapLine, how: 'name' };
  if (/whats ?app|\bwa\b|\bwac\b|ctwa|community/.test(n)) return { line: `wa_${biz}` as MapLine, how: 'name' };
  if (/channel|telegram|\btg\b|subscribe/.test(n)) return { line: `ch_${biz}` as MapLine, how: 'name' };
  if (biz !== 'agency' || /\bnorm|agency|\bag\b/.test(n)) return { line: biz as MapLine, how: 'name' };
  // the chats this campaign brought
  const r = one<{ f: number; p: number; w: number; n: number }>(`SELECT COALESCE(SUM(line='funnel'),0) f, COALESCE(SUM(tier='premium'),0) p, COALESCE(SUM(COALESCE(ch,'')='wa'),0) w, COUNT(*) n FROM leads WHERE camp=?`, camp);
  if (r && r.n) {
    const b = r.f * 2 > r.n ? 'funnel' : r.p * 2 > r.n ? 'premium' : 'agency';
    return { line: (r.w * 2 > r.n ? `wa_${b}` : b) as MapLine, how: 'chats' };
  }
  return { line: 'agency', how: 'default' };
}

/* ---------------- sync ---------------- */
type Ins = { date_start: string; ad_id: string; account_id?: string; campaign_id?: string; campaign_name?: string; adset_name?: string; ad_name?: string; spend?: string;
  impressions?: string; reach?: string; clicks?: string; inline_link_clicks?: string; actions?: { action_type: string; value: string }[]; account_currency?: string };
const act = (a: Ins['actions'], ...types: string[]) => Math.max(0, ...types.map(t => num((a || []).find(x => x.action_type === t)?.value)));
let busy = false, lastRun = 0;

/** Pull the days [from..today] (max 90) from every ad account, then rebuild ad_spend for those days. */
export async function madsSync(force = false): Promise<{ days: number; rows: number; spend: number } | null> {
  const s = getSettings();
  const since = metaSince(s);
  if (!since) { if (force) throw new HttpError(400, 'Turn the Meta switch ON first'); return null; }
  const every = Math.max(1, Number(s.cm_every) || 2) * 60000; // same timer as Comments
  if (!force && now() - lastRun < every - 5000) return null;
  if (busy) return null;
  busy = true; lastRun = now();
  try {
    ensureMetaTables();
    const c = creds(s);
    const today = localDate(now(), s);
    // first run after switching ON (or a new start day): everything since the start day; then the last 3 days (Meta still changes them)
    const full = s.mads_full !== since;
    // after a gap (server off for days) start from 2 days before the last good sync, not just the last 3 days
    const lastOk = Number(s.mads_last_ok) || 0;
    let back = localDate(now() - 2 * DAY, s);
    if (lastOk) { const g = localDate(lastOk - 2 * DAY, s); if (g < back) back = g; }
    let from = full ? since : (back > since ? back : since);
    const min = localDate(now() - 89 * DAY, s); if (from < min) from = min;
    let rows = 0; const errs: string[] = [];
    const rate = num(s.inr_rate, 104) || 104;
    for (const a of accounts(s)) {
      try {
        // 10-day pieces so a busy account never gets cut off; a piece that still has more pages is an error (nothing half-saved)
        const data: Ins[] = [];
        for (let a0 = from; a0 <= today;) {
          const a1 = [localDate(Date.parse(a0 + 'T12:00:00Z') + 9 * DAY - num(s.tz_offset_min) * 60000, s), today].sort()[0];
          const part = await graphAll<Ins>(c, `${a}/insights`, {
            level: 'ad', time_increment: 1, time_range: { since: a0, until: a1 }, limit: 500,
            fields: 'date_start,ad_id,account_id,campaign_id,campaign_name,adset_name,ad_name,spend,impressions,reach,clicks,inline_link_clicks,actions,account_currency',
          }, 60);
          if (part.length >= 60 * 500) throw new Error('too many ad rows in 10 days — try again later');
          data.push(...part);
          a0 = localDate(Date.parse(a1 + 'T12:00:00Z') + DAY - num(s.tz_offset_min) * 60000, s);
        }
        run('DELETE FROM meta_insights WHERE acct=? AND date>=? AND date<=?', a, from, today);
        for (const d of data) {
          const cur = d.account_currency === 'INR' ? 1 / rate : 1;
          run(`INSERT OR REPLACE INTO meta_insights(date, ad_id, acct, camp_id, camp, adset, ad, spend, impr, reach, clicks, link_clicks, msgs, leads, subs, purchases, synced_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
            d.date_start, d.ad_id, a, d.campaign_id || null, (d.campaign_name || '').trim(), (d.adset_name || '').trim() || null, (d.ad_name || '').trim() || null,
            money(num(d.spend) * cur), num(d.impressions), num(d.reach), num(d.clicks), num(d.inline_link_clicks),
            act(d.actions, 'onsite_conversion.messaging_conversation_started_7d'),
            act(d.actions, 'lead', 'offsite_conversion.fb_pixel_lead', 'onsite_conversion.lead_grouped'),
            act(d.actions, 'subscribe', 'offsite_conversion.fb_pixel_subscribe', 'onsite_web_subscribe'),
            act(d.actions, 'purchase', 'offsite_conversion.fb_pixel_purchase', 'omni_purchase'), now());
          rows++;
        }
      } catch (e) {
        if ((e as MetaError).kind === 'token') throw e;
        errs.push(`${a}: ${(e as Error).message}`.slice(0, 160));
      }
    }
    // accounts skipped or no longer in the token: their old rows must not count
    const keep = accounts(s);
    run(`DELETE FROM meta_insights WHERE date>=? AND acct NOT IN (${keep.map(() => '?').join(',') || "''"})`, from, ...keep);
    // a failed account → don't turn typed rows into Meta rows (they'd be lost); try again next time
    const days = rebuildSpend(from, today, getSettings(), !errs.length);
    if (full && !errs.length) setSetting('mads_full', since);
    if (!errs.length) setSetting('mads_last_ok', String(now()));
    setSetting('mads_last_sync', String(now()));
    setSetting('mads_last_err', errs.join(' · '));
    const spend = money(one<{ v: number }>('SELECT COALESCE(SUM(spend),0) v FROM meta_insights WHERE date>=? AND date<=?', from, today)!.v);
    return { days, rows, spend };
  } catch (e) {
    setSetting('mads_last_err', `${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}: ${(e as Error).message}`.slice(0, 300));
    if (force) throw e instanceof HttpError ? e : new HttpError(502, (e as Error).message);
    return null;
  } finally { busy = false; }
}

/** Writes each day's Meta spend per line into ad_spend (amount = Meta + manual other-account money). Retargeting / skipped stay out. */
export function rebuildSpend(from: string, to: string, s: Settings = getSettings(), takeTyped = true) {
  ensureMetaTables();
  const since = metaSince(s); if (!since) return 0;
  if (from < since) from = since;
  const map = new Map<string, MapLine>();
  const per = new Map<string, number>(); // date|line → spend
  const dates = new Set<string>();
  for (const r of all<{ date: string; camp: string; v: number }>('SELECT date, camp, SUM(spend) v FROM meta_insights WHERE date>=? AND date<=? GROUP BY date, camp', from, to)) {
    let l = map.get(r.camp); if (!l) { l = guessLine(r.camp, s).line; map.set(r.camp, l); }
    dates.add(r.date);
    if (l === 'skip' || l.startsWith('rt_')) continue;
    per.set(`${r.date}|${l}`, money((per.get(`${r.date}|${l}`) || 0) + r.v));
  }
  // every day in the range: budget rows go (auto=1), Meta rows (auto=2) are rewritten, manual other-account money (extra) stays
  for (let d = from; d <= to; d = localDate(Date.parse(d + 'T12:00:00Z') + DAY - num(s.tz_offset_min) * 60000, s)) {
    dates.add(d);
    run('DELETE FROM ad_spend WHERE date=? AND auto=1', d);
    // rows typed before Meta took over that day (auto=0, no extra column yet) are replaced by Meta
    if (takeTyped) run('UPDATE ad_spend SET extra=0, auto=2, note=? WHERE date=? AND auto=0 AND extra IS NULL', 'Meta', d);
    else if (one<{ x: number }>('SELECT 1 x FROM ad_spend WHERE date=? AND auto=0 AND extra IS NULL', d)) continue; // keep the typed day as it is for now
    for (const l of SPEND_LINES) {
      const v = per.get(`${d}|${l}`) || 0;
      const row = one<{ extra: number | null }>('SELECT extra FROM ad_spend WHERE date=? AND line=?', d, l);
      if (!row && !v) continue;
      const extra = num(row?.extra);
      run(`INSERT INTO ad_spend(date, line, amount, note, auto, meta, extra) VALUES(?,?,?,?,2,?,?)
           ON CONFLICT(date, line) DO UPDATE SET amount=excluded.amount, note=excluded.note, auto=2, meta=excluded.meta, extra=excluded.extra`,
        d, l, money(v + extra), extra ? 'Meta + other account' : 'Meta', money(v), money(extra));
    }
  }
  return dates.size;
}

/** Manual money on a Meta day = another ad account (added on top of Meta). */
export function saveExtra(date: string, line: string, amount: number, note: string) {
  ensureMetaTables();
  const row = one<{ meta: number | null }>('SELECT meta FROM ad_spend WHERE date=? AND line=?', date, line);
  const meta = num(row?.meta);
  run(`INSERT INTO ad_spend(date, line, amount, note, auto, meta, extra) VALUES(?,?,?,?,2,?,?)
       ON CONFLICT(date, line) DO UPDATE SET amount=excluded.amount, note=excluded.note, auto=2, extra=excluded.extra`,
    date, line, money(meta + amount), (note ? note + ' · ' : '') + (meta ? 'Meta + other account' : 'Other account'), meta, money(amount));
}

/* ---------------- switch ---------------- */
export function madsSet(b: { on?: unknown; since?: unknown; line_map?: unknown; skip_accts?: unknown }) {
  const s = getSettings();
  if (b.on !== undefined) {
    const on = !!b.on;
    if (on && !s.cm_user_token) throw new HttpError(400, 'Connect Meta first in Admin → Comments (same app, token and proxy)');
    if (on && s.mads_on !== '1') {
      const today = localDate(now(), s);
      const since = /^\d{4}-\d{2}-\d{2}$/.test(String(b.since || '')) ? String(b.since) : today;
      if (since > today) throw new HttpError(400, 'The start day can’t be in the future');
      if (since < localDate(now() - 89 * DAY, s)) throw new HttpError(400, 'Meta gives day-by-day numbers for the last 90 days only — pick a later start day');
      setSetting('mads_since', since); setSetting('mads_full', '');
      setSetting('mads_on', '1');
    } else if (!on && s.mads_on === '1') {
      setSetting('mads_on', '0');
      // daily budgets start again today (they must not fill the Meta days back)
      restartBudgetsFrom(localDate(now(), s));
      // today becomes a normal day: only the typed other-account money stays (as a typed row), budgets fill the rest
      const t = localDate(now(), s);
      run('DELETE FROM ad_spend WHERE date=? AND auto=2 AND COALESCE(extra,0)=0', t);
      run("UPDATE ad_spend SET amount=extra, meta=NULL, extra=NULL, auto=0, note=REPLACE(REPLACE(note,'Meta + other account','Other account'),' · Other account','') WHERE date=? AND auto=2", t);
    }
  }
  if (b.since !== undefined && b.on === undefined && metaOn()) {
    const v = String(b.since || '');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) throw new HttpError(400, 'Pick a day');
    setSetting('mads_since', v); setSetting('mads_full', '');
  }
  if (b.line_map && typeof b.line_map === 'object') {
    const m = lineMap(getSettings());
    for (const [k, v] of Object.entries(b.line_map as Record<string, string>)) { if (v === '' || v === 'auto') delete m[k]; else if ((MAP_LINES as readonly string[]).includes(v)) m[k] = v as MapLine; }
    setSetting('mads_line_map', JSON.stringify(m));
    const since = metaSince(); if (since) rebuildSpend(since, localDate(now(), getSettings()));
  }
  if (Array.isArray(b.skip_accts)) {
    setSetting('mads_skip_accts', (b.skip_accts as unknown[]).map(String).join(','));
    const keep = accounts(getSettings());
    run(`DELETE FROM meta_insights WHERE acct NOT IN (${keep.map(() => '?').join(',') || "''"})`, ...keep);
    const since = metaSince(); if (since) rebuildSpend(since, localDate(now(), getSettings()));
  }
  return madsStatus();
}

export function madsStatus() {
  ensureMetaTables();
  const s = getSettings();
  let accts: { id: string; name: string }[] = []; try { accts = JSON.parse(s.cm_accts || '[]'); } catch { /* */ }
  const since = metaSince(s);
  const camps = since ? all<{ camp: string; spend: number; msgs: number; days: number }>('SELECT camp, ROUND(SUM(spend),2) spend, SUM(msgs) msgs, COUNT(DISTINCT date) days FROM meta_insights WHERE date>=? GROUP BY camp ORDER BY spend DESC LIMIT 200', since)
    .map(c => ({ ...c, ...guessLine(c.camp, s) })) : [];
  return {
    on: metaOn(s), since: since || '', connected: !!s.cm_user_token, proxy: !!s.cm_proxy, accounts: accts, skip: String(s.mads_skip_accts || '').split(',').filter(Boolean),
    last_sync: Number(s.mads_last_sync) || 0, last_err: s.mads_last_err || '', every: Number(s.cm_every) || 2, camps, lines: LINE_LABEL,
  };
}

/* ---------------- numbers for pages ---------------- */
type Tot = { spend: number; impr: number; reach: number; clicks: number; link_clicks: number; msgs: number; leads: number; subs: number; purchases: number };
/** Meta totals for a day range, optionally only campaigns of some lines (Home line filter). */
export function metaTotals(fromD: string, toD: string, lines?: string[] | null, s: Settings = getSettings()) {
  ensureMetaTables();
  const t: Tot = { spend: 0, impr: 0, reach: 0, clicks: 0, link_clicks: 0, msgs: 0, leads: 0, subs: 0, purchases: 0 };
  const since = metaSince(s); if (!since) return null;
  if (fromD < since) fromD = since;
  for (const r of all<Tot & { camp: string }>('SELECT camp, SUM(spend) spend, SUM(impr) impr, SUM(reach) reach, SUM(clicks) clicks, SUM(link_clicks) link_clicks, SUM(msgs) msgs, SUM(leads) leads, SUM(subs) subs, SUM(purchases) purchases FROM meta_insights WHERE date>=? AND date<=? GROUP BY camp', fromD, toD)) {
    const l = guessLine(r.camp, s).line;
    if (l === 'skip') continue;
    if (lines && !lines.includes(l)) continue;
    for (const k of Object.keys(t) as (keyof Tot)[]) t[k] += num(r[k]);
  }
  t.spend = money(t.spend);
  const d = (a: number, b: number) => (b ? money(a / b) : null);
  return { ...t, ctr: t.impr ? Math.round(t.clicks / t.impr * 10000) / 100 : null, cpc: d(t.spend, t.clicks), cpm: t.impr ? money(t.spend / t.impr * 1000) : null,
    cost_per_msg: d(t.spend, t.msgs), cost_per_lead: d(t.spend, t.leads), cost_per_sub: d(t.spend, t.subs), freq: t.reach ? Math.round(t.impr / t.reach * 100) / 100 : null, since };
}

/** Spend of each campaign per day (for chat attribution). */
export function campDaySpend(fromD: string, toD: string) {
  ensureMetaTables();
  const since = metaSince(); if (since && fromD < since) fromD = since;
  const m = new Map<string, number>();
  for (const r of all<{ date: string; camp: string; v: number }>('SELECT date, camp, SUM(spend) v FROM meta_insights WHERE date>=? AND date<=? GROUP BY date, camp', fromD, toD)) m.set(`${r.date}|${r.camp}`, r.v);
  return m;
}

/** A day/line that already holds Meta numbers (also after the switch went OFF) — typed money is added, never replaces Meta. */
export function hasMetaRow(date: string, line: string) {
  ensureMetaTables();
  return !!one<{ x: number }>('SELECT 1 x FROM ad_spend WHERE date=? AND line=? AND auto=2 AND meta IS NOT NULL', date, line);
}
