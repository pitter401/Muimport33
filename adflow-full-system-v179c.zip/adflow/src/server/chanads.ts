/**
 * Channel ads (v111): Meta ad (Subscribe) → /agency|premium|funnel/telegram → join request on the channel
 *   → the bot DMs them (image + offer, then the other services) → request approved at once → Meta Subscribe.
 * Everything leads into the bot chat: "/start svc_<line>" (a button) makes a lead for that service, assigned like any
 * other lead (round robin / Funnel → manager), welcomed, and worked in the agent app. A plain /start (channel posts link
 * to the bot) shows the services menu first. No Adsbhai Support account link anywhere in this flow.
 */
import { one, all, run } from './db';
import { getSettings, setSetting, tierFor, type Settings } from './settings';
import { tg } from './telegram';
import { sendCapi, buildUserData } from './capi';
import { publicUrl } from './email';
import { money, now, rnd } from './util';
import { shortDelivery } from './content';
import { offerImageUrl, offerLine, sendTgPhoto, tgBtnImgOn, welcomeCaption } from './offerimg';

export type ChanLine = 'agency' | 'premium' | 'funnel';
export const CHAN_LINES: ChanLine[] = ['agency', 'premium', 'funnel'];
export const chanLine = (x: unknown): ChanLine => (x === 'premium' ? 'premium' : x === 'funnel' ? 'funnel' : 'agency');
/** The lead fields for a line. */
export const lineFields = (ln: ChanLine) => ({ line: ln === 'funnel' ? 'funnel' : 'agency', tier: ln === 'premium' ? 'premium' : null, service: ln === 'funnel' ? 'funnel' : 'account' });

const usd = (v: unknown) => { const n = money(v); return '$' + (Number.isInteger(n) ? String(n) : n.toFixed(2)); };
/** Telegram prices (what we charge in chats). */
export function chanPrices(s: Settings) {
  return { agency: usd(s.price_account), premium: usd(tierFor(s, 'premium').price_account), funnel: usd(s.price_funnel), fb: usd(s.price_fb_old), fee: `${s.topup_comm_pct || 3}%` };
}
/** v138: delivery time of a line, always from the settings (Premium: premium_delivery; Agency / Funnel: delivery_time). */
export const chanDelivery = (s: Settings, ln: ChanLine = 'agency') => String((ln === 'premium' ? tierFor(s, 'premium').delivery_time : s.delivery_time) || s.delivery_time || '').trim();
const fill = (s: Settings, t: string, ln: ChanLine = 'agency') => {
  const p = chanPrices(s);
  return String(t || '').replace(/\{delivery\}/g, chanDelivery(s, ln)).replace(/\{delivery_premium\}/g, chanDelivery(s, 'premium')).replace(/\{price_agency\}/g, p.agency).replace(/\{price_premium\}/g, p.premium).replace(/\{price_funnel\}/g, p.funnel)
    .replace(/\{price_fb\}/g, p.fb).replace(/\{fee\}/g, p.fee).replace(/\{brand\}/g, s.brand_name || '');
};
const premiumOn = (s: Settings) => s.premium_on === '1';
export const LABEL: Record<ChanLine, string> = { agency: 'Agency ad account', premium: 'Premium ad account', funnel: 'Landing page + funnel' };

/* ---------------- links ---------------- */
export const botLink = (s: Settings, param = '') => (s.bot_username ? `https://t.me/${s.bot_username}${param ? '?start=' + param : ''}` : '');
/** Website order with the right product at Telegram prices (null when website orders are off / no PUBLIC_URL). */
export function orderLink(s: Settings, ln: ChanLine, abs = true, tok = '') {
  if (s.web_orders_on !== '1') return null;
  const q = ln === 'funnel' ? 'kind=funnel' : ln === 'premium' && premiumOn(s) ? 'tier=premium' : 'kind=account';
  // cj = their join (ad click data) → a website order from inside Telegram still counts for the ad
  const path = `/order?${q}&tg=1&src=channel${tok ? '&cj=' + tok : ''}`;
  if (!abs) return path;
  const base = publicUrl();
  return base ? base + path : null;
}
export const waLink = (s: Settings) => (s.wa_on === '1' && s.wa_comm_link ? s.wa_comm_link : '');
/** The image sent with the bot's first message — v140: the ONE line → image resolver shared with WhatsApp (admin's own
 *  https image for that line, else the built-in offer image made from the settings). '' = no image for this line. */
export function chanImage(s: Settings, ln: ChanLine) {
  return offerImageUrl(s, ln);
}

/* ---------------- the bot's messages ---------------- */
type Btn = { text: string; url: string };
/** v116: Telegram refuses the WHOLE message if one button link is bad (e.g. a WhatsApp link saved without https://). */
export function cleanUrl(u: unknown): string | null {
  const x = String(u || '').trim();
  if (/^https?:\/\/[^\s]+$/i.test(x)) return x;
  if (/^(t\.me|telegram\.me|chat\.whatsapp\.com|wa\.me|whatsapp\.com|www\.)[^\s]*$/i.test(x)) return 'https://' + x;
  return null;
}
const kb = (rows: (Btn | null)[][]) => ({ inline_keyboard: rows.map(r => r.filter((b): b is Btn => !!b && !!cleanUrl(b.url)).map(b => ({ text: b.text, url: cleanUrl(b.url)! }))).filter(r => r.length) });
/** v116: the pre-typed first message in the support chat (also how we know which service they picked). */
export const SVC_TEXT: Record<ChanLine, string> = { agency: 'Hi, I want an agency ad account.', premium: 'Hi, I want a Premium ad account.', funnel: 'Hi, I want a landing page + funnel.' };
/** v116: open the chat with our support account (Telegram Business) with the message typed; no support account → the bot chat like before. */
/** v118: a short code in the pre-typed message: which service + who (Telegram id in base 36), e.g. "CP-1x9k2z" = Premium.
 *  Our support chat reads it, so the chat is tracked even if the customer changes the words. */
const LETTER: Record<ChanLine, string> = { agency: 'A', premium: 'P', funnel: 'F' };
export const chanCode = (ln: ChanLine, who: string | number) => (/^\d{3,}$/.test(String(who)) ? `C${LETTER[ln]}-${Number(who).toString(36)}` : '');
export function readChanCode(t: string): { line: ChanLine; uid: string } | null {
  const m = String(t || '').match(/\bC([APF])-([0-9a-z]{2,14})\b/i);
  if (!m) return null;
  const uid = parseInt(m[2].toLowerCase(), 36);
  return Number.isFinite(uid) && uid > 0 ? { line: m[1].toUpperCase() === 'P' ? 'premium' : m[1].toUpperCase() === 'F' ? 'funnel' : 'agency', uid: String(uid) } : null;
}
export const supportLink = (s: Settings, ln: ChanLine, who: string | number = '') => {
  if (!s.owner_username) return '';
  const code = chanCode(ln, who);
  return `https://t.me/${String(s.owner_username).replace(/^@/, '')}?text=${encodeURIComponent(SVC_TEXT[ln] + (code ? ` My code: ${code}` : ''))}`;
};
const svcBtn = (s: Settings, ln: ChanLine, tok: string, text?: string, who: string | number = ''): Btn | null => {
  if (ln === 'premium' && !premiumOn(s)) return null;
  const url = supportLink(s, ln, who) || (s.bot_username ? botLink(s, `svc_${ln}${tok ? '_' + tok : ''}`) : '');
  return url ? { text: text || `${ln === 'funnel' ? '🚀' : ln === 'premium' ? '⭐' : '✅'} ${LABEL[ln]} · ${chanPrices(s)[ln]}${ln === 'funnel' ? '/month' : ''}`, url } : null;
};
/** v116: which service a first message in the support chat is about (the pre-typed text, or their own words). */
export function lineFromText(t: string): ChanLine | null {
  const x = String(t || '').toLowerCase();
  if (/premium/.test(x)) return 'premium';
  if (/funnel|landing/.test(x)) return 'funnel';
  if (/ad ?account|agency/.test(x)) return 'agency';
  return null;
}
/** v116: has this Telegram user come through the channel flow (joined via our links, got the bot message, or opened the bot)? */
export function channelPerson(uid: string) {
  const cj = one<{ id: number; tok: string | null; vid: string | null; line: string | null; line_x: string | null; src: string | null; ip: string | null; ua: string | null; fbc: string | null; fbp: string | null; page_url: string | null }>(
    "SELECT * FROM channel_joins WHERE tg_user=? ORDER BY (src='ad') DESC, id DESC LIMIT 1", uid);
  const known = !!cj || !!one('SELECT 1 FROM join_dms WHERE tg_user=?', uid) || !!one('SELECT 1 FROM bot_subs WHERE tg_user=?', uid);
  return known ? { cj: cj || null } : null;
}

/* ---------- v139: info buttons in the bot welcome (Settings → Telegram channel → "Info buttons in bot welcome") ----------
 * See pricing / What's included are answered IN the bot chat (no lead, no Meta event). Only the action buttons (Get account,
 * Buy Premium, Start my funnel, Talk to agent) open the support chat, with the line's message typed — the lead and the
 * Contact / Lead event come when they really write there, like before. No emoji in these buttons. */
export const botInfoOn = (s: Settings) => s.chan_info_btns !== '0';
export type InfoKind = 'p' | 'i';
// v140: a small icon on these fixed button labels only (user-approved); every label ≤ 20 characters with the icon
export const INFO_LABEL: Record<InfoKind, string> = { p: '💰 See pricing', i: "📦 What's included" };
export const ACTION_LABEL: Record<ChanLine, string> = { agency: '✅ Get account', premium: '💎 Buy Premium', funnel: '📈 Start my funnel' };
export const TALK_BTN = '💬 Talk to agent';
export const TALK_TEXT: Record<ChanLine, string> = { agency: 'Hi, I want to talk to an agent about the agency ad account.', premium: 'Hi, I want to talk to an agent about the Premium ad account.', funnel: 'Hi, I want to talk to an agent about the landing page + funnel.' };
const supportUrl = (s: Settings, ln: ChanLine, who: string | number, text: string, tok = '') => {
  if (!s.owner_username) return s.bot_username ? botLink(s, `svc_${ln}${tok ? '_' + tok : ''}`) : '';
  const code = chanCode(ln, who);
  return `https://t.me/${String(s.owner_username).replace(/^@/, '')}?text=${encodeURIComponent(text + (code ? ` My code: ${code}` : ''))}`;
};
type AnyBtn = { text: string; url?: string; callback_data?: string };
/** The info buttons of a line: [the info buttons not tapped yet] / [the action → support] / [Talk to agent → support]. */
export function infoRows(s: Settings, ln: ChanLine, who: string | number, done: InfoKind | null = null, tok = ''): AnyBtn[][] {
  const info = (['p', 'i'] as InfoKind[]).filter(k => k !== done).map(k => ({ text: INFO_LABEL[k], callback_data: `bi:${LETTER[ln]}:${k}` }));
  const act = supportUrl(s, ln, who, SVC_TEXT[ln], tok), talk = supportUrl(s, ln, who, TALK_TEXT[ln], tok);
  const rows: AnyBtn[][] = [];
  if (info.length) rows.push(info);
  if (act) rows.push([{ text: ACTION_LABEL[ln], url: cleanUrl(act)! }]);
  if (talk) rows.push([{ text: TALK_BTN, url: cleanUrl(talk)! }]);
  return rows;
}
export const lineOfLetter = (x: string): ChanLine | null => (x === 'A' ? 'agency' : x === 'P' ? 'premium' : x === 'F' ? 'funnel' : null);

// v117: people from the Premium ad never see the cheaper Agency account (we upsell $25 → Premium, never down)
const others = (s: Settings, ln: ChanLine) => CHAN_LINES.filter(x => x !== ln && !(x === 'premium' && !premiumOn(s)) && !(ln === 'premium' && x === 'agency'));
/** The ONE message after the join request: image + offer of the page they came from + the other services, all buttons. */
export function joinOffer(s: Settings, ln: ChanLine, tok: string, who: string | number = '') {
  const p = chanPrices(s);
  const oth = others(s, ln);
  const also = String(s.chan_dm_upsell || '').trim();
  const list = oth.map(x => x === 'funnel' ? `landing page + funnel (${p.funnel}/month)` : x === 'premium' ? `Premium ad accounts (${p.premium})` : `agency ad accounts (${p.agency})`).join(', ');
  const text = fill(s, (s as Record<string, string>)[`chan_dm_${ln}`] || '', ln).trim() + (also && list ? `\n\n${fill(s, also)} ${list}.` : '');
  const ord = orderLink(s, ln, true, tok);
  const wa = waLink(s);
  if (botInfoOn(s)) {
    // v139: the info buttons first; the other services / website / WhatsApp as plain links below (no emoji)
    const p2 = chanPrices(s);
    const extra = kb([
      [ord ? { text: 'Order on website', url: ord } : null],
      ...oth.map(x => [svcBtn(s, x, tok, `${LABEL[x]} · ${p2[x]}${x === 'funnel' ? '/month' : ''}`, who)]),
      [wa ? { text: 'WhatsApp community', url: wa } : null],
    ]).inline_keyboard;
    // v140: ONE photo message: the line's image + a short caption (≤300; the long text when it is that short) + the buttons
    const image = tgBtnImgOn(s) ? chanImage(s, ln) : '';
    // the caption is always the short one (product + price, one fact, delivery, one next step); the long text is the fallback
    return { text, markup: { inline_keyboard: [...infoRows(s, ln, who, null, tok), ...extra] }, image, caption: image ? welcomeCaption(s, ln, 'tg') : text, parse_mode: image ? 'HTML' as const : undefined };
  }
  const markup = kb([
    [svcBtn(s, ln, tok, ln === 'funnel' ? '🚀 Start my funnel setup' : '✅ I want this account', who)],
    [ord ? { text: '🛒 Order on website', url: ord } : null],
    ...oth.map(x => [svcBtn(s, x, tok, undefined, who)]),
    [wa ? { text: 'WhatsApp community', url: wa } : null],
  ]);
  return { text, markup, image: tgBtnImgOn(s) ? chanImage(s, ln) : '', caption: text, parse_mode: undefined };
}
/** /start with nothing picked yet (channel post link, or someone found the bot): the services menu. */
export function serviceMenu(s: Settings, tok = '', from: ChanLine | null = null, who: string | number = '') {
  // v117: someone from the Premium ad → Premium + Funnel only, website order for Premium
  const prem = from === 'premium' && premiumOn(s);
  const lines = CHAN_LINES.filter(x => !(x === 'premium' && !premiumOn(s)) && !(prem && x === 'agency'));
  const ord = orderLink(s, prem ? 'premium' : 'agency', true, tok);
  const wa = waLink(s);
  return {
    text: fill(s, s.chan_menu_text || ''),
    markup: kb([...lines.map(x => [svcBtn(s, x, tok, undefined, who)]), [ord ? { text: '🛒 Order on website', url: ord } : null], [wa ? { text: 'WhatsApp community', url: wa } : null]]),
  };
}

/** The photo + caption + buttons as ONE message (file_id cached after the first upload); no image / refused → the text. */
async function sendWithImage(s: Settings, chatId: string | number, image: string, text: string, markup: unknown, caption = text, parse_mode?: 'HTML') {
  const r = await sendTgPhoto(s, chatId, image, { caption, parse_mode, markup, short: caption.length > 1024 ? '' : undefined, fallback: text });
  if (!r.ok || r.err) botError(String(r.err || r.description || '').replace(/^ · /, ''));
  return r;
}
/** v116: last problem the bot had sending to someone (shown in Settings → Channel ads) — so a silent bot can be explained. */
export function botError(e: string) {
  if (/blocked by the user|user is deactivated|chat not found/i.test(e)) return; // their side, nothing to fix
  try { setSetting('bot_send_error', `${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}: ${e.slice(0, 300)}`); } catch { /* */ }
}
/** v116: the services menu as one message (with the same safety as above). */
export async function sendMenu(s: Settings, chatId: string | number, prefix = '', from: ChanLine | null = null) {
  const mm = serviceMenu(s, '', from, chatId);
  return sendWithImage(s, chatId, '', (prefix ? prefix + '\n\n' : '') + mm.text, mm.markup);
}

/** Join request from a channel-ad page: ONE message, the offer + the other services (only possible BEFORE the request is approved). */
export async function dmOnJoin(s: Settings, userChatId: number | string, ln0: ChanLine, tok: string) {
  // v140: a Premium person never gets the Agency offer (or its image), even from the Agency page
  const ln = offerLine(ln0, ln0 === 'agency' && /^\d+$/.test(String(userChatId)) && isPremiumPerson(String(userChatId)));
  const a = joinOffer(s, ln, tok, userChatId);
  const r1 = await sendWithImage(s, userChatId, a.image, a.text, a.markup, a.caption, a.parse_mode).catch(e => ({ ok: false, description: String(e) }));
  return { ok: !!r1.ok, error: r1.ok ? '' : String((r1 as { description?: string }).description || '') };
}

/** v116: welcome for everyone else who asks to join (not from a channel-ad page): image + services + website + WhatsApp. */
export function joinWelcome(s: Settings, who: string | number = '') {
  let t = String(s.chan_join_dm_text || '');
  if (!premiumOn(s)) t = t.split('\n').filter(l => !l.includes('{price_premium}')).join('\n');
  const text = fill(s, t).trim().slice(0, 1024);
  const ord = orderLink(s, 'agency', true, '');
  const wa = waLink(s);
  let markup: { inline_keyboard: AnyBtn[][] } = kb([...CHAN_LINES.map(x => [svcBtn(s, x, '', undefined, who)]), [ord ? { text: '🛒 Order on website', url: ord } : null], [wa ? { text: 'WhatsApp community', url: wa } : null]]);
  // v139: info buttons on → pricing / details of the agency account in the bot first (the services stay below)
  if (botInfoOn(s)) markup = { inline_keyboard: [[{ text: INFO_LABEL.p, callback_data: 'bi:A:p' }, { text: INFO_LABEL.i, callback_data: 'bi:A:i' }], ...markup.inline_keyboard] };
  const own = String(s.chan_img_welcome || '').trim();
  const image = !tgBtnImgOn(s) ? '' : /^https:\/\//.test(own) ? own : publicUrl() ? `${publicUrl()}/chan/welcome.jpg` : '';
  return { text, markup, image };
}
export async function dmWelcome(s: Settings, userChatId: number | string) {
  const a = joinWelcome(s, userChatId);
  if (!a.text) return { ok: false, error: 'no text' };
  const r1 = await sendWithImage(s, userChatId, a.image, a.text, a.markup).catch(e => ({ ok: false, description: String(e) }));
  return { ok: !!r1.ok, error: r1.ok ? '' : String((r1 as { description?: string }).description || '') };
}

/** Their latest channel-ad join (by Telegram user) — for people who come back through the channel post link. */
export function latestJoinFor(uid: string) {
  return one<{ id: number; tok: string | null; vid: string | null; line: string | null; line_x: string | null; ip: string | null; ua: string | null; fbc: string | null; fbp: string | null; page_url: string | null }>(
    "SELECT * FROM channel_joins WHERE tg_user=? AND src='ad' ORDER BY id DESC LIMIT 1", uid);
}

/** Phase 2 optimization event: they picked a service in the bot (Admin → Channel ads: Contact / Lead / off). Once per person. */
export async function sendPickEvent(s: Settings, lead: { id: number; line?: string | null; name?: string | null; ip?: string | null; ua?: string | null; fbc?: string | null; fbp?: string | null; fbclid?: string | null; vid?: string | null; page_url?: string | null; created_at?: number | null }, ln: ChanLine, uid: string) {
  const ev = s.chan_pick_event === 'Lead' ? 'Lead' : s.chan_pick_event === 'off' ? '' : 'Contact';
  if (!ev || (!lead.fbc && !lead.fbp && !lead.vid)) return null; // no ad click behind it → nothing Meta could use
  const line = ln === 'funnel' ? 'funnel' : 'agency';
  const id = `pick_${line}_${uid}`;
  return sendCapi(s, {
    line, event_id: id, event_name: ev, lead_id: lead.id, source_url: lead.page_url || null, once: { events: [id] },
    user_data: buildUserData(lead as Parameters<typeof buildUserData>[0], s), custom_data: { content_name: LABEL[ln] + ' (from the channel)' },
  }).catch(e => ({ error: String(e) }));
}

/** Bot "subscribers": everyone who started the bot from the channel flow (for later broadcasts / stats). */
/** v116: answer someone who opened the bot: their channel-ad offer, else the welcome they got on joining, else the menu.
 *  Marks them answered (bot_subs.replied_at) — the worker also answers, once, everyone who pressed Start and got nothing. */
export async function answerStart(s: Settings, chatId: string | number, uid: string) {
  const back = latestJoinFor(uid);
  let r: { ok: boolean; error?: string } | null = null;
  const prem = isPremiumPerson(uid);
  if (back) r = await dmOnJoin(s, chatId, chanLine(back.line_x || back.line), back.tok || '');
  else if (!prem && s.chan_join_dm_on !== '0' && one('SELECT 1 FROM join_dms WHERE tg_user=?', uid)) r = await dmWelcome(s, chatId);
  if (!r?.ok) { const m = await sendMenu(s, chatId, '', prem ? 'premium' : back ? chanLine(back.line_x || back.line) : null); r = { ok: !!m.ok, error: m.ok ? '' : String(m.description || '') }; }
  run('UPDATE bot_subs SET replied_at=? WHERE tg_user=?', r.ok ? now() : (/blocked|deactivated|not found/i.test(r.error || '') ? -1 : null), uid);
  return r;
}
/** v118: someone who ever was a Premium person (Premium ad, Premium chat or a Premium sale) never sees the cheaper Agency account. */
export function isPremiumPerson(uid: string) {
  return !!one("SELECT 1 FROM leads WHERE tg_chat_id=? AND tier='premium' AND status!='merged'", uid) || latestJoinFor(uid)?.line_x === 'premium';
}
/** v118: the product buttons for someone (with their code): Premium person → Premium + Funnel; everyone else → all (Agency people may see Premium). */
export function productButtons(s: Settings, uid: string) {
  const prem = isPremiumPerson(uid);
  return CHAN_LINES.filter(x => !(prem && x === 'agency')).map(x => [svcBtn(s, x, '', undefined, uid)]).filter(r => r[0]) as Btn[][];
}
export function noteBotStart(uid: string, name: string, src: string, cjId: number | null) {
  run(`INSERT INTO bot_subs(tg_user, name, src, cj_id, started_at, last_at) VALUES(?,?,?,?,?,?)
       ON CONFLICT(tg_user) DO UPDATE SET last_at=excluded.last_at, bfu_n=CASE WHEN COALESCE(bot_subs.bfu_n,0) >= 9 THEN 0 ELSE bot_subs.bfu_n END, bfu_at=NULL, name=COALESCE(NULLIF(excluded.name,''), bot_subs.name), cj_id=COALESCE(bot_subs.cj_id, excluded.cj_id)`,
    uid, name.slice(0, 80), src.slice(0, 20), cjId, now(), now());
}

/** A channel-ad join (by its token) → the browser / click data for the lead. */
export function joinByTok(tok: string) {
  return /^[A-Za-z0-9]{6,16}$/.test(tok) ? one<{ id: number; vid: string | null; line: string | null; tier: string | null; ip: string | null; ua: string | null; fbc: string | null; fbp: string | null; page_url: string | null }>('SELECT * FROM channel_joins WHERE tok=?', tok) : undefined;
}
export const newTok = () => rnd(10);

/* ---------------- page text per line ---------------- */
export function chanCopy(s: Settings, ln: ChanLine) {
  const p = chanPrices(s);
  if (ln === 'funnel') return {
    sub: `A landing page and a full lead funnel built for your business, with Meta tracking set up. ${p.funnel}/month. Join the channel to see real results first.`,
    topics: ['Landing pages', 'Lead funnels', 'Meta tracking (CAPI)', 'Client results', 'Offers & updates'],
    offer: [
      { icon: 'filter', t: `Landing page + funnel · ${p.funnel}/month`, d: 'A fast landing page and a funnel that sends leads straight to your Telegram or WhatsApp.', tag: 'Service' },
      { icon: 'zap', t: 'Meta tracking done right', d: 'Server-side events (CAPI) so Meta learns from real leads and your cost per result drops.', tag: 'Setup' },
      { icon: 'star', t: 'Real client results', d: 'See live numbers from campaigns we run: cost per lead, joins and sales.', tag: 'Proof' },
      { icon: 'users', t: 'Talk to our team', d: 'Ask anything about your business and how the funnel would work for you.', tag: 'Support' },
    ],
    posts: [['Client result', 'Cost per result this week', '10:24'], ['Funnel setup', 'What you get for ' + p.funnel + '/month', '13:05'], ['New offer', 'Setup slots this week', '18:40']] as [string, string, string][],
    tiles: [['Price', p.funnel + '/mo'], ['Tracking', 'CAPI'], ['Results', 'Live'], ['Support', '7 days']] as [string, string][],
    faq: [
      ['How much does the funnel cost?', `${p.funnel} per month. It is a paid service, managed for you every month.`],
      ['What does the funnel setup include?', 'A landing page, a lead funnel into your Telegram or WhatsApp, and Meta tracking, managed for you every month.'],
      ['How fast is the setup?', 'Most setups are ready within a few days once you send your details.'],
      ['How do I start?', 'Join the channel. Our bot sends you the details right away, and you can start from there.'],
    ] as [string, string][],
    band: 'Funnel results, offers and setup slots reach the {name} channel first.', foot: `Landing page + funnel setup: ${p.funnel}/month. Our team handles it on Telegram.`, lock: 'Paid service · our team replies on Telegram',
  };
  const prem = ln === 'premium';
  const price = prem ? p.premium : p.agency;
  return {
    sub: `${prem ? 'Premium' : 'Agency'} ad accounts for Meta ads: no spending limit, no 18% GST on ad spend, shared to your Business Manager in ${chanDelivery(s, ln)}. ${price} per account.`,
    topics: [prem ? 'Premium ad accounts' : 'Agency ad accounts', 'No spending limit', 'No 18% GST', 'Top-up ' + p.fee, 'Offers & updates'],
    offer: [
      { icon: prem ? 'star' : 'card', t: `${prem ? 'Premium' : 'Agency'} ad account · ${price}`, d: 'Shared directly to your Business Manager. Run ads from your own Ads Manager.', tag: 'Service' },
      { icon: 'zap', t: 'No spending limit', d: 'Spend as much as you want from day one, no slow warm-up.', tag: 'Benefit' },
      { icon: 'dollar', t: 'No 18% GST on ad spend', d: `Top up any time. Fee only ${p.fee}.`, tag: 'Benefit' },
      { icon: 'shield', t: 'Real human support', d: 'Our team helps on Telegram 7 days a week.', tag: 'Support' },
    ],
    posts: [['Account delivered', 'Shared to a client BM in 18 min', '10:24'], [prem ? 'Premium account' : 'Agency account', `Today's rate: ${price}`, '13:05'], ['Top-up done', `Fee only ${p.fee}`, '18:40']] as [string, string, string][],
    tiles: [['Price', price], ['Delivery', shortDelivery(chanDelivery(s, ln))], ['GST', 'None'], ['Support', '7 days']] as [string, string][],
    faq: [
      ['How much is an ad account?', `${price} per account. Top-ups have a ${p.fee} fee.`],
      ['How does the account work?', 'You send your Business Manager ID, we share the account to it, you top up and run ads from your own Ads Manager.'],
      ['How fast is delivery?', `Usually within ${chanDelivery(s, ln)} after payment.`],
      ['How do I order?', 'Join the channel. Our bot sends you the details right away, and you can order from there or on our website.'],
    ] as [string, string][],
    band: 'Account offers, delivery updates and results reach the {name} channel first.', foot: `${prem ? 'Premium' : 'Agency'} ad accounts ${price} each, top-up fee ${p.fee}. Our team handles it on Telegram.`, lock: 'Paid service · our team replies on Telegram',
  };
}

/* ---------------- stats ---------------- */
export function chanStats(from: number, to: number, spend: Record<string, number> = {}) {
  const out: Record<string, { visitors: number; spend: number; cpj: number | null; cpc: number | null; cps: number | null; joins: number; dms: number; joined: number; left: number; stayed: number; subs: number; waiting: number; leads: number; contacts: number; sales: number; revenue: number; orders: number; order_rev: number; bot_info: number; bot_info_support: number }> = {};
  for (const ln of CHAN_LINES) {
    // people who asked to join in this period (one row per visitor link) and what happened to them since
    const j = one<{ n: number; d: number; jn: number; lf: number; sb: number; wt: number }>(`SELECT COUNT(*) n, COALESCE(SUM(dm_at IS NOT NULL),0) d, COALESCE(SUM(joined_at IS NOT NULL),0) jn,
      COALESCE(SUM(left_at IS NOT NULL),0) lf, COALESCE(SUM(sub_at IS NOT NULL),0) sb, COALESCE(SUM(sub_due IS NOT NULL AND sub_state IS NULL AND left_at IS NULL),0) wt
      FROM channel_joins WHERE src='ad' AND line_x=? AND requested_at>=? AND requested_at<?`, ln, from, to)!;
    const f = lineFields(ln);
    const lw = `l.source='channel' AND COALESCE(l.line,'agency')=? AND ${ln === 'premium' ? "l.tier='premium'" : "COALESCE(l.tier,'')!='premium'"}`;
    const l = one<{ n: number }>(`SELECT COUNT(*) n FROM leads l WHERE ${lw} AND l.created_at>=? AND l.created_at<?`, f.line, from, to)!;
    const sa = one<{ n: number; v: number }>(`SELECT COUNT(*) n, COALESCE(SUM(x.amount),0) v FROM sales x JOIN leads l ON l.id=x.lead_id WHERE ${lw} AND x.created_at>=? AND x.created_at<?`, f.line, from, to)!;
    const kindW = ln === 'funnel' ? "kind='funnel'" : ln === 'premium' ? "kind!='funnel' AND COALESCE(tier,'')='premium'" : "kind!='funnel' AND COALESCE(tier,'')!='premium'";
    const o = one<{ n: number; v: number }>(`SELECT COUNT(*) n, COALESCE(SUM(amount),0) v FROM web_orders WHERE src='channel' AND ${kindW} AND paid_at IS NOT NULL AND created_at>=? AND created_at<?`, from, to)!;
    const ct = one<{ n: number }>(`SELECT COUNT(*) n FROM capi_log c JOIN leads l ON l.id=c.lead_id WHERE c.event_id LIKE 'pick\\_%' ESCAPE '\\' AND ${lw} AND c.created_at>=? AND c.created_at<?`, f.line, from, to)!;
    const vis = one<{ n: number }>('SELECT COUNT(*) n FROM page_visits WHERE page=? AND created_at>=? AND created_at<?', 'ch_' + ln, from, to)!.n;
    // v139: people who tapped See pricing / What's included in the bot in this period, and how many of them then wrote to support
    const bi = one<{ n: number; w: number }>(`SELECT COUNT(DISTINCT b.tg_user) n, COUNT(DISTINCT CASE WHEN EXISTS(SELECT 1 FROM leads l WHERE l.tg_chat_id=b.tg_user AND l.status!='merged') THEN b.tg_user END) w
      FROM bot_taps b WHERE b.line=? AND b.at>=? AND b.at<?`, ln, from, to)!;
    const sp = money(spend[ln] || 0), sold = sa.n + o.n;
    out[ln] = { visitors: vis, spend: sp, cpj: j.n && sp ? money(sp / j.n) : null, cpc: l.n && sp ? money(sp / l.n) : null, cps: sold && sp ? money(sp / sold) : null, joins: j.n, dms: j.d, joined: j.jn, left: j.lf, stayed: j.jn - j.lf, subs: j.sb, waiting: j.wt, leads: l.n, contacts: ct.n, sales: sa.n, revenue: money(sa.v), orders: o.n, order_rev: money(o.v), bot_info: bi.n, bot_info_support: bi.w };
  }
  const subs = one<{ n: number }>('SELECT COUNT(*) n FROM bot_subs WHERE started_at>=? AND started_at<?', from, to)!.n;
  return { lines: out, bot_starts: subs, bot_subs_total: one<{ n: number }>('SELECT COUNT(*) n FROM bot_subs')!.n };
}
/** v120: where a Telegram user came from — a channel-ad page (/agency|premium|funnel/telegram), the /telegram page ad, or organic. */
const ORIGIN = (u: string) => `CASE WHEN EXISTS(SELECT 1 FROM channel_joins cj WHERE cj.tg_user=${u} AND cj.src='ad') THEN 'ads' WHEN EXISTS(SELECT 1 FROM channel_joins cj WHERE cj.tg_user=${u} AND cj.src='page') THEN 'tg' ELSE 'organic' END`;
/** v120 Home → /telegram page ads: people who asked to join from /telegram in this period and what they did since. */
export function tgPageStats(from: number, to: number, spend = 0) {
  const j = one<{ n: number; jn: number; lf: number; sb: number; wt: number }>(`SELECT COUNT(DISTINCT tg_user) n, COUNT(DISTINCT CASE WHEN joined_at IS NOT NULL THEN tg_user END) jn,
    COUNT(DISTINCT CASE WHEN joined_at IS NOT NULL AND left_at IS NOT NULL THEN tg_user END) lf, COUNT(DISTINCT CASE WHEN sub_at IS NOT NULL THEN tg_user END) sb,
    COUNT(DISTINCT CASE WHEN sub_due IS NOT NULL AND sub_state IS NULL AND left_at IS NULL THEN tg_user END) wt
    FROM channel_joins WHERE src='page' AND tg_user IS NOT NULL AND requested_at>=? AND requested_at<?`, from, to)!;
  const coh = "SELECT tg_user FROM channel_joins WHERE src='page' AND tg_user IS NOT NULL AND requested_at>=? AND requested_at<?";
  const st = one<{ n: number }>(`SELECT COUNT(*) n FROM bot_subs WHERE tg_user IN (${coh})`, from, to)!.n;
  const l = one<{ n: number }>(`SELECT COUNT(DISTINCT tg_chat_id) n FROM leads WHERE status!='merged' AND tg_chat_id IN (${coh})`, from, to)!.n;
  const sa = one<{ n: number; v: number }>(`SELECT COUNT(*) n, COALESCE(SUM(x.amount),0) v FROM sales x JOIN leads l ON l.id=x.lead_id WHERE l.tg_chat_id IN (${coh})`, from, to)!;
  const sp = money(spend);
  return { spend: sp, joins: j.n, joined: j.jn, left: j.lf, stayed: j.jn - j.lf, subs: j.sb, waiting: j.wt, bot_starts: st, messaged: l, sales: sa.n, revenue: money(sa.v),
    cpj: j.n && sp ? money(sp / j.n) : null, cps_sub: j.sb && sp ? money(sp / j.sb) : null, cpm: l && sp ? money(sp / l) : null, cpsale: sa.n && sp ? money(sp / sa.n) : null };
}
/** v120 Home → 🤖 Bot tab: everyone who came through the bot (its buttons / code) — organic, channel-ad pages, /telegram ads. */
export function botStats(from: number, to: number) {
  const O = ['organic', 'ads', 'tg'] as const;
  const by = <T extends { o: string }>(rows: T[], k: keyof T) => Object.fromEntries(O.map(o => [o, Number(rows.find(r => r.o === o)?.[k] || 0)])) as Record<typeof O[number], number>;
  const starts = all<{ o: string; n: number }>(`SELECT ${ORIGIN('b.tg_user')} o, COUNT(*) n FROM bot_subs b WHERE b.started_at>=? AND b.started_at<? AND COALESCE(b.src,'')!='back' GROUP BY o`, from, to);
  const msg = all<{ o: string; n: number }>(`SELECT ${ORIGIN('l.tg_chat_id')} o, COUNT(*) n FROM leads l WHERE l.source='channel' AND l.status!='merged' AND l.created_at>=? AND l.created_at<? GROUP BY o`, from, to);
  const prod = one<{ a: number; p: number; f: number }>(`SELECT COALESCE(SUM(COALESCE(line,'agency')!='funnel' AND COALESCE(tier,'')!='premium'),0) a, COALESCE(SUM(COALESCE(line,'agency')!='funnel' AND tier='premium'),0) p, COALESCE(SUM(line='funnel'),0) f
    FROM leads WHERE source='channel' AND status!='merged' AND created_at>=? AND created_at<?`, from, to)!;
  const sal = all<{ o: string; n: number; v: number }>(`SELECT ${ORIGIN('l.tg_chat_id')} o, COUNT(*) n, COALESCE(SUM(x.amount),0) v FROM sales x JOIN leads l ON l.id=x.lead_id WHERE l.source='channel' AND x.created_at>=? AND x.created_at<? GROUP BY o`, from, to);
  const rem = one<{ n: number; p: number }>("SELECT COUNT(*) n, COUNT(DISTINCT tg_user) p FROM bot_log WHERE kind LIKE 'reminder%' AND at>=? AND at<?", from, to)!;
  const afterRem = one<{ n: number }>(`SELECT COUNT(*) n FROM leads l WHERE l.source='channel' AND l.status!='merged' AND l.created_at>=? AND l.created_at<?
    AND EXISTS(SELECT 1 FROM bot_log b WHERE b.tg_user=l.tg_chat_id AND b.kind LIKE 'reminder%' AND b.at<l.created_at)`, from, to)!.n;
  const waiting = one<{ n: number }>(`SELECT COUNT(*) n FROM bot_subs WHERE replied_at>0 AND COALESCE(bfu_n,0)<3 AND tg_user NOT IN (SELECT tg_chat_id FROM leads WHERE tg_chat_id IS NOT NULL AND status!='merged')`)!.n;
  return { starts: by(starts, 'n'), messaged: by(msg, 'n'), sales: by(sal, 'n'), revenue: Object.fromEntries(O.map(o => [o, money(Number(sal.find(r => r.o === o)?.v || 0))])),
    products: { agency: prod.a, premium: prod.p, funnel: prod.f }, reminders: rem.n, reminded_people: rem.p, after_reminder: afterRem, not_messaged_yet: waiting,
    starts_total: one<{ n: number }>("SELECT COUNT(*) n FROM bot_subs WHERE COALESCE(src,'')!='back'")!.n };
}
export { getSettings };
