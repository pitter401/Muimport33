/**
 * "Auto first message" — the chat account (e.g. @adsbhaisupport) logged in as a normal Telegram user (MTProto).
 * Used ONLY to send the first message to people who filled the form but never wrote on Telegram,
 * and to deliver agent replies to them until they answer (bots can't write first in Telegram Business).
 *
 * Login happens once from the Admin app (web process). After that only the worker process keeps the
 * connection open, so the same session is never used by two processes at the same time.
 */
import bigInt from 'big-integer';
import { TelegramClient, Api } from 'telegram';
import { StringSession } from 'telegram/sessions';
import { Logger, LogLevel } from 'telegram/extensions/Logger';
import { one, all, run } from './db';
import { getSettings, setSetting, fmt, msgFor, bizOf, forLead, type Settings } from './settings';
import { now, HOUR, num, fillName, HttpError } from './util';
import { pushTo } from './push';
import { paceAsk, paceFloodWait, pacePeerFlood, tgaStopped, PRIO } from './pace';
import { vary } from './vary';
import { mediaPath, localDur } from './wati';

const quiet = () => new Logger(LogLevel.NONE);
const errText = (e: unknown) => String((e as { errorMessage?: string })?.errorMessage || (e as Error)?.message || e);

export function ubReady(s: Settings = getSettings()) {
  return !!(s.ub_session && s.ub_api_id && s.ub_api_hash);
}

/* ======================= login (web process, admin only) ======================= */
type Pending = { client: TelegramClient; phone: string; hash: string; apiId: number; apiHash: string; at: number };
const G = globalThis as typeof globalThis & { __ubLogin?: Pending };

async function dropPending() {
  const p = G.__ubLogin; G.__ubLogin = undefined;
  if (p) await p.client.disconnect().catch(() => {});
}

export async function ubSendCode(apiIdIn: unknown, apiHashIn: unknown, phoneIn: unknown) {
  const s = getSettings();
  const apiId = num(apiIdIn || s.ub_api_id);
  const apiHash = String(apiHashIn && !String(apiHashIn).startsWith('••') ? apiHashIn : s.ub_api_hash).trim();
  let phone = String(phoneIn || '').replace(/[^\d+]/g, '');
  if (/^\d{10}$/.test(phone)) phone = '+91' + phone;
  if (!apiId || !apiHash) throw new HttpError(400, 'Enter API ID and API hash from my.telegram.org first');
  if (phone.replace(/\D/g, '').length < 10) throw new HttpError(400, 'Enter the phone number of the chat account');
  await dropPending();
  const client = new TelegramClient(new StringSession(''), apiId, apiHash, { connectionRetries: 3, baseLogger: quiet() });
  await client.connect();
  try {
    const r = await client.sendCode({ apiId, apiHash }, phone);
    G.__ubLogin = { client, phone, hash: r.phoneCodeHash, apiId, apiHash, at: now() };
    setSetting('ub_api_id', String(apiId));
    setSetting('ub_api_hash', apiHash);
    return { ok: true, via_app: r.isCodeViaApp };
  } catch (e) {
    await client.disconnect().catch(() => {});
    throw new HttpError(400, 'Telegram: ' + errText(e));
  }
}

export async function ubSignIn(codeIn: unknown, passwordIn: unknown) {
  const p = G.__ubLogin;
  if (!p || now() - p.at > 15 * 60000) throw new HttpError(400, 'Code expired. Tap “Send code” again.');
  const code = String(codeIn || '').replace(/\D/g, '');
  const password = String(passwordIn || '');
  let me: Api.User | undefined;
  try {
    if (!p.client.connected) await p.client.connect();
    try {
      const r = await p.client.invoke(new Api.auth.SignIn({ phoneNumber: p.phone, phoneCodeHash: p.hash, phoneCode: code }));
      if (r instanceof Api.auth.AuthorizationSignUpRequired) throw new HttpError(400, 'This number has no Telegram account');
      me = (r as Api.auth.Authorization).user as Api.User;
    } catch (e) {
      if (errText(e).includes('SESSION_PASSWORD_NEEDED')) {
        if (!password) return { ok: false, need_password: true };
        me = await p.client.signInWithPassword({ apiId: p.apiId, apiHash: p.apiHash }, {
          password: async () => password,
          onError: async (err: Error) => { throw err; },
        }) as Api.User;
      } else throw e;
    }
  } catch (e) {
    if (e instanceof HttpError) throw e;
    const t = errText(e);
    if (/PASSWORD_HASH_INVALID/.test(t)) throw new HttpError(400, 'Wrong 2-step verification password');
    if (/PHONE_CODE_INVALID/.test(t)) throw new HttpError(400, 'Wrong code. Check the code Telegram sent and try again.');
    if (/PHONE_CODE_EXPIRED/.test(t)) { await dropPending(); throw new HttpError(400, 'Code expired. Tap “Send code” again.'); }
    throw new HttpError(400, 'Telegram: ' + t);
  }
  const session = (p.client.session as StringSession).save();
  setSetting('ub_session', session);
  setSetting('ub_me', [me?.firstName, me?.lastName].filter(Boolean).join(' ') + (me?.username ? ` (@${me.username})` : ''));
  setSetting('ub_pause_until', '0');
  setSetting('ub_status', 'Logged in');
  G.__ubLogin = undefined;
  await p.client.disconnect().catch(() => {});
  return { ok: true, me: getSettings().ub_me };
}

export function ubLogout() {
  setSetting('ub_session', '');
  setSetting('ub_me', '');
  setSetting('ub_status', 'Logged out');
  void dropPending();
}

/* ======================= worker side ======================= */
let cur: { sess: string; client: TelegramClient } | null = null;

async function client(): Promise<TelegramClient | null> {
  const s = getSettings();
  if (!ubReady(s)) {
    if (cur) { await cur.client.disconnect().catch(() => {}); cur = null; }
    return null;
  }
  if (cur && cur.sess === s.ub_session) {
    if (!cur.client.connected) await cur.client.connect();
    return cur.client;
  }
  if (cur) await cur.client.disconnect().catch(() => {});
  const c = new TelegramClient(new StringSession(s.ub_session), num(s.ub_api_id), s.ub_api_hash, { connectionRetries: 5, baseLogger: quiet() });
  try {
    await c.connect();
    if (!(await c.checkAuthorization())) throw new Error('AUTH_KEY_UNREGISTERED');
  } catch (e) {
    const t = errText(e);
    if (/AUTH_KEY|SESSION_REVOKED|USER_DEACTIVATED/.test(t)) {
      setSetting('ub_session', ''); setSetting('ub_status', 'Logged out by Telegram — log in again');
    } else setSetting('ub_status', 'Connection error: ' + t);
    await c.disconnect().catch(() => {});
    cur = null;
    return null;
  }
  cur = { sess: s.ub_session, client: c };
  setSetting('ub_status', 'Connected');
  return c;
}

/** Telegram asked the chat account to wait (FLOOD_WAIT): nothing goes from it (human sends get a clear error meanwhile). */
function paused(s: Settings) { return num(s.ub_pause_until) > now() && num(s.ub_pause_until) < STOP_UNTIL_FIXED; }
/** Background chat-account jobs (folders, mutes, contacts, first messages, delivery messages) also rest during a spam-limit pause. */
function quietAcct(s: Settings) { return paused(s) || tgaStopped(now(), s); }

/** Before v143: "stopped until fixed" (a far-future pause). v143 turns it into a 24 h pause of automatic messages (pace.ts). */
export const STOP_UNTIL_FIXED = 9e15;
/** v143: a spam-limit error text → the short Telegram code. */
export const spamCode = (t: string) => (/PEER_FLOOD|USER_RESTRICTED|FROZEN_METHOD_INVALID|FROZEN_PARTICIPANT_MISSING/i.exec(t)?.[0] || (/spam/i.test(t) ? 'SPAM' : ''));
/** Admin alert: push + a Telegram message from the bot to the manager(s) (and the business owner). */
export async function alertSpamLimit(code: string, hours: number) {
  const title = '⛔ Auto messages stopped';
  const body = `Telegram put a spam limit on the chat account (${code}). Automatic messages from it are paused for ${hours} h; replies by hand still work. WhatsApp and the bot are not affected. Check @SpamBot, then Admin → Auto first message → Resume.`;
  await pushTo('admin', null, title, body).catch(() => {});
  try {
    const s = getSettings();
    if (!s.bot_token) return;
    const { tg } = await import('./telegram');
    const ids = new Set(all<{ tg_chat_id: string }>("SELECT tg_chat_id FROM agents WHERE role='manager' AND deleted=0 AND tg_chat_id IS NOT NULL").map(x => x.tg_chat_id));
    if (s.owner_id) ids.add(s.owner_id);
    for (const id of ids) await tg(s, 'sendMessage', { chat_id: id, text: `${title}\n${body}` }).catch(() => null);
  } catch { /* best effort */ }
}
/**
 * Telegram limits (v143, per channel — only the chat account's own queue is touched, never WhatsApp or the bot):
 *  - FLOOD_WAIT_X → the chat account waits exactly X s + a margin (Settings), then carries on at the normal speed.
 *  - Spam limit (PEER_FLOOD, account restricted/frozen) → automatic chat-account messages pause 24 h (Settings), stranger
 *    first messages 48 h, the admin is alerted. Sending by hand stays allowed (replies to people who wrote first work).
 */
export function handleLimit(e: unknown) {
  const t = errText(e);
  const fw = t.match(/FLOOD_WAIT_(\d+)|wait of (\d+) seconds/i);
  if (fw) {
    const sec = num(fw[1] || fw[2]);
    const until = paceFloodWait('tga', sec);
    setSetting('ub_pause_until', String(until));
    setSetting('ub_status', `Telegram asked to wait ${sec < 120 ? sec + ' s' : Math.ceil(sec / 60) + ' min'} (FLOOD_WAIT)`);
    return true;
  }
  const code = spamCode(t);
  if (code) {
    const s = getSettings();
    if (pacePeerFlood(code)) {
      const h = Math.max(1, num(s.pace_flood_h, 24));
      setSetting('ub_status', `Spam limit on this account (${code}): automatic messages paused for ${h} h. Fix it in @SpamBot, then press Resume.`);
      void alertSpamLimit(code, h);
    }
    return true;
  }
  return false;
}
/** v143: a clear error for a send by hand that Telegram refused because of a limit. */
export function limitMessage(t: string) {
  if (spamCode(t)) return 'Telegram spam limit on the chat account: it cannot start chats with people who have not written to it. Ask the client to write first, or call / WhatsApp them.';
  const fw = t.match(/FLOOD_WAIT_(\d+)|wait of (\d+) seconds/i);
  if (fw) return `Telegram asked the chat account to wait ${num(fw[1] || fw[2])} s (FLOOD_WAIT). Try again after that.`;
  return t;
}

/** Messages we send as the chat account come back as a Business "owner" message — skip that copy. */
export function expectEcho(chatId: string, text: string) {
  run('DELETE FROM echo_skip WHERE created_at<?', now() - 10 * 60000);
  run('INSERT INTO echo_skip(chat_id, text, created_at) VALUES(?,?,?)', String(chatId), text.trim(), now());
}
export function isOwnEcho(chatId: string, text: string) {
  const r = one<{ rowid: number }>('SELECT rowid FROM echo_skip WHERE chat_id=? AND text=? ORDER BY rowid LIMIT 1', String(chatId), text.trim());
  if (r) run('DELETE FROM echo_skip WHERE rowid=?', r.rowid);
  return !!r;
}

const peer = (id: string, hash: string) => new Api.InputPeerUser({ userId: bigInt(id), accessHash: bigInt(hash) });

type LeadRow = { id: number; name: string | null; phone: string | null; agent_id: number | null; service?: string | null; line?: string | null; biz?: string | null; biz_no?: number | null };

/** Called by the worker every ~30s. Sends at most one first message per call. */
export async function autoContactTick(hooks: {
  pickAgent: (service?: string | null, line?: string | null, lead?: { service?: string | null; line?: string | null; call_agent_id?: number | null }) => number | null;
  addMsg: (lead: { id: number }, m: { dir: 'in' | 'out' | 'sys'; sender: string; text?: string }) => void;
  notify: (leadId: number, agentId: number | null, title: string, body: string) => Promise<void> | void;
  /** this person already chats with us (wrote without the form code) → join that chat with the form lead instead of messaging */
  linkExisting?: (formLeadId: number, chatId: string) => Promise<boolean>;
}, at?: number) {
  const s = getSettings();
  if (s.auto_msg_on !== '1' || !ubReady(s) || quietAcct(s)) return null;
  const t = at ?? now();
  // v143: first messages to strangers — the riskiest send: own caps (5 / h, 30 / day) checked by the send queue, paused 48 h after
  // any Telegram limit, and always last in line behind replies and follow-ups
  const cap = Math.max(1, num(s.auto_msg_hour_cap, 20));
  const sentLastHour = one<{ n: number }>("SELECT COUNT(*) n FROM leads WHERE contact_state IN ('sent','not_found') AND contact_at>?", t - HOUR)!.n;
  if (sentLastHour >= cap) return null;
  const delay = Math.max(1, num(s.auto_msg_delay_min, 5)) * 60000;
  const lead = one<LeadRow>(`SELECT id, name, phone, agent_id, service, line, biz, biz_no FROM leads
      WHERE source='form' AND tg_chat_id IS NULL AND status='new' AND phone IS NOT NULL AND phone!='' AND COALESCE(contact_state,'')=''
        AND created_at<? AND created_at>? ORDER BY created_at LIMIT 1`, t - delay, t - 24 * HOUR);
  if (!lead) return null;
  if (!paceAsk('tga', `first:${lead.id}`, 'first', PRIO.first, t, lead.id)) return null; // waits in the send queue
  run("UPDATE leads SET contact_state='working', contact_at=? WHERE id=?", t, lead.id);

  const c = await client();
  if (!c) { run("UPDATE leads SET contact_state=NULL WHERE id=?", lead.id); return null; }

  const first = String(lead.name || '').trim().split(/\s+/)[0] || 'there';
  try {
    const imp = await c.invoke(new Api.contacts.ImportContacts({
      contacts: [new Api.InputPhoneContact({ clientId: bigInt(lead.id), phone: String(lead.phone), firstName: contactName({ ...lead, status: 'active' }, s), lastName: '' })],
    }));
    const u = imp.users.find((x): x is Api.User => x instanceof Api.User);
    if (!u || !u.accessHash) {
      run("UPDATE leads SET contact_state='not_found', contact_at=?, contact_err=? WHERE id=?", now(), 'Number not on Telegram or hidden by privacy', lead.id);
      hooks.addMsg(lead, { dir: 'sys', sender: 'system', text: '📵 Auto message: this number is not on Telegram (or hides it). Call or WhatsApp instead.' });
      return { id: lead.id, result: 'not_found' };
    }
    const uid = u.id.toString(), hash = u.accessHash.toString();
    if (hooks.linkExisting && one("SELECT 1 FROM leads WHERE tg_chat_id=? AND id!=? AND status!='merged'", uid, lead.id)) {
      if (s.save_contacts !== '1') await c.invoke(new Api.contacts.DeleteContacts({ id: [new Api.InputUser({ userId: u.id, accessHash: u.accessHash })] })).catch(() => {});
      run('UPDATE leads SET tg_access_hash=? WHERE id=?', hash, lead.id);
      if (await hooks.linkExisting(lead.id, uid)) return { id: lead.id, result: 'linked' };
    }
    const sm = forLead(s, lead); // funnel leads get the funnel first message
    const text = fillName(fmt(vary(sm.auto_msg_text, Math.random, s.fu_vary !== '0'), sm), { name: first } as never);
    // Save the chat first so the echo of our own message is matched to this lead
    const aid = lead.agent_id || hooks.pickAgent(lead.service, lead.line, lead as never);
    run(`UPDATE leads SET tg_chat_id=?, tg_access_hash=?, tg_username=?, tg_name=?, biz_conn=COALESCE(biz_conn, ?), status='active',
          agent_id=?, assigned_at=COALESCE(assigned_at, ?), contact_state='sent', contact_at=? WHERE id=?`,
      uid, hash, u.username || '', lead.name || '', s.biz_conn_id || null, aid, now(), now(), lead.id);
    if (s.save_contacts === '1') run('UPDATE leads SET tg_contact=? WHERE id=?', contactName({ ...lead, status: 'active' }, s), lead.id);
    expectEcho(uid, text);
    await c.sendMessage(peer(uid, hash), { message: text });
    hooks.addMsg(lead, { dir: 'out', sender: 'auto', text });
    hooks.addMsg(lead, { dir: 'sys', sender: 'system', text: '🤖 They filled the form but didn’t write, so the first message was sent automatically. Waiting for their reply.' });
    // Keep it saved as "AdsBhai Lead 12" (setting), otherwise remove the temporary contact
    if (s.save_contacts !== '1') await c.invoke(new Api.contacts.DeleteContacts({ id: [new Api.InputUser({ userId: u.id, accessHash: u.accessHash })] })).catch(() => {});
    await hooks.notify(lead.id, aid, '🤖 Auto message sent', `${lead.name || 'Lead'} filled the form but didn’t write. We messaged them first.`);
    return { id: lead.id, result: 'sent' };
  } catch (e) {
    const limited = handleLimit(e);
    run("UPDATE leads SET contact_state=?, contact_err=? WHERE id=?", limited ? null : 'failed', errText(e).slice(0, 200), lead.id);
    if (!limited) hooks.addMsg(lead, { dir: 'sys', sender: 'system', text: '⚠️ Auto message failed: ' + errText(e).slice(0, 120) });
    return { id: lead.id, result: 'error', error: errText(e) };
  }
}

/* ---------- agent replies to people who haven't answered yet (bot can't write there) ---------- */
export async function queueUserbotText(leadId: number, text: string, agentId: number | null, sender: string, file?: { id: string; kind: string }) {
  const r = run('INSERT INTO ub_outbox(lead_id, text, agent_id, sender, status, created_at, file_id, file_kind) VALUES(?,?,?,?,?,?,?,?)', leadId, text, agentId, sender, 'queued', now(), file?.id ?? null, file?.kind ?? null);
  const id = Number(r.lastInsertRowid);
  for (let i = 0; i < 50; i++) {                      // wait up to ~25s for the worker
    await new Promise(res => setTimeout(res, 500));
    const row = one<{ status: string; error: string | null }>('SELECT status, error FROM ub_outbox WHERE id=?', id);
    if (row?.status === 'sent') return { ok: true, msg_id: one<{ tg_id: number | null }>('SELECT tg_id FROM ub_outbox WHERE id=?', id)?.tg_id ?? null };
    if (row?.status === 'error') return { ok: false, error: row.error || 'not delivered' };
  }
  run("UPDATE ub_outbox SET status='error', error='timeout' WHERE id=? AND status='queued'", id);
  return { ok: false, error: 'The background worker did not answer. Is it running? (pm2 status)' };
}

let dialogsAt = 0;
async function findHash(c: TelegramClient, userId: string): Promise<string | null> {
  try { const e = await c.getInputEntity(bigInt(userId)); if (e instanceof Api.InputPeerUser) return e.accessHash.toString(); } catch { /* not cached */ }
  if (now() - dialogsAt < 5 * 60_000) return null; // one dialog scan per 5 min at most
  dialogsAt = now();
  try {
    const ds = await c.getDialogs({ limit: 500 });
    const d = ds.find(x => x.entity instanceof Api.User && x.entity.id.toString() === userId);
    return d && d.entity instanceof Api.User && d.entity.accessHash ? d.entity.accessHash.toString() : null;
  } catch (e) { handleLimit(e); return null; }
}

export async function outboxTick() {
  const rows = all<{ id: number; lead_id: number; text: string; kind: string | null; tg_id: number | null; agent_id: number | null; sender: string | null; created_at: number; file_id: string | null; file_kind: string | null }>("SELECT id, lead_id, text, kind, tg_id, agent_id, sender, created_at, file_id, file_kind FROM ub_outbox WHERE status='queued' ORDER BY id LIMIT 10");
  if (!rows.length) return;
  const s = getSettings();
  const fw = paused(s); // Telegram asked to wait (FLOOD_WAIT)
  const c = fw ? null : await client();
  for (const r of rows) {
    // v143: automatic rows (follow-up / dead-chat message handed over from Telegram Business) were paced when they were made; one
    // that waited (a FLOOD_WAIT, a spam-limit pause) asks the send queue again, so a backlog never goes out at once.
    // A person's message (agent / admin) is never delayed.
    const auto = r.kind !== 'delete' && !r.agent_id && !['agent', 'admin'].includes(String(r.sender || ''));
    if (fw) {
      if (auto) continue;
      run("UPDATE ub_outbox SET status='error', error=? WHERE id=?", `Telegram asked the chat account to wait until ${new Date(num(s.ub_pause_until)).toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit' })} (FLOOD_WAIT). Try again then.`, r.id);
      continue;
    }
    if (auto && (now() - r.created_at > 60_000 || tgaStopped(now(), s)) && !paceAsk('tga', `ob:${r.id}`, 'fu', PRIO.fu1, now(), r.lead_id)) continue;
    const lead = one<{ tg_chat_id: string | null; tg_access_hash: string | null }>('SELECT tg_chat_id, tg_access_hash FROM leads WHERE id=?', r.lead_id);
    // v117: no saved access hash → the chat account already has this chat (the client wrote to it): look it up once
    if (c && lead?.tg_chat_id && !lead.tg_access_hash) { const h = await findHash(c, lead.tg_chat_id); if (h) { lead.tg_access_hash = h; run('UPDATE leads SET tg_access_hash=? WHERE tg_chat_id=?', h, lead.tg_chat_id); } }
    if (!c || !lead?.tg_chat_id || !lead.tg_access_hash) {
      run("UPDATE ub_outbox SET status='error', error=? WHERE id=?", !c ? 'Chat account is not logged in (Admin → Settings → Auto first message)' : 'Chat not available', r.id);
      if (c) run("INSERT INTO messages(lead_id, dir, sender, text, created_at) VALUES(?,'sys','system',?,?)", r.lead_id, '⚠️ The chat account could not find this chat, so the automatic message was not delivered. Please send it yourself.', now());
      continue;
    }
    // v137: delete for everyone (a message the chat account sent)
    if (r.kind === 'delete') {
      try { await c.deleteMessages(peer(lead.tg_chat_id, lead.tg_access_hash), [Number(r.tg_id)], { revoke: true }); run("UPDATE ub_outbox SET status='sent' WHERE id=?", r.id); }
      catch (e) { handleLimit(e); run("UPDATE ub_outbox SET status='error', error=? WHERE id=?", errText(e).slice(0, 200), r.id); }
      continue;
    }
    try {
      expectEcho(lead.tg_chat_id, r.text);
      let sent;
      if (r.file_id) { // v148: a voice note / photo / file (Telegram Business only sends files within 24 h of their last message)
        const p = mediaPath(r.file_id);
        if (!p) throw new Error('file missing on the server');
        const voice = r.file_kind === 'voice';
        sent = await c.sendFile(peer(lead.tg_chat_id, lead.tg_access_hash), {
          file: p, caption: r.text || undefined, voiceNote: voice, forceDocument: r.file_kind === 'document', workers: 1,
          ...(voice ? { attributes: [new Api.DocumentAttributeAudio({ voice: true, duration: Math.max(1, Math.round(localDur(r.file_id) || 1)) })] } : {}),
        });
      } else sent = await c.sendMessage(peer(lead.tg_chat_id, lead.tg_access_hash), { message: r.text });
      run("UPDATE ub_outbox SET status='sent', tg_id=? WHERE id=?", (sent as { id?: number } | undefined)?.id ?? null, r.id);
    } catch (e) {
      handleLimit(e);
      const t = errText(e);
      run("UPDATE ub_outbox SET status='error', error=? WHERE id=?", limitMessage(t).slice(0, 200), r.id);
      // this client blocked us / deleted the account → no more automatic messages to them
      if (/USER_IS_BLOCKED|YOU_BLOCKED_USER|INPUT_USER_DEACTIVATED|USER_DEACTIVATED|PEER_ID_INVALID|USER_PRIVACY_RESTRICTED|PRIVACY_PREMIUM_REQUIRED/i.test(t)
        && run("UPDATE leads SET auto_stop=? WHERE id=? AND auto_stop IS NULL", 'Telegram: ' + (t.match(/[A-Z_]{6,}/)?.[0] || 'not delivered'), r.lead_id).changes)
        run("INSERT INTO messages(lead_id, dir, sender, text, created_at) VALUES(?,'sys','system',?,?)", r.lead_id, `🛑 Automatic messages stopped for this chat: ${t.match(/[A-Z_]{6,}/)?.[0] || 'not delivered'}. They start again only if the client writes.`, now());
    }
  }
}

export async function ubShutdown() { if (cur) await cur.client.disconnect().catch(() => {}); cur = null; }

/* ---------- delivery messages to website customers, sent by phone number from the chat account ---------- */
export async function phoneJobTick(onSent?: (jobId: number, u: { id: string; hash: string; username: string; name: string }) => void) {
  const s = getSettings();
  const job = one<{ id: number; phone: string; name: string; text: string }>("SELECT id, phone, name, text FROM ub_phone_jobs WHERE status='queued' AND COALESCE(due_at,0)<=? ORDER BY id LIMIT 1", now());
  if (!job) return null;
  if (!ubReady(s)) { run("UPDATE ub_phone_jobs SET status='skipped', error='chat account not logged in' WHERE id=?", job.id); return { id: job.id, result: 'skipped' }; }
  if (quietAcct(s)) return null;
  if (!paceAsk('tga', `job:${job.id}`, 'delivery', PRIO.delivery, now(), null)) return null; // v143: send queue
  const c = await client();
  if (!c) return null;
  run("UPDATE ub_phone_jobs SET status='working' WHERE id=?", job.id);
  try {
    const imp = await c.invoke(new Api.contacts.ImportContacts({ contacts: [new Api.InputPhoneContact({ clientId: bigInt(job.id + 1_000_000), phone: job.phone, firstName: (job.name || `${s.brand_name} Customer`).slice(0, 60), lastName: '' })] }));
    const u = imp.users.find((x): x is Api.User => x instanceof Api.User);
    if (!u || !u.accessHash) { run("UPDATE ub_phone_jobs SET status='not_found' WHERE id=?", job.id); return { id: job.id, result: 'not_found' }; }
    expectEcho(u.id.toString(), job.text);
    await c.sendMessage(peer(u.id.toString(), u.accessHash.toString()), { message: job.text });
    if (s.save_contacts !== '1') await c.invoke(new Api.contacts.DeleteContacts({ id: [new Api.InputUser({ userId: u.id, accessHash: u.accessHash })] })).catch(() => {});
    run("UPDATE ub_phone_jobs SET status='sent' WHERE id=?", job.id);
    try { onSent?.(job.id, { id: u.id.toString(), hash: u.accessHash.toString(), username: u.username || '', name: [u.firstName, u.lastName].filter(Boolean).join(' ') }); } catch (e) { console.error('[phone job] lead', e); }
    return { id: job.id, result: 'sent' };
  } catch (e) {
    const limited = handleLimit(e);
    run('UPDATE ub_phone_jobs SET status=?, error=? WHERE id=?', limited ? 'queued' : 'failed', errText(e).slice(0, 200), job.id);
    return { id: job.id, result: 'error' };
  }
}

/* ======================= chat folders per agent ======================= */
type FolderPlan = { agentId: number; key?: string; title: string; peers: { id: string; hash: string | null }[]; sig: string };
const fkey = (p: FolderPlan) => p.key || String(p.agentId);
/** v148: "Sold Akash", "Sold Babai" … — the chats where that person made a sale, right after their own folder. Pure — unit-tested. */
export function planSoldFolders(agentsIn: { id: number; name: string; role?: string | null }[], sold: { agent_id: number; tg_chat_id: string; tg_access_hash: string | null; last_at: number | null }[], max: number): FolderPlan[] {
  const agents = [...agentsIn].sort((x, y) => (x.role === 'manager' ? 0 : 1) - (y.role === 'manager' ? 0 : 1));
  return agents.map(a => {
    const list = sold.filter(l => l.agent_id === a.id && /^\d+$/.test(l.tg_chat_id)).sort((x, y) => (y.last_at || 0) - (x.last_at || 0));
    const seen = new Set<string>(); const peers: FolderPlan['peers'] = [];
    for (const l of list) { if (seen.has(l.tg_chat_id) || peers.length >= max) continue; seen.add(l.tg_chat_id); peers.push({ id: l.tg_chat_id, hash: l.tg_access_hash }); }
    const title = ('Sold ' + (a.name.trim() || `Agent ${a.id}`)).slice(0, 12);
    return { agentId: a.id, key: 's' + a.id, title, peers, sig: title + '|' + peers.map(p => p.id).sort().join(',') };
  });
}
/** Agent folder, then that agent's Sold folder. */
export function mergeFolderPlans(main: FolderPlan[], sold: FolderPlan[]) {
  const out: FolderPlan[] = [];
  for (const p of main) { out.push(p); const s = sold.find(x => x.agentId === p.agentId); if (s) out.push(s); }
  return out;
}
type FolderState = Record<string, { fid: number; sig: string }>;

/** Which chats go in which agent's folder (newest first, capped). Pure — unit-tested. */
export function planFolders(agentsIn: { id: number; name: string; role?: string | null }[], leads: { agent_id: number; tg_chat_id: string; tg_access_hash: string | null; last_at: number | null }[], max: number): FolderPlan[] {
  const used = new Set<string>();
  // Manager folder(s) first, right after “All chats”
  const agents = [...agentsIn].sort((x, y) => (x.role === 'manager' ? 0 : 1) - (y.role === 'manager' ? 0 : 1));
  return agents.map(a => {
    const list = leads.filter(l => l.agent_id === a.id && /^\d+$/.test(l.tg_chat_id)).sort((x, y) => (y.last_at || 0) - (x.last_at || 0));
    const seen = new Set<string>(); const peers: FolderPlan['peers'] = [];
    for (const l of list) { if (seen.has(l.tg_chat_id) || peers.length >= max) continue; seen.add(l.tg_chat_id); peers.push({ id: l.tg_chat_id, hash: l.tg_access_hash }); }
    let title = a.name.trim().slice(0, 12) || `Agent ${a.id}`;
    if (used.has(title.toLowerCase())) title = `${title.slice(0, 9)} ${a.id}`.slice(0, 12);
    used.add(title.toLowerCase());
    const ids = peers.map(p => p.id).sort();
    return { agentId: a.id, title, peers, sig: title + '|' + ids.join(',') };
  });
}

let lastDialogScan = 0;
let lastFullSync = 0;
/** Keeps one Telegram folder per agent on the chat account, e.g. "Rahul", "Avik". Runs in the worker. */
export async function folderTick(force = false) {
  const s = getSettings();
  const state: FolderState = (() => { try { return JSON.parse(s.folders_state || '{}'); } catch { return {}; } })();
  if (s.folders_on !== '1') {
    if (!Object.keys(state).length || !ubReady(s) || quietAcct(s)) return null;
    const c = await client(); if (!c) return null;
    for (const k of Object.keys(state)) { await c.invoke(new Api.messages.UpdateDialogFilter({ id: state[k].fid })).catch(() => {}); delete state[k]; }
    setSetting('folders_state', '{}'); setSetting('folders_status', 'Folders removed');
    return { removed: true };
  }
  if (!ubReady(s) || quietAcct(s)) return null;
  const max = Math.max(10, Math.min(200, num(s.folders_max, 100)));
  const agents = all<{ id: number; name: string; role: string | null }>('SELECT id, name, role FROM agents WHERE deleted=0 ORDER BY id');
  const leadsQ = () => all<{ id: number; agent_id: number; tg_chat_id: string; tg_access_hash: string | null; last_at: number | null }>(
    "SELECT id, agent_id, tg_chat_id, tg_access_hash, last_at FROM leads WHERE agent_id IS NOT NULL AND tg_chat_id IS NOT NULL AND status IN ('new','active','sold') ORDER BY last_at DESC LIMIT 5000");
  // v148: who made the sale (sales.agent_id) → that person's "Sold …" folder
  const soldQ = () => s.folders_sold_on === '0' ? [] : all<{ agent_id: number; tg_chat_id: string; tg_access_hash: string | null; last_at: number | null }>(
    "SELECT DISTINCT x.agent_id, l.tg_chat_id, l.tg_access_hash, l.last_at FROM sales x JOIN leads l ON l.id=x.lead_id WHERE x.agent_id IS NOT NULL AND l.tg_chat_id IS NOT NULL AND l.status!='merged' AND COALESCE(l.ch,'tg')!='wa' ORDER BY l.last_at DESC LIMIT 5000");
  let leads = leadsQ();
  const mkPlans = () => mergeFolderPlans(planFolders(agents, leads, max), planSoldFolders(agents, soldQ(), max));
  let plans = mkPlans();
  const full = force || now() - lastFullSync > 6 * HOUR;
  const changed = plans.filter(p => full || !state[fkey(p)] || state[fkey(p)].sig !== p.sig);
  const gone = Object.keys(state).filter(k => !plans.some(p => fkey(p) === k));
  const wantOrder = plans.map(p => state[fkey(p)]?.fid).filter(Boolean).join(',');
  if (!changed.length && !gone.length && wantOrder === (s.folders_order || '')) return null;
  const c = await client(); if (!c) return null;
  try {
    // Chats that came through Telegram Business have no access hash yet → read them from the account's chat list
    const need = new Set(changed.flatMap(p => p.peers.filter(x => !x.hash).map(x => x.id)));
    if (need.size && (force || now() - lastDialogScan > 5 * 60_000)) {
      lastDialogScan = now();
      const dialogs = await c.getDialogs({ limit: 1000 });
      for (const d of dialogs) {
        const e = d.entity;
        if (e instanceof Api.User && e.accessHash && need.has(e.id.toString())) run('UPDATE leads SET tg_access_hash=? WHERE tg_chat_id=?', e.accessHash.toString(), e.id.toString());
      }
      leads = leadsQ(); plans = mkPlans();
    }
    // existing folder ids on the account, so we never overwrite the owner's own folders
    const res = await c.invoke(new Api.messages.GetDialogFilters());
    const filters = (res as unknown as { filters?: Api.TypeDialogFilter[] }).filters || (res as unknown as Api.TypeDialogFilter[]);
    const taken = new Set<number>((Array.isArray(filters) ? filters : []).map(f => (f as { id?: number }).id).filter((x): x is number => typeof x === 'number'));
    const ours = new Set(Object.values(state).map(v => v.fid));
    const freeId = () => { for (let i = 2; i < 256; i++) if (!taken.has(i) && !ours.has(i)) { ours.add(i); return i; } return 0; };
    let made = 0, removed = 0, skipped = 0;
    for (const k of gone) { await c.invoke(new Api.messages.UpdateDialogFilter({ id: state[k].fid })).catch(() => {}); delete state[k]; removed++; }
    for (const p of plans) {
      const st = state[fkey(p)];
      if (!full && st && st.sig === p.sig) continue;
      const peers = p.peers.filter(x => x.hash).map(x => new Api.InputPeerUser({ userId: bigInt(x.id), accessHash: bigInt(x.hash!) }));
      skipped += p.peers.length - peers.length;
      if (!peers.length) { // Telegram doesn't allow an empty folder
        if (st) { await c.invoke(new Api.messages.UpdateDialogFilter({ id: st.fid })).catch(() => {}); delete state[fkey(p)]; removed++; }
        continue;
      }
      const fid = st?.fid || freeId();
      if (!fid) { setSetting('folders_status', 'No free folder slot on the chat account'); break; }
      await c.invoke(new Api.messages.UpdateDialogFilter({ id: fid, filter: new Api.DialogFilter({
        id: fid, title: new Api.TextWithEntities({ text: p.title, entities: [] }), pinnedPeers: [], includePeers: peers, excludePeers: [],
      }) }));
      state[fkey(p)] = { fid, sig: p.sig }; made++;
      setSetting('folders_state', JSON.stringify(state));
    }
    setSetting('folders_state', JSON.stringify(state));
    // Order: All chats → manager → other agents → the owner's own folders
    const ourOrder = plans.map(p => state[fkey(p)]?.fid).filter((x): x is number => !!x);
    const ordered = ourOrder.join(',');
    if (ordered && (ordered !== s.folders_order || made || removed)) {
      const cur = await c.invoke(new Api.messages.GetDialogFilters());
      const fl = ((cur as unknown as { filters?: Api.TypeDialogFilter[] }).filters || []) as Api.TypeDialogFilter[];
      const hasDefault = fl.some(f => f instanceof Api.DialogFilterDefault);
      const others = fl.map(f => (f as { id?: number }).id).filter((x): x is number => typeof x === 'number' && !ourOrder.includes(x));
      await c.invoke(new Api.messages.UpdateDialogFiltersOrder({ order: [...(hasDefault ? [0] : []), ...ourOrder, ...others] })).catch(e => console.warn('[folders] order', errText(e)));
      setSetting('folders_order', ordered);
    }
    if (full) lastFullSync = now();
    setSetting('folders_status', `Updated ${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })} · ${Object.keys(state).length} folder(s)${skipped ? ` · ${skipped} chat(s) waiting to appear in the chat list` : ''}`);
    return { made, removed, skipped };
  } catch (e) {
    if (handleLimit(e)) return { error: 'flood' };
    const t = errText(e);
    setSetting('folders_status', /FILTERS_TOO_MUCH|LIMIT/.test(t) ? 'Telegram folder limit reached (10 folders, 20 with Premium). Delete some folders in the app.' : 'Folder error: ' + t);
    return { error: t };
  }
}

/* ======================= mute other agents' chats on the chat account ======================= */
const MUTE_FOREVER = 2147483647;
/** Chats whose mute state on the chat account must change (want: 1 = mute, 0 = unmute). */
export function muteQueue(on: boolean, limit = 20) {
  const want = `CASE WHEN ${on ? 1 : 0} = 0 THEN 0 WHEN COALESCE(a.role,'agent')='manager' AND a.deleted=0 THEN 0 ELSE 1 END`;
  return all<{ id: number; tg_chat_id: string; tg_access_hash: string; want: number }>(
    `SELECT l.id, l.tg_chat_id, l.tg_access_hash, ${want} want FROM leads l JOIN agents a ON a.id=l.agent_id
     WHERE l.tg_chat_id IS NOT NULL AND l.tg_access_hash IS NOT NULL AND l.status!='merged' AND COALESCE(l.tg_muted,0) != ${want}
     ORDER BY l.last_at DESC LIMIT ?`, limit);
}
/** Manager's chats stay unmuted; every other agent's chats are muted on the chat account (so the owner's phone stays quiet).
 *  Also keeps "who can call me" = My contacts, so customers can't ring the chat account. Runs every 20s, small batches. */
export async function muteTick() {
  const s = getSettings();
  if (!ubReady(s) || quietAcct(s)) return null;
  const rows = muteQueue(s.mute_agent_chats === '1');
  const calls = s.calls_contacts_only === '1' ? 'nobody' : 'all';
  const callsTodo = s.calls_state !== calls && !(calls === 'all' && !s.calls_state);
  if (!rows.length && !callsTodo) return null;
  const c = await client(); if (!c) return null;
  let muted = 0, unmuted = 0;
  try {
    if (callsTodo) {
      await c.invoke(new Api.account.SetPrivacy({ key: new Api.InputPrivacyKeyPhoneCall(),
        rules: calls === 'nobody' ? [new Api.InputPrivacyValueDisallowAll()] : [new Api.InputPrivacyValueAllowAll()] }));
      setSetting('calls_state', calls);
    }
    const done = new Set<string>();
    for (const r of rows) {
      if (!done.has(r.tg_chat_id)) {
        done.add(r.tg_chat_id);
        await c.invoke(new Api.account.UpdateNotifySettings({
          peer: new Api.InputNotifyPeer({ peer: peer(r.tg_chat_id, r.tg_access_hash) }),
          settings: new Api.InputPeerNotifySettings({ muteUntil: r.want ? MUTE_FOREVER : 0 }),
        }));
        r.want ? muted++ : unmuted++;
      }
      run('UPDATE leads SET tg_muted=? WHERE tg_chat_id=?', r.want, r.tg_chat_id);
    }
    return { muted, unmuted, calls: callsTodo ? calls : undefined };
  } catch (e) {
    if (handleLimit(e)) return { error: 'flood' };
    const t = errText(e);
    if (/PEER_ID_INVALID|USER_ID_INVALID|CHANNEL_INVALID/.test(t) && rows[0]) run('UPDATE leads SET tg_access_hash=NULL WHERE id=?', rows[0].id);
    return { error: t, muted, unmuted };
  }
}

/* ======================= leads saved as contacts on the chat account ======================= */
/** "AdsBhai Agency Lead 12" / "AdsBhai Funnel Lead 3" while it's a lead (own numbering per business); the customer's own name once sold (or bought on the website). */
export function contactName(l: { id: number; status: string; source?: string | null; name?: string | null; tg_name?: string | null; biz?: string | null; biz_no?: number | null; tier?: string | null }, s: Settings) {
  const real = String(l.name || l.tg_name || '').trim();
  if ((l.status === 'sold' || l.source === 'web') && real) return real.slice(0, 60);
  const tag = `${l.biz === 'funnel' ? 'Funnel' : l.tier === 'premium' ? 'Premium' : 'Agency'} Lead ${l.biz_no || l.id}`;
  // name first, so you know who it is when you call — e.g. "Lucifer · Funnel Lead 12"
  return (real ? `${real.slice(0, 40)} · ${tag}` : `${s.brand_name} ${tag}`).slice(0, 60);
}
/** Leads whose saved contact must change: add/rename (want = name) or delete (want = 'deleted'). Newest lead per chat only. */
export function contactQueue(s: Settings, limit = 5) {
  // v69: contacts first saved by phone number (form leads) kept the old name → save every contact once more (by id + by phone)
  if (num(s.contacts_ver) < 3) { run('UPDATE leads SET tg_contact=NULL WHERE tg_contact IS NOT NULL AND tg_contact!=\'deleted\''); setSetting('contacts_ver', '3'); }
  const rows = all<{ id: number; status: string; source: string | null; name: string | null; tg_name: string | null; tg_chat_id: string; tg_access_hash: string; tg_contact: string | null; biz: string | null; biz_no: number | null; tier: string | null; phone: string | null }>(
    `SELECT l.id, l.status, l.source, l.name, l.tg_name, l.tg_chat_id, l.tg_access_hash, l.tg_contact, l.biz, l.biz_no, l.tier, l.phone FROM leads l
     WHERE l.tg_chat_id IS NOT NULL AND l.tg_access_hash IS NOT NULL AND l.status!='merged'
       AND l.id = (SELECT MAX(x.id) FROM leads x WHERE x.tg_chat_id=l.tg_chat_id AND x.status!='merged')
     ORDER BY l.last_at DESC LIMIT 3000`);
  const out: (typeof rows[number] & { want: string })[] = [];
  for (const r of rows) {
    const want = r.status === 'dead' ? 'deleted' : contactName(r, s);
    if (want === 'deleted' ? (r.tg_contact && r.tg_contact !== 'deleted') : r.tg_contact !== want) out.push({ ...r, want });
    if (out.length >= limit) break;
  }
  return out;
}
export async function contactsTick() {
  const s = getSettings();
  if (s.save_contacts !== '1' || !ubReady(s) || quietAcct(s)) return null;
  const rows = contactQueue(s);
  if (!rows.length) return null;
  const c = await client(); if (!c) return null;
  let saved = 0, deleted = 0;
  for (const r of rows) {
    const user = new Api.InputUser({ userId: bigInt(r.tg_chat_id), accessHash: bigInt(r.tg_access_hash) });
    try {
      if (r.want === 'deleted') { await c.invoke(new Api.contacts.DeleteContacts({ id: [user] })); deleted++; }
      else {
        const res: any = await c.invoke(new Api.contacts.AddContact({ id: user, firstName: r.want, lastName: '', phone: '', addPhonePrivacyException: false }));
        // A contact that was first saved BY PHONE NUMBER (form leads) keeps that entry's old name unless it's saved by phone again.
        // Phones to use: the one Telegram shows us for this user + any phone on this chat's lead records.
        const tgPhone = String((res?.users || []).find((u: any) => String(u.id) === String(r.tg_chat_id))?.phone || '');
        const phones = new Set<string>();
        for (const raw of [tgPhone && '+' + tgPhone.replace(/^\+/, ''), r.phone, ...all<{ phone: string }>("SELECT DISTINCT phone FROM leads WHERE phone IS NOT NULL AND phone!='' AND tg_chat_id=?", r.tg_chat_id).map(x => x.phone)]) {
          let ph = String(raw || '').replace(/[^\d+]/g, '');
          if (/^\d{10}$/.test(ph)) ph = '+91' + ph;
          if (ph.replace(/\D/g, '').length >= 10) phones.add(ph.startsWith('+') ? ph : '+' + ph);
        }
        for (const ph of [...phones].slice(0, 3))
          await c.invoke(new Api.contacts.ImportContacts({ contacts: [new Api.InputPhoneContact({ clientId: bigInt(r.id), phone: ph, firstName: r.want, lastName: '' })] })).catch(() => null);
        saved++;
      }
      run('UPDATE leads SET tg_contact=? WHERE tg_chat_id=?', r.want, r.tg_chat_id);
    } catch (e) {
      if (handleLimit(e)) return { error: 'flood', saved, deleted };
      // the chat no longer exists / user deleted the account → don't retry forever
      run('UPDATE leads SET tg_contact=? WHERE id=?', r.want, r.id);
      console.warn('[contacts]', r.id, errText(e));
    }
  }
  return { saved, deleted };
}

/** Blue ticks: ask the chat account how far each client has read our messages (Telegram tells only the account,
 *  never the bot), then mark those messages read. Only runs while there are unread messages from the last 3 days. */
export async function readTick() {
  const s = getSettings();
  if (!ubReady(s) || quietAcct(s)) return 0;
  const want = all<{ lead_id: number; tg_chat_id: string }>(
    "SELECT DISTINCT m.lead_id, l.tg_chat_id FROM messages m JOIN leads l ON l.id=m.lead_id WHERE m.dir='out' AND m.read_at IS NULL AND m.tg_msg_id IS NOT NULL AND m.created_at>? AND l.tg_chat_id IS NOT NULL", now() - 3 * 86400000);
  if (!want.length) return 0;
  const c = await client();
  if (!c) return 0;
  let res: Api.messages.TypeDialogs;
  try {
    res = await c.invoke(new Api.messages.GetDialogs({ offsetDate: 0, offsetId: 0, offsetPeer: new Api.InputPeerEmpty(), limit: 100, hash: bigInt(0) }));
  } catch (e) { handleLimit(e); return 0; }
  if (!('dialogs' in res)) return 0;
  const readUpTo = new Map<string, number>();
  for (const d of res.dialogs) if (d instanceof Api.Dialog && d.peer instanceof Api.PeerUser) readUpTo.set(String(d.peer.userId), d.readOutboxMaxId);
  let n = 0;
  for (const w of want) {
    const max = readUpTo.get(w.tg_chat_id);
    if (max) n += markReadUpTo(w.lead_id, max);
  }
  return n;
}

/** "Last seen" like in Telegram: the chat account sees each client's online status (as far as their privacy allows).
 *  seen_state: online (seen_at = until when) · at (seen_at = exact time) · recently · week · month · '' (hidden). */
export function seenOf(st: unknown): { state: string; at: number | null } {
  if (st instanceof Api.UserStatusOnline) return { state: 'online', at: st.expires * 1000 };
  if (st instanceof Api.UserStatusOffline) return { state: 'at', at: st.wasOnline * 1000 };
  if (st instanceof Api.UserStatusRecently) return { state: 'recently', at: null };
  if (st instanceof Api.UserStatusLastWeek) return { state: 'week', at: null };
  if (st instanceof Api.UserStatusLastMonth) return { state: 'month', at: null };
  return { state: '', at: null };
}
export async function seenTick() {
  const s = getSettings();
  if (!ubReady(s) || quietAcct(s)) return 0;
  if (!one("SELECT 1 FROM leads WHERE tg_chat_id IS NOT NULL AND status IN ('active','new') AND last_at>? LIMIT 1", now() - 30 * 86400000)) return 0;
  const c = await client();
  if (!c) return 0;
  let res: Api.messages.TypeDialogs;
  try {
    res = await c.invoke(new Api.messages.GetDialogs({ offsetDate: 0, offsetId: 0, offsetPeer: new Api.InputPeerEmpty(), limit: 100, hash: bigInt(0) }));
  } catch (e) { handleLimit(e); return 0; }
  if (!('users' in res)) return 0;
  let n = 0;
  for (const u of res.users) {
    if (!(u instanceof Api.User) || u.bot || u.self) continue;
    const v = seenOf(u.status);
    n += run('UPDATE leads SET seen_state=?, seen_at=? WHERE tg_chat_id=? AND (COALESCE(seen_state,\'\')<>? OR COALESCE(seen_at,0)<>?)', v.state, v.at, String(u.id), v.state, v.at ?? 0).changes;
  }
  // v113: read in the Telegram app → read in the admin + agent apps too
  if ('dialogs' in res) for (const d of res.dialogs) if (d instanceof Api.Dialog && d.peer instanceof Api.PeerUser && !d.unreadMark) syncInboxRead(String(d.peer.userId), d.readInboxMaxId);
  return n;
}

/** The owner read the chat in Telegram up to message `maxId` → the apps count those messages as read (admin + agent). Pure-ish. */
export function syncInboxRead(chatId: string, maxId: number) {
  if (!maxId) return 0;
  const l = one<{ id: number; admin_read_at: number; agent_read_at: number }>("SELECT id, admin_read_at, agent_read_at FROM leads WHERE tg_chat_id=? AND status!='merged' ORDER BY id DESC LIMIT 1", chatId);
  if (!l) return 0;
  const t = one<{ t: number | null }>("SELECT MAX(created_at) t FROM messages WHERE lead_id=? AND dir='in' AND tg_msg_id IS NOT NULL AND tg_msg_id<=?", l.id, maxId)?.t;
  if (!t || (t <= (l.admin_read_at || 0) && t <= (l.agent_read_at || 0))) return 0;
  return run('UPDATE leads SET admin_read_at=MAX(COALESCE(admin_read_at,0), ?), agent_read_at=MAX(COALESCE(agent_read_at,0), ?) WHERE id=?', t, t, l.id).changes;
}

/** Read in the admin / agent app → mark it read in the Telegram app too (the chat account, directly). Best effort. */
export async function readInTelegram(chatId: string, hash: string | null, maxId: number) {
  const s = getSettings();
  if (!hash || !maxId || !ubReady(s) || quietAcct(s)) return false;
  const c = await client(); if (!c) return false;
  try { await c.invoke(new Api.messages.ReadHistory({ peer: peer(chatId, hash), maxId })); return true; } catch (e) { handleLimit(e); return false; }
}

/* ======================= v113: lead chats never hide in "Archived" ======================= */
/** Telegram's "Archive and mute new chats" (on by itself for busy accounts) sends a customer who writes again after the chat
 *  was deleted into Archived, muted → nobody sees it. Which archived chats are our open leads (and should they be unmuted)? Pure. */
export function archivedLeads(userIds: string[]) {
  if (!userIds.length) return [];
  const q = userIds.map(() => '?').join(',');
  return all<{ id: number; tg_chat_id: string; tg_muted: number | null }>(
    `SELECT id, tg_chat_id, tg_muted FROM leads WHERE tg_chat_id IN (${q}) AND status IN ('new','active','sold') AND last_at>? GROUP BY tg_chat_id`, ...userIds, now() - 60 * 86400000);
}
let privacyChecked = 0;
/** Every minute: turn "Archive and mute new chats" OFF (once an hour check) and move archived lead chats back to the chat list. */
export async function unarchiveTick() {
  const s = getSettings();
  if (s.ub_unarchive === '0' || !ubReady(s) || quietAcct(s)) return null;
  const c = await client(); if (!c) return null;
  let privacyOff = false, moved = 0, unmuted = 0;
  try {
    if (now() - privacyChecked > HOUR) {
      privacyChecked = now();
      const g = await c.invoke(new Api.account.GetGlobalPrivacySettings()) as Api.GlobalPrivacySettings;
      if (g?.archiveAndMuteNewNoncontactPeers) {
        await c.invoke(new Api.account.SetGlobalPrivacySettings({ settings: new Api.GlobalPrivacySettings({ ...g, archiveAndMuteNewNoncontactPeers: false }) }));
        privacyOff = true;
      }
    }
    const res = await c.invoke(new Api.messages.GetDialogs({ folderId: 1, offsetDate: 0, offsetId: 0, offsetPeer: new Api.InputPeerEmpty(), limit: 100, hash: bigInt(0) }));
    if (!('users' in res)) return { privacyOff, moved, unmuted };
    const users = res.users.filter((u): u is Api.User => u instanceof Api.User && !u.bot && !u.self && !!u.accessHash);
    const rows = archivedLeads(users.map(u => u.id.toString()));
    for (const r of rows) {
      const u = users.find(x => x.id.toString() === r.tg_chat_id)!;
      const p = new Api.InputPeerUser({ userId: u.id, accessHash: u.accessHash! });
      await c.invoke(new Api.folders.EditPeerFolders({ folderPeers: [new Api.InputFolderPeer({ peer: p, folderId: 0 })] }));
      run('UPDATE leads SET tg_access_hash=? WHERE tg_chat_id=?', u.accessHash!.toString(), r.tg_chat_id);
      moved++;
      // archive & mute also muted it: unmute unless WE mute it on purpose (other agents' chats)
      if (!r.tg_muted) { await c.invoke(new Api.account.UpdateNotifySettings({ peer: new Api.InputNotifyPeer({ peer: p }), settings: new Api.InputPeerNotifySettings({ muteUntil: 0 }) })).catch(() => {}); unmuted++; }
      const lead = one<{ id: number }>("SELECT id FROM leads WHERE tg_chat_id=? AND status!='merged' ORDER BY id DESC LIMIT 1", r.tg_chat_id);
      if (lead) run("INSERT INTO messages(lead_id, dir, sender, text, created_at) VALUES(?, 'sys', 'system', ?, ?)", lead.id, '📥 Telegram had put this chat in Archived (muted) — moved back to the chat list', now());
    }
    if (privacyOff || moved) setSetting('unarchive_status', `${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}: ${privacyOff ? '“Archive and mute new chats” turned OFF. ' : ''}${moved ? moved + ' chat(s) moved back from Archived.' : ''}`);
    return { privacyOff, moved, unmuted };
  } catch (e) {
    if (handleLimit(e)) return { error: 'flood' };
    return { error: errText(e) };
  }
}

/** v116: approve every join request still waiting in the channel (the chat account must be a channel admin).
 *  Bot API can't list old requests, so this goes through the chat account. Returns how many were waiting. */
export async function approvePendingJoins(chat: string): Promise<{ ok: boolean; count?: number; error?: string }> {
  const s = getSettings();
  if (!chat) return { ok: false, error: 'Channel is not set' };
  if (!ubReady(s)) return { ok: false, error: 'Chat account is not connected (Settings → Chat account)' };
  if (paused(s)) return { ok: false, error: 'Chat account is paused by Telegram for a while' };
  const c = await client(); if (!c) return { ok: false, error: 'Chat account is not connected' };
  const target = /^-?\d+$/.test(chat) ? chat.replace(/^-100/, '') : chat.replace(/^@/, '');
  try {
    let ent: Api.TypeInputPeer | null = null;
    try { ent = await c.getInputEntity(/^\d+$/.test(target) ? new Api.PeerChannel({ channelId: bigInt(target) }) : target); } catch { /* not cached yet */ }
    if (!ent) {
      const ds = await c.getDialogs({ limit: 300 });
      const d = ds.find(x => x.isChannel && (x.entity?.id?.toString() === target || ('username' in (x.entity || {}) && String((x.entity as Api.Channel).username || '').toLowerCase() === target.toLowerCase())));
      if (d?.inputEntity) ent = d.inputEntity;
    }
    if (!ent) return { ok: false, error: 'The chat account is not in this channel' };
    const r = await c.invoke(new Api.messages.GetChatInviteImporters({ peer: ent, requested: true, offsetDate: 0, offsetUser: new Api.InputUserEmpty(), limit: 1 })) as Api.messages.ChatInviteImporters;
    const count = r?.count || 0;
    if (count) await c.invoke(new Api.messages.HideAllChatJoinRequests({ peer: ent, approved: true }));
    return { ok: true, count };
  } catch (e) {
    if (handleLimit(e)) return { ok: false, error: 'Telegram asked to wait (flood)' };
    const t = errText(e);
    return { ok: false, error: /ADMIN|RIGHT|FORBIDDEN/i.test(t) ? 'The chat account must be an admin of the channel (with “Add members”)' : t };
  }
}

/** The client has read up to Telegram message `max` → our newest message at or below it, and everything we sent before it, is read. */
export function markReadUpTo(leadId: number, max: number) {
  const last = one<{ id: number | null }>("SELECT MAX(id) id FROM messages WHERE lead_id=? AND dir='out' AND tg_msg_id IS NOT NULL AND tg_msg_id<=?", leadId, max);
  return last?.id ? run("UPDATE messages SET read_at=? WHERE lead_id=? AND dir='out' AND read_at IS NULL AND id<=?", now(), leadId, last.id).changes : 0;
}

/** v137: delete a message the chat account sent, for both sides (revoke). Done by the worker (it holds the session). */
export async function queueUserbotDelete(leadId: number, tgId: number) {
  const r = run("INSERT INTO ub_outbox(lead_id, text, kind, tg_id, status, created_at) VALUES(?,?,?,?,?,?)", leadId, '', 'delete', tgId, 'queued', now());
  const id = Number(r.lastInsertRowid);
  for (let i = 0; i < 40; i++) {
    await new Promise(res => setTimeout(res, 500));
    const row = one<{ status: string; error: string | null }>('SELECT status, error FROM ub_outbox WHERE id=?', id);
    if (row?.status === 'sent') return { ok: true };
    if (row?.status === 'error') return { ok: false, error: row.error || 'not deleted' };
  }
  run("UPDATE ub_outbox SET status='error', error='timeout' WHERE id=? AND status='queued'", id);
  return { ok: false, error: 'The background worker did not answer. Is it running? (pm2 status)' };
}

/** v152: photos + a text to our own Saved Messages (the chat account), e.g. proof of a manual ad-account share. */
export async function ubSaveToSelf(files: { name: string; data: Buffer }[], text: string): Promise<boolean> {
  const c = await client();
  if (!c) return false;
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const { CustomFile } = require('telegram/client/uploads') as typeof import('telegram/client/uploads');
  const list = files.map(f => new CustomFile(f.name, f.data.length, '', f.data));
  if (list.length) await c.sendFile('me', { file: list, caption: list.length === 1 ? text : undefined, forceDocument: false });
  if (list.length !== 1 && text) await c.sendMessage('me', { message: text });
  return true;
}

/** v156: the 9:16 delivery image as a story of the chat account (24 h, everyone). The link area sits on the drawn button
 *  ("Get your account → @bot"). If Telegram refuses the link area (needs Premium on some accounts), the story goes without it. */
export async function ubPostStory(img: Buffer, caption: string, url: string | null): Promise<{ ok: boolean; link?: boolean; error?: string }> {
  const c = await client();
  if (!c) return { ok: false, error: 'chat account not logged in (Admin → Telegram chat account)' };
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const { CustomFile } = require('telegram/client/uploads') as typeof import('telegram/client/uploads');
  const file = await c.uploadFile({ file: new CustomFile('story.png', img.length, '', img), workers: 1 });
  const media = new Api.InputMediaUploadedPhoto({ file });
  // button on the 1080×1920 design: x 170..910, y 1680..1750 → centre in % of the picture
  const area = url ? [new Api.MediaAreaUrl({ coordinates: new Api.MediaAreaCoordinates({ x: 50, y: 89.9, w: 68.5, h: 3.7, rotation: 0 }), url })] : undefined;
  const send = (areas: typeof area, cap: string) => c.invoke(new Api.stories.SendStory({
    peer: new Api.InputPeerSelf(), media, mediaAreas: areas, caption: cap, privacyRules: [new Api.InputPrivacyValueAllowAll()],
    randomId: bigInt(Math.floor(Math.random() * 9e15)), period: 86400,
  }));
  let lastErr = '';
  for (const [areas, cap] of [[area, caption], [undefined, caption], [undefined, caption.slice(0, 120)]] as const) {
    try { await send(areas, cap); return { ok: true, link: !!areas }; }
    catch (e) { lastErr = errText(e); if (/FLOOD|PREMIUM_ACCOUNT_REQUIRED.*STORIES|STORIES_TOO_MUCH/i.test(lastErr) && !areas) break; }
  }
  return { ok: false, error: lastErr };
}
