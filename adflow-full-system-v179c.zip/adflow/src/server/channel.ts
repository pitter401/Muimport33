/**
 * Telegram channel join tracking.
 * Landing top bar → /j → the bot (admin of the channel) creates a join link for THIS visitor (creates_join_request)
 * → the person taps "Request to join" → chat_join_request reaches our webhook → Meta "Subscribe" with that visitor's
 * click/browser ids (right pixel: Agency or Funnel page) → the request is approved. One Subscribe per person per pixel.
 */
import { one, all, run } from './db';
import { getSettings, type Settings } from './settings';
import { tg } from './telegram';
import { sendCapi, buildUserData, clickIds } from './capi';
import { clientIp } from './http';
import { now } from './util';
import { chanLine, dmOnJoin, dmWelcome, newTok } from './chanads';
import { campOfReq, noteVisitCamp } from './camps';

const DAY = 86400000;

/** @username or -100… id the bot uses for the channel: the setting, else the username from a public t.me/<name> link. */
export function channelChat(s: Settings = getSettings()) {
  const c = String(s.channel_chat || '').trim();
  if (c) return /^-?\d+$/.test(c) ? c : '@' + c.replace(/^@/, '').replace(/^https?:\/\/t\.me\//i, '');
  const m = String(s.channel_link || '').trim().match(/^(?:https?:\/\/)?t\.me\/([A-Za-z][A-Za-z0-9_]{3,})\/?$/i);
  return m ? '@' + m[1] : '';
}

/** /j?line=agency|funnel → a join link for this visitor (re-used for 7 days). Falls back to the plain channel link. */
export async function joinLinkFor(req: Request): Promise<string | null> {
  const s = getSettings();
  const url = new URL(req.url);
  // v111: channel-ad pages send line=agency|premium|funnel & src=ad (premium joins count on the Agency pixel)
  const lx = chanLine(url.searchParams.get('line'));
  const line = lx === 'funnel' ? 'funnel' : 'agency';
  const sp = url.searchParams.get('src');
  const src = sp === 'ad' ? 'ad' : sp === 'page' ? 'page' : 'bar'; // channel-ad page · /telegram page · the landing top bar
  const page = req.headers.get('referer') || '';
  const ids = clickIds(req, page);
  const fallback = s.channel_link || (channelChat(s).startsWith('@') ? `https://t.me/${channelChat(s).slice(1)}` : null);
  const chat = channelChat(s);
  if (!chat || !s.bot_token) return fallback;
  if (ids.vid) {
    const old = one<{ id: number; link: string }>("SELECT id, link FROM channel_joins WHERE vid=? AND line=? AND COALESCE(line_x, line)=? AND COALESCE(src,'bar')=? AND link IS NOT NULL AND created_at>? ORDER BY id DESC LIMIT 1", ids.vid, line, lx, src, now() - 7 * DAY);
    if (old) {
      run("UPDATE channel_joins SET fbc=COALESCE(NULLIF(?,''), fbc), fbp=COALESCE(NULLIF(?,''), fbp), ip=?, ua=? WHERE id=?", ids.fbc, ids.fbp, clientIp(req), req.headers.get('user-agent') || '', old.id);
      return old.link;
    }
  }
  const r = one<{ id: number }>('INSERT INTO channel_joins(vid, line, line_x, src, tok, ip, ua, fbc, fbp, page_url, created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?) RETURNING id',
    ids.vid || null, line, lx, src, src === 'ad' ? newTok() : null, clientIp(req), req.headers.get('user-agent') || '', ids.fbc || null, ids.fbp || null, page.slice(0, 500), now())!;
  const cmp = campOfReq(req, page); // v130: which campaign / ad brought this join
  if (cmp) { run('UPDATE channel_joins SET camp=?, adset=?, ad=? WHERE id=?', cmp.camp, cmp.adset, cmp.ad, r.id); noteVisitCamp(ids.vid, cmp); }
  const res = await tg(s, 'createChatInviteLink', { chat_id: chat, name: `v${r.id}`, creates_join_request: true });
  if (!res.ok) { console.warn('[channel] invite link:', res.description); return fallback; }
  run('UPDATE channel_joins SET link=? WHERE id=?', res.result.invite_link, r.id);
  return res.result.invite_link as string;
}

/** The welcome message's channel link: a join-request link made by the bot for THIS lead (never the plain public link,
 *  so people still join through a request). Joins through it are approved but send NO Subscribe — that's only for the website. */
export async function channelLinkForLead(lead: { id: number; vid?: string | null; line?: string | null; ip?: string | null; ua?: string | null; fbc?: string | null; fbp?: string | null; page_url?: string | null }) {
  const s = getSettings();
  const chat = channelChat(s);
  if (!chat || !s.bot_token) return null;
  const key = `chat${lead.id}`; // chat (welcome) joins: approved, but NO Subscribe event
  const line = lead.line === 'funnel' ? 'funnel' : 'agency';
  const old = one<{ link: string }>('SELECT link FROM channel_joins WHERE vid=? AND line=? AND link IS NOT NULL AND created_at>? ORDER BY id DESC LIMIT 1', key, line, now() - 30 * DAY);
  if (old) return old.link;
  const r = one<{ id: number }>("INSERT INTO channel_joins(vid, line, src, ip, ua, fbc, fbp, page_url, created_at) VALUES(?,?,'chat',?,?,?,?,?,?) RETURNING id",
    key, line, lead.ip || null, lead.ua || null, lead.fbc || null, lead.fbp || null, lead.page_url || null, now())!;
  const res = await tg(s, 'createChatInviteLink', { chat_id: chat, name: `v${r.id}`, creates_join_request: true });
  if (!res.ok) { console.warn('[channel] welcome invite link:', res.description); return null; }
  run('UPDATE channel_joins SET link=? WHERE id=?', res.result.invite_link, r.id);
  return res.result.invite_link as string;
}

type Jr = { chat: { id: number }; from: { id: number; first_name?: string }; user_chat_id?: number; invite_link?: { name?: string } };

/** A join request: Subscribe only when it came from the website top bar, then approve (any source). */
export async function handleJoinRequest(jr: Jr) {
  const s = getSettings();
  const uid = String(jr.from.id);
  const name = jr.invite_link?.name || '';
  const row = /^v\d+$/.test(name) ? one<any>('SELECT * FROM channel_joins WHERE id=?', Number(name.slice(1))) : undefined;
  if (row) run('UPDATE channel_joins SET tg_user=?, requested_at=? WHERE id=?', uid, now(), row.id);
  // Subscribe ONLY for joins from the website top bar (/j). Chat/welcome links and plain links: no event.
  const fromSite = !!row && !String(row.vid || '').startsWith('chat');
  let sent: unknown = null;
  // v113: Subscribe only for people who STAY (Admin → Telegram channel → minutes, default 60): it waits for their join,
  // then the worker checks they are still in the channel. 0 = at once, like before.
  if (fromSite && subDelayMin(s) <= 0) { sent = await sendSubscribe(s, row, uid); run("UPDATE channel_joins SET sub_at=?, sub_state='sent' WHERE id=?", now(), row.id); }
  // v111: channel-ad page → the bot DMs the offer first (only allowed before the request is approved), then approves at once
  const ad = !!row && row.src === 'ad';
  let dm: Awaited<ReturnType<typeof dmOnJoin>> | null = null;
  if (ad && s.chan_ad_dm_on !== '0') {
    dm = await dmOnJoin(s, jr.user_chat_id || jr.from.id, chanLine(row.line_x || row.line), row.tok || '').catch(e => ({ ok: false, error: String(e) }));
    run('UPDATE channel_joins SET dm_at=?, dm_err=? WHERE id=?', dm.ok ? now() : null, dm.ok ? null : dm.error.slice(0, 200), row.id);
  }
  // v116: everyone else gets the welcome message (once per person, never to people already chatting with us)
  if (!ad && s.chan_join_dm_on !== '0' && s.bot_username && !one('SELECT 1 FROM join_dms WHERE tg_user=?', uid)
    && !one("SELECT 1 FROM leads WHERE tg_chat_id=? AND status!='merged'", uid)) {
    dm = await dmWelcome(s, jr.user_chat_id || jr.from.id).catch(e => ({ ok: false, error: String(e) }));
    run('INSERT OR REPLACE INTO join_dms(tg_user, at, ok, err) VALUES(?,?,?,?)', uid, now(), dm.ok ? 1 : 0, dm.ok ? null : dm.error.slice(0, 200));
    if (row) run('UPDATE channel_joins SET dm_at=?, dm_err=? WHERE id=?', dm.ok ? now() : null, dm.ok ? null : dm.error.slice(0, 200), row.id);
  }
  // v116: ONE switch for the whole auto join (channel-ad pages and every other link)
  if (s.chan_auto_approve === '1') {
    const ar = await tg(s, 'approveChatJoinRequest', { chat_id: jr.chat.id, user_id: jr.from.id });
    if (ar.ok && row) markJoined(s, row.id); // in the channel from now (the chat_member update confirms it too)
  }
  return { matched: fromSite, sent, dm };
}

/** Minutes they must stay in the channel before Subscribe goes to Meta (0 = at once). */
export const subDelayMin = (s: Settings) => Math.max(0, Math.min(1440, Number(s.chan_sub_delay_min ?? 60) || 0));

/** Subscribe for this join (website joins only), with the visitor's click / browser ids. Once per person per pixel. */
export async function sendSubscribe(s: Settings, row: any, uid: string) {
  // same browser filled the form → send their phone/name too
  const lead = row.vid ? one<any>("SELECT * FROM leads WHERE vid=? AND status!='merged' AND source!='channel' ORDER BY id DESC LIMIT 1", row.vid) : undefined;
  const line = row.line === 'funnel' ? 'funnel' : 'agency';
  const ud = buildUserData({
    ...(lead || {}), id: lead?.id,
    ip: row.ip || lead?.ip, ua: row.ua || lead?.ua, fbc: row.fbc || lead?.fbc, fbp: row.fbp || lead?.fbp, vid: row.vid || lead?.vid,
    fbclid: lead?.fbclid, page_url: row.page_url || lead?.page_url, created_at: row.created_at || lead?.created_at,
  }, s);
  return sendCapi(s, {
    line, event_id: `sub_${line}_${uid}`, event_name: 'Subscribe', lead_id: lead?.id ?? null, source_url: row.page_url || null,
    once: { events: [`sub_${line}_${uid}`] },
    user_data: ud, custom_data: { content_name: 'Telegram channel' },
  }).catch(e => ({ error: String(e) }));
}

/** They are in the channel now → the stay clock starts (website joins wait for Subscribe). */
function markJoined(s: Settings, id: number) {
  const r = one<any>('SELECT * FROM channel_joins WHERE id=?', id);
  if (!r || r.joined_at) return;
  const site = !String(r.vid || '').startsWith('chat') && !r.sub_state;
  run('UPDATE channel_joins SET joined_at=?, left_at=NULL, sub_due=? WHERE id=?', now(), site && subDelayMin(s) > 0 ? now() + subDelayMin(s) * 60000 : null, id);
}

/** chat_member update for our channel: joined (approved by anyone) or left / removed. */
export function handleChatMember(cm: { chat: { id: number; username?: string }; new_chat_member?: { user?: { id: number }; status?: string; is_member?: boolean }; old_chat_member?: { status?: string } }) {
  const s = getSettings();
  const chat = channelChat(s);
  if (!chat || !(String(cm.chat.id) === chat || (cm.chat.username && '@' + cm.chat.username.toLowerCase() === chat.toLowerCase()))) return null;
  const uid = String(cm.new_chat_member?.user?.id || '');
  if (!uid) return null;
  const st = cm.new_chat_member?.status || '';
  const inside = ['member', 'administrator', 'creator'].includes(st) || (st === 'restricted' && cm.new_chat_member?.is_member !== false);
  const row = one<any>('SELECT * FROM channel_joins WHERE tg_user=? AND requested_at>? ORDER BY id DESC LIMIT 1', uid, now() - 30 * DAY);
  if (!row) return null;
  if (inside) { markJoined(s, row.id); return 'joined'; }
  if (st === 'left' || st === 'kicked') {
    run("UPDATE channel_joins SET left_at=?, sub_state=CASE WHEN sub_state IS NULL AND sub_due IS NOT NULL THEN 'left' ELSE sub_state END WHERE id=?", now(), row.id);
    return 'left';
  }
  return null;
}

/** Worker (every minute): joins whose stay time is over → still in the channel? Subscribe. Left? nothing. */
export async function subscribeDue(s: Settings = getSettings()) {
  const chat = channelChat(s);
  const rows = all<any>("SELECT * FROM channel_joins WHERE sub_due IS NOT NULL AND sub_due<=? AND sub_state IS NULL AND tg_user IS NOT NULL ORDER BY sub_due LIMIT 50", now());
  let sent = 0;
  for (const r of rows) {
    if (r.left_at) { run("UPDATE channel_joins SET sub_state='left' WHERE id=?", r.id); continue; }
    const m = chat ? await tg(s, 'getChatMember', { chat_id: chat, user_id: Number(r.tg_user) }).catch(() => null) : null;
    if (!m?.ok) { if (now() - r.sub_due > DAY) run("UPDATE channel_joins SET sub_state='skipped' WHERE id=?", r.id); continue; } // Telegram busy → next minute
    const st = m.result?.status;
    const inside = ['member', 'administrator', 'creator'].includes(st) || (st === 'restricted' && m.result?.is_member !== false);
    if (!inside) { run("UPDATE channel_joins SET sub_state='left', left_at=COALESCE(left_at, ?) WHERE id=?", now(), r.id); continue; }
    await sendSubscribe(s, r, String(r.tg_user));
    run("UPDATE channel_joins SET sub_state='sent', sub_at=? WHERE id=?", now(), r.id);
    sent++;
  }
  return sent;
}

/** Admin "Check channel": the bot can see the channel and is an admin allowed to invite. */
export async function checkChannel(s: Settings = getSettings()) {
  const chat = channelChat(s);
  if (!chat) return { ok: false, error: 'Set the channel @username (or -100… ID), or a public t.me/<name> link.' };
  if (!s.bot_token) return { ok: false, error: 'Bot token not set.' };
  const c = await tg(s, 'getChat', { chat_id: chat });
  if (!c.ok) return { ok: false, error: `The bot can’t see ${chat}. Add the bot to the channel as an admin. (${c.description || ''})` };
  const me = await tg(s, 'getMe', {});
  const m = me.ok ? await tg(s, 'getChatMember', { chat_id: chat, user_id: me.result.id }) : { ok: false } as any;
  const st = m.ok ? m.result : null;
  if (!st || (st.status !== 'administrator' && st.status !== 'creator')) return { ok: false, error: 'The bot is in the channel but not an admin. Make it an admin with “Invite users via link”.' };
  if (st.status === 'administrator' && st.can_invite_users === false) return { ok: false, error: 'Give the bot the “Invite users via link” admin right.' };
  const test = await tg(s, 'createChatInviteLink', { chat_id: chat, name: 'check', creates_join_request: true });
  if (!test.ok) return { ok: false, error: 'Could not make a join link: ' + (test.description || '') };
  await tg(s, 'revokeChatInviteLink', { chat_id: chat, invite_link: test.result.invite_link });
  return { ok: true, title: c.result.title as string, chat };
}
