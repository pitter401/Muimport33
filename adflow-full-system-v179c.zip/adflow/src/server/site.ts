import { offerImagePath } from './offerimg';
import { headers } from 'next/headers';
import type { Metadata } from 'next';
import { getSettings, fmt, lines, usesUploadedLogo, tierFor, type Settings } from './settings';
import { kitVersion } from './brandkit';

/** Public origin of the site (no trailing slash). PUBLIC_URL wins; otherwise the request's own host. */
export async function siteUrl() {
  if (process.env.PUBLIC_URL) return process.env.PUBLIC_URL.replace(/\/$/, '');
  const h = await headers();
  const proto = h.get('x-forwarded-proto')?.split(',')[0] || 'https';
  const host = h.get('x-forwarded-host') || h.get('host') || 'localhost';
  return `${proto}://${host}`;
}

/** Accepts the full tag Google gives (<meta name="google-site-verification" content="abc" />) or just "abc". */
export function gscCode(v: string) {
  const s = String(v || '').trim();
  if (!s) return '';
  const m = s.match(/content\s*=\s*["']([^"']+)["']/i);
  return (m ? m[1] : s).replace(/[^A-Za-z0-9_\-]/g, '').slice(0, 100);
}

/**
 * Metadata for the landing pages. "/" and the four design URLs (/p/purple, /p/gold, /p/green, /p/blue) show the
 * same text, so all of them name "/" as the canonical page — Google indexes one strong page instead of five copies.
 */
export async function landingMetadata(s: Settings = getSettings(), mode: 'agency' | 'funnel' = 'agency'): Promise<Metadata> {
  const base = await siteUrl();
  const F = mode === 'funnel';
  // the Funnel page (/funnel + its design URLs) is its own page for Google, with its own title
  const canon = F ? '/funnel' : '/';
  const title = fmt(F ? s.f_seo_title : s.seo_title, s);
  const description = fmt(F ? s.f_seo_description : s.seo_description, s);
  const v = kitVersion(s);
  // 16:9 share card: Agency design on the main page, Funnel design on /funnel (same images as the WhatsApp short links)
  const img = { url: `/share-image?line=${F ? 'funnel' : 'agency'}&v=${v}`, width: 1200, height: 675, alt: title, type: 'image/png' };
  const google = gscCode(s.gsc_verify);
  return {
    metadataBase: new URL(base),
    title,
    description,
    applicationName: s.brand_name,
    alternates: { canonical: canon },
    robots: { index: true, follow: true, googleBot: { index: true, follow: true, 'max-image-preview': 'large', 'max-snippet': -1, 'max-video-preview': -1 } },
    openGraph: { type: 'website', url: canon, siteName: s.brand_name, title, description, locale: 'en_US', images: [img] },
    twitter: { card: 'summary_large_image', title, description, images: [img.url] },
    formatDetection: { telephone: false, email: false, address: false },
    ...(google ? { verification: { google } } : {}),
    icons: siteIcons(s),
  };
}

/** Favicon / app icon — the uploaded logo or the generated brand logo (used by every page, incl. /telegram). */
/** v134: share card (WhatsApp / Telegram / Facebook link preview) + site icon for any page — same 16:9 image as the landing pages. */
export async function shareMeta(o: { title: string; description?: string; line?: 'agency' | 'funnel'; url?: string }, s: Settings = getSettings()) {
  const img = { url: `/share-image?line=${o.line === 'funnel' ? 'funnel' : 'agency'}&v=${kitVersion(s)}`, width: 1200, height: 675, alt: o.title, type: 'image/png' };
  return {
    metadataBase: new URL(await siteUrl()),
    openGraph: { type: 'website' as const, siteName: s.brand_name, title: o.title, ...(o.description ? { description: o.description } : {}), ...(o.url ? { url: o.url } : {}), images: [img] },
    twitter: { card: 'summary_large_image' as const, title: o.title, ...(o.description ? { description: o.description } : {}), images: [img.url] },
    icons: siteIcons(s),
  };
}
export function siteIcons(s: Settings = getSettings()) {
  const v = kitVersion(s);
  return usesUploadedLogo(s) ? { icon: `/api/logo?v=${s.logo_ver}`, apple: `/api/logo?v=${s.logo_ver}` } : { icon: `/brand/logo.png?size=192&v=${v}`, apple: `/brand/logo.png?size=180&v=${v}` };
}

/** Other ways people type the brand ("Adsbhai", "Ads Bhai", "adsbhai.com") — helps the brand search find us. */
function brandAliases(s: Settings, base: string) {
  const b = (s.brand_name || '').trim();
  const host = base.replace(/^https?:\/\//, '');
  const spaced = b.replace(/([a-z])([A-Z])/g, '$1 $2');
  return [...new Set([b.toLowerCase(), spaced, b.replace(/\s+/g, ''), host].filter(x => x && x !== b))];
}

/** schema.org data for Google: the business, the website, the two services with prices, and the FAQ. */
export async function landingJsonLd(s: Settings = getSettings()) {
  const base = await siteUrl();
  const org = `${base}/#org`;
  const faq = lines(fmt(s.faq, s)).filter(l => !/ad policies still apply/i.test(l))
    .map(l => { const i = l.indexOf('|'); return i > 0 ? [l.slice(0, i).trim(), l.slice(i + 1).trim()] : ['', ''] as string[]; })
    .filter(([q, a]) => q && a);
  const offer = (name: string, desc: string, price: string, monthly: boolean) => ({
    '@type': 'Offer',
    name, description: desc, url: `${base}/`,
    price: String(Number(price) || price), priceCurrency: 'USD', availability: 'https://schema.org/InStock',
    ...(monthly ? { priceSpecification: { '@type': 'UnitPriceSpecification', price: String(Number(price) || price), priceCurrency: 'USD', unitCode: 'MON', referenceQuantity: { '@type': 'QuantitativeValue', value: 1, unitCode: 'MON' } } } : {}),
  });
  const graph: Record<string, unknown>[] = [
    {
      '@type': 'Organization', '@id': org, name: s.brand_name, alternateName: brandAliases(s, base), url: `${base}/`,
      logo: usesUploadedLogo(s) ? `${base}/api/logo?v=${s.logo_ver}` : `${base}/brand/logo.png?size=512`,
      ...(s.channel_link ? { sameAs: [s.channel_link] } : {}),
    },
    { '@type': 'WebSite', '@id': `${base}/#website`, url: `${base}/`, name: s.brand_name, alternateName: brandAliases(s, base), inLanguage: 'en', publisher: { '@id': org } },
    {
      '@type': 'Service', '@id': `${base}/#service`, name: fmt(s.account_title, s), serviceType: 'Meta agency ad accounts',
      description: fmt(s.seo_description, s), provider: { '@id': org }, areaServed: 'Worldwide',
      offers: [
        offer(fmt(s.account_title, s), fmt(s.account_sub, s), s.price_account, false),
        offer(fmt(s.funnel_title, s), fmt(s.funnel_sub, s), s.price_funnel, true),
        ...(s.premium_on === '1' ? [{ ...offer(fmt(s.premium_title, s), fmt(s.premium_sub, s), s.price_premium, false), url: `${base}/premium` }] : []),
      ],
    },
  ];
  if (faq.length) graph.push({ '@type': 'FAQPage', '@id': `${base}/#faq`, mainEntity: faq.map(([q, a]) => ({ '@type': 'Question', name: q, acceptedAnswer: { '@type': 'Answer', text: a } })) });
  // "<" escaped so the JSON can never close the <script> tag
  return JSON.stringify({ '@context': 'https://schema.org', '@graph': graph }).replace(/</g, '\\u003c');
}

/* ---------------- /premium ---------------- */
/** Premium page: its own title + description for Google ("Premium Agency Ad Accounts — Strong, Aged Profiles"). */
export async function premiumMetadata(s0: Settings = getSettings()): Promise<Metadata> {
  const s = tierFor(s0, 'premium');
  const m = await landingMetadata(s0);
  const title = fmt(s.premium_seo_title, s), description = fmt(s.premium_seo_description, s);
  return {
    ...m, title, description, alternates: { canonical: '/premium' },
    // v140: the Premium offer image (Premium price) — the Agency share card showed the Agency "From $" price
    openGraph: { ...(m.openGraph || {}), url: '/premium', title, description, images: [{ url: offerImagePath(s0, 'premium'), width: 1280, height: 720, alt: title, type: 'image/png' }] },
    twitter: { ...(m.twitter || {}), title, description, images: [offerImagePath(s0, 'premium')] },
  };
}

/** schema.org for /premium: the Premium product with its price, a breadcrumb under the brand, and its points as an item list. */
export async function premiumJsonLd(s0: Settings = getSettings()) {
  const base = await siteUrl();
  const s = tierFor(s0, 'premium');
  const url = `${base}/premium`;
  const graph = [
    {
      '@type': 'Product', '@id': `${url}#product`, name: fmt(s.premium_title, s), description: fmt(s.premium_seo_description, s),
      brand: { '@type': 'Brand', name: s.brand_name }, category: 'Meta agency ad accounts', url,
      image: `${base}${offerImagePath(s0, 'premium')}`,
      additionalProperty: lines(fmt(s.premium_bullets, s)).map(x => ({ '@type': 'PropertyValue', name: 'Premium', value: x })),
      offers: [
        { '@type': 'Offer', name: 'Order on Telegram', price: String(Number(s.price_premium) || s.price_premium), priceCurrency: 'USD', availability: 'https://schema.org/InStock', url, seller: { '@id': `${base}/#org` } },
        ...(s0.web_orders_on === '1' && Number(s.price_premium_web) > 0 ? [{ '@type': 'Offer', name: 'Order on the website', price: String(Number(s.price_premium_web)), priceCurrency: 'USD', availability: 'https://schema.org/InStock', url: `${base}/order?tier=premium`, seller: { '@id': `${base}/#org` } }] : []),
      ],
    },
    { '@type': 'BreadcrumbList', itemListElement: [
      { '@type': 'ListItem', position: 1, name: s.brand_name, item: `${base}/` },
      { '@type': 'ListItem', position: 2, name: 'Premium ad accounts', item: url },
    ] },
  ];
  return JSON.stringify({ '@context': 'https://schema.org', '@graph': graph }).replace(/</g, '\\u003c');
}
