import crypto from 'crypto';
import { one } from './db';
import { getSettings } from './settings';

function secret() {
  const s = process.env.APP_SECRET;
  if (!s || s.length < 16) throw new Error('APP_SECRET is missing in .env (min 16 chars)');
  return s;
}

export function hashPassword(pw: string) {
  const salt = crypto.randomBytes(16).toString('hex');
  return `scrypt$${salt}$${crypto.scryptSync(pw, salt, 32).toString('hex')}`;
}
export function verifyPassword(pw: string, stored: string) {
  const [alg, salt, hash] = String(stored || '').split('$');
  if (alg !== 'scrypt' || !salt || !hash) return false;
  const a = crypto.scryptSync(pw, salt, 32), b = Buffer.from(hash, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

type Payload = { r: 'admin' | 'agent' | 'cust' | 'dl'; id: number; v: number; exp: number }; // v166: 'dl' = 5-minute download token
const b64 = (s: string) => Buffer.from(s).toString('base64url');
const sign = (data: string) => crypto.createHmac('sha256', secret()).update(data).digest('base64url');

export function makeToken(p: Omit<Payload, 'exp'>, days = 60) {
  const data = b64(JSON.stringify({ ...p, exp: Date.now() + days * 86400000 }));
  return `${data}.${sign(data)}`;
}
function readToken(t: string | undefined | null): Payload | null {
  if (!t) return null;
  const [data, sig] = t.split('.');
  if (!data || !sig) return null;
  const good = sign(data);
  if (good.length !== sig.length || !crypto.timingSafeEqual(Buffer.from(good), Buffer.from(sig))) return null;
  try { const p = JSON.parse(Buffer.from(data, 'base64url').toString()) as Payload; return p.exp > Date.now() ? p : null; } catch { return null; }
}

function cookie(req: Request, name: string) {
  const m = (req.headers.get('cookie') || '').match(new RegExp('(?:^|;\\s*)' + name + '=([^;]+)'));
  return m ? decodeURIComponent(m[1]) : null;
}
function bearer(req: Request) {
  const h = req.headers.get('authorization') || '';
  return h.startsWith('Bearer ') ? h.slice(7) : null;
}

/** Admin password: the one set in the Admin app, else ADMIN_PASSWORD from .env */
export function checkAdminLogin(username: string, password: string) {
  const u = process.env.ADMIN_USERNAME || 'admin';
  if (username.trim().toLowerCase() !== u.toLowerCase()) return false;
  const s = getSettings();
  if (s.admin_pass_hash) return verifyPassword(password, s.admin_pass_hash);
  return !!process.env.ADMIN_PASSWORD && password === process.env.ADMIN_PASSWORD;
}
export function adminVersion() { const s = getSettings(); return s.admin_pass_hash ? parseInt(s.admin_pass_hash.slice(-6), 16) || 1 : 1; }

/** v127: a token in the URL (?t=) only counts when it is a short download token (max 10 minutes left).
 *  v166: and only a 'dl' token, only on a GET of an export path (never a login for anything else). */
function urlToken(req: Request) {
  if (req.method !== 'GET') return null;
  const u = new URL(req.url);
  const p = readToken(u.searchParams.get('t'));
  const path = u.pathname.replace(/^.*\/api\/admin\//, '');
  const exportPath = /\/api\/admin\//.test(u.pathname) && (path.startsWith('export/') || (path.startsWith('export_') && path !== 'export_token'));
  return p && p.r === 'dl' && exportPath && p.exp - Date.now() <= 10 * 60000 ? p : null;
}
export function getAdmin(req: Request) {
  const p = readToken(bearer(req) || cookie(req, 'af_admin'));
  if (p && p.r === 'admin' && p.v === adminVersion()) return { id: 0 };
  const d = urlToken(req); // v166
  return d && d.v === adminVersion() ? { id: 0 } : null;
}

export type Agent = { id: number; name: string; username: string; tg_chat_id: string | null; comm_per_sale: number; receive: number; online: number; session_ver: number; role: string };
export function getAgent(req: Request): Agent | null {
  const p = readToken(bearer(req) || cookie(req, 'af_agent')); // v166: no URL token for agents (download tokens are admin-only)
  if (!p || p.r !== 'agent') return null;
  const a = one<Agent>('SELECT * FROM agents WHERE id=? AND deleted=0', p.id);
  return a && a.session_ver === p.v ? a : null;
}

export type Customer = { id: number; email: string; name: string | null; phone: string | null; session_ver: number };
export function getCustomer(req: Request): Customer | null {
  const p = readToken(cookie(req, 'af_cust') || bearer(req));
  if (!p || p.r !== 'cust') return null;
  const c = one<Customer>('SELECT * FROM customers WHERE id=?', p.id);
  return c && c.session_ver === p.v ? c : null;
}

export const cookieHeader = (name: string, token: string, maxDays = 60) =>
  `${name}=${token}; Path=/; Max-Age=${maxDays * 86400}; HttpOnly; SameSite=Lax${process.env.INSECURE_COOKIES === '1' ? '' : '; Secure'}`;
