import fs from 'fs';
import path from 'path';
import { ImageResponse } from 'next/og';
import { getSettings, fmt, usesUploadedLogo, type Settings } from './settings';
import { readLogo } from './logo';
import { offerFacts, type OfferLine } from './offerimg';

/**
 * Brand kit — images made automatically from the brand name and the MAIN landing theme (Admin → Brand & landing page):
 *   logo (square, the brand's first letter), wide logo (mark + name), Facebook cover, link-share (OG) image.
 * Change the brand name or the main theme and every image follows. An uploaded logo is used inside the cover/OG image.
 */

/** Colours per main theme: [background gradient stops], [logo mark gradient], accent text colour. */
const KIT: Record<string, { bg: string[]; mark: [string, string]; accent: string; glow: string }> = {
  purple: { bg: ['#000000', '#1d0a4a', '#4a17a3', '#8a2fd0', '#c446c9', '#e8619b', '#f6a77b'], mark: ['#7c3aed', '#d946ef'], accent: '#ffd8c8', glow: 'rgba(246,167,123,.55)' },
  blue: { bg: ['#020a1f', '#061a4d', '#0b3aa8', '#1663e6', '#38bdf8'], mark: ['#1663e6', '#38bdf8'], accent: '#bfe0ff', glow: 'rgba(56,189,248,.45)' },
  green: { bg: ['#02130a', '#053d24', '#0b6b3a', '#15803d', '#65a30d'], mark: ['#15803d', '#84cc16'], accent: '#d9f99d', glow: 'rgba(190,242,100,.4)' },
  gold: { bg: ['#04050c', '#1a1030', '#7c2d5a', '#f43f5e', '#fb923c'], mark: ['#f97316', '#f43f5e'], accent: '#fed7aa', glow: 'rgba(251,146,60,.5)' },
};
export const kitFor = (theme: string) => KIT[theme] || KIT.purple;

/** First letter (or digit) of the brand, upper-case: "AdsBhai" -> "A", "Bitflow" -> "B". */
export function brandInitial(brand: string) {
  const m = String(brand || '').match(/[\p{L}\p{N}]/u);
  return (m ? m[0] : 'A').toUpperCase();
}

let fontCache: { name: string; data: ArrayBuffer; weight: 400 | 600 | 800; style: 'normal' }[] | null = null;
function fonts() {
  if (fontCache) return fontCache;
  const dir = path.join(process.cwd(), 'node_modules', '@fontsource', 'montserrat', 'files');
  const load = (w: 400 | 600 | 800) => {
    try { const b = fs.readFileSync(path.join(dir, `montserrat-latin-${w}-normal.woff`)); return { name: 'Montserrat', data: b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength) as ArrayBuffer, weight: w, style: 'normal' as const }; } catch { return null; }
  };
  fontCache = ([400, 600, 800] as const).map(load).filter(Boolean) as NonNullable<ReturnType<typeof load>>[];
  return fontCache;
}

const grad = (stops: string[], deg = 160) => `linear-gradient(${deg}deg, ${stops.join(', ')})`;
const uploadedLogo = (s: Settings) => { if (!usesUploadedLogo(s)) return null; const l = readLogo(); return l && l.type !== 'image/svg+xml' ? `data:${l.type};base64,${l.buf.toString('base64')}` : null; };

/** The logo symbol (white, on the theme gradient): an upward arrow shaped like an "A" over a rising bar chart. */
function Glyph({ size }: { size: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100">
      <path d="M50 16 L80 46 H62 L50 34 L38 46 H20 Z" fill="#ffffff" />
      <rect x="24" y="56" width="11" height="24" rx="3" fill="#ffffff" fillOpacity="0.6" />
      <rect x="44.5" y="48" width="11" height="32" rx="3" fill="#ffffff" fillOpacity="0.85" />
      <rect x="65" y="56" width="11" height="24" rx="3" fill="#ffffff" fillOpacity="0.6" />
    </svg>
  );
}

/** The square brand mark: rounded square, theme gradient, the logo symbol. */
function Mark({ size, theme, radius = 0.24 }: { size: number; theme: string; brand?: string; radius?: number }) {
  const k = kitFor(theme);
  return (
    <div style={{ width: size, height: size, borderRadius: size * radius, background: grad(k.mark, 135), display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', top: -size * 0.22, right: -size * 0.16, width: size * 0.68, height: size * 0.68, borderRadius: size, background: 'rgba(255,255,255,0.13)', display: 'flex' }} />
      <Glyph size={size} />
    </div>
  );
}

const opts = (w: number, h: number, extra: Record<string, string> = {}) => ({ width: w, height: h, fonts: fonts(), headers: { 'Cache-Control': 'public, max-age=600', ...extra } });

/** Square logo (Facebook / Instagram profile picture, favicon). Full-bleed, so it also works in a circle crop. */
export function logoImage(s: Settings = getSettings(), size = 1024, extra?: Record<string, string>) {
  const k = kitFor(s.theme);
  return new ImageResponse(
    <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', background: grad(k.mark, 135), position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', top: -size * 0.22, right: -size * 0.16, width: size * 0.68, height: size * 0.68, borderRadius: size, background: 'rgba(255,255,255,0.13)', display: 'flex' }} />
      <Glyph size={size * 1.02} />
    </div>,
    opts(size, size, extra),
  );
}

/** Android app icon — just the logo, no text. Admin app: the site logo (uploaded or the main theme's).
 *  Agent app: the logo mark in its own colour (Admin → System → Agent app icon) so the two apps are easy to tell apart.
 *  shape: square (legacy, rounded) · round (circle) · full (adaptive-icon layer; the phone cuts the shape) · clear (empty layer). */
export function appIconImage(s: Settings = getSettings(), app: 'admin' | 'agent' = 'agent', size = 192, shape: 'square' | 'round' | 'full' | 'clear' = 'square', extra?: Record<string, string>, theme?: string) {
  if (shape === 'clear') return new ImageResponse(<div style={{ width: '100%', height: '100%', display: 'flex' }} />, opts(size, size, extra));
  const t = theme || (app === 'agent' ? s.apk_agent_theme || 'green' : s.theme);
  const k = kitFor(t);
  const up = app === 'admin' && !theme ? uploadedLogo(s) : null;
  const radius = shape === 'round' ? size : shape === 'square' ? size * 0.22 : 0;
  return new ImageResponse(
    up
      ? <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#ffffff', borderRadius: radius, overflow: 'hidden' }}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={up} width={size * 0.8} height={size * 0.8} style={{ objectFit: 'contain' }} alt="" />
        </div>
      : <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', background: grad(k.mark, 135), position: 'relative', overflow: 'hidden', borderRadius: radius }}>
          <div style={{ position: 'absolute', top: -size * 0.22, right: -size * 0.16, width: size * 0.68, height: size * 0.68, borderRadius: size, background: 'rgba(255,255,255,0.13)', display: 'flex' }} />
          <Glyph size={size * 0.9} />
        </div>,
    opts(size, size, extra),
  );
}

/** Wide logo: mark + brand name on a transparent background. on = 'light' (dark text) or 'dark' (white text). */
export function wideLogoImage(s: Settings = getSettings(), on: 'light' | 'dark' = 'light', extra?: Record<string, string>) {
  const H = 300, name = s.brand_name || 'Brand';
  const W = Math.round(H * 1.1 + name.length * H * 0.36 + 60);
  return new ImageResponse(
    <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', gap: H * 0.16, padding: `0 ${H * 0.1}px` }}>
      <Mark size={H * 0.8} theme={s.theme} brand={name} />
      <div style={{ fontFamily: 'Montserrat', fontWeight: 800, fontSize: H * 0.42, letterSpacing: -H * 0.012, color: on === 'dark' ? '#ffffff' : '#0f0a24', display: 'flex' }}>{name}</div>
    </div>,
    opts(W, H, extra),
  );
}

/**
 * Wide banner in the main theme: Facebook cover (1640x624) and link-share image (1200x630).
 * Facebook format: on phones the sides are cut off and the profile picture covers the bottom-centre,
 * so everything important sits in the top-middle band (measured on a phone: only the middle ~60% of the width
 * shows and the profile picture starts just below half height); the name sits bottom-left of the visible area.
 */
export function coverImage(s: Settings = getSettings(), w = 1640, h = 624, extra?: Record<string, string>) {
  const k = kitFor(s.theme);
  const u = uploadedLogo(s);
  const prices = [Number(s.price_account), s.web_orders_on === '1' ? Number(s.price_account_web) : NaN].filter(n => n > 0);
  const fromPrice = prices.length ? String(Math.min(...prices)) : s.price_account;
  const partner = s.partner_on === '1' ? (s.partner_text || '').trim() : '';
  const facebook = w / h > 2.2;
  const sc = facebook ? h / 624 : (w / 1640) * 1.45; // OG image: bigger text, it is shown small
  const tick = (c: string, sz: number) => (
    <svg width={sz} height={sz} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="3.4" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5" /></svg>
  );
  const chips = ['No spending limit', `From $${fromPrice}`, `Live in ${s.delivery_time}`];
  const pad = { padding: `${9 * sc}px ${18 * sc}px`, borderRadius: 999, fontSize: (facebook ? 17 : 19.5) * sc, fontWeight: 600, display: 'flex', alignItems: 'center', gap: 8 * sc } as const;
  // growth line along the bottom
  const wave = `M0 ${h * 0.93} C ${w * 0.18} ${h * 0.8}, ${w * 0.3} ${h * 0.92}, ${w * 0.48} ${h * 0.82} S ${w * 0.75} ${h * 0.7}, ${w} ${h * 0.5}`;
  return new ImageResponse(
    <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', position: 'relative', overflow: 'hidden', background: grad(k.bg, 120), fontFamily: 'Montserrat', color: '#fff' }}>
      <div style={{ position: 'absolute', left: w * 0.18, top: -h * 0.5, width: h * 1.1, height: h * 1.1, borderRadius: h, background: 'rgba(255,255,255,0.07)', display: 'flex' }} />
      <div style={{ position: 'absolute', right: -h * 0.3, top: h * 0.2, width: h * 1.2, height: h * 1.2, borderRadius: h, background: 'rgba(255,255,255,0.06)', display: 'flex' }} />
      <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} style={{ position: 'absolute', left: 0, top: 0 }}>
        <path d={wave} fill="none" stroke="rgba(255,255,255,0.45)" strokeWidth={3 * sc} />
      </svg>
      {/* upper-middle band: partner, headline, chips */}
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', marginTop: facebook ? 44 * sc : 64 * sc, gap: (facebook ? 14 : 20) * sc, maxWidth: facebook ? w * 0.56 : w * 0.9 }}>
        {partner && (
          <div style={{ ...pad, background: 'rgba(255,255,255,0.14)', border: `${1.5 * sc}px solid rgba(255,255,255,0.3)`, paddingLeft: 8 * sc }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: 28 * sc, height: 28 * sc, borderRadius: 999, background: '#0866ff' }}>{tick('#fff', 17 * sc)}</div>
            {partner}
          </div>
        )}
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', fontWeight: 800, fontSize: (facebook ? 62 : 76) * sc, lineHeight: 1.04, letterSpacing: -2 * sc, textAlign: 'center' }}>
          <span>Agency ad accounts</span>
          <span style={{ color: k.accent }}>in {s.delivery_time}.</span>
        </div>
        <div style={{ display: 'flex', gap: 12 * sc, flexWrap: 'wrap', justifyContent: 'center' }}>
          {chips.map(t => <div key={t} style={{ ...pad, background: 'rgba(0,0,0,0.22)', border: `${1.5 * sc}px solid rgba(255,255,255,0.22)` }}>{tick(k.accent, 18 * sc)}{t}</div>)}
          <div style={{ ...pad, background: '#ffffff', color: '#140c2e' }}>
            <svg width={22 * sc} height={22 * sc} viewBox="0 0 24 24"><circle cx="12" cy="12" r="12" fill="#2AABEE" /><path d="M5.5 11.8l10.6-4.1c.5-.2.9.1.8.8l-1.8 8.5c-.1.6-.5.7-1 .5l-2.8-2-1.3 1.3c-.2.2-.3.3-.6.3l.2-2.9 5.2-4.7c.2-.2 0-.3-.3-.1l-6.4 4-2.8-.9c-.6-.2-.6-.6.2-.7z" fill="#fff" /></svg>
            Order on Telegram
          </div>
        </div>
      </div>
      {/* name: Facebook -> bottom-left of the phone-visible area (left of the profile picture); link image -> bottom-right */}
      <div style={{ position: 'absolute', ...(facebook ? { left: w * 0.235 } : { right: 50 * sc }), bottom: (facebook ? 70 : 34) * sc, display: 'flex', alignItems: 'center', gap: 12 * sc }}>
        {u
          // eslint-disable-next-line @next/next/no-img-element
          ? <img src={u} width={46 * sc} height={46 * sc} style={{ borderRadius: 12 * sc, objectFit: 'contain' }} alt="" />
          : <Mark size={46 * sc} theme={s.theme} />}
        <div style={{ fontWeight: 800, fontSize: 30 * sc, letterSpacing: -0.5 * sc, display: 'flex' }}>{s.brand_name}</div>
      </div>
    </div>,
    opts(w, h, extra),
  );
}

/**
 * 16:9 share card (1200x675) for links sent in chats (WhatsApp / Telegram previews):
 * headline + benefits on the left, an ad-account card (or, for the funnel, a "new lead" card) on the right.
 */
export function shareImage(s: Settings = getSettings(), line: 'agency' | 'funnel' = 'agency', extra?: Record<string, string>) {
  const W = 1200, H = 675;
  const k = kitFor(s.theme);
  const u = uploadedLogo(s);
  const funnel = line === 'funnel';
  const prices = [Number(s.price_account), s.web_orders_on === '1' ? Number(s.price_account_web) : NaN].filter(n => n > 0);
  const fromPrice = prices.length ? String(Math.min(...prices)) : s.price_account;
  const partner = s.partner_on === '1' ? (s.partner_text || '').trim() : '';
  const tick = (c: string, sz: number) => <svg width={sz} height={sz} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="3.4" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5" /></svg>;
  const head = funnel ? ['Landing page + funnel,', 'built for you.'] : ['Agency ad accounts', `live in ${s.delivery_time}.`];
  const points = funnel
    ? ['Landing page & lead form', 'Leads straight to Telegram', 'Meta tracking set up right', `$${s.price_funnel} / month`]
    : ['No spending limit', `From $${fromPrice}`, 'Fast top-ups, any time', 'Real people support'];
  const card = { background: 'rgba(255,255,255,0.97)', color: '#140c2e', borderRadius: 26, boxShadow: '0 30px 80px rgba(0,0,0,0.45)', display: 'flex', flexDirection: 'column' } as const;
  const row = (label: string, value: string, color = '#140c2e') => (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '13px 0', borderTop: '1.5px solid #eee9f7' }}>
      <span style={{ fontSize: 19, color: '#6b6385', fontWeight: 600 }}>{label}</span>
      <span style={{ fontSize: 20, fontWeight: 800, color }}>{value}</span>
    </div>
  );
  const bars = [38, 52, 46, 64, 58, 78, 92];
  return new ImageResponse(
    <div style={{ width: '100%', height: '100%', display: 'flex', position: 'relative', overflow: 'hidden', background: grad(k.bg, 125), fontFamily: 'Montserrat', color: '#fff' }}>
      <div style={{ position: 'absolute', left: -160, bottom: -260, width: 620, height: 620, borderRadius: 999, background: 'rgba(255,255,255,0.06)', display: 'flex' }} />
      <div style={{ position: 'absolute', right: -120, top: -200, width: 640, height: 640, borderRadius: 999, background: 'rgba(255,255,255,0.07)', display: 'flex' }} />
      {/* left: brand, headline, points, CTA */}
      <div style={{ display: 'flex', flexDirection: 'column', padding: '54px 0 0 64px', width: 650 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          {u
            // eslint-disable-next-line @next/next/no-img-element
            ? <img src={u} width={52} height={52} style={{ borderRadius: 14, objectFit: 'contain' }} alt="" />
            : <Mark size={52} theme={s.theme} />}
          <div style={{ fontWeight: 800, fontSize: 32, letterSpacing: -0.5, display: 'flex' }}>{s.brand_name}</div>
          {partner && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginLeft: 8, padding: '6px 14px 6px 7px', borderRadius: 999, background: 'rgba(255,255,255,0.14)', border: '1.5px solid rgba(255,255,255,0.3)', fontSize: 16, fontWeight: 600 }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: 22, height: 22, borderRadius: 999, background: '#0866ff' }}>{tick('#fff', 14)}</div>
              {partner}
            </div>
          )}
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', marginTop: 40, fontWeight: 800, fontSize: funnel ? 58 : 62, lineHeight: 1.05, letterSpacing: -2 }}>
          <span>{head[0]}</span>
          <span style={{ color: k.accent }}>{head[1]}</span>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14, marginTop: 34 }}>
          {points.map(p => (
            <div key={p} style={{ display: 'flex', alignItems: 'center', gap: 14, fontSize: 25, fontWeight: 600 }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: 34, height: 34, borderRadius: 999, background: 'rgba(255,255,255,0.18)' }}>{tick(k.accent, 20)}</div>
              {p}
            </div>
          ))}
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 38, alignSelf: 'flex-start', padding: '14px 26px', borderRadius: 999, background: '#ffffff', color: '#140c2e', fontSize: 23, fontWeight: 800 }}>
          <svg width={28} height={28} viewBox="0 0 24 24"><circle cx="12" cy="12" r="12" fill="#2AABEE" /><path d="M5.5 11.8l10.6-4.1c.5-.2.9.1.8.8l-1.8 8.5c-.1.6-.5.7-1 .5l-2.8-2-1.3 1.3c-.2.2-.3.3-.6.3l.2-2.9 5.2-4.7c.2-.2 0-.3-.3-.1l-6.4 4-2.8-.9c-.6-.2-.6-.6.2-.7z" fill="#fff" /></svg>
          {funnel ? 'Talk to your manager' : 'Chat with your agent'}
        </div>
      </div>
      {/* right: product card */}
      <div style={{ position: 'absolute', right: 58, top: 92, width: 430, display: 'flex', flexDirection: 'column' }}>
        {funnel ? (
          <div style={{ ...card, padding: '26px 28px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: 44, height: 44, borderRadius: 999, background: '#2AABEE', color: '#fff', fontSize: 22, fontWeight: 800 }}>R</div>
              <div style={{ display: 'flex', flexDirection: 'column' }}>
                <span style={{ fontSize: 21, fontWeight: 800 }}>New lead · Rahul S.</span>
                <span style={{ fontSize: 16, color: '#6b6385', fontWeight: 600 }}>from your landing page · just now</span>
              </div>
            </div>
            <div style={{ display: 'flex', marginTop: 18, padding: '14px 18px', borderRadius: 18, background: '#f2eefb', fontSize: 19, fontWeight: 600, color: '#3b3157' }}>Hi! What is the price?</div>
            {row('Landing page', 'Live', '#16a34a')}
            {row('Leads to', 'Your Telegram')}
            {row('Meta tracking', 'Connected', '#16a34a')}
          </div>
        ) : (
          <div style={{ ...card, padding: '26px 28px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ display: 'flex', flexDirection: 'column' }}>
                <span style={{ fontSize: 16, color: '#6b6385', fontWeight: 600 }}>Agency ad account</span>
                <span style={{ fontSize: 26, fontWeight: 800, letterSpacing: -0.5 }}>{s.brand_name} · USD</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 7, padding: '7px 14px', borderRadius: 999, background: '#dcfce7', color: '#15803d', fontSize: 17, fontWeight: 800 }}><span style={{ display: 'flex', width: 10, height: 10, borderRadius: 999, background: 'currentColor' }} />Active</div>
            </div>
            <div style={{ display: 'flex', alignItems: 'flex-end', gap: 10, height: 118, marginTop: 20, marginBottom: 16 }}>
              {bars.map((b, i) => <div key={i} style={{ display: 'flex', width: 40, height: `${b}%`, borderRadius: 9, background: i === bars.length - 1 ? grad(k.mark, 180) : '#e7e0f7' }} />)}
            </div>
            {row('Spending limit', 'No limit', '#16a34a')}
            {row('Top-up', 'Any time')}
            {row('Ready in', s.delivery_time)}
          </div>
        )}
        <div style={{ display: 'flex', alignSelf: 'flex-end', alignItems: 'center', gap: 10, marginTop: -22, marginRight: 22, padding: '12px 20px', borderRadius: 18, background: '#140c2e', border: '1.5px solid rgba(255,255,255,0.18)', boxShadow: '0 16px 40px rgba(0,0,0,0.4)', fontSize: 19, fontWeight: 700 }}>
          <div style={{ display: 'flex', width: 12, height: 12, borderRadius: 999, background: '#4ade80' }} />
          {funnel ? 'Live in 2–3 days' : 'Top-up done'}
        </div>
      </div>
    </div>,
    opts(W, H, extra),
  );
}

/** Cache-busting version for the image URLs: changes with the brand, the main theme, the headline or the uploaded logo. */
export function kitVersion(s: Settings = getSettings()) {
  const str = [s.brand_name, s.theme, s.headline, s.headline_accent, s.price_account, s.price_account_web, s.web_orders_on, s.delivery_time, s.logo_ver, s.logo_mode, s.partner_on, s.partner_text].join('|');
  let h = 0; for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) | 0;
  return (h >>> 0).toString(36);
}

/**
 * v140: per-line OFFER image (1280x720) sent WITH the welcome buttons (Telegram photo / WhatsApp image header).
 * Shows ONLY its own line: Agency (its price, fee, delivery), Premium (Premium price — never the Agency price), Funnel (per month).
 * Everything comes from the settings (offerFacts); vector ticks, no emoji in the image.
 */
export function offerImage(s: Settings = getSettings(), ln: OfferLine = 'agency', extra?: Record<string, string>) {
  const W = 1280, H = 720;
  const f = offerFacts(s, ln);
  const u = uploadedLogo(s);
  const check = (c: string, sz: number) => (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: sz, height: sz, borderRadius: 999, background: c }}>
      <svg width={sz * 0.62} height={sz * 0.62} viewBox="0 0 24 24" fill="none" stroke="#0c0a1d" strokeWidth="3.6" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5" /></svg>
    </div>
  );
  return new ImageResponse(
    <div style={{ width: '100%', height: '100%', display: 'flex', position: 'relative', overflow: 'hidden', background: '#0c0a1d', fontFamily: 'Montserrat', color: '#fff' }}>
      <div style={{ position: 'absolute', left: 0, top: 0, width: W, height: H, display: 'flex', backgroundImage: `radial-gradient(circle at 82% 8%, ${f.glow} 0%, rgba(12,10,29,0) 55%)` }} />
      <div style={{ position: 'absolute', left: 0, top: 0, width: W, height: H, display: 'flex', backgroundImage: 'radial-gradient(circle at 0% 100%, rgba(56,189,248,0.16) 0%, rgba(12,10,29,0) 45%)' }} />
      {/* left: brand, tag, headline, footer */}
      <div style={{ display: 'flex', flexDirection: 'column', padding: '64px 0 0 72px', width: 640 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          {u
            // eslint-disable-next-line @next/next/no-img-element
            ? <img src={u} width={64} height={64} style={{ borderRadius: 16, objectFit: 'contain' }} alt="" />
            : <Mark size={64} theme={s.theme} />}
          <div style={{ fontWeight: 800, fontSize: 32, letterSpacing: -0.5, display: 'flex' }}>{s.brand_name}</div>
        </div>
        <div style={{ display: 'flex', alignSelf: 'flex-start', marginTop: 40, padding: '9px 20px', borderRadius: 999, border: `2px solid ${f.accent}`, background: 'rgba(255,255,255,0.06)', color: f.accent, fontSize: 18, fontWeight: 800, letterSpacing: 2.4 }}>{f.tag}</div>
        <div style={{ display: 'flex', flexDirection: 'column', marginTop: 26, fontWeight: 800, fontSize: 66, lineHeight: 1.06, letterSpacing: -2.2 }}>
          <span>{f.head[0]}</span>
          <span style={{ color: f.accent }}>{f.head[1]}</span>
        </div>
      </div>
      <div style={{ position: 'absolute', left: 72, bottom: 58, display: 'flex', fontSize: 21, fontWeight: 600, color: 'rgba(255,255,255,0.72)' }}>Tap a button below · <span style={{ color: '#fff', marginLeft: 8, fontWeight: 800 }}>our team replies here</span></div>
      {/* right: price card */}
      <div style={{ position: 'absolute', right: 72, top: 186, width: 540, display: 'flex', flexDirection: 'column', padding: '34px 38px', borderRadius: 30, background: 'rgba(255,255,255,0.07)', border: '1.5px solid rgba(255,255,255,0.16)', boxShadow: `0 30px 90px ${f.glow}` }}>
        <div style={{ display: 'flex', alignItems: 'flex-end', gap: 14 }}>
          <span style={{ fontSize: 96, fontWeight: 800, letterSpacing: -3, lineHeight: 1, color: f.accent }}>{f.price || ' '}</span>
          <span style={{ fontSize: 24, fontWeight: 600, color: 'rgba(255,255,255,0.75)', marginBottom: 10 }}>{f.price ? f.per : ''}</span>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 17, marginTop: 28 }}>
          {f.bullets.map(b => (
            <div key={b} style={{ display: 'flex', alignItems: 'center', gap: 14, fontSize: 23, fontWeight: 600 }}>{check(f.accent, 30)}<span>{b}</span></div>
          ))}
        </div>
      </div>
    </div>,
    { ...opts(W, H, extra), headers: { 'Content-Type': 'image/png', 'Cache-Control': 'public, max-age=600', ...(extra || {}) } },
  );
}

/**
 * v153: the small notification icon (top bar of the phone). Android shows only the shape, in white,
 * so this is a white silhouette of the logo on a transparent background.
 */
export async function statIconPng(s: Settings = getSettings(), size = 96): Promise<Buffer> {
  const sharp = (await import('sharp')).default;
  const l = usesUploadedLogo(s) ? readLogo() : null;
  if (l) {
    try {
      const { data, info } = await sharp(l.buf, { density: 300 }).resize(512, 512, { fit: 'contain', background: { r: 255, g: 255, b: 255, alpha: 0 } }).ensureAlpha().raw().toBuffer({ resolveWithObject: true });
      // the logo's background colour = the corners; every pixel clearly different from it is the shape
      const px = (i: number) => [data[i], data[i + 1], data[i + 2], data[i + 3]];
      const c = px(0);
      const out = Buffer.alloc(info.width * info.height * 4);
      for (let i = 0; i < data.length; i += 4) {
        const [r, g, b, a] = px(i);
        const diff = Math.abs(r - c[0]) + Math.abs(g - c[1]) + Math.abs(b - c[2]);
        const on = a > 100 && (c[3] < 100 ? true : diff > 90);
        out[i] = out[i + 1] = out[i + 2] = 255; out[i + 3] = on ? 255 : 0;
      }
      const inner = Math.round(size * 0.84);
      const shape = await sharp(out, { raw: { width: info.width, height: info.height, channels: 4 } }).trim({ threshold: 1 }).resize(inner, inner, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } }).png().toBuffer();
      return await sharp({ create: { width: size, height: size, channels: 4, background: { r: 0, g: 0, b: 0, alpha: 0 } } }).composite([{ input: shape, gravity: 'center' }]).png().toBuffer();
    } catch { /* below: our mark */ }
  }
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 100 100"><path d="M50 12 L84 46 H63 L50 33 L37 46 H16 Z" fill="#fff"/><rect x="21" y="55" width="13" height="29" rx="3" fill="#fff"/><rect x="43.5" y="47" width="13" height="37" rx="3" fill="#fff"/><rect x="66" y="55" width="13" height="29" rx="3" fill="#fff"/></svg>`;
  return sharp(Buffer.from(svg)).png().toBuffer();
}
