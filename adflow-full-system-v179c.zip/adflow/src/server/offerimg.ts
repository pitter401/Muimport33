// v140: the per-line offer image (Agency / Premium / Funnel) that goes WITH the welcome button message:
//   Telegram: one sendPhoto with caption + inline keyboard · WhatsApp (WATI Pro): the buttons message with an image header
//   · normal WhatsApp: the image as a separate session message before the plain welcome (inside the 24-hour window, no template).
// ONE resolver for both apps: offerLine() → offerImageUrl(). Lines never cross: a line without its own image gets NO image
// (never another line's). A Premium person always gets the Premium image, even on an Agency path.
import { one, run } from './db';
import { tierFor, bizOf, type Settings } from './settings';
import { publicUrl } from './email';
import { tg, type TgResult } from './telegram';

export type OfferLine = 'agency' | 'premium' | 'funnel';
export const OFFER_LINES: OfferLine[] = ['agency', 'premium', 'funnel'];
type LeadLike = { service?: string | null; line?: string | null; tier?: string | null };

/** THE line → image line resolver (Telegram and WhatsApp).
 *  A line name or a chat (service / line / tier). Funnel stays Funnel; an Agency path of a Premium person → Premium. */
export function offerLine(x: OfferLine | string | LeadLike | null | undefined, premiumPerson = false): OfferLine {
  if (typeof x === 'string') {
    if (x === 'funnel') return 'funnel';
    if (x === 'premium') return 'premium';
    return premiumPerson ? 'premium' : 'agency';
  }
  if (x && bizOf(x) === 'funnel') return 'funnel';
  if ((x && x.tier === 'premium') || premiumPerson) return 'premium';
  return 'agency';
}

const usd = (v: unknown) => { const n = Number(String(v ?? '').replace(/[^\d.]/g, '')); return Number.isFinite(n) && n > 0 ? '$' + (Number.isInteger(n) ? String(n) : n.toFixed(2)) : ''; };
const pct = (v: unknown, d = '3') => `${String(v ?? '').replace(/%/g, '').trim() || d}%`;

/** What the image (and the short welcome caption) says for one line — only that line's own settings. */
export function offerFacts(s: Settings, ln: OfferLine) {
  if (ln === 'premium') {
    const p = tierFor(s, 'premium');
    const delivery = String(p.delivery_time || s.delivery_time || '').trim();
    return {
      line: ln, tag: 'PREMIUM AD ACCOUNT', title: 'Premium Account', head: ['Premium accounts', 'for serious scale'], price: usd(p.price_account), per: 'per account',
      fee: pct(p.topup_comm_pct), delivery,
      bullets: ['Aged profile + verified BM', 'No spending limit from day one', 'No 18% GST on ad spend', delivery ? `Ready in ${delivery}` : 'Priority support'],
      accent: '#fcd34d', glow: 'rgba(234,120,40,0.42)',
    };
  }
  if (ln === 'funnel') {
    return {
      line: ln, tag: 'LANDING PAGE + FUNNEL', title: 'Landing Page + Funnel', head: ['Leads straight', 'to your phone'], price: usd(s.price_funnel), per: 'per month',
      fee: '', delivery: '2 to 3 days',
      bullets: ['Fast landing page, built for you', 'Meta ads setup with tracking', 'Leads sent to your WhatsApp', 'Hosting and support included'],
      accent: '#c4b5fd', glow: 'rgba(168,85,247,0.45)',
    };
  }
  const delivery = String(s.delivery_time || '').trim();
  return {
    line: ln, tag: 'AGENCY AD ACCOUNT', title: 'Agency Account', head: ['Run Meta ads', 'with no limits'], price: usd(s.price_account), per: 'per account',
    fee: pct(s.topup_comm_pct), delivery,
    bullets: ['No spending limit from day one', 'No 18% GST on ad spend', delivery ? `In your Business Manager in ${delivery}` : 'Shared to your Business Manager', `Top-up fee only ${pct(s.topup_comm_pct)}`],
    accent: '#5eead4', glow: 'rgba(124,58,237,0.5)',
  };
}

/** Cache buster: changes when anything shown on that line's image changes (price, fee, delivery, brand, logo). */
export function offerVersion(s: Settings, ln: OfferLine) {
  const str = JSON.stringify([offerFacts(s, ln), s.brand_name, s.logo_ver, s.logo_mode, 'v140b']);
  let h = 0; for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) | 0;
  return (h >>> 0).toString(36);
}
export const offerImagePath = (s: Settings, ln: OfferLine) => `/offer-image/${ln}.png?v=${offerVersion(s, ln)}`;
/** The admin's own image for the line (Settings → Channel ads: chan_img_<line>, an https link), else ''. */
export const ownOfferImage = (s: Settings, ln: OfferLine) => { const u = String((s as Record<string, string>)[`chan_img_${ln}`] || '').trim(); return /^https:\/\/\S+$/.test(u) ? u : ''; };
/** Public https URL of the line's image ('' = this line has no image → send text only, NEVER another line's image). */
export function offerImageUrl(s: Settings, ln: OfferLine): string {
  const own = ownOfferImage(s, ln);
  if (own) return own;
  let base = publicUrl();
  if (!base) return '';
  if (!/\/\/(localhost|127\.)/.test(base)) base = base.replace(/^http:\/\//, 'https://'); // WhatsApp / Telegram load https only
  return base + offerImagePath(s, ln);
}

/* ---------- switches ---------- */
/** Settings → Telegram channel → "Send the offer image with buttons" (default ON). */
export const tgBtnImgOn = (s: Settings) => s.chan_btn_img !== '0';
/** Settings → WATI Pro buttons → "Send the offer image with buttons" (default ON). */
export const waBtnImgOn = (s: Settings) => s.wati_btn_img !== '0';
/** The image also on the See pricing / What's included replies and the WhatsApp button auto-replies (default OFF). */
export const imgOnReplies = (s: Settings) => s.img_on_replies === '1';
/** Normal (non-Pro) WhatsApp: the image as its own message before the plain welcome (default ON). */
export const waPlainImgOn = (s: Settings) => s.wati_plain_img !== '0';

/* ---------- the short welcome caption (≤ 300 characters) ---------- */
const escHtml = (t: string) => t.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
/** 3–4 short lines: product + price (bold, no emoji), one fact line, the delivery line (⏱), one clear next step.
 *  mode tg → Telegram HTML (<b>), wa → WhatsApp (*bold*). Only this line's facts. */
export function welcomeCaption(s: Settings, ln: OfferLine, mode: 'tg' | 'wa' = 'tg'): string {
  const f = offerFacts(s, ln);
  const brand = String(s.brand_name || '').trim();
  const name = `${brand ? brand + ' ' : ''}${f.title}`;
  const bold = mode === 'tg' ? `<b>${escHtml(name)}</b>` : `*${name}*`;
  const price = f.price ? (ln === 'funnel' ? `${f.price}/month` : `${f.price}, ${f.fee} top-up fee`) : '';
  const fact = ln === 'premium' ? 'Aged profile and verified BM, no spending limit.' : ln === 'funnel' ? 'Landing page, Meta ads tracking, leads to your WhatsApp.' : 'No spending limit, no 18% GST on ad spend.';
  const del = ln === 'funnel' ? '⏱ Setup takes 2 to 3 days.' : f.delivery ? `⏱ ${ln === 'premium' ? 'Ready' : 'In your Business Manager'} in ${f.delivery}.` : '';
  const next = ln === 'agency' ? 'Tap See pricing to compare plans.' : ln === 'premium' ? "Tap What's included to see everything you get." : 'Tap See pricing for the full details.';
  const l1 = price ? `${bold} — ${price}` : bold;
  const t = [l1, mode === 'tg' ? escHtml(fact) : fact, mode === 'tg' ? escHtml(del) : del, next].filter(Boolean).join('\n');
  return t.slice(0, 300);
}

/* ---------- Telegram: photo + caption + keyboard, file_id cached ---------- */
export function cachedFileId(url: string) { return one<{ file_id: string }>('SELECT file_id FROM tg_file_cache WHERE url=?', url)?.file_id || null; }
function saveFileId(url: string, r: TgResult) {
  const ph = r.result?.photo;
  const id = Array.isArray(ph) && ph.length ? ph[ph.length - 1]?.file_id : null;
  if (id) run('INSERT INTO tg_file_cache(url, file_id, at) VALUES(?,?,?) ON CONFLICT(url) DO UPDATE SET file_id=excluded.file_id, at=excluded.at', url, String(id), Date.now());
}
/** One photo message: caption + buttons. Caption over 1024 → the photo with a short caption, then the text with the buttons.
 *  First send uploads by URL and caches Telegram's file_id; later sends reuse it (a refused file_id → dropped, URL again).
 *  Image missing / refused → the plain text with the buttons (never lost). Returns the last result + img: whether the image went. */
export async function sendTgPhoto(s: Settings, chatId: string | number, url: string, o: { caption: string; parse_mode?: 'HTML'; markup?: unknown; short?: string; fallback: string; fallbackParse?: 'HTML' }): Promise<TgResult & { img: boolean; err?: string }> {
  let err = '';
  if (url) {
    const long = o.caption.length > 1024;
    const cap = long ? (o.short || '').slice(0, 1024) : o.caption;
    const body = (photo: string) => ({ chat_id: chatId, photo, ...(cap ? { caption: cap } : {}), ...(!long && o.parse_mode ? { parse_mode: o.parse_mode } : {}), ...(!long && o.markup ? { reply_markup: o.markup } : {}) });
    const fid = cachedFileId(url);
    let r: TgResult | null = null;
    if (fid) {
      r = await tg(s, 'sendPhoto', body(fid)).catch(e => ({ ok: false, description: String(e) }));
      if (!r.ok && /file|wrong|identifier|photo/i.test(r.description || '')) { run('DELETE FROM tg_file_cache WHERE url=?', url); r = null; }
    }
    if (!r) { r = await tg(s, 'sendPhoto', body(url)).catch(e => ({ ok: false, description: String(e) })); if (r.ok) saveFileId(url, r); }
    if (r.ok) {
      if (!long) return { ...r, img: true };
      const t = await tg(s, 'sendMessage', { chat_id: chatId, text: o.fallback, ...(o.fallbackParse ? { parse_mode: o.fallbackParse } : {}), ...(o.markup ? { reply_markup: o.markup } : {}), disable_web_page_preview: true });
      return { ...t, img: true };
    }
    err = 'photo: ' + (r.description || '');
  }
  let t = await tg(s, 'sendMessage', { chat_id: chatId, text: o.fallback, ...(o.fallbackParse ? { parse_mode: o.fallbackParse } : {}), ...(o.markup ? { reply_markup: o.markup } : {}), disable_web_page_preview: true });
  if (!t.ok && /button|url|markup|reply_markup|entities|parse/i.test(t.description || '')) {
    err += ' · buttons: ' + (t.description || '');
    t = await tg(s, 'sendMessage', { chat_id: chatId, text: o.fallback.replace(/<\/?b>/g, ''), disable_web_page_preview: true });
  }
  return { ...t, img: false, err: err + (t.ok ? '' : ' · ' + (t.description || '')) };
}

/** The line's image as bytes (normal WhatsApp sends it as a file). Own https image → downloaded; built-in → rendered here. */
const pngCache = new Map<string, { buf: Buffer; type: string }>();
export async function offerImageBytes(s: Settings, ln: OfferLine): Promise<{ buf: Buffer; type: string } | null> {
  const url = offerImageUrl(s, ln);
  if (!url) return null;
  const hit = pngCache.get(url);
  if (hit) return hit;
  let out: { buf: Buffer; type: string } | null = null;
  try {
    if (ownOfferImage(s, ln)) {
      const r = await fetch(url, { signal: AbortSignal.timeout(15000) });
      const type = (r.headers.get('content-type') || '').split(';')[0];
      if (r.ok && /^image\/(jpeg|png)$/.test(type)) out = { buf: Buffer.from(await r.arrayBuffer()), type };
    } else {
      const { offerImage } = await import('./brandkit');
      const r = offerImage(s, ln);
      out = { buf: Buffer.from(await r.arrayBuffer()), type: 'image/png' };
    }
  } catch { out = null; }
  if (out && out.buf.length > 100) { if (pngCache.size > 12) pngCache.clear(); pngCache.set(url, out); return out; }
  return null;
}
