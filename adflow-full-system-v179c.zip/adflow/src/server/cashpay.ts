// v141: cash / offline payouts — the manager (agent app) or the admin writes down money already paid to an agent (cash, UPI…).
// They live in the same payouts table as payout requests (status 'paid', kind 'cash'), so the wallet balance, "available to
// withdraw" and the payout request limit all use them. Earned commission, the leaderboard and Home profit do not change.
import { one, all, run } from './db';
import { getSettings } from './settings';
import { agentLog } from './crm';
import { now, num, money, HttpError } from './util';

export type Actor = { role: 'admin' | 'manager'; id: number | null; name: string };
const DAY = 86400000;

/** amount typed in INR or USD → USD (INR through the app's INR rate setting). */
export function toUsd(amount: number, cur: 'INR' | 'USD') {
  if (cur === 'USD') return money(amount);
  const rate = num(getSettings().inr_rate);
  if (!(rate > 0)) throw new HttpError(400, 'Set the INR rate first (Settings → Prices → INR rate) to record INR payouts');
  return money(amount / rate);
}

export function addCashPayout(b: Record<string, unknown>, by: Actor) {
  const a = one<{ id: number; name: string; role: string | null; deleted: number }>('SELECT id, name, role, deleted FROM agents WHERE id=?', num(b.agent_id));
  if (!a || a.deleted) throw new HttpError(404, 'Agent not found');
  if (a.role === 'manager') throw new HttpError(400, 'Pick an agent (not the manager)');
  const cur = String(b.cur || 'INR').toUpperCase() === 'USD' ? 'USD' : 'INR';
  const amt = Number(b.amount);
  if (!(amt > 0) || amt > 10_000_000) throw new HttpError(400, 'Enter the amount paid');
  const usd = toUsd(amt, cur);
  if (!(usd > 0)) throw new HttpError(400, 'Amount is too small');
  const d = String(b.date || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
  const tz = num(getSettings().tz_offset_min, 330) * 60000;
  const payDate = d ? Date.UTC(+d[1], +d[2] - 1, +d[3], 12) - tz : now();
  if (payDate > now() + DAY) throw new HttpError(400, 'The date can’t be in the future');
  const note = String(b.note || '').trim().slice(0, 120) || 'Cash';
  const r = one<{ id: number }>("INSERT INTO payouts(agent_id, amount, method, details, status, note, created_at, done_at, kind, cur, orig_amount, by_name, by_role, by_id, pay_date) VALUES(?,?,?,?,'paid',?,?,?,'cash',?,?,?,?,?,?) RETURNING id",
    a.id, usd, 'cash', note, note, now(), now(), cur, money(amt), by.name, by.role, by.id, payDate)!;
  agentLog(a.id, 'payout_add', `Cash payout ${fmtAmt(cur, amt)} (${'$' + usd}) recorded by ${who(by)} · ${note}`);
  return { ok: true, id: r.id, usd };
}

export function delCashPayout(id: unknown, by: Actor) {
  const p = one<{ id: number; agent_id: number; created_at: number; cur: string; orig_amount: number; amount: number; note: string }>("SELECT * FROM payouts WHERE id=? AND kind='cash'", num(id));
  if (!p) throw new HttpError(404, 'Payout not found');
  if (by.role !== 'admin' && now() - p.created_at > DAY) throw new HttpError(403, 'Only the admin can delete a payout after 24 hours');
  run('DELETE FROM payouts WHERE id=?', p.id);
  agentLog(p.agent_id, 'payout_del', `Cash payout ${fmtAmt(p.cur as 'INR', p.orig_amount)} ($${p.amount}) deleted by ${who(by)}`);
  return { ok: true };
}

/** Payouts per agent (cash ones + paid requests) with this month's and lifetime totals (USD; INR typed shown too). */
export function cashPayouts(agentId?: number | null) {
  const s = getSettings();
  const tz = num(s.tz_offset_min, 330) * 60000;
  const d = new Date(now() + tz), monthStart = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1) - tz;
  const agents = all<{ id: number; name: string }>("SELECT id, name FROM agents WHERE deleted=0 AND COALESCE(role,'agent')!='manager' ORDER BY name");
  const rows = all<any>(`SELECT p.id, p.agent_id, a.name agent_name, p.amount, p.cur, p.orig_amount, p.note, p.by_name, p.by_role, p.kind, COALESCE(p.pay_date, p.done_at, p.created_at) paid_at, p.created_at, p.method
    FROM payouts p LEFT JOIN agents a ON a.id=p.agent_id WHERE p.status='paid' ${agentId ? 'AND p.agent_id=' + Number(agentId) : ''} ORDER BY COALESCE(p.pay_date, p.done_at, p.created_at) DESC, p.id DESC LIMIT 500`);
  // v166: month / lifetime totals by SQL over every paid payout (the list above is capped at 500)
  const T = (from: number) => new Map(all<{ a: number; usd: number; inr: number; n: number }>(`SELECT agent_id a, COALESCE(SUM(amount),0) usd, COALESCE(SUM(CASE WHEN cur='INR' THEN orig_amount ELSE 0 END),0) inr, COUNT(*) n FROM payouts
    WHERE status='paid' AND COALESCE(pay_date, done_at, created_at)>=? ${agentId ? 'AND agent_id=' + Number(agentId) : ''} GROUP BY agent_id`, from).map(r => [r.a, { usd: money(r.usd), inr: money(r.inr), n: r.n }]));
  const M = T(monthStart), L = T(-1e15), zero = { usd: 0, inr: 0, n: 0 };
  const per = agents.filter(a => !agentId || a.id === agentId).map(a => ({ id: a.id, name: a.name, month: M.get(a.id) || zero, life: L.get(a.id) || zero }));
  return { agents: per, rows, inr_rate: num(s.inr_rate) || null, truncated: rows.length >= 500 };
}

const who = (by: Actor) => by.role === 'manager' ? `${by.name} (manager)` : 'Admin';
export const fmtAmt = (cur: 'INR' | 'USD' | string, v: number) => (cur === 'INR' ? '₹' + Math.round(v).toLocaleString('en-IN') : '$' + money(v));
