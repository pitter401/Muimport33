/**
 * Crypto payment links made by agents from a Telegram chat (agent app → "💳 Payment link").
 *  - Ad account: Telegram price × qty (e.g. $23)       - Funnel: Telegram funnel price
 *  - Top-up: amount + top-up fee % (e.g. $100 → $103)
 * The client opens {site}/pay/PL-XXXX, picks a coin and pays (NOWPayments address + QR inside our page).
 * When NOWPayments confirms: the sale / top-up is recorded for the agent (Meta Purchase for sales),
 * a task goes to the manager, the agent is notified and the client gets a "payment received" message.
 */
import crypto from 'crypto';
import { one, all, run, db } from './db';
import { getSettings, tierFor, priceFor, type Settings } from './settings';
import { now, num, money, HttpError, HOUR } from './util';
import { publicUrl } from './email';
import { npCreatePayment, npPaymentStatus, enabledCoins, NP_PAID, coinList, coinName } from './nowpay';
import { addMsg, agentById, notifyAgent, displayName, leadById, recordSale, addTopup, topupFee, sendToLead, type Lead } from './crm';
import { createTask, cryptoInfo, managers, saveLeadAccounts, staleNews } from './shop';
import { pushTo } from './push';
import { requestFromPayLink } from './meta';
import { WA_ITEMS, waPrice, addWaSale, chatCatalog, checkUnitPrice } from './wasales';

export type PayLink = {
  id: number; code: string; lead_id: number; agent_id: number; kind: 'account' | 'funnel' | 'topup' | 'custom'; qty: number; bm_id: string | null; act_id: string | null;
  amount: number; fee: number; total: number; label: string; status: string; np_payment_id: string | null; np_status: string | null; pay_currency: string | null;
  pay_address: string | null; pay_amount: number | null; pay_extra: string | null; np_expires: number | null; np_checked: number | null; paid_at: number | null; created_at: number;
  tier?: string | null; share_mode?: string | null; client_email?: string | null; offer_free?: number | null;
  wa?: number | null; item?: string | null; cust_name?: string | null; cust_phone?: string | null; wa_topup?: number | null; wa_items?: string | null; wa_disc?: number | null;
  paid_usd?: number | null; short_at?: number | null; ok_by?: string | null;
  list_price?: number | null; ptier?: string | null; parts?: string | null; parent_id?: number | null;
};

/* v134: short payments. Paid less than the link → NOT confirmed (owner's rule: only a full payment confirms).
   The client is told what came and what is left and pays the rest on the same link; it confirms when the rest arrives. */
export const paidOf = (l: { paid_usd?: number | null }) => money(num(l.paid_usd));
export const dueOf = (l: { total: number; paid_usd?: number | null }) => money(Math.max(0, l.total - paidOf(l)));
const enough = (l: { total: number }, paid: number) => paid + 0.015 >= l.total; // only rounding, never a real shortfall

export const payLinksOn = (s: Settings = getSettings()) => s.agent_paylinks_on === '1' && !!s.np_api_key && enabledCoins(s).length > 0;
const usd = (n: number) => '$' + money(n).toFixed(2).replace(/\.00$/, '');
export const payUrl = (code: string) => `${publicUrl()}/pay/${code}`;
const byCode = (c: unknown) => one<PayLink>('SELECT * FROM pay_links WHERE code=?', String(c || '').trim().toUpperCase());

/** Agent creates a link for the client in this chat. Prices come from Settings (agents can't change them). */
export function createPayLink(lead: Lead, agentId: number, b: Record<string, unknown>, opt: { noMin?: boolean; free?: boolean; part?: number } = {}): { ok: true; link: ReturnType<typeof pubLink>; url: string; message: string } {
  // v159: several products in one link (e.g. Facebook account + agency ad account)
  if (!opt.part && Array.isArray(b.items)) {
    const its = (b.items as Record<string, unknown>[]).filter(x => x && typeof x === 'object');
    if (its.length > 1) return createBundle(lead, agentId, its, opt);
    if (its.length === 1) b = { ...its[0], lead_id: b.lead_id };
  }
  // v144: b.item = a product of this chat's catalog (chatCatalog: Agency / Premium normal + full access, Facebook account + BM, funnel)
  const s00 = getSettings();
  const cat = b.item != null && b.item !== '' ? chatCatalog(s00, lead).find(x => x.k === b.item) : undefined;
  if (b.item != null && b.item !== '' && !cat) throw new HttpError(400, lead.tier === 'premium' && ['account', 'full'].includes(String(b.item)) ? 'This is a Premium chat: only Premium accounts are sold here.' : 'Choose the product');
  // Premium chats: Premium price + fee — unless the agent picked the normal ad account (std) for this customer
  const std = cat ? cat.tier === 'agency' : b.std === true || b.std === 1 || b.std === '1';
  // retargeting offer chats: the offer price (and the Premium first top-up offer)
  const s = std && b.kind !== 'topup' ? s00 : priceFor(s00, lead);
  if (!payLinksOn(s)) throw new HttpError(400, 'Crypto payment links are off. Admin → Settings → Website orders → NOWPayments.');
  const kind = cat ? cat.kind : b.kind === 'topup' ? 'topup' : b.kind === 'funnel' ? 'funnel' : b.kind === 'custom' ? 'custom' : 'account';
  const bm = String(b.bm_id || '').replace(/\D/g, '');
  const act = String(b.act_id || '').trim().replace(/^act_/i, '').replace(/\D/g, '');
  if (bm && (bm.length < 8 || bm.length > 20)) throw new HttpError(400, 'Business Manager ID looks wrong (numbers only)');
  let qty = 1, amount = 0, fee = 0, label = '', offerFree = 0, listP: number | null = null;
  const full = cat ? cat.full : kind === 'account' && (b.full === true || b.full === 1 || b.full === '1') ? 1 : 0; // full access: they top up themselves
  // v144: the price per account / month can be changed (special price); agents: at most max_discount_pct below the normal price
  const unitOf = (list: number, what: string) => {
    if (b.unit_price == null || String(b.unit_price).trim() === '') return list;
    const u = checkUnitPrice(s00, b.unit_price, list, !!opt.free, what);
    if (Math.abs(u - list) > 0.004) listP = list;
    return u;
  };
  const pl = (n: number, w: string) => `${n} ${w}${n > 1 ? 's' : ''}`;
  if (cat) {
    qty = Math.floor(num(b.qty, 1));
    if (cat.kind === 'funnel') qty = 1;
    if (!(qty >= 1 && qty <= 50)) throw new HttpError(400, 'Choose 1 to 50');
    amount = money(unitOf(cat.price, cat.kind === 'funnel' ? 'month' : cat.kind === 'custom' ? 'item' : 'account') * qty);
    label = cat.k === 'account' ? pl(qty, 'agency ad account') : cat.k === 'full' ? pl(qty, 'full access ad account') : cat.k === 'premium' ? pl(qty, 'Premium ad account')
      : cat.k === 'premium_full' ? pl(qty, 'full access Premium ad account') : cat.k === 'fb_old' ? `${qty > 1 ? qty + ' × ' : ''}Facebook account + Business Manager` : 'Landing page + funnel (1 month)';
  } else if (kind === 'account') {
    qty = Math.floor(num(b.qty, 1));
    if (!(qty >= 1 && qty <= 50)) throw new HttpError(400, 'Choose 1 to 50 accounts');
    amount = money(unitOf(num(full ? s.price_account_full : s.price_account), 'account') * qty);
    label = full ? `${qty} full access${lead.tier === 'premium' && !std ? ' Premium' : ''} ad account${qty > 1 ? 's' : ''}` : `${qty} agency ad account${qty > 1 ? 's' : ''}`;
  } else if (kind === 'funnel') {
    amount = money(unitOf(num(s.price_funnel), 'month'));
    label = 'Landing page + funnel (1 month)';
  } else if (kind === 'custom') {
    // any amount for anything else (e.g. a full access ad account) — no fee, recorded as a sale when paid
    amount = money(b.amount);
    if (!(amount >= 1)) throw new HttpError(400, 'Enter the amount');
    if (amount > 50000) throw new HttpError(400, 'Maximum $50,000 per link');
    label = String(b.label || '').replace(/\s+/g, ' ').trim().slice(0, 80) || 'Payment';
  } else {
    amount = money(b.amount);
    const min = opt.noMin ? 1 : money(s.topup_min || 30); // v134: the manager may go below the minimum
    if (!(amount >= min)) throw new HttpError(400, `Minimum top-up is ${usd(min)}`);
    if (amount > 50000) throw new HttpError(400, 'Maximum $50,000 per link');
    if (act && act.length < 6) throw new HttpError(400, 'Ad account ID looks wrong');
    const tf = topupFee(lead, amount);
    fee = tf.fee; offerFree = tf.free;
    label = `Ad account top-up ${usd(amount)}${act ? ' → act_' + act : ''}`;
  }
  if (!(amount > 0)) throw new HttpError(400, 'Price is not set. Admin → Settings → Prices.');
  const total = money(amount + fee);
  // ad account links: which type (verified / in review / unverified) and how it is shared (client BM ID or email invite)
  const shareMode = kind === 'account' && b.share_mode === 'email' && getSettings().meta_email_invites === '1' ? 'email' : kind === 'account' ? 'bm' : null;
  // email invites: the manager picks the type, so the agent's choice is not kept
  const tier = kind === 'account' && shareMode !== 'email' && ['verified', 'review', 'unverified'].includes(String(b.tier)) ? String(b.tier) : null;
  const clientEmail = shareMode === 'email' ? String(b.client_email || '').trim().toLowerCase().slice(0, 160) : '';
  if (clientEmail && !/^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(clientEmail)) throw new HttpError(400, 'Client email looks wrong');
  const recent = one<{ n: number }>('SELECT COUNT(*) n FROM pay_links WHERE lead_id=? AND created_at>? AND parent_id IS NULL', lead.id, now() - HOUR)!.n; // v166
  if (!opt.part && recent >= 10) throw new HttpError(429, 'Too many links for this chat in the last hour');
  const code = 'PL-' + crypto.randomBytes(5).toString('hex').toUpperCase();
  // v144: product tier (premium / agency) + catalog item, so the paid link is recorded as exactly this product
  const ptier = cat ? cat.tier : kind === 'account' && lead.tier === 'premium' ? (std ? 'agency' : 'premium') : null;
  run(`INSERT INTO pay_links(full, code, lead_id, agent_id, kind, qty, bm_id, act_id, amount, fee, total, label, status, created_at, tier, share_mode, client_email, offer_free, item, ptier, list_price, parent_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    full, code, lead.id, agentId, kind, qty, bm || null, act || null, amount, fee, total, label, opt.part ? 'part' : 'new', now(), tier, shareMode, clientEmail || null, offerFree || null, cat ? cat.k : null, ptier, listP, opt.part || null);
  const link = byCode(code)!;
  if (kind === 'topup' && act) saveLeadAccounts(lead.id, [act], { source: 'topup' });
  const url = payUrl(code);
  if (opt.part) return { ok: true, link: pubLink(link), url, message: '' };
  addMsg(lead, { dir: 'sys', sender: 'system', agent_id: agentId, text: `💳 Payment link ${code}: ${label} · ${usd(total)}${fee ? ` (incl. ${usd(fee)} fee)` : ''}${listP != null ? ` · Special price (${usd(amount / qty)} instead of ${usd(listP)})` : ''}\n${url}` });
  return { ok: true, link: pubLink(link), url, message: clientMessage(s, link, url) };
}

/** v159: one link, several products. Each product is its own row (status 'part') so that, when paid, each is recorded / shared
 *  exactly like its own paid link (sale + commission, ad account share, top-up, manager task). The client pays the sum once. */
function createBundle(lead: Lead, agentId: number, items: Record<string, unknown>[], opt: { noMin?: boolean; free?: boolean }) {
  const s = getSettings();
  if (!payLinksOn(s)) throw new HttpError(400, 'Crypto payment links are off. Admin → Settings → Website orders → NOWPayments.');
  if (items.length > 10) throw new HttpError(400, 'Maximum 10 products in one link');
  const recent = one<{ n: number }>('SELECT COUNT(*) n FROM pay_links WHERE lead_id=? AND created_at>? AND parent_id IS NULL', lead.id, now() - HOUR)!.n; // v166
  if (recent >= 10) throw new HttpError(429, 'Too many links for this chat in the last hour');
  const code = 'PL-' + crypto.randomBytes(5).toString('hex').toUpperCase();
  let parent!: PayLink;
  const kids: PayLink[] = [];
  db().transaction(() => {
    const r = run("INSERT INTO pay_links(code, lead_id, agent_id, kind, qty, amount, fee, total, label, status, created_at) VALUES(?,?,?,'custom',1,0,0,0,'','new',?)", code, lead.id, agentId, now());
    const pid = Number(r.lastInsertRowid);
    items.forEach((it, i) => {
      try { const c = createPayLink(lead, agentId, it, { ...opt, part: pid }); kids.push(byCode(c.link.code)!); }
      catch (e) { throw new HttpError((e as HttpError).status || 400, `Item ${i + 1}: ${(e as Error).message}`); }
    });
    const amount = money(kids.reduce((x, k) => x + k.amount, 0)), fee = money(kids.reduce((x, k) => x + k.fee, 0)), total = money(kids.reduce((x, k) => x + k.total, 0));
    const label = kids.map(k => k.label).join(' + ').slice(0, 300);
    run('UPDATE pay_links SET amount=?, fee=?, total=?, label=?, parts=? WHERE id=?', amount, fee, total, label, JSON.stringify(kids.map(k => k.id)), pid);
    parent = one<PayLink>('SELECT * FROM pay_links WHERE id=?', pid)!;
  })();
  const url = payUrl(code);
  addMsg(lead, { dir: 'sys', sender: 'system', agent_id: agentId, text: `💳 Payment link ${code} (${kids.length} items): ${kids.map(k => `${k.label} ${usd(k.total)}`).join(' + ')} = ${usd(parent.total)}\n${url}` });
  return { ok: true as const, link: pubLink(parent), url, message: clientMessage(s, parent, url) };
}
export const partsOf = (l: { id: number; parts?: string | null }) => l.parts ? all<PayLink>("SELECT * FROM pay_links WHERE parent_id=? ORDER BY id", l.id) : [];

/* ---------------- v122/v123: WhatsApp payment links (no Telegram chat) ---------------- */
/** Agent app → menu → "WhatsApp payment link": one crypto link for a WhatsApp customer with one or more services,
 *  an optional top-up (+ our top-up fee) and an optional discount. When paid: each service is saved as a WhatsApp sale
 *  (revenue, no commission, NO Meta event), the top-up goes to top-ups (its fee is our income) and the manager gets a task. */
type WaLine = { k: string; label: string; qty: number; amount: number };
const waLines = (l: PayLink): WaLine[] => { try { return JSON.parse(String((l as { wa_items?: string | null }).wa_items || '[]')); } catch { return []; } };
export function createWaPayLink(agent: { id: number; name: string }, b: Record<string, unknown>) {
  const s = getSettings();
  if (!payLinksOn(s)) throw new HttpError(400, 'Crypto payment links are off. Admin → Settings → Website orders → NOWPayments.');
  // services: b.items = [{ item, qty, amount, label }] (older app: one b.item)
  const raw = (Array.isArray(b.items) ? b.items : b.item && b.item !== 'topup' ? [{ item: b.item, qty: b.qty, amount: b.amount, label: b.label }] : []) as Record<string, unknown>[];
  if (raw.length > 10) throw new HttpError(400, 'Maximum 10 services per link');
  const lines: WaLine[] = raw.map(r => {
    const it = WA_ITEMS.find(x => x.k === r.item);
    if (!it) throw new HttpError(400, 'Choose the product');
    const qty = Math.floor(num(r.qty, 1));
    if (!(qty >= 1 && qty <= 50)) throw new HttpError(400, 'Quantity: 1 to 50');
    const typed = money(r.amount);
    const amount = typed > 0 ? typed : money(waPrice(s, it.k) * qty);
    if (!(amount >= 1)) throw new HttpError(400, `Enter the amount for ${it.label}`);
    const what = it.k === 'other' ? String(r.label || '').replace(/\s+/g, ' ').trim().slice(0, 60) || 'Other' : it.label;
    return { k: it.k, label: `${qty > 1 ? qty + ' × ' : ''}${what}`, qty, amount };
  });
  const top = money(b.topup);
  // v129: no minimum top-up on WhatsApp links (the website / Telegram minimum stays)
  if (!lines.length && !(top > 0)) throw new HttpError(400, 'Add a service or a top-up');
  const prem = lines.some(x => x.k === 'premium' || x.k === 'premium_full') || b.tier === 'premium'; // v135: a top-up-only link for a Premium customer → the Premium fee
  const pct = num((prem ? tierFor(s, 'premium') : s).topup_comm_pct, 3);
  const feeOn = !(b.fee_on === false || b.fee_on === 0 || b.fee_on === '0');
  const fee = top > 0 && feeOn ? money(top * pct / 100) : 0;
  const sub = money(lines.reduce((a, x) => a + x.amount, 0));
  const disc = money(b.discount);
  if (disc < 0 || disc > money(sub + fee)) throw new HttpError(400, `Discount can be at most ${usd(sub + fee)} (services + fee, not the top-up)`);
  const amount = money(sub - Math.min(disc, sub)); // what the services bring in after the discount
  const feeNet = money(fee - Math.max(0, disc - sub)); // a discount bigger than the services comes off the fee
  const total = money(amount + top + feeNet);
  if (!(total >= 1)) throw new HttpError(400, 'Total must be at least $1');
  if (total > 50000) throw new HttpError(400, 'Maximum $50,000 per link');
  const bm = String(b.bm_id || '').replace(/\D/g, '');
  if (bm && (bm.length < 8 || bm.length > 20)) throw new HttpError(400, 'Business Manager ID looks wrong (numbers only)');
  const act = String(b.act_id || '').trim().replace(/^act_/i, '').replace(/\D/g, '');
  if (act && act.length < 6) throw new HttpError(400, 'Ad account ID looks wrong');
  const name = String(b.name || '').replace(/\s+/g, ' ').trim().slice(0, 80), phone = String(b.phone || '').replace(/[^\d+ ]/g, '').trim().slice(0, 24);
  const label = (lines.length ? lines.map(x => x.label).join(' + ') + (top > 0 ? ` + ${usd(top)} top-up` : '') : `Ad account top-up ${usd(top)}${act ? ' → act_' + act : ''}`).slice(0, 200);
  if (one<{ n: number }>('SELECT COUNT(*) n FROM pay_links WHERE wa=1 AND agent_id=? AND created_at>?', agent.id, now() - HOUR)!.n >= 30) throw new HttpError(429, 'Too many links in the last hour');
  const first = lines.length ? WA_ITEMS.find(x => x.k === lines[0].k)! : null;
  const hasAcct = lines.some(x => WA_ITEMS.find(y => y.k === x.k)?.service === 'account');
  const kind = !lines.length ? 'topup' : lines.length === 1 ? first!.service : hasAcct ? 'account' : 'custom';
  const code = 'PL-' + crypto.randomBytes(5).toString('hex').toUpperCase();
  // top-up only: kind 'topup', amount = the top-up (like Telegram links). With services: amount = services after discount, wa_topup = top-up.
  run(`INSERT INTO pay_links(code, lead_id, agent_id, kind, qty, bm_id, act_id, amount, fee, total, label, status, created_at, tier, share_mode, wa, item, cust_name, cust_phone, full, wa_topup, wa_items, wa_disc)
    VALUES(?,NULL,?,?,?,?,?,?,?,?,?,'new',?,?,?,1,?,?,?,?,?,?,?)`, code, agent.id, kind, lines.reduce((a, x) => a + (WA_ITEMS.find(y => y.k === x.k)?.service === 'account' ? x.qty : 0), 0) || 1,
    bm || null, act || null, lines.length ? amount : top, feeNet, total, label, now(), prem ? 'premium' : null, hasAcct ? 'bm' : null, lines.length === 1 ? lines[0].k : lines.length ? 'multi' : 'topup',
    name || null, phone || null, lines.some(x => x.k === 'full' || x.k === 'premium_full') ? 1 : 0, lines.length && top > 0 ? top : null, JSON.stringify(lines), disc || null);
  const link = byCode(code)!;
  const url = payUrl(code);
  return { ok: true, link: pubWa(link), url, message: waMessage(link, url) };
}
/** Breakdown lines (WhatsApp message + pay page). */
export function waBreakdown(l: PayLink) {
  const out: [string, number][] = [];
  const top = l.kind === 'topup' ? l.amount : num(l.wa_topup);
  for (const x of waLines(l)) out.push([x.label, x.amount]);
  if (top > 0) out.push([`Top-up${l.act_id ? ' → act_' + l.act_id : ''}`, top]);
  const disc = num((l as { wa_disc?: number | null }).wa_disc);
  const sub = waLines(l).reduce((a, x) => a + x.amount, 0);
  const fee = disc > sub ? money(l.fee + (disc - sub)) : l.fee; // the fee before a discount that ate into it
  if (fee > 0) out.push([`Top-up fee (${Math.round(fee / top * 10000) / 100}%)`, fee]);
  if (disc > 0) out.push(['Discount', -disc]);
  return out;
}
function waMessage(l: PayLink, url: string) {
  const rows = waBreakdown(l);
  const body = rows.length > 1 || num((l as { wa_disc?: number | null }).wa_disc) > 0 ? [...rows.map(([t, v]) => `${t}: ${v < 0 ? '-' + usd(-v) : usd(v)}`), `Total: ${usd(l.total)}`] : [`${l.label}: ${usd(l.total)}`];
  return `💳 Your payment link\n${body.join('\n')}\n\nPay with crypto (USDT and more):\n${url}\n\nIt is confirmed automatically once the payment arrives.`;
}
const pubWa = (l: PayLink) => ({ ...pubLink(l), item: l.item, cust_name: l.cust_name, cust_phone: l.cust_phone, wa_topup: l.wa_topup ?? null, wa_disc: (l as { wa_disc?: number | null }).wa_disc ?? null });
/** The agent's WhatsApp links (the manager sees everyone's). */
export function waPayLinks(agentId: number, all_ = false) {
  return all<PayLink>(`SELECT * FROM pay_links WHERE wa=1 ${all_ ? '' : 'AND agent_id=?'} ORDER BY id DESC LIMIT 50`, ...(all_ ? [] : [agentId])).map(pubWa);
}
async function markWaPaid(l: PayLink) {
  const claimed = run("UPDATE pay_links SET status='paid', paid_at=? WHERE id=? AND status IN ('new','pending_payment','cancelled')", now(), l.id).changes;
  if (!claimed) return;
  const ag = agentById(l.agent_id);
  const who = [l.cust_name, l.cust_phone].filter(Boolean).join(' · ') || 'WhatsApp customer';
  const top = l.kind === 'topup' ? l.amount : num(l.wa_topup);
  // each service → a WhatsApp sale (revenue). A discount is shared over the services by their price, so the sales add up to what was paid for them.
  const lines = waLines(l);
  const sub = lines.reduce((a, x) => a + x.amount, 0);
  let left = l.kind === 'topup' ? 0 : l.amount;
  lines.forEach((x, i) => {
    const amt = i === lines.length - 1 ? money(left) : money(sub > 0 ? x.amount * l.amount / sub : 0);
    left = money(left - amt);
    if (!(amt > 0)) return;
    try {
      addWaSale({ item: x.k, qty: x.qty, amount: amt, name: l.cust_name, phone: l.cust_phone, note: `Crypto link ${l.code}${x.k === 'other' ? ' · ' + x.label : ''}${amt < x.amount ? ` · discount ${usd(x.amount - amt)}` : ''}` }, { name: ag?.name || 'Payment link', agent_id: ag?.id ?? null }, { link: true, link_id: l.id });
    } catch (e) { console.warn('[paylink wa] sale', l.code, (e as Error).message); }
  });
  // the top-up → top-ups (the client's ad money; its fee is our income)
  if (top > 0) {
    run('INSERT INTO topups(lead_id, agent_id, amount, commission, note, created_at, wa) VALUES(NULL,?,?,?,?,?,1)', l.agent_id, top, l.fee, `WhatsApp · ${who} · ${l.code}${l.act_id ? ' · act_' + l.act_id : ''}`.slice(0, 200), now());
  }
  if (managers().length && ag?.role !== 'manager') {
    try {
      await createTask({ kind: l.kind === 'funnel' ? 'funnel' : l.kind === 'account' ? 'account' : l.kind === 'topup' ? 'topup' : 'other', source: 'agent', agent_id: l.agent_id, bm_id: l.bm_id, act_id: l.act_id,
        qty: l.kind === 'account' ? l.qty : null, amount: l.kind === 'topup' ? l.amount : null,
        note: `💬 WhatsApp · ${who} · ✅ Paid ${usd(gotUsd(l))} by crypto (${l.code})${paidNote(l)} · ${l.label}${top > 0 && l.kind !== 'topup' ? ` · then TOP UP ${usd(top)} on the new account` : ''}${(l as { full?: number }).full ? ' · 🔑 FULL ACCESS' : ''}${l.kind === 'account' && !l.bm_id ? ' · ask the client for the BM ID' : ''}${l.kind === 'topup' && !l.act_id ? ' · ask the client for the ad account ID' : ''}` });
    } catch (e) { console.warn('[paylink wa] task', (e as Error).message); }
  }
  await notifyAgent(ag, `✅ WhatsApp customer ${who} paid ${usd(gotUsd(l))} — ${l.label} (${l.code})${paidNote(l)}. Saved automatically, don’t add it again.`, null, { title: `✅ Paid ${usd(l.total)} (WhatsApp)`, body: `${who} · ${l.label}` });
  void pushTo('admin', null, `✅ WhatsApp link paid ${usd(l.total)}`, `${who} · ${l.label}${ag ? ' · ' + ag.name : ''}`, {});
}

/** Ready-to-send text for the client (agent can edit it before sending). */
/** The fee % this link was made with (Premium links can have their own). */
const linkPct = (l: { amount: number; fee: number; offer_free?: number | null }, s: Settings) => {
  const base = l.amount - num(l.offer_free); // Premium offer: no fee on the first part
  return base > 0 && l.fee > 0 ? Math.round(l.fee / base * 10000) / 100 : num(s.topup_comm_pct, 3);
};

export function clientMessage(s: Settings, l: PayLink, url: string) {
  const kids = partsOf(l);
  const what = kids.length ? `${kids.map(k => `• ${k.kind === 'topup' ? `Top-up ${usd(k.amount)}${k.act_id ? ` to act_${k.act_id}` : ''} + fee ${usd(k.fee)}` : k.label}: ${usd(k.total)}`).join('\n')}\nTotal: ${usd(l.total)}`
    : l.kind === 'topup'
    ? `Top-up: ${usd(l.amount)}${l.act_id ? ` to act_${l.act_id}` : ''}\nFee (${linkPct(l, s)}%): ${usd(l.fee)}${num(l.offer_free) > 0 ? ` — 🎁 offer: no fee on the first ${usd(num(l.offer_free))}` : ''}\nTotal: ${usd(l.total)}`
    : `${l.label}: ${usd(l.total)}`;
  return `💳 Your payment link\n${what}\n\nPay with crypto (USDT and more):\n${url}\n\nIt is confirmed automatically once the payment arrives.`;
}

export const pubLink = (l: PayLink) => ({ id: l.id, code: l.code, kind: l.kind, qty: l.qty, bm_id: l.bm_id, act_id: l.act_id, amount: l.amount, fee: l.fee, total: l.total, label: l.label, status: l.status, pay_currency: l.pay_currency, paid_at: l.paid_at, created_at: l.created_at, url: payUrl(l.code), paid_usd: paidOf(l), due: dueOf(l), ok_by: l.ok_by || null, item: l.wa ? undefined : l.item || null, list_price: l.list_price ?? null });
export const leadPayLinks = (leadId: number) => all<PayLink>('SELECT * FROM pay_links WHERE lead_id=? AND parent_id IS NULL ORDER BY id DESC LIMIT 30', leadId).map(pubLink); // v166: a bundle's parts (paid or not) are not links of their own
/** v144: the links of a chat + what can be sold in it (one catalog for the sheet) + the agent's price limit. */
export const chatLinksAndItems = (lead: Lead) => { const s = getSettings(); return { links: leadPayLinks(lead.id), items: chatCatalog(s, lead), max_discount_pct: num(s.max_discount_pct, 40) }; };

/** agentId null = admin / manager (any link). v166: a part-paid link is never cancelled, except by the admin with force. */
export function cancelPayLink(id: number, agentId: number | null, opt: { force?: boolean; by?: number | null } = {}) {
  const l = one<PayLink>('SELECT * FROM pay_links WHERE id=?', id);
  if (!l || l.parent_id || (agentId !== null && l.agent_id !== agentId)) throw new HttpError(404, 'Link not found');
  if (!['new', 'pending_payment'].includes(l.status)) throw new HttpError(400, 'Paid links can’t be cancelled');
  if (paidOf(l) > 0 && !opt.force) throw new HttpError(400, `The client already paid ${usd(paidOf(l))} on this link. It can’t be cancelled. Ask the admin.`);
  run("UPDATE pay_links SET status='cancelled' WHERE id=?", id);
  run("UPDATE pay_links SET status='cancelled' WHERE parent_id=? AND status='part'", id);
  const lead = leadById(l.lead_id);
  if (lead) addMsg(lead, { dir: 'sys', sender: 'system', agent_id: agentId ?? opt.by ?? null, text: `🚫 Payment link ${l.code} cancelled${paidOf(l) > 0 ? ` (${usd(paidOf(l))} was already paid)` : ''}` });
  return { ok: true };
}

/* ---------------- public pay page (/pay/PL-XXXX) ---------------- */
const hits = new Map<string, number[]>();
function limit(ip: string) {
  const t = now(); const h = (hits.get(ip) || []).filter(x => x > t - 60000); h.push(t); hits.set(ip, h);
  if (h.length > 40) throw new HttpError(429, 'Too many requests. Wait a minute.');
}

export function payPageInfo(code: unknown, ip: string) {
  limit(ip);
  const l = byCode(code);
  if (!l || l.parent_id) throw new HttpError(404, 'This payment link does not exist. Ask your account manager for a new one.');
  const s = getSettings();
  return {
    link: { code: l.code, label: l.label, kind: l.kind, amount: l.amount, fee: l.fee, total: l.total, status: l.status, fee_pct: linkPct(l, s), wa: !!l.wa, lines: l.wa ? waBreakdown(l) : l.parts ? partsOf(l).flatMap(k => k.kind === 'topup' ? [[`Top-up${k.act_id ? ' → act_' + k.act_id : ''}`, k.amount], [`Top-up fee`, k.fee]] as [string, number][] : [[k.label, k.total]] as [string, number][]).filter(x => x[1] !== 0) : null, paid_usd: paidOf(l), due: dueOf(l) },
    coins: coinList(s), crypto: l.status === 'pending_payment' ? cryptoInfo(l) : null,
  };
}

export async function payPageStart(code: unknown, b: Record<string, unknown>, ip: string) {
  limit(ip);
  const s = getSettings();
  const l = byCode(code);
  if (!l || l.parent_id) throw new HttpError(404, 'Link not found');
  if (!['new', 'pending_payment'].includes(l.status)) throw new HttpError(400, l.status === 'cancelled' ? 'This link was cancelled. Ask your account manager for a new one.' : 'This link is already paid');
  const cur = String(b.currency || '').toLowerCase();
  if (!enabledCoins(s).includes(cur)) throw new HttpError(400, 'Choose one of the listed coins');
  if (!b.renew && l.pay_currency === cur && l.pay_address && (l.np_expires || 0) > now() + 60000) return { ok: true, crypto: cryptoInfo(l) };
  const due = dueOf(l); // after a short payment: only what is left
  const pay = await npCreatePayment(s, { code: l.code, amount: due, desc: `${s.brand_name}: ${l.label} (${l.code})${due < l.total ? ' · remaining' : ''}`, payCurrency: cur });
  run("UPDATE pay_links SET np_payment_id=?, pay_currency=?, pay_address=?, pay_amount=?, pay_extra=?, np_expires=?, np_status='waiting', status='pending_payment' WHERE id=?",
    pay.id, cur, pay.address, pay.amount, pay.extra, pay.expires, l.id);
  const lead = leadById(l.lead_id);
  if (lead && l.status === 'new') addMsg(lead, { dir: 'sys', sender: 'system', text: `👀 Client opened payment link ${l.code} and chose ${coinName(s, cur)}` });
  return { ok: true, crypto: cryptoInfo(byCode(l.code)!) };
}

/** Page polls: also ask NOWPayments directly (max every 15s) in case the IPN is late. */
export async function payPageCheck(code: unknown, ip: string) {
  const l = byCode(code);
  if (l && l.status === 'pending_payment' && l.np_payment_id && now() - (l.np_checked || 0) >= 15000) {
    run('UPDATE pay_links SET np_checked=? WHERE id=?', now(), l.id);
    const st = await npPaymentStatus(getSettings(), l.np_payment_id);
    if (st && String(st.payment_id || '') === String(l.np_payment_id)) await payLinkIpn({ ...st, order_id: l.code });
  }
  return payPageInfo(code, ip);
}

/* ---------------- payment confirmed ---------------- */
export async function payLinkIpn(p: Record<string, unknown>) {
  const l = byCode(p.order_id);
  if (!l) return { ignored: true };
  const status = String(p.payment_status || '');
  if (staleNews(l.np_payment_id, p)) return { ok: true, stale: true }; // old address after a coin change
  run('UPDATE pay_links SET np_status=?, np_payment_id=COALESCE(?, np_payment_id), pay_currency=COALESCE(?, pay_currency) WHERE id=?', status, p.payment_id ? String(p.payment_id) : null, p.pay_currency ? String(p.pay_currency) : null, l.id);
  const done = NP_PAID.includes(status);
  if (!done && status !== 'partially_paid') return { ok: true };
  // each NOWPayments payment asked for the link total, or (after a short payment) what was left — never more
  const price = num(p.price_amount);
  if (String(p.price_currency || 'usd').toLowerCase() !== 'usd' || !(price > 0) || price > l.total + 0.01) { console.warn('[paylink] amount mismatch', l.code, p.price_amount, l.total); return { ok: false, mismatch: true }; }
  // USD that really came: what was asked × the part of the coin amount that arrived
  const want = num(p.pay_amount) || (String(p.payment_id || "") === String(l.np_payment_id || "") ? num(l.pay_amount) : 0), got = num(p.actually_paid);
  // finished / confirmed = NOWPayments got this payment in full; partially_paid = only the part that arrived
  const usdIn = money(done ? price : want > 0 && got > 0 ? Math.min(price, price * got / want) : 0);
  const pid = String(p.payment_id || l.np_payment_id || l.code);
  run('INSERT INTO pay_parts(np_id, link_id, usd, coin, st, at) VALUES(?,?,?,?,?,?) ON CONFLICT(np_id, link_id) DO UPDATE SET usd=MAX(usd, excluded.usd), st=excluded.st', pid, l.id, usdIn, p.pay_currency ? String(p.pay_currency) : null, status, now());
  const paid = money(one<{ t: number }>('SELECT COALESCE(SUM(usd),0) t FROM pay_parts WHERE link_id=?', l.id)!.t);
  const before = paidOf(l);
  run('UPDATE pay_links SET paid_usd=? WHERE id=?', paid, l.id);
  const cur = { ...l, paid_usd: paid };
  const lead = l.lead_id ? leadById(l.lead_id) : undefined;
  if (enough(l, paid)) { if (l.wa) await markWaPaid(cur); else await markLinkPaid(cur, lead); return { ok: true }; }
  if (paid > before + 0.009 && ['new', 'pending_payment'].includes(l.status)) await shortPaid(cur, lead);
  return { ok: true, short: true };
}

/** Paid less than the link: not confirmed. Client: what came + what is left, pay the rest on the same link. Agent + admin: told. Confirms only when the full amount has come. */
async function shortPaid(l: PayLink, lead: Lead | undefined) {
  const paid = paidOf(l), due = dueOf(l), url = payUrl(l.code);
  // the next visit to the link asks a new address for the rest only
  run("UPDATE pay_links SET short_at=?, pay_address=NULL, pay_amount=NULL, pay_extra=NULL, np_expires=0, status='pending_payment' WHERE id=?", now(), l.id);
  const ag = agentById(l.agent_id);
  const line = `received ${usd(paid)} of ${usd(l.total)} on link ${l.code} — ${usd(due)} still due`;
  if (l.wa || !lead) {
    const who = [l.cust_name, l.cust_phone].filter(Boolean).join(' · ') || 'WhatsApp customer';
    await notifyAgent(ag, `⚠️ Short payment: ${who} — ${line}. NOT confirmed until the full amount comes. Ask the customer to pay the remaining ${usd(due)} on the same link: ${url}`, null, { title: `⚠️ Short payment · ${usd(due)} due`, body: `${who} · ${l.code}` });
    void pushTo('admin', null, `⚠️ Short payment · ${usd(due)} due`, `${who} · ${l.code}${ag ? ' · ' + ag.name : ''}`, {});
    return;
  }
  addMsg(lead, { dir: 'sys', sender: 'system', agent_id: l.agent_id, text: `⚠️ Short payment: ${line}. NOT confirmed until the full amount comes — the client was asked to pay the rest on the same link.` });
  try {
    await sendToLead(lead, `We received ${usd(paid)} of ${usd(l.total)} for ${l.label} (${l.code}).\nRemaining: ${usd(due)}\n\nYour payment is not confirmed yet. Please pay the remaining ${usd(due)} on the same link:\n${url}`, 'agent', l.agent_id);
  } catch (e) { console.warn('[paylink] short msg', (e as Error).message); }
  await notifyAgent(ag, `⚠️ ${displayName(lead)}: ${line}. Not confirmed — the client was asked to pay the rest.`, lead.id, { title: `⚠️ Short payment · ${usd(due)} due`, body: `${displayName(lead)} · ${l.code}` });
  void pushTo('admin', null, `⚠️ Short payment · ${usd(due)} due`, `${displayName(lead)} · ${l.code}${ag ? ' · ' + ag.name : ''}`, { lead_id: String(lead.id) });
}

/** Admin: links paid short and not confirmed. */
export function shortLinks() {
  return all<PayLink & { agent_name: string | null }>("SELECT p.*, a.name agent_name FROM pay_links p LEFT JOIN agents a ON a.id=p.agent_id WHERE p.status IN ('new','pending_payment','cancelled') AND p.parent_id IS NULL AND COALESCE(p.paid_usd,0) > 0 ORDER BY p.id DESC LIMIT 50") // v166: + cancelled links with money on them
    .map(l => ({ ...pubLink(l), agent_name: l.agent_name, lead_id: l.lead_id, wa: !!l.wa, cust_name: l.cust_name || null, cust_phone: l.cust_phone || null }));
}
const paidNote = (l: PayLink) => {
  const p = paidOf(l);
  if (!(p > 0) || p >= l.total - 0.009) return '';
  return ` · paid ${usd(p)} of ${usd(l.total)}`;
};
const gotUsd = (l: PayLink) => paidOf(l) > 0 ? paidOf(l) : l.total;

async function markLinkPaid(l: PayLink, lead: Lead | undefined) {
  // claim once (IPN and the page poll can arrive together)
  const claimed = run("UPDATE pay_links SET status='paid', paid_at=? WHERE id=? AND status IN ('new','pending_payment','cancelled')", now(), l.id).changes;
  if (!claimed) return;
  const s = getSettings();
  const ag = agentById(l.agent_id) || (managers()[0] ? agentById(managers()[0].id) : undefined); // v135: agent gone → the manager, so the sale is never lost
  if (!lead) return;
  addMsg(lead, { dir: 'sys', sender: 'system', agent_id: l.agent_id, text: `✅ PAID by crypto: ${l.label} · ${usd(gotUsd(l))} (${l.code})${paidNote(l)}` });
  // v159: one link with several products → each product is settled as its own paid link
  const kids = l.parts ? partsOf(l) : [];
  const items: PayLink[] = [];
  if (kids.length) {
    for (const k of kids) {
      if (run("UPDATE pay_links SET status='paid', paid_at=?, paid_usd=?, pay_currency=? WHERE id=? AND status IN ('part','cancelled')", now(), k.total, l.pay_currency, k.id).changes) items.push(one<PayLink>('SELECT * FROM pay_links WHERE id=?', k.id)!);
    }
  } else items.push(l);
  const recs: string[] = [];
  for (const it of items) { const r = await settleItem(it, lead, ag, kids.length ? `${paidNote(l)} · part of ${l.code}` : paidNote(l), kids.length ? usd(it.total) : usd(gotUsd(l))); if (r) recs.push(r); }
  const recorded = [...new Set(recs)].join(', ');
  await notifyAgent(ag, `✅ ${displayName(lead)} paid ${usd(gotUsd(l))} — ${l.label} (${l.code})${paidNote(l)}.${recorded ? ' ' + recorded + ' automatically, don’t mark it again.' : ''}`, lead.id, { title: `✅ Paid ${usd(l.total)}`, body: `${displayName(lead)} · ${l.label}` });
  void pushTo('admin', null, `✅ Crypto link paid ${usd(gotUsd(l))}`, `${displayName(lead)} · ${l.label}${ag ? ' · ' + ag.name : ''}`, { lead_id: String(lead.id) });
  // Tell the client
  const nextOf = (x: PayLink) => x.kind === 'topup' ? `Your top-up of ${usd(x.amount)} will be added shortly.` : x.kind === 'funnel' ? 'We’ll start your funnel setup now.' : x.kind === 'custom' ? 'We’ll set it up for you shortly.' : `Your ad account${x.qty > 1 ? 's' : ''} will be shared within ${s.delivery_time}.${x.bm_id || x.share_mode === 'email' ? '' : ' Please send your Business Manager ID.'}`;
  const next = items.length > 1 ? [...new Set(items.map(x => x.kind === 'custom' || x.item === 'fb_old' ? `${x.label}: we’ll set it up for you shortly.` : nextOf(x)))].join('\n') : nextOf(items[0] || l);
  try { await sendToLead(lead, `✅ Payment received: ${usd(gotUsd(l))}. Thank you!\n${next}`, 'agent', l.agent_id); } catch (e) { console.warn('[paylink] client msg', (e as Error).message); }
}
/** Record one paid product (sale / top-up), share or top up through our BMs, else a task for the manager. */
async function settleItem(l: PayLink, lead: Lead, ag: ReturnType<typeof agentById>, note: string, paidTxt: string) {
  // Record it for the agent, the same as tapping "Mark sold" / "Add topup"
  let recorded = '';
  if (ag) {
    try {
      if (l.kind === 'topup') { addTopup(lead, ag, l.amount, `Crypto link ${l.code}`, { fee: l.fee, free: (l as { offer_free?: number | null }).offer_free }); recorded = 'Top-up recorded'; }
      // v141: a link the manager made in an agent's chat (manager → Agents) → the chat's agent keeps the sale, like "Mark sold"
      else { const own = ag.role === 'manager' && lead.agent_id && lead.agent_id !== ag.id ? agentById(lead.agent_id) : undefined; const rs: any = await recordSale(lead, own && !own.deleted ? own : ag, { closed_by: ag.id, service: l.kind, qty: l.qty, paid: l.amount, link_id: l.id, full: (l as { full?: number }).full, tier: l.ptier || undefined, item: l.item || undefined, list_price: l.list_price ?? null }, { check: ag.role !== 'manager' }); recorded = rs?.pending_check ? 'Sale waits for the manager check (other account type)' : 'Sale recorded'; }
    } catch (e) { console.warn('[paylink] record', l.code, (e as Error).message); }
  }
  // Our own BMs (Ad accounts system): share / top-up straight away or ask the manager to approve
  let viaMeta = false;
  // full access accounts are given by the manager by hand (our automatic sharing never gives full control)
  try { viaMeta = (l as { full?: number }).full ? false : await requestFromPayLink(l, lead); } catch (e) { console.warn('[paylink] meta', l.code, (e as Error).message); }
  // Task for the manager (unless the agent is the manager)
  if (!viaMeta && managers().length && ag?.role !== 'manager') {
    try {
      await createTask({
        kind: l.kind === 'topup' ? 'topup' : l.kind === 'custom' ? 'other' : l.kind, source: 'agent', lead_id: lead.id, agent_id: l.agent_id, bm_id: l.bm_id, act_id: l.act_id,
        qty: l.kind === 'account' ? l.qty : null, amount: l.kind === 'topup' ? l.amount : null,
        note: `✅ Paid ${paidTxt} by crypto (${l.code})${note}${l.kind === 'custom' || l.item === 'fb_old' ? ' · ' + l.label : ''}${(l as { full?: number }).full ? ' · 🔑 FULL ACCESS' : ''}${l.kind === 'account' && !l.bm_id ? ' · ask the client for the BM ID' : ''}${l.kind === 'topup' && !l.act_id ? ' · ask the client for the ad account ID' : ''}`,
      });
    } catch (e) { console.warn('[paylink] task', (e as Error).message); }
  }
  return recorded;
}
