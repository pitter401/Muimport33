import { HttpError } from './util';
import crypto from 'crypto';
import type { Settings } from './settings';
import { publicUrl } from './email';

const API = () => process.env.NP_API_BASE || 'https://api.nowpayments.io';
export const npWidgetUrl = (invoiceId: string) => `${process.env.NP_WIDGET_BASE || 'https://nowpayments.io'}/embeds/payment-widget?iid=${encodeURIComponent(invoiceId)}`;

/** Built-in coin names. More coins can be added from Admin → Settings → Website → “Add coin” (NOWPayments list), saved in np_coin_meta. */
export const COINS: Record<string, string> = { usdtbsc: 'USDT (BEP20)', trx: 'TRX (Tron)', usdttrc20: 'USDT (TRC20)', btc: 'Bitcoin', eth: 'Ethereum', ltc: 'Litecoin', bnbbsc: 'BNB (BEP20)', sol: 'Solana' };
/** Network name shown next to the address so people send on the right chain. */
export const NETWORKS: Record<string, string> = { usdtbsc: 'BNB Smart Chain (BEP20)', trx: 'Tron (TRC20)', usdttrc20: 'Tron (TRC20)', btc: 'Bitcoin', eth: 'Ethereum (ERC20)', ltc: 'Litecoin', bnbbsc: 'BNB Smart Chain (BEP20)', sol: 'Solana' };
export const COIN_TICKER: Record<string, string> = { usdtbsc: 'USDT', trx: 'TRX', usdttrc20: 'USDT', btc: 'BTC', eth: 'ETH', ltc: 'LTC', bnbbsc: 'BNB', sol: 'SOL' };
export type CoinMeta = { name: string; network: string; ticker: string };
/** Coins the admin added from the NOWPayments list: { code: { name, network, ticker } } */
export function coinMeta(s: Pick<Settings, 'np_coin_meta'>): Record<string, CoinMeta> {
  try {
    const j = JSON.parse(String(s.np_coin_meta || '{}'));
    const out: Record<string, CoinMeta> = {};
    if (j && typeof j === 'object') for (const [k, v] of Object.entries(j as Record<string, Partial<CoinMeta>>)) {
      const code = String(k).toLowerCase().replace(/[^a-z0-9]/g, '');
      if (code && v && typeof v === 'object') out[code] = { name: String(v.name || code.toUpperCase()).slice(0, 60), network: String(v.network || '').slice(0, 60), ticker: String(v.ticker || code.toUpperCase()).slice(0, 15) };
    }
    return out;
  } catch { return {}; }
}
export const coinName = (s: Pick<Settings, 'np_coin_meta'>, id: string) => COINS[id] || coinMeta(s)[id]?.name || id.toUpperCase();
export const coinNetwork = (s: Pick<Settings, 'np_coin_meta'>, id: string) => NETWORKS[id] || coinMeta(s)[id]?.network || '';
export const coinTicker = (s: Pick<Settings, 'np_coin_meta'>, id: string) => COIN_TICKER[id] || coinMeta(s)[id]?.ticker || id.toUpperCase();
export const enabledCoins = (s: Settings) => { const m = coinMeta(s); return [...new Set(String(s.np_currencies || '').split(/[,\s]+/).map(x => x.trim().toLowerCase()).filter(x => x && (x in COINS || x in m)))]; };
/** Coins customers can pick, with the name to show. */
export const coinList = (s: Settings) => enabledCoins(s).map(id => ({ id, name: coinName(s, id) }));

/** Upper-case network codes from NOWPayments → readable names. */
const NET_NAMES: Record<string, string> = { bsc: 'BNB Smart Chain (BEP20)', trx: 'Tron (TRC20)', eth: 'Ethereum (ERC20)', sol: 'Solana', matic: 'Polygon', polygon: 'Polygon', btc: 'Bitcoin', ltc: 'Litecoin', ton: 'TON', arbitrum: 'Arbitrum', op: 'Optimism', base: 'Base', avaxc: 'Avalanche C-Chain', doge: 'Dogecoin', xrp: 'XRP Ledger', bch: 'Bitcoin Cash' };
/** Full NOWPayments coin list for the admin's “Add coin” search (names + network + whether it is on in the NOWPayments account). */
export async function npAllCoins(s: Settings) {
  if (!s.np_api_key) throw new HttpError(400, 'Add your NOWPayments API key first, then Save');
  const h = { 'x-api-key': s.np_api_key };
  const [full, mine] = await Promise.all([
    fetch(`${API()}/v1/full-currencies`, { headers: h, signal: AbortSignal.timeout(20000) }).then(r => r.ok ? r.json() : null).catch(() => null) as Promise<{ currencies?: Record<string, unknown>[] } | null>,
    fetch(`${API()}/v1/merchant/coins`, { headers: h, signal: AbortSignal.timeout(20000) }).then(r => r.ok ? r.json() : null).catch(() => null) as Promise<{ selectedCurrencies?: string[] } | null>,
  ]);
  if (!full?.currencies?.length) throw new HttpError(502, 'Could not load the coin list from NOWPayments. Check the API key and try again.');
  const on = new Set((mine?.selectedCurrencies || []).map(x => String(x).toLowerCase()));
  return full.currencies
    .filter(c => c && c.code && c.enable !== false)
    .map(c => {
      const code = String(c.code).toLowerCase();
      const net = String(c.network || '').toLowerCase();
      const ticker = String(c.ticker || c.code).toUpperCase().replace(/(BSC|TRC20|ERC20|SOL|MATIC|ARB|OP|BASE|TON)$/, '') || String(c.code).toUpperCase();
      return { id: code, name: String(c.name || code.toUpperCase()), network: NETWORKS[code] || NET_NAMES[net] || (net ? net.toUpperCase() : ''), ticker: COIN_TICKER[code] || ticker, on_np: on.size ? on.has(code) : null, memo: !!c.extra_id_exists };
    })
    .sort((a, b) => (Number(b.on_np) - Number(a.on_np)) || a.name.localeCompare(b.name));
}

/** Creates a NOWPayments invoice (shown inside our page with their payment widget). */
export async function npCreateInvoice(s: Settings, o: { code: string; amount: number; desc: string; payCurrency?: string; back: string }) {
  if (!s.np_api_key) throw new HttpError(400, 'Crypto payments are not set up yet. Choose another method or contact your account manager.');
  const body: Record<string, unknown> = {
    price_amount: o.amount, price_currency: 'usd', order_id: o.code, order_description: o.desc.slice(0, 200),
    ipn_callback_url: `${publicUrl()}/api/np/ipn`, success_url: o.back, cancel_url: o.back, is_fixed_rate: true, is_fee_paid_by_user: false,
  };
  if (o.payCurrency) body.pay_currency = o.payCurrency;
  const r = await fetch(`${API()}/v1/invoice`, { method: 'POST', headers: { 'x-api-key': s.np_api_key, 'content-type': 'application/json' }, body: JSON.stringify(body), signal: AbortSignal.timeout(20000) });
  const j = await r.json().catch(() => ({})) as { id?: string | number; invoice_url?: string; message?: string };
  if (!r.ok || !j.id) { console.warn('[nowpayments]', r.status, j.message); throw new HttpError(502, 'Could not start the crypto payment right now. Please try again in a minute.'); }
  return { id: String(j.id), url: j.invoice_url || '' };
}

function sortDeep(v: unknown): unknown {
  if (Array.isArray(v)) return v.map(sortDeep);
  if (v && typeof v === 'object') return Object.keys(v as object).sort().reduce((a, k) => { (a as Record<string, unknown>)[k] = sortDeep((v as Record<string, unknown>)[k]); return a; }, {} as Record<string, unknown>);
  return v;
}
/** IPN signature: HMAC-SHA512 of the JSON body with keys sorted, using the IPN secret. */
export function npSignature(secret: string, body: unknown) {
  return crypto.createHmac('sha512', secret).update(JSON.stringify(sortDeep(body))).digest('hex');
}
export function npVerify(s: Settings, body: unknown, sig: string | null) {
  if (!s.np_ipn_secret || !sig) return false;
  const good = npSignature(s.np_ipn_secret, body);
  return good.length === sig.length && crypto.timingSafeEqual(Buffer.from(good), Buffer.from(sig.toLowerCase()));
}
export const NP_PAID = ['confirmed', 'sending', 'finished'];

/** Direct payment (no NOWPayments page): we get an address + exact amount and show them in our own page. */
export async function npCreatePayment(s: Settings, o: { code: string; amount: number; desc: string; payCurrency: string }) {
  if (!s.np_api_key) throw new HttpError(400, 'Crypto payments are not set up yet. Choose another method or contact your account manager.');
  const body = {
    price_amount: o.amount, price_currency: 'usd', pay_currency: o.payCurrency, order_id: o.code, order_description: o.desc.slice(0, 200),
    // not fixed-rate: NOWPayments keeps the address open for days (fixed rate expires in ~20 min)
    ipn_callback_url: `${publicUrl()}/api/np/ipn`, is_fixed_rate: false, is_fee_paid_by_user: false,
  };
  const r = await fetch(`${API()}/v1/payment`, { method: 'POST', headers: { 'x-api-key': s.np_api_key, 'content-type': 'application/json' }, body: JSON.stringify(body), signal: AbortSignal.timeout(25000) });
  const j = await r.json().catch(() => ({})) as { payment_id?: string | number; pay_address?: string; pay_amount?: number; payin_extra_id?: string | null; expiration_estimate_date?: string; valid_until?: string; message?: string; code?: string };
  if (!r.ok || !j.payment_id || !j.pay_address) {
    console.warn('[nowpayments] payment', r.status, j.message || j.code);
    if (/less than minimal|AMOUNT_MINIMAL|too small|minimal/i.test(`${j.code || ''} ${j.message || ''}`)) throw new HttpError(400, 'This amount is below the minimum for this coin. Please choose USDT (BEP20) or another coin.');
    throw new HttpError(502, 'Could not create the payment address right now. Please try again in a minute.');
  }
  const win = Math.max(10, Math.min(24 * 60, Number(s.pay_window_min) || 60)) * 60000; // our own timer shown to the customer
  const exp = Date.now() + win;
  return { id: String(j.payment_id), address: j.pay_address, amount: Number(j.pay_amount), extra: j.payin_extra_id || null, expires: exp };
}
/** Ask NOWPayments for the current status (used when the customer taps "Check status" / page polls). */
export async function npPaymentStatus(s: Settings, id: string) {
  if (!s.np_api_key) return null;
  try {
    const r = await fetch(`${API()}/v1/payment/${encodeURIComponent(id)}`, { headers: { 'x-api-key': s.np_api_key }, signal: AbortSignal.timeout(15000) });
    if (!r.ok) return null;
    return await r.json() as Record<string, unknown>;
  } catch { return null; }
}
