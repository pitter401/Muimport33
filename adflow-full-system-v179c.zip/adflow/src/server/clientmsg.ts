/** Automatic messages to the client (sent from the chat account, like the agent writing). Used by the Ad accounts system and by manager tasks. */
import { getSettings } from './settings';
import { money } from './util';
import { one } from './db';
import { addMsg, sendToLead, type Lead } from './crm';

export type ClientMsgKey = 'meta_msg_share' | 'meta_msg_invite' | 'meta_msg_invite_ok' | 'meta_msg_topup' | 'meta_msg_low' | 'meta_msg_replace' | 'meta_msg_topup_hand' | 'meta_msg_topup_req';
const usd = (n: number) => '$' + money(n).toFixed(2).replace(/\.00$/, '');

/** Fill a template. Unknown values: the "({bm})" part or the whole line is left out. Returns '' when switched off. */
export function clientText(key: ClientMsgKey, v: { acts: string[]; bm?: string | null; email?: string | null; amount?: number; balance?: number; verified?: string | null; topup?: number | null }) {
  const s = getSettings();
  if (s.meta_client_msgs === '0') return '';
  let t = String(s[key] || '');
  if (!v.bm) t = t.replace(/\s*\(\{bm\}\)/g, '');
  if (v.balance === undefined) t = t.split('\n').filter(l => !l.includes('{balance}')).join('\n');
  // v155: account given with no balance yet → say it clearly instead of "Balance: $0"
  if ((key === 'meta_msg_share' || key === 'meta_msg_replace') && v.balance !== undefined && !(v.balance > 0)) {
    const min = Number(s.topup_min) || 0;
    t = t.split('\n').map(l => l.includes('{balance}') ? `Balance: $0 (no top-up yet). Tell us when you want to top up${min ? ` · minimum top-up $${min}` : ''}.` : l).join('\n');
  }
  // v157: money put on the account together with the share → its own line, right above the balance
  if ((key === 'meta_msg_share' || key === 'meta_msg_replace') && v.topup && v.topup > 0) {
    const line = `💰 Top-up added: ${usd(v.topup)}`;
    t = t.includes('{balance}') ? t.split('\n').map(l => l.includes('{balance}') ? line + '\n' + l : l).join('\n') : t + '\n' + line;
  }
  if (v.amount === undefined) t = t.split('\n').filter(l => !l.includes('{amount}')).join('\n');
  if (!v.verified) t = t.split('\n').filter(l => !l.includes('{verified}')).join('\n');
  return t.replace(/\{act\}/g, v.acts.map(a => 'act_' + a).join(', ')).replace(/\{bm\}/g, v.bm || '').replace(/\{email\}/g, v.email || '')
    .replace(/\{amount\}/g, usd(v.amount || 0)).replace(/\{balance\}/g, usd(v.balance || 0)).replace(/\{verified\}/g, v.verified || '').trim().replace(/^(.+)$/s, m => m + autoFooter());
}

/** Send it. Returns true when the client got it. A failure leaves a note in the chat for the agent. */
export async function tellClient(lead: Lead | undefined, key: ClientMsgKey, v: Parameters<typeof clientText>[1]) {
  if (!lead) return false;
  const text = clientText(key, { ...v, verified: v.verified ?? verifiedOf(v.acts), topup: v.topup ?? (key === 'meta_msg_share' || key === 'meta_msg_replace' ? shareTopup(v.acts[0]) : null) });
  if (!text) return false;
  try { await sendToLead(lead, text, 'agent', lead.agent_id); return true; }
  catch (e) { addMsg(lead, { dir: 'sys', sender: 'system', text: `⚠️ Could not send the client the message (${(e as Error).message}). Tell them yourself.` }); return false; }
}

/** v153: "1 Jun 2026" for the BM's 'verified since' date of these accounts (first one that has it). */
export function verifiedOf(acts: string[]) {
  for (const a of acts) {
    const r = one<{ v: string | null }>("SELECT b.verified_since v FROM meta_accounts a JOIN meta_bms b ON b.bm_id=a.bm_id WHERE a.act_id=?", String(a).replace(/\D/g, ''));
    if (r?.v) { const t = new Date(r.v + 'T00:00:00Z'); if (!isNaN(t.getTime())) return t.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' }); }
  }
  return null;
}

/** v157: money put on the account with this share (top-up with the account + the client's credit). 0 = none. */
export function shareTopup(act?: string | null) {
  if (!act) return 0;
  const a = one<{ assigned_at: number | null }>('SELECT assigned_at FROM meta_accounts WHERE act_id=?', String(act).replace(/\D/g, ''));
  if (!a?.assigned_at) return 0;
  const r = one<{ v: number }>("SELECT COALESCE(SUM(CASE WHEN kind='topup' THEN amount WHEN kind='share' THEN amount ELSE 0 END),0) v FROM meta_log WHERE act_id=? AND kind IN ('topup','share') AND created_at>=? AND created_at<=?", String(act).replace(/\D/g, ''), a.assigned_at - 5000, a.assigned_at + 15 * 60000);
  return money(r?.v || 0);
}

/** v155: the line under every automatic message / post, so the client knows it came from the system (not a reply we skipped). */
export function autoFooter() { const f = String(getSettings().meta_auto_footer || '').trim(); return f ? '\n\n' + f : ''; }
