/* v167: forced app update.
 *  An Android app older than the minimum build must update before it opens (the Daily reel needs the new WebView setting).
 *  Safe by design — the gate only activates when ALL of these are true:
 *   - "Force update" is ON (app_force_update, default on);
 *   - the APK for that app is really on the server (DOWNLOADS_DIR/<app>.apk) and version.json says it is at least the minimum;
 *   - the minimum comes from a v167-or-later build: scripts/build-apk.sh writes "v167" (the first such build's code) into
 *     version.json, so nothing is blocked until the owner builds the new APKs on his server.
 *  The client additionally never blocks a browser / PWA, or when it can't read its own build number. */
import fs from 'fs';
import path from 'path';
import { one, run } from './db';
import { num, HttpError } from './util';

export const FORCE_DEFAULTS = { app_force_update: '1', min_app_build_agent: '', min_app_build_admin: '' };
const dlDir = () => process.env.DOWNLOADS_DIR || '/var/www/adflow-downloads';
const get = (k: keyof typeof FORCE_DEFAULTS) => { const r = one<{ v: string }>('SELECT v FROM settings WHERE k=?', k); return r ? String(r.v ?? '') : FORCE_DEFAULTS[k]; };

type Ver = { code?: number; name?: string; at?: number; v167?: number; v168?: number }; // v168: first build with the background reel downloader
function readVersion(): Ver { try { return JSON.parse(fs.readFileSync(path.join(dlDir(), 'version.json'), 'utf8')); } catch { return {}; } }
const apkThere = (app: 'agent' | 'admin') => { try { return fs.statSync(path.join(dlDir(), `${app}.apk`)).size > 100000; } catch { return false; } };

/** The minimum build per app (0 = no forced update for that app). Read by /api/app-version. */
export function forceInfo() {
  const v = readVersion();
  const code = num(v.code), base = Math.max(num(v.v167), num(v.v168)); // v168: once a 1.7 (v168) build is on the server, it is the minimum
  const on = get('app_force_update') !== '0';
  const minFor = (app: 'agent' | 'admin') => {
    if (!on || !base || !apkThere(app)) return 0;              // no new build on the server yet → never block
    const min = Math.max(base, num(get(app === 'agent' ? 'min_app_build_agent' : 'min_app_build_admin')));
    return code >= min ? min : 0;                                 // the APK being served must be new enough itself
  };
  return { force: on, min_agent: minFor('agent'), min_admin: minFor('admin') };
}

/** Admin → System: the "Force update" switch + what it means right now. */
export function forceStatus() {
  const v = readVersion(), f = forceInfo();
  return { on: f.force, min_agent: f.min_agent, min_admin: f.min_admin, built: num(v.v167) > 0, v168: num(v.v168), // v168
     code: num(v.code), name: String(v.name || ''), apk_agent: apkThere('agent'), apk_admin: apkThere('admin') };
}
export function forceSet(b: Record<string, unknown>) {
  if (typeof b.on !== 'boolean') throw new HttpError(400, 'on: true / false');
  run('INSERT INTO settings(k, v) VALUES(?, ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v', 'app_force_update', b.on ? '1' : '0');
  return forceStatus();
}
