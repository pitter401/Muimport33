import { all, run } from './db';

/** Every value here can be changed from the Admin app → Settings. */
export const DEFAULTS = {
  // Brand & landing content
  brand_name: 'AdFlow',
  theme: 'purple',
  seo_title: '{brand} — Meta agency ad accounts delivered in {delivery}',
  seo_description: 'Agency ad accounts shared to your Business Manager within {delivery}, plus complete lead funnels. One agent on Telegram from order to launch.',
  // Google Search Console: the HTML-tag verification (full <meta> tag or just its content value)
  gsc_verify: '',
  stock_badge: 'Accounts in stock today',
  headline: 'Scale on Meta with agency ad accounts',
  headline_accent: 'live within one hour.',
  subheadline: 'Agency ad accounts shared to your Business Manager, and complete lead funnels built for you. One agent handles everything on Telegram.',
  tg_note: 'Order on Telegram',
  tg_note_sub: 'A real agent replies in minutes',
  tg_steps: 'Answer 3 quick questions and add your number\nTelegram opens with your message. Just tap Send\nPay in the chat. Your account is live within {delivery}',
  price_account: '20',
  contacts_ver: '0',
  apk_agent_theme: 'green',          // Agent app icon colour (purple | blue | green | gold)
  price_account_full: '45',            // full-access ad account (customer tops up himself, no fee; 1 account + 2 replacements)
  price_premium_full: '60',            // full-access PREMIUM ad account
  price_fb_old: '10',                  // Facebook account + Business Manager setup (for people who have none) — /products
  price_account_web: '17',
  // Premium page (/premium) — price test + stronger accounts. Its leads go to the manager unless an agent is tagged Premium.
  mgr_lines: 'funnel,premium', // which chats the MANAGER takes besides Agency (Agency = his “Receive new leads”). Admin → Agents → manager
  premium_on: '1',
  price_premium: '45', // Telegram price
  price_premium_web: '40', // website price
  premium_topup_pct: '3',
  premium_delivery: '30 minutes',
  premium_ad_budget: '0', // its OWN daily budget (Ad spend → Premium ads / day), not part of Agency
  spend_split: '0',
  ad_line_since: '', // {line: 'YYYY-MM-DD'} — when each ad spend line's daily budget started
  // retargeting ad sets (their ad links end with ?rt=1) — daily budgets, PART of the Agency / Funnel budgets; only for the Home "Retargeting only" view
  rt_budget_agency: '0',
  rt_budget_premium: '0',
  rt_budget_funnel: '0', // daily budget of the /premium ad set — only for the Premium vs Standard comparison
  // Retargeting offers — only for people who came from a retargeting ad (link ends with ?rt=1). Their chat keeps the offer for offer_days.
  offer_on: '1',
  offer_days: '7',
  offer_agency_price: '20', // normal ad account price for retargeted people (only used when lower than the normal price)
  offer_premium_free: '200', // Premium: first top-up 0% fee on up to this amount (0 = off). The Premium price never changes.
  offer_funnel_price: '40', // funnel: first month price
  offer_agency_text: 'This week only: ${offer_price} per account (normally ${normal_price}). Offer ends Sunday.',
  offer_premium_text: 'This week: 0% fee on your first top-up (up to ${offer_max}). Offer ends Sunday.',
  offer_funnel_text: 'This week only: first month ${offer_price} (normally ${normal_price}). Offer ends Sunday.',
  premium_badge: 'Premium · Strong profile accounts',
  premium_title: 'Premium agency ad account',
  premium_sub: 'Aged, strong-history profiles for bigger budgets',
  premium_bullets: 'Aged profiles with a strong history\nHandles higher daily spend\nPriority delivery within {delivery}\nUnlimited free replacements\nYour own dedicated agent',
  premium_headline: 'Premium agency ad accounts',
  premium_accent: 'with strong, aged profiles.',
  premium_seo_title: 'Premium Agency Ad Accounts — Strong, Aged Profiles | {brand}',
  premium_seo_description: 'Premium Meta agency ad accounts from {brand}: aged, strong-history profiles that handle higher daily spend. ${price_account} on Telegram, live within {delivery}, unlimited free replacements and a dedicated agent.',
  premium_text: 'Aged, strong-history ad accounts that handle bigger budgets. Live within {delivery}, unlimited free replacements, and your own dedicated agent on Telegram.',
  price_funnel_web: '50',
  web_orders_on: '0',
  topup_min: '30',
  // Website payments
  np_api_key: '',
  np_ipn_secret: '',
  np_currencies: 'usdtbsc,trx',
  np_coin_meta: '',                   // coins added from the NOWPayments list (JSON: code → name, network, ticker)
  pay_window_min: '60',
  // Agents can make crypto payment links from a Telegram chat (Telegram prices; top-ups + fee)
  agent_paylinks_on: '1',
  inr_on: '0',
  inr_rate: '90',
  // v130: campaign spend from Meta (our ad accounts) for the Campaigns table — token optional (else the BM's from Ad accounts)
  camp_acts: '',
  camp_token: '',
  upi_on: '0',
  upi_id: '',
  upi_name: '',
  manager_tg: '',
  // Emails (resend.com)
  resend_api_key: '',
  email_from: '',
  email_from_name: '',
  price_funnel: '50',
  delivery_time: '1 hour',
  payment_text: 'USDT or UPI',
  account_badge: 'Most ordered',
  account_title: 'Agency ad account',
  account_sub: 'Shared to your Business Manager within {delivery}',
  account_bullets: 'No spending limit\nNo 18% GST — US verified agency account\nTop-ups through your agent ({topup_fee} fee)\nHelp creating a BM if needed',
  account_cta: 'Get an ad account',
  funnel_badge: 'Done for you',
  funnel_title: 'Landing page and funnel',
  funnel_sub: 'From ad click to paying customer, built and run for you',
  funnel_bullets: 'Landing page with lead form\nLeads routed to your agents\nAdmin app and agent app\nServer-side Meta tracking',
  funnel_cta: 'Set up my funnel',
  chat_title: 'From first message to live account, in one chat',
  chat_text: 'No tickets, no dashboards to learn. Your agent stays with you in Telegram from the first question to every top-up after launch.',
  demo_agent_name: 'Rahul',
  why_title: 'Built for media buyers who can’t afford to wait',
  faq: 'Do I need a Business Manager? | Yes. The ad account is shared to your Facebook Business Manager. If you don’t have one, it is free to create at business.facebook.com and your agent will guide you.\nHow fast is delivery? | Within {delivery} of confirmed payment.\nHow do I pay? | {payment}. Your agent sends payment details in the Telegram chat.\nWho pays for the ad spend? | You do. The ${price_account} covers the account itself. You add funds for your campaigns through top-ups.\nWhat’s in the funnel setup? | A landing page with a qualifying form, Telegram routing to your agents, an admin app with an agent app, and server-side Conversions API tracking for leads and sales.',
  cta_title: 'Your next account is one message away.',
  cta_text: 'Answer three questions and continue on Telegram with your own agent.',
  footer_note: 'Meta agency ad accounts, live within {delivery}. Top-ups through your own agent.',
  channel_link: '',
  // Telegram channel: the bot (admin of the channel) makes a join link per visitor → join request → Meta "Subscribe" → approved
  channel_chat: '', // @username or -100… id of the channel (empty = taken from a public t.me/username link)
  channel_name: '', // shown in the top bar (empty = brand name)
  chan_bar_on: '1', // top bar on the landing pages (Agency + Funnel) shows the channel instead of the "Trusted by" text
  chan_bar_text: '{channel_name} on Telegram · Tips & offers',
  f_chan_bar_text: '', // Funnel page (empty = same as above)
  chan_bar_cta: 'Join',
  chan_auto_approve: '1',
  // v116: the bot's welcome message to everyone else who asks to join (website top bar, /telegram page, plain links) — once per person
  chan_join_dm_on: '1',
  admin_ring_off: '0',             // v140: admin phones never ring on silent / vibrate (per-person switch; global alarm_on still applies)
  chan_btn_img: '1',               // v140: the line's offer image goes with the bot welcome buttons (one photo message)
  img_on_replies: '0',             // v140: the image also on See pricing / What's included / WhatsApp button auto-replies (OFF = text only)
  chan_info_btns: '1',             // v139: See pricing / What's included answered in the bot welcome (no lead until they message support)
  chan_join_dm_text: 'Welcome to {brand}! Thanks for joining our channel.\n\nWhat we do for you:\n- Agency ad accounts from {price_agency}: no spending limit, no 18% GST on ad spend\n- Premium ad accounts: {price_premium}\n- Landing page + Telegram funnel: {price_funnel}/month\n\nShared to your Business Manager in {delivery}. Tap a service below to chat with our team.',
  chan_approve_req: '0', chan_approve_status: '', bot_send_error: '', fu_last_run: '',
  chan_img_welcome: '', // own image URL (https) for the welcome message; empty = built-in
  // v118: someone who already chats with our support account opens the bot again
  // v119: started the bot but never wrote to our support account → 3 reminders from the bot (same gaps + quiet hours as the normal follow-ups)
  bfu_on: '1',
  bfu1: 'Hi {name}, thanks for opening our bot. Our team is online on Telegram at {support}. Tap a button below to message us and we will help you get started.',
  bfu2: 'Hi {name}, just checking in. Our team at {support} is ready to help you. Tap below to send us a message.',
  bfu3: 'Hi {name}, last reminder from my side. Whenever you are ready, tap below and message {support}. We reply fast.',
  chan_back_text: 'Welcome back, {name}!\n\nYou already have an open chat with our support team ({support}). Your agent is there and will help you with everything.\n\nTap below to continue the conversation, or pick another service.',
  chan_sub_delay_min: '60', // Subscribe goes to Meta only if they are still in the channel after this many minutes (0 = at once)
  lead_ads_on: '1',         // Admin → More → What's running: lead ads (landing → Telegram). OFF = their cards are hidden on Home
  wa_ads_on: '0',           // v137: What's running → WhatsApp ads (chat button pages /…/whatsapp). OFF = their Home block / pickers hidden (money always counted)
  wa_comm_ads_on: '0',      // v137: What's running → WhatsApp community ads (/…/community pages)
  chan_ads_on: '1',         // Admin → More → What's running: channel ads (OFF = their parts are hidden on Home)
  ub_unarchive: '1',        // chat account: keep lead chats out of Telegram's Archived (+ “Archive and mute new chats” OFF)
  unarchive_status: '',
  // v111 channel ads (/agency|premium|funnel/telegram): bot DM on the join request, instant approve, bot services menu
  chan_ad_dm_on: '1',
  chan_ad_approve: '1',   // joins from the channel-ad pages are approved at once (other joins follow chan_auto_approve)
  chan_menu_on: '1',      // /start on the bot (channel post link) shows the services menu
  chan_dm_agency: 'Welcome to {brand}! Your request to join the channel is being approved.\n\nAgency ad account: {price_agency}\n- No spending limit from day one\n- No 18% GST on ad spend\n- Shared to your Business Manager in {delivery}\n- Top-up fee only {fee}\n\nTap the button below and our team will set it up for you.',
  chan_dm_premium: 'Welcome to {brand}! Your request to join the channel is being approved.\n\nPremium ad account: {price_premium}\n- No spending limit from day one\n- No 18% GST on ad spend\n- Shared to your Business Manager in {delivery}\n- Priority support\n\nTap the button below and our team will set it up for you.',
  chan_dm_funnel: 'Welcome to {brand}! Your request to join the channel is being approved.\n\nLanding page + funnel setup: {price_funnel}/month\n- A fast landing page for your business\n- Leads straight to your Telegram or WhatsApp\n- Meta tracking (CAPI) set up for you\n\nTap the button below to start your setup.',
  chan_dm_upsell: 'We also do:', // + the other services with prices, in the same message
  chan_pick_event: 'Contact',   // Meta event when they pick a service in the bot (phase 2 optimization): Contact · Lead · off
  chan_menu_text: 'Welcome to {brand}! What do you need?\n\nPick a service below to chat with our team.',
  chan_img_agency: '', chan_img_premium: '', chan_img_funnel: '', // own image URL (https) for the bot message; empty = built-in
  welcome_channel_on: '0', // add the channel line to the Telegram welcome message (OFF until the channel has some members)

  // Meta Conversions API
  pixel_id: '',
  capi_token: '',
  test_event_code: '',
  graph_version: 'v23.0',
  purchase_once: '1',

  // Telegram
  tg_mode: 'business',
  prefill_text: 'Hi! I want an agency ad account. My code: {code}',
  // Pre-typed WhatsApp message when the admin/agent taps WhatsApp on a lead ({tg_link} = that person's own Telegram link)
  wa_msg: 'Hi {name}! 👋 This is {brand}. You asked about an agency ad account on our website.\n\nTap here to chat with your agent on Telegram:\n{tg_link}\n\nOr just reply here if WhatsApp is easier for you.',
  welcome_on: '1',
  welcome_msg: 'Hi {name}! 👋 Thanks for reaching out. Your agent will reply here in a few minutes.',
  // "Chat with agent" button on the landing pages (same Telegram flow, own first message + own welcome)
  chat_btn_on: '1',
  // Ticker of REAL recent purchases / top-ups on the landing pages (first name + initial only)
  recent_on: '1',
  // Ticker fill — adds randomised sample entries when real data is sparse
  ticker_fill_on: '1',
  chat_btn_text: 'Chat with agent',
  chat_prefill_text: 'Hi! I have a question. My code: {code}',
  chat_welcome_msg: 'Hi {name}! This is {brand}. Tell me your question, I\'m right here.\n\nIn short, what we offer:\n- USA / Indian verified agency ad account: ${price_account} per account\n- Shared to your Business Manager within {delivery}\n- No spending limit, top-up fee only {topup_fee} (minimum top-up ${topup_min})\n\nTo get started, just tell me these 3 things:\n1. What do you run ads for?\n2. How many accounts do you need?\n3. Do you have a Business Manager (BM), or do you need one?',  welcome_delay_sec: '35',
  welcome_channel_line: 'Meanwhile, you can join our Telegram channel: {channel}',
  proof_text: 'Trusted by 1,000+ advertisers',
  proof_link: '',
  bot_token: '',
  bot_username: '',
  owner_username: '',
  owner_name: '',
  owner_id: '',
  // Telegram chat IDs that can send a proxy list to the bot for checking (comma separated)
  proxy_chat_ids: '8100797592',
  biz_conn_id: '',

  // Auto first message from the chat account (for people who filled the form but never wrote)
  auto_msg_on: '1',
  auto_msg_delay_min: '2',
  auto_msg_hour_cap: '20',
  auto_msg_text: 'Hi {name}! 👋 You asked for an agency ad account on {brand}. Reply here and your agent will set it up for you.',
  ub_api_id: '',
  ub_api_hash: '',
  ub_session: '',
  ub_me: '',
  ub_pause_until: '0',
  // v143: sending speed for ALL automatic messages, one line per channel (human sends are never delayed)
  pace_on: '1',
  pace_tga_gap: '90',      // Telegram chat account: seconds between automatic messages …
  pace_tga_jitter: '60',   // … plus a random 0–60 s
  pace_tga_hour: '20',     // max automatic messages per hour (0 = no cap)
  pace_tga_day: '120',     // max per 24 hours
  pace_tgb_gap: '3',       // Telegram bot (Bot API)
  pace_tgb_min: '30',      // per minute
  pace_wa_gap: '20',       // WhatsApp (WATI)
  pace_wa_jitter: '15',
  pace_wa_hour: '60',
  pace_first_hour: '5',    // first messages to people who never wrote to us
  pace_first_day: '30',
  pace_flood_h: '24',      // PEER_FLOOD → automatic chat-account messages pause this long
  pace_first_flood_h: '48',// any Telegram limit → stranger first messages pause this long
  pace_fw_margin: '30',    // FLOOD_WAIT_X → wait X + this many seconds
  fu_vary: '1',            // light wording changes so the same text doesn't go out 30 times
  ub_status: '',
  // Telegram chat folders on the chat account: one folder per agent with the chats that agent handles
  folders_on: '1',
  folders_sold_on: '1', // v148: a "Sold <agent>" folder next to each agent's folder
  // v150: Comments (Facebook Page + ads, Instagram ad posts) — Admin → Comments
  cm_on: '0', cm_auto: '0', cm_ai: '1', cm_every: '2', cm_words: '', cm_proxy: '',
  cm_app_id: '', cm_app_secret: '', cm_user_token: '', cm_token_exp: '', cm_page_id: '', cm_page_name: '', cm_page_token: '', cm_accts: '',
  cm_last_sync: '', cm_last_err: '', cm_warned: '',
  // v151: Ads data from Meta (master switch) — same app / token / proxy as Comments
  mads_on: '0', mads_since: '', mads_full: '', mads_line_map: '', mads_skip_accts: '', mads_last_sync: '', mads_last_err: '', mads_last_ok: '',
  folders_max: '100',
  folders_state: '',
  mute_agent_chats: '1',
  // Lead goes to the next agent if nobody replies in time (during working hours); after all agents → manager
  reassign_on: '1',
  reassign_min: '30',
  // v141: temporary cover — a covered chat with a deal in progress goes back to its owner after this many quiet hours;
  // a sale within this many days after the cover's last message counts for the cover (unless the owner talked with them since)
  cover_quiet_h: '72',
  cover_credit_days: '7',
  cover_max_days: '7', // a cover never lasts longer than this (then the chat goes back to its owner with a summary)
  work_hours: '9-22',
  // Save every lead as a contact on the chat account ("AdsBhai Lead 12"), rename to the customer's name when sold, delete when dead
  save_contacts: '1',
  calls_contacts_only: '1',
  calls_state: '',
  folders_order: '',
  folders_status: '',

  // Telegram didn't open? → offer the website order on the same screen
  // WhatsApp community (free — no Meta events at all)
  wa_on: '1', // MASTER switch: OFF = WhatsApp hidden everywhere (button, box, welcome line, agent number)
  wa_comm_link: 'https://chat.whatsapp.com/GD4bIf0GQ67510bihODcl9',
  wa_members: '1.4K+',
  wa_fab_on: '1', // round WhatsApp button above the chat button on the landing pages
  wa_fallback_on: '1', // "Telegram didn't open?" box offers WhatsApp
  wa_fallback_sec: '4',
  wa_fallback_text: 'No Telegram? Join our WhatsApp community for updates, offers and help.',
  welcome_wa_on: '1', // add the WhatsApp community line to the Telegram welcome message
  welcome_wa_line: 'Also on WhatsApp? Join our community: {wa_link}',
  wa_agent_on: '0', // "Chat with an agent on WhatsApp" in the box (OFF by default)
  wa_agent_number: '+1 646 270 7080',
  wa_agent_text: 'Hi! I want an agency ad account.',
  tg_fallback_on: '1',
  tg_fallback_sec: '20',
  tg_fallback_text: 'Looks like Telegram didn’t open. No problem — you can place your order directly on our website.',
  // PageView + ViewContent only after the visitor has looked at the page this long (seconds, tab visible)
  vc_delay_sec: '5',
  // "X+ people are viewing this" banner — minimum number shown (0 = hide banner)
  viewer_floor: '72',
  // the number moves randomly between these two (plus real visitors on the page right now)
  viewer_min: '76',
  viewer_max: '191',

  // Agents
  quick_replies: 'An agency ad account is ${price_account} ({price_account_inr} INR).\nDelivery is within {delivery} after payment.\nWe accept {payment}.\nPlease send your Business Manager ID so we can share the account.\nYour account is live. You can start your campaigns now.',
  fu_auto: '1',                      // '1' = follow-ups 1-3 are sent automatically through Telegram Business; '0' = the agent is reminded to send them
  fu_hours: '12,24,24',
  dead_hours: '24',
  // Dead chats get one message after 7 days and one after 15 days (they stay in Dead; a reply brings them back)
  revive_on: '1',
  revive_days: '7,15',
  revive1: 'Hi {name} 👋 Just checking in from {brand}. Still planning to run Meta ads? Agency ad accounts go live within {delivery}, from ${price_account}. Reply here and we\'ll set you up.',
  revive2: 'Hi {name}, one last check from {brand} 🙂 If you need a Meta agency ad account (no spending limit, fast top-ups), just reply to this message and an agent will help you right away.',
  quiet_hours: '22-9',
  fu1: 'Hi {name}, just checking in. Do you still need the ad account? 🙂',
  fu2: 'Hi {name}, accounts are in stock right now. Want me to reserve one for you?',
  fu3: 'Hi {name}, last reminder from my side. Reply here anytime and I will set you up.',
  topup_comm_pct: '3',
  // ===== Profit per agent (Team → Leaderboard) =====
  max_discount_pct: '40',            // v144: an agent may lower the price per account by at most this % (manager / admin: any price > 0)
  acct_cost: '3',                    // what one ad account costs us (USD) — taken off each account sale
  ad_budget_agency: '40',            // daily Meta ad budget (USD) for the Agency page; added to Ad spend every day by itself (edit any day there)
  ad_budget_funnel: '10',            // same for the Funnel page
  ad_budget_wa_agency: '0', ad_budget_wa_premium: '0', ad_budget_wa_funnel: '0', // v135 WhatsApp ad pages (/agency|premium|funnel/whatsapp + /community), $/day
  ad_budget_ch_agency: '0', ad_budget_ch_premium: '0', ad_budget_ch_funnel: '0', // v114 channel-ad pages (/agency|premium|funnel/telegram), $/day
  ad_budget_telegram: '0',           // same for the /telegram channel page (Subscribe ads); 0 = no ads running
  ad_auto_since: '',
  // ===== Meta BMs & ad accounts (Admin → Ad accounts) =====
  meta_enabled: '0',                 // master switch. OFF = setup mode: admin/manager can add BMs and test; agents, payment links and auto sync don't use it
  // messages to the client (sent from the chat account, like the agent). {act} {bm} {email} {amount} {balance}. Never mention the account type.
  meta_client_msgs: '1',
  meta_email_invites: '0',           // '1' = clients without a BM can get an email invite to our BM (only the manager sends it)
  meta_msg_share: '✅ Your ad account is ready!\nAd account ID: {act}\nShared to your Business Manager ({bm}).\nVerified business since {verified}\nOpen business.facebook.com → Business settings → Ad accounts to see it.\nBalance: {balance}',
  meta_msg_invite: '✅ Your ad account is ready!\nWe sent an invite to {email}. Open the email from Facebook and tap Accept.\nAfter that, ad account {act} shows in your Ads Manager.\nBalance: {balance}',
  meta_msg_invite_ok: '✅ Invite accepted. Ad account {act} is now in your Ads Manager.',
  meta_msg_topup: '💰 Top-up done: {amount} added to ad account {act}.\nBalance now: {balance}',
  // v155: low balance → the client is told; every automatic Ad-account message and channel post ends with this line
  meta_msg_low: '⚠️ Low balance on your ad account {act}: {balance} left.\nTop up now so your ads keep running.',
  meta_auto_footer: '🤖 Automatic message · live data from the Meta API',
  // v156: replacement account (old one stopped working) and a top-up the manager did by hand (account not in the system)
  meta_msg_replace: '✅ Your ad account has been successfully replaced. This is your new account:\nAd account ID: {act}\nShared to your Business Manager ({bm}).\nVerified business since {verified}\nBalance: {balance}',
  meta_msg_topup_hand: '💰 Top-up done: {amount} added to your ad account {act}.',
  meta_msg_topup_req: '🧾 This is your ad account: {act}\nYour top-up request of {amount} has been sent to our manager. You will get a message with the screenshot as soon as it is added.',
  meta_names_v157: '',
  meta_digest_on: '1',              // v158: daily top-up post (channel albums + story)
  meta_digest_time: '22:00',        // India time
  meta_digest_last: '',              // v157: old client account names renamed once
  meta_digest_busy: '',              // v163: the top-up post is being sent (time) — one at a time
  v165_topups: '',                  // v165: earlier top-ups saved in Sales once
  synced_build: '',                 // v165: the build the last "sync everything after an update" ran for
  meta_shot_wait: '0',               // v159: channel post / story wait for the client-chat screenshot (uploaded by the team)
  meta_story_on: '1',                // v156: every delivery also posted as a Telegram story (9:16) from the chat account
  meta_sync_min: '360',              // how often every BM is read from Meta (6 hours; actions always read fresh)
  meta_name_pattern: '{brand} {n}',
  meta_rename_new: '0',              // '1' = new accounts get the pattern name when imported
  meta_low_usd: '15',                // tell the agent when a client's balance falls under this
  meta_lock_usd: '0.1',              // spend limit kept on a free account (nobody can spend more)
  meta_cap_unit: '',                 // auto: how Meta reads spend-limit writes ('usd' or 'cents'), learnt on first top-up
  // v152: profiles behind one iProxy line — the IP changes before each profile's work, one profile at a time
  mq_proxy: '',                      // the iProxy proxy (http/socks5) every profile's Meta call goes through (never the server IP)
  mq_ip_link: '',                    // iProxy "Change IP by URL" link
  mq_ip_at: '', mq_ip: '', mq_ip_profile: '', mq_ip_used: '', // v154: which profile the current IP belongs to + when it was last used           // last IP change time / last IP seen through the proxy
  mq_wait_s: '20',                   // seconds to wait after the change link before checking the new IP
  mq_country: 'IN',                  // the new IP must be in this country ('' = any)
  mq_auto_sync: '1',                 // hourly auto sync ON/OFF (only while the system is ON)
  mq_every_min: '60',
  mq_partner_hand: '1',              // v153: Meta blocks partner assign for new apps (#3) → the manager assigns it in Business Settings, the system checks it and does the rest
  mq_auto_approve: '1',              // master: paid + in stock + agent allowed → shared without the manager (chat, payment link, website)
  meta_cat_usd: '100',               // Meta daily limit ≥ this = Premium account, below = $25 account
  meta_post_on: '0',                 // post every share to the Telegram channel
  meta_post_chat: '',                // channel @username or -100… id (the bot is admin there)
  meta_post_next: '151',             // the next "Client #" number
  meta_proof_client: '1',            // send the 2 proof images to the client after a share
  default_cc: '91',
  tz_offset_min: '330',

  // ===== FUNNEL business (page: /funnel). Empty message fields fall back to the agency ones. =====
  // Its own Meta pixel / dataset (empty = events go to the agency pixel)
  f_pixel_id: '',
  f_capi_token: '',
  f_test_event_code: '',
  // v131: WhatsApp chats through WATI (coexistence: the Business app keeps working on the same number)
  wati_on: '0', // MASTER switch for the whole WhatsApp chat system (webhook, sending, pages, follow-ups, events)
  wati_url: 'https://live-mt-server.wati.io', // API endpoint (WATI → API Docs)
  wati_token: '',
  wati_hook: '', // secret part of our webhook URL (made once)
  // v137: WATI Pro plan extras (all OFF while wati_pro='0': no extra API calls)
  wati_pro: '0', // "We're on the WATI Pro plan"
  wati_buttons: '1', // Pro: tap-to-answer list menu + buttons after the welcome
  wati_status_sync: '1', // Pro: chat sold / dead / deleted → SOLVED in WATI, customer writes again → OPEN
  wati_attr_sync: '1', // Pro: contact attributes adsbhai_line / status / agent / accounts / lead_id
  wati_btn_img: '1', // v140: Pro buttons welcome with the line's offer image as the header
  wati_plain_img: '1', // v140: normal WhatsApp (no Pro buttons): the offer image as its own message before the plain welcome
  wati_btn_agency: "💰 See pricing, 📦 What's included, ✅ Get account", // Pro: buttons under the WhatsApp welcome (comma separated, max 3, 20 characters each)
  wati_btn_premium: "💰 See pricing, 📦 What's included, 💎 Buy Premium",
  wati_btn_funnel: "💰 See pricing, 📦 What's included, 📈 Start my funnel",
  // v138 (Pro): automatic reply per welcome button, JSON { agency|premium|funnel: { "<label>": { text, voice, buttons } } }. Empty = built-in replies (btnreplies.ts)
  wati_btn_replies: '',
  wati_sync_phone: '1', // any plan: replies typed in the WhatsApp Business app are pulled from WATI into our chat
  wa_number: '+1 646 270 7080', // the WhatsApp number customers message
  wa_prefill: 'Hi! I want {what}. My code: {code}', // pre-typed message from the /…/whatsapp pages
  wa_ai_on: '1', // AI replies on WhatsApp chats (same AI as Telegram, same agents)
  wa_fu_on: '1', // WhatsApp follow-ups inside the 24-hour window
  wa_fu_hours: '6,12', // follow-up 1 and 2 after our last message (hours)
  wa_fu_last_min: '15', // last follow-up this many minutes before the 24-hour window closes
  wa_lead_turns: '2', // Lead goes to Meta after the customer replied this many times to our messages
  wa_pixel_id: '', wa_capi_token: '', wa_test_event_code: '', // Meta pixel for WhatsApp chats: Agency + Premium
  wa_f_pixel_id: '', wa_f_capi_token: '', wa_f_test_event_code: '', // Meta pixel for WhatsApp chats: Funnel
  wa_page_title: 'Chat with us on WhatsApp',
  wa_page_text: 'Tap the button, WhatsApp opens with a message ready. Just press send and our team replies in a few minutes.',
  wa_comm_page_title: 'Join our WhatsApp community',
  wa_comm_page_text: 'Enter your WhatsApp number and join. Offers, tips and help from our team, every day.',
  // Funnel leads: '0' = only the manager, '1' = round-robin between agents tagged "Funnel" (then the manager)
  funnel_to_agents: '0',
  // Funnel landing page text
  f_badge: 'Done-for-you lead funnels',
  f_headline: 'Get leads on autopilot with a funnel',
  f_accent: 'built for you.',
  f_sub: 'A landing page, a qualifying form and Telegram routing to your sales team, with Meta tracking set up right. We build it, you close the leads.',
  f_why_title: 'A funnel that brings you buyers, not just clicks',
  f_faq: 'What do I get? | A landing page with a short qualifying form, every lead sent to your sales team on Telegram, an admin app with an agent app, and server-side Meta tracking (Conversions API).\nHow long does setup take? | Usually 2 to 3 days after we get your offer details.\nDo I need my own ad account? | Yes, ads run from your own ad account. If you need one, we also provide agency ad accounts from ${price_account}.\nHow do I pay? | {payment}. Your manager sends the details on Telegram.\nIs there a monthly fee? | Yes, ${price_funnel} per month covers hosting, the apps and support.\nCan you change the page later? | Yes. Tell your manager on Telegram and we update it.',
  f_cta_title: 'Ready for leads that actually reply?',
  f_cta_text: 'Answer two quick questions and talk to your funnel manager on Telegram.',
  f_seo_title: '{brand} — Done-for-you lead funnels for Meta ads',
  f_seo_description: 'Landing page, qualifying form, Telegram lead routing and Meta Conversions API tracking, built and run for you. ${price_funnel} per month.',
  // Funnel bot messages
  f_prefill_text: 'Hi! I want a landing page and funnel. My code: {code}',
  f_wa_msg: 'Hi {name}! 👋 This is {brand}. You asked about a landing page and funnel for your business on our website.\n\nTap here to talk to your funnel manager on Telegram:\n{tg_link}\n\nOr just reply here if WhatsApp is easier for you.',
  f_welcome_msg: 'Hi {name}! 👋 Thanks for your interest in a funnel from {brand}. Your funnel manager will reply here in a few minutes.',
  f_chat_welcome_msg: 'Hi {name}! This is {brand}. Tell me your question, I\'m right here.\n\nWe set up a complete funnel for your business:\n- A landing page that brings in leads\n- Full Meta ads setup\n- Leads straight to your WhatsApp\nPrice: ${price_funnel}\n\nTo get started, just tell me these 3 things:\n1. What is your business?\n2. Which city / country do you want customers from?\n3. What daily ad budget do you have in mind?',  f_auto_msg_text: 'Hi {name}! 👋 You asked about a landing page and funnel on {brand}. Reply here and your manager will walk you through it.',
  f_quick_replies: 'The funnel setup is ${price_funnel} per month.\nIt includes a landing page, a lead form, Telegram routing to your team and Meta tracking.\nSetup takes 2 to 3 days.\nWhat do you sell, and who is your customer?\nWe accept {payment}.',
  f_fu1: 'Hi {name}, just checking in. Do you still want the funnel set up? 🙂',
  f_fu2: 'Hi {name}, we have a setup slot free this week. Want me to book it for you?',
  f_fu3: 'Hi {name}, last reminder from my side. Reply here anytime and we will build your funnel.',
  f_revive1: 'Hi {name} 👋 Just checking in from {brand}. Still looking for more leads from Meta ads? A ready funnel is ${price_funnel} per month. Reply here and we\'ll set it up.',
  f_revive2: 'Hi {name}, one last check from {brand} 🙂 If you want a landing page and funnel that sends leads straight to your team, just reply to this message.',

  // Push notifications
  fcm_service_account: '',

  // Internal
  admin_pass_hash: '',
  rr_last: '0',
  rr_last_f: '0',
  rr_last_p: '0',
  rr_call_p: '0',
  // ---- AI (Admin → AI). Everything OFF by default except the agent coach (works once the key is set) ----
  ai_key: '',                        // Anthropic API key
  ai_model: 'claude-haiku-5-5',      // cheapest Claude model
  ai_coach_model: 'claude-opus-5-5', // v134: the coach (suggestions for agents) uses the strongest model — expert advice
  ai_price_in: '1',                  // $ per million input tokens (for the cost meter)
  ai_price_out: '5',                 // $ per million output tokens
  ai_daily_cap: '3',                 // stop all AI calls for the day after this many $ (0 = no cap)
  ai_coach_on: '1',                  // reply suggestions + next step for agents/manager in every chat
  ai_auto_on: '0',                   // AI answers chats by itself
  ai_auto_agents: '',                // …only the chats of these agent ids (comma list)
  ai_wait_sec: '25',                 // wait this long after the customer's last message (they often send several)
  ai_human_hold_min: '30',           // a person wrote in the chat within this time → AI stays quiet
  ai_min_score: '90',                // auto-reply can be switched on only when the Test Lab score is at least this
  ai_last_score: '',
  ai_knowledge: '',                  // empty = built-in knowledge sheet
  ai_fu_on: '1',                     // hot leads (they replied at least once): AI writes the follow-ups — only with the key + Test Lab score
  ai_fu_hours: '4,24,72',            // hot-lead follow-up gaps (hours)
  ai_fu_dead_hours: '48',            // hot lead → Dead this long after the 3rd follow-up
  ai_seed_ver: '0',
  ai_voice_on: '0',                  // send a voice note (ElevenLabs) when the customer shows interest
  ai_voice_mode: 'interest',         // when: interest (AI decides) | every (every Nth AI reply) | mirror (when the customer sent a voice note)
  ai_voice_every: '3',               // mode every: every Nth reply
  ai_voice_max: '3',                 // max AI voice notes in one chat (0 = no limit)
  ai_voice_volume: '-3',             // voice loudness in dB: -6 softer · -3 a bit softer (default) · 0 normal · 3 louder
  ai_voice_speed: '0.9',             // voice note speed: 1 = as made, 0.9 = a bit slower (default), 0.82 = slow
  ai_voice_bg: 'office',             // background under voice notes: office (keyboard + people far away, made once) | fan
  ai_voice_noise: 'light',           // room sound under the voice: off | light | medium
  team_voice_id: '',                 // v110: own ElevenLabs voice for TEAM voice notes (empty = the main voice, AI → Setup)
  team_voice_gender: 'female',       // that voice is a woman / man → how the words are rewritten (deti hun / deta hun)
  team_voice_style: 'female_words',  // female_words: their words → female wording → our voice (Eleven v4) · same: voice changer, their exact way of speaking
  welcome_voice_on: '0',             // a short AI voice note a little after the welcome message (new leads from the ads)
  welcome_voice_delay_sec: '25',     // seconds after the welcome
  welcome_voice_text: 'Hello sir, {brand} mein aapka welcome. Main aapki ad account setup mein help karungi. Bas ek baar bata dijiye aap kis cheez ke ads run karte ho, phir hum aage start karte hain.',
  welcome_voice_text_f: 'Hello sir, {brand} mein aapka welcome. Hum aapke business ke liye poora funnel setup kar dete hain, landing page, ads aur leads seedha aapke WhatsApp pe. Bas ek baar bata dijiye aapka business kya hai.',
  welcome_voice_text_c: 'Hello sir, maine aapko upar sab likh diya hai, price aur top-up sab. Aapka jo bhi sawaal hai yahin pooch lijiye, aur upar wali teen cheezein bata dijiye, phir hum aage start karte hain.', // "Chat with agent" people ("Hi! I have a question…"). Empty = no voice for them
  welcome_voice_text_cf: 'Hello sir, maine aapko upar saari details bhej di hain. Bas upar wali chaar cheezein bata dijiye, aapka business kya hai aur leads kahan chahiye, phir main aapka funnel setup start karwa deti hun.',
  welcome_voice_text_m: 'Namaste sir, ye {brand} ka ek automatic voice note hai. Saari details upar bhej di hain. Bas jo aapko chahiye uska number reply kar dijiye, ek, do, teen ya chaar. Hamari team se ek agent thodi der mein khud aapse baat karega.', // v133: people who came with no link (got the menu)
  notif_sound: 'default',            // v134: 'default' = built-in alert, 'own' = the sound the admin uploaded
  notif_sound_file: '',
  notif_sound_ver: '0',
  alarm_on: '1',
  alarm_scope: 'all',                // v136: 'all' = every new customer message rings on silent / vibrate too; 'leads' = only new leads                     // v134: new-lead alert rings on every team phone even on silent / vibrate (admin decides, working hours only)
  menu_on: '1',                      // v133: no link (wrote directly, Telegram or WhatsApp) → the 1/2/3/4 menu instead of the Agency welcome; their answer sets the chat type
  menu_msg: "Hi {name}! 👋 Welcome to *{brand}*\n_Meta agency ad accounts & funnels, trusted by 1,000+ advertisers_\n\nReply with a number 👇\n\n*1️⃣ Agency Ad Account · ${price_account}*\nLive in {delivery} · No spending limit · No 18% GST\n\n*2️⃣ Premium Ad Account · ${price_premium}* ⭐\nAged strong profile & verified BM · Bigger budgets · Ready in {delivery_premium}\n\n*3️⃣ Landing Page + Funnel · ${price_funnel}/month*\nDone for you · Leads straight to your WhatsApp\n\n*4️⃣ Something else*\nTalk to our team\n\nA real person replies in a few minutes 🙂\n🌐 adsbhai.com",
  btn_voice_cache: '',               // v138 auto: voice notes made for the WhatsApp button auto-replies (same text → made once)
  welcome_voice_cache: '',           // auto: Telegram file ids of the made welcome voice notes (same text → made once, then re-used for free)
  team_voice_change: '0',            // agent / manager / admin voice notes from the apps → turned into our voice (ElevenLabs voice changer) + room sound
  el_key: '',
  el_voice_id: 'IDtcuDsxYTOIGN7AjCvp',  // Akash's pick (ElevenLabs → Voices → ⋮ → Copy voice ID)
  el_model: 'eleven_v4',             // eleven_v4 (best, Text-to-Dialogue API) · eleven_v3 · eleven_multilingual_v2 · eleven_flash_v2_5 (cheapest)
  rr_call: '0',                      // round-robin for the call list (form-only leads), separate from the chat rotation
  rr_call_f: '0',
  logo_file: '',
  logo_ver: '0',
  // 'auto' = logo made from the brand's first letter in each landing page's colours; 'upload' = the uploaded logo
  logo_mode: 'auto',
  // "Meta Business Partner" badge on the landing pages (turn on only if you are listed in Meta's partner directory)
  partner_on: '1',
  partner_text: 'Meta Business Partner',
  // blue verified tick after the brand name on the landing pages
  brand_verified: '1',
  // v167: Daily reel (Admin → More → Daily reel; saved by reel/settings_save, not by the Settings page)
  reel_on: '0', reel_max: '4', reel_gap_h: '3', reel_first_full: '1', reel_skip_later: '1', reel_styles: 'A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T' /* v168: + E–T */, reel_who: 'agents', reel_people: '', reel_seeded: '',
  // v167: forced app update (Admin → System → Force update). Empty minimum = the first v167 APK build (version.json "v167")
  app_force_update: '1', min_app_build_agent: '', min_app_build_admin: '',
  // v168: status videos + agents' reel download (Admin → More → Status video; saved by svid/settings, not by the Settings page)
  svid_on: '0', svid_formats: '', svid_fmt_last: '', svid_fmt_last_l: '', svid_agent_dl: '0', svid_formats_v175: '', svid_tall: '1', svid_redo: '', svid_night: '', svid_night_note: '', svid_worker: '', svid_install: '', svid_install_n: '0',
};
export type Settings = typeof DEFAULTS;
export type SettingKey = keyof Settings;

export const SECRET_KEYS: SettingKey[] = ['ai_key', 'el_key', 'capi_token', 'f_capi_token', 'bot_token', 'fcm_service_account', 'ub_api_hash', 'ub_session', 'np_api_key', 'np_ipn_secret', 'resend_api_key', 'camp_token', 'wati_token', 'wa_capi_token', 'wa_f_capi_token', 'cm_app_secret', 'cm_user_token', 'cm_page_token', 'cm_proxy', 'mq_proxy', 'mq_ip_link'];
export const AUTO_KEYS: SettingKey[] = ['fu_last_run', 'bot_send_error', 'chan_approve_req', 'chan_approve_status', 'unarchive_status', 'welcome_voice_cache', 'btn_voice_cache', 'bot_username', 'owner_name', 'owner_id', 'biz_conn_id', 'admin_pass_hash', 'rr_last', 'rr_last_f', 'rr_last_p', 'rr_call', 'rr_call_f', 'rr_call_p', 'ub_session', 'ub_me', 'ub_pause_until', 'ub_status', 'folders_state', 'folders_status', 'calls_state', 'folders_order', 'logo_file', 'logo_ver', 'notif_sound_file', 'notif_sound_ver', 'meta_cap_unit', 'ad_auto_since', 'ai_last_score', 'ai_seed_ver', 'contacts_ver', 'spend_split', 'ad_line_since', 'cm_app_secret', 'cm_user_token', 'cm_page_token', 'cm_proxy', 'cm_app_id', 'cm_token_exp', 'cm_page_id', 'cm_page_name', 'cm_accts', 'cm_last_sync', 'cm_last_err', 'cm_warned', 'cm_on', 'cm_auto', 'cm_ai', 'cm_every', 'cm_words', 'mads_on', 'mads_since', 'mads_full', 'mads_line_map', 'mads_skip_accts', 'mads_last_sync', 'mads_last_err', 'mads_last_ok', 'mq_ip_at', 'mq_ip', 'mq_ip_profile', 'mq_ip_used', 'meta_post_next', 'reel_on', 'reel_max', 'reel_gap_h', 'reel_first_full', 'reel_skip_later', 'reel_styles', 'reel_who', 'reel_people', 'reel_seeded', 'app_force_update', 'min_app_build_agent', 'min_app_build_admin', 'svid_on', 'svid_formats', 'svid_fmt_last', 'svid_fmt_last_l', 'svid_agent_dl', 'svid_tall', 'svid_formats_v175', 'svid_redo', 'svid_night', 'svid_night_note', 'svid_worker', 'svid_install', 'svid_install_n']; // v168: svid_*
export type Biz = 'agency' | 'funnel';
/** Which business a lead/chat belongs to (routing, messages). Same rule as the leads.biz column. */
export const bizOf = (l: { service?: string | null; line?: string | null } | null | undefined): Biz =>
  l && (l.service === 'funnel' || (l.service === 'chat' && l.line === 'funnel')) ? 'funnel' : 'agency';
const F_MSG = ['prefill_text', 'wa_msg','welcome_msg', 'chat_welcome_msg', 'auto_msg_text', 'quick_replies', 'fu1', 'fu2', 'fu3', 'revive1', 'revive2'] as const;
/** Settings with the funnel's own bot messages swapped in (empty funnel fields keep the agency text). */
export function msgFor(s: Settings, biz: Biz): Settings {
  if (biz !== 'funnel') return s;
  const o = { ...s } as Record<string, string>;
  for (const k of F_MSG) { const v = (s as Record<string, string>)['f_' + k]; if (v && v.trim()) o[k] = v; }
  return o as Settings;
}
/** Who may take this chat: Agency, Funnel or Premium (Premium = agency chats from /premium). */
export type Route = Biz | 'premium';
export const routeOf = (l: { service?: string | null; line?: string | null; tier?: string | null } | null | undefined): Route =>
  bizOf(l) === 'agency' && l?.tier === 'premium' ? 'premium' : bizOf(l);

/* ---- Retargeting offers ---- */
/** Came from a retargeting ad: the ad link ends with ?rt=1 */
export const isRtUrl = (u: unknown) => /[?&]rt=1(?:[&#]|$)/.test(String(u || ''));
type LeadLike = { service?: string | null; line?: string | null; tier?: string | null; offer_until?: number | null } | null | undefined;
const nn = (v: unknown) => { const x = parseFloat(String(v)); return Number.isFinite(x) ? x : 0; };
export type Offer = { route: Route; text: string; agent: string; price?: number; was?: number; free?: number };
/** This week's offer for one line (Agency, Premium, Funnel) — null when off or not set up (an offer price must be lower than the normal price). */
export function offerOf(s0: Settings, route: Route): Offer | null {
  if (s0.offer_on !== '1') return null;
  if (route === 'premium') {
    const free = nn(s0.offer_premium_free);
    if (!(free > 0) || s0.premium_on !== '1') return null;
    return { route, free, text: fmt(s0.offer_premium_text, s0, { offer_max: String(free) }), agent: `🎁 Offer: first top-up 0% fee (up to $${free})` };
  }
  const F = route === 'funnel';
  const price = nn(F ? s0.offer_funnel_price : s0.offer_agency_price), was = nn(F ? s0.price_funnel : s0.price_account);
  if (!(price > 0 && price < was)) return null;
  const v = { offer_price: String(price), normal_price: String(was) };
  return { route, price, was, text: fmt(F ? s0.offer_funnel_text : s0.offer_agency_text, s0, v), agent: F ? `🎁 Offer: first month $${price} (normal $${was})` : `🎁 Offer: collect $${price} / account (normal $${was})` };
}
/** Settings with the offer price swapped in (Agency: account price, Funnel: monthly price; the website price never goes above it). */
export function applyOffer(s: Settings, o: Offer | null): Settings {
  if (!o || o.price == null) return s;
  const low = (v: string) => String(nn(v) > 0 ? Math.min(nn(v), o.price!) : o.price);
  return o.route === 'funnel' ? { ...s, price_funnel: String(o.price), price_funnel_web: low(s.price_funnel_web) } : { ...s, price_account: String(o.price), price_account_web: low(s.price_account_web) };
}
/** The offer this chat still has (tagged when they came from a retargeting ad, for offer_days days). */
export const leadOffer = (s0: Settings, l: LeadLike): Offer | null => (l && nn(l.offer_until) > Date.now() ? offerOf(s0, routeOf(l)) : null);
/** When a lead from a retargeting ad keeps its offer until (ms) — null when no offer applies. */
export function offerUntil(s0: Settings, route: Route, rt: boolean): number | null {
  if (!rt || !offerOf(s0, route)) return null;
  return Date.now() + Math.min(30, Math.max(1, nn(s0.offer_days) || 7)) * 24 * 3600 * 1000;
}

export type Tier = '' | 'premium';
export const tierOf = (t: unknown): Tier => (t === 'premium' ? 'premium' : '');
/** Settings with this tier's prices swapped in: Premium → its own Telegram/website price, top-up fee and delivery time.
 *  Every price the customer or the agent sees for a Premium lead comes through here. */
export function tierFor(s: Settings, tier: unknown): Settings {
  if (tierOf(tier) !== 'premium') return s;
  return { ...s, price_account: s.price_premium || s.price_account, price_account_web: s.price_premium_web || s.price_premium || s.price_account_web, price_account_full: s.price_premium_full || s.price_account_full,
    topup_comm_pct: s.premium_topup_pct || s.topup_comm_pct, delivery_time: s.premium_delivery || s.delivery_time };
}
/** Messages + prices for one lead (funnel texts, Premium prices). */
export const forLead = (s: Settings, l: LeadLike) => applyOffer(tierFor(msgFor(s, bizOf(l)), l?.tier), leadOffer(s, l));
/** Retargeting offer chats: quick replies + follow-ups with the offer price (null = use the normal ones). */
export function offerTexts(s0: Settings, l: LeadLike) {
  if (!leadOffer(s0, l)) return null;
  const s = forLead(s0, l);
  return { quick_replies: lines(fmt(s.quick_replies, s)), fu: [fmt(s.fu1, s), fmt(s.fu2, s), fmt(s.fu3, s)] };
}
/** Prices for one lead without the funnel message swap (Premium prices + the retargeting offer). */
export const priceFor = (s: Settings, l: LeadLike) => applyOffer(tierFor(s, l?.tier), leadOffer(s, l));
/** What the agent must charge in this chat (shown on top of the chat): Telegram price, website price, top-up fee, delivery. */
export function leadPrices(s0: Settings, l: NonNullable<LeadLike>) {
  const o = leadOffer(s0, l);
  const s = applyOffer(tierFor(s0, l.tier), o);
  const n = (v: string) => Number(v) || 0;
  return { tier: tierOf(l.tier), biz: bizOf(l), account: n(s.price_account), web: s0.web_orders_on === '1' ? n(s.price_account_web) : 0, funnel: n(s.price_funnel), topup_pct: n(s.topup_comm_pct), delivery: s.delivery_time,
    offer: o ? { label: o.agent, until: Number(l.offer_until) || 0, free: o.free || 0 } : null };
}

/** Settings with the right Meta pixel for the landing page the person came from. Funnel without its own pixel → agency pixel. */
export function pixelFor(s: Settings, line: string | null | undefined): Settings {
  // v131: WhatsApp chats have their own pixels (Agency + Premium · Funnel) — never the Telegram ones
  if (line === 'wa_agency') return { ...s, pixel_id: s.wa_pixel_id, capi_token: s.wa_capi_token, test_event_code: s.wa_test_event_code };
  if (line === 'wa_funnel') return { ...s, pixel_id: s.wa_f_pixel_id, capi_token: s.wa_f_capi_token, test_event_code: s.wa_f_test_event_code };
  if (line !== 'funnel' || !s.f_pixel_id || !s.f_capi_token) return s;
  return { ...s, pixel_id: s.f_pixel_id, capi_token: s.f_capi_token, test_event_code: s.f_test_event_code };
}

/** True when the uploaded logo should be used (one is uploaded and the mode is 'upload'). */
export const usesUploadedLogo = (s: Settings) => !!s.logo_file && s.logo_mode === 'upload';

export const THEMES = ['purple', 'green', 'blue', 'gold'] as const;
export type Theme = (typeof THEMES)[number];

let cache: { at: number; s: Settings } | null = null;
let upgraded = false;
/** Replace earlier default texts that were saved unchanged (keeps anything the admin wrote). */
export function upgradeOldDefaults() {
  upgraded = true;
  const old: [string, string][] = [
    ['price_account', '15'], ['tg_note', 'You order and chat with your agent on Telegram. No signup.'], ['proof_text', '1000+ members already use our ad accounts'], ['account_bullets', 'Your own BM, your own campaigns\nTop-ups through your agent\nHelp creating a BM if needed\nYou pay Meta for your ad spend'],
    ['footer_note', 'Not affiliated with Meta Platforms, Inc.'],
    ['payment_text', 'USDT, UPI or bank transfer'],
    ['price_account_full', '50'],
    ['chat_welcome_msg', 'Hi {name}! 👋 Thanks for messaging {brand}. An agent will reply here in a few minutes — ask us anything.'],
    ['f_chat_welcome_msg', 'Hi {name}! 👋 Thanks for messaging {brand}. Your funnel manager will reply here in a few minutes. Ask us anything.'],
    ['faq', 'Do I need a Business Manager? | Yes. The ad account is shared to your Facebook Business Manager. If you don’t have one, it is free to create at business.facebook.com and your agent will guide you.\nHow fast is delivery? | Within {delivery} of confirmed payment.\nHow do I pay? | {payment}. Your agent sends payment details in the Telegram chat.\nWho pays for the ad spend? | You do. The ${price_account} covers the account itself. You add funds for your campaigns through top-ups.\nWhat’s in the funnel setup? | A landing page with a qualifying form, Telegram routing to your agents, an admin app with an agent app, and server-side Conversions API tracking for leads and sales.\nDo Meta’s ad policies still apply? | Yes. Every ad must follow Meta’s Advertising Standards. Accounts used for policy violations can be restricted by Meta.'],
  ];
  for (const [k, v] of old) run('DELETE FROM settings WHERE k=? AND v=?', k, v);
}

export function getSettings(): Settings {
  if (cache && Date.now() - cache.at < 1500) return cache.s;
  if (!upgraded) upgradeOldDefaults();
  const s = { ...DEFAULTS };
  for (const r of all<{ k: string; v: string }>('SELECT k, v FROM settings')) if (r.k in s) (s as Record<string, string>)[r.k] = r.v ?? '';
  cache = { at: Date.now(), s };
  return s;
}

export function setSetting(k: SettingKey, v: unknown) {
  run('INSERT INTO settings(k, v) VALUES(?, ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v', k, String(v ?? ''));
  cache = null;
}

/** USD amount -> rupees at the admin's "1 USD = ? INR" rate, rounded up, Indian digit grouping (2,300 / 1,00,000). */
export function toInr(usd: string | number, s: Settings) {
  const rate = Number(s.inr_rate) || 0, n = Number(usd);
  if (!rate || !Number.isFinite(n)) return '';
  return Math.ceil(n * rate).toLocaleString('en-IN');
}

/** Replace {brand} {delivery} {payment} {price_account} {price_funnel} ... placeholders (+ their _inr versions). */
export function fmt(text: string, s: Settings, extra: Record<string, string> = {}) {
  const web = s.price_account_web || s.price_account, funnelWeb = s.price_funnel_web || s.price_funnel, min = s.topup_min || '30';
  const map: Record<string, string> = {
    brand: s.brand_name, delivery: s.delivery_time, payment: s.payment_text,
    price_account: s.price_account, price_funnel: s.price_funnel, topup_fee: `${s.topup_comm_pct}%`,
    price_account_web: web, price_funnel_web: funnelWeb, topup_min: min, inr_rate: String(Number(s.inr_rate) || ''),
    price_account_inr: toInr(s.price_account, s), price_funnel_inr: toInr(s.price_funnel, s),
    price_account_web_inr: toInr(web, s), price_funnel_web_inr: toInr(funnelWeb, s), topup_min_inr: toInr(min, s),
    wa_link: s.wa_on === '1' ? s.wa_comm_link || '' : '', wa_members: s.wa_members || '',
    ...extra,
  };
  return String(text || '').replace(/\{(\w+)\}/g, (m, k) => (k in map ? map[k] : m));
}
export const lines = (t: string) => String(t || '').split('\n').map(x => x.trim()).filter(Boolean);

/** v160: "what's included" messages for the ⚡ quick panel in the chat (agents / manager / admin): Agency, Premium, Funnel.
 *  Built from the prices and the bullet lists in Settings, so they always match the site. */
export function productInfoMsgs(s0: Settings): { title: string; text: string }[] {
  const s = s0;
  const out: { title: string; text: string }[] = [];
  const b = (t: string, ss: Settings) => lines(fmt(t, ss)).map(x => '✅ ' + x.replace(/^[-•✅]\s*/, '')).join('\n');
  out.push({ title: 'Agency ad account', text: fmt(`🚀 Meta Agency Ad Account — ready in {delivery}\n\n${b(s.account_bullets || '', s)}\n\n💲 Price: \${price_account} ({price_account_inr} INR) per ad account\n💸 Top-up fee: {topup_fee}\n💵 Minimum top-up: \${topup_min} ({topup_min_inr} INR)\n\nPay with {payment}. Send your Business Manager ID and we share the account to it.`, s) });
  if (s.premium_on === '1') {
    const p = tierFor(s, 'premium');
    out.push({ title: 'Premium ad account', text: fmt(`⭐ Premium Agency Ad Account\n\n${b(s.premium_bullets || '', p)}\n\n💲 Price: \${price_account} ({price_account_inr} INR) per ad account\n💸 Top-up fee: {topup_fee}\n\nPay with {payment}. Send your Business Manager ID and we share the account to it.`, p) });
  }
  if (Number(s.price_funnel) > 0) out.push({ title: 'Landing page + funnel', text: fmt(`🎯 Landing page + funnel setup — \${price_funnel}/month ({price_funnel_inr} INR)\n\n✅ Landing page made for your business\n✅ Meta Pixel + Conversions API tracking\n✅ We build and run your ad campaign\n✅ Leads straight to your WhatsApp / Telegram\n✅ 1 reel video for your ads\n\nAd budget is separate and goes on your ad account. Pay with {payment}.`, s) });
  return out;
}
