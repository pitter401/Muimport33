import type { MetadataRoute } from 'next';
import { siteUrl } from '@/server/site';

export const dynamic = 'force-dynamic';

/** Crawl the public pages; keep the admin / agent apps and the API out of search. */
export default async function robots(): Promise<MetadataRoute.Robots> {
  const base = await siteUrl();
  return {
    rules: [{ userAgent: '*', allow: ['/', '/api/logo'], disallow: ['/admin', '/agent', '/api/', '/pay/'] }],
    sitemap: `${base}/sitemap.xml`,
    host: base,
  };
}
