import { one } from '@/server/db';
import { getSettings, bizOf } from '@/server/settings';
import { leadLink } from '@/server/crm';
import { kitVersion } from '@/server/brandkit';
import { baseUrl } from '@/server/http';

export const dynamic = 'force-dynamic';

const esc = (s: unknown) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]!));

/** Short link sent on WhatsApp: /t/<lead code> → that person's Telegram chat with their code already typed
 *  (so the chat links to their form and the Lead event can be sent). Already chatting → the chat account.
 *  It is a tiny page (not a plain redirect) so WhatsApp / Telegram show OUR 16:9 preview image, then it jumps to Telegram at once. */
export async function GET(req: Request, ctx: { params: Promise<{ code: string }> }) {
  const { code } = await ctx.params;
  const s = getSettings();
  const home = s.owner_username ? `https://t.me/${s.owner_username}` : new URL('/', req.url).toString();
  const l = /^[A-Za-z0-9]{8,40}$/.test(code || '')
    ? one<{ token: string; service: string | null; line: string | null; tg_chat_id: string | null }>('SELECT token, service, line, tg_chat_id FROM leads WHERE token=?', code)
    : undefined;
  const to = (l && !l.tg_chat_id ? leadLink(s, l.token, l.service === 'chat', bizOf(l)) : null) || home;
  const funnel = !!l && bizOf(l) === 'funnel';
  let base = process.env.PUBLIC_URL || req.headers.get('x-forwarded-host') || req.headers.get('host') ? baseUrl(req) : new URL(req.url).origin;
  if (!/\/\/(localhost|127\.)/.test(base)) base = base.replace(/^http:\/\//, 'https://'); // WhatsApp only loads https preview images
  const img = `${base}/share-image?line=${funnel ? 'funnel' : 'agency'}&v=${kitVersion(s)}`;
  const title = funnel ? `${s.brand_name} · Landing page + funnel, built for you` : `${s.brand_name} · Agency ad accounts, live in ${s.delivery_time}`;
  const desc = funnel ? 'Tap to talk to your funnel manager on Telegram.' : 'Tap to chat with your agent on Telegram.';
  const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(title)}</title><meta name="robots" content="noindex">
<meta property="og:type" content="website"><meta property="og:site_name" content="${esc(s.brand_name)}">
<meta property="og:title" content="${esc(title)}"><meta property="og:description" content="${esc(desc)}">
<meta property="og:url" content="${esc(base + '/t/' + (l ? l.token : ''))}">
<meta property="og:image" content="${esc(img)}"><meta property="og:image:secure_url" content="${esc(img)}"><meta property="og:image:type" content="image/png">
<meta property="og:image:width" content="1200"><meta property="og:image:height" content="675">
<meta name="twitter:card" content="summary_large_image"><meta name="twitter:image" content="${esc(img)}">
<meta http-equiv="refresh" content="0;url=${esc(to)}">
<style>body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#140c2e;color:#fff;font:600 17px system-ui,sans-serif}a{color:#c4b5fd}</style>
</head><body><p>Opening Telegram… <a href="${esc(to)}">Tap here</a> if it doesn't open.</p>
<script>location.replace(${JSON.stringify(to).replace(/</g, '\\u003c')})</script></body></html>`;
  return new Response(html, { status: 200, headers: { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store', 'x-robots-tag': 'noindex' } });
}
