import { getSettings, THEMES } from '@/server/settings';
import { logoImage, wideLogoImage, coverImage, appIconImage, statIconPng } from '@/server/brandkit';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * Brand kit images (made from the brand name + main landing theme):
 *   /brand/logo.png?size=1024          square logo / profile picture
 *   /brand/logo-wide.png?on=light|dark mark + name, transparent background
 *   /brand/facebook-cover.png          1640x624 Facebook page cover
 * Add ?download=1 to get it as a file.
 */
export async function GET(req: Request, { params }: { params: Promise<{ file: string }> }) {
  const { file } = await params;
  const q = new URL(req.url).searchParams;
  const s = getSettings();
  const slug = (s.brand_name || 'brand').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'brand';
  const dl = (name: string): Record<string, string> => (q.get('download') ? { 'Content-Disposition': `attachment; filename="${slug}-${name}.png"` } : {});
  switch (file) {
    case 'logo.png': {
      const size = Math.min(2048, Math.max(32, Number(q.get('size')) || 1024));
      const t = q.get('theme');
      return logoImage(t && (THEMES as readonly string[]).includes(t) ? { ...s, theme: t } : s, size, dl('logo'));
    }
    case 'logo-wide.png': return wideLogoImage(s, q.get('on') === 'dark' ? 'dark' : 'light', dl(q.get('on') === 'dark' ? 'logo-wide-white' : 'logo-wide'));
    case 'app-icon.png': {
      const size = Math.min(1024, Math.max(32, Number(q.get('size')) || 192));
      const shape = (['square', 'round', 'full', 'clear'] as const).find(x => x === q.get('shape')) || 'square';
      const th = q.get('theme'); // preview of one colour (Admin → System)
      return appIconImage(s, q.get('app') === 'admin' ? 'admin' : 'agent', size, shape, dl(`${q.get('app') === 'admin' ? 'admin' : 'agent'}-icon`), th && (THEMES as readonly string[]).includes(th) ? th : undefined);
    }
    case 'stat-icon.png': {
      const size = Math.min(512, Math.max(24, Number(q.get('size')) || 96));
      const png = await statIconPng(s, size);
      return new Response(new Uint8Array(png), { headers: { 'content-type': 'image/png', 'cache-control': 'no-store' } });
    }
    case 'facebook-cover.png': return coverImage(s, 1640, 624, dl('facebook-cover'));
    default: return new Response('Not found', { status: 404 });
  }
}
