import type { Metadata, Viewport } from 'next';
import { notFound } from 'next/navigation';
import { ChannelPage, channelMetadata } from '@/components/site/ChannelPage';
import { THEME_VARS } from '@/components/site/themes';

export const dynamic = 'force-dynamic';

/** Channel page in each design: /telegram/purple, /telegram/blue, /telegram/green, /telegram/gold. */
export async function generateMetadata(): Promise<Metadata> { return channelMetadata(); }
export async function generateViewport({ params }: { params: Promise<{ theme: string }> }): Promise<Viewport> {
  const t = THEME_VARS[(await params).theme] || THEME_VARS.purple;
  return { themeColor: `rgb(${t.vars.bg.split(' ').join(',')})` };
}
export default async function Page({ params }: { params: Promise<{ theme: string }> }) {
  const { theme } = await params;
  if (!(theme in THEME_VARS)) notFound();
  return <ChannelPage theme={theme} />;
}
