'use client';
import { AppCrash } from '@/components/app/AppCrash';
export default function GlobalError({ error }: { error: Error & { digest?: string } }) { return <html lang="en"><body style={{ margin: 0, background: '#0b0b12' }}><AppCrash error={error} /></body></html>; }
