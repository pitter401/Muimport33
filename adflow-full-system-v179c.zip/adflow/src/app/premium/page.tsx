import type { Metadata, Viewport } from 'next';
import { notFound } from 'next/navigation';
import { Landing } from '@/components/site/Landing';
import { landingContent } from '@/server/content';
import { isRtVisit } from '@/server/rt';
import { premiumMetadata, premiumJsonLd } from '@/server/site';
import { getSettings } from '@/server/settings';
import { THEME_VARS } from '@/components/site/themes';

export const dynamic = 'force-dynamic';

/** /premium — the same landing with the Premium offer and prices (price test + stronger accounts).
 *  Its leads are tagged Premium: Premium prices everywhere, and the manager handles them unless agents are tagged Premium. */
export async function generateMetadata(): Promise<Metadata> { return premiumMetadata(); }
export async function generateViewport(): Promise<Viewport> {
  const t = THEME_VARS[getSettings().theme] || THEME_VARS.purple;
  return { themeColor: `rgb(${t.vars.bg.split(' ').join(',')})` };
}

export default async function PremiumPage({ searchParams }: { searchParams?: Promise<Record<string, string | string[] | undefined>> }) {
  const s = getSettings();
  if (s.premium_on !== '1') notFound();
  const ld = await premiumJsonLd(s);
  return <><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: ld }} /><Landing c={landingContent(s.theme in THEME_VARS ? s.theme : 'purple', s, 'agency', 'premium', await isRtVisit(searchParams))} /></>;
}
