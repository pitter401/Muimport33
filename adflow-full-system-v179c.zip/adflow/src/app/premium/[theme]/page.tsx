import type { Metadata, Viewport } from 'next';
import { notFound } from 'next/navigation';
import { Landing } from '@/components/site/Landing';
import { landingContent } from '@/server/content';
import { premiumMetadata, premiumJsonLd } from '@/server/site';
import { getSettings } from '@/server/settings';
import { THEME_VARS } from '@/components/site/themes';

export const dynamic = 'force-dynamic';

/** /premium/purple, /premium/blue, /premium/green, /premium/gold — the Premium page in each theme (one per ad set if you like).
 *  Google sees them as /premium (canonical). */
export async function generateMetadata(): Promise<Metadata> { return premiumMetadata(); }
export async function generateViewport({ params }: { params: Promise<{ theme: string }> }): Promise<Viewport> {
  const t = THEME_VARS[(await params).theme] || THEME_VARS.purple;
  return { themeColor: `rgb(${t.vars.bg.split(' ').join(',')})` };
}

export default async function PremiumThemePage({ params }: { params: Promise<{ theme: string }> }) {
  const { theme } = await params;
  const s = getSettings();
  if (!(theme in THEME_VARS) || s.premium_on !== '1') notFound();
  const ld = await premiumJsonLd(s);
  return <><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: ld }} /><Landing c={landingContent(theme, s, 'agency', 'premium')} /></>;
}
