import type { Metadata, Viewport } from 'next';
import { WhatsAppPage, waMetadata } from '@/components/site/WhatsAppPage';
import { getSettings } from '@/server/settings';
import { THEME_VARS } from '@/components/site/themes';

export const dynamic = 'force-dynamic';

/** v131: /premium/community — WhatsApp ad page (community) in the site's landing design. */
export async function generateMetadata(): Promise<Metadata> { return waMetadata('premium', 'community'); }
export async function generateViewport(): Promise<Viewport> {
  const t = THEME_VARS[getSettings().theme] || THEME_VARS.purple;
  return { themeColor: `rgb(${t.vars.bg.split(' ').join(',')})` };
}
export default function Page() {
  return <WhatsAppPage theme={getSettings().theme} line="premium" mode="community" />;
}
