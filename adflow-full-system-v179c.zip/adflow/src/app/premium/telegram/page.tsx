import type { Metadata, Viewport } from 'next';
import { notFound } from 'next/navigation';
import { ChannelPage, channelMetadata } from '@/components/site/ChannelPage';
import { getSettings } from '@/server/settings';
import { THEME_VARS } from '@/components/site/themes';

export const dynamic = 'force-dynamic';

/** /premium/telegram — channel-ad page (premium): join request → the bot DMs the offer → approved → Subscribe. */
export async function generateMetadata(): Promise<Metadata> { return channelMetadata('premium'); }
export async function generateViewport(): Promise<Viewport> {
  const t = THEME_VARS[getSettings().theme] || THEME_VARS.purple;
  return { themeColor: `rgb(${t.vars.bg.split(' ').join(',')})` };
}
export default function Page() {
  if (getSettings().premium_on !== '1') notFound();
  return <ChannelPage theme={getSettings().theme} line="premium" />;
}
