import type { Metadata, Viewport } from 'next';
import { notFound } from 'next/navigation';
import { Landing } from '@/components/site/Landing';
import { landingContent } from '@/server/content';
import { landingMetadata, landingJsonLd } from '@/server/site';
import { THEME_VARS } from '@/components/site/themes';

export const dynamic = 'force-dynamic';

/** Each theme also has its own URL — use different ones in different ad sets to test which converts best. */
export async function generateMetadata(): Promise<Metadata> { return landingMetadata(); }
export async function generateViewport({ params }: { params: Promise<{ theme: string }> }): Promise<Viewport> {
  const t = THEME_VARS[(await params).theme] || THEME_VARS.purple;
  return { themeColor: `rgb(${t.vars.bg.split(' ').join(',')})` };
}

export default async function ThemePage({ params }: { params: Promise<{ theme: string }> }) {
  const { theme } = await params;
  if (!(theme in THEME_VARS)) notFound();
  const ld = await landingJsonLd();
  return <><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: ld }} /><Landing c={landingContent(theme)} /></>;
}
