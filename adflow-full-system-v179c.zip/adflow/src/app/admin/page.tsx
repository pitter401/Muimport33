import type { Metadata, Viewport } from 'next';
import AdminApp from '@/components/app/AdminApp';

export const metadata: Metadata = { title: 'Admin', manifest: '/admin.webmanifest', robots: { index: false } };
export const viewport: Viewport = { themeColor: [{ media: '(prefers-color-scheme: light)', color: '#ffffff' }, { media: '(prefers-color-scheme: dark)', color: '#17212B' }], width: 'device-width', initialScale: 1, maximumScale: 1, viewportFit: 'cover' };

export default function Page() { return <div className="tg-auto"><AdminApp /></div>; }
