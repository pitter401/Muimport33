'use client';
import { AppCrash } from '@/components/app/AppCrash';
export default function Error({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) { return <AppCrash error={error} reset={reset} />; }
