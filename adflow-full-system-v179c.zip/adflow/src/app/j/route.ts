import { joinLinkFor } from '@/server/channel';

export const dynamic = 'force-dynamic';

/** Top bar "Join" → this visitor's own channel join link (so the join request can be matched for the Subscribe event). */
export async function GET(req: Request) {
  const to = await joinLinkFor(req).catch(() => null);
  return new Response(null, { status: 302, headers: { location: to || new URL('/', req.url).toString(), 'cache-control': 'no-store', 'x-robots-tag': 'noindex' } });
}
