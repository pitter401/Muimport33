import { InfoPage, infoMetadata } from '@/components/site/InfoPage';

export const dynamic = 'force-dynamic';
export const generateMetadata = () => infoMetadata('how-it-works');
export default function Page() { return <InfoPage slug="how-it-works" />; }
