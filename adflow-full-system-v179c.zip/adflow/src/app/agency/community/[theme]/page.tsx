import type { Metadata, Viewport } from 'next';
import { notFound } from 'next/navigation';
import { WhatsAppPage, waMetadata } from '@/components/site/WhatsAppPage';
import { THEME_VARS } from '@/components/site/themes';

export const dynamic = 'force-dynamic';

/** v131: /agency/community/<theme> — the same WhatsApp ad page in each design (purple, blue, green, gold). */
export async function generateMetadata(): Promise<Metadata> { return waMetadata('agency', 'community'); }
export async function generateViewport({ params }: { params: Promise<{ theme: string }> }): Promise<Viewport> {
  const t = THEME_VARS[(await params).theme] || THEME_VARS.purple;
  return { themeColor: `rgb(${t.vars.bg.split(' ').join(',')})` };
}
export default async function Page({ params }: { params: Promise<{ theme: string }> }) {
  const { theme } = await params;
  if (!(theme in THEME_VARS)) notFound();
  return <WhatsAppPage theme={theme} line="agency" mode="community" />;
}
