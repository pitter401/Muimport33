import type { Metadata, Viewport } from 'next';
import AgentApp from '@/components/app/AgentApp';

export const metadata: Metadata = { title: 'Chats', manifest: '/agent.webmanifest', robots: { index: false } };
export const viewport: Viewport = { themeColor: [{ media: '(prefers-color-scheme: light)', color: '#ffffff' }, { media: '(prefers-color-scheme: dark)', color: '#17212B' }], width: 'device-width', initialScale: 1, maximumScale: 1, viewportFit: 'cover' };

export default function Page() { return <div className="tg-auto"><AgentApp /></div>; }
