import type { Metadata, Viewport } from 'next';
import { ChannelPage, channelMetadata } from '@/components/site/ChannelPage';
import { getSettings } from '@/server/settings';
import { THEME_VARS } from '@/components/site/themes';

export const dynamic = 'force-dynamic';

/** /funnel/telegram — channel-ad page (funnel): join request → the bot DMs the offer → approved → Subscribe. */
export async function generateMetadata(): Promise<Metadata> { return channelMetadata('funnel'); }
export async function generateViewport(): Promise<Viewport> {
  const t = THEME_VARS[getSettings().theme] || THEME_VARS.purple;
  return { themeColor: `rgb(${t.vars.bg.split(' ').join(',')})` };
}
export default function Page() {
  return <ChannelPage theme={getSettings().theme} line="funnel" />;
}
