import type { Metadata, Viewport } from 'next';
import { notFound } from 'next/navigation';
import { ChannelPage, channelMetadata } from '@/components/site/ChannelPage';
import { getSettings } from '@/server/settings';
import { THEME_VARS } from '@/components/site/themes';

export const dynamic = 'force-dynamic';

/** /funnel/telegram/<theme> — the same channel-ad page in each design (purple, blue, green, gold). */
export async function generateMetadata(): Promise<Metadata> { return channelMetadata('funnel'); }
export async function generateViewport({ params }: { params: Promise<{ theme: string }> }): Promise<Viewport> {
  const t = THEME_VARS[(await params).theme] || THEME_VARS.purple;
  return { themeColor: `rgb(${t.vars.bg.split(' ').join(',')})` };
}
export default async function Page({ params }: { params: Promise<{ theme: string }> }) {
  const { theme } = await params;
  if (!(theme in THEME_VARS)) notFound();
  return <ChannelPage theme={theme} line="funnel" />;
}
