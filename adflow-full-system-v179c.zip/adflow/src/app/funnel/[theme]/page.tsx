import type { Metadata, Viewport } from 'next';
import { notFound } from 'next/navigation';
import { Landing } from '@/components/site/Landing';
import { landingContent } from '@/server/content';
import { landingMetadata, landingJsonLd } from '@/server/site';
import { getSettings } from '@/server/settings';
import { THEME_VARS } from '@/components/site/themes';

export const dynamic = 'force-dynamic';

/** Funnel page in each design: /funnel/purple, /funnel/blue, /funnel/green, /funnel/gold. */
export async function generateMetadata(): Promise<Metadata> { return landingMetadata(getSettings(), 'funnel'); }
export async function generateViewport({ params }: { params: Promise<{ theme: string }> }): Promise<Viewport> {
  const t = THEME_VARS[(await params).theme] || THEME_VARS.purple;
  return { themeColor: `rgb(${t.vars.bg.split(' ').join(',')})` };
}

export default async function FunnelThemePage({ params }: { params: Promise<{ theme: string }> }) {
  const { theme } = await params;
  if (!(theme in THEME_VARS)) notFound();
  const s = getSettings();
  const ld = await landingJsonLd(s);
  return <><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: ld }} /><Landing c={landingContent(theme, s, 'funnel')} /></>;
}
