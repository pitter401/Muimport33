import type { Metadata, Viewport } from 'next';
import { Landing } from '@/components/site/Landing';
import { landingContent } from '@/server/content';
import { isRtVisit } from '@/server/rt';
import { landingMetadata, landingJsonLd } from '@/server/site';
import { getSettings } from '@/server/settings';
import { THEME_VARS } from '@/components/site/themes';

export const dynamic = 'force-dynamic';

export async function generateMetadata(): Promise<Metadata> { return landingMetadata(); }
export async function generateViewport(): Promise<Viewport> {
  const t = THEME_VARS[getSettings().theme] || THEME_VARS.purple;
  return { themeColor: `rgb(${t.vars.bg.split(' ').join(',')})` };
}

export default async function Home({ searchParams }: { searchParams?: Promise<Record<string, string | string[] | undefined>> }) {
  const s = getSettings();
  const ld = await landingJsonLd(s);
  return <><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: ld }} /><Landing c={landingContent(s.theme in THEME_VARS ? s.theme : 'purple', s, 'agency', '', await isRtVisit(searchParams))} /></>;
}
