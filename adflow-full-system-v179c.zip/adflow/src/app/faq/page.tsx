import { InfoPage, infoMetadata } from '@/components/site/InfoPage';

export const dynamic = 'force-dynamic';
export const generateMetadata = () => infoMetadata('faq');
export default function Page() { return <InfoPage slug="faq" />; }
