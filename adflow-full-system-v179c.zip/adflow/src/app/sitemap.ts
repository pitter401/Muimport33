import type { MetadataRoute } from 'next';
import { siteUrl } from '@/server/site';
import { getSettings } from '@/server/settings';
import { INFO_PAGES } from '@/components/site/InfoPage';

export const dynamic = 'force-dynamic';

/** The two canonical landing pages (Agency "/" and Funnel "/funnel"). Their design URLs point to them with rel=canonical. */
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = await siteUrl();
  return [
    { url: `${base}/`, lastModified: new Date(), changeFrequency: 'weekly', priority: 1 },
    { url: `${base}/funnel`, lastModified: new Date(), changeFrequency: 'weekly', priority: 0.9 },
    ...(getSettings().premium_on === '1' ? [{ url: `${base}/premium`, lastModified: new Date(), changeFrequency: 'weekly' as const, priority: 0.9 }] : []),
    // small pages Google can show as sitelinks under the main result
    ...INFO_PAGES.map(p => ({ url: `${base}/${p.slug}`, lastModified: new Date(), changeFrequency: 'monthly' as const, priority: 0.7 })),
    { url: `${base}/products`, lastModified: new Date(), changeFrequency: 'weekly', priority: 0.8 },
    { url: `${base}/telegram`, lastModified: new Date(), changeFrequency: 'monthly', priority: 0.6 },
  ];
}
