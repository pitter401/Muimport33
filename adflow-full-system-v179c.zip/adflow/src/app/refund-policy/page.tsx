import { InfoPage, infoMetadata } from '@/components/site/InfoPage';

export const dynamic = 'force-dynamic';
export const generateMetadata = () => infoMetadata('refund-policy');
export default function Page() { return <InfoPage slug="refund-policy" />; }
