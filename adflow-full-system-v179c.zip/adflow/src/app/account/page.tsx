import type { Metadata } from 'next';
import { redirect } from 'next/navigation';
import { getSettings, usesUploadedLogo } from '@/server/settings';
import { THEME_VARS, themeCss } from '@/components/site/themes';
import { shopThemeCss } from '@/components/site/palette';
import { AccountPage } from '@/components/shop/Shop';

export const dynamic = 'force-dynamic';
export async function generateMetadata(): Promise<Metadata> {
  const s = getSettings();
  return { title: 'My account — ' + s.brand_name, robots: { index: false }, icons: { icon: usesUploadedLogo(s) ? '/api/logo?v=' + s.logo_ver : '/brand/logo.png?size=192&theme=' + s.theme } };
}

export default function Page() {
  const s = getSettings();
  if (s.web_orders_on !== '1') redirect('/');
  const theme = s.theme in THEME_VARS ? s.theme : 'purple';
  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: themeCss(theme) + shopThemeCss(theme) }} />
      <AccountPage brand={s.brand_name} logo={usesUploadedLogo(s) ? '/api/logo?v=' + s.logo_ver : '/brand/logo.png?size=96&theme=' + s.theme + '&v=' + encodeURIComponent(s.brand_name)} />
    </>
  );
}
