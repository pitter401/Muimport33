import { one } from '@/server/db';

export const dynamic = 'force-dynamic';

/** For the watchdog (worker/watchdog.mjs): answers only when the website AND the database respond. */
export function GET() {
  const t = Date.now();
  one('SELECT 1 x');
  return Response.json({ ok: true, ms: Date.now() - t }, { headers: { 'cache-control': 'no-store' } });
}
