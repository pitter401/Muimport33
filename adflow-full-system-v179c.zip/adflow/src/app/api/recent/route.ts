import { all } from '@/server/db';
import { getSettings } from '@/server/settings';
import { json } from '@/server/http';

export const dynamic = 'force-dynamic';

type Item = { name: string; text: string; at: number; fill?: true };
let cache: { at: number; items: Item[] } | null = null;

/** "Rahul S." — first name + last initial only. Empty when there is no real name. */
function short(n: string | null | undefined) {
  const p = String(n || '').replace(/[^\p{L}\s.'-]/gu, ' ').trim().split(/\s+/).filter(Boolean);
  if (!p.length || p[0].length < 2) return '';
  const first = p[0][0].toUpperCase() + p[0].slice(1).toLowerCase();
  return p[1] ? `${first} ${p[1][0].toUpperCase()}.` : first;
}

// ── Ticker fill: a steady timeline of activity across India ─────────────────
// Every event has a FIXED time (derived from the clock), so on refresh the same events are there,
// they keep ageing ("just now" -> "3 minutes ago"), and new ones appear on top as time passes.
const FILL_NAMES = [
  'Rahul','Suman','Amit','Priya','Vikram','Anjali','Deepak','Pooja','Suresh','Neha',
  'Rajesh','Kavita','Ajay','Meena','Vinod','Sunita','Ramesh','Geeta','Arun','Shweta',
  'Mahesh','Rekha','Dinesh','Anita','Sunil','Aarti','Pankaj','Nisha','Rohit','Divya',
  'Gaurav','Pallavi','Nitin','Ritu','Karan','Sonal','Vikas','Priyanka','Ashok','Swati',
  'Hemant','Bhavna','Sanjay','Nidhi','Aakash','Tanvi','Manish','Bijay','Santosh','Imran',
];
const FILL_CITIES = [
  'Mumbai','Delhi','Bangalore','Hyderabad','Chennai','Kolkata','Pune','Ahmedabad',
  'Jaipur','Surat','Lucknow','Kanpur','Nagpur','Indore','Thane','Bhopal','Patna',
  'Vadodara','Ghaziabad','Ludhiana','Coimbatore','Agra','Nashik','Faridabad','Rajkot',
  'Varanasi','Amritsar','Navi Mumbai','Ranchi','Howrah','Guwahati','Noida','Gurgaon','Kochi',
];
// [what, where] — weighted: ad accounts on Telegram are the most common
const FILL_ACTIONS: [string, string][] = [
  ['Ad Account', 'Telegram'], ['Ad Account', 'Telegram'], ['Ad Account', 'Telegram'],
  ['Ad Account', 'Website'], ['Ads Setup', 'Telegram'], ['Ads Setup', 'Website'],
  ['2 Ad Accounts', 'Telegram'], ['Ad Account', 'Telegram'],
];
const SLOT_MS = 4 * 60_000; // one possible event per 4-minute slot
const SPAN_MS = 120 * 60_000; // look back 2 hours

/** Small deterministic hash -> [0,1). Same input always gives the same number. */
function rnd(n: number, salt: number) {
  let x = (n * 2654435761 + salt * 40503) >>> 0;
  x ^= x >>> 16; x = Math.imul(x, 0x7feb352d) >>> 0; x ^= x >>> 15; x = Math.imul(x, 0x846ca68b) >>> 0; x ^= x >>> 16;
  return (x >>> 0) / 4294967296;
}

function fillItems(now: number): Item[] {
  const out: Item[] = [];
  const last = Math.floor(now / SLOT_MS);
  let prevName = '';
  for (let slot = last - Math.floor(SPAN_MS / SLOT_MS); slot <= last; slot++) {
    if (rnd(slot, 1) < 0.25) continue; // ~75% of slots have a purchase
    const at = slot * SLOT_MS + Math.floor(rnd(slot, 2) * SLOT_MS);
    if (at > now) continue; // not happened yet
    let name = FILL_NAMES[Math.floor(rnd(slot, 3) * FILL_NAMES.length)];
    if (name === prevName) name = FILL_NAMES[(FILL_NAMES.indexOf(name) + 7) % FILL_NAMES.length];
    prevName = name;
    const city = FILL_CITIES[Math.floor(rnd(slot, 4) * FILL_CITIES.length)];
    const [what, where] = FILL_ACTIONS[Math.floor(rnd(slot, 5) * FILL_ACTIONS.length)];
    out.push({ name, at, text: `purchased ${what} from ${city} on ${where}`, fill: true });
  }
  return out;
}

/** Recent purchases and top-ups (last 60 days) for the landing-page ticker, plus the timeline fill when it is ON. */
export async function GET() {
  const s = getSettings();

  if (s.recent_on !== '1') return json({ items: [] });
  if (cache && Date.now() - cache.at < 30_000) return json({ items: cache.items });
  const since = Date.now() - 60 * 86400000;
  const realItems: Item[] = [];
  for (const r of all<{ name: string | null; tg_name: string | null; service: string; qty: number; amount: number; created_at: number }>(
    'SELECT l.name, l.tg_name, s.service, s.qty, s.amount, s.created_at FROM sales s JOIN leads l ON l.id=s.lead_id WHERE s.created_at>? ORDER BY s.id DESC LIMIT 40', since)) {
    const n = short(r.name || r.tg_name); if (!n) continue;
    realItems.push({ name: n, at: r.created_at, text: r.service === 'funnel' ? 'purchased Ads Setup on Telegram' : `purchased ${r.qty > 1 ? r.qty + ' Ad Accounts' : 'Ad Account'} on Telegram` });
  }
  for (const r of all<{ name: string | null; cname: string | null; kind: string; qty: number; amount: number; at: number }>(
    "SELECT o.name, c.name cname, o.kind, o.qty, o.amount, COALESCE(o.paid_at, o.created_at) at FROM web_orders o JOIN customers c ON c.id=o.customer_id WHERE o.status IN ('paid','delivered') AND COALESCE(o.paid_at, o.created_at)>? ORDER BY o.id DESC LIMIT 40", since)) {
    const n = short(r.name || r.cname); if (!n) continue;
    realItems.push({ name: n, at: r.at, text: r.kind === 'funnel' ? 'purchased Ads Setup on Website' : `purchased ${r.qty > 1 ? r.qty + ' Ad Accounts' : 'Ad Account'} on Website` });
  }
  for (const r of all<{ name: string | null; amount: number; at: number }>(
    'SELECT COALESCE(l.name, l.tg_name) name, t.amount, t.created_at at FROM topups t JOIN leads l ON l.id=t.lead_id WHERE t.created_at>? ORDER BY t.id DESC LIMIT 30', since)) {
    const n = short(r.name); if (!n) continue;
    realItems.push({ name: n, at: r.at, text: `topped up $${Math.round(r.amount).toLocaleString('en-US')}` });
  }
  for (const r of all<{ name: string | null; amount: number; at: number }>(
    "SELECT c.name, t.amount, COALESCE(t.done_at, t.created_at) at FROM web_topups t JOIN customers c ON c.id=t.customer_id WHERE t.status='done' AND COALESCE(t.done_at, t.created_at)>? ORDER BY t.id DESC LIMIT 30", since)) {
    const n = short(r.name); if (!n) continue;
    realItems.push({ name: n, at: r.at, text: `topped up $${Math.round(r.amount).toLocaleString('en-US')}` });
  }

  let items: Item[] = [...realItems];
  if (s.ticker_fill_on === '1') {
    // add timeline events, but never right next to a real sale
    for (const f of fillItems(Date.now())) if (!realItems.some(r => Math.abs(r.at - f.at) < 180_000)) items.push(f);
  }

  items.sort((a, b) => b.at - a.at);
  cache = { at: Date.now(), items: items.slice(0, 60).map(({ fill: _f, ...rest }) => rest) };
  return json({ items: cache.items });
}
