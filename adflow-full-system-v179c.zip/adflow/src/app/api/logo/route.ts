import { readLogo } from '@/server/logo';

export const dynamic = 'force-dynamic';

export async function GET() {
  const l = readLogo();
  if (!l) return new Response('no logo', { status: 404 });
  return new Response(new Uint8Array(l.buf), {
    headers: { 'content-type': l.type, 'cache-control': 'public, max-age=86400', 'content-security-policy': "default-src 'none'; style-src 'unsafe-inline'", 'x-content-type-options': 'nosniff' },
  });
}
