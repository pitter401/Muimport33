import { getSettings } from '@/server/settings';
import { downloadFile } from '@/server/telegram';
import { getAdmin, getAgent } from '@/server/auth';
import { one } from '@/server/db';

export const dynamic = 'force-dynamic';
const CT: Record<string, string> = { jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp', gif: 'image/gif', mp4: 'video/mp4', mov: 'video/quicktime', webm: 'video/webm', oga: 'audio/ogg', ogg: 'audio/ogg', opus: 'audio/ogg', mp3: 'audio/mpeg', m4a: 'audio/mp4', wav: 'audio/wav', pdf: 'application/pdf', tgs: 'application/x-tgsticker' };

/** Streams a Telegram file to the agent/admin app. Agents can only open files from their own chats. */
export async function GET(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const fileId = decodeURIComponent(id);
  const admin = getAdmin(req);
  if (!admin) {
    const agent = getAgent(req);
    if (!agent) return new Response('forbidden', { status: 403 });
    const ok = one('SELECT 1 FROM messages m JOIN leads l ON l.id=m.lead_id WHERE m.file_id=? AND l.agent_id=? LIMIT 1', fileId, agent.id);
    if (!ok) return new Response('forbidden', { status: 403 });
  }
  const f = await downloadFile(getSettings(), fileId);
  if (!f || !f.res.ok) return new Response('File not available (Telegram bots can download files up to 20 MB)', { status: 404 });
  const ext = (f.path.split('.').pop() || '').toLowerCase();
  const type = CT[ext] || f.res.headers.get('content-type') || 'application/octet-stream';
  // v139: whole file + byte ranges, so the player can read the voice note's length (OGG keeps it at the end) and seek
  const buf = new Uint8Array(await f.res.arrayBuffer());
  const base = { 'content-type': type, 'cache-control': 'private, max-age=86400', 'accept-ranges': 'bytes' };
  const rg = /^bytes=(\d*)-(\d*)$/.exec(req.headers.get('range') || '');
  if (rg && (rg[1] || rg[2])) {
    const size = buf.length;
    let a = rg[1] ? Number(rg[1]) : Math.max(0, size - Number(rg[2]));
    let b = rg[1] && rg[2] ? Math.min(Number(rg[2]), size - 1) : size - 1;
    if (a >= size || a > b) return new Response(null, { status: 416, headers: { ...base, 'content-range': `bytes */${size}` } });
    a = Math.max(0, a); b = Math.max(a, b);
    return new Response(buf.slice(a, b + 1), { status: 206, headers: { ...base, 'content-range': `bytes ${a}-${b}/${size}`, 'content-length': String(b - a + 1) } });
  }
  return new Response(buf, { headers: { ...base, 'content-length': String(buf.length) } });
}
