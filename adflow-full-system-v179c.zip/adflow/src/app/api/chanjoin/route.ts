import { one } from '@/server/db';

export const dynamic = 'force-dynamic';

/** v121 channel pages: did this visitor's join request reach the channel since they tapped Join? (for the WhatsApp fallback) */
export async function GET(req: Request) {
  const m = (req.headers.get('cookie') || '').match(/(?:^|;\s*)af_vid=([^;]+)/);
  const vid = m ? decodeURIComponent(m[1]) : '';
  const since = Math.max(0, Number(new URL(req.url).searchParams.get('since')) || 0) - 60000;
  const asked = !!vid && !!one('SELECT 1 FROM channel_joins WHERE vid=? AND requested_at>=? LIMIT 1', vid, since);
  return Response.json({ asked, vid: !!vid }, { headers: { 'cache-control': 'no-store', 'x-robots-tag': 'noindex' } });
}
