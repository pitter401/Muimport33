import { json } from '@/server/http';
import { getSettings } from '@/server/settings';
import { viewerBase } from '@/server/viewers';

export const dynamic = 'force-dynamic';

/** In-memory viewer sessions: token → { theme, lastSeen } */
const sessions = new Map<string, { theme: string; lastSeen: number }>();
const TTL = 75 * 1000; // live = pinged in the last 75s (page polls every 30s)

function purge() {
  const cut = Date.now() - TTL;
  for (const [k, v] of sessions) if (v.lastSeen < cut) sessions.delete(k);
}

function countTheme(theme: string) {
  purge();
  let n = 0;
  for (const v of sessions.values()) { void v; n++; } void theme;
  return n;
}

/**
 * GET /api/viewers?theme=purple&tok=<visitor_token>
 * Returns { count: N } — N = a slowly moving number between viewer_min and viewer_max + live active sessions.
 * Also registers/refreshes the visitor's session.
 */
export async function GET(req: Request) {
  const u = new URL(req.url);
  const theme = u.searchParams.get('theme') || 'purple';
  const tok = u.searchParams.get('tok') || '';
  const s = getSettings();
  const floor = viewerBase(s);
  if (!floor) return json({ count: 0 });

  if (tok && /^[a-z0-9]{6,40}$/i.test(tok) && (sessions.has(tok) || sessions.size < 5000)) {
    sessions.set(tok, { theme: theme.slice(0, 10), lastSeen: Date.now() });
  }

  const live = countTheme(theme);
  return json({ count: floor + live });
}
