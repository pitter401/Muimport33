// v168: a status video / "my reel" download by a 10-minute signed link (see statusvid.ts fileLink). GET only.
import { serveLink } from '@/server/statusvid';

export const dynamic = 'force-dynamic';
export async function GET(req: Request) { return serveLink(req); }
export async function HEAD(req: Request) { return serveLink(req); }
