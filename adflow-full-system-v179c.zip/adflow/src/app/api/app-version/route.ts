/* Latest Android app build (written by scripts/build-apk.sh) — the apps show an "Update" banner when theirs is older. */
import fs from 'fs';
import path from 'path';
import { forceInfo } from '@/server/appforce';

export const dynamic = 'force-dynamic';

export function GET() {
  let v: Record<string, unknown> = {};
  try { v = JSON.parse(fs.readFileSync(path.join(process.env.DOWNLOADS_DIR || '/var/www/adflow-downloads', 'version.json'), 'utf8')); } catch { /* no build yet */ }
  // v147: the server's current build → the apps reload themselves after a server update (no need to close and reopen)
  let web = '';
  try { web = fs.readFileSync(path.join(process.cwd(), '.next', 'BUILD_ID'), 'utf8').trim(); } catch { /* dev */ }
  // v167: forced update — the minimum build per app (0 = none). Only set when the new APK is really on the server.
  let f = { force: false, min_agent: 0, min_admin: 0 };
  try { f = forceInfo(); } catch { /* no db yet */ }
  return Response.json({ code: Number(v.code) || 0, name: String(v.name || ''), at: Number(v.at) || 0, web, ...f }, { headers: { 'cache-control': 'no-store' } });
}
