import { getSettings } from '@/server/settings';
import { webhookSecret } from '@/server/telegram';
import { handleUpdate } from '@/server/crm';
import { json } from '@/server/http';

export const dynamic = 'force-dynamic';

export async function POST(req: Request) {
  const s = getSettings();
  if (!s.bot_token || req.headers.get('x-telegram-bot-api-secret-token') !== webhookSecret(s)) return new Response('forbidden', { status: 403 });
  const u = await req.json().catch(() => null);
  if (u) {
    const kind = Object.keys(u).filter(k => k !== 'update_id').join(',');
    console.log('[tg] update', kind, kind === 'business_connection' ? JSON.stringify({ user: u.business_connection?.user?.username, enabled: u.business_connection?.is_enabled }) : '');
    // v153: our channel's posts → the next "Client #" follows them (nothing else is done with channel posts)
    if (u.channel_post || u.edited_channel_post) {
      try { const { syncClientNo } = await import('@/server/proof'); const n = syncClientNo(u.channel_post || u.edited_channel_post); if (n) console.log('[tg] next client number', n); } catch (e) { console.error('[tg] client no', e); }
      return json({ ok: true });
    }
    try { await handleUpdate(u); } catch (e) { console.error('[tg]', e); }
  }
  return json({ ok: true });
}
