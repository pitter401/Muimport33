import { getSettings } from '@/server/settings';
import { hookKey, parseHook, parseStatus, logWati } from '@/server/wati';
import { handleWaInbound, waStatus } from '@/server/crm';
import { json } from '@/server/http';

export const dynamic = 'force-dynamic';

/** v131: WATI webhook (WATI → Connectors → Webhooks → this URL, event "message"). */
export async function POST(req: Request, ctx: { params: Promise<{ key: string }> }) {
  const s = getSettings();
  const { key } = await ctx.params;
  if (!s.wati_hook || key !== hookKey(s)) return new Response('not found', { status: 404 });
  const raw = await req.text();
  logWati('hook', raw);
  if (s.wati_on !== '1') return json({ ok: true, off: true });
  let b: unknown = null;
  try { b = JSON.parse(raw); } catch { return json({ ok: true }); }
  for (const x of Array.isArray(b) ? b : [b]) {
    const st = parseStatus(x); // v134: delivered / read ticks
    if (st) { try { waStatus(st.ids, st.st); } catch (e) { logWati('error', (e as Error).message); } continue; }
    const m = parseHook(x);
    if (!m) continue;
    try { await handleWaInbound(s, m); } catch (e) { console.error('[wati]', e); logWati('error', (e as Error).message); }
  }
  return json({ ok: true });
}
export async function GET() { return json({ ok: true }); }
