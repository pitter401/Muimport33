import { payPageInfo, payPageStart, payPageCheck } from '@/server/paylinks';
import { json, body, fail, clientIp } from '@/server/http';

export const dynamic = 'force-dynamic';

/** Public API for the crypto payment link page (/pay/PL-XXXX). GET = info (?check=1 also asks NOWPayments), POST = choose coin. */
export async function GET(req: Request, ctx: { params: Promise<{ code: string }> }) {
  try {
    const { code } = await ctx.params;
    const check = new URL(req.url).searchParams.get('check');
    return json(check ? await payPageCheck(code, clientIp(req)) : payPageInfo(code, clientIp(req)));
  } catch (e) { return fail(e); }
}
export async function POST(req: Request, ctx: { params: Promise<{ code: string }> }) {
  try { const { code } = await ctx.params; return json(await payPageStart(code, await body(req), clientIp(req))); } catch (e) { return fail(e); }
}
