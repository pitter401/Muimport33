import { readNotifSound } from '@/server/notifsound';

export const dynamic = 'force-dynamic';

/** v134: the team notification sound the admin uploaded (phones download it once per version). */
export async function GET() {
  const f = readNotifSound();
  if (!f) return new Response('no sound', { status: 404 });
  return new Response(new Uint8Array(f.buf), {
    headers: { 'content-type': f.type, 'cache-control': 'public, max-age=31536000, immutable', 'content-security-policy': "default-src 'none'", 'x-content-type-options': 'nosniff' },
  });
}
