import { one, all, run, emptyInSql } from '@/server/db';
import { contactName } from '@/server/userbot';
import { addWaSale, addWaTopup, delWaSale, delWaTopup, editWaSale, listWaSales } from '@/server/wasales';
import { productInfoMsgs, getSettings, fmt, lines, msgFor, tierFor, leadPrices, offerOf, offerTexts } from '@/server/settings';
import { getAgent, verifyPassword, makeToken, cookieHeader, type Agent } from '@/server/auth';
import { needsReplySql, leadById, agentById, sendToLead, uploadToLead, recordSale, addTopup, wallet, runFollowups, linkCode, setReminder, welcomePendingSql, chatHeld, waText, type Lead, setLeadType, markReadEverywhere, requestDelete, chatPage, setReceive, clearCoverForAssign, agentLog, realConvAt, commSql, notifyAgent, displayName, addMsg, sendOnceByCid } from '@/server/crm';
import { addCashPayout, delCashPayout, cashPayouts } from '@/server/cashpay';
import { registerToken, pushTo, ringOffFor } from '@/server/push';
import { forwardToManager, listTasks, completeTask, markPaid, cancelItem, webOn, leadAccounts } from '@/server/shop';
import { ownSoundVer } from '@/server/notifsound';
import { createPayLink, chatLinksAndItems, leadPayLinks, cancelPayLink, payLinksOn, createWaPayLink, waPayLinks } from '@/server/paylinks';
import { WA_ITEMS, waPrice } from '@/server/wasales';
import { waSyncSoon, waPhoneSyncSoon } from '@/server/wasync';
import { json, body, fail, baseUrl, clientIp, loginBlocked, loginFailed, realIp } from '@/server/http';
import { now, num, money, dayRange, HttpError, presence } from '@/server/util';
import { metaApi } from '@/server/metaapi';
import { stampCamps, stampLead, chipsOf } from '@/server/camps';
import { assignCalls, markCall, callSql, callTodoSql, hotSql } from '@/server/calls';
import * as AI from '@/server/ai';
import { addMsg as addMsgAi } from '@/server/crm';
import { metaOn, metaHas, metaEnabled, createRequest, leadMetaAccounts, openCredit, freeAccounts, tierOf, listRequests, catOf, freePickList } from '@/server/meta';
import { reelUserApi } from '@/server/reel';
import { reelDlApi } from '@/server/statusvid'; // v168

export const dynamic = 'force-dynamic';

async function handle(req: Request, ctx: { params: Promise<{ p: string[] }> }) {
  const path = (await ctx.params).p.join('/');
  try {
    if (path === 'login') {
      const b = await body(req);
      const ip = realIp(req);
      if (loginBlocked(ip)) return json({ error: 'Too many wrong tries. Wait 15 minutes and try again.' }, 429);
      const a = one<Agent & { pass_hash: string }>('SELECT * FROM agents WHERE lower(username)=lower(?) AND deleted=0', String(b.username || '').trim());
      if (!a || !verifyPassword(String(b.password || ''), a.pass_hash)) { loginFailed(ip); await new Promise(r => setTimeout(r, 700)); return json({ error: 'Wrong username or password' }, 401); }
      const token = makeToken({ r: 'agent', id: a.id, v: a.session_ver });
      return json({ ok: true, token }, 200, { 'set-cookie': cookieHeader('af_agent', token) });
    }
    if (path === 'logout') return json({ ok: true }, 200, { 'set-cookie': cookieHeader('af_agent', '', 0) });

    const agent = getAgent(req);
    if (!agent) return json({ error: 'login' }, 401);
    if (req.method !== 'POST' && (path === 'online' || path === 'receive_on')) return json({ error: 'Use POST' }, 405); // v166: no change from a plain GET
    // v168: the app's background reel downloader (x-af-bg: 1, app closed) must not make the agent look online / active
    const bgReel = path.startsWith('reel/') && req.headers.get('x-af-bg') === '1';
    if (!bgReel) {
      run('UPDATE agents SET last_seen=? WHERE id=?', now(), agent.id);
      run('INSERT OR IGNORE INTO agent_active(agent_id, minute) VALUES(?,?)', agent.id, Math.floor(now() / 60000)); // v135: minutes the app was open (it polls while on screen)
    }
    // v167: Daily reel (agents and the manager; who sees it is decided on the server). Reads its own body.
    // v168: "Today's reel" download (setting OFF → 403; only the agent's own file)
    if (path.startsWith('reeldl/')) return await reelDlApi(path.slice(7), { role: agent.role === 'manager' ? 'manager' : 'agent', id: agent.id, name: agent.name }, req);
    if (path.startsWith('reel/')) return await reelUserApi(path.slice(5), { role: agent.role === 'manager' ? 'manager' : 'agent', id: agent.id, name: agent.name }, req);
    const s = getSettings();
    const b = req.method === 'POST' && !(req.headers.get('content-type') || '').includes('multipart') ? await body(req) : {};
    const url = new URL(req.url);
    const mgr = () => { if (agent.role !== 'manager') throw new HttpError(403, 'Only the manager can do this'); };
    // v141: manager → Agents → one agent's chats: ONLY with ?as_agent=<id> (explicit). Plain agents never get another agent's chat.
    const asId = num(url.searchParams.get('as_agent'));
    if (asId && agent.role !== 'manager') throw new HttpError(403, 'Only the manager can open another agent’s chats');
    const viewA = asId ? agentById(asId) : undefined;
    if (asId && (!viewA || viewA.deleted || viewA.role === 'manager')) throw new HttpError(404, 'Agent not found');
    const me = viewA ? viewA.id : agent.id; // whose chats this request is about
    type CL = Lead & { cover_agent_id?: number | null };
    const mineOrCover = (l: CL) => l.agent_id === me || l.cover_agent_id === me;
    const ownLead = (id: unknown) => { const l = leadById(num(id)) as CL | undefined; if (!l) throw new HttpError(404, 'Chat not found');
      if (!mineOrCover(l)) throw new HttpError(403, viewA ? `This chat is not ${viewA.name}’s` : 'This chat belongs to another agent');
      if (chatHeld(l.id)) throw new HttpError(409, 'This chat opens after the welcome message is sent'); return l as Lead; };
    // v141: while a cover agent has the chat, its owner can read it but not answer (one agent talks to the customer); the manager can
    const actLead = (id: unknown) => { const l = ownLead(id) as CL;
      if (l.cover_agent_id && l.cover_agent_id !== me && l.agent_id === me && agent.role !== 'manager') throw new HttpError(403, `With ${agentById(l.cover_agent_id)?.name || 'another agent'} right now (covering for you) — you can read this chat, they answer it until it comes back to you.`);
      return l as Lead; };
    const isMgrOrOwn = (id: unknown) => { const l = leadById(num(id)) as CL | undefined; if (!l) throw new HttpError(404, 'Chat not found'); if (!mineOrCover(l) && agent.role !== 'manager') throw new HttpError(403, 'This chat belongs to another agent'); return l as Lead; };
    const coverInfo = (l: { id: number; agent_id: number | null; cover_agent_id?: number | null; cover_since?: number | null }) => {
      if (!l.cover_agent_id || l.cover_agent_id === l.agent_id) return {};
      const owner = agentById(l.agent_id), cov = agentById(l.cover_agent_id);
      const deal = !!realConvAt(l.id, l.cover_agent_id, l.cover_since || 0);
      return l.cover_agent_id === me ? { cover_for: owner?.name || 'agent', cover_label: `Covering for ${owner?.name || 'agent'}` }
        : { covered_by: cov?.name || 'agent', cover_deal: deal, cover_label: `With ${cov?.name || 'agent'} (${deal ? 'deal in progress' : 'covering'})`, read_only: agent.role !== 'manager' };
    };

    if (path.startsWith('meta/')) { mgr(); return json(await metaApi(path.slice(5), req, b, { role: 'manager', id: agent.id, name: agent.name })); }
    switch (path) {
      case 'meta_chat': {
        // the client's ad accounts from our BMs + credit + free stock per type (chat → Ad account)
        const lead = isMgrOrOwn(url.searchParams.get('lead_id'));
        const free = { verified: 0, review: 0, unverified: 0 } as Record<string, number>;
        for (const a of freeAccounts('any')) if (a.bstatus === 'ok') free[tierOf(a.verification)]++;
        // v152: Premium / $25 stock (Meta daily limit) too; credit amounts only for the manager
        const mgrView = agent.role === 'manager';
        const cats = { premium: 0, std: 0 } as Record<string, number>;
        for (const a of freeAccounts('any')) if (a.bstatus === 'ok') { const c = catOf(a); if (c) cats[c]++; }
        return json({ on: metaHas(), off: !metaEnabled(), email_invites: getSettings().meta_email_invites === '1', accounts: leadMetaAccounts(lead.id), credit: mgrView ? openCredit(lead.id) : null, free, cats, free_list: mgrView ? freePickList() : undefined,
          requests: listRequests('all').filter(r => r.lead_id === lead.id).slice(0, 10).map(r => (mgrView ? r : { ...r, credit: null })),
          links: all("SELECT code, kind, label, total, amount, fee, act_id FROM pay_links WHERE lead_id=? AND status='paid' AND parts IS NULL AND code NOT IN (SELECT pay_code FROM meta_requests WHERE pay_code IS NOT NULL AND status!='rejected') ORDER BY id DESC", lead.id) });
      }
      // v152: credit amounts never go to a plain agent (only the manager sees them)
      case 'meta_hand_scan': case 'meta_hand': { // v175: delivered by hand with screenshots (manager only)
        if (agent.role !== 'manager') return json({ error: 'Manager only' }, 403);
        const H = await import('@/server/handdeliver');
        if (path === 'meta_hand_scan') return json(await H.handScan(Array.isArray(b.shots) ? b.shots : []));
        const l = isMgrOrOwn(b.lead_id);
        const o = l.agent_id && l.agent_id !== agent.id ? agentById(l.agent_id) : null;
        return json(await H.handDeliver('manager', (o && !o.deleted ? o : agent) as never, l, b));
      }
      case 'meta_free': { // v171: the manager picks the account (client without a chat)
        if (agent.role !== 'manager') return json({ error: 'Manager only' }, 403);
        return json({ accounts: freePickList() });
      }
      case 'meta_manual': {
        // v152: a client with no chat in the app (WhatsApp group etc.): agent → request for the manager, manager → shared right away
        const { manualShare } = await import('@/server/metaq');
        const out = await manualShare({ role: agent.role === 'manager' ? 'manager' : 'agent', id: agent.id, name: agent.name }, b);
        return json(agent.role === 'manager' ? out : noCredit(out));
      }
      case 'meta_request': {
        const lead = isMgrOrOwn(b.lead_id);
        const out = await createRequest({ role: agent.role === 'manager' ? 'manager' : 'agent', id: agent.id, name: agent.name }, (() => { /* v173 QA: a chat request never picks the account */ const bb = { ...b } as Record<string, unknown>; delete bb.new_act; delete bb.hand; if (bb.kind !== 'topup') delete bb.act_id; return bb; })(), lead);
        return json(agent.role === 'manager' ? out : noCredit(out));
      }
      case 'me': {
        void runFollowups();
        const full = one<{ pass_hash: string }>('SELECT pass_hash FROM agents WHERE id=?', agent.id)!;
        return json({
          agent: { id: agent.id, name: agent.name, username: agent.username, role: agent.role || 'agent', online: agent.online, receive: agent.receive, comm_per_sale: agent.comm_per_sale, comm_premium: (agent as { comm_premium?: number | null }).comm_premium ?? null, comm_funnel: (one<{ f: number | null }>('SELECT comm_funnel f FROM agents WHERE id=?', agent.id)?.f || null), tg_linked: !!agent.tg_chat_id },
          tg_link: s.bot_username ? `https://t.me/${s.bot_username}?start=ag_${agent.id}_${linkCode(agent.id, full.pass_hash)}` : null,
          has_manager: !!one("SELECT 1 FROM agents WHERE deleted=0 AND role='manager'"), web_on: webOn(s),
          // v141: receiving leads was turned off after 3 misses in a row → banner "Tap to turn it back on"
          auto_off: (() => { const x = one<{ r: number; a: number | null }>('SELECT receive r, auto_off_at a FROM agents WHERE id=?', agent.id); return !!x && !x.r && !!x.a; })(),
          // v131: WhatsApp folder (master switch ON and this agent may get WhatsApp chats; the manager always)
          wa_on: s.wati_on === '1' && (agent.role === 'manager' || (',' + String((one<{ c: string | null }>('SELECT chans c FROM agents WHERE id=?', agent.id)?.c) || 'tg') + ',').includes(',wa,')),
          brand: s.brand_name, meta_on: metaOn(), meta_acct: metaHas(), meta_off: !metaEnabled(), meta_email: s.meta_email_invites === '1', auto_acct: !!(one<{ a: number }>('SELECT COALESCE(auto_acct,0) a FROM agents WHERE id=?', agent.id)?.a), auto_topup: !!(one<{ a: number }>('SELECT COALESCE(auto_topup,0) a FROM agents WHERE id=?', agent.id)?.a), price_account: num(s.price_account), max_discount_pct: num(s.max_discount_pct, 40), ring_silent: s.alarm_on !== '0' && !ringOffFor('agent', agent.id, s), /* v144: in-app sound on silent / vibrate */ price_account_full: num(s.price_account_full), price_fb_old: num(s.price_fb_old), price_premium_full: num(s.price_premium_full), price_funnel: num(s.price_funnel), topup_pct: num(s.topup_comm_pct), topup_min: num(s.topup_min, 30), paylinks: payLinksOn(s), snd: ownSoundVer(s),
          product_msgs: productInfoMsgs(s), quick_replies: lines(fmt(s.quick_replies, s)), fu: [fmt(s.fu1, s), fmt(s.fu2, s), fmt(s.fu3, s)],
          // funnel chats: their own texts (empty funnel fields → the agency ones)
          ...(() => { const f = msgFor(s, 'funnel'); return { quick_replies_f: lines(fmt(f.quick_replies, f)), fu_f: [fmt(f.fu1, f), fmt(f.fu2, f), fmt(f.fu3, f)] }; })(),
          // Premium chats: their prices + quick replies / follow-ups with the Premium prices
          ...(() => { const p = tierFor(s, 'premium'); return { premium: { price_account: num(p.price_account), topup_pct: num(p.topup_comm_pct), quick_replies: lines(fmt(p.quick_replies, p)), fu: [fmt(p.fu1, p), fmt(p.fu2, p), fmt(p.fu3, p)] } }; })(),
          // retargeting offers (chats tagged with an offer: chats[].offer_until > now)
          offer: (() => { const a = offerOf(s, 'agency'), f = offerOf(s, 'funnel'), p = offerOf(s, 'premium'); return a || f || p ? { account: a?.price || 0, funnel: f?.price || 0, free: p?.free || 0 } : null; })(),
        });
      }
      case 'chats': {
        void runFollowups();
        try { stampCamps(); } catch (e) { console.warn('[camps]', (e as Error).message); }
        // v141: own chats + chats this agent covers for someone else; a new chat shows only after its welcome text + voice
        const rows = all<any>(`SELECT l.id, l.ch, l.camp, l.ad, l.camp_kind, l.line, l.menu, l.tier, l.offer_until, l.source, l.biz_no, l.name, l.tg_name, l.tg_username, l.phone, l.status, l.fu_stage, l.fu_due, l.remind_at, l.remind_due, l.last_in_at, l.last_out_at, l.noreply_at, l.last_text, l.last_at, l.niche, l.service, l.biz, l.agent_id, l.cover_agent_id, l.cover_since,
          (SELECT COUNT(*) FROM messages m WHERE m.lead_id=l.id AND m.dir='in' AND m.created_at>l.agent_read_at) unread,
          (SELECT dir FROM messages m WHERE m.lead_id=l.id AND m.dir!='sys' ORDER BY m.created_at DESC, m.id DESC LIMIT 1) last_dir
          FROM leads l WHERE (l.agent_id=? OR l.cover_agent_id=?) AND l.tg_chat_id IS NOT NULL AND l.status!='merged' AND NOT ${welcomePendingSql('l')} ORDER BY l.last_at DESC LIMIT 1000`, me, me);
        assignCalls();
        const callsTodo = one<{ n: number }>(`SELECT COUNT(*) n FROM leads l WHERE l.call_agent_id=? AND ${callTodoSql('l')}`, me)!.n;
        const hotN = one<{ n: number }>(`SELECT COUNT(*) n FROM leads l WHERE ${agent.role === 'manager' && !viewA ? '1=1' : 'l.agent_id=' + Number(me)} AND ${hotSql('l')} AND l.call_state IS NULL AND NOT ${welcomePendingSql('l')}`)!.n;
        const st = getSettings();
        // v132: WhatsApp chats carry the contact name we save for them in our apps (WhatsApp has no API to save it on the phone)
        const [tf, tt] = dayRange('today', st); // v136: header line "Today 2 sales · $4 earned"
        const today = viewA ? null : one<{ n: number; rev: number; c: number }>(`SELECT COUNT(*) n, COALESCE(SUM(amount),0) rev, ${commSql('?', 'x.created_at>=? AND x.created_at<?')} c FROM sales WHERE agent_id=? AND created_at>=? AND created_at<?`, agent.id, tf, tt, agent.id, tf, tt, agent.id, tf, tt); // v141: split sales by their share
        return json({ chats: rows.map(r => { const x = { ...r, ...coverInfo(r), ...chipsOf(r) /* v142: campaign chip + line badge */ }; delete x.agent_id; delete x.cover_agent_id; delete x.cover_since; return r.ch === 'wa' ? { ...x, contact: contactName(r, st) } : x; }), calls_todo: callsTodo, hot_n: hotN, today, ...(viewA ? { as_agent: { id: viewA.id, name: viewA.name } } : {}) });
      }
      // people who filled the form but never messaged → this agent phones them
      case 'calls': {
        assignCalls();
        const rows = all<any>(`SELECT l.* FROM leads l WHERE l.call_agent_id=? AND ${callSql('l')} ORDER BY (l.call_state IS NULL OR l.call_state='no_answer') DESC, (l.call_state='interested') DESC, l.created_at DESC LIMIT 500`, me);
        return json({ calls: rows.map(l => ({
          id: l.id, name: l.name, phone: l.phone, email: l.email, service: l.service, biz: l.biz, has_bm: l.has_bm, niche: l.niche, budget: l.budget, theme: l.theme, line: l.line, created_at: l.created_at,
          call_state: l.call_state, call_at: l.call_at, call_by: l.call_by, call_note: l.call_note, wa_text: l.phone ? waText(s, l, baseUrl(req)) : null,
        })) });
      }
      // hot leads: talked on Telegram, then went quiet → call them (manager: everyone's, agent: own)
      case 'hot': {
        const rows = all<any>(`SELECT l.*, (SELECT name FROM agents a WHERE a.id=l.agent_id) agent_name, (SELECT CASE WHEN m.file_type IS NOT NULL AND COALESCE(m.text,'')='' THEN '[' || m.file_type || ']' ELSE m.text END FROM messages m WHERE m.lead_id=l.id AND m.dir='in' AND NOT (${emptyInSql('m')}) ORDER BY m.created_at DESC, m.id DESC LIMIT 1) last_in_text FROM leads l WHERE ${agent.role === 'manager' && !viewA ? '1=1' : 'l.agent_id=' + Number(me)} AND ${hotSql('l')} AND NOT ${welcomePendingSql('l')} ORDER BY (l.call_state IS NULL) DESC, l.last_in_at DESC LIMIT 300`);
        return json({ hot: rows.map(l => ({
          id: l.id, name: l.name || l.tg_name, phone: l.phone, email: l.email, service: l.service, biz: l.biz, has_bm: l.has_bm, niche: l.niche, budget: l.budget, theme: l.theme, line: l.line, created_at: l.created_at,
          last_in_at: l.last_in_at, last_text: l.last_in_text || l.last_text, tg_username: l.tg_username, agent_name: l.agent_id !== me ? l.agent_name : null, mine: l.agent_id === me,
          call_state: l.call_state, call_at: l.call_at, call_by: l.call_by, call_note: l.call_note, wa_text: l.phone ? waText(s, l, baseUrl(req)) : null,
        })) });
      }
      // AI coach: next step + ready replies for this chat
      case 'ai_coach': return json(await AI.aiCoach(isMgrOrOwn(b.lead_id), b.force === true));
      case 'ai_feedback': { const l = isMgrOrOwn(b.lead_id); AI.aiFeedback(l.id, agent.id, String(b.suggested || ''), String(b.sent || '')); return json({ ok: true }); }
      case 'ai_chat_state': {
        const l = isMgrOrOwn(b.lead_id);
        run('UPDATE leads SET ai_state=?, ai_done_msg=(SELECT MAX(id) FROM messages WHERE lead_id=?) WHERE id=?', b.state === 'paused' ? 'paused' : null, l.id, l.id);
        addMsgAi(l, { dir: 'sys', sender: 'system', text: b.state === 'paused' ? `🤖 AI paused in this chat (${agent.name})` : `🤖 AI resumed in this chat (${agent.name})` });
        return json({ ok: true });
      }
      case 'call_mark': {
        const l = leadById(num(b.lead_id));
        if (!l || ((l as any).call_agent_id !== agent.id && l.agent_id !== agent.id && agent.role !== 'manager')) throw new HttpError(404, 'Lead not found');
        return json({ ok: true, lead: markCall(l.id, String(b.state || ''), String(b.note || ''), agent.name) });
      }
      case 'chat': {
        stampLead(num(url.searchParams.get('id'))); // v130: which campaign / ad
        const lead = ownLead(url.searchParams.get('id'));
        const after = num(url.searchParams.get('after'));
        const page = chatPage(lead.id, after, 1000, true); // v139: by real time (created_at, then id); v141: + who sent it ("Akash (manager)")
        const msgs = page.messages;
        const deleted = all('SELECT id, deleted_by FROM messages WHERE lead_id=? AND deleted_at IS NOT NULL', lead.id); // v137
        if (!viewA) markReadEverywhere(lead); // v113: seen in the agent app = seen in the admin app + Telegram (v141: the manager looking at an agent's chats leaves them unread for the agent)
        waPhoneSyncSoon(lead); // v137: replies typed in the WhatsApp Business app (background, max once a minute)
        const { ip, ua, fbc, fbp, fbclid, token, vid, biz_conn, tg_access_hash, ...safe } = lead as Lead;
        return json({ cursor: page.cursor,
          lead: { ...safe, ...coverInfo(lead as CL), ...chipsOf(lead as any), ...(lead.ch === 'wa' ? { contact: contactName(lead as any, getSettings()) } : {}), prices: leadPrices(getSettings(), lead), texts: offerTexts(getSettings(), lead), wa_text: lead.phone ? waText(getSettings(), lead, baseUrl(req)) : null, ai_active: AI.aiActiveFor(lead as any), ai_auto_agent: AI.autoAgents().includes(lead.agent_id || 0), coach_on: getSettings().ai_coach_on === '1' && AI.aiReady() }, messages: msgs.map(m => m.agent_id && m.sender !== 'agent' ? { ...m, agent_name: null } : m), read_upto: one<{ v: number | null }>("SELECT MAX(id) v FROM messages WHERE lead_id=? AND dir='out' AND read_at IS NOT NULL", lead.id)?.v || 0, delivered_upto: one<{ v: number | null }>("SELECT MAX(id) v FROM messages WHERE lead_id=? AND dir='out' AND delivered_at IS NOT NULL", lead.id)?.v || 0, deleted, me_id: agent.id,
          sales: all(`SELECT x.service, x.qty, x.amount, x.list_price, x.created_at, CASE WHEN x.owner_agent_id IS NOT NULL AND x.agent_id!=x.owner_agent_id AND a.role!='manager' THEN 'sold by ' || a.name || ' (covering for ' || o.name || ')' END cover_note,
            (SELECT reason FROM sale_splits p WHERE p.sale_id=x.id LIMIT 1) split_reason FROM sales x LEFT JOIN agents a ON a.id=x.agent_id LEFT JOIN agents o ON o.id=x.owner_agent_id WHERE x.lead_id=? ORDER BY x.id`, lead.id), // v141: no commission numbers here
          topups: all('SELECT amount, commission, note, created_at FROM topups WHERE lead_id=? ORDER BY id', lead.id),
        });
      }
      case 'paylink': return json(createPayLink(actLead(b.lead_id), agent.id, b, { noMin: agent.role === 'manager', free: agent.role === 'manager' }));
      case 'lead_accounts': return json({ accounts: leadAccounts(ownLead(url.searchParams.get('lead_id')).id) });
      case 'paylinks': return json(chatLinksAndItems(ownLead(url.searchParams.get('lead_id')))); // v144: + the chat's product catalog
      case 'del_request': return json(await requestDelete(ownLead(b.lead_id), agent, b.reason));
      case 'paylink_cancel': { // v166: the manager can cancel any agent's link; an agent only their own, in a chat they still answer
        const pl = one<{ lead_id: number | null }>('SELECT lead_id FROM pay_links WHERE id=?', num(b.id));
        if (agent.role !== 'manager' && pl?.lead_id) actLead(pl.lead_id);
        return json(cancelPayLink(num(b.id), agent.role === 'manager' ? null : agent.id, { by: agent.id }));
      }
      // v122: WhatsApp payment links (agent app → menu)
      case 'wa_paylink': return json(createWaPayLink(agent, b));
      case 'wa_paylinks': return json({ on: payLinksOn(s), links: waPayLinks(agent.id, agent.role === 'manager'), items: WA_ITEMS.map(x => ({ k: x.k, label: x.label, price: waPrice(s, x.k) })), topup_pct: num(s.topup_comm_pct, 3), premium_pct: num(tierFor(s, 'premium').topup_comm_pct, 3), topup_min: num(s.topup_min, 30) });
      case 'forward': return json(await forwardToManager(actLead(b.lead_id), agent.id, b));
      case 'tasks': { mgr(); return json({ tasks: listTasks(url.searchParams.get('status') === 'done' ? 'done' : 'open') }); }
      case 'task_done': { mgr(); return json(await completeTask(num(b.id), b, 'manager:' + agent.id)); }
      case 'mark_paid': { mgr(); return json(await markPaid(b.type === 'topup' ? 'web_topups' : 'web_orders', num(b.id), 'manager:' + agent.id)); }
      case 'cancel_item': { mgr(); return json(cancelItem(b.type === 'topup' ? 'web_topups' : 'web_orders', num(b.id), null)); }
      case 'remind': return json(setReminder(actLead(b.lead_id), b.at, b.note, 'agent:' + agent.id));
      case 'send': { const l = actLead(b.lead_id); await sendOnceByCid(b.cid, l.id, () => sendToLead(l, String(b.text || ''), 'agent', agent.id, num(b.reply_to) || null)); return json({ ok: true }); } // v166: + cid (no double send on a retry) // v141: the manager in an agent's chat = sent by the manager, the chat stays the agent's
      // v137: delete our message (Telegram: for everyone; WhatsApp: for us only)
      case 'msg_delete': { const { deleteMessage } = await import('@/server/msgdelete'); return json(await deleteMessage(num(b.id), { role: agent.role === 'manager' ? 'manager' : 'agent', id: agent.id, name: agent.name }, lid => { try { (agent.role === 'manager' ? isMgrOrOwn : actLead)(lid); return true; } catch { return false; } })); }
      case 'upload': {
        const form = await req.formData();
        await uploadToLead(actLead(form.get('lead_id')), form, 'agent', agent.id);
        return json({ ok: true });
      }
      case 'sold': {
        if (agent.role !== 'manager') throw new HttpError(403, 'Only the manager can mark a chat as sold');
        const l = isMgrOrOwn(b.lead_id);
        // the chat's own agent keeps the commission when the manager marks it (v141: a covered chat → the cover, see saleCredit)
        const o = l.agent_id && l.agent_id !== agent.id ? agentById(l.agent_id) : null;
        const owner = o && !o.deleted ? o : null; // v166: a deleted agent's chat → the manager's sale (like the admin path)
        return json({ ok: true, ...(await recordSale(l, owner ? { ...owner, deleted: 0 } : { ...agent, deleted: 0 }, { ...b, closed_by: agent.id })) });
      }
      case 'topup': { const l = actLead(b.lead_id); const ow = agent.role === 'manager' && l.agent_id && l.agent_id !== agent.id ? agentById(l.agent_id) : undefined; return json({ ok: true, ...addTopup(l, ow && !ow.deleted ? ow : { ...agent, deleted: 0 }, b.amount, b.note, undefined, !!b.force) }); }
      case 'wa_sales': case 'wa_sale_add': case 'wa_sale_del': case 'wa_sale_edit': case 'wa_topup_add': case 'wa_topup_del': {
        if (agent.role !== 'manager') throw new HttpError(403, 'Only the manager can add WhatsApp sales');
        return json(path === 'wa_sales' ? listWaSales() : path === 'wa_topup_add' ? addWaTopup(b, { name: agent.name, agent_id: agent.id }) : path === 'wa_topup_del' ? delWaTopup(b.id) : path === 'wa_sale_add' ? addWaSale(b, { name: agent.name, agent_id: agent.id }) : path === 'wa_sale_edit' ? editWaSale(b.id, b.amount) : delWaSale(b.id));
      }
      case 'lead_type': {
        if (agent.role !== 'manager') throw new HttpError(403, 'Only the manager can change the chat type');
        return json(setLeadType(isMgrOrOwn(b.lead_id), String(b.type || ''), agent.name));
      }
      case 'lead_status': {
        const lead = actLead(b.lead_id);
        if (b.status === 'dead' && (lead.status === 'sold' || lead.sold_at) && agent.role !== 'manager') throw new HttpError(400, 'Only the manager or admin can move a Sold chat to Dead');
        const st = b.status === 'dead' ? 'dead' : lead.sold_at ? 'sold' : 'active'; // v146
        run("UPDATE leads SET status=?, fu_due=0, fu_stage=0, last_in_at=CASE WHEN ?='active' THEN ? ELSE last_in_at END WHERE id=?", st, st, now(), lead.id);
        waSyncSoon(b.lead_id ? num(b.lead_id) : null); // v137 (WATI Pro): Dead → SOLVED, attributes
        return json({ ok: true });
      }
      // v141: the agent turns receiving leads back on after an auto-off (not after the admin / manager turned it off by hand)
      case 'receive_on': {
        const x = one<{ r: number; a: number | null }>('SELECT receive r, auto_off_at a FROM agents WHERE id=?', agent.id)!;
        if (x.r) return json({ ok: true });
        if (!x.a) throw new HttpError(403, 'Your admin turned receiving leads off. Ask them to turn it back on.');
        await setReceive(agent.id, true, 'the agent, from the banner'); return json({ ok: true });
      }
      // v141: manager → Agents: the team (not the manager) with their open / waiting chats — no money numbers
      case 'team': {
        mgr();
        const rows = all<any>(`SELECT a.id, a.name, a.online, a.receive, a.auto_off_at, a.last_seen,
            (SELECT COUNT(*) FROM leads l WHERE (l.agent_id=a.id OR l.cover_agent_id=a.id) AND l.status='active' AND l.tg_chat_id IS NOT NULL AND NOT ${welcomePendingSql('l')}) open,
            (SELECT COUNT(*) FROM leads l WHERE ((l.agent_id=a.id AND l.cover_agent_id IS NULL) OR l.cover_agent_id=a.id) AND ${needsReplySql('l')}) waiting,
            (SELECT COUNT(*) FROM leads l WHERE l.cover_agent_id=a.id) covering
          FROM agents a WHERE a.deleted=0 AND COALESCE(a.role,'agent')!='manager' ORDER BY a.name`);
        return json({ agents: rows.map(a => ({ ...a, ...presence(a.last_seen) })) });
      }
      // v141: the manager moves a chat for good (Assign) — ends any cover; the manager can also switch an agent's receiving leads
      case 'assign': {
        mgr();
        const l = leadById(num(b.lead_id)); const to = agentById(num(b.agent_id));
        if (!l) throw new HttpError(404, 'Chat not found');
        if (!to || to.deleted) throw new HttpError(404, 'Agent not found');
        run('UPDATE leads SET agent_id=?, assigned_at=?, agent_read_at=0, tried_agents=NULL WHERE id=?', to.id, now(), l.id);
        clearCoverForAssign(l.id);
        addMsg(l, { dir: 'sys', sender: 'system', text: `🔁 Assigned to ${to.name} (by ${agent.name}, manager)` });
        agentLog(to.id, 'assigned', `#${l.id} assigned by ${agent.name} (manager)`, l.id);
        waSyncSoon(l.id);
        await notifyAgent(to, `🔁 Lead #${l.id} ${displayName(l)} was assigned to you.\n↩️ Reply to this message to answer.`, l.id, { title: 'Chat assigned to you', body: displayName(l) });
        return json({ ok: true });
      }
      case 'agent_receive': { mgr(); const a = agentById(num(b.id)); if (!a || a.deleted || a.role === 'manager') throw new HttpError(404, 'Agent not found'); return json(await setReceive(a.id, !!b.receive, `${agent.name} (manager)`)); }
      // v141: cash / offline payouts (manager only; delete within 24 h)
      case 'cash_payouts': { mgr(); return json(cashPayouts(num(url.searchParams.get('agent')) || null)); }
      case 'cash_payout_add': { mgr(); return json(addCashPayout(b, { role: 'manager', id: agent.id, name: agent.name })); }
      case 'cash_payout_del': { mgr(); return json(delCashPayout(b.id, { role: 'manager', id: agent.id, name: agent.name })); }
      case 'online': { run('UPDATE agents SET online=? WHERE id=?', b.online ? 1 : 0, agent.id); return json({ ok: true }); }
      // v159: the agent's own dashboard (Home) — leads, messages, hot, customers, sold, earnings + incentive
      case 'dashboard': { const [f, t] = dayRange(url.searchParams.get('range'), s); return json({ range: url.searchParams.get('range') || 'today', ...(await import('@/server/bonus')).agentDashboard(agent.id, f, t) }); }
      case 'wallet': {
        const [f, t] = dayRange('today', s);
        return json({
          wallet: wallet(agent.id),
          payouts: all('SELECT id, amount, method, status, note, created_at, done_at, kind, cur, orig_amount, by_name, by_role, pay_date FROM payouts WHERE agent_id=? ORDER BY COALESCE(pay_date, created_at) DESC, id DESC LIMIT 50', agent.id), // v141: + cash payouts
          splits: all('SELECT p.share, p.reason, x.created_at, x.amount FROM sale_splits p JOIN sales x ON x.id=p.sale_id WHERE p.agent_id=? ORDER BY x.id DESC LIMIT 20', agent.id), // v141: 50/50 cover splits
          today: one(`SELECT COUNT(*) n, COALESCE(SUM(amount),0) rev, ${commSql('?', 'x.created_at>=? AND x.created_at<?')} c FROM sales WHERE agent_id=? AND created_at>=? AND created_at<?`, agent.id, f, t, agent.id, f, t, agent.id, f, t),
          topups_today: one('SELECT COALESCE(SUM(amount),0) v, COALESCE(SUM(commission),0) c FROM topups WHERE agent_id=? AND created_at>=? AND created_at<?', agent.id, f, t),
          bonus_today: money(one<{ v: number }>('SELECT COALESCE(SUM(amount),0) v FROM agent_bonus WHERE agent_id=? AND created_at>=? AND created_at<?', agent.id, f, t)!.v), // v162: earned today = commission + incentive
        });
      }
      case 'payout': {
        const amount = money(b.amount);
        const w = wallet(agent.id);
        if (!(amount > 0) || amount > w.available) throw new HttpError(400, `You can request up to $${w.available}`);
        const method = b.method === 'usdt' ? 'usdt' : 'bank';
        const details = String(b.details || '').trim().slice(0, 300);
        if (method === 'usdt' && !/^0x[a-fA-F0-9]{40}$/.test(details)) throw new HttpError(400, 'Enter a valid USDT BEP20 address (starts with 0x, 42 characters)');
        if (method === 'bank' && details.length < 6) throw new HttpError(400, 'Enter account holder name, account number and IFSC or UPI ID');
        run("INSERT INTO payouts(agent_id, amount, method, details, status, created_at) VALUES(?,?,?,?, 'pending', ?)", agent.id, amount, method, details, now());
        void pushTo('admin', null, '💳 Payout request', `${agent.name} requested $${amount}`);
        return json({ ok: true });
      }
      case 'push_register': return json(registerToken('agent', agent.id, String(b.token || ''), String(b.platform || 'android'), { native: b.native === 1 || b.native === true, app_version: b.app_version, device: b.device })); // v139: + native / app version / device
      case 'push_seen': return json((await import('@/server/push')).noteSeen('agent', agent.id, (b || {}) as Record<string, unknown>, req.headers.get('user-agent') || '')); // v143: app opened (version)
      case 'push_debug': return json((await import('@/server/push')).savePushDebug('agent', agent.id, (b || {}) as Record<string, unknown>)); // v139: a failed push setup step
      // v139: a login token for the phone's own (Java) calls — push_register / push_report work without the WebView cookie
      case 'native_auth': return json({ token: makeToken({ r: 'agent', id: agent.id, v: agent.session_ver }, 60), role: 'agent' });
      case 'push_report': return json((await import('@/server/push')).saveRingReport('agent', agent.id, (b || {}) as Record<string, unknown>)); // v137: what the phone played
    }
    return json({ error: 'Not found' }, 404);
  } catch (e) { return fail(e, !!getAgent(req)); }
}

export const GET = handle;
export const POST = handle;

/** v152: drop every credit amount from a reply (plain agents never see the client's credit). */
function noCredit<T>(v: T): T {
  if (Array.isArray(v)) return v.map(noCredit) as unknown as T;
  if (v && typeof v === 'object') {
    const o: Record<string, unknown> = {};
    for (const [k, x] of Object.entries(v as Record<string, unknown>)) if (k !== 'credit' && k !== 'credit_used') o[k] = noCredit(x);
    return o as T;
  }
  return v;
}
