import { run } from '@/server/db';
import { getSettings } from '@/server/settings';
import { sendCapi, buildUserData, clickIds } from '@/server/capi';
import { json, body, clientIp, getCookie } from '@/server/http';
import { isBot, now } from '@/server/util';
import { campOfReq, noteVisitCamp } from '@/server/camps';
import { noteStep, pageKey } from '@/server/funnel'; // v168: landing page funnel steps (stored only; no Meta event)

export const dynamic = 'force-dynamic';

/** PageView (once a day) + ViewContent (once) per visitor — fired by the landing page after the visitor has watched it for a few seconds. ViewContent — once per visitor (event_id = vc_<visitor id>). Fired by the landing page in the browser. */
// v127: one IP can't flood Meta with made-up visits (new visitor id every time)
const byIp = new Map<string, number[]>();
function tooMany(ip: string) {
  const t = Date.now(), h = (byIp.get(ip) || []).filter(x => x > t - 10 * 60000);
  h.push(t); byIp.set(ip, h);
  if (byIp.size > 20000) for (const [k, v] of byIp) if (!v.some(x => x > t - 10 * 60000)) byIp.delete(k);
  return h.length > 40;
}

export async function POST(req: Request) {
  if (tooMany(clientIp(req))) return json({ ok: true });
  const b = await body(req);
  const ua = req.headers.get('user-agent') || '';
  const vid = getCookie(req, 'af_vid');
  if (!vid || isBot(ua)) return json({ ok: true });
  const s = getSettings();
  const ids = clickIds(req, String(b.url || ''));
  // Funnel page (/funnel) events go to the funnel pixel, with their own event ids (a visitor can see both pages)
  const line = b.line === 'funnel' ? 'funnel' : 'agency';
  // /premium: its own events (own ids + "(Premium)" names) so it can have its own retargeting audience on the same pixel
  let path = ''; try { path = new URL(String(b.url || '')).pathname; } catch { /* no url */ }
  const prem = line === 'agency' && /^\/premium(\/|$)/.test(path);
  // v131: the WhatsApp ad pages → the WhatsApp pixels (Agency + Premium · Funnel)
  const wa = /^\/(agency|premium|funnel)\/(whatsapp|community)(\/|$)/.test(path) ? 'wa' : null;
  const px = line === 'funnel' ? 'f_' : prem ? 'p_' : '';
  const P = prem ? ' (Premium)' : '';
  // v168: a funnel step the landing page reports (reached the name + number step) — stored for Home's funnel only, never sent to Meta
  if (b.ev === 'step') { if (b.step === 'form') noteStep(vid, pageKey(path, line), 'form'); return json({ ok: true }); }
  if (b.ev === 'atc') {
    noteStep(vid, pageKey(path, line), 'cta'); // v168: tapped Order / Chat (the AddToCart below is unchanged)
    // AddToCart — pressed an Order / Chat button. Once per visitor.
    const what = ['account', 'funnel', 'chat', 'website'].includes(String(b.what)) ? String(b.what) : 'account';
    const r = await sendCapi(s, {
      ch: wa, line, event_id: px + 'atc_' + vid, event_name: 'AddToCart', source_url: String(b.url || '').slice(0, 500),
      user_data: buildUserData({ ip: clientIp(req), ua, fbc: ids.fbc, fbp: ids.fbp, vid }, s),
      custom_data: { content_name: (what === 'funnel' ? 'Landing + Funnel' : what === 'chat' ? 'Chat with agent' : what === 'website' ? 'Ad Account (website)' : 'Ad Account') + P, currency: 'USD', value: what === 'chat' ? undefined : Number(what === 'funnel' ? s.price_funnel : what === 'website' ? (prem ? s.price_premium_web : s.price_account_web) : (prem ? s.price_premium : s.price_account)) || undefined },
    });
    return json({ ok: true, dedup: 'dedup' in r });
  }
  run('INSERT OR IGNORE INTO visits(vid, theme, created_at) VALUES(?,?,?)', vid, String(b.theme || s.theme).slice(0, 10), now());
  noteVisitCamp(vid, campOfReq(req, String(b.url || ''))); // v130: which campaign / ad
  // per page too (Agency / Funnel / /telegram), so Home can show each page's visitors
  const chp = path.match(/^\/(agency|premium|funnel)\/telegram(\/|$)/); // v114: channel-ad pages
  const wap = path.match(/^\/(agency|premium|funnel)\/(whatsapp|community)(\/|$)/); // v131: WhatsApp ad pages
  run('INSERT OR IGNORE INTO page_visits(vid, page, created_at) VALUES(?,?,?)', vid, wap ? 'wa_' + wap[1] : chp ? 'ch_' + chp[1] : /^\/telegram(\/|$)/.test(path) ? 'telegram' : /^\/premium(\/|$)/.test(path) ? 'premium' : line, now());
  if (wap) noteStep(vid, pageKey(path, line), 'view'); // v168: the WhatsApp chat page and the community page counted apart
  const ud = buildUserData({ ip: clientIp(req), ua, fbc: ids.fbc, fbp: ids.fbp, vid }, s);
  const url = String(b.url || '').slice(0, 500);
  // PageView once per visitor per day (for "website visitors" retargeting audiences)
  void sendCapi(s, { ch: wa, line, event_id: px + 'pv_' + vid + '_' + new Date().toISOString().slice(0, 10), event_name: 'PageView', source_url: url, user_data: ud }).catch(() => {});
  const r = await sendCapi(s, {
    ch: wa, line, event_id: px + 'vc_' + vid, event_name: 'ViewContent', source_url: url,
    user_data: ud,
    custom_data: { content_name: line === 'funnel' ? 'Funnel landing' : prem ? 'Premium landing' : 'Landing', content_category: String(b.theme || s.theme) },
  });
  return json({ ok: true, dedup: 'dedup' in r });
}
