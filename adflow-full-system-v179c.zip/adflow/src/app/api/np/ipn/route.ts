import { getSettings } from '@/server/settings';
import { npVerify } from '@/server/nowpay';
import { handleIpn } from '@/server/shop';
import { payLinkIpn } from '@/server/paylinks';
import { json } from '@/server/http';

export const dynamic = 'force-dynamic';

/** NOWPayments payment status callback (IPN). Signature = HMAC-SHA512 of the sorted JSON with the IPN secret. */
export async function POST(req: Request) {
  const raw = await req.text();
  let body: Record<string, unknown>;
  try { body = JSON.parse(raw); } catch { return json({ error: 'bad json' }, 400); }
  const s = getSettings();
  if (!npVerify(s, body, req.headers.get('x-nowpayments-sig'))) { console.warn('[ipn] bad signature'); return json({ error: 'bad signature' }, 401); }
  try { return json(String(body.order_id || '').startsWith('PL-') ? await payLinkIpn(body) : await handleIpn(body)); } catch (e) { console.error('[ipn]', e); return json({ error: 'failed' }, 500); }
}
