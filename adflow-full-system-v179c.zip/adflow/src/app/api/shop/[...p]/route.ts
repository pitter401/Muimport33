import { one, all } from '@/server/db';
import { getSettings, isRtUrl } from '@/server/settings';
import { getCustomer, makeToken, cookieHeader } from '@/server/auth';
import { json, body, fail, clientIp, getCookie } from '@/server/http';
import { num, HttpError } from '@/server/util';
import { clickIds } from '@/server/capi';
import { coinList } from '@/server/nowpay';
import {
  webOn, prices, shopSettings, sendOtp, guestCustomer, orderKey, checkOrderKey, verifyOtp, createOrder, startPayment, submitUtr, createTopup, cancelItem, customerAccounts, inrInfo, managerLink, cryptoInfo, refreshCrypto, leadPrefill,
  type Order, type Topup, type Customer,
} from '@/server/shop';

export const dynamic = 'force-dynamic';

const pub = (o: Order) => ({ id: o.id, code: o.code, kind: o.kind, full: o.full ? 1 : 0, qty: o.qty, bm_id: o.bm_id, amount: o.amount, status: o.status, pay_method: o.pay_method, inr_amount: o.inr_amount, utr: o.utr, accounts: o.accounts ? o.accounts.split(',').map(a => 'act_' + a) : [], created_at: o.created_at, delivered_at: o.delivered_at, paid_at: o.paid_at });
const pubT = (t: Topup) => ({ id: t.id, code: t.code, act_id: t.act_id, amount: t.amount, fee: t.fee, total: t.total, status: t.status, pay_method: t.pay_method, inr_amount: t.inr_amount, utr: t.utr, created_at: t.created_at, done_at: t.done_at });

async function handle(req: Request, ctx: { params: Promise<{ p: string[] }> }) {
  const path = (await ctx.params).p.join('/');
  try {
    const s = getSettings();
    if (path === 'config') {
      // /order?tier=premium → the Premium website price and delivery
      const tier = new URL(req.url).searchParams.get('tier') === 'premium' && s.premium_on === '1' ? 'premium' : '';
      const rt = getCookie(req, 'af_rt') === '1' || new URL(req.url).searchParams.get('rt') === '1';
      const { s: st, offer } = shopSettings(s, tier, rt);
      const p0 = prices(st);
      // /products links (given to Telegram / WhatsApp customers) → Telegram prices
      const tgp = new URL(req.url).searchParams.get('tg') === '1';
      const p = tgp ? { ...p0, account: num(st.price_account), funnel: num(st.price_funnel) } : p0;
      const c = getCustomer(req);
      return json({
        on: webOn(s), brand: s.brand_name, prices: p, tgp, offer, delivery: st.delivery_time, tier, premium_title: tier ? s.premium_title : '',
        coins: coinList(s), crypto: !!s.np_api_key,
        inr: s.inr_on === '1', inr_rate: num(s.inr_rate, 90), upi: s.inr_on === '1' && s.upi_on === '1' && !!s.upi_id.trim(), manager: managerLink(s),
        customer: c ? { email: c.email, name: c.name, phone: c.phone } : null,
      });
    }
    if (!webOn(s)) throw new HttpError(404, 'Website orders are switched off');
    const b = req.method === 'POST' ? await body(req) : {};
    if (path === 'prefill') return json({ ok: true, lead: leadPrefill(new URL(req.url).searchParams.get('lead')) });
    if (path === 'otp_send') return json(await sendOtp(b.email, clientIp(req)));
    if (path === 'otp_verify') {
      const c = verifyOtp(b.email, b.code);
      const token = makeToken({ r: 'cust', id: c.id, v: c.session_ver }, 90);
      return json({ ok: true, customer: { email: c.email, name: c.name, phone: c.phone } }, 200, { 'set-cookie': cookieHeader('af_cust', token, 90) });
    }
    if (path === 'logout') return json({ ok: true }, 200, { 'set-cookie': cookieHeader('af_cust', '', 0) });

    const type = (v: unknown) => (v === 'topup' ? 'web_topups' : 'web_orders') as 'web_orders' | 'web_topups';
    const fp = () => { const ids = clickIds(req, String(b.page_url || '')); return { ip: clientIp(req), ua: req.headers.get('user-agent') || '', fbc: ids.fbc, fbp: ids.fbp, page_url: String(b.page_url || '') }; };
    const url = new URL(req.url);
    const rtOf = (x: Record<string, unknown>) => getCookie(req, 'af_rt') === '1' || isRtUrl(x.page_url);
    const logged = getCustomer(req);
    // Orders: no login needed — the person who placed it gets a secret key for its payment page
    if (path === 'order_create' && !logged) {
      const g = guestCustomer(b.email, clientIp(req));
      const o = await createOrder(g, { ...b, rt: rtOf(b) }, fp(), true);
      return json({ ok: true, order: pub(o), key: orderKey(o.code) });
    }
    let cust = logged;
    const hasKey = path === 'item' ? !!url.searchParams.get('key') : !!b.key;
    if (hasKey && ['pay', 'utr', 'cancel', 'item'].includes(path)) {
      cust = null; // a key opens exactly that one order, whoever is logged in
      const isOrder = (path === 'item' ? url.searchParams.get('type') : b.type) !== 'topup';
      const key = path === 'item' ? url.searchParams.get('key') : b.key;
      const code = path === 'item' ? String(url.searchParams.get('code') || '') : String(b.code || '');
      const row = isOrder && key ? one<Order>(path === 'item' || code ? 'SELECT * FROM web_orders WHERE code=?' : 'SELECT * FROM web_orders WHERE id=?', path === 'item' || code ? code : num(b.id)) : undefined;
      if (row && checkOrderKey(row.code, key) && (path === 'item' || !b.id || num(b.id) === row.id)) cust = one<Customer>('SELECT * FROM customers WHERE id=?', row.customer_id) || null;
    }
    if (!cust) return json({ error: 'login' }, 401);

    switch (path) {
      case 'me': return json({
        customer: { email: cust.email, name: cust.name, phone: cust.phone },
        orders: all<Order>('SELECT * FROM web_orders WHERE customer_id=? ORDER BY id DESC LIMIT 100', cust.id).map(pub),
        topups: all<Topup>('SELECT * FROM web_topups WHERE customer_id=? ORDER BY id DESC LIMIT 100', cust.id).map(pubT),
        accounts: customerAccounts(cust.id).map(a => ({ id: a.id, act_id: 'act_' + a.act_id, created_at: a.created_at })),
      });
      case 'order_create': {
        const o = await createOrder(cust, { ...b, rt: rtOf(b) }, fp());
        return json({ ok: true, order: pub(o), key: orderKey(o.code) });
      }
      case 'topup_create': return json({ ok: true, topup: pubT(createTopup(cust, b)) });
      case 'pay': return json(await startPayment(type(b.type), num(b.id), cust, b));
      case 'utr': return json(await submitUtr(type(b.type), num(b.id), cust, b.utr));
      case 'cancel': return json(cancelItem(type(b.type), num(b.id), cust.id));
      case 'item': {
        const t = type(url.searchParams.get('type'));
        let row = one<Order & Topup>(`SELECT * FROM ${t} WHERE code=? AND customer_id=?`, String(url.searchParams.get('code') || ''), cust.id);
        if (!row) throw new HttpError(404, 'Not found');
        if (url.searchParams.get('check')) { await refreshCrypto(t, row.id); row = one<Order & Topup>(`SELECT * FROM ${t} WHERE id=?`, row.id)!; }
        const extra = row.pay_method === 'inr' && row.inr_amount ? inrInfo(s, row.code, row.inr_amount) : null;
        return json({ item: t === 'web_orders' ? pub(row) : pubT(row), inr: extra, crypto: row.pay_method === 'crypto' && row.status === 'pending_payment' ? cryptoInfo(row) : null, manager: managerLink(s) });
      }
    }
    return json({ error: 'Not found' }, 404);
  } catch (e) { return fail(e); }
}
export const GET = handle;
export const POST = handle;
