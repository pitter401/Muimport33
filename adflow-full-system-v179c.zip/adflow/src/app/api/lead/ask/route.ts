import { one, run } from '@/server/db';
import { json, body, fail } from '@/server/http';
import { now, HOUR } from '@/server/util';
import { createTask, validEmail, normEmail } from '@/server/shop';
import { addMsg, type Lead } from '@/server/crm';

export const dynamic = 'force-dynamic';

/** "Chat with agent" when Telegram didn't open: the visitor leaves an email + question → a task for the manager. Once per lead. */
export async function POST(req: Request) {
  try {
    const b = await body(req);
    const t = String(b.t || '');
    if (!/^[A-Za-z0-9]{8,40}$/.test(t)) return json({ ok: false, error: 'Please refresh the page and try again.' }, 400);
    const lead = one<Lead & { ask_sent: number | null }>('SELECT * FROM leads WHERE token=? AND created_at>?', t, now() - 24 * HOUR);
    if (!lead) return json({ ok: false, error: 'Please refresh the page and try again.' }, 404);
    const email = normEmail(b.email);
    if (!validEmail(email)) return json({ ok: false, error: 'Enter a valid email address.' }, 400);
    const q = String(b.question || '').trim().slice(0, 600);
    if (lead.ask_sent) return json({ ok: true, already: true });
    run("UPDATE leads SET email=COALESCE(NULLIF(email,''), ?), ask_sent=? WHERE id=?", email, now(), lead.id);
    addMsg(lead, { dir: 'sys', sender: 'system', text: `✉️ Telegram didn’t open — left email ${email}${q ? ': ' + q : ''}` });
    await createTask({ kind: 'other', source: 'web', lead_id: lead.id, note: `✉️ Website visitor (Telegram didn’t open) — reply by email: ${email}${lead.phone ? ' · ' + lead.phone : ''}${q ? '\n“' + q + '”' : ''}` });
    return json({ ok: true });
  } catch (e) { return fail(e); }
}
