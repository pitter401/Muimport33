import { one, run } from '@/server/db';
import { getSettings, THEMES, bizOf, priceFor, routeOf, isRtUrl, offerUntil } from '@/server/settings';
import { leadLink, type Lead } from '@/server/crm';
import { sendCapi, buildUserData, samePerson, clickIds } from '@/server/capi';
import { json, body, clientIp, getCookie } from '@/server/http';
import { now, rnd, HOUR, cleanPhone } from '@/server/util';

import { campOfReq, noteVisitCamp } from '@/server/camps';

export const dynamic = 'force-dynamic';

/** Landing form submit. Saves the lead + browser data (IP, UA, fbc, fbp) for CAPI later.
 *  Sends InitiateCheckout (order form) or Contact ("Chat with agent") right away — the Lead event comes later, when they message on Telegram. */
export async function POST(req: Request) {
  const b = await body(req);
  // Honeypot: phone browsers sometimes autofill hidden fields, so never block a real person — just log it.
  if (b.website) console.warn('[lead] honeypot filled', String(b.website).slice(0, 60));
  const name = String(b.name || '').trim().slice(0, 80);
  const s0 = getSettings();
  const phone = cleanPhone(String(b.phone || '').slice(0, 30), s0.default_cc || '91');
  const email = String(b.email || '').trim().slice(0, 120);
  if (name.length < 2) return json({ ok: false, error: 'Enter your full name.' }, 400);
  if (!phone) return json({ ok: false, error: 'Enter a valid 10-digit mobile number.' }, 400);
  if (email && !/^\S+@\S+\.\S+$/.test(email)) return json({ ok: false, error: 'Enter a valid email address.' }, 400);
  const ip = clientIp(req);
  if ((one<{ n: number }>('SELECT COUNT(*) n FROM leads WHERE ip=? AND created_at>?', ip, now() - HOUR)?.n || 0) >= 8)
    return json({ ok: false, error: 'Too many requests. Try again later.' }, 429);
  const s = getSettings();
  // cookies, or built from the ad's fbclid in the page URL when the cookie is missing
  const { fbc, fbp } = clickIds(req, String(b.page_url || ''));
  let token = rnd(12);
  const theme = (THEMES as readonly string[]).includes(String(b.theme)) ? String(b.theme) : s.theme;
  // which landing page: the Funnel page (/funnel) or the main Agency page → decides the Meta pixel
  const line = b.line === 'funnel' ? 'funnel' : 'agency';
  const service = b.service === 'funnel' ? 'funnel' : b.service === 'chat' ? 'chat' : 'account';
  // /premium page → Premium lead (own prices; the manager handles it unless agents are tagged Premium)
  const tier = line === 'agency' && b.tier === 'premium' && s.premium_on === '1' ? 'premium' : null;
  // came from a retargeting ad (?rt=1 now, or earlier this week → cookie) → this week's offer stays with the chat
  const rt = isRtUrl(b.page_url) || getCookie(req, 'af_rt') === '1';
  const offer = offerUntil(s, routeOf({ service, line, tier }), rt);
  const ua = req.headers.get('user-agent') || '', vid = getCookie(req, 'af_vid');
  const fields = [theme, name, phone, email, service, String(b.has_bm || '').slice(0, 5), String(b.niche || '').slice(0, 40), String(b.budget || '').slice(0, 40), ip, ua] as const;
  // Same person filling the form again (same number, or same browser — e.g. fixing a typo in the number) before writing on Telegram
  // → update that one lead instead of making a second one.
  const prev = one<{ id: number; token: string }>(
    `SELECT id, token FROM leads WHERE source='form' AND status='new' AND tg_chat_id IS NULL AND started_at IS NULL AND COALESCE(line,'agency')=?
       AND ((phone=? AND created_at>?) OR (?!='' AND vid=? AND created_at>?) OR (?!='' AND fbp=? AND created_at>?) OR (ip=? AND ua=? AND created_at>?))
     ORDER BY id DESC LIMIT 1`,
    line, phone, now() - 24 * HOUR, vid, vid, now() - 24 * HOUR, fbp, fbp, now() - 24 * HOUR, ip, ua, now() - 2 * HOUR);
  if (prev) {
    token = prev.token;
    run(`UPDATE leads SET offer_until=COALESCE(?, offer_until), tier=?, theme=?, name=?, phone=?, email=?, service=?, has_bm=?, niche=?, budget=?, ip=?, ua=?,
           fbc=COALESCE(NULLIF(?,''), fbc), fbp=COALESCE(NULLIF(?,''), fbp), fbclid=COALESCE(NULLIF(?,''), fbclid), page_url=?, vid=COALESCE(NULLIF(?,''), vid), last_at=? WHERE id=?`,
      offer, tier, ...fields, fbc, fbp, fbc.split('.').slice(3).join('.'), String(b.page_url || '').slice(0, 500), vid, now(), prev.id);
  } else run(`INSERT INTO leads(offer_until, tier, line, token, source, theme, name, phone, email, service, has_bm, niche, budget, ip, ua, fbc, fbp, fbclid, page_url, vid, created_at, status, last_at, last_text)
       VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    offer, tier, line, token, 'form', ...fields, fbc, fbp, fbc.split('.').slice(3).join('.'),
    String(b.page_url || '').slice(0, 500), vid, now(), 'new', now(), 'Form filled, waiting for Telegram');
  noteVisitCamp(vid, campOfReq(req, String(b.page_url || ''))); // v130: the chat that follows gets this campaign
  const chat = b.service === 'chat';
  const link = leadLink(s, token, chat, bizOf({ service, line }));
  const lead = one<Lead>('SELECT * FROM leads WHERE token=?', token);
  if (lead) void sendCapi(s, {
    line, event_id: (chat ? 'ct_' : 'ic_') + lead.id, event_name: chat ? 'Contact' : 'InitiateCheckout', lead_id: lead.id, source_url: lead.page_url, once: { leads: samePerson(lead) },
    user_data: buildUserData(lead, s),
    custom_data: chat ? { content_name: 'Chat with agent' } : { content_name: lead.service === 'funnel' ? 'Landing + Funnel' : tier ? 'Ad Account (Premium)' : 'Ad Account', currency: 'USD', value: Number(lead.service === 'funnel' ? priceFor(s, lead).price_funnel : priceFor(s, lead).price_account) || undefined },
  }).catch(() => {});
  if (!link) console.warn('[lead] no Telegram link — mode:', s.tg_mode, 'owner:', s.owner_username || '-', 'bot:', s.bot_username || '-');
  return json({ ok: true, link, t: link ? token : undefined });
}

/** Landing page asks (every few seconds, for ~2 min) whether this person's Telegram chat has started.
 *  Not started → the page offers the website order instead. Only the browser that got the secret token can ask. */
export async function GET(req: Request) {
  const t = new URL(req.url).searchParams.get('t') || '';
  if (!/^[A-Za-z0-9]{8,40}$/.test(t)) return json({ ok: false }, 400);
  const l = one<{ started_at: number | null; tg_chat_id: string | null }>('SELECT started_at, tg_chat_id FROM leads WHERE token=? AND created_at>?', t, now() - 24 * HOUR);
  if (!l) return json({ ok: false }, 404);
  return json({ ok: true, started: !!(l.started_at || l.tg_chat_id) }, 200, { 'cache-control': 'no-store' });
}
