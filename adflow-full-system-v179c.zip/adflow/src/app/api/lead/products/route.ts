import { one, run } from '@/server/db';
import { getSettings, THEMES } from '@/server/settings';
import { json, body, clientIp, getCookie } from '@/server/http';
import { now, rnd, HOUR } from '@/server/util';
import { clickIds } from '@/server/capi';
import { campOfReq, noteVisitCamp } from '@/server/camps';
import { publicUrl } from '@/server/email';

export const dynamic = 'force-dynamic';

/** v160: /products → "Order on Telegram". Before, the link had no code, so the chat came in as a plain Agency chat with no campaign
 *  (a funnel order got the Agency welcome, "Old non-tracked ads"). Now a lead is made first (the right business, the campaign —
 *  or "Products page" + the site that sent them, e.g. a client site's "Ads by AdsBhai" badge), and the pre-typed text carries its code. */
export async function POST(req: Request) {
  const b = await body(req);
  const s = getSettings();
  const product = String(b.product || '');
  const text = String(b.text || '').replace(/\r/g, '').slice(0, 900);
  const ip = clientIp(req);
  if ((one<{ n: number }>("SELECT COUNT(*) n FROM leads WHERE ip=? AND created_at>?", ip, now() - HOUR)?.n || 0) >= 12) return json({ ok: false }, 429);
  const funnel = product === 'funnel';
  const premium = /premium/.test(product) && s.premium_on === '1';
  const line = funnel ? 'funnel' : 'agency';
  const service = funnel ? 'funnel' : 'account';
  const pageUrl = String(b.page_url || '').slice(0, 500);
  const ua = req.headers.get('user-agent') || '', vid = getCookie(req, 'af_vid');
  const { fbc, fbp } = clickIds(req, pageUrl);
  const theme = (THEMES as readonly string[]).includes(String(b.theme)) ? String(b.theme) : s.theme;
  // the ad that brought them (tags / cookie), else this page + the site they came from
  const ad = campOfReq(req, pageUrl);
  let from = '';
  try { const r = String(b.ref || ''); if (r) { const h = new URL(r).hostname.replace(/^www\./, ''); const own = new URL(publicUrl() || 'https://adsbhai.com').hostname.replace(/^www\./, ''); if (h && h !== own) from = h.slice(0, 60); } } catch { /* */ }
  const camp = ad || { camp: 'Products page', adset: from || null, ad: null };
  const token = rnd(12);
  run(`INSERT INTO leads(tier, line, token, source, theme, service, ip, ua, fbc, fbp, fbclid, page_url, vid, created_at, status, last_at, last_text, camp, adset, ad)
       VALUES(?,?,?,'products',?,?,?,?,?,?,?,?,?,?,'new',?,'Ordered on the products page, waiting for Telegram',?,?,?)`,
    premium ? 'premium' : null, line, token, theme, service, ip, ua, fbc, fbp, fbc.split('.').slice(3).join('.'), pageUrl, vid, now(), now(), camp.camp, camp.adset, camp.ad);
  noteVisitCamp(vid, ad);
  const code = 'L-' + token;
  let link: string | null = null;
  if (s.tg_mode === 'business' && s.owner_username) link = `https://t.me/${s.owner_username}?text=${encodeURIComponent(`${text}\n${code}`.trim())}`;
  else if (s.bot_username) link = `https://t.me/${s.bot_username}?start=l_${token}`;
  return json({ ok: !!link, link });
}
