import { waJoin } from '@/server/wapages';
import { json, body } from '@/server/http';
import { HttpError } from '@/server/util';

export const dynamic = 'force-dynamic';

/** v131: community page → save the number + ad click, send them to the community link. */
export async function POST(req: Request) {
  try { return json(waJoin(req, await body(req))); }
  catch (e) { const h = e as HttpError; return json({ ok: false, error: h.message }, h.status || 500); }
}
