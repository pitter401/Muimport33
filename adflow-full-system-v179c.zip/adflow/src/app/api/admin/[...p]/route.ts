import { npAllCoins, coinMeta } from '@/server/nowpay';
import * as WD from '@/server/watchdog';
import { one, all, run, tx, emptyInSql } from '@/server/db';
import { addWaSale, addWaTopup, delWaSale, delWaTopup, editWaSale, listWaSales, waSaleAgent, pickAgent } from '@/server/wasales';
import { productInfoMsgs, getSettings, setSetting, bizOf, leadPrices, offerTexts, tierFor, DEFAULTS, SECRET_KEYS, AUTO_KEYS, THEMES, type SettingKey } from '@/server/settings';
import { getAdmin, checkAdminLogin, makeToken, cookieHeader, adminVersion, hashPassword } from '@/server/auth';
import { needsReplySql, leadById, agentById, sendToLead, uploadToLead, wallet, runFollowups, addMsg, notifyAgent, displayName, setReminder, waText, deleteLead, setLeadType, markReadEverywhere, deleteRequests, keepChat, recordSale, addTopup, type Lead, type AgentRow, chatPage, setReceive, clearCoverForAssign, realConvAt, markNoReply, dropAsCover, sendOnceByCid } from '@/server/crm';
import { addCashPayout, delCashPayout, cashPayouts } from '@/server/cashpay';
import { createPayLink, chatLinksAndItems, leadPayLinks, cancelPayLink, payLinksOn } from '@/server/paylinks';
import { leadAccounts } from '@/server/shop';
import { metaOn, metaHas, metaEnabled, createRequest, leadMetaAccounts, openCredit, freeAccounts, tierOf, listRequests, catOf, freePickList } from '@/server/meta';
import { lines as lineList, fmt as fmtS, msgFor, offerOf } from '@/server/settings';
import { sendCapi, buildUserData, clickIds } from '@/server/capi';
import { checkChannel } from '@/server/channel';
import { setupWebhook, tg } from '@/server/telegram';
import { registerToken } from '@/server/push';
import { waSyncSoon, waPhoneSyncSoon } from '@/server/wasync';
import { json, body, fail, baseUrl, clientIp, loginBlocked, loginFailed, realIp } from '@/server/http';
import { ubSendCode, ubSignIn, ubLogout, contactName } from '@/server/userbot';
import { saveLogo } from '@/server/logo';
import { listTasks, completeTask, markPaid, cancelItem } from '@/server/shop';
import { shortLinks } from '@/server/paylinks';
import { saveNotifSound } from '@/server/notifsound';
import { now, num, money, dayRange, localDate, csvq, HttpError, presence } from '@/server/util';
import { assignCalls, markCall, callSql, callTodoSql, hotSql } from '@/server/calls';
import * as AI from '@/server/ai';
import * as VFX from '@/server/voicefx';
import * as SYS from '@/server/sysjobs';
import * as CM from '@/server/comments';
import * as MA from '@/server/metaads';
import fsAi from 'fs';
import pathAi from 'path';
import { teamProfit, ensureAutoSpend, costSql, spendLine, replCost, replLineSql } from '@/server/profit';
import { metaApi } from '@/server/metaapi';
import { metaFile as metaFileSync, csvOf as csvOfSync } from '@/server/metaexport';
import { campaignStats, saveCampSpend, stampCamps, stampLead, campActs, WA_SALE, chipsOf } from '@/server/camps';
import { reelAdminApi, reelUserApi } from '@/server/reel';
import { svidAdminApi } from '@/server/statusvid'; // v168
import { forceStatus, forceSet } from '@/server/appforce';

export const dynamic = 'force-dynamic';

/** A lead / order that came from a retargeting ad: the ad's link carries ?rt=1 (kept in page_url). */
/** v166: admin paths that change something even with an empty body → POST only */
const MUTATING_GET = new Set(['ub_logout', 'ub_resume', 'cm_disconnect', 'chan_approve_all', 'mads_sync', 'cm_sync', 'webhook', 'chan_check', 'notif_sound_sync', 'push_test', 'capi_test', 'ai_lab_run', 'ai_case_run', 'ai_reply_now', 'ai_coach', 'agent_logout', 'agent_delete', 'agent_toggle', 'settings_save', 'ai_save', 'mads_set', 'cm_save', 'noreply', 'lead_status', 'del_keep', 'wa_sale_add', 'wa_topup_add', 'sold', 'topup', 'paylink', 'send', 'app_force_set']);
const RT_SQL = (a: string) => `(${a}.page_url LIKE '%?rt=1%' OR ${a}.page_url LIKE '%&rt=1%')`;

async function handle(req: Request, ctx: { params: Promise<{ p: string[] }> }) {
  const path = (await ctx.params).p.join('/');
  try {
    if (path === 'login') {
      const b = await body(req);
      const ip = realIp(req);
      if (loginBlocked(ip)) return json({ error: 'Too many wrong tries. Wait 15 minutes and try again.' }, 429);
      if (!checkAdminLogin(String(b.username || ''), String(b.password || ''))) { loginFailed(ip); await new Promise(r => setTimeout(r, 800)); return json({ error: 'Wrong username or password' }, 401); }
      const token = makeToken({ r: 'admin', id: 0, v: adminVersion() }, 30);
      return json({ ok: true, token }, 200, { 'set-cookie': cookieHeader('af_admin', token, 30) });
    }
    if (path === 'logout') return json({ ok: true }, 200, { 'set-cookie': cookieHeader('af_admin', '', 0) });
    if (!getAdmin(req)) return json({ error: 'login' }, 401);
    // v166: actions never run on a plain GET (a link tapped in a chat would carry the Lax cookie); meta/* is checked in metaApi
    if (req.method !== 'POST' && MUTATING_GET.has(path)) return json({ error: 'Use POST' }, 405);
    // v166: a POST from another site is refused (the apps load this server itself, so they are same-origin)
    if (req.method === 'POST' && req.headers.get('sec-fetch-site') === 'cross-site') return json({ error: 'Cross-site request refused' }, 403);
    // v167: Daily reel — the admin as a viewer (reel/view/*) and the admin pages (reel/*); they read their own bodies (chunked uploads)
    if (path.startsWith('reel/view/')) return await reelUserApi(path.slice(10), { role: 'admin' }, req);
    if (path.startsWith('reel/')) return await reelAdminApi(path.slice(5), req);
    // v168: Status video (stock uploads in chunks read their own bodies; GET = reads + file downloads, POST = every change)
    if (path.startsWith('svid/')) return await svidAdminApi(path.slice(5), req);

    const s = getSettings();
    const url = new URL(req.url);
    const q = (k: string) => url.searchParams.get(k);
    const b = req.method === 'POST' && !(req.headers.get('content-type') || '').includes('multipart') ? await body(req) : {};
    const lead = (id: unknown) => { const l = leadById(num(id)); if (!l) throw new HttpError(404, 'Lead not found'); return l; };
    // v136: the owner sells from a chat → the sale / top-up / link is the chat's agent's (or the manager's when nobody has it)
    const owner = (l: Lead): AgentRow & { deleted: number } => {
      const a = l.agent_id ? agentById(l.agent_id) : undefined;
      if (a && !a.deleted) return { ...a, deleted: 0 };
      const m = one<AgentRow>("SELECT * FROM agents WHERE role='manager' AND deleted=0 ORDER BY id LIMIT 1");
      if (m) return { ...m, deleted: 0 };
      throw new HttpError(400, 'Assign the chat to an agent first');
    };
    const byAdmin = (l: Lead) => run("UPDATE messages SET text=text || ' (by Admin)' WHERE id=(SELECT MAX(id) FROM messages WHERE lead_id=? AND dir='sys')", l.id);

    // v127: a 5-minute token for download links (CSV exports open in the browser) — the login token never goes in a URL
    if (path === 'export_token') return json({ token: makeToken({ r: 'dl', id: 0, v: adminVersion() }, 5 / 1440) }); // v166: a 'dl' token (export GETs only)
    if (path.startsWith('export/')) return exportCsv(path.slice(7), q('range'), q('type'), q('line'));
    // v137: look before downloading — the same CSV builders, parsed: row count + the first 20 rows; and the counts for every card
    // v137: Meta-ready files per app (hashed customer lists / offline purchases)
    if (path === 'export_meta_cards') { const M = await import('@/server/metaexport'); const app = (M.EX_APPS.map(x => x[0]) as string[]).includes(String(q('app'))) ? q('app') as any : 'all'; return json({ app, guide: M.EX_GUIDE[app as keyof typeof M.EX_GUIDE], cards: M.metaCards(app, q('range'), q('line')) }); }
    if (path === 'export_meta_preview') {
      const M = await import('@/server/metaexport');
      const app = (M.EX_APPS.map(x => x[0]) as string[]).includes(String(q('app'))) ? q('app') as any : 'all';
      const kind = String(q('kind')) as any;
      if (!(kind in M.EX_CARDS)) throw new HttpError(404, 'Unknown file');
      const fl = M.metaFile(app, kind, q('range'), q('line'));
      return json({ kind, cols: fl.cols, total: fl.rows.length, rows: fl.rows.slice(0, 20), hashed: true, keys: M.matchKeys(fl.cols, fl.rows) });
    }
    if (path === 'export_preview') return json(await exportPreview(String(q('kind') || ''), q('range'), q('type'), q('line'), 20));
    if (path === 'export_counts') {
      const kinds: [string, string | null][] = [['leads.csv', null], ['meta_purchases.csv', null], ['audience.csv', 'buyers'], ['audience.csv', 'all'], ['channel_people.csv', null], ['channel_audience.csv', null]];
      const out: Record<string, number> = {};
      for (const [k, ty] of kinds) out[k + (ty ? '?type=' + ty : '')] = (await exportPreview(k, q('range'), ty, q('line'), 0)).total;
      return json({ counts: out });
    }
    if (path.startsWith('meta/')) return json(await metaApi(path.slice(5), req, b, { role: 'admin', id: null, name: 'Admin' }));

    switch (path) {
      /* ---------------- System (Admin → System: update from zip, build apps) ---------------- */
      /* ---------------- v150: Comments (Facebook Page + ads, Instagram ad posts) ---------------- */
      case 'cm_status': return json(CM.cmStatus());
      /* ---------------- v151: Ads data from Meta (master switch) ---------------- */
      case 'mads_status': return json(MA.madsStatus());
      case 'mads_set': return json(MA.madsSet(b));
      case 'mads_sync': return json(await MA.madsSync(true));
      case 'cm_list': return json(CM.cmList({ label: q('label'), src: q('src'), ad: q('ad'), status: q('status'), q: q('q'), before: num(q('before')) }));
      case 'cm_connect': return json(await CM.cmConnect(b));
      case 'cm_disconnect': return json(CM.cmDisconnect());
      case 'cm_save': return json(CM.cmSave(b));
      case 'cm_sync': return json(await CM.cmSync(true) || { new: 0, deleted: 0, ads: 0 });
      case 'cm_delete': return json(await CM.cmDelete((Array.isArray(b.ids) ? b.ids : [b.id]).map(String).filter(Boolean)));
      case 'cm_keep': return json(CM.cmKeep((Array.isArray(b.ids) ? b.ids : [b.id]).map(String).filter(Boolean)));
      case 'app_force': return json(forceStatus()); // v167: Admin → System → Force update
      case 'app_force_set': return json(forceSet(b));
      case 'sys_jobs': return json({ jobs: SYS.listJobs(), running: SYS.runningJob(), agent_icon: s.apk_agent_theme || 'green', themes: THEMES });
      case 'sys_watchdog': return json({ events: WD.watchdogEvents(), report: q('report') ? WD.watchdogReport(q('report')) : null });
      case 'sys_icon': { if (!(THEMES as readonly string[]).includes(String(b.theme))) throw new HttpError(400, 'Pick a colour'); setSetting('apk_agent_theme', String(b.theme)); return json({ ok: true }); }
      case 'sys_log': return json(SYS.jobLog(String(q('id') || ''), num(q('from'))));
      case 'sys_update': {
        const form = await req.formData();
        if (!checkAdminLogin(process.env.ADMIN_USERNAME || 'admin', String(form.get('password') || ''))) throw new HttpError(403, 'Wrong admin password');
        const f = form.get('file');
        if (!f || typeof f === 'string' || !/\.zip$/i.test(f.name)) throw new HttpError(400, 'Choose the .zip file');
        if (f.size > 60 * 1024 * 1024) throw new HttpError(400, 'Zip is larger than 60 MB');
        if (SYS.runningJob()) throw new HttpError(409, 'Another update/build is still running — wait for it to finish');
        const zp = pathAi.join(SYS.jobsDir(), `upload-${now()}.zip`);
        fsAi.writeFileSync(zp, Buffer.from(await f.arrayBuffer()));
        try { return json({ job: SYS.startUpdate(zp, f.name) }); } catch (e) { try { fsAi.unlinkSync(zp); } catch { /* gone */ } throw e; }
      }
      case 'sys_apk': {
        if (!checkAdminLogin(process.env.ADMIN_USERNAME || 'admin', String(b.password || ''))) throw new HttpError(403, 'Wrong admin password');
        return json({ job: SYS.startApkBuild() });
      }
      /* ---------------- AI (Admin → AI) ---------------- */
      case 'ai': {
        AI.ensureSeed();
        const cnt = (t: string, w = '1=1') => one<{ n: number }>(`SELECT COUNT(*) n FROM ${t} WHERE ${w}`)!.n;
        return json({
          ai: {
            key_set: !!s.ai_key, key: s.ai_key ? '••••••' + s.ai_key.slice(-4) : '', model: s.ai_model, coach_model: s.ai_coach_model, coach_on: s.ai_coach_on === '1', auto_on: s.ai_auto_on === '1',
            auto_agents: AI.autoAgents(s), wait_sec: s.ai_wait_sec, hold_min: s.ai_human_hold_min, min_score: s.ai_min_score, daily_cap: s.ai_daily_cap,
            price_in: s.ai_price_in, price_out: s.ai_price_out, fu_on: s.ai_fu_on === '1', fu_hours: s.ai_fu_hours, fu_dead_hours: s.ai_fu_dead_hours, fu_active: AI.aiFuActive(s), voice_on: s.ai_voice_on === '1', el_key_set: !!s.el_key, el_key: s.el_key ? '••••••' + s.el_key.slice(-4) : '',
            el_voice_id: s.el_voice_id, el_model: s.el_model, voice_mode: s.ai_voice_mode || 'interest', voice_every: s.ai_voice_every, voice_max: s.ai_voice_max, voice_noise: s.ai_voice_noise || 'light', team_voice_change: s.team_voice_change === '1', team_voice_style: s.team_voice_style || 'female_words', team_voice_id: s.team_voice_id || '', team_voice_gender: s.team_voice_gender === 'male' ? 'male' : 'female', voice_bg: s.ai_voice_bg === 'fan' ? 'fan' : 'office', voice_speed: s.ai_voice_speed || '0.9', voice_volume: s.ai_voice_volume || '-3', wv_on: s.welcome_voice_on === '1', wv_delay: s.welcome_voice_delay_sec, wv_text: s.welcome_voice_text, wv_text_f: s.welcome_voice_text_f, wv_text_c: s.welcome_voice_text_c, wv_text_cf: s.welcome_voice_text_cf, wv_text_m: s.welcome_voice_text_m, office_sec: VFX.officeBedSeconds(),
            ffmpeg: !!VFX.ffmpegPath(), room: VFX.hasRoomNoise() ? { seconds: Math.round(num((() => { try { return fsAi.readFileSync(VFX.roomNoiseFile() + '.len', 'utf8'); } catch { return 0; } })())) } : null, knowledge: s.ai_knowledge || '', knowledge_default: AI.knowledgeText({ ...s, ai_knowledge: '' }), knowledge_custom: !!(s.ai_knowledge || '').trim(),
          },
          score: AI.labScore(), last_score: s.ai_last_score, lab: AI.labState, cost_today: AI.aiCostToday(), usage: AI.aiUsage(7),
          counts: { examples: cnt('ai_examples', 'on_=1'), cases: cnt('ai_cases'), feedback: cnt('ai_feedback', 'used=0'), proofs: cnt('ai_proofs', "status='on'") },
          agents: all("SELECT id, name, role FROM agents WHERE deleted=0 ORDER BY role='manager' DESC, name"),
        });
      }
      case 'ai_save': {
        const keys = ['ai_model', 'ai_coach_model', 'ai_coach_on', 'ai_auto_on', 'ai_auto_agents', 'ai_wait_sec', 'ai_human_hold_min', 'ai_min_score', 'ai_daily_cap', 'ai_price_in', 'ai_price_out', 'ai_fu_on', 'ai_fu_hours', 'ai_fu_dead_hours', 'ai_voice_on', 'ai_voice_mode', 'ai_voice_every', 'ai_voice_max', 'ai_voice_noise', 'ai_voice_bg', 'ai_voice_speed', 'ai_voice_volume', 'team_voice_change', 'team_voice_style', 'team_voice_id', 'team_voice_gender', 'welcome_voice_on', 'welcome_voice_delay_sec', 'welcome_voice_text', 'welcome_voice_text_f', 'welcome_voice_text_c', 'welcome_voice_text_cf', 'welcome_voice_text_m', 'el_voice_id', 'el_model', 'ai_knowledge'] as const;
        if ('ai_voice_mode' in b && !['interest', 'every', 'mirror'].includes(String(b.ai_voice_mode))) throw new HttpError(400, 'Pick when to send voice notes');
        if ('ai_voice_noise' in b && !['off', 'light', 'medium'].includes(String(b.ai_voice_noise))) throw new HttpError(400, 'Pick the room sound level');
        for (const k of ['ai_voice_every', 'ai_voice_max'] as const) if (k in b && (!/^\d{1,2}$/.test(String(b[k]).trim()) || (k === 'ai_voice_every' && num(b[k]) < 1))) throw new HttpError(400, k === 'ai_voice_every' ? 'Every … reply: type a number from 1 to 99' : 'Voice notes per chat: type a number (0 = no limit)');
        for (const k of ['ai_key', 'el_key'] as const) { const v = String(b[k] ?? '').trim(); if (v && !v.startsWith('••')) setSetting(k, v); if (b['clear_' + k] === true) setSetting(k, ''); }
        const want = (k: string) => (k in b ? String(b[k] ?? '').trim() : null);
        if (want('team_voice_change') === '1' && (!getSettings().el_key || !getSettings().el_voice_id)) throw new HttpError(400, 'Add the ElevenLabs key and voice ID first');
        if (want('welcome_voice_on') === '1' && (!getSettings().el_key || !getSettings().el_voice_id)) throw new HttpError(400, 'Add the ElevenLabs key and voice ID first');
        if ('welcome_voice_delay_sec' in b && !(num(b.welcome_voice_delay_sec) >= 5 && num(b.welcome_voice_delay_sec) <= 600)) throw new HttpError(400, 'Welcome voice: seconds after the welcome must be 5 to 600');
        for (const k of ['welcome_voice_text', 'welcome_voice_text_f', 'welcome_voice_text_c', 'welcome_voice_text_cf', 'welcome_voice_text_m'] as const) if (k in b && String(b[k] || '').trim().length > 400) throw new HttpError(400, 'Welcome voice text: keep it under 400 letters (about 25 seconds)');
        if ('ai_voice_volume' in b && !(num(b.ai_voice_volume, 99) >= -12 && num(b.ai_voice_volume, 99) <= 6)) throw new HttpError(400, 'Voice loudness: -12 to 6');
        if ('ai_voice_speed' in b && !(num(b.ai_voice_speed) >= 0.7 && num(b.ai_voice_speed) <= 1.2)) throw new HttpError(400, 'Voice speed: 0.7 to 1.2');
        if ('ai_voice_bg' in b && !['fan', 'office'].includes(String(b.ai_voice_bg))) throw new HttpError(400, 'Pick the background');
        if ('team_voice_style' in b && !['same', 'female_words', 'mix'].includes(String(b.team_voice_style))) throw new HttpError(400, 'Pick how team voice notes are made');
        if ('team_voice_gender' in b && !['male', 'female'].includes(String(b.team_voice_gender))) throw new HttpError(400, 'Pick male or female');
        if ('team_voice_id' in b) { b.team_voice_id = String(b.team_voice_id || '').trim(); if (b.team_voice_id && !/^[A-Za-z0-9]{10,40}$/.test(String(b.team_voice_id))) throw new HttpError(400, 'That does not look like an ElevenLabs voice ID (ElevenLabs → Voices → ⋮ → Copy voice ID)'); }
        if (want('ai_auto_on') === '1' && s.ai_auto_on !== '1') {
          const sc = AI.labScore(), min = num(want('ai_min_score') ?? s.ai_min_score, 90);
          if (sc === null || sc < min) throw new HttpError(400, `Run the Test Lab first: score ${sc ?? '—'}% is below ${min}%`);
          if (!getSettings().ai_key) throw new HttpError(400, 'Add the Anthropic API key first');
        }
        for (const k of keys) { const v = want(k); if (v !== null) setSetting(k, k === 'ai_knowledge' ? v.slice(0, 20000) : v.slice(0, k.startsWith('welcome_voice_text') ? 400 : 300)); }
        return json({ ok: true });
      }
      case 'ai_examples': return json({ examples: all('SELECT * FROM ai_examples ORDER BY CASE source WHEN \'correction\' THEN 0 WHEN \'sold\' THEN 1 ELSE 2 END, id DESC') });
      case 'ai_example_save': {
        const v = [String(b.title || '').slice(0, 80) || 'Example', ['agency', 'funnel'].includes(String(b.biz)) ? String(b.biz) : 'any', String(b.chat || '').slice(0, 6000), b.on_ === false || b.on_ === 0 ? 0 : 1];
        if (!String(v[2]).trim()) throw new HttpError(400, 'Write the chat first');
        if (b.id) run('UPDATE ai_examples SET title=?, biz=?, chat=?, on_=? WHERE id=?', ...v, num(b.id));
        else run("INSERT INTO ai_examples(title, biz, chat, on_, source, created_at) VALUES(?,?,?,?,'admin',?)", ...v, now());
        return json({ ok: true });
      }
      case 'ai_example_delete': run('DELETE FROM ai_examples WHERE id=?', num(b.id)); return json({ ok: true });
      case 'ai_cases': AI.ensureSeed(); return json({ cases: all('SELECT * FROM ai_cases ORDER BY id'), score: AI.labScore(), lab: AI.labState });
      case 'ai_case_save': {
        const turns = Array.isArray(b.turns) ? (b.turns as any[]).map(t => ({ from: t.from === 'a' ? 'a' : 'c', text: String(t.text || '').slice(0, 2000) })).filter(t => t.text.trim()) : [];
        if (!turns.length) throw new HttpError(400, 'Add at least one customer message');
        const v = [String(b.title || '').slice(0, 80) || 'Case', b.biz === 'funnel' ? 'funnel' : 'agency', JSON.stringify(turns), String(b.expect || '').slice(0, 1000), String(b.facts || '').slice(0, 1000)];
        if (b.id) run('UPDATE ai_cases SET title=?, biz=?, turns=?, expect=?, facts=? WHERE id=?', ...v, num(b.id));
        else run('INSERT INTO ai_cases(title, biz, turns, expect, facts, created_at) VALUES(?,?,?,?,?,?)', ...v, now());
        return json({ ok: true });
      }
      case 'ai_case_delete': run('DELETE FROM ai_cases WHERE id=?', num(b.id)); return json({ ok: true });
      case 'ai_case_run': return json({ case: await AI.runCase(num(b.id)) });
      case 'ai_lab_run': return json(AI.startLabRun(Array.isArray(b.ids) ? (b.ids as unknown[]).map(num).filter(Boolean) : undefined));
      case 'ai_lab_state': return json({ lab: AI.labState, score: AI.labScore() });
      case 'ai_case_mark': return json(AI.markCase(num(b.id), String(b.mark || ''), String(b.fix || '')));
      case 'ai_sim': {
        const turns = Array.isArray(b.turns) ? (b.turns as any[]).map(t => ({ from: (t.from === 'a' ? 'a' : 'c') as 'a' | 'c', text: String(t.text || '') })).filter(t => t.text.trim()) : [];
        if (!turns.length) throw new HttpError(400, 'Type a customer message first');
        return json({ out: await AI.simulate(b.biz === 'funnel' ? 'funnel' : 'agency', turns, String(b.facts || ''), 'reply', { voice: b.voice === 'always' ? 'always' : 'auto', audio: b.audio === true }) });
      }
      /* Voice test (Admin → AI → Test Lab → Try it): the admin records a voice note as the customer → text → AI reply (+ the AI's voice note) */
      case 'ai_sim_voice': {
        const form = await req.formData();
        const f = form.get('file');
        if (!f || typeof f === 'string' || f.size < 500) throw new HttpError(400, 'Record a voice note first');
        if (f.size > 15 * 1024 * 1024) throw new HttpError(400, 'Voice note is too long');
        const text = await AI.transcribeBuffer(getSettings(), Buffer.from(await f.arrayBuffer()), f.name || 'voice.ogg');
        if (!text) throw new HttpError(400, 'Nothing was heard in the voice note — try again a bit louder');
        let prev: any[] = [];
        try { prev = JSON.parse(String(form.get('turns') || '[]')); } catch { /* none */ }
        const turns = [...(Array.isArray(prev) ? prev : []).map(t => ({ from: (t.from === 'a' ? 'a' : 'c') as 'a' | 'c', text: String(t.text || '') })).filter(t => t.text.trim()), { from: 'c' as const, text: `[voice note: "${text}"]` }];
        const out = await AI.simulate(form.get('biz') === 'funnel' ? 'funnel' : 'agency', turns, String(form.get('facts') || ''), 'reply', { voice: form.get('voice') === 'always' ? 'always' : 'auto', audio: true });
        return json({ heard: text, out });
      }
      case 'ai_voice_sample': {
        const s2 = { ...getSettings(), ...(['off', 'light', 'medium'].includes(String(b.noise)) ? { ai_voice_noise: String(b.noise) } : {}), ...(['fan', 'office'].includes(String(b.bg)) ? { ai_voice_bg: String(b.bg) } : {}), ...(num(b.speed) >= 0.7 && num(b.speed) <= 1.2 ? { ai_voice_speed: String(b.speed) } : {}) };
        const n = await AI.makeVoiceNote(s2, String(b.text || '').trim().slice(0, 400).replace(/\{brand\}/g, s2.brand_name || 'AdsBhai').replace(/\{name\}/g, 'Rahul ji') || 'Haan sir, ho jayega. Aap kis cheez ke ads chalane wale ho?');
        if (!n) throw new HttpError(400, AI.ttsError || 'Voice could not be made — check the ElevenLabs key and voice ID');
        return json({ audio: `data:audio/ogg;base64,${n.data.toString('base64')}`, ogg: true });
      }
      /* Try the team voice change without sending anything: record → hear it in our voice */
      case 'ai_voice_change_test': {
        const form = await req.formData();
        const f = form.get('file');
        if (!f || typeof f === 'string' || f.size < 1500) throw new HttpError(400, 'Record a few seconds first');
        if (f.size > 15 * 1024 * 1024) throw new HttpError(400, 'Recording is too long');
        const s2 = { ...getSettings(), ...(['same', 'female_words', 'mix'].includes(String(form.get('style'))) ? { team_voice_style: String(form.get('style')) } : {}), ...(['male', 'female'].includes(String(form.get('gender'))) ? { team_voice_gender: String(form.get('gender')) } : {}), ...(form.get('voice_id') != null ? { team_voice_id: String(form.get('voice_id')).trim() } : {}) };
        const tv = await AI.teamVoice(s2, Buffer.from(await f.arrayBuffer()), f.name || 'voice.webm');
        return json({ audio: `data:audio/ogg;base64,${tv.data.toString('base64')}`, heard: tv.heard, text: tv.text, fixed: tv.fixed || [] });
      }
      /* Office background (made once with ElevenLabs Sound Effects): POST {make:true} makes it, GET plays it */
      case 'ai_voice_office': {
        if (b.make === true) return json({ ok: true, job: AI.startOfficeBed(getSettings()) });
        if (q('status')) return json({ job: AI.officeJob, seconds: VFX.officeBedSeconds() });
        if (!VFX.hasOfficeBed()) return new Response('not found', { status: 404 });
        return new Response(new Uint8Array(fsAi.readFileSync(VFX.officeBedFile())), { headers: { 'content-type': 'audio/ogg', 'cache-control': 'no-store' } });
      }
      case 'ai_voice_room': {
        if (req.method === 'POST' && (req.headers.get('content-type') || '').includes('multipart')) {
          const form = await req.formData();
          const f = form.get('file');
          if (!f || typeof f === 'string' || f.size < 2000) throw new HttpError(400, 'Record 10-20 seconds of your room first');
          if (f.size > 25 * 1024 * 1024) throw new HttpError(400, 'File is larger than 25 MB');
          try { return json({ ok: true, ...(await VFX.saveRoomNoise(Buffer.from(await f.arrayBuffer()))) }); } catch (e) { throw new HttpError(400, (e as Error).message); }
        }
        if (b.delete === true) { VFX.deleteRoomNoise(); return json({ ok: true }); }
        if (!VFX.hasRoomNoise()) return new Response('not found', { status: 404 });
        return new Response(new Uint8Array(fsAi.readFileSync(VFX.roomNoiseFile())), { headers: { 'content-type': 'audio/ogg', 'cache-control': 'no-store' } });
      }
      case 'ai_learn': return json({
        feedback: all('SELECT f.*, a.name agent_name, l.name lead_name FROM ai_feedback f LEFT JOIN agents a ON a.id=f.agent_id LEFT JOIN leads l ON l.id=f.lead_id WHERE f.used=0 ORDER BY f.id DESC LIMIT 100'),
        sold: all("SELECT l.id, l.name, l.tg_name, l.biz, l.sold_at, (SELECT COUNT(*) FROM messages m WHERE m.lead_id=l.id AND m.dir!='sys') n FROM leads l WHERE l.status='sold' AND l.tg_chat_id IS NOT NULL ORDER BY l.sold_at DESC LIMIT 50"),
      });
      case 'ai_example_from_lead': return json(AI.exampleFromLead(num(b.lead_id), String(b.title || '')));
      case 'ai_feedback_use': {
        const f = one<any>('SELECT * FROM ai_feedback WHERE id=?', num(b.id));
        if (!f) throw new HttpError(404, 'Not found');
        if (b.use !== false) {
          const l = leadById(f.lead_id);
          const names = [l?.name, l?.tg_name].filter(Boolean) as string[];
          const ctx = all<{ dir: string; text: string }>("SELECT dir, text FROM messages WHERE lead_id=? AND dir!='sys' AND created_at<? ORDER BY created_at DESC, id DESC LIMIT 8", f.lead_id, f.created_at).reverse();
          const chat = ctx.map(m => `${m.dir === 'in' ? 'C' : 'A'}: ${AI.maskText(m.text, names)}`).join('\n') + '\n' + String(f.sent).split('\n').filter(Boolean).map(x => 'A: ' + AI.maskText(x, names)).join('\n');
          run("INSERT INTO ai_examples(title, biz, chat, source, on_, created_at) VALUES(?,?,?,'agent',1,?)", 'Agent fix #' + f.id, l ? bizOf(l) : 'any', chat, now());
        }
        run('UPDATE ai_feedback SET used=1 WHERE id=?', f.id);
        return json({ ok: true });
      }
      case 'ai_proofs': return json({ proofs: all('SELECT * FROM ai_proofs ORDER BY id DESC') });
      case 'ai_proof_upload': {
        const form = await req.formData();
        const f = form.get('file');
        if (!f || typeof f === 'string' || !/^image\//.test(f.type)) throw new HttpError(400, 'Choose an image');
        if (f.size > 8 * 1024 * 1024) throw new HttpError(400, 'Image is larger than 8 MB');
        const ext = f.type.includes('png') ? 'png' : f.type.includes('webp') ? 'webp' : 'jpg';
        const name = `p${now()}${Math.floor(Math.random() * 1000)}.${ext}`;
        fsAi.writeFileSync(pathAi.join(AI.proofDir(), name), Buffer.from(await f.arrayBuffer()));
        run("INSERT INTO ai_proofs(biz, kind, file, status, created_at) VALUES(?, 'upload', ?, 'on', ?)", ['agency', 'funnel'].includes(String(form.get('biz'))) ? String(form.get('biz')) : 'any', name, now());
        return json({ ok: true });
      }
      case 'ai_proof_set': run('UPDATE ai_proofs SET status=?, biz=COALESCE(?, biz) WHERE id=?', b.status === 'off' ? 'off' : 'on', ['agency', 'funnel', 'any'].includes(String(b.biz)) ? String(b.biz) : null, num(b.id)); return json({ ok: true });
      case 'ai_proof_delete': {
        const p = one<{ file: string }>('SELECT file FROM ai_proofs WHERE id=?', num(b.id));
        if (p) { try { fsAi.unlinkSync(pathAi.join(AI.proofDir(), p.file)); } catch { /* gone */ } run('DELETE FROM ai_proofs WHERE id=?', num(b.id)); }
        return json({ ok: true });
      }
      case 'ai_proof_img': {
        const p = one<{ file: string }>('SELECT file FROM ai_proofs WHERE id=?', num(q('id')));
        const fp = p && pathAi.join(AI.proofDir(), p.file);
        if (!fp || !fsAi.existsSync(fp)) return new Response('not found', { status: 404 });
        return new Response(new Uint8Array(fsAi.readFileSync(fp)), { headers: { 'content-type': /\.png$/.test(fp) ? 'image/png' : /\.webp$/.test(fp) ? 'image/webp' : 'image/jpeg', 'cache-control': 'private, max-age=3600' } });
      }
      case 'ai_coach': return json(await AI.aiCoach(lead(b.lead_id), b.force === true));
      case 'ai_feedback': AI.aiFeedback(num(b.lead_id), null, String(b.suggested || ''), String(b.sent || '')); return json({ ok: true });
      case 'ai_chat_state': {
        const l = lead(b.lead_id);
        run('UPDATE leads SET ai_state=?, ai_done_msg=(SELECT MAX(id) FROM messages WHERE lead_id=?) WHERE id=?', b.state === 'paused' ? 'paused' : null, l.id, l.id);
        addMsg(l, { dir: 'sys', sender: 'system', text: b.state === 'paused' ? '🤖 AI paused in this chat (Admin)' : '🤖 AI resumed in this chat (Admin)' });
        return json({ ok: true });
      }
      case 'ai_reply_now': return json({ out: await AI.aiReplyToLead(lead(b.lead_id), 'reply') });

      case 'me': return json({ ok: true, brand: s.brand_name, username: process.env.ADMIN_USERNAME || 'admin', snd: (await import('@/server/notifsound')).ownSoundVer(s) });

      // v136: light counts for the tab badges (polled every few seconds)
      case 'badges': {
        const c = (sql: string) => one<{ n: number }>(sql)!.n;
        const li = one<{ id: number; lead_id: number; text: string | null; file_type: string | null; created_at: number }>("SELECT m.id, m.lead_id, m.text, m.file_type, m.created_at FROM messages m JOIN leads l ON l.id=m.lead_id WHERE m.dir='in' AND m.created_at>l.admin_read_at AND l.status!='merged' AND NOT (" + emptyInSql('m') + ") ORDER BY m.created_at DESC, m.id DESC LIMIT 1");
        const ll = li ? leadById(li.lead_id) : null;
        return json({
          unread: c("SELECT COUNT(*) n FROM leads l WHERE l.status!='merged' AND EXISTS(SELECT 1 FROM messages m WHERE m.lead_id=l.id AND m.dir='in' AND m.created_at>l.admin_read_at)"),
          payouts: c("SELECT COUNT(*) n FROM payouts WHERE status='pending'"),
          tasks: c("SELECT COUNT(*) n FROM tasks WHERE status='open'"),
          dels: deleteRequests().length, short: shortLinks().length,
          meta_req: c("SELECT COUNT(*) n FROM meta_requests WHERE status IN ('pending','failed','manual','running')"),
          last_in: li && ll ? { id: li.id, lead_id: li.lead_id, name: ll.ch === 'wa' ? contactName(ll as any, s) || displayName(ll) : displayName(ll), text: li.text || (li.file_type === 'voice' ? 'Voice message' : li.file_type === 'photo' ? 'Photo' : li.file_type ? 'File' : ''), at: li.created_at } : null,
        });
      }
      // v168: Home → Landing page funnel (read-only; one funnel per landing page / ad type)
      case 'landing_funnel': { const [f, t] = dayRange(q('range'), s); return json((await import('@/server/funnel')).landingFunnels(f, t, q('line'))); }
      case 'stats': {
        void runFollowups();
        const [f, t] = dayRange(q('range'), s);
        const n = (sql: string, ...a: unknown[]) => one<any>(sql, ...a)!;
        // ?line=agency|funnel → only that landing page's ads (leads by the page they came from; sales/topups by their lead)
        // premium = only chats from /premium (part of Agency)
        const ln = q('line') === 'funnel' ? 'funnel' : q('line') === 'agency' ? 'agency' : q('line') === 'premium' ? 'premium' : null;
        // v120: people who came through the bot (source 'channel') are not landing-page ad people → not in the Agency / Funnel / Premium tabs (Home → 🤖 Bot tab)
        const NC = (a: string) => ` AND COALESCE(${a}.source,'')!='channel'`;
        const L = (a = 'leads') => (ln === 'funnel' ? `${a}.line='funnel'${NC(a)}` : ln === 'agency' ? `COALESCE(${a}.line,'agency')!='funnel' AND COALESCE(${a}.tier,'')!='premium'${NC(a)}` : ln === 'premium' ? `COALESCE(${a}.line,'agency')!='funnel' AND ${a}.tier='premium'${NC(a)}` : '1=1');
        // ?rt=1 → only people who came from a RETARGETING ad (its link has ?rt=1)
        const rt = q('rt') === '1';
        const L0 = L;
        const LR = (a = 'leads') => (rt ? `(${L0(a)}) AND ${RT_SQL(a)}` : L0(a));
        // v115: WhatsApp sales (no lead) count in their own line's tab (Funnel / Agency / Premium) by the product picked
        const WAL = ln === 'funnel' ? "sales.line='funnel'" : ln === 'premium' ? "COALESCE(sales.line,'agency')!='funnel' AND sales.tier='premium'" : "COALESCE(sales.line,'agency')!='funnel' AND COALESCE(sales.tier,'')!='premium'";
        const XL = (tbl: string) => (ln || rt ? `${ln && !rt && tbl === 'sales' ? `(sales.lead_id IS NULL AND COALESCE(sales.wa,0)=1 AND ${WAL}) OR ` : ''}EXISTS(SELECT 1 FROM leads lx WHERE lx.id=${tbl}.lead_id AND ${LR('lx')})${ln === 'agency' && !rt ? ` OR (${tbl}.lead_id IS NULL${tbl === 'sales' ? ' AND COALESCE(sales.wa,0)=0' : ''}) OR (${tbl}.lead_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM leads ly WHERE ly.id=${tbl}.lead_id))` : ''}` : '1=1');
        const webOn = ln !== 'funnel'; // website orders are Agency business
        const WT = (ln === 'premium' ? " AND tier='premium'" : ln === 'agency' ? " AND COALESCE(tier,'')!='premium'" : '') + (rt ? ` AND ${RT_SQL('web_orders')}` : ''); // Premium tab: only website orders placed from /premium
        const visitors = rt ? null : ln === 'agency' ? n("SELECT COUNT(*) n FROM page_visits WHERE page='agency' AND created_at>=? AND created_at<?", f, t).n
          : ln ? n('SELECT COUNT(*) n FROM page_visits WHERE page=? AND created_at>=? AND created_at<?', ln, f, t).n : n('SELECT COUNT(*) n FROM visits WHERE created_at>=? AND created_at<?', f, t).n;
        const forms = n(`SELECT COUNT(*) n FROM leads WHERE source='form' AND created_at>=? AND created_at<? AND ${LR()}`, f, t).n;
        const started = n(`SELECT COUNT(*) n FROM leads WHERE started_at>=? AND started_at<? AND status!='merged' AND COALESCE(source,'')!='channel' AND ${LR()}`, f, t).n; // v120: bot people → 🤖 Bot tab
        const sales = n(`SELECT COUNT(*) n, COALESCE(SUM(amount),0) rev, COALESCE(SUM(commission),0) c FROM sales WHERE created_at>=? AND created_at<? AND (${XL('sales')})`, f, t);
        const waS = n(`SELECT COUNT(*) n, COALESCE(SUM(amount),0) rev FROM sales WHERE ${WA_SALE('sales')} AND created_at>=? AND created_at<? AND (${XL('sales')})`, f, t);
        const tops = n(`SELECT COALESCE(SUM(amount),0) v, COALESCE(SUM(commission),0) c FROM topups WHERE created_at>=? AND created_at<? AND (${XL('topups')})`, f, t);
        ensureAutoSpend(s);
        // Premium has no Ad spend line of its own: its daily budget (Settings → Premium) × the days in the range
        const pf = Math.max(f, n("SELECT COALESCE(MIN(created_at),?) v FROM leads WHERE tier='premium'", now()).v); // not before the first Premium lead
        // Retargeting: its daily budgets (Ad spend → retargeting parts) × the days since the first retargeting lead
        const rf = Math.max(f, n(`SELECT COALESCE(MIN(created_at),?) v FROM leads WHERE ${RT_SQL('leads')}`, now()).v);
        const rtDays = Math.max(1, Math.ceil((Math.min(t, now()) - rf) / 86400000));
        const rtBud = ln === 'funnel' ? num(s.rt_budget_funnel) : ln === 'premium' ? num(s.rt_budget_premium) : ln === 'agency' ? num(s.rt_budget_agency) : num(s.rt_budget_agency) + num(s.rt_budget_premium) + num(s.rt_budget_funnel);
        void pf;
        // v151: Meta switch ON → results + spend of the matching campaigns from the Meta Insights API
        const mt = MA.metaOn(s) ? MA.metaTotals(localDate(f, s), localDate(t - 1, s), rt ? (ln ? ['rt_' + ln] : [...MA.RT_LINES]) : ln ? [ln, 'wa_' + ln] : [...(await import('@/server/profit')).SPEND_LINES], s) : null;
        const spend = rt ? (mt ? mt.spend : money(rtBud * rtDays))
          : money(n(`SELECT COALESCE(SUM(amount),0) v FROM ad_spend WHERE date>=? AND date<=?${ln ? ' AND line IN (?,?)' : ''}`, localDate(f, s), localDate(t - 1, s), ...(ln ? [ln, 'wa_' + ln] : [])).v); // v135: + that line's WhatsApp ads
        const acctCost = money(n(`SELECT COALESCE(SUM(${costSql(s)}),0) v FROM sales WHERE created_at>=? AND created_at<? AND (${XL('sales')})`, f, t).v + (webOn ? n("SELECT COALESCE(SUM(qty),0) v FROM web_orders WHERE kind='account' AND status='delivered' AND delivered_at>=? AND delivered_at<?" + WT, f, t).v * num(s.acct_cost, 3) : 0) + (rt ? 0 : replCost(f, t, ln))); // v156: + replacement accounts
        const web = webOn ? n("SELECT COUNT(*) n, COALESCE(SUM(amount),0) rev FROM web_orders WHERE status='delivered' AND delivered_at>=? AND delivered_at<?" + WT, f, t) : { n: 0, rev: 0 };
        const webTop = webOn && ln !== 'premium' ? n("SELECT COALESCE(SUM(amount),0) v, COALESCE(SUM(fee),0) fee FROM web_topups WHERE status='done' AND done_at>=? AND done_at<?", f, t) : { v: 0, fee: 0 };
        // v160: conversion — people who wrote in the period, buyers, % ; new chats that bought; old chats coming back
        const conv = await (async () => {
          const B = await import('@/server/bonus');
          const people = n(`SELECT COUNT(*) n FROM leads WHERE status!='merged' AND COALESCE(source,'')!='channel' AND ${LR()} AND id IN (SELECT m.lead_id FROM messages m WHERE m.dir='in' AND m.created_at>=? AND m.created_at<?)`, f, t).n;
          const rows = all<{ at: number; first_buy: number; first_msg: number | null }>(B.buyerRowsSql(XL('sales').replace(/\bsales\./g, 'x.')), f, t);
          const noLead = n(`SELECT COUNT(*) n FROM sales WHERE lead_id IS NULL AND created_at>=? AND created_at<? AND (${XL('sales')})`, f, t).n;
          // buyers not counted in "people" (bought by link without writing, or a bot-channel chat) → added, so the rate never goes over 100%
          const silent = n(`SELECT COUNT(DISTINCT lead_id) n FROM sales WHERE lead_id IS NOT NULL AND created_at>=? AND created_at<? AND (${XL('sales')})
            AND NOT EXISTS(SELECT 1 FROM leads lp WHERE lp.id=sales.lead_id AND lp.status!='merged' AND COALESCE(lp.source,'')!='channel' AND ${LR('lp')} AND lp.id IN (SELECT m.lead_id FROM messages m WHERE m.dir='in' AND m.created_at>=? AND m.created_at<?))`, f, t, f, t).n;
          const buyers = rows.length + noLead, active = people + silent + noLead;
          const newBought = n(`SELECT COUNT(*) n FROM leads WHERE started_at>=? AND started_at<? AND status!='merged' AND COALESCE(source,'')!='channel' AND ${LR()} AND EXISTS(SELECT 1 FROM sales x WHERE x.lead_id=leads.id AND x.created_at<?)`, f, t, t).n; // v161: bought by the end of the period
          const pct = (a: number, b: number) => b > 0 ? Math.round(a / b * 1000) / 10 : null;
          return { people, buyers, active, conv_pct: pct(buyers, active), new_bought: newBought, new_conv_pct: pct(newBought, started), ...B.buyerStats(rows, f) };
        })();
        // v161: what sold — by product (Telegram / WhatsApp), top-ups, website orders, replacements, total income
        const what = await (async () => {
          const P = await import('@/server/profit');
          const products = P.salesByProduct(f, t, XL('sales').replace(/\bsales\./g, 'x.'));
          const tp = n(`SELECT COUNT(*) n, COALESCE(SUM(amount),0) v, COALESCE(SUM(commission),0) c FROM topups WHERE created_at>=? AND created_at<? AND (${XL('topups')})`, f, t);
          const webK = webOn ? all<{ kind: string; n: number; q: number; v: number }>("SELECT kind, COUNT(*) n, COALESCE(SUM(qty),0) q, COALESCE(SUM(amount),0) v FROM web_orders WHERE status='delivered' AND delivered_at>=? AND delivered_at<?" + WT + ' GROUP BY kind', f, t) : [];
          const webTn = webOn && ln !== 'premium' ? n("SELECT COUNT(*) n FROM web_topups WHERE status='done' AND done_at>=? AND done_at<?", f, t).n : 0;
          let repl = { n: 0, c: 0 };
          try { repl = n(`SELECT COUNT(*) n, COALESCE(SUM(r.cost),0) c FROM meta_replacements r LEFT JOIN leads l ON l.id=r.lead_id WHERE r.created_at>=? AND r.created_at<?${ln === 'premium' ? " AND l.tier='premium'" : ln === 'funnel' ? " AND l.line='funnel'" : ln === 'agency' ? " AND COALESCE(l.line,'agency')!='funnel' AND COALESCE(l.tier,'')!='premium'" : ''}`, f, t) as { n: number; c: number }; } catch { /* */ }
          const noAgent = n(`SELECT COUNT(*) n, COALESCE(SUM(amount),0) v FROM sales WHERE created_at>=? AND created_at<? AND (${XL('sales')}) AND (agent_id IS NULL OR NOT EXISTS(SELECT 1 FROM agents a WHERE a.id=sales.agent_id AND a.deleted=0))`, f, t);
          return { products, topups: { n: tp.n + webTn, v: money(tp.v + webTop.v), fee: money(tp.c + webTop.fee) }, web: webK.map(w => ({ kind: w.kind, n: w.n, q: w.q, v: money(w.v) })), repl: { n: repl.n, cost: money(repl.c) },
            no_agent: { n: noAgent.n, v: money(noAgent.v) }, sources: P.bySource(f, t, XL('sales').replace(/\bsales\./g, 'x.'), LR('l')), income: money(sales.rev + web.rev + tops.c + webTop.fee) };
        })();
        const bonus = ln || rt ? 0 : money(n('SELECT COALESCE(SUM(amount),0) v FROM agent_bonus WHERE created_at>=? AND created_at<?', f, t).v); // v159: incentives (whole team only)
        // v162: My income (whole business, All tab): from the agents' work + your own (manager) work + website / not on an agent; agents' earnings
        const mine = ln || rt ? null : await (async () => {
          const T = (await import('@/server/profit')).teamProfit(f, t);
          const rows = T.rows as any[];
          const sumP = (r: any[]) => money(r.reduce((x, y) => x + num(y.profit), 0));
          const mgr = rows.filter(r => r.role === 'manager'), ags = rows.filter(r => r.role !== 'manager');
          const other = money(num(T.off.profit));
          const total = money(sumP(mgr) + sumP(ags) + other);
          return {
            total, from_agents: sumP(ags), from_me: sumP(mgr), other, me_names: mgr.map(r => r.name),
            other_parts: { web: money(num(T.off.web?.v)), no_agent: money(num(T.off.sales?.v)), spend: money(num(T.off.spend)) },
            agents: ags.map(r => ({ id: r.id, name: r.name, sales: r.sales || 0, comm: money(num(r.sale_comm)), bonus: money(num(r.bonus)), earn: money(num(r.sale_comm) + num(r.bonus)), profit: money(num(r.profit)) })),
            comm: money(rows.reduce((x, y) => x + num(y.sale_comm), 0) + num(T.off.comm)), bonus, after_bonus: money(total - bonus),
          };
        })();
        const tasksOpen = n("SELECT COUNT(*) n FROM tasks WHERE status='open'").n;
        const byTheme = all(`SELECT COALESCE(theme,'?') theme, COUNT(*) n FROM leads WHERE source='form' AND created_at>=? AND created_at<? AND ${LR()} GROUP BY theme`, f, t);
        const status = all(`SELECT status, COUNT(*) n FROM leads WHERE status!='merged' AND ${LR()} GROUP BY status`);
        // Telegram channel: join requests in the range, one per person per source. Website joins send Subscribe; chat-link joins don't.
        // channel ads (old /telegram page + v114 channel-ad pages) bring joins, not landing-page leads
        const tgSpend = money(n("SELECT COALESCE(SUM(amount),0) v FROM ad_spend WHERE line IN ('telegram','ch_agency','ch_premium','ch_funnel') AND date>=? AND date<=?", localDate(f, s), localDate(t - 1, s)).v);
        const chSpend = (l: string) => money(n('SELECT COALESCE(SUM(amount),0) v FROM ad_spend WHERE line=? AND date>=? AND date<=?', 'ch_' + l, localDate(f, s), localDate(t - 1, s)).v);
        const jn = (w: string) => n(`SELECT COUNT(DISTINCT tg_user) n FROM channel_joins WHERE requested_at>=? AND requested_at<? AND tg_user IS NOT NULL AND ${w}`, f, t).n;
        const chanSub = { agency: jn("COALESCE(src,'bar')='bar' AND line='agency'"), funnel: jn("COALESCE(src,'bar')='bar' AND line='funnel'"), page: jn("src='page'") };
        const chan = {
          on: !!(s.channel_chat || s.channel_link), ...chanSub, total: chanSub.agency + chanSub.funnel + chanSub.page,
          chat: jn("src='chat'"), spend: tgSpend, cps: chanSub.page && tgSpend ? money(tgSpend / chanSub.page) : null,
          page_ads: (await import('@/server/chanads')).tgPageStats(f, t, money(n("SELECT COALESCE(SUM(amount),0) v FROM ad_spend WHERE line='telegram' AND date>=? AND date<=?", localDate(f, s), localDate(t - 1, s)).v)),
        };
        const leadSpend = ln || rt ? spend : money(spend - tgSpend); // channel ads bring subscribers, not leads/sales
        const chanads = !ln && !rt && s.chan_ads_on !== '0' ? (await import('@/server/chanads')).chanStats(f, t, { agency: chSpend('agency'), premium: chSpend('premium'), funnel: chSpend('funnel') }) : null;
        // v137: WhatsApp ads block (only when those ads run; the money is counted everywhere anyway)
        const waOnA = s.wa_ads_on === '1', waOnC = s.wa_comm_ads_on === '1';
        const waads = !ln && !rt && (waOnA || waOnC) ? (() => {
          const LNS3 = ['agency', 'premium', 'funnel'] as const;
          const SLN = (l: string) => (l === 'funnel' ? "COALESCE(x.line,'agency')='funnel'" : l === 'premium' ? "COALESCE(x.line,'agency')!='funnel' AND x.tier='premium'" : "COALESCE(x.line,'agency')!='funnel' AND COALESCE(x.tier,'')!='premium'");
          const LLN = (l: string) => (l === 'funnel' ? "lw.line='funnel'" : l === 'premium' ? "COALESCE(lw.line,'agency')!='funnel' AND lw.tier='premium'" : "COALESCE(lw.line,'agency')!='funnel' AND COALESCE(lw.tier,'')!='premium'");
          const lines = Object.fromEntries(LNS3.map(l => {
            const v = n("SELECT COUNT(*) n FROM page_visits WHERE page=? AND created_at>=? AND created_at<?", 'wa_' + l, f, t).n;
            const c = n('SELECT COUNT(*) n, COALESCE(SUM(lead_id IS NOT NULL),0) lead FROM wa_clicks WHERE line=? AND created_at>=? AND created_at<?', l, f, t);
            // sold: WhatsApp sales of this line (hand sales by their product, chat sales by the chat's line)
            const sl = n(`SELECT COUNT(*) n, COALESCE(SUM(x.amount),0) rev FROM sales x LEFT JOIN leads lw ON lw.id=x.lead_id WHERE x.created_at>=? AND x.created_at<? AND ((x.lead_id IS NULL AND COALESCE(x.wa,0)=1 AND ${SLN(l)}) OR (COALESCE(lw.ch,'')='wa' AND ${LLN(l)}))`, f, t);
            const sp = money(n("SELECT COALESCE(SUM(amount),0) v FROM ad_spend WHERE line=? AND date>=? AND date<=?", 'wa_' + l, localDate(f, s), localDate(t - 1, s)).v);
            const j = n("SELECT COUNT(*) n, COALESCE(SUM(msg_at IS NOT NULL),0) m, COALESCE(SUM(EXISTS(SELECT 1 FROM sales x WHERE x.lead_id=wa_joins.lead_id)),0) sold FROM wa_joins WHERE line=? AND created_at>=? AND created_at<?", l, f, t);
            return [l, { visitors: v, chat_taps: c.n, chats: c.lead, sold: sl.n, revenue: money(sl.rev), spend: sp, profit: money(sl.rev - sp), community_numbers: j.n, messaged: j.m, community_sold: j.sold }];
          }));
          return { chat_on: waOnA, comm_on: waOnC, lines };
        })() : null;
        return json({ meta: mt, line: ln || 'all', rt, chan, chanads, waads, wa_ads_on: waOnA, wa_comm_ads_on: waOnC, lead_ads: s.lead_ads_on !== '0', chan_delay: Number(s.chan_sub_delay_min ?? 60) || 0,
          visitors, forms, started, sales: sales.n, revenue: money(sales.rev), sale_comm: money(sales.c), topup_vol: money(tops.v), topup_fees: money(tops.c), spend,
          cpl: started ? money(leadSpend / started) : null, cpf: forms ? money(leadSpend / forms) : null, // Lead event = messaged on Telegram
          wa_sales: waS.n, wa_revenue: money(waS.rev),
          cpa: sales.n + web.n ? money(leadSpend / (sales.n + web.n)) : null,
          // v135: ROI = net profit ÷ ad spend (same profit as below), not just revenue − spend
          roi: spend ? Math.round(money(sales.rev + tops.c + web.rev + webTop.fee - spend - sales.c - acctCost) / spend * 100) : null, roas: spend ? money((sales.rev + web.rev) / spend) : null,
          profit: money(sales.rev + tops.c + web.rev + webTop.fee - spend - sales.c - acctCost), acct_cost: acctCost, bonus, conv, what, mine, web_sales: web.n, web_revenue: money(web.rev), web_topup_vol: money(webTop.v), web_topup_fees: money(webTop.fee), tasks_open: tasksOpen, web_on: s.web_orders_on === '1', status, by_theme: byTheme, // v162: incentive is not taken off
          unassigned: n(`SELECT COUNT(*) n FROM leads WHERE tg_chat_id IS NOT NULL AND agent_id IS NULL AND status!='merged' AND ${LR()}`).n,
          // v136: open chats where the customer wrote last (nobody answered yet), in total and per agent
          needs_reply: n(`SELECT COUNT(*) n FROM leads WHERE ${needsReplySql()} AND ${LR()}`).n,
          // v137: split by app, so Home opens the Telegram / WhatsApp tab that has them
          needs_reply_ch: Object.fromEntries(['tg', 'wa'].map(k => [k, 0]).concat(all<{ c: string; n: number }>(`SELECT CASE WHEN COALESCE(ch,'')='wa' THEN 'wa' ELSE 'tg' END c, COUNT(*) n FROM leads WHERE ${needsReplySql()} AND ${LR()} GROUP BY c`).map(r => [r.c, r.n]))),
          needs_reply_by_ch: all<{ a: number; c: string; n: number }>(`SELECT agent_id a, CASE WHEN COALESCE(ch,'')='wa' THEN 'wa' ELSE 'tg' END c, COUNT(*) n FROM leads WHERE ${needsReplySql()} AND agent_id IS NOT NULL AND ${LR()} GROUP BY agent_id, c`)
            .reduce((m, r) => { (m[r.a] ||= { tg: 0, wa: 0 })[r.c as 'tg' | 'wa'] = r.n; return m; }, {} as Record<number, { tg: number; wa: number }>),
          needs_reply_by: Object.fromEntries(all<{ a: number; n: number }>(`SELECT agent_id a, COUNT(*) n FROM leads WHERE ${needsReplySql()} AND agent_id IS NOT NULL AND ${LR()} GROUP BY agent_id`).map(r => [r.a, r.n])),
          // v136: Telegram | WhatsApp split of sales and top-up fees (WhatsApp = a WhatsApp chat or a WhatsApp sale the admin added)
          split: (() => {
            const W = (tb: string) => `(COALESCE(${tb}.wa,0)=1 OR EXISTS(SELECT 1 FROM leads lw WHERE lw.id=${tb}.lead_id AND (lw.ch='wa' OR lw.tg_chat_id LIKE 'wa:%')))`;
            const sx = n(`SELECT COUNT(*) n, COALESCE(SUM(amount),0) rev FROM sales WHERE ${W('sales')} AND created_at>=? AND created_at<? AND (${XL('sales')})`, f, t);
            const tx = n(`SELECT COALESCE(SUM(commission),0) c FROM topups WHERE ${W('topups')} AND created_at>=? AND created_at<? AND (${XL('topups')})`, f, t);
            return { wa: { n: sx.n, rev: money(sx.rev), fees: money(tx.c) }, tg: { n: sales.n - sx.n, rev: money(sales.rev - sx.rev), fees: money(tops.c - tx.c) } };
          })(),
          followups: n(`SELECT COUNT(*) n FROM leads WHERE ((fu_due=1 AND status='active') OR COALESCE(remind_due,0)=1) AND ${LR()}`).n,
          payouts_pending: n("SELECT COUNT(*) n, COALESCE(SUM(amount),0) v FROM payouts WHERE status='pending'"),
          unread: n(`SELECT COUNT(*) n FROM leads l WHERE l.status!='merged' AND ${LR('l')} AND EXISTS(SELECT 1 FROM messages m WHERE m.lead_id=l.id AND m.dir='in' AND m.created_at>l.admin_read_at)`).n,
          setup: { pixel: !!s.pixel_id, capi: !!s.capi_token, bot: !!s.bot_username, business: !!s.biz_conn_id, mode: s.tg_mode, agents: n('SELECT COUNT(*) n FROM agents WHERE deleted=0').n, push: !!s.fcm_service_account },
        });
      }

      case 'campaigns': return json(await campaignStats(q('range'), q('line'), q('mode') || 'sales', q('app') || 'all')); // v137: sales made in the period (default) / chats started
      // v131: WhatsApp (WATI) — webhook URL to paste in WATI, a test message, the raw log
      case 'wati': {
        const W = await import('@/server/wati'), WS = await import('@/server/wasync'), BR = await import('@/server/btnreplies');
        // v138: each button reply as the customer gets it NOW (saved settings: prices, INR rate, Premium prices for Premium)
        const map = BR.parseReplies(s.wati_btn_replies), sample = { agency: { line: 'agency', service: 'account' }, premium: { line: 'agency', service: 'account', tier: 'premium' }, funnel: { line: 'funnel', service: 'funnel' } } as const;
        const btn_preview = Object.fromEntries(BR.BTN_LINES.map(ln => { const l = { ...sample[ln], name: 'Rahul' }; const labels = WS.waButtonsFor(s, l); return [ln, Object.fromEntries(labels.map(x => { const r = BR.replyFor(map, ln, labels, x); return [x, r?.text.trim() ? WS.btnReplyText(s, l, r.text) : '']; }))]; }));
        return json({ hook_url: `${baseUrl(req).replace(/\/$/, '')}/api/wati/${W.hookKey()}`, ready: W.waReady(), log: W.watiLog(40), api_log: W.watiApiLog(10), btn_preview });
      }
      // v140: each line's offer image for the admin previews (Settings → Telegram channel / WATI Pro buttons)
      case 'offer_images': {
        const O = await import('@/server/offerimg');
        return json({ lines: O.OFFER_LINES.map(ln => ({ line: ln, url: O.offerImageUrl(s, ln), own: !!O.ownOfferImage(s, ln), preview: O.ownOfferImage(s, ln) || O.offerImagePath(s, ln), caption: O.welcomeCaption(s, ln, 'wa') })) });
      }
      case 'wati_test': {
        const W = await import('@/server/wati');
        const to = String(b.phone || '').replace(/\D/g, '');
        if (to.length < 8) throw new HttpError(400, 'Enter a WhatsApp number with country code');
        if (getSettings().wati_on !== '1') throw new HttpError(400, 'Switch WhatsApp chats ON first');
        const r = await W.waSendText(getSettings(), 'wa:' + to, String(b.text || 'Test message from AdsBhai'));
        if (!r.ok) throw new HttpError(400, r.description || 'Not sent');
        return json({ ok: true });
      }
      case 'camp_plan_kinds': { const C = await import('@/server/camps'); return json({ kinds: Object.entries(C.PLAN_KINDS).map(([k, v]) => ({ k, label: v.label })), plans: C.listPlans() }); }
      case 'camp_plan_preview': { const C = await import('@/server/camps'); return json(C.planNames(b, baseUrl(req))); }
      case 'camp_plan_save': { const C = await import('@/server/camps'); return json(C.savePlan(b, baseUrl(req))); }
      case 'camp_plan_del': { const C = await import('@/server/camps'); return json(C.delPlan(b.id)); }
      case 'camp_spend': return json({ acts: campActs(s).map(a => 'act_' + a).join(', '), token_set: !!s.camp_token });
      case 'camp_spend_save': return json(saveCampSpend(b, (k, v) => setSetting(k as any, v)));
      case 'noreply': { const ids = (Array.isArray(b.lead_ids) ? b.lead_ids : [b.lead_id]).map((x: unknown) => num(x)).filter((x: number) => x > 0); return json(markNoReply(ids, 'Admin')); }
      case 'leads': {
        try { stampCamps(); } catch (e) { console.warn('[camps]', (e as Error).message); }
        const [f, t] = dayRange(q('range') || 'all', s);
        const where = ['l.created_at>=?', 'l.created_at<?', "l.status!='merged'"]; const args: unknown[] = [f, t];
        const cs = q('status');
        if (cs === 'hot') { where.splice(0, 2); args.length = 0; where.push(hotSql('l')); } // hot = whenever they came
        else if (cs === 'call_todo' || cs === 'call_done' || cs === 'call_no' || cs === 'call_ni' || cs === 'call_int' || cs === 'call_conv') {
          assignCalls();
          where.push(cs === 'call_todo' ? callTodoSql('l') : `${callSql('l')} AND l.call_state='${({ call_done: 'called', call_no: 'no_answer', call_ni: 'not_interested', call_int: 'interested', call_conv: 'converted' } as Record<string, string>)[cs]}'`);
        } else if (cs === 'reply') where.push(needsReplySql('l')); // v144: Needs reply = open + sold chats where the customer wrote last
        else if (cs) { where.push('l.status=?'); args.push(cs); }
        if (q('chats') === '1') where.push('l.tg_chat_id IS NOT NULL');
        if (q('agent') === 'none') where.push('l.agent_id IS NULL'); // v136: Unassigned folder
        else if (q('agent')) { where.push('l.agent_id=?'); args.push(num(q('agent'))); }
        if (q('biz') === 'agency' || q('biz') === 'funnel') { where.push('l.biz=?'); args.push(q('biz')); }
        if (q('tier') === 'premium') where.push("l.tier='premium'");
        if (q('q')) {
          const v = '%' + q('q') + '%';
          let d = String(q('q')).replace(/\D/g, ''); if (d.length === 12 && d.startsWith('91')) d = d.slice(2); if (d.length === 11 && d.startsWith('0')) d = d.slice(1);
          const dv = d.length >= 4 ? '%' + d + '%' : '\u0000';
          where.push("(l.name LIKE ? OR l.phone LIKE ? OR REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(l.phone,''),' ',''),'-',''),'+',''),'(','') LIKE ? OR l.email LIKE ? OR l.tg_username LIKE ? OR l.tg_name LIKE ? OR l.id=?)");
          args.push(v, v, dv, v, v, v, num(q('q'), -1));
        }
        const rows = all<any>(`SELECT l.token, l.tg_chat_id, l.id, l.tier, l.biz, l.biz_no, l.line, l.source, l.theme, l.name, l.phone, l.email, l.service, l.has_bm, l.niche, l.budget, l.tg_username, l.tg_name, l.status, l.fu_stage, l.fu_due,
          l.ch, l.camp, l.ad, l.camp_kind, l.menu, l.created_at, l.started_at, l.sold_at, l.last_text, l.last_at, l.last_in_at, l.last_out_at, l.noreply_at, l.remind_at, l.remind_due, l.agent_id, a.name agent_name, l.cover_agent_id, (SELECT name FROM agents cv WHERE cv.id=l.cover_agent_id) cover_name, (l.hold_alert IS NOT NULL AND COALESCE(l.hold_until,0) > ${now()}) held, (l.fbc IS NOT NULL AND l.fbc!='') has_fbc,
          l.call_state, l.call_at, l.call_by, l.call_note, l.call_agent_id, (SELECT name FROM agents ca WHERE ca.id=l.call_agent_id) call_agent_name,
          (SELECT COALESCE(SUM(amount),0) FROM sales WHERE lead_id=l.id) revenue,
          (SELECT COUNT(*) FROM messages m WHERE m.lead_id=l.id AND m.dir='in' AND m.created_at>l.admin_read_at) unread,
          (SELECT MAX(d.due_at) FROM delayed_msgs d WHERE d.lead_id=l.id AND d.status='queued' AND d.notify IS NOT NULL AND d.due_at > ${now() - 120000}) welcome_due
          FROM leads l LEFT JOIN agents a ON a.id=l.agent_id WHERE ${where.join(' AND ')} ORDER BY COALESCE(l.last_at, l.created_at) DESC LIMIT 1500`, ...args);
        return json({ wa_on: s.wati_on === '1', leads: rows.map(({ token, tg_chat_id, ...r }) => ({ ...r, ...chipsOf(r), ...(r.ch === 'wa' ? { contact: contactName(r, s) } : {}), wa_text: r.phone ? waText(s, { ...r, token, tg_chat_id }, baseUrl(req)) : null })) });
      }
      case 'chat': {
        stampLead(num(q('id'))); // v130: which campaign / ad
        const l = lead(q('id'));
        markReadEverywhere(l); // v113: seen in the admin app = seen in the agent app + Telegram
        waPhoneSyncSoon(l); // v137: replies typed in the WhatsApp Business app (background, max once a minute)
        const page = chatPage(l.id, num(q('after')), 1500, true); // v139: by real time; the cursor stays the id
        return json({ cursor: page.cursor,
          lead: { ...l, ...chipsOf(l as any), ...(l.ch === 'wa' ? { contact: contactName(l as any, s) } : {}), prices: leadPrices(s, l), texts: offerTexts(s, l), agent_name: agentById(l.agent_id)?.name || null,
            ...(() => { const c = (l as Lead & { cover_agent_id?: number | null; cover_since?: number | null }); if (!c.cover_agent_id || c.cover_agent_id === l.agent_id) return {}; const cv = agentById(c.cover_agent_id); const deal = !!realConvAt(l.id, c.cover_agent_id, c.cover_since || 0);
              return { cover_name: cv?.name || 'agent', cover_label: `Covered by ${cv?.name || 'agent'}${cv?.role === 'manager' ? ' (manager)' : ''} for ${agentById(l.agent_id)?.name || 'agent'} · ${deal ? 'deal in progress' : 'covering'}` }; })(), // v141
            wa_text: l.phone ? waText(s, l, baseUrl(req)) : null, ai_active: AI.aiActiveFor(l as any, s), ai_auto_agent: AI.autoAgents(s).includes(l.agent_id || 0), coach_on: s.ai_coach_on === '1' && AI.aiReady(s) },
          messages: page.messages,
          deleted: all('SELECT id, deleted_by FROM messages WHERE lead_id=? AND deleted_at IS NOT NULL', l.id), // v137
          read_upto: one<{ v: number | null }>("SELECT MAX(id) v FROM messages WHERE lead_id=? AND dir='out' AND read_at IS NOT NULL", l.id)?.v || 0,
          delivered_upto: one<{ v: number | null }>("SELECT MAX(id) v FROM messages WHERE lead_id=? AND dir='out' AND delivered_at IS NOT NULL", l.id)?.v || 0,
          sales: all(`SELECT x.*, CASE WHEN x.owner_agent_id IS NOT NULL AND x.agent_id!=x.owner_agent_id AND a.role!='manager' THEN 'sold by ' || a.name || ' (covering for ' || o.name || ')' END cover_note, (SELECT reason FROM sale_splits p WHERE p.sale_id=x.id LIMIT 1) split_reason
            FROM sales x LEFT JOIN agents a ON a.id=x.agent_id LEFT JOIN agents o ON o.id=x.owner_agent_id WHERE x.lead_id=? ORDER BY x.id`, l.id), // v141
          topups: all('SELECT * FROM topups WHERE lead_id=? ORDER BY id', l.id),
          capi: all('SELECT event_id, event_name, status, created_at FROM capi_log WHERE lead_id=? ORDER BY created_at', l.id),
        });
      }
      case 'call_mark': { const l = lead(b.lead_id); return json({ ok: true, lead: markCall(l.id, String(b.state || ''), String(b.note || ''), 'Admin') }); }
      case 'send': { const l = lead(b.lead_id); await sendOnceByCid(b.cid, l.id, () => sendToLead(l, String(b.text || ''), 'admin', null, num(b.reply_to) || null)); return json({ ok: true }); } // v166: + cid
      case 'msg_delete': { const { deleteMessage } = await import('@/server/msgdelete'); return json(await deleteMessage(num(b.id), { role: 'admin', id: null, name: 'Admin' }, () => true)); } // v137
      case 'lead_delete': return json(deleteLead(num(b.lead_id)));
      case 'del_requests': return json({ list: deleteRequests() });
      case 'del_keep': return json(keepChat(num(b.lead_id)));
      case 'upload': { const form = await req.formData(); await uploadToLead(lead(form.get('lead_id')), form, 'admin', null); return json({ ok: true }); }
      case 'tasks': return json({ tasks: listTasks(q('status') === 'done' ? 'done' : q('status') === 'all' ? 'all' : 'open') });
      case 'task_done': return json(await completeTask(num(b.id), b, 'admin'));
      case 'mark_paid': return json(await markPaid(b.type === 'topup' ? 'web_topups' : 'web_orders', num(b.id), 'admin'));
      case 'cancel_item': return json(cancelItem(b.type === 'topup' ? 'web_topups' : 'web_orders', num(b.id), null));
      case 'short_links': return json({ links: shortLinks() });
      case 'web_orders': {
        const st = q('status');
        const orders = all<any>(`SELECT o.*, c.email, c.name, c.phone FROM web_orders o JOIN customers c ON c.id=o.customer_id ${st ? 'WHERE o.status=?' : ''} ORDER BY o.id DESC LIMIT 500`, ...(st ? [st] : []));
        const topups = all<any>(`SELECT t.*, c.email, c.name, c.phone FROM web_topups t JOIN customers c ON c.id=t.customer_id ${st ? 'WHERE t.status=?' : ''} ORDER BY t.id DESC LIMIT 500`, ...(st ? [st] : []));
        const openTask = (k: string, id: number) => one<{ id: number }>(`SELECT id FROM tasks WHERE ${k}=? AND status='open'`, id)?.id || null;
        return json({ orders: orders.map(o => ({ ...o, task_id: openTask('order_id', o.id) })), topups: topups.map(t => ({ ...t, task_id: openTask('topup_id', t.id) })) });
      }
      case 'remind': return json(setReminder(lead(b.lead_id), b.at, b.note, 'admin'));
      case 'reassign': {
        const l = lead(b.lead_id); const ag = agentById(num(b.agent_id));
        if (!ag || ag.deleted) throw new HttpError(404, 'Agent not found');
        run('UPDATE leads SET agent_id=?, assigned_at=?, agent_read_at=0 WHERE id=?', ag.id, now(), l.id);
        clearCoverForAssign(l.id); // v141: assigning by hand ends any cover (and its credit window)
        addMsg(l, { dir: 'sys', sender: 'system', text: `🔁 Assigned to ${ag.name}` });
        waSyncSoon(l.id);
        await notifyAgent(ag, `🔁 Lead #${l.id} ${displayName(l)} was assigned to you.\n↩️ Reply to this message to answer.`, l.id, { title: 'Chat assigned to you', body: displayName(l) });
        return json({ ok: true });
      }
      /* v136: sell from a chat in the admin app — recorded for the chat's agent (or the manager) */
      case 'sales_me': {
        const p = tierFor(s, 'premium'), f = msgFor(s, 'funnel');
        const a = offerOf(s, 'agency'), fo = offerOf(s, 'funnel'), po = offerOf(s, 'premium');
        return json({
          price_account: num(s.price_account), price_account_full: num(s.price_account_full), price_fb_old: num(s.price_fb_old), price_premium_full: num(s.price_premium_full), price_funnel: num(s.price_funnel), topup_pct: num(s.topup_comm_pct), topup_min: num(s.topup_min, 30), max_discount_pct: num(s.max_discount_pct, 40),
          paylinks: payLinksOn(s), meta_on: metaOn(), meta_acct: metaHas(), meta_off: !metaEnabled(), meta_email: s.meta_email_invites === '1',
          product_msgs: productInfoMsgs(s), quick_replies: lineList(fmtS(s.quick_replies, s)), fu: [fmtS(s.fu1, s), fmtS(s.fu2, s), fmtS(s.fu3, s)],
          quick_replies_f: lineList(fmtS(f.quick_replies, f)), fu_f: [fmtS(f.fu1, f), fmtS(f.fu2, f), fmtS(f.fu3, f)],
          premium: { price_account: num(p.price_account), topup_pct: num(p.topup_comm_pct), quick_replies: lineList(fmtS(p.quick_replies, p)), fu: [fmtS(p.fu1, p), fmtS(p.fu2, p), fmtS(p.fu3, p)] },
          offer: a || fo || po ? { account: a?.price || 0, funnel: fo?.price || 0, free: po?.free || 0 } : null,
        });
      }
      case 'sold': { const l = lead(b.lead_id); const o = owner(l); return json({ ok: true, by: o.name, ...(await recordSale(l, { ...o, name: `Admin for ${o.name}` }, b, { admin: true })) }); } // v144: the admin may set any price > 0
      case 'topup': { const l = lead(b.lead_id); const r = addTopup(l, owner(l), b.amount, b.note); byAdmin(l); return json({ ok: true, ...r }); }
      case 'paylink': { const l = lead(b.lead_id); const r = createPayLink(l, owner(l).id, b, { noMin: true, free: true }); byAdmin(l); return json(r); }
      case 'paylinks': return json(chatLinksAndItems(lead(q('lead_id')))); // v144: + the chat's product catalog
      case 'paylink_cancel': return json(cancelPayLink(num(b.id), null, { force: b.force === true || b.force === 1 })); // v166: a part-paid link only with force
      case 'lead_accounts': return json({ accounts: leadAccounts(lead(q('lead_id')).id) });
      case 'meta_hand_scan': return json(await (await import('@/server/handdeliver')).handScan(Array.isArray(b.shots) ? b.shots : [])); // v175
      case 'meta_hand': { const l = lead(b.lead_id); return json(await (await import('@/server/handdeliver')).handDeliver('admin', owner(l), l, b)); }
      case 'meta_chat': {
        const l = lead(q('lead_id'));
        const free = { verified: 0, review: 0, unverified: 0 } as Record<string, number>;
        const cats = { premium: 0, std: 0 } as Record<string, number>;
        for (const a of freeAccounts('any')) if (a.bstatus === 'ok') { free[tierOf(a.verification)]++; const c = catOf(a); if (c) cats[c]++; }
        return json({ on: metaHas(), off: !metaEnabled(), email_invites: s.meta_email_invites === '1', accounts: leadMetaAccounts(l.id), credit: openCredit(l.id), free, cats, free_list: freePickList(), requests: listRequests('all').filter(r => r.lead_id === l.id).slice(0, 10),
          links: all("SELECT code, kind, label, total, amount, fee, act_id FROM pay_links WHERE lead_id=? AND status='paid' AND parts IS NULL AND code NOT IN (SELECT pay_code FROM meta_requests WHERE pay_code IS NOT NULL AND status!='rejected') ORDER BY id DESC", l.id) });
      }
      case 'meta_request': return json(await createRequest({ role: 'admin', id: null, name: 'Admin' }, (() => { /* v173 QA: a chat request never picks the account */ const bb = { ...b } as Record<string, unknown>; delete bb.new_act; delete bb.hand; if (bb.kind !== 'topup') delete bb.act_id; return bb; })(), lead(b.lead_id)));
      case 'wa_sales': return json(listWaSales(true));
      case 'wa_sale_agent': return json(waSaleAgent(b.id, b.agent_id)); // v161
      case 'wa_sale_add': return json(addWaSale(b, { name: 'Admin', agent_id: pickAgent(b.agent_id) })); // v161: who made it (no commission)
      case 'wa_sale_del': return json(delWaSale(b.id));
      case 'wa_topup_add': return json(addWaTopup(b, { name: 'Admin' }));
      case 'wa_topup_del': return json(delWaTopup(b.id));
      case 'topup_del': return json((await import('@/server/salehist')).deleteTopup(b.id)); // v124
      case 'wa_sale_edit': return json(editWaSale(b.id, b.amount));
      case 'lead_type': {
        return json(setLeadType(lead(b.lead_id), String(b.type || ''), 'owner'));
      }
      case 'lead_status': {
        const l = lead(b.lead_id);
        // v146: Sold chats can go to Dead too (abusive / done); reopening a chat with a sale puts it back in Sold
        const st = b.status === 'dead' ? 'dead' : (l as Lead).sold_at ? 'sold' : 'active';
        run("UPDATE leads SET status=?, fu_due=0, fu_stage=0, last_in_at=CASE WHEN ?='active' THEN ? ELSE last_in_at END WHERE id=?", st, st, now(), l.id);
        waSyncSoon(b.lead_id ? num(b.lead_id) : null); // v137 (WATI Pro): Dead → SOLVED, attributes
        return json({ ok: true });
      }

      case 'agents': {
        const rows = all<any>("SELECT id, name, username, comm_premium, comm_funnel, auto_off_at, COALESCE(role,'agent') role, COALESCE(lines,'agency') lines, COALESCE(chans,'tg') chans, COALESCE(auto_acct,0) auto_acct, COALESCE(auto_topup,0) auto_topup, COALESCE(ring_off,0) ring_off, tg_chat_id, comm_per_sale, receive, online, last_seen, created_at FROM agents WHERE deleted=0 ORDER BY id");
        return json({ agents: rows.map(a => ({ ...a, ...presence(a.last_seen), ...(a.role === 'manager' ? { mgr_lines: s.mgr_lines } : {}), wallet: wallet(a.id), chats: one<any>("SELECT COUNT(*) n FROM leads WHERE agent_id=? AND status IN ('active','new')", a.id)!.n })) });
      }
      case 'ring_set': { // v140: per-person "Ring on silent / vibrate" (can only turn the ring off; the global switch still applies)
        const P = await import('@/server/push');
        if (!P.setRingOff(String(b.key || ''), b.ring === false || b.off === true)) throw new HttpError(400, 'Person not found');
        return json({ ok: true, people: P.ringPeople() });
      }
      case 'agent_save': {
        const name = String(b.name || '').trim().slice(0, 40);
        const username = String(b.username || '').trim().toLowerCase().slice(0, 30);
        const password = String(b.password || '');
        if (!name) throw new HttpError(400, 'Enter the agent’s name');
        if (!/^[a-z0-9._-]{3,30}$/.test(username)) throw new HttpError(400, 'Username: 3–30 letters, numbers, dot, dash or underscore');
        const dupe = one<{ id: number }>('SELECT id FROM agents WHERE lower(username)=? AND deleted=0 AND id!=?', username, num(b.id));
        if (dupe) throw new HttpError(400, 'This username is already used by another agent');
        const role = b.role === 'manager' ? 'manager' : 'agent';
        const comm = role === 'manager' ? 0 : money(b.comm_per_sale ?? 2); // manager's sales are the business's earnings
        // which chats this agent takes: Agency, Funnel or both
        const ls = (Array.isArray(b.lines) ? b.lines : String(b.lines || 'agency').split(',')).map(String).filter(x => x === 'agency' || x === 'funnel' || x === 'premium');
        // Premium commission: empty = same as the normal commission
        const commP = role === 'manager' || b.comm_premium === '' || b.comm_premium == null ? null : money(b.comm_premium);
        const commF = role === 'manager' || b.comm_funnel === '' || b.comm_funnel == null || !(money(b.comm_funnel) > 0) ? null : money(b.comm_funnel); // v141
        const linesStr = (ls.some(x => x !== 'premium') ? [...new Set(ls)] : ['agency', ...ls]).join(',');
        // v131: which chats the agent gets: Telegram, WhatsApp or both (the manager sees both always)
        const chs = (Array.isArray(b.chans) ? b.chans : String(b.chans ?? 'tg').split(',')).map(String).filter(x => x === 'tg' || x === 'wa');
        const chansStr = (chs.length ? [...new Set(chs)] : ['tg']).join(',');
        const wasOn = b.id ? one<{ r: number }>('SELECT receive r FROM agents WHERE id=?', num(b.id))?.r : undefined;
        if (password && password.length < 6) throw new HttpError(400, 'Password must be at least 6 characters'); // v166: checked before anything is saved
        if (!b.id && password.length < 6) throw new HttpError(400, 'Password must be at least 6 characters');
        tx(() => { // v166: all or nothing
        // manager: which chats he takes besides Agency (Funnel / Premium) — a setting, there is one manager
        if (role === 'manager' && typeof b.mgr_lines === 'string') setSetting('mgr_lines', String(b.mgr_lines).split(',').filter(x => x === 'funnel' || x === 'premium').join(','));
        if (b.id) {
          run('UPDATE agents SET name=?, username=?, comm_per_sale=?, receive=?, role=?, lines=?, auto_acct=?, auto_topup=?, comm_premium=? WHERE id=?', name, username, comm, b.receive ? 1 : 0, role, linesStr, b.auto_acct ? 1 : 0, b.auto_topup ? 1 : 0, commP, num(b.id));
          run('UPDATE agents SET chans=? WHERE id=?', chansStr, num(b.id));
          if ('comm_funnel' in b || role === 'manager') run('UPDATE agents SET comm_funnel=? WHERE id=?', commF, num(b.id)); // v141
          if ('ring_off' in b) run('UPDATE agents SET ring_off=? WHERE id=?', b.ring_off ? 1 : 0, num(b.id)); // v140
          if (password) {
            run('UPDATE agents SET pass_hash=?, session_ver=session_ver+1 WHERE id=?', hashPassword(password), num(b.id));
          }
        } else {
          run('INSERT INTO agents(name, username, pass_hash, comm_per_sale, receive, online, created_at, role, lines, auto_acct, auto_topup, comm_premium) VALUES(?,?,?,?,?,1,?,?,?,?,?,?)', name, username, hashPassword(password), comm, b.receive === false || b.receive === 0 || b.receive === '0' ? 0 : 1, now(), role, linesStr, b.auto_acct ? 1 : 0, b.auto_topup ? 1 : 0, commP);
          run('UPDATE agents SET chans=?, comm_funnel=? WHERE id=(SELECT MAX(id) FROM agents WHERE username=? AND deleted=0)', chansStr, commF, username);
        }
        });
        // v141: receiving leads switched here → covers start / end like the switch on the list (receive was saved above)
        if (b.id && wasOn !== undefined && !!wasOn !== !!b.receive) { run('UPDATE agents SET receive=? WHERE id=?', wasOn, num(b.id)); await setReceive(num(b.id), !!b.receive, 'admin'); }
        return json({ ok: true });
      }
      case 'agent_toggle': return json(await setReceive(num(b.id), !!b.receive, 'admin')); // v141: + covers start / end, auto-off cleared
      // v141: cash / offline payouts (the admin can delete any entry)
      case 'cash_payouts': return json(cashPayouts(num(q('agent')) || null));
      case 'cash_payout_add': return json(addCashPayout(b, { role: 'admin', id: null, name: 'Admin' }));
      case 'cash_payout_del': return json(delCashPayout(b.id, { role: 'admin', id: null, name: 'Admin' }));
      case 'agent_log': return json({ rows: all('SELECT kind, text, lead_id, at FROM agent_log WHERE agent_id=? ORDER BY id DESC LIMIT 100', num(q('id'))) });
      case 'agent_logout': { run('UPDATE agents SET session_ver=session_ver+1 WHERE id=?', num(b.id)); run("DELETE FROM push_tokens WHERE role='agent' AND user_id=?", num(b.id)); return json({ ok: true }); }
      case 'agent_delete': {
        const da = agentById(num(b.id));
        if (!da || da.deleted) return json({ ok: true }); // already gone
        await setReceive(da.id, false, 'admin, agent deleted'); // v166: their waiting customers get a cover now
        run("UPDATE agents SET deleted=1, receive=0, username=username||'#'||id, session_ver=session_ver+1 WHERE id=?", num(b.id));
        run("DELETE FROM push_tokens WHERE role='agent' AND user_id=?", num(b.id));
        await dropAsCover(da.id); // v166: chats they were covering → back to the owner (or a new cover)
        return json({ ok: true });
      }

      // v159: incentive to the agents with receiving leads ON (equal shares, never the manager)
      case 'bonus_info': { const B = await import('@/server/bonus'); return json({ agents: B.bonusAgents(), history: B.bonusHistory() }); }
      case 'bonus_give': return json(await (await import('@/server/bonus')).giveBonus(b, 'Admin'));
      case 'bonus_delete': return json((await import('@/server/bonus')).deleteBonus(b.batch));
      case 'leaderboard': {
        const [f, t] = dayRange(q('range'), s);
        const p = teamProfit(f, t);
        return json(p);
      }

      case 'spend': {
        ensureAutoSpend(s);
        const off = num(s.tz_offset_min) * 60000;
        // v137: the chosen range (same picker as Home); the totals come from Home's own numbers (stats) in the app
        const [rf, rt0] = dayRange(q('range') || '30d', s);
        const fromD = localDate(rf, s), toD = localDate(rt0 - 1, s);
        const rows = all<any>('SELECT * FROM ad_spend WHERE (amount>0 OR auto=1) AND date>=? AND date<=? ORDER BY date DESC, line', fromD, toD).map(x => {
          const f = Date.parse(x.date + 'T00:00:00Z') - off, t = f + 86400000;
          if (String(x.line).startsWith('ch_')) {
            const lx = String(x.line).slice(3);
            const lw = lx === 'funnel' ? "l.line='funnel'" : lx === 'premium' ? "COALESCE(l.line,'agency')='agency' AND l.tier='premium'" : "COALESCE(l.line,'agency')='agency' AND COALESCE(l.tier,'')!='premium'";
            const joins = one<any>("SELECT COUNT(*) n FROM channel_joins WHERE src='ad' AND line_x=? AND requested_at>=? AND requested_at<?", lx, f, t)!.n;
            const lc = one<any>(`SELECT COUNT(*) n FROM leads l WHERE l.source='channel' AND ${lw} AND l.created_at>=? AND l.created_at<?`, f, t)!.n;
            const sl = one<any>(`SELECT COUNT(*) n, COALESCE(SUM(x.amount),0) rev FROM sales x JOIN leads l ON l.id=x.lead_id WHERE l.source='channel' AND ${lw} AND x.created_at>=? AND x.created_at<?`, f, t)!;
            return { ...x, joins, contacts: lc, cpj: joins && x.amount ? money(x.amount / joins) : null, cpc: lc && x.amount ? money(x.amount / lc) : null, leads: 0, sales: sl.n, revenue: money(sl.rev), roi: x.amount ? Math.round((sl.rev - x.amount) / x.amount * 100) : null };
          }
          if (String(x.line).startsWith('wa_')) { // v135: WhatsApp ad pages → WhatsApp chats of that line
            const lx = String(x.line).slice(3);
            const lw = `(l.ch='wa' OR l.tg_chat_id LIKE 'wa:%') AND ${lx === 'funnel' ? "l.line='funnel'" : lx === 'premium' ? "COALESCE(l.line,'agency')!='funnel' AND l.tier='premium'" : "COALESCE(l.line,'agency')!='funnel' AND COALESCE(l.tier,'')!='premium'"}`;
            const l = one<any>(`SELECT COUNT(*) n FROM leads l WHERE COALESCE(l.started_at, l.assigned_at, l.created_at)>=? AND COALESCE(l.started_at, l.assigned_at, l.created_at)<? AND l.status!='merged' AND ${lw}`, f, t)!;
            const sl = one<any>(`SELECT COUNT(*) n, COALESCE(SUM(x.amount),0) rev FROM sales x JOIN leads l ON l.id=x.lead_id WHERE x.created_at>=? AND x.created_at<? AND ${lw}`, f, t)!;
            return { ...x, leads: l.n, sales: sl.n, revenue: money(sl.rev), cpl: l.n ? money(x.amount / l.n) : null, cpa: sl.n ? money(x.amount / sl.n) : null, roi: x.amount ? Math.round((sl.rev - x.amount) / x.amount * 100) : null };
          }
          if (x.line === 'telegram') {
            const subs = one<any>("SELECT COUNT(DISTINCT tg_user) n FROM channel_joins WHERE src='page' AND requested_at>=? AND requested_at<? AND tg_user IS NOT NULL", f, t)!.n;
            return { ...x, subs, cps: subs && x.amount ? money(x.amount / subs) : null, leads: 0, sales: 0, revenue: 0, roi: null };
          }
          const ln = "NOT (COALESCE(l.ch,'')='wa' OR COALESCE(l.tg_chat_id,'') LIKE 'wa:%') AND " + (x.line === 'funnel' ? "l.line='funnel'" : x.line === 'premium' ? "COALESCE(l.line,'agency')!='funnel' AND l.tier='premium'" : "COALESCE(l.line,'agency')!='funnel' AND COALESCE(l.tier,'')!='premium'");
          const l = one<any>(`SELECT COUNT(*) n FROM leads l WHERE COALESCE(l.started_at, l.assigned_at)>=? AND COALESCE(l.started_at, l.assigned_at)<? AND l.status!='merged' AND l.tg_chat_id IS NOT NULL AND ${ln}`, f, t)!;
          const sl = one<any>(`SELECT COUNT(*) n, COALESCE(SUM(x.amount),0) rev FROM sales x LEFT JOIN leads l ON l.id=x.lead_id WHERE x.created_at>=? AND x.created_at<? AND COALESCE(x.wa,0)=0 AND ${ln}`, f, t)!;
          return { ...x, leads: l.n, sales: sl.n, revenue: money(sl.rev), cpl: l.n ? money(x.amount / l.n) : null, cpa: sl.n ? money(x.amount / sl.n) : null, roi: x.amount ? Math.round((sl.rev - x.amount) / x.amount * 100) : null };
        });
        // v137: one row per day that has spend OR sales — the same rules as Home, so the days add up to Home's totals
        const SL = (q('line') === 'agency' || q('line') === 'premium' || q('line') === 'funnel' ? q('line') : 'all') as 'all' | 'agency' | 'premium' | 'funnel';
        const { homeLineSql } = await import('@/server/camps');
        const XS = `(${homeLineSql(SL, 'sales')})`, XT = `(${homeLineSql(SL, 'topups')})`;
        const dayOf = (col: string) => `strftime('%Y-%m-%d', (${col} + ${num(s.tz_offset_min) * 60000}) / 1000, 'unixepoch')`;
        const map = new Map<string, any>();
        const D = (d: string) => { let x = map.get(d); if (!x) { x = { date: d, spend: 0, spend_rows: 0, messaged: 0, sales: 0, revenue: 0, fees: 0, commission: 0, acct_cost: 0, web: 0, web_fee: 0, attributed: 0 }; map.set(d, x); } return x; };
        const spendLines = SL === 'all' ? null : [SL, 'wa_' + SL];
        for (const x of all<{ date: string; v: number; n: number }>(`SELECT date, SUM(amount) v, COUNT(*) n FROM ad_spend WHERE date>=? AND date<=?${spendLines ? ' AND line IN (?,?)' : ''} GROUP BY date`, fromD, toD, ...(spendLines || []))) { const d = D(x.date); d.spend = money(x.v); d.spend_rows = x.n; }
        for (const x of all<{ d: string; n: number; rev: number; c: number; cost: number }>(`SELECT ${dayOf('created_at')} d, COUNT(*) n, SUM(amount) rev, SUM(commission) c, SUM(${costSql(s)}) cost FROM sales WHERE created_at>=? AND created_at<? AND ${XS} GROUP BY d`, rf, rt0)) Object.assign(D(x.d), { sales: x.n, revenue: money(x.rev), commission: money(x.c), acct_cost: money(x.cost) });
        for (const x of all<{ d: string; c: number }>(`SELECT ${dayOf('created_at')} d, SUM(commission) c FROM topups WHERE created_at>=? AND created_at<? AND ${XT} GROUP BY d`, rf, rt0)) D(x.d).fees = money(x.c);
        const NCL = SL === 'funnel' ? "line='funnel'" : SL === 'agency' ? "COALESCE(line,'agency')!='funnel' AND COALESCE(tier,'')!='premium'" : SL === 'premium' ? "COALESCE(line,'agency')!='funnel' AND tier='premium'" : '1=1';
        for (const x of all<{ d: string; n: number }>(`SELECT ${dayOf('started_at')} d, COUNT(*) n FROM leads WHERE started_at>=? AND started_at<? AND status!='merged' AND COALESCE(source,'')!='channel' AND ${NCL} GROUP BY d`, rf, rt0)) D(x.d).messaged = x.n;
        if (SL !== 'funnel') {
          const WT = SL === 'premium' ? " AND tier='premium'" : SL === 'agency' ? " AND COALESCE(tier,'')!='premium'" : '';
          for (const x of all<{ d: string; v: number; q: number }>(`SELECT ${dayOf('delivered_at')} d, SUM(amount) v, SUM(CASE WHEN kind='account' THEN qty ELSE 0 END) q FROM web_orders WHERE status='delivered' AND delivered_at>=? AND delivered_at<?${WT} GROUP BY d`, rf, rt0)) { const d = D(x.d); d.web = money(x.v); d.acct_cost = money(d.acct_cost + x.q * num(s.acct_cost, 3)); }
          if (SL !== 'premium') for (const x of all<{ d: string; f: number }>(`SELECT ${dayOf('done_at')} d, SUM(fee) f FROM web_topups WHERE status='done' AND done_at>=? AND done_at<? GROUP BY d`, rf, rt0)) D(x.d).web_fee = money(x.f);
        }
        // v159: incentives to agents (whole team view only)
        if (SL === 'all') for (const x of all<{ d: string; v: number }>(`SELECT ${dayOf('created_at')} d, SUM(amount) v FROM agent_bonus WHERE created_at>=? AND created_at<? GROUP BY d`, rf, rt0)) D(x.d).bonus = money(x.v);
        // v156: replacement accounts (cost only)
        try { for (const x of all<{ d: string; c: number }>(`SELECT ${dayOf('r.created_at')} d, SUM(r.cost) c FROM meta_replacements r LEFT JOIN leads l ON l.id=r.lead_id WHERE r.created_at>=? AND r.created_at<?${replLineSql(SL)} GROUP BY d`, rf, rt0)) { /* v166: same line rule as Home (replCost) */ const d = D(x.d); d.acct_cost = money(d.acct_cost + x.c); } } catch { /* */ }
        // revenue the line rows above could tie to a line / ad page (the rest = "Unattributed", so the day always adds up)
        for (const x of rows) if (map.has(x.date)) map.get(x.date).attributed = money(map.get(x.date).attributed + (Number(x.revenue) || 0));
        const days = [...map.values()].filter(d => d.spend || d.sales || d.fees || d.web || d.messaged || d.bonus).map(d => {
          const profit = money(d.revenue + d.fees + d.web + d.web_fee - d.spend - d.commission - d.acct_cost); // v162: incentive not taken off
          return { ...d, profit, roi: d.spend ? Math.round(profit / d.spend * 100) : null, unattributed: money(Math.max(0, d.revenue - d.attributed)), no_spend: !d.spend_rows };
        }).sort((a, b) => b.date.localeCompare(a.date));
        return json({ rows, days, range: q('range') || '30d', wa_ads_on: s.wa_ads_on === '1' || s.wa_comm_ads_on === '1', today: localDate(now(), s), budget_agency: s.ad_budget_agency, budget_funnel: s.ad_budget_funnel, budget_telegram: s.ad_budget_telegram, budget_ch_agency: s.ad_budget_ch_agency, budget_ch_premium: s.ad_budget_ch_premium, budget_ch_funnel: s.ad_budget_ch_funnel, budget_wa_agency: s.ad_budget_wa_agency, budget_wa_premium: s.ad_budget_wa_premium, budget_wa_funnel: s.ad_budget_wa_funnel, budget_premium: s.premium_ad_budget, rt_agency: s.rt_budget_agency, rt_premium: s.rt_budget_premium, rt_funnel: s.rt_budget_funnel, acct_cost: s.acct_cost, meta_since: MA.metaOn(s) ? MA.metaSince(s) : null });
      }
      case 'spend_save': {
        if (!/^\d{4}-\d{2}-\d{2}$/.test(String(b.date || ''))) throw new HttpError(400, 'Pick a date');
        const line = spendLine(b.line);
        const amt = money(b.amount);
        if (!(amt >= 0) || b.amount === '' || b.amount == null) throw new HttpError(400, 'Enter the amount spent in USD');
        if (MA.isMetaDay(String(b.date), s) || MA.hasMetaRow(String(b.date), line)) { MA.saveExtra(String(b.date), line, amt, String(b.note || '').slice(0, 100)); return json({ ok: true, extra: true }); } // v151: Meta day → other ad account money
        run('INSERT INTO ad_spend(date, line, amount, note, auto) VALUES(?,?,?,?,0) ON CONFLICT(date, line) DO UPDATE SET amount=excluded.amount, note=excluded.note, auto=0', b.date, line, amt, String(b.note || '').slice(0, 100));
        return json({ ok: true });
      }
      // kept as a $0 row so the daily budget doesn't add that day again
      case 'spend_delete': { if (MA.isMetaDay(String(b.date), s) || MA.hasMetaRow(String(b.date), spendLine(b.line))) { MA.saveExtra(String(b.date), spendLine(b.line), 0, ''); return json({ ok: true }); }
        run("INSERT INTO ad_spend(date, line, amount, note, auto) VALUES(?,?,0,'',0) ON CONFLICT(date, line) DO UPDATE SET amount=0, note='', auto=0", String(b.date), spendLine(b.line)); return json({ ok: true }); }

      case 'payouts': return json({ rows: all("SELECT p.*, a.name agent_name FROM payouts p LEFT JOIN agents a ON a.id=p.agent_id ORDER BY (p.status='pending') DESC, p.id DESC LIMIT 500") });
      case 'payout_update': {
        const st = b.status === 'paid' ? 'paid' : 'rejected';
        const r = run("UPDATE payouts SET status=?, note=?, done_at=? WHERE id=? AND status='pending'", st, String(b.note || '').slice(0, 200), now(), num(b.id));
        if (!r.changes) throw new HttpError(400, 'This request was already handled');
        const p = one<any>('SELECT * FROM payouts WHERE id=?', num(b.id))!;
        const ag = agentById(p.agent_id);
        const msg = st === 'paid' ? `✅ Payout of $${p.amount} marked as paid.${p.note ? '\nNote: ' + p.note : ''}` : `❌ Payout request of $${p.amount} was rejected.${p.note ? '\nReason: ' + p.note : ''}`;
        if (ag) { await notifyAgent(ag, msg, null, { title: st === 'paid' ? 'Payout paid' : 'Payout rejected', body: `$${p.amount}${p.note ? ' · ' + p.note : ''}` }); }
        return json({ ok: true });
      }

      case 'offer_stats': {
        // Retargeting offers: chats tagged with an offer (came from a ?rt=1 ad) per line, sales at the offer price, what the offer cost us
        const days = Math.max(1, Math.min(90, num(q('days'), 7)));
        // v136: Home → ?range= (same as the rest of Home); ?days= still works
        const [from, to] = q('range') ? dayRange(q('range'), s) : [now() - days * 86400000, now() + 60000];
        const RW: Record<string, string> = {
          agency: "COALESCE(l.biz,'agency')='agency' AND COALESCE(l.tier,'')!='premium'",
          premium: "COALESCE(l.biz,'agency')='agency' AND l.tier='premium'",
          funnel: "l.biz='funnel'",
        };
        const pct = num(tierFor(s, 'premium').topup_comm_pct, 3);
        const rows = Object.fromEntries(Object.entries(RW).map(([k, w]) => {
          const L = one<{ n: number; c: number }>(`SELECT COUNT(*) n, SUM(CASE WHEN l.tg_chat_id IS NOT NULL THEN 1 ELSE 0 END) c FROM leads l WHERE l.offer_until IS NOT NULL AND l.status!='merged' AND l.created_at>=? AND l.created_at<? AND ${w}`, from, to)!;
          const S = one<{ n: number; v: number; q: number; o: number }>(`SELECT COUNT(DISTINCT x.lead_id) n, COALESCE(SUM(x.amount),0) v, COALESCE(SUM(x.qty),0) q, SUM(CASE WHEN x.offer=1 THEN 1 ELSE 0 END) o FROM sales x JOIN leads l ON l.id=x.lead_id WHERE l.offer_until IS NOT NULL AND x.created_at>=? AND x.created_at<? AND ${w}`, from, to)!;
          const T = one<{ f: number; n: number }>(`SELECT COALESCE(SUM(t.offer_free),0) f, COUNT(t.offer_free) n FROM topups t JOIN leads l ON l.id=t.lead_id WHERE t.created_at>=? AND t.created_at<? AND ${w}`, from, to)!;
          const off = one<{ d: number }>(`SELECT COALESCE(SUM(x.amount),0) d FROM sales x JOIN leads l ON l.id=x.lead_id WHERE x.offer=1 AND x.created_at>=? AND x.created_at<? AND ${w}`, from, to)!;
          const offQ = one<{ q: number; fq: number }>(`SELECT COALESCE(SUM(CASE WHEN x.service='account' THEN x.qty END),0) q, COALESCE(SUM(CASE WHEN x.service='funnel' THEN 1 END),0) fq FROM sales x JOIN leads l ON l.id=x.lead_id WHERE x.offer=1 AND x.created_at>=? AND x.created_at<? AND ${w}`, from, to)!;
          // what the offer cost: (normal price − offer price) on offer sales, or the waived Premium top-up fee
          const normal = offQ.q * num(s.price_account) + offQ.fq * num(s.price_funnel);
          const cost = k === 'premium' ? money(T.f * pct / 100) : money(Math.max(0, normal - off.d));
          return [k, { leads: L.n, chats: L.c || 0, sales: S.n, revenue: money(S.v), offer_sales: S.o || 0, free_topups: T.n, cost }];
        }));
        const web = one<{ n: number; v: number }>("SELECT COUNT(*) n, COALESCE(SUM(amount),0) v FROM web_orders WHERE offer='1' AND status IN ('paid','delivered','done') AND created_at>=? AND created_at<?", from, to)!;
        return json({ days, on: s.offer_on === '1', rows, web: { orders: web.n, revenue: money(web.v) } });
      }
      case 'sale_history': return json((await import('@/server/salehist')).saleHistory({ range: q('range'), kind: q('kind'), who: q('who'), line: q('line') })); // v124
      case 'ch_report': { const [f, t] = dayRange(q('range'), s); return json({ ...(await import('@/server/chreport')).channelReport(f, t), wa_ads_on: s.wa_ads_on === '1' || s.wa_comm_ads_on === '1' }); } // v135 Telegram vs WhatsApp (v137: WA ad pages only when running)
      case 'bot_stats': { // v120: Home → 🤖 Bot tab
        const [f, t] = dayRange(q('range'), s);
        return json((await import('@/server/chanads')).botStats(f, t));
      }
      case 'chan_stats': {
        const days = Math.max(1, Math.min(90, num(q('days'), 7)));
        const CA = await import('@/server/chanads');
        const [cf, ct] = q('range') ? dayRange(q('range'), s) : [now() - days * 86400000, now() + 60000]; // v136: ?range=
        return json({ ...CA.chanStats(cf, ct), bot: s.bot_username || '', menu_link: CA.botLink(s, 'ch') });
      }
      case 'premium_stats': {
        ensureAutoSpend(s);
        // Premium (/premium) vs Standard (main agency page): leads, chats, sales, revenue over the last N days
        const days = Math.max(1, Math.min(90, num(q('days'), 7)));
        const [from, to] = q('range') ? dayRange(q('range'), s) : [now() - days * 86400000, now() + 60000]; // v136: ?range=
        const prem = tierFor(s, 'premium');
        const one_ = (tier: '' | 'premium') => {
          const lw = "COALESCE(l.line,'agency')='agency' AND COALESCE(l.service,'account')!='funnel' AND COALESCE(l.tier,'')=?";
          const leads = one<{ n: number; c: number }>(`SELECT COUNT(*) n, SUM(CASE WHEN l.started_at IS NOT NULL OR l.tg_chat_id IS NOT NULL THEN 1 ELSE 0 END) c FROM leads l WHERE l.source='form' AND l.status!='merged' AND l.created_at>=? AND l.created_at<? AND ${lw}`, from, to, tier)!;
          const sold = one<{ n: number; v: number }>(`SELECT COUNT(DISTINCT x.lead_id) n, COALESCE(SUM(x.amount),0) v FROM sales x JOIN leads l ON l.id=x.lead_id WHERE x.created_at>=? AND x.created_at<? AND ${lw}`, from, to, tier)!;
          const web = one<{ n: number; v: number }>("SELECT COUNT(*) n, COALESCE(SUM(amount),0) v FROM web_orders WHERE kind='account' AND status IN ('paid','delivered','done') AND created_at>=? AND created_at<? AND COALESCE(tier,'')=?", from, to, tier)!;
          const spendSum = one<{ v: number }>('SELECT COALESCE(SUM(amount),0) v FROM ad_spend WHERE line=? AND date>=? AND date<=?', tier ? 'premium' : 'agency', localDate(from, s), localDate(to - 1, s))!.v;
          const p = tier ? prem : s;
          return { leads: leads.n, chats: leads.c || 0, sales: sold.n + web.n, revenue: money(sold.v + web.v), spend: money(spendSum), price: num(p.price_account), price_web: num(p.price_account_web) };
        };
        return json({ days, standard: one_(''), premium: one_('premium') });
      }
      case 'capi': {
        // v137: range + filters (source / event / status / pixel) for the list; the summary grid and the reasons
        const C = await import('@/server/capi');
        C.backfillCapiSource();
        const [f, t] = dayRange(q('range') || 'today', s);
        const px = q('pixel') || '';
        const PX = px === 'agency' || px === 'funnel' ? ` AND COALESCE(line,'agency')='${px}'` : px === 'wa' ? " AND line LIKE 'wa_%'" : '';
        const w = `created_at>=? AND created_at<?${PX}`;
        const grid = all<{ source: string; ev: string; status: string; n: number }>(`SELECT COALESCE(source,'other') source, event_name ev, status, COUNT(*) n FROM capi_log WHERE ${w} GROUP BY 1,2,3`, f, t);
        const PIX = (l: string | null) => (String(l || 'agency').startsWith('wa_') ? (l === 'wa_funnel' ? 'WhatsApp Funnel pixel' : 'WhatsApp Agency pixel') : l === 'funnel' ? 'Funnel pixel' : 'Agency pixel');
        const SEC = (l: string | null) => (String(l || '').startsWith('wa_') ? 'wati' : 'meta');
        const reasons = all<{ response: string; source: string; line: string; status: string; n: number; last: number }>(`SELECT COALESCE(response,'') response, COALESCE(source,'other') source, COALESCE(line,'agency') line, status, COUNT(*) n, MAX(created_at) last FROM capi_log WHERE ${w} AND status NOT IN ('sent','pending') GROUP BY 1,2,3,4 ORDER BY n DESC LIMIT 50`, f, t)
          .map(r => ({ ...r, reason: r.status === 'dup' ? 'Already sent for this person (one per person)' : r.response.replace(/^Not sent: /, '').slice(0, 160) || r.status, pixel: PIX(r.line), sec: r.status === 'dup' ? null : SEC(r.line) }));
        const fs = [q('source'), q('event'), q('status')];
        const lw = `${w}${fs[0] ? ' AND COALESCE(source,\'other\')=?' : ''}${fs[1] ? ' AND event_name=?' : ''}${fs[2] ? ' AND status=?' : ''}`;
        return json({ test_code: s.test_event_code, f_test_code: s.f_test_event_code, sources: C.CAPI_SOURCES, grid, reasons,
          rows: all(`SELECT event_id, event_name, lead_id, status, response, tries, created_at, COALESCE(line,'agency') line, COALESCE(source,'other') source FROM capi_log WHERE ${lw} ORDER BY created_at DESC LIMIT 300`, f, t, ...fs.filter(Boolean)) });
      }
      case 'chan_check': return json(await checkChannel());
      case 'fu_health': return json((await import('@/server/crm')).fuHealth());
      case 'chan_approve_all': setSetting('chan_approve_req', '1'); return json({ ok: true });
      case 'capi_test': {
        const line = b.line === 'funnel' ? 'funnel' : 'agency';
        const ev = ['Lead', 'Purchase', 'Subscribe'].includes(b.event) ? String(b.event) : 'ViewContent';
        const value = num(line === 'funnel' ? s.price_funnel : s.price_account);
        // test event code typed on the Meta events page: used for this one test only (empty = a real event, no test code)
        const code = 'test_code' in b ? String(b.test_code || '').trim().slice(0, 40) : null;
        const sx = code === null ? s : { ...s, test_event_code: code, f_test_event_code: code };
        const r = await sendCapi(sx, {
          line, event_id: `test_${ev.toLowerCase()}_${now()}`, event_name: ev, source_url: baseUrl(req) + (line === 'funnel' ? '/funnel' : '/'),
          // browser id + visitor id + country too, so test events don't pull the match quality down
          user_data: buildUserData({ ip: clientIp(req), ua: req.headers.get('user-agent') || '', fbp: clickIds(req).fbp, vid: 'admin_test' }, s),
          custom_data: ev === 'Purchase' ? { content_name: 'Admin test', value, currency: 'USD', num_items: 1 } : { content_name: 'Admin test' },
        });
        return json({ ok: 'status' in r && r.status === 'sent', event: ev, result: r });
      }

      case 'ub_send_code': return json(await ubSendCode(b.api_id, b.api_hash, b.phone));
      case 'ub_sign_in': return json(await ubSignIn(b.code, b.password));
      case 'ub_logout': { ubLogout(); return json({ ok: true }); }
      // v143: Resume ends the spam-limit pause, but the backlog goes on at the normal sending speed (never all at once)
      case 'ub_resume': { setSetting('ub_pause_until', '0'); const r = (await import('@/server/pace')).paceResume(); setSetting('ub_status', 'Resumed — the waiting messages go out slowly at the normal sending speed'); return json({ ok: true, ...r }); }
      case 'ub_info': {
        const day = Date.now() - 86400000;
        const st = (x: string) => one<{ n: number }>('SELECT COUNT(*) n FROM leads WHERE contact_state=? AND contact_at>?', x, day)!.n;
        return json({
          logged_in: !!s.ub_session, me: s.ub_me, status: s.ub_status, folders_status: s.folders_status, paused_until: num(s.ub_pause_until) > Date.now() && num(s.ub_pause_until) < 9e15 ? num(s.ub_pause_until) : 0,
          pace: (await import('@/server/pace')).paceStatus(), // v143: spam-limit pause (stop_until), stranger first-message pause, queue
          last24: { sent: st('sent'), not_found: st('not_found'), failed: st('failed'),
            replied: one<{ n: number }>("SELECT COUNT(*) n FROM leads WHERE contact_state='sent' AND contact_at>? AND started_at IS NOT NULL", day)!.n },
          waiting: one<{ n: number }>("SELECT COUNT(*) n FROM leads WHERE source='form' AND tg_chat_id IS NULL AND status='new' AND COALESCE(contact_state,'')='' AND created_at>?", day)!.n,
        });
      }
      case 'push_test': return json(await (await import('@/server/push')).pushTest(num(b.agent_id) || null, { text: b.text, to: b.to, only: b.only })); // v135 (v137: own text + who)
      case 'ring_reports': return json({ reports: (await import('@/server/push')).ringReports(num(q('since'))) }); // v137
      case 'ring_people': return json({ people: (await import('@/server/push')).ringPeople(), global: s.alarm_on !== '0' }); // v140: Ring for each person
      case 'push_phones': return json({ phones: (await import('@/server/push')).pushPhones() }); // v139: Phones registered
      case 'notif_sound_sync': return json(await (await import('@/server/push')).pushSoundSync(b.to)); // v137: "Send sound to all phones"
      case 'sound_sync_status': return json((await import('@/server/push')).soundSyncStatus(num(q('since')), String(q('ver') || ''), q('to') || 'all')); // v137
      case 'notif_sound': {
        const form = await req.formData();
        const f = form.get('file');
        if (form.get('remove') === '1') { await saveNotifSound(null); return json({ ok: true }); }
        if (!f || typeof f === 'string') throw new HttpError(400, 'Choose a sound file');
        await saveNotifSound(f);
        // v137: phones download it now (the test box runs its own sync for the phones it picked: nosync=1)
        const sync = form.get('nosync') === '1' ? null : await (await import('@/server/push')).pushSoundSync().catch(() => null);
        return json({ ok: true, ver: getSettings().notif_sound_ver, sync });
      }
      case 'logo': {
        const form = await req.formData();
        const f = form.get('file');
        if (form.get('remove') === '1') { await saveLogo(null); return json({ ok: true }); }
        if (!f || typeof f === 'string') throw new HttpError(400, 'Choose an image');
        await saveLogo(f);
        return json({ ok: true, ver: getSettings().logo_ver });
      }
      case 'settings': {
        const out: Record<string, string> = { ...s };
        for (const k of SECRET_KEYS) out[k] = s[k] ? (k === 'fcm_service_account' ? '•••••• (saved)' : '••••••' + s[k].slice(-4)) : '';
        for (const k of ['admin_pass_hash', 'rr_last', 'biz_conn_id', 'owner_id', 'ub_session']) delete out[k];
        for (const k of Object.keys(out)) if (/^(ai|el)_/.test(k)) delete out[k]; // AI settings live in Admin → AI
        return json({ settings: out, themes: THEMES, base_url: baseUrl(req), business: { connected: !!s.biz_conn_id, owner_username: s.owner_username, owner_name: s.owner_name } });
      }
      case 'np_coins': return json({ coins: await npAllCoins(s) });
      case 'settings_save': {
        const oldBot = s.bot_token;
        const put: [SettingKey, string][] = []; // v166: every field is checked first, then all are saved together
        for (const k of Object.keys(DEFAULTS) as SettingKey[]) {
          if (AUTO_KEYS.includes(k) || !(k in b) || /^(ai|el)_/.test(k)) continue;
          let v = String(b[k] ?? '').trim();
          if (SECRET_KEYS.includes(k) && (v.startsWith('••') || v === '')) { if (b['clear_' + k] === true) put.push([k, '']); continue; }
          if (k === 'owner_username') v = v.replace(/^https?:\/\/t\.me\//i, '').replace(/^@/, '').replace(/[^A-Za-z0-9_]/g, '');
          if (k === 'theme' && !(THEMES as readonly string[]).includes(v)) continue;
          if (k === 'wati_btn_replies' && v) { try { v = JSON.stringify((await import('@/server/btnreplies')).cleanReplies(JSON.parse(v))); } catch { throw new HttpError(400, 'Button replies could not be read — reload the page and try again'); } }
          if (k === 'np_coin_meta') v = v ? JSON.stringify(coinMeta({ np_coin_meta: v })) : '';
          if (k === 'np_currencies') v = [...new Set(v.toLowerCase().split(/[,\s]+/).map(x => x.replace(/[^a-z0-9]/g, '')).filter(Boolean))].join(',');
          if (k === 'fcm_service_account') { try { const j = JSON.parse(v); if (!j.client_email || !j.private_key || !j.project_id) throw 0; } catch { throw new HttpError(400, 'Firebase key must be the full service-account JSON file content'); } }
          if (k === 'fu_hours' && !/^\s*\d+(\.\d+)?\s*,\s*\d+(\.\d+)?\s*,\s*\d+(\.\d+)?\s*$/.test(v)) throw new HttpError(400, 'Follow-up gaps must be three numbers like 12,24,24');
          if (k === 'work_hours' && v && !/^\s*\d{1,2}\s*-\s*\d{1,2}\s*$/.test(v)) throw new HttpError(400, 'Working hours must look like 9-22');
          if (k === 'reassign_min' && !(parseFloat(v) >= 5)) throw new HttpError(400, 'Reply time must be at least 5 minutes');
          if (k === 'cover_quiet_h' && !(parseFloat(v) >= 1 && parseFloat(v) <= 720)) throw new HttpError(400, 'Quiet hours must be 1 to 720');
          if (k === 'cover_max_days' && !(parseFloat(v) >= 1 && parseFloat(v) <= 60)) throw new HttpError(400, 'Cover limit must be 1 to 60 days');
          if (k === 'cover_credit_days' && !(parseFloat(v) >= 0 && parseFloat(v) <= 60)) throw new HttpError(400, 'Credit days must be 0 to 60');
          if (k === 'chan_sub_delay_min' && !(Number(v) >= 0 && Number(v) <= 1440)) throw new HttpError(400, 'Stay time must be 0 to 1440 minutes');
          if (k === 'chan_pick_event' && !['Contact', 'Lead', 'off'].includes(v)) throw new HttpError(400, 'Pick Contact, Lead or Off');
          if (/^chan_img_/.test(k) && v && !/^https:\/\/\S+$/.test(v)) throw new HttpError(400, 'Bot image must be an https:// link to a .jpg / .png (or leave it empty for the built-in one)');
          if (/^pace_/.test(k) && k !== 'pace_on' && !(parseFloat(v) >= 0 && parseFloat(v) <= 100000)) throw new HttpError(400, `${k.replace(/_/g, ' ')} must be a number (0 or more)`);
          if (k === 'quiet_hours' && v && !/^\s*\d{1,2}\s*-\s*\d{1,2}\s*$/.test(v)) throw new HttpError(400, 'Quiet hours must look like 22-9');
          if (k === 'tz_offset_min' && !(/^-?\d{1,4}$/.test(v) && Number(v) >= -720 && Number(v) <= 840)) throw new HttpError(400, 'Time zone offset must be minutes from UTC, -720 to 840 (India = 330)'); // v166: west of UTC too
          if (['price_account', 'price_funnel', 'topup_comm_pct', 'auto_msg_delay_min', 'auto_msg_hour_cap', 'welcome_delay_sec', 'dead_hours', 'pay_window_min', 'reassign_min', 'meta_sync_min', 'meta_low_usd', 'meta_lock_usd', 'acct_cost', 'ad_budget_agency', 'ad_budget_funnel', 'ad_budget_telegram', 'ad_budget_ch_agency', 'ad_budget_ch_premium', 'ad_budget_ch_funnel', 'ad_budget_wa_agency', 'ad_budget_wa_premium', 'ad_budget_wa_funnel', 'price_premium', 'price_premium_web', 'premium_topup_pct', 'premium_ad_budget', 'rt_budget_agency', 'rt_budget_premium', 'rt_budget_funnel', 'offer_agency_price', 'offer_funnel_price', 'offer_premium_free', 'offer_days'].includes(k) && !(parseFloat(v) >= 0)) throw new HttpError(400, `${k.replace(/_/g, ' ')} must be a number`);
          put.push([k, v]);
        }
        tx(() => { for (const [k, v] of put) setSetting(k, v); });
        const ns = getSettings();
        // v137: Default ↔ our own sound switched → the phones get the change now (silent sync push)
        if ((ns.notif_sound === 'own') !== (s.notif_sound === 'own')) void import('@/server/push').then(p => p.pushSoundSync()).catch(() => null);
        const webhook = ns.bot_token && (ns.bot_token !== oldBot || b.reconnect) ? await setupWebhook(ns, baseUrl(req)) : null;
        return json({ ok: true, webhook });
      }
      case 'webhook': {
        const r = await setupWebhook(s, baseUrl(req));
        const info = await tg(getSettings(), 'getWebhookInfo', {});
        return json({ ...r, info: info.result || null });
      }
      case 'password': {
        if (!checkAdminLogin(process.env.ADMIN_USERNAME || 'admin', String(b.current || ''))) throw new HttpError(400, 'Current password is wrong');
        if (String(b.next || '').length < 8) throw new HttpError(400, 'New password must be at least 8 characters');
        setSetting('admin_pass_hash', hashPassword(String(b.next)));
        const token = makeToken({ r: 'admin', id: 0, v: adminVersion() }, 30);
        return json({ ok: true, token }, 200, { 'set-cookie': cookieHeader('af_admin', token, 30) });
      }
      case 'push_register': return json(registerToken('admin', 0, String(b.token || ''), String(b.platform || 'android'), { native: b.native === 1 || b.native === true, app_version: b.app_version, device: b.device })); // v139
      case 'push_seen': return json((await import('@/server/push')).noteSeen('admin', 0, (b || {}) as Record<string, unknown>, req.headers.get('user-agent') || '')); // v143: app opened (version)
      case 'push_debug': return json((await import('@/server/push')).savePushDebug('admin', 0, (b || {}) as Record<string, unknown>)); // v139
      // v139: a login token for the phone's own (Java) calls — push_register / push_report work without the WebView cookie
      case 'native_auth': return json({ token: makeToken({ r: 'admin', id: 0, v: adminVersion() }, 30), role: 'admin' });
      case 'push_report': return json((await import('@/server/push')).saveRingReport('admin', 0, (b || {}) as Record<string, unknown>)); // v137: what the phone played
      // v166: the 2nd 'push_test' case (never reached) was removed — pushTest() above also sends to the admin's phones
    }
    return json({ error: 'Not found' }, 404);
  } catch (e) { return fail(e, !!getAdmin(req)); }
}

/** v137: a CSV file → its columns, the number of rows and the first `limit` rows (quotes handled). */
function parseCsv(text: string) {
  const rows: string[][] = []; let row: string[] = [], cell = '', q = false;
  const t = text.replace(/^\uFEFF/, '');
  for (let i = 0; i < t.length; i++) {
    const ch = t[i];
    if (q) { if (ch === '"') { if (t[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += ch; continue; }
    if (ch === '"') q = true; else if (ch === ',') { row.push(cell); cell = ''; } else if (ch === '\n') { row.push(cell); rows.push(row); row = []; cell = ''; } else if (ch !== '\r') cell += ch;
  }
  if (cell || row.length) { row.push(cell); rows.push(row); }
  return rows;
}
async function exportPreview(kind: string, range: string | null, type: string | null, line: string | null, limit: number) {
  const r = exportCsv(kind, range, type, line);
  if (r.status !== 200 || !/text\/csv/.test(r.headers.get('content-type') || '')) throw new HttpError(404, 'Unknown export');
  const all0 = parseCsv(await r.text());
  const cols = all0[0] || [], rows = all0.slice(1).filter(x => x.length > 1 || x[0] !== '');
  return { kind, cols, total: rows.length, rows: rows.slice(0, limit), hashed: kind === 'meta_purchases.csv' || kind === 'audience.csv' || kind === 'channel_audience.csv' };
}
function exportCsv(kind: string, range: string | null, type: string | null, line: string | null) {
  const s = getSettings();
  // v137: meta/<app>/<file>.csv — the Meta-ready files (hashed)
  const mm = kind.match(/^meta\/(all|tg_chat|tg_channel|wa|web)\/(buyers|people|nonbuyers|purchases|wa_community|wa_taps|ch_nomsg|ch_left|ch_info_nomsg)\.csv$/);
  if (mm) {
    const fl = metaFileSync(mm[1] as never, mm[2] as never, range, line);
    const name = `meta_${mm[1]}_${mm[2]}${line && line !== 'all' ? '_' + line : ''}.csv`;
    return new Response('\uFEFF' + csvOfSync(fl.cols, fl.rows), { headers: { 'content-type': 'text/csv; charset=utf-8', 'content-disposition': `attachment; filename="${name}"`, 'cache-control': 'no-store' } });
  }
  const [f, t] = dayRange(range || 'all', s);
  // ?line= agency (normal) · premium · funnel · (empty = everyone)
  const ln = line === 'agency' || line === 'premium' || line === 'funnel' ? line : '';
  const LW = (a: string) => (ln === 'funnel' ? ` AND ${a}.line='funnel'` : ln === 'premium' ? ` AND COALESCE(${a}.line,'agency')!='funnel' AND ${a}.tier='premium'` : ln === 'agency' ? ` AND COALESCE(${a}.line,'agency')!='funnel' AND COALESCE(${a}.tier,'')!='premium'` : '');
  const file = (body: string, name0: string) => { const name = ln ? name0.replace(/\.csv$/, `_${ln}.csv`) : name0; return new Response('﻿' + body, { headers: { 'content-type': 'text/csv; charset=utf-8', 'content-disposition': `attachment; filename="${name}"`, 'cache-control': 'no-store' } }); };
  if (kind === 'leads.csv') {
    const rows = all<any>("SELECT l.*, a.name agent_name, (SELECT COALESCE(SUM(amount),0) FROM sales WHERE lead_id=l.id) revenue, (SELECT COALESCE(SUM(amount),0) FROM topups WHERE lead_id=l.id) topups FROM leads l LEFT JOIN agents a ON a.id=l.agent_id WHERE l.created_at>=? AND l.created_at<? AND l.status!='merged'" + LW('l') + " ORDER BY l.id", f, t);
    const cols = ['id', 'line', 'tier', 'source', 'theme', 'name', 'phone', 'email', 'service', 'has_bm', 'niche', 'budget', 'tg_username', 'agent_name', 'status', 'revenue', 'topups', 'created_at', 'started_at', 'sold_at'];
    return file([cols.join(','), ...rows.map(x => cols.map(c => csvq(/_at$/.test(c) && x[c] ? new Date(x[c]).toISOString() : x[c])).join(','))].join('\n'), 'leads.csv');
  }
  // v118: people from the channel ads (and anyone who asked to join): what we know and send to Meta — no names are collected there
  if (kind === 'channel_people.csv' || kind === 'channel_audience.csv') {
    const lx = ln ? ` AND COALESCE(j.line_x, j.line)=?` : '';
    const rows = all<any>(`SELECT j.*, b.name bot_name, l.id lead_id, l.name lead_name, l.tg_username, l.status lead_status, l.tier lead_tier,
        (SELECT COUNT(*) FROM sales x WHERE x.lead_id=l.id) sales_n, (SELECT COALESCE(SUM(amount),0) FROM sales x WHERE x.lead_id=l.id) revenue
      FROM channel_joins j LEFT JOIN bot_subs b ON b.tg_user=j.tg_user
      LEFT JOIN leads l ON l.id=(SELECT id FROM leads WHERE tg_chat_id=j.tg_user AND status!='merged' ORDER BY id DESC LIMIT 1)
      WHERE j.tg_user IS NOT NULL AND j.requested_at>=? AND j.requested_at<?${lx} ORDER BY j.id`, f, t, ...(ln ? [ln] : []));
    if (kind === 'channel_audience.csv') {
      // Meta customer list: the same hashed external_id / ids Meta got with Subscribe (one row per person)
      const seen = new Set<string>(); const out = ['extern_id'];
      for (const x of rows) { if (seen.has(x.tg_user)) continue; seen.add(x.tg_user); const u: any = buildUserData({ vid: x.vid, ip: x.ip, ua: x.ua, fbc: x.fbc, fbp: x.fbp }, s); if (u.external_id?.[0]) out.push(csvq(u.external_id[0])); }
      return file(out.join('\n'), 'channel_audience.csv');
    }
    const iso = (v: number | null) => (v ? new Date(v).toISOString() : '');
    const cols = ['telegram_id', 'name', 'username', 'page', 'came_from', 'asked_to_join', 'joined', 'left', 'still_in', 'subscribe_sent', 'messaged_us', 'lead_status', 'sales', 'revenue', 'ip', 'user_agent', 'fbc', 'fbp', 'visitor_id', 'page_url'];
    const out = [cols.join(',')];
    for (const x of rows) out.push([x.tg_user, x.lead_name || x.bot_name || '', x.tg_username || '', x.line_x || x.line || '', x.src || '', iso(x.requested_at), iso(x.joined_at), iso(x.left_at), x.joined_at && !x.left_at ? 'yes' : 'no', x.sub_at ? 'yes' : 'no', x.lead_id ? 'yes' : 'no', x.lead_status || '', x.sales_n || 0, x.revenue || 0, x.ip || '', x.ua || '', x.fbc || '', x.fbp || '', x.vid || '', x.page_url || ''].map(csvq).join(','));
    return file(out.join('\n'), 'channel_people.csv');
  }
  if (kind === 'meta_purchases.csv') {
    const rows = all<any>('SELECT s.id sid, s.amount, s.created_at sat, l.* FROM sales s JOIN leads l ON l.id=s.lead_id WHERE s.created_at>=? AND s.created_at<?' + LW('l') + ' ORDER BY s.id', f, t);
    const out = ['email,phone,fn,ln,external_id,event_name,event_time,value,currency,order_id'];
    for (const x of rows) { const u: any = buildUserData(x, s); out.push([u.em?.[0] || '', u.ph?.[0] || '', u.fn?.[0] || '', u.ln?.[0] || '', u.external_id?.[0] || '', 'Purchase', Math.floor(x.sat / 1000), x.amount, 'USD', 'S' + x.sid].map(csvq).join(',')); }
    return file(out.join('\n'), 'meta_purchases.csv');
  }
  if (kind === 'audience.csv') {
    const buyers = type !== 'all';
    const rows = all<any>(`SELECT l.*, (SELECT COALESCE(SUM(amount),0) FROM sales WHERE lead_id=l.id) value FROM leads l WHERE l.created_at>=? AND l.created_at<? ${buyers ? "AND (l.status='sold' OR EXISTS(SELECT 1 FROM sales x WHERE x.lead_id=l.id))" : "AND l.status!='merged'"} AND (COALESCE(l.email,'')!='' OR COALESCE(l.phone,'')!='')${LW('l')} ORDER BY l.id`, f, t);
    const out = ['email,phone,fn,ln,value'];
    for (const x of rows) { const u: any = buildUserData(x, s); out.push([u.em?.[0] || '', u.ph?.[0] || '', u.fn?.[0] || '', u.ln?.[0] || '', x.value].map(csvq).join(',')); }
    return file(out.join('\n'), buyers ? 'audience_buyers.csv' : 'audience_all_leads.csv');
  }
  return json({ error: 'Not found' }, 404);
}

export const GET = handle;
export const POST = handle;
