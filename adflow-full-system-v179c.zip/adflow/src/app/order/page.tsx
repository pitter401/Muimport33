import { shareMeta } from '@/server/site';
import type { Metadata } from 'next';
import { redirect } from 'next/navigation';
import { getSettings, usesUploadedLogo } from '@/server/settings';
import { THEME_VARS, themeCss } from '@/components/site/themes';
import { shopThemeCss } from '@/components/site/palette';
import { OrderPage } from '@/components/shop/Shop';

export const dynamic = 'force-dynamic';
export async function generateMetadata(): Promise<Metadata> {
  const s = getSettings();
  const title = 'Order — ' + s.brand_name;
  return { title, robots: { index: false }, ...(await shareMeta({ title, description: `Order ${s.brand_name} ad accounts, top-ups and funnel setup online.`, url: '/order' }, s)) };
}

export default function Page() {
  const s = getSettings();
  if (s.web_orders_on !== '1') redirect('/');
  const theme = s.theme in THEME_VARS ? s.theme : 'purple';
  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: themeCss(theme) + shopThemeCss(theme) }} />
      <OrderPage brand={s.brand_name} logo={usesUploadedLogo(s) ? '/api/logo?v=' + s.logo_ver : '/brand/logo.png?size=96&theme=' + s.theme + '&v=' + encodeURIComponent(s.brand_name)} />
    </>
  );
}
