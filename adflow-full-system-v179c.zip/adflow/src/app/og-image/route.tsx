import { getSettings } from '@/server/settings';
import { coverImage } from '@/server/brandkit';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** 1200x630 link-share image (Google, WhatsApp, Telegram, Facebook): same design as the Facebook cover, main theme colours. */
export async function GET() {
  return coverImage(getSettings(), 1200, 630);
}
