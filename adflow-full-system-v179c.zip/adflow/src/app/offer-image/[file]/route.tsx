import { getSettings } from '@/server/settings';
import { offerImage } from '@/server/brandkit';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** v140: /offer-image/<agency|premium|funnel>.png — the line's offer image (1280x720 PNG, no login) sent with the welcome
 *  buttons: Telegram photo and WhatsApp image header. Prices and delivery from the settings. Unknown name → 404. */
export async function GET(_req: Request, ctx: { params: Promise<{ file: string }> }) {
  const { file } = await ctx.params;
  const m = /^(agency|premium|funnel)\.png$/.exec(String(file || ''));
  if (!m) return new Response('Not found', { status: 404 });
  return offerImage(getSettings(), m[1] as 'agency' | 'premium' | 'funnel');
}
