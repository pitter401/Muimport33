import { shareMeta } from '@/server/site';
import type { Metadata } from 'next';
import { getSettings, usesUploadedLogo } from '@/server/settings';
import { THEME_VARS, themeCss } from '@/components/site/themes';
import { shopThemeCss } from '@/components/site/palette';
import { PayLinkPage } from '@/components/shop/Shop';

export const dynamic = 'force-dynamic';
export async function generateMetadata(): Promise<Metadata> {
  const s = getSettings();
  const title = 'Payment — ' + s.brand_name;
  return { title, robots: { index: false, follow: false }, ...(await shareMeta({ title, description: `Secure payment link from ${s.brand_name}.` }, s)) };
}

/** Crypto payment link an agent sent in Telegram. */
export default async function Page({ params }: { params: Promise<{ code: string }> }) {
  const { code } = await params;
  const s = getSettings();
  const theme = s.theme in THEME_VARS ? s.theme : 'purple';
  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: themeCss(theme) + shopThemeCss(theme) }} />
      <PayLinkPage code={code} brand={s.brand_name} logo={usesUploadedLogo(s) ? '/api/logo?v=' + s.logo_ver : '/brand/logo.png?size=96&theme=' + s.theme + '&v=' + encodeURIComponent(s.brand_name)} />
    </>
  );
}
