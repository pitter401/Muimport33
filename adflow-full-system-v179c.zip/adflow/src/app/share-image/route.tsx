import { getSettings } from '@/server/settings';
import { shareImage } from '@/server/brandkit';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** 1200x675 (16:9) preview image for links sent in chats. ?line=funnel → the funnel version. */
export async function GET(req: Request) {
  const line = new URL(req.url).searchParams.get('line') === 'funnel' ? 'funnel' : 'agency';
  return shareImage(getSettings(), line);
}
