import { waChatLink } from '@/server/wapages';

export const dynamic = 'force-dynamic';

/** v131: "Chat on WhatsApp" on the WhatsApp ad pages → WhatsApp with the pre-typed message + this visitor's code. */
export async function GET(req: Request) {
  const to = waChatLink(req);
  return new Response(null, { status: 302, headers: { location: to || new URL('/', req.url).toString(), 'cache-control': 'no-store', 'x-robots-tag': 'noindex' } });
}
