import type { Viewport } from 'next';
import { getSettings } from '@/server/settings';
import { THEME_VARS } from '@/components/site/themes';
import { ProductsView, productsMetadata } from '@/components/site/ProductsView';

export const dynamic = 'force-dynamic';
export const generateMetadata = productsMetadata;
export async function generateViewport(): Promise<Viewport> {
  const t = THEME_VARS[getSettings().theme] || THEME_VARS.purple;
  return { themeColor: `rgb(${t.vars.bg.split(' ').join(',')})` };
}
export default function Page() {
  const s = getSettings();
  return <ProductsView theme={s.theme in THEME_VARS ? s.theme : 'purple'} />;
}
