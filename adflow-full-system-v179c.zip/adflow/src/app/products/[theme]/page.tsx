import type { Viewport } from 'next';
import { notFound } from 'next/navigation';
import { THEME_VARS } from '@/components/site/themes';
import { ProductsView, productsMetadata } from '@/components/site/ProductsView';

export const dynamic = 'force-dynamic';
export const generateMetadata = productsMetadata;
export async function generateViewport({ params }: { params: Promise<{ theme: string }> }): Promise<Viewport> {
  const t = THEME_VARS[(await params).theme] || THEME_VARS.purple;
  return { themeColor: `rgb(${t.vars.bg.split(' ').join(',')})` };
}
export default async function Page({ params }: { params: Promise<{ theme: string }> }) {
  const { theme } = await params;
  if (!(theme in THEME_VARS)) notFound();
  return <ProductsView theme={theme} />;
}
