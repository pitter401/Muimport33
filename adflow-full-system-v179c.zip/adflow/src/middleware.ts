import { NextResponse, type NextRequest } from 'next/server';

/** Landing pages: set visitor id + Meta _fbp / _fbc cookies (no browser pixel needed). */
export function middleware(req: NextRequest) {
  const res = NextResponse.next();
  const opts = { path: '/', maxAge: 60 * 60 * 24 * 90, sameSite: 'lax' as const, secure: process.env.INSECURE_COOKIES !== '1' };
  const rand = () => Array.from(crypto.getRandomValues(new Uint8Array(12)), b => (b % 36).toString(36)).join('');
  if (!req.cookies.get('af_vid')) res.cookies.set('af_vid', rand() + rand(), opts);
  if (!req.cookies.get('_fbp')) res.cookies.set('_fbp', `fb.1.${Date.now()}.${Math.floor(1e9 + Math.random() * 9e9)}`, opts);
  const fbclid = req.nextUrl.searchParams.get('fbclid');
  const fbc = req.cookies.get('_fbc')?.value;
  if (fbclid && (!fbc || !fbc.endsWith('.' + fbclid))) res.cookies.set('_fbc', `fb.1.${Date.now()}.${fbclid}`, opts);
  // v130: landed from a tagged ad (?utm_campaign=…) → remember campaign / ad set / ad for the next pages, the channel join and the chat
  const sp = req.nextUrl.searchParams, cl = (k: string) => (sp.get(k) || '').replace(/\s+/g, ' ').trim().slice(0, 100);
  const camp = cl('utm_campaign') || cl('campaign_name');
  // v161: client-site badge → "Client badge" + the client (utm_source)
  const badge = camp.toLowerCase() === 'client_badge';
  if (camp && !/\{\{/.test(camp)) res.cookies.set('af_cmp', encodeURIComponent(JSON.stringify(badge ? ['client_badge', cl('utm_source'), ''] : [camp, cl('utm_term') || cl('adset_name'), cl('utm_content') || cl('ad_name')])), { ...opts, maxAge: 60 * 60 * 24 * 30 });
  return res;
}

// every landing / order page — the Funnel pages too (they were missing → no _fbp/_fbc/visitor id there)
export const config = { matcher: ['/', '/p/:theme*', '/premium', '/premium/:theme*', '/funnel', '/funnel/:theme*', '/order', '/products', '/products/:theme*', '/account', '/pay/:code*', '/telegram', '/telegram/:theme*', '/agency/telegram', '/agency/telegram/:theme*', '/premium/telegram', '/premium/telegram/:theme*', '/funnel/telegram', '/funnel/telegram/:theme*', '/agency/whatsapp', '/agency/whatsapp/:theme*', '/premium/whatsapp', '/premium/whatsapp/:theme*', '/funnel/whatsapp', '/funnel/whatsapp/:theme*', '/agency/community', '/agency/community/:theme*', '/premium/community', '/premium/community/:theme*', '/funnel/community', '/funnel/community/:theme*'] };
