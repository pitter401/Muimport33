import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  // v173: the update builds into .next-new while the live site keeps running from .next, then swaps (no 502 during an update)
  distDir: process.env.NEXT_DIST_DIR || '.next',
  poweredByHeader: false,
  reactStrictMode: true,
  // Telegram user-account client (auto first message) must not be bundled
  serverExternalPackages: ['telegram', 'big-integer', 'tesseract.js', '@tesseract.js-data/eng', 'playwright-core'], // v168: playwright-core = the status-video renderer (worker only)
  // v127: safer browser defaults on every page (no framing by other sites, no MIME sniffing, HTTPS remembered)
  async headers() {
    return [{
      source: '/:path*',
      headers: [
        { key: 'X-Frame-Options', value: 'SAMEORIGIN' },
        { key: 'X-Content-Type-Options', value: 'nosniff' },
        { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
        { key: 'Strict-Transport-Security', value: 'max-age=15552000' },
        { key: 'Permissions-Policy', value: 'camera=(), geolocation=(), payment=(), usb=(), microphone=(self)' },
      ],
    }, {
      // v168: the in-app reel templates (page, runtime, fonts): served from the HTTP cache at once, refreshed in the background
      source: '/reel-tpl/:path*',
      headers: [{ key: 'Cache-Control', value: 'public, max-age=600, stale-while-revalidate=604800' }],
    }];
  },
};

export default nextConfig;
