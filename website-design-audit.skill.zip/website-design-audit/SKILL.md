---
name: "website-design-audit"
description: "Audit a website or landing page (Next.js/React/HTML) for real design, UX, mobile, accessibility, copy and trust problems using Taste Skill's browser checker plus Vercel's Web Interface Guidelines, then report prioritized fixes. Use whenever the user asks to audit, review, check or improve a site's design/UX, says a page looks generic or broken on phone, or shares a design-skill repo to audit with."
---

# Website design audit

Goal: a short, prioritized list of problems that actually hurt the business (sales, trust, ad approval, phone users), not a dump of every rule a linter can fire.

## Report only — never fix

This skill only finds problems and suggests fixes. Do not edit, fix, remove or switch off anything in the code or settings, and do not build or package an update — not even a quick or "obvious" fix, and not for the most serious item. Example: if the page shows invented activity (fake "X bought just now", inflated viewer counts), say that it is there, where it comes from, why it should be fixed and how — and stop there. The user reads the report and picks which items to get done; work on them only after the user names them in a later message. Running the site locally and checkers to look at it is fine; changing it is not.

## 1. Get the page running

- Prefer the live URL. If the shell cannot reach it, run the project locally (`npm run build && npm start`) with settings/content close to live (brand, prices, theme, links), so findings match what customers see.
- Save the HTML of the main pages (`curl localhost:3000/<path> > page.html`) for the copy check.

## 2. Run the two rule sets

**Taste Skill** (browser checker, copy linter). Clone it into its own folder:

```bash
git clone --depth 1 https://github.com/Leonxlnx/taste-skill
S=taste-skill/skills/taste-skill/scripts
node $S/copy-lint.mjs page.html --kind service          # no browser, < 1 s
node $S/consistency.mjs http://localhost:3000/ --widths 1440,390 --profile .taste-skill/chrome --page service --category "<what is sold>" --primary "<main action>" --out out
```

- It needs Chrome: set `CHROME_PATH`. Running as root, Chrome exits early, so point `CHROME_PATH` at a tiny wrapper script that adds `--no-sandbox` (never edit the kit's files).
- Pick `--page`: service (agency, people hired), product, software, place (shop/cafe).
- Group the output: `grep -E "^\s+(FAIL|WARN) " out.txt | awk '{print $1,$2}' | sort | uniq -c | sort -rn`, then read the details of the checks that matter.

**Vercel Web Interface Guidelines**: fetch `https://raw.githubusercontent.com/vercel-labs/web-interface-guidelines/main/command.md` and grep the site code for its anti-patterns: `maximum-scale`/`user-scalable`, `transition-all`, `outline-none` without `focus-visible`, `onPaste` preventDefault, `<div onClick>`, `<img>` without width/height, inputs without labels/autocomplete, missing `aria-live` on errors, missing skip link, theme-color / color-scheme.

## 3. Separate real problems from taste opinions

Taste Skill encodes one designer's house style. Drop findings that are only style preference unless the user wants that look, and say you dropped them:
- "never violet", one section per screen / hero exactly one screen, no accordions or tabs, photographs everywhere, "dealt moments", shader rules.

Keep findings that hurt real users or the business:
- **Trust / honesty first**: invented social proof (generated "X bought just now" names, inflated "people viewing" counts, made-up stats or reviews). Check the code that feeds these widgets, not just the text. Flag it as the top item: it is misleading to customers and against Meta/Google ad policies, so it can get ad accounts or pages rejected.
- **Phone**: sideways scroll at 320-390px (off-viewport), text cut by the fold, tap targets under 44px, nav wrapping at 768px.
- **Content hidden until JS runs** (scroll-reveal at opacity 0, count-up numbers that render "0" server-side): crawlers and slow phones see nothing or zeros.
- **Contrast** under 4.5:1 for body text, dead links (`href="#"`), missing focus rings, unlabeled inputs.
- **Consistency**: too many button styles, one action drawn two ways, duplicate wording of the same promise.

## 4. Report

In the user's language (Hinglish if that is how they talk), short, three tiers:

- 🔴 Must fix (trust, broken on phone, wrong data shown)
- 🟠 Should fix (contrast, hidden content, nav, buttons, tap size)
- 🟡 Small (focus, labels, minor code hygiene, copy duplicates)
- ✅ What is already good (one line)

Each item: what is wrong, where (page/element or `file:line`), why it matters, and the suggested fix in one line. Say which rules you skipped as opinion. End by asking which items the user wants done (and any choice only the user can make, e.g. turn a ticker off or show only real sales) — then stop and wait.