# AdsBhai Ad Campaign System

<!-- tab: Tab 1 -->

# AdsBhai Ad Campaign System

2026-11-06 · @someone

Meta ad pe click → adsbhai.com landing page → order (USA agency account $20 se shuru) website ya Telegram @Adsbhaibot pe. Cold traffic ko hook-wale videos, aur page dekh ke chhodne walon ko retargeting videos.

## Funnel

Har step pe ek hi kaam: agle step tak le jaana. Purchase event CAPI se wapas Meta ko jaata hai, taaki Meta khareedne wale log dhoondhe.

1. **Reel ad (cold)** — pehle 2 second ka hook scroll rokta hai ("Ad account baar-baar disable?").
2. **Click → adsbhai.com** — ViewContent event fire.
3. **Landing page** — "$20 se shuru", 1 ghanta delivery, NO limit / NO 18% GST upar hi dikhe.
4. **Order** — website checkout ya Telegram @Adsbhaibot ($20 se shuru). Lead event jab bot pe message aaye.
5. **Purchase** — payment confirm hote hi Purchase CAPI event (event\_id se dedup).
6. **Retargeting** — jo page dekh ke ya bot pe aake nahi kharide, unhe 1–14 din retargeting videos.

## Campaigns aur audiences

Do campaign: 75% budget cold Sales campaign mein, 25% retargeting mein. Dono ka optimization event = Purchase.

| Campaign | Audience | Videos | Budget |
| --- | --- | --- | --- |
| 1. Cold — Sales (Advantage+) | India, 20–45, broad; interests test: Facebook Ads, Shopify, Dropshipping, Digital marketing | UGC Hook, Animated Sell, Animated Skit | 75% |
| 2. Retargeting — Sales | Website visitors 14 din (purchase exclude) + video viewers 50% (7 din) + Instagram/FB engagers 14 din | UGC Retarget, Animated Retarget | 25% |

- Cold mein ek ad set, 3 videos ek saath; Meta khud winner ko budget dega.
- Purchasers ko dono campaigns se exclude karo (Purchase 30 din custom audience).
- Placement: Reels + Stories first; 9:16 videos hain.

## Creatives

Paanch videos banaye ja rahe hain. Teen cold ke liye, do retargeting ke liye.

| Video | Style | Hook (pehle 2 sec) | Audience | Length |
| --- | --- | --- | --- | --- |
| UGC Hook | Model, cloned voice, lip-sync | "Ad account baar-baar disable ho raha hai? Skip mat karna" | Cold | \~27s |
| Animated Sell | Motion graphics, male voice | DISABLED stamp + "phir se disable?" | Cold | \~31s |
| Animated Skit | Rahul–Priya baatcheet | "Mera ad account phir disable… 3rd time!" | Cold | \~30s |
| UGC Retarget | Model, cloned voice | "Page dekha… order kyun nahi kiya?" | Retargeting | \~20s |
| Animated Retarget | Motion graphics, female voice | Cursor "Order Now" pe atka hua | Retargeting | \~15s |

Ad copy (primary text) sab mein same base: "USA verified Meta agency ad account • No spending limit • No 18% GST • $20 se shuru • 1 ghante mein delivery. Order: adsbhai.com". CTA button: Shop Now / Order Now.

## Hook bank

Winner video mil jaaye to sirf pehle 2–3 second badal ke naye versions banao. Baaki video same rahega.

- "Tumhara 4th ad account bhi disable hone wala hai… agar ye nahi kiya."
- "Ads chalane walon ka sabse bada dard: Account disabled."
- "$20 mein woh cheez jo tumhara ad budget bacha legi."
- "18% GST dekar ads chala rahe ho? Ruk jao."
- "Spending limit $50 pe atka hua hai? Ye dekho."
- "Gaming/cricket niche ke ads approve nahi ho rahe?"
- "Personal ad account se ads chalana band karo."

## Landing page checklist

Ad ka promise aur landing page ka pehla screen same hona chahiye, warna click waste hota hai.

- [ ] Pehle screen pe: "USA Verified Meta Agency Ad Account — $20 se shuru", aur ek bada "Order Now" button
- [ ] Teen badges button ke paas: No spending limit • No 18% GST • 1 ghante mein delivery
- [ ] Video ka hi visual style (cream + orange/green), taaki user ko lage wahi jagah hai
- [ ] Order form 3 field se zyada nahi (naam, WhatsApp/Telegram, BM ID)
- [ ] "Order kaise milta hai" — 3 step: Order → Payment → 1 ghante mein account
- [ ] FAQ: refund/replacement policy, top-up kaise hota hai (3% fee), kaunse niches chalte hain
- [ ] Website order main button, Telegram (@Adsbhaibot) neeche secondary button
- [ ] Mobile pe page 2 sec mein load; Pixel + CAPI dono (event\_id dedup)

## Tracking aur KPIs

Faisla CPA (cost per purchase) pe lo, likes ya views pe nahi. Neeche ke target pehle hafte ke andaaze hain; apne data se badalna.

| Metric | Kahan dekhna | Target (start) | Kya karna |
| --- | --- | --- | --- |
| Hook rate (3-sec views ÷ impressions) | Ads Manager custom column | 30%+ | Kam ho to sirf hook badlo |
| CTR (link) | Ads Manager | 1.2%+ | Kam ho to offer/caption badlo |
| Landing → Order rate | Purchase ÷ ViewContent | 5%+ | Kam ho to landing page theek karo |
| CPA | Ads Manager (Purchase) | ₹600 se kam | 2× target ke upar 3 din = ad band |
| ROAS | Purchase value ÷ spend | 1.5+ | Upar ho to budget +20% har 2 din |

Events: ViewContent (page load), Lead (bot pe message), Purchase (payment confirm). Sab CAPI se, browser Pixel ke saath same event\_id.

## Pehle 14 din ka testing plan

Pehle 7 din data lo, phir winner pe paisa lagao. Beech mein ad set mat chhedo.

1. **Din 1–3:** Cold campaign 3 videos ke saath, ₹1,500/din. Retargeting abhi band (audience chhoti hai).
2. **Din 4:** Retargeting on, ₹500/din, jab website visitors 1,000+ ho jaayein.
3. **Din 5–7:** Jo video CPA target ke andar, use rakho. 2× CPA wale band.
4. **Din 8–10:** Winner video ke 3 naye hook versions (Hook bank se) daalo.
5. **Din 11–14:** Jo ad set ROAS 1.5+ de raha hai, uska budget har 2 din +20%.

Budget figures example hain; apne monthly budget ke hisaab se same ratio (75/25) rakho.

