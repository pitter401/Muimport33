# AdsBhai AI — Step 1 Questionnaire

<!-- tab: Tab 1 -->

# AdsBhai AI — Step 1 Questionnaire

2026-11-19 · @someone

## Kaise bharna hai

Is doc ke jawab se AdsBhai AI ka dimaag banega: kya bechna hai, kitne mein, aur kaise baat karni hai. Jo yahan likha hoga, AI usi ke hisaab se bolega; jo yahan nahi hoga, AI wo chat agent ko de dega.

- Har sawaal ke neeche **Sample jawab** maine likha hai. Sahi hai to chhod de, galat hai to wahin badal de.
- **Tera jawab** khaali ho to sample hi maana jaayega.
- Jo cheez abhi pata nahi, wahan "abhi pata nahi" likh de. Kuch bhi galat andaza mat bharna.
- Price dollar ($) mein hi likhna, jaise ab tak bata rahe ho.

## Services aur price

AI sirf yahi price bolega, iske bahar kuch nahi. Galat cell wahin table mein badal de.

| Service | Price (sample) | Kya milta hai (sample) | Tera jawab |
| --- | --- | --- | --- |
| Ad account | $23 one time | Kabhi bhi issue aaye to free replacement |  |
| Landing page + funnel setup | $50 / month | Page banana, tracking, Telegram/WhatsApp leads setup |  |
| Ad budget top-up | \_\_\_\_% fee | Customer jitna budget daale, utna account me |  |
| Ads chalana (campaign setup) | \_\_\_\_ | Hum ad bana ke chalayenge? Haan / Nahi |  |
| WhatsApp API / training | \_\_\_\_ | Channel me training paid hai |  |

1. Top-up ki fee kitni hai? Minimum top-up kitna?
   - Sample jawab: ****% fee, minimum $****.
   - Tera jawab:
2. $50 funnel me ad account shaamil hai ya alag $23?
   - Sample jawab: Alag. Funnel $50/month, account $23 alag.
   - Tera jawab:
3. Combo ya package deta hai (jaise account + funnel saath me sasta)?
   - Sample jawab: Abhi nahi.
   - Tera jawab:
4. Customer ka apna ad account ho to sirf funnel de sakte ho?
   - Sample jawab: Haan, sirf funnel $50/month.
   - Tera jawab:

## Payment aur delivery

AI payment sirf system ke Payment link se lega; UPI ya wallet address kabhi khud se nahi bhejega.

1. Customer kis tarike se pay kar sakta hai?
   - Sample jawab: Payment link se (USDT / card / UPI — jo link me available ho).
   - Tera jawab:
2. Payment ke baad ad account kitni der me milta hai?
   - Sample jawab: \_\_\_\_ ghante ke andar.
   - Tera jawab:
3. Funnel / landing page kitne din me ready hota hai?
   - Sample jawab: \_\_\_\_ din.
   - Tera jawab:
4. Setup ke liye customer se kya-kya chahiye (logo, business naam, WhatsApp number, Telegram link)?
   - Sample jawab: Business naam, logo, WhatsApp number ya Telegram link, aur kya bechna hai.
   - Tera jawab:
5. Replacement kaise milta hai? Kitni der me?
   - Sample jawab: Account band hone pe chat me batao, \_\_\_\_ ghante me naya account.
   - Tera jawab:
6. Refund deta hai? Kab?
   - Sample jawab: Account dene ke baad refund nahi, sirf replacement.
   - Tera jawab:
7. Monthly $50 ki renewal kaise hoti hai? Na de to kya hota hai?
   - Sample jawab: Har mahine payment link; na de to page band.
   - Tera jawab:

## Rules

Inme se koi bhi cheez aaye to AI mana nahi karega, chat seedha manager ko dega.

1. Kaun se business ke ads bilkul nahi karte?
   - Sample jawab: Betting / gambling, fake product, loan fraud, adult, crypto doubling scheme.
   - Tera jawab:
2. Kaun se business "dhyan se" karte ho (Meta jaldi reject karta hai)?
   - Sample jawab: Prediction / tips channel, crypto, trading course, health product — ad me words badal ke.
   - Tera jawab:
3. AI kya promise kabhi nahi karega?
   - Sample jawab: Leads ki pakki ginti, sale ki guarantee, ad kabhi reject nahi hoga, account kabhi band nahi hoga.
   - Tera jawab:
4. India ke alawa dusre desh ke customer lete ho?
   - Sample jawab: Haan, price same dollar me.
   - Tera jawab:

## Discount aur mol-bhav

1. Discount dete ho? Kitna tak?
   - Sample jawab: AI koi discount nahi dega. Customer maange to chat manager ko.
   - Tera jawab:
2. Customer bole "mehenga hai" to AI kya bole?
   - Sample jawab: Chhote budget se start kar sakte ho; setup ek baar ka hai, replacement free hai, isliye sasta padta hai.
   - Tera jawab:
3. Customer bole "dusra $15 me de raha hai" to?
   - Sample jawab: Unka replacement nahi hota; hamara kabhi bhi free replacement. Phir bhi chahe to manager se baat karwa do.
   - Tera jawab:
4. Ek se zyada account lene pe kuch kam karte ho?
   - Sample jawab: 3+ account pe manager decide karega.
   - Tera jawab:

