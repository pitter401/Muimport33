# P2PINR Token — Architecture Blueprint

<!-- tab: P2PINR Token — Architecture Blueprint -->

# P2PINR Token — Architecture Blueprint

2026-09-20 · @someone

> **Update, 23 Sep 2026.** Direction confirmed: all new staking — users and merchants — runs on PINR; tiers and rewards are paid in PINR; unstaking returns the same PINR units; and PINR gets an internal USDT ⇄ PINR swap so nobody needs an external wallet. New in this pass: the **Deployment kit** at the end of Part 1, **Part 5 — PINR-only staking and the unstake flow**, and **Part 6 — The internal swap**. The platform is now LIVE, so every phase ships dark, behind flags that are off. The migration is now `0016_token.sql` (0015 is taken) and its SQL was re-run against migrations 0001–0015 on Postgres 16: three statements in the earlier draft would have failed or re-broken fraud slashing, and are fixed below.

## Decisions — 23 Sep 2026 discussion

Where this section conflicts with Parts 1–6, **this section wins**. The parts below get rewritten area by area as each one is built.

| Area | Decision |
| --- | --- |
| Launch model | **Platform-only first.** At launch PINR lives only inside the platform: no PancakeSwap pool, no PINR deposits, no PINR withdrawals |
| Launch price | **$1 per PINR**, set by admin (price source `ADMIN_FIXED`) |
| Supply | **10,00,000 PINR** (1 million), fixed, minted once to the Safe. Deploy costs only gas |
| Contract owner | No owner or admin key inside the contract. The company owns the project and 100% of the supply, held in its Safe. Whether a capped mint is needed depends on the reward-funding answer |
| Exit path | **PINR → USDT swap, then the existing USDT withdrawal.** There is no direct PINR withdrawal |
| Swap switches | USDT → PINR and PINR → USDT have separate admin switches. PINR → USDT stays ON normally — admin controls daily, per-user and stock limits — and goes fully OFF only in an emergency, briefly, because it is the only exit |
| Swap stock | Admin funds it at launch, maker–checker |
| Backing rule | USDT received from USDT → PINR swaps stays in the swap stock: it is what backs the $1. At a fixed price, PINR bought by users and USDT in stock move one-for-one. Only free tokens (rewards, incentives) and company withdrawals break that. Admin panel shows backing = stock USDT ÷ PINR held by users. The swap spread (e.g. $1.00 in, $0.98 out) is the company's margin |
| Staking | All new staking — users and merchants — in PINR |
| Merchant bond | **Fixed token count set by admin** (e.g. 300 PINR at launch). No margin call, no forced top-up, no automatic limit change when the price moves. Admin can change the requirement for new merchants only. Admin panel shows each merchant's bond in today's $ and the uncovered gap, for information; admin may lower a merchant's limit by hand |
| Victim refund | Slashed PINR is converted to USDT through the swap stock at the platform price and paid to the victim; this conversion ignores user swap limits. Any shortfall: merchant's USDT balance → recovery debt → company. **Landing page unchanged.** No separate `RECOVERY_RESERVE` account |
| Early unstake | Admin-only, as today (`stakes.early_unlock` + reason + 2FA), with an optional penalty % the admin may apply |
| Opening the market later | PancakeSwap pool opened at the price the platform shows that day; the swap switches to follow the pool at the same moment; pool USDT ≥ 20 × the daily total PINR withdrawal cap (worst day ≤ 10% fall); backing 90–100%; per-user and total daily PINR withdrawal caps; staked tokens not withdrawable; a waiting period for free tokens; never open above the platform price |

**Removed from the first build** (these return only when the market opens): the PINR deposit scanner, the signer token map, the deposit-address change, the PancakeSwap TWAP oracle (`ADMIN_FIXED` only), merchant revaluation and margin calls, and `RECOVERY_RESERVE` (drop it from the 0016 system-code list when building).

**Still open**

- What "3%" means, and where rewards come from — Patrick will decide.
- Fixed supply vs capped mint — depends on the reward answer.
- User tiers as a fixed PINR count, like merchant bonds? Recommended: yes.
- Token name and symbol; launch date.

## Summary: you already own 70% of this

P2PINR does not need a new staking system — it needs a **second asset** inside the system it already has. The database is already multi-asset (`ledger_accounts.asset`), the buckets `BUY_STAKE`, `MERCHANT_STAKE` and `EARNING` already exist, and `stake_tiers`, `stake_positions`, `earning_positions`, `earning_rewards` and `merchant_profiles.required_stake_usdt` are all built and working — in USDT. The real work is five things:

1. Make the ledger genuinely two-asset (the schema allows it; `ledger.ts` hard-codes `asset = 'USDT'` in every query).
2. Make custody two-token on the same deposit addresses (one EVM address receives both USDT and PINR).
3. Add a price oracle, because every limit and every collateral rule in the platform is denominated in USDT and our token is not stable.
4. Turn the single hard-coded earn plan in settings into admin-managed plans with their own rate, duration and caps.
5. Add an internal USDT ⇄ PINR swap and a proper unstake flow, so a user can get PINR to stake — and turn it back into USDT — without an external wallet (Parts 5 and 6).

### The three decisions that determine everything else

| Decision | Options | Recommendation | Why |
| --- | --- | --- | --- |
| Custody of staked tokens | Non-custodial (user signs from MetaMask into a staking contract) vs custodial (tokens sit in your hot/cold wallets, staking is a ledger lock) | **Custodial ledger lock** | You are already a custodial exchange with an audited double-entry ledger, a signer service and a reconciliation job. A staking contract adds a second source of truth, gas costs per stake, and an audit you must pay for. |
| Where staking state lives | On-chain staking contract vs off-chain `stake_positions` rows | **Off-chain, ledger-backed** | Admin-set APY, dynamic plans and instant slashing are trivial off-chain and painful on-chain. On-chain staking is a v2 marketing feature, not a v1 requirement. |
| Collateral denomination | Merchant bond sized in PINR tokens vs sized in USDT value of PINR | **USDT value, with a haircut and top-up calls** | A token you issue is worth least exactly when you need the collateral. A bond of "50,000 PINR" is not a bond. |

### The three things that will bite you

- **Reward funding.** If Earn rewards are paid in newly minted tokens, the yield is nominal and the token price absorbs it — users end up with more tokens worth the same or less. If they are paid from real revenue, the yield is real but capped by revenue. Pick one deliberately and say which in the UI. The existing `earning.fundingSource` setting already forces this choice; extend it, don't bypass it.
- **Legal.** An admin-set fixed return with a lock-in, on a token you issue, taken from the public in India, reads like an unregulated deposit scheme under the BUDS Act 2019. This is the single highest-risk item in the plan. Details in *Risk, security and compliance*.
- **Price manipulation.** If token price raises trading limits, anyone who can move a thin market can raise their own limits. The oracle design in *Part 2* is a control, not a nicety.

## What exists today, and where the token plugs in

Everything below is in the repo now. Read this table as the change list — it is the honest scope of the work.

| Component | What it does today | What the token needs |
| --- | --- | --- |
| `ledger_accounts` | Double-entry, bigint micro units, DB-trigger balanced, `asset` column exists and defaults `'USDT'`; unique keys are already `(mode, asset, user_id, bucket)` | **No schema change.** Only code: `ensureAccount`, `getUserBalances`, `getSystemBalances` and `checkLedgerIntegrity` all hard-code `asset = 'USDT'` |
| `ledger.ts` `AccountRef` | `{kind:'USER', userId, bucket}` / `{kind:'SYSTEM', code}` | Add `asset: 'USDT' \| 'PINR'` to both shapes; `post()` must reject a transaction that mixes assets |
| Buckets | `AVAILABLE, ORDER_LOCKED, BUY_STAKE, MERCHANT_STAKE, EARNING, PENDING_WITHDRAWAL, REFERRAL` | **None.** All three staking buckets already exist and become per-asset for free |
| System accounts | `CUSTODY_HOT_WALLET`, `CUSTODY_COLD_WALLET`, `REVENUE_*`, `EXPENSE_*`, `TREASURY_EQUITY`, `RECONCILIATION_SUSPENSE`, `RECOVERY_FRAUD_SLASH` (added in 0015) | Add `TOKEN_TREASURY`, `TOKEN_REWARD_POOL`, `REWARD_RESERVED`, `SWAP_INVENTORY`, `REVENUE_SWAP_FEES`, `RECOVERY_RESERVE` and three more — the full list is in schema section 1, and it keeps `RECOVERY_FRAUD_SLASH` |
| `wallets` / `wallet_addresses` | One wallet per `(user, mode, asset, network)`; one ACTIVE address per wallet; `UNIQUE (chain_id, lower(address))` | **This is the one real conflict.** The same EVM address receives both tokens, but the unique index stops two wallets sharing an address. Deposit addresses must become per-`(user, chain)`, not per-asset |
| `deposits` / `withdrawals` | Single token contract from `settings.chain.tokenContract`; 15 confirmations; finalized-block gate; signer service with per-tx and daily raw caps | Add `asset` column; scanner watches two contracts; signer needs a second token contract + its own caps |
| `stake_tiers` / `stake_positions` | `kind IN ('BUYING','MERCHANT')`, tier snapshot frozen at stake time, `ACTIVE/RELEASED/SLASHED`, `lock_days`, early unlock, `slashMerchantStake()`, `payFromRecovery()` | Add `asset` + `stake_asset`; tier thresholds stay denominated in USDT value, satisfied by PINR at oracle price |
| `earning_positions` / `earning_rewards` | One global plan from `settings.earning` (`monthlyRewardBps`, `lockMonths`, funding source, early-exit penalty), monthly accrual, idempotent per `(position, period)` | Needs a real `earning_plans` table — the admin wants several plans, day-based durations and per-plan rates |
| `merchant_profiles` | `PENDING → PENDING_STAKE → ACTIVE`, `required_stake_usdt`, `stakeWindowDays = 7`, eligibility checked inside the acceptance lock | Bond becomes two-asset with a haircut; add top-up-call state |
| `limits.ts` | Pure function; highest active stake tier wins, then per-user override | Add the PINR tier source; keep USDT as the unit of account |
| Pricing | 30-minute rate windows derive the sell rate from buy-rate / commission / margin ranges | A second oracle for PINR→USDT. Do **not** reuse the INR rate-window machinery |
| Settings registry | `chain` group holds a single `tokenContract`, `tokenDecimals`, `minConfirmations`, explorer URLs | Becomes `chain.usdt` + `chain.pinr`, or a token list |
| Go-live gate | `readiness_items` with BLOCKER/HIGH severity, evidence + approver required | New BLOCKER items for the token (contract verified, mint authority, oracle, reward funding) |

### Deposit-address conflict, concretely

```mermaid
flowchart LR
  U[User] --> W1[wallet<br/>asset=USDT]
  U --> W2[wallet<br/>asset=PINR]
  W1 --> A1[address 0xABC]
  W2 -.blocked by<br/>unique index.-> A1
  A1 --> S[deposit scanner<br/>watches 2 contracts]
```

The fix is to stop treating a deposit address as belonging to an asset. Keep `wallets` per asset for balance display, but move `wallet_addresses` to a `(user_id, mode, chain_id)` key and let the scanner decide the asset from the log's `address` field, which `transfersTo()` already returns as `tokenContract`.

## Part 1 — Deploying the BEP-20 token and wiring it into the platform

The contract should be boring. Every extra power you keep (mint, pause, blacklist, transfer tax) is a power an exchange listing team, a token scanner and your own users will hold against you. Ship the minimum, hold the rest in a multisig, and make the platform read the token from admin config rather than from code.

### Contract decisions

| Feature | Recommendation | Reasoning |
| --- | --- | --- |
| Base | OpenZeppelin `ERC20` + `ERC20Burnable`, Solidity 0.8.20+ | BEP-20 is ERC-20; audited base, no custom transfer logic |
| Decimals | **18** | Matches USDT-BEP20 on BSC, so your existing raw↔micro conversion path is unchanged |
| Supply | **Fixed, minted once to treasury at deploy; no `mint()` at all** | Removes the rug vector entirely and makes Earn funding an explicit budget decision rather than a printing press |
| If you must keep minting | `AccessControl` `MINTER_ROLE` held only by a 3-of-5 Gnosis Safe, behind a `TimelockController` (48h), with a hard `MAX_SUPPLY` cap in the contract | A cap plus a timelock is the difference between "discretionary issuance" and "we can be rugged" |
| Pause | **No** | A pausable token freezes DEX liquidity and gets flagged by honeypot detectors |
| Blacklist / transfer tax / max-wallet | **No** | These are the exact signatures scanners mark as scam-risk; they also break your own withdrawals |
| Ownership | Transfer to the Safe at deploy; renounce entirely if supply is fixed | Renounced + fixed supply + verified source is the cleanest story you can tell |

### Deployment sequence

```mermaid
flowchart TD
  A[Finalise name, symbol,<br/>decimals, supply] --> B[Create 3-of-5 Gnosis Safe<br/>on BSC]
  B --> C[Deploy to BSC testnet<br/>chainId 97]
  C --> D[Verify source on testnet<br/>BscScan]
  D --> E[Run full platform<br/>testnet integration]
  E --> F[Deploy to mainnet<br/>chainId 56]
  F --> G[Verify + transfer<br/>ownership to Safe]
  G --> H[Seed PancakeSwap pool,<br/>lock LP tokens]
  H --> I[Admin panel: save<br/>contract address]
```

Step by step:

1. **Fix the parameters.** Name, symbol, 18 decimals, total supply, and the allocation split. Write them down before deploying — on a fixed-supply token they are permanent.
2. **Create the Safe first.** A 3-of-5 Gnosis Safe on BSC, signers on separate devices, at least one key offline. The token is deployed *to* this, not to a personal MetaMask.
3. **Deploy to BSC testnet (chainId 97).** Hardhat or Foundry, with the deployment script committed to the repo. Fund the deployer from a testnet BNB faucet.
4. **Verify the source on testnet BscScan.** If verification fails on testnet it will fail on mainnet.
5. **Run the whole platform against testnet** — deposit, credit, stake, accrue, unstake, withdraw, reconcile. This is the same gate `CUST-04 / CUST-07` in your go-live tracker, repeated for the second token.
6. **Deploy to mainnet (chainId 56)** from a clean deployer wallet, verify immediately, then transfer ownership to the Safe (or renounce).
7. **Liquidity.** A PancakeSwap v2 PINR/USDT pool. Whatever you seed it with, **lock the LP tokens** (e.g. a time-lock contract) and publish the lock. An unlocked LP is the second thing anyone checks after mint authority.
8. **Wire it into the platform** through the admin panel, not through a code deploy.

### Supply allocation — a template to fill, not a recommendation

The split below is a structure; the percentages are yours to set. What matters is that every bucket has a named on-chain address and a public vesting rule, because that is what users check.

| Bucket | Purpose | Vesting rule |
| --- | --- | --- |
| Staking + Earn reward pool | Funds all reward accrual | Released only by the accrual job, against a published budget |
| Liquidity | PancakeSwap pool | LP locked, lock proof published |
| Treasury / operations | Runway, listings, market making | Multisig, time-locked tranches |
| Team | Team allocation | Cliff + linear vest on-chain, never a plain wallet |
| Merchant incentives | Bond subsidies, merchant rewards | Released per campaign |

### Platform configuration — what the admin saves, not what you hard-code

Add a `chain.pinr` settings group mirroring the existing `chain` group, plus a new `token` group. Keep the USDT group untouched so nothing about the working exchange changes.

| Setting | Example | Notes |
| --- | --- | --- |
| `chain.pinr.tokenContract` | `0x…` | Admin-editable, 2FA-gated (`twofa.forSettingsChanges` already exists) |
| `chain.pinr.tokenDecimals` | `18` | Verified at save time against the chain, not trusted from the form |
| `chain.pinr.tokenSymbol` | `PINR` | Verified via `erc20Symbol()` |
| `chain.pinr.minConfirmations` | `15` | Same as USDT |
| `chain.pinr.minDeposit` | e.g. `100` | In tokens |
| `chain.pinr.depositsEnabled` / `withdrawalsEnabled` | `false` | Separate kill switches, mirroring `live.features` |
| `token.oracleSource` | `PANCAKESWAP_TWAP` \| `ADMIN_FIXED` \| `CEX` | See *Part 2* |
| `token.stakingEnabled`, `token.earnEnabled`, `token.merchantBondEnabled` | `false` | Ship dark, enable one at a time |

**Save-time validation is the important part.** When an admin saves `chain.pinr.tokenContract`, the server should call `erc20Symbol()`, `erc20Decimals()` and `erc20BalanceOf()` on the live RPC — all three already exist in `src/server/chain/bsc.ts` — and refuse the save if the symbol or decimals do not match what was entered. A typo'd contract address here silently sends real user deposits to a token you do not control.

### Deployment kit — the exact setup

This is the hands-on version of the eight steps above. The contract has **no owner at all**: the whole supply is minted once, in the constructor, straight to the Safe. After deployment the deployer wallet has no power over the token, so it can be a throwaway hot wallet.

| What | Use | Why |
| --- | --- | --- |
| Toolchain | Foundry (`forge`, `cast`) | Tests, deploy script and verification in one tool; the script lives in the repo |
| Library | OpenZeppelin Contracts **v5.0.2**, pinned | Audited ERC-20; a pinned version means the verified bytecode is reproducible |
| Compiler | solc **0.8.24**, `evm_version = "shanghai"`, optimizer 200 runs | Shanghai opcodes are live on BSC; pinning avoids a surprise default |
| Treasury | Safe (app.safe.global) on BNB Chain, **3-of-5** | Receives 100% of supply; every later movement needs 3 signatures |
| Deployer | Fresh wallet in an encrypted Foundry keystore, \~0.02 BNB | Never a personal MetaMask; never a plaintext key in `.env` |
| Explorer | BscScan verification (Etherscan V2 API key) | Verified source is TOK-01 |
| RPC | One testnet (chainId 97) and one mainnet (chainId 56) URL | Same providers the platform already uses |

**1. The contract** — `src/PINRToken.sol`. Name, symbol and supply are placeholders until the open questions are answered; they become permanent at deploy.

```solidity
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {ERC20Burnable} from "@openzeppelin/contracts/token/ERC20/extensions/ERC20Burnable.sol";

/// Fixed supply, no owner, no mint, no pause, no blacklist, no transfer tax.
contract PINRToken is ERC20, ERC20Burnable {
    uint256 public constant TOTAL_SUPPLY = 1_000_000 * 1e18; // 10 lakh PINR — decided 23 Sep 2026

    constructor(address treasurySafe) ERC20("P2PINR Token", "PINR") {
        _mint(treasurySafe, TOTAL_SUPPLY); // OpenZeppelin reverts on the zero address
    }
}
```

**2. The deploy script** — `script/Deploy.s.sol`.

```solidity
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {Script} from "forge-std/Script.sol";
import {PINRToken} from "../src/PINRToken.sol";

contract Deploy is Script {
    function run() external returns (PINRToken token) {
        address safe = vm.envAddress("TREASURY_SAFE");
        vm.startBroadcast();
        token = new PINRToken(safe);
        vm.stopBroadcast();
    }
}
```

**2b. The test** — `test/PINRToken.t.sol`. Delete the `Counter` example files that `forge init` creates.

```solidity
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {Test} from "forge-std/Test.sol";
import {PINRToken} from "../src/PINRToken.sol";

contract PINRTokenTest is Test {
    address constant SAFE = address(0x5AFE);

    function test_wholeSupplyGoesToSafe() public {
        PINRToken t = new PINRToken(SAFE);
        assertEq(t.totalSupply(), t.TOTAL_SUPPLY());
        assertEq(t.balanceOf(SAFE), t.TOTAL_SUPPLY());
        assertEq(t.balanceOf(address(this)), 0);
        assertEq(t.decimals(), 18);
    }

    function test_zeroTreasuryReverts() public {
        vm.expectRevert();
        new PINRToken(address(0));
    }
}
```

**3. The commands.** Testnet first, then the identical run on mainnet with a fresh deployer.

```bash
# one-time project setup
forge init pinr-token && cd pinr-token
forge install OpenZeppelin/openzeppelin-contracts@v5.0.2
echo '@openzeppelin/contracts/=lib/openzeppelin-contracts/contracts/' > remappings.txt
# foundry.toml -> solc_version = "0.8.24", evm_version = "shanghai", optimizer = true, optimizer_runs = 200

# deployer key goes into an encrypted keystore, never into .env
cast wallet import deployer --interactive

# build + test
forge build && forge test

# deploy to BSC testnet (chainId 97)
export TREASURY_SAFE=0xYourSafeOnTestnet
forge script script/Deploy.s.sol --rpc-url $BSC_TESTNET_RPC --account deployer --broadcast

# verify source
forge verify-contract $TOKEN src/PINRToken.sol:PINRToken --chain 97 \
  --constructor-args $(cast abi-encode "constructor(address)" $TREASURY_SAFE) \
  --etherscan-api-key $ETHERSCAN_API_KEY --watch

# read it back from the chain
cast call $TOKEN "totalSupply()(uint256)" --rpc-url $BSC_TESTNET_RPC
cast call $TOKEN "balanceOf(address)(uint256)" $TREASURY_SAFE --rpc-url $BSC_TESTNET_RPC
cast call $TOKEN "decimals()(uint8)" --rpc-url $BSC_TESTNET_RPC
```

If API verification gives trouble, BscScan's web **Verify & Publish** page takes the output of `forge flatten src/PINRToken.sol` with the same compiler settings.

**4. After mainnet deploy, in this order:**

1. **Check the chain, not the script output.** Total supply equals `TOTAL_SUPPLY`, the Safe holds all of it, decimals is 18, and BscScan shows verified source with no owner or mint functions.
2. **Record it.** A `token_supply_events` row of kind `DEPLOY` with the tx hash.
3. **Split the allocation from the Safe.** Team tokens go into an on-chain vesting contract (OpenZeppelin `VestingWallet`), never a plain wallet. The reward pool and the swap inventory go to the platform custody address; each transfer is recorded as a treasury op, and the ledger credit is posted only after the transfer is confirmed on chain.
4. **Seed the PancakeSwap v2 PINR/USDT pool from the Safe.** The launch price is simply the USDT you add divided by the PINR you add. Lock the LP tokens in a public locker and publish the lock transaction (TOK-03).
5. **Token profile.** Submit the logo and project details through BscScan's token-info update, which needs the verified contract and an email on the project's own domain.
6. **Wire it in** through Admin → Settings (`chain.pinr.*`) with save-time validation, every token flag still off.

The contract was **not compiled in this session** — there is no package access here. It is the standard OpenZeppelin fixed-supply shape; compile it and run `forge test` in Phase 2 before anything touches mainnet.

## Part 2 — User staking: why anyone stakes, and how limits follow

A user stakes because it makes their *trading* better, not because the yield is attractive. Yield alone attracts people who sell the reward immediately; utility attracts people who hold because selling costs them something they use. Give the token three benefits, ranked by how much real demand they create:

| Benefit | What the user gets | Demand it creates | Cost to you |
| --- | --- | --- | --- |
| **Fee discount** | Commission on Buy / Sell / Scan & Pay drops by tier (e.g. 100 bps → 75 bps) | Strongest. A heavy trader must keep holding or their costs rise | Real revenue, but only from users who trade |
| **Higher limits** | Bigger per-order cap, daily volume, daily/monthly order count | Strong. Your base buy limit today is ₹20 max per order, 5/day — the gap to a staked tier is the product | None directly; raises AML exposure |
| **Earn yield** | Staking return set by admin (Part 4) | Weakest, and the most expensive | Direct expense or dilution |

The existing tier engine already does the middle one. `limits.ts` computes `BASIC → STAKE_TIER → OVERRIDE`, picks the highest active tier by stake size, and freezes the tier terms into `stake_positions.tier_snapshot` at stake time. That behaviour is correct and should not change. What changes is that a tier can now be satisfied with PINR.

### The unit-of-account rule

**Tier thresholds stay denominated in USDT. PINR satisfies them at oracle price, minus a haircut.** Everything in the platform — limits, commissions, merchant capacity, AML thresholds — is already in micro-USDT. Do not introduce a second unit of account; introduce a conversion.

```latex
\text{credited\_value}_{USDT} = \text{amount}_{PINR} \times \text{oracle\_price} \times (1 - \text{haircut})
```

A haircut of 30–50% for a young, thinly traded token is normal. It is also what protects you from the manipulation case: if PINR trades in a shallow pool, someone can push the price up, stake into a high tier, trade at high limits, and let the price fall back. Controls, in order of importance:

1. **TWAP, never spot.** Use a 1–24 hour time-weighted average from the PancakeSwap pair, not `getReserves()` at one block.
2. **Bounded movement.** The stored oracle price may move at most N% per update (e.g. 10%/hour). A larger move parks the price and raises an admin alert instead of applying.
3. **Floor and ceiling.** Admin-set absolute bounds; outside them, PINR staking is suspended and existing tiers hold.
4. **Deposit maturity.** PINR must sit in the account for a minimum period (e.g. 24h) before it counts toward a tier — blocks the flash-stake-and-trade pattern.
5. **Separate cap.** A ceiling on how much limit can come from PINR at all, so the token can never unlock unlimited trading.

### Revaluation and the grace period

This is the rule that decides whether the feature feels fair or feels like a trap.

```mermaid
stateDiagram-v2
  [*] --> Active: stake accepted
  Active --> Watch: value falls<br/>below tier
  Watch --> Active: price recovers<br/>or user tops up
  Watch --> Downgraded: grace period<br/>expires
  Downgraded --> Active: user tops up
  Active --> Released: lock ends,<br/>user unstakes
  Downgraded --> Released: lock ends
```

- The tier snapshot is frozen at stake time, as it is today. Revaluation happens on a schedule (hourly job), not per request — a user's limits must never change between opening a trade screen and submitting it.
- On a fall, the user enters a **grace period** (recommend 7 days) with a notification and a clear top-up path. Limits hold during grace.
- On expiry, the tier drops to whatever the current value supports. **Open orders are never affected**; the drop applies to new orders only.
- On a rise, the tier can improve immediately — upgrades need no grace period.

### Schema changes for this part

- `stake_tiers`: add `stake_asset text NOT NULL DEFAULT 'USDT'`, `fee_discount_bps int NOT NULL DEFAULT 0`, `reward_apr_bps int`, `min_hold_hours int`.
- `stake_positions`: add `asset`, `valued_usdt` (at stake time), `valuation_price`, `valued_at`, `grace_until`, `countable_from`, `unbond_requested_at`, `release_after`, and statuses `WATCH` and `UNBONDING` alongside `ACTIVE`. `amount` keeps meaning units of `asset` — see Part 5.
- New `token_price_points` table (see schema section) — every valuation must be reproducible after the fact, for disputes and for the audit trail.

### The "3%" needs pinning down

Your note says *3% earn/reward benefit*. Three different products hide behind that number, and they have different costs and different legal exposure:

| Reading | Meaning | Annual cost on ₹1 crore staked |
| --- | --- | --- |
| 3% per annum | A savings-like rate | ₹3 lakh |
| 3% per month | 42.6% effective annual | ₹42.6 lakh |
| 3% cashback | 3% of *fees paid* returned to stakers | Scales with revenue, self-funding |

The third is the only one that funds itself and the only one that is not a promised return. I would default to it unless you specifically want the first.

## Part 3 — Merchant staking as real collateral

A merchant bond exists for exactly one job: **to make a defrauded user whole without the company paying out of pocket.** Every design choice follows from that. Your platform already has the machinery — `slashMerchantStake()` moves stake to a recovery account and `payFromRecovery()` pays the victim from it. What the token changes is whether that money is actually there when you reach for it.

### The problem with a pure token bond

A merchant defaults most often when the market is stressed. That is also when a thin PINR/USDT pool is at its worst. A 50,000 PINR bond posted at ₹10 is a ₹5 lakh bond; if you have to sell it into a falling pool to cover a ₹3 lakh claim, you may realise ₹1 lakh. The bond looked sufficient in the admin panel and was not.

So: **a PINR bond is never the whole bond.**

### Recommended structure: USDT floor + PINR tranche

```latex
\text{required\_bond}_{USDT} = \max\left(\text{floor},\; k \times \text{per\_order\_capacity} + m \times \text{daily\_capacity}\right)
```

| Component | Rule | Why |
| --- | --- | --- |
| USDT floor tranche | At least 50–60% of the requirement, in USDT | Immediately payable to a victim, no liquidation, no price risk |
| PINR tranche | The remainder, credited at `oracle_price × (1 - haircut)` with a **larger** haircut than user staking (50–60%) | Gives merchants a reason to hold the token without pretending it is cash |
| Sizing | Scales with the merchant's own capacity settings | Today `defaultRequiredStakeUsdt` is `'0'` and flat. A merchant handling ₹5 lakh/day and one handling ₹20,000/day should not post the same bond |
| Incentive | Merchants posting the PINR tranche get a lower commission split or higher capacity | This is the actual demand driver — merchants are your highest-value token holders |

### Merchant lifecycle

```mermaid
stateDiagram-v2
  [*] --> Pending: application<br/>submitted
  Pending --> PendingStake: approved,<br/>bond required
  PendingStake --> Active: bond posted<br/>in full
  PendingStake --> Rejected: window expires
  Active --> MarginCall: bond value falls<br/>below requirement
  MarginCall --> Active: topped up
  MarginCall --> Restricted: call expires
  Restricted --> Active: topped up
  Active --> Suspended: dispute lost<br/>or fraud flag
  Suspended --> Slashed: admin slash<br/>after appeal
  Slashed --> Restricted: bond rebuilt
  Active --> Unbonding: merchant exits
  Unbonding --> [*]: cooldown ends,<br/>stake released
```

`PENDING`, `PENDING_STAKE`, `ACTIVE`, `SUSPENDED` and `REJECTED` already exist in `merchant_profiles.status`. The new states are **`MARGIN_CALL`**, **`RESTRICTED`** and **`UNBONDING`**.

### The rules, precisely

1. **Margin call.** The hourly revaluation job compares `bond_value_usdt` against `required_stake_usdt` (the requirement column that already exists). Below 100% → `MARGIN_CALL`, notification, and a top-up deadline (recommend 72h). The merchant keeps trading during the call — cutting them off instantly is how you lose good merchants to a price dip.
2. **Restricted.** Deadline passes → `RESTRICTED`: no new order acceptance, existing orders run to completion. Reuse the existing eligibility path — `merchantIneligibility()` already returns `'Your merchant stake is below the required amount.'`, so the check point exists.
3. **Hard floor.** If bond value drops below 50% of requirement, restrict immediately with no grace. A deep fall is not a dip.
4. **Slash order.** Always **USDT tranche first**, then PINR. Never liquidate PINR while USDT is available — and never sell PINR into your own pool to pay a claim if the treasury can cover it and be reimbursed. Add a `token_liquidations` record for every forced sale.
5. **Slashing requires maker–checker.** Two staff, a written reason, 2FA, and an audit entry. Your `pending_actions` + `dualApprovalAboveUsdt` machinery already does this; extend it to slashes above a threshold.
6. **Appeal window.** A slash decision the merchant can contest for N days before the funds actually move to the victim, unless the dispute is already resolved against them. This is what stops a bond from feeling arbitrary.
7. **Unbonding cooldown.** On exit, the bond is not released until every order is closed **and** a cooldown has passed (recommend 14–30 days), because chargebacks and complaints arrive late. `releaseMerchantStakesOnClose()` currently releases on close — it needs the cooldown inserted.

### Schema changes for this part

`merchant_profiles` gains: `bond_usdt_min_share_bps` (0 = PINR-only), `bond_value_usdt` (cached), `bond_revalued_at`, `margin_call_at`, `margin_call_due_at`, `restricted_at`, `unbonding_started_at`, `unbonding_release_at`. The requirement itself stays in the existing `required_stake_usdt`.

Per-asset bond amounts live in `stake_positions` rows with `kind = 'MERCHANT'` and the new `asset` column, so there is one position per asset per merchant and the existing release/slash code paths keep working.

## Part 4 — The admin-controlled Earn model

Today there is **one** plan, living in `settings.earning`: one `monthlyRewardBps`, one `lockMonths`, one funding source. You want many plans with their own rates and durations, changeable from the admin panel. That needs a real table, and it needs one rule enforced above everything else:

> **Changing a plan must never change a position that is already open.** The user agreed to terms; the terms are theirs until maturity.

The code already gets this right — `earning_positions.plan_snapshot` freezes the whole settings object at open, and `exitEarningEarly()` reads the penalty from the snapshot, not from live settings. Keep that principle and formalise it with plan versions.

### The plan model

| Field | Type | Notes |
| --- | --- | --- |
| `name` | text | "30-Day Flexi", "180-Day Premium" |
| `asset` | `USDT` \| `PINR` | One plan is one asset |
| `duration_days` | int | **Days, not months.** 0 = flexible / no lock |
| `rate_bps` | int | Annualised, stored in basis points |
| `accrual_period` | `DAILY` \| `WEEKLY` \| `MONTHLY` \| `AT_MATURITY` | Daily accrual, periodic payout |
| `payout_mode` | `TO_AVAILABLE` \| `COMPOUND` \| `AT_MATURITY` | Compounding changes the reserve maths — see below |
| `min_amount`, `max_per_user`, `capacity_total` | bigint | Capacity is what protects the reward pool |
| `early_exit` | `NONE` \| `PENALTY` \| `FORFEIT_REWARDS` |  |
| `early_exit_penalty_bps` | int |  |
| `auto_renew` | boolean | On maturity, reopen at the *then-current* published rate, with notice |
| `status` | `DRAFT` \| `ACTIVE` \| `CLOSED` \| `ARCHIVED` | `CLOSED` = no new positions, existing ones run to maturity |
| `version` | int | Incremented on every rate or term change; old versions stay readable |
| `effective_from`, `effective_to` | timestamptz |  |

A rate change creates **version N+1**; positions keep pointing at the version they opened under. The admin panel shows both "current rate" and "weighted average rate across open positions", because the second is what you actually owe.

### Solvency: reserve at open, do not accrue and hope

This is the most important design decision in Part 4. The current job checks the budget *at payout time* and skips the payment if there is not enough — which means a user can be told they earned a reward and then not receive it. Instead:

```latex
\text{reward\_reserved} = \text{principal} \times \frac{\text{rate\_bps}}{10{,}000} \times \frac{\text{duration\_days}}{365}
```

At the moment a position opens, move the **entire projected reward** from `TOKEN_REWARD_POOL` to a `REWARD_RESERVED` system account in the same ledger transaction that locks the principal. If the pool cannot cover it, the position cannot open — the plan shows "full" instead. Accrual then pays out of the reservation, which is already fenced off.

This gives you a hard invariant you can assert in `checkLedgerIntegrity()`:

> `REWARD_RESERVED` balance ≥ sum of unpaid projected rewards across all `ACTIVE` positions.

For `COMPOUND` plans, reserve the compounded total, not the simple total.

### Accrual flow

```mermaid
flowchart TD
  A[hourly worker job] --> B{position due<br/>a period?}
  B -- no --> Z[skip]
  B -- yes --> C[compute reward<br/>from frozen version]
  C --> D[post ledger tx<br/>idempotency: pos:period]
  D --> E[RESERVED debit -><br/>user AVAILABLE credit]
  E --> F[insert earning_rewards<br/>unique pos,period]
  F --> G{matured?}
  G -- yes --> H[release principal,<br/>status MATURED]
  G -- no --> Z
  H --> I{auto_renew?}
  I -- yes --> J[open new position<br/>at current version]
  I -- no --> Z
```

The existing `runEarningPayouts()` is already idempotent per `(position_id, period_index)` via a unique index and an idempotency key — that pattern is correct and should be carried over unchanged. The only structural change is replacing `addMonths(started_at, n)` with day-based period boundaries so 30-day and custom durations work.

### Admin guardrails

These are not optional. An admin panel that can set any APY on any plan is one mis-click from an unpayable liability.

| Guardrail | Rule |
| --- | --- |
| Hard rate ceiling | A `token.maxPlanAprBps` in settings that no plan may exceed; changing the ceiling itself is a separate, logged action |
| Maker–checker | Creating or re-rating a plan uses the existing `pending_actions` flow — one admin proposes, another approves |
| 2FA | `twofa.forSettingsChanges` is already `true`; plans must be covered by it |
| Audit | Every plan version writes to `admin_audit_logs` with before/after, as `upsertTier()` already does for stake tiers |
| Capacity | Every plan has a total capacity; the pool reservation makes over-subscription impossible anyway, but the cap gives you a second brake |
| Kill switch | `token.earnEnabled = false` stops new positions instantly without touching open ones |
| Projection panel | Before saving a rate, the admin sees total projected payout at that rate against current pool balance |
| Honest labelling | Rates shown as "variable, not guaranteed" — the existing `earning.disclaimer` field already does this and must stay |

## Part 5 — PINR-only staking and the unstake flow

Parts 2 and 3 were written for a world where PINR could *also* satisfy a tier. The direction now is stronger: **every new stake is PINR**, for users and merchants. The tier engine does not change — thresholds stay in USDT value (Part 2's unit-of-account rule) and PINR satisfies them at oracle price minus the haircut. One setting, `token.stake.newStakeAsset`, flips new stakes from USDT to PINR at launch, and the stake screen then shows only PINR tiers, each with its threshold in PINR at today's price ("Gold — about 24,000 PINR today"). What this part adds is the way out.

### The one rule: the same token comes back

Unstaking returns **exactly the PINR units that were locked** — not their USDT value at stake time, and not a conversion at today's price.

- `stake_positions.amount` always means "units of `asset` locked in the ledger". Release posts that same number from `BUY_STAKE` (or `MERCHANT_STAKE`) to `AVAILABLE`, in the same asset. The earlier draft had a second `amount_native` column; it is gone — one number, one meaning, no way to release the wrong one.
- If the PINR price moved during the lock, the gain or the loss is the user's. The stake screen says so before they confirm.
- Staking rewards are separate postings in PINR from `REWARD_RESERVED` (Part 4), never folded into the principal release.

### User unstake flow

```mermaid
stateDiagram-v2
  [*] --> Active: stake locked
  Active --> Watch: value falls below tier
  Watch --> Active: price recovers or top-up
  Active --> Unbonding: Unstake after unlock date
  Watch --> Unbonding: Unstake after unlock date
  Unbonding --> Released: cooldown over, PINR back to Available
  Released --> [*]
  note right of Unbonding : release job skips accounts on fraud hold or with an open dispute
```

1. **Request.** The user taps Unstake. In one transaction, with the position locked `FOR UPDATE`, the server checks: the user owns it; status is `ACTIVE` or `WATCH`; `now ≥ unlock_at` (before that, only staff with `stakes.early_unlock`, a reason and 2FA — exactly how `releaseStake()` works today); and no open dispute involves the user.
2. **Unbonding.** Status becomes `UNBONDING`, with `unbond_requested_at = now` and `release_after = now + token.stake.userCooldownHours`. No ledger movement yet — the PINR stays in `BUY_STAKE`.
3. **The tier stops counting at the request, not at release.** `limits.ts` counts only `ACTIVE` and `WATCH` positions, so nobody keeps a high tier through the cooldown. Orders already open are not touched.
4. **Release.** The `stake_unbond_release` job (every 5 minutes) takes due positions, skips any account on fraud hold, suspended, or with an open dispute (those go to an admin queue), and posts `BUY_STAKE → AVAILABLE` for exactly `amount` under the key `stake:{positionId}:release` — the key `releaseStake()` already uses, so a job run and an admin release can never both pay.
5. **Rewards stop at the request.** A staking reward accrues up to `unbond_requested_at`; the last period is paid at release and any unused reservation returns to `TOKEN_REWARD_POOL`.

Why a cooldown for users at all: it breaks "stake just before a big trade for the discount and limits, unstake right after", and it gives the fraud engine a window to freeze an account before its tokens become withdrawable. 24 hours is enough; 0 is allowed if you disagree.

### Merchant unbond flow

Today a merchant can never release their own stake — only staff with `stakes.early_unlock`, or `releaseMerchantStakesOnClose()` when the merchant is closed. Keep that shape and add a proper exit:

1. The merchant taps Exit, or an admin closes them. Status becomes `UNBONDING` and `merchantIneligibility()` refuses new orders from that moment.
2. The bond is released only when **all** of these hold: every order is terminal; no dispute or complaint is open; no recovery debt is outstanding; and `token.stake.merchantCooldownDays` (14–30) have passed since the **last completed order** — not since the request, because complaints arrive late.
3. An admin approves from a queue that shows those checks, one click when all are green. `MERCHANT_STAKE → AVAILABLE`, the same PINR units, minus anything slashed during the cooldown.
4. Partial unbonding releases only the excess above 120% of the requirement at current value, with the same cooldown. The requirement itself is released only on exit.

### Existing USDT stakes — the platform is LIVE

- **Nothing converts automatically.** Every open USDT position keeps its tier until its unlock date and unstakes in USDT through the code path that works today. `asset` defaults to `'USDT'`, so every existing row is already correct after the migration (tested against live-shaped data).
- Offer a voluntary **"Move my stake to PINR"** screen: release the unlocked USDT stake, swap USDT → PINR (Part 6), stake the PINR — three single-asset ledger transactions in one database transaction, behind one confirm, with the swap quote shown first.
- An existing merchant USDT stake stays their bond until they post the PINR bond; only then is the USDT released, and coverage never drops below 100% at any step.

### Merchant bond in PINR-only mode

Part 3 recommends a USDT floor. If you go PINR-only, one thing must be added to keep victims safe: the landing page's money-back line is paid out of merchant stakes today, in USDT. A victim needs USDT now; a slashed PINR bond is only worth what it sells for, and it sells worst exactly when merchants fail.

The fix is a company-funded **`RECOVERY_RESERVE`** in USDT:

1. `token.merchantBondMode = PINR_ONLY` sets `bond_usdt_min_share_bps = 0` and uses the larger merchant haircut (50–60%).
2. **Recovery order** when a merchant owes a victim: the merchant's own USDT `AVAILABLE` balance → any legacy USDT stake → the PINR bond, slashed to `RECOVERY_FRAUD_SLASH` in PINR → and the remaining gap is paid from `RECOVERY_RESERVE` at once and recorded as the merchant's debt, as `recoverFromMerchant()` already does for shortfalls.
3. The victim is always paid in USDT, never in PINR.
4. The slashed PINR is converted through the swap inventory by a `RECOVERY_CONVERSION` treasury op (maker–checker) to refill the reserve — or held, if the treasury prefers.
5. Size the reserve at no less than the largest single merchant requirement plus a margin (or a share of 30-day merchant volume). It becomes readiness gate TOK-12, and while it is below minimum, new merchant approvals pause.

The plain statement: with PINR-only bonds, the company carries the price risk of the collateral. The reserve is what makes that risk visible and funded instead of hidden.

### Settings for this part

| Setting | Example | Notes |
| --- | --- | --- |
| `token.stake.newStakeAsset` | `PINR` | `USDT` today; flip at launch |
| `token.stake.userCooldownHours` | 24 | 0 allowed |
| `token.stake.merchantCooldownDays` | 21 | Counted from the last completed order |
| `token.stake.merchantPartialUnbondBps` | 12000 | Only the excess above 120% of the requirement |
| `token.merchantBondMode` | `PINR_ONLY` or `USDT_FLOOR` | `PINR_ONLY` needs a funded reserve |
| `token.recoveryReserveMinUsdt` | set at launch | Below it, new merchant approvals pause |

All of these sit in the sensitive `token` group: 2FA to change, audited, like every other sensitive group.

## Part 6 — The internal swap: USDT ⇄ PINR without a wallet

A user who wants to stake PINR needs PINR, and one who unstakes may want USDT back. Sending them to MetaMask and PancakeSwap is exactly the friction you want to remove. The internal swap is an instant conversion between a user's own USDT and PINR balances inside the platform: **no wallet, no gas, no blockchain transaction.** It is a ledger operation only. Custody already holds both tokens, so a swap changes who owns what inside the ledger, not what sits on chain — which is also why reconciliation keeps working unchanged.

### Three ways to build it

| Model | How it works | Verdict |
| --- | --- | --- |
| Platform quote against inventory | The platform quotes a price from the oracle plus a spread; the platform's own inventory is the other side | **Recommended for v1.** Instant, simple, every limit under your control |
| Internal order book | Users post bids and asks; a matching engine pairs them | Later, if volume justifies it. At launch users would see an empty book |
| Route every swap to PancakeSwap | Each user click becomes an on-chain DEX trade from the hot wallet | No. Gas and slippage per swap, a signer call per click, MEV exposure. Use the DEX only for treasury rebalancing |

### Swap flow

```mermaid
sequenceDiagram
  participant U as User app
  participant S as Server
  participant D as Postgres
  U->>S: quote USDT to PINR, 1000 USDT
  S->>D: flags, KYC, fraud hold, limits, fresh oracle price
  S->>D: insert swap_quotes, expires in 20s
  S-->>U: rate, fee, you receive, countdown
  U->>S: execute quoteId + idempotencyKey
  S->>D: BEGIN
  S->>D: lock quote, lock both inventory rows USDT then PINR
  S->>D: re-check balance, limits, price drift
  S->>D: post in-leg USDT, post out-leg PINR
  S->>D: insert swaps row, mark quote USED
  S->>D: COMMIT
  S-->>U: done, balances updated
```

### Pricing

- **Reference price:** the latest accepted oracle point, no older than `token.swap.maxPriceAgeSec`. Stale means both sides pause.
- **Always the conservative side of TWAP and spot:** a user buying PINR pays the higher of the two, a user selling gets the lower. The TWAP lags the pool on purpose (Part 2). Without this rule, anyone watching the pool could buy cheap on PancakeSwap, deposit, and sell to you at the stale, higher TWAP.
- **Spread plus size impact:** a fixed spread on each side, plus an impact term that grows with the swap's size relative to the inventory it draws on.
- **An explicit fee** in the input asset, shown on its own line. Never a hidden markup.

```latex
\begin{aligned}
P_{buy} &= \max(P_{twap}, P_{spot}) \times \left(1 + \tfrac{s + i}{10{,}000}\right) & \text{PINR}_{out} &= \left\lfloor \frac{\text{USDT}_{in} - \text{fee}}{P_{buy}} \right\rfloor \\
P_{sell} &= \min(P_{twap}, P_{spot}) \times \left(1 - \tfrac{s + i}{10{,}000}\right) & \text{USDT}_{out} &= \left\lfloor (\text{PINR}_{in} - \text{fee}) \times P_{sell} \right\rfloor
\end{aligned}
```

Here *s* is `spreadBps` and *i* is the impact in basis points, `impactFactorBps × swap value ÷ inventory value of the output asset`, rounded up. A worked example with TWAP 0.0125, spot 0.0128, fee 20 bps, spread 100 bps and impact 5 bps:

|  | Buy PINR with 1,000 USDT | Sell 50,000 PINR |
| --- | --- | --- |
| Fee | 2 USDT | 100 PINR |
| Reference price | 0.0128 (the higher) | 0.0125 (the lower) |
| Quoted price | 0.0129344 | 0.01236875 |
| User receives | 77,158.584858 PINR | 617.200625 USDT |

A user who buys and immediately sells back at these prices loses about 4.8%, most of it the gap between TWAP and spot. That cost is deliberate: it is what makes the swap useless as an arbitrage route. All arithmetic runs in integer micro units with the price as a scaled integer; outputs round down, fees round up, and there is no floating point anywhere.

A quote lives `token.swap.quoteTtlSec` (20 seconds). At execution, if the oracle has since moved **against the platform** by more than `maxDriftBps`, the swap is refused with "Rate updated — review the new quote". Otherwise the quote is honoured as shown.

### Execution — one database transaction

1. Lock the quote `FOR UPDATE`. It must be `OPEN`, belong to this user and be unexpired.
2. **Lock both `SWAP_INVENTORY` rows in a fixed order — USDT, then PINR — before posting anything.** Tested on Postgres: without this, one user buying PINR and another selling PINR at the same moment deadlock on the two inventory rows; with it, both commit.
3. Re-check the flags, the account state, the per-user and global limits including this swap, the output asset's inventory floor, and price drift.
4. Post the **in-leg**, input asset only: user `AVAILABLE` → `SWAP_INVENTORY` (net) and `REVENUE_SWAP_FEES` (fee), key `swap:{quoteId}:in`.
5. Post the **out-leg**, output asset only: `SWAP_INVENTORY` → user `AVAILABLE`, key `swap:{quoteId}:out`.
6. Insert the `swaps` row — append-only, with `quote_id` unique so one quote can never execute twice — and mark the quote `USED`.
7. Commit. Any failure — low balance, empty inventory, a limit — rolls back both legs together (tested).

Every ledger transaction stays single-asset, so the rule in the ledger section holds, and 0016 now makes the database enforce it as well.

### Inventory and treasury

- Two system accounts, `SWAP_INVENTORY` in USDT and in PINR, credit-normal with `allow_negative = false`: the database itself refuses to hand out inventory that is not there.
- **PINR inventory** comes from the treasury allocation: Safe → custody on chain, then a `FUND_INVENTORY` treasury op credits it once the transfer is confirmed.
- **USDT inventory is company money, never user money.** The company deposits USDT to custody through the existing treasury flow (`TREASURY_EQUITY`); an approved op then moves `TREASURY_EQUITY → SWAP_INVENTORY`, and is refused if custody minus customer liabilities is smaller than the amount.
- **Rebalancing is manual in v1, maker–checker.** When users mostly sell PINR, USDT inventory drains and PINR piles up; the treasury sells PINR on PancakeSwap from the Safe (`REBALANCE_SELL_PINR`) and books the USDT back after confirmation, or the reverse. Automated on-chain market-making of your own token is where scanners and regulators look hardest, so keep it human and logged.
- **You are not a guaranteed buyer.** The sell side pauses when USDT inventory reaches its floor. The swap screen says so plainly, and marketing never promises "instant cash-out anytime".

### Limits and circuit breakers

| Control | Suggested start | Why |
| --- | --- | --- |
| Eligibility | KYC approved, no fraud hold, not frozen | Same gate as trading |
| Min / max per swap | 1 / 2,000 USDT equivalent | Keeps early exposure small |
| Per-user daily volume | 5,000 USDT equivalent per direction | One account cannot drain inventory |
| Global hourly net PINR selling | 2% of USDT inventory | Stops a run on the sell side |
| Inventory floor per asset | Warn and widen the spread at 30% of target; pause that direction at 10% | Inventory never hits zero mid-day |
| Deposited PINR maturity | 24 h before it can be sold for USDT | Blocks "buy cheap on the DEX, deposit, dump into the platform" |
| Swapped PINR in tiers | Counts only after `min_hold_hours` (Part 2) | Blocks swap → stake → trade → unstake → swap loops |
| Oracle stale or out of band | Both sides pause | Never quote from a bad price |
| Quote rate limit | 30 per minute per user | Quotes are cheap to ask for, not free |
| Kill switches | `token.swap.enabled`, `buyEnabled`, `sellEnabled` | Freeze one direction without touching the exchange |

### INR to PINR

There is no INR ⇄ PINR order side. A user paying INR buys USDT through the existing P2P flow, then swaps USDT → PINR. The app can later show both steps as one "Buy PINR" screen, but underneath it stays two operations, so no new merchant pricing, matching or dispute machinery is needed.

### Tax

Each swap is a VDA-to-VDA transfer, so 194S TDS applies to swaps too (LEGAL-06). The `swaps` table carries `tds_asset` and `tds_amount` from day one, so it can be implemented without another migration. Do not enable swaps on LIVE until those mechanics are decided.

### Settings for this part

| Setting | Example | Notes |
| --- | --- | --- |
| `token.swap.enabled`, `buyEnabled`, `sellEnabled` | `false` | Ship dark |
| `token.swap.spreadBps` | 100 | Each side |
| `token.swap.feeBps` | 20 | In the input asset, shown separately |
| `token.swap.impactFactorBps` | 1000 | A swap worth 1% of inventory adds 10 bps |
| `token.swap.quoteTtlSec` | 20 |  |
| `token.swap.maxPriceAgeSec` | 600 | Older means pause |
| `token.swap.maxDriftBps` | 50 | Against the platform, between quote and execute |
| `token.swap.minUsdt`, `maxUsdtPerSwap`, `userDailyUsdt` | 1, 2,000, 5,000 | USDT equivalent |
| `token.swap.globalHourlyNetSellBps` | 200 | Of USDT inventory |
| `token.swap.inventoryTargetUsdt`, `inventoryTargetPinr` | set at launch | Floors are a share of target |
| `token.swap.depositMaturityHours` | 24 | Before deposited PINR can be sold |

## Database structure

One migration, `0016_token.sql`. Everything stays additive — no existing column is dropped or renamed, so a rollback is a rollback of code, not of data.

### 1. Make the existing tables two-asset

```sql
-- ledger: schema already supports `asset`; widen the system-account set.
-- Keeps every code from 0015 (incl. RECOVERY_FRAUD_SLASH) — dropping one would re-break slashing.
ALTER TABLE ledger_accounts DROP CONSTRAINT ledger_accounts_system_code_check;
ALTER TABLE ledger_accounts ADD CONSTRAINT ledger_accounts_system_code_check
  CHECK (system_code IN (
    'CUSTODY_HOT_WALLET','CUSTODY_COLD_WALLET',
    'REVENUE_TRADING_COMMISSION','REVENUE_ORDER_FEES','REVENUE_WITHDRAWAL_FEES',
    'EXPENSE_REFERRAL_PAYOUTS','EXPENSE_EARNING_REWARDS','EXPENSE_NETWORK_FEES',
    'TREASURY_EQUITY','RECONCILIATION_SUSPENSE','RECOVERY_FRAUD_SLASH',
    -- new in 0016
    'REVENUE_SLASHED_COLLATERAL','REVENUE_EARLY_EXIT_PENALTIES','REVENUE_SWAP_FEES',
    'EXPENSE_STAKING_REWARDS',
    'TOKEN_TREASURY','TOKEN_REWARD_POOL','REWARD_RESERVED',
    'SWAP_INVENTORY','RECOVERY_RESERVE'));

-- One asset per ledger transaction, enforced by the database as well as by post().
-- Same function as 0002 plus the asset count; the two constraint triggers keep pointing at it.
CREATE OR REPLACE FUNCTION rf_check_transaction_balanced() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
  tx_id   uuid;
  debits  numeric;
  credits numeric;
  n       int;
  assets  int;
BEGIN
  IF TG_TABLE_NAME = 'ledger_entries' THEN tx_id := NEW.transaction_id; ELSE tx_id := NEW.id; END IF;
  SELECT coalesce(sum(e.amount) FILTER (WHERE e.direction = 'DEBIT'), 0),
         coalesce(sum(e.amount) FILTER (WHERE e.direction = 'CREDIT'), 0),
         count(*),
         count(DISTINCT a.asset)
    INTO debits, credits, n, assets
    FROM ledger_entries e JOIN ledger_accounts a ON a.id = e.account_id
   WHERE e.transaction_id = tx_id;
  IF n < 2 THEN
    RAISE EXCEPTION 'ledger: transaction % has % entries (minimum 2)', tx_id, n USING ERRCODE = 'check_violation';
  END IF;
  IF debits <> credits THEN
    RAISE EXCEPTION 'ledger: transaction % is unbalanced (debits %, credits %)', tx_id, debits, credits
      USING ERRCODE = 'check_violation';
  END IF;
  IF assets <> 1 THEN
    RAISE EXCEPTION 'ledger: transaction % mixes % assets', tx_id, assets USING ERRCODE = 'check_violation';
  END IF;
  RETURN NULL;
END $$;

-- deposits already carry token_contract (0001); withdrawals do not
ALTER TABLE deposits    ADD COLUMN asset text NOT NULL DEFAULT 'USDT';
ALTER TABLE withdrawals ADD COLUMN asset text NOT NULL DEFAULT 'USDT';
ALTER TABLE withdrawals ADD COLUMN token_contract text;
CREATE INDEX deposits_asset_idx ON deposits (mode, asset, detected_at DESC);

-- deposit addresses stop belonging to an asset (see Part 1)
ALTER TABLE wallet_addresses ADD COLUMN assets text[] NOT NULL DEFAULT ARRAY['USDT'];
DROP INDEX wallet_addresses_active_uq;
CREATE UNIQUE INDEX wallet_addresses_active_uq
  ON wallet_addresses (user_id, mode, chain_id) WHERE status = 'ACTIVE';
```

### 2. Staking, two-asset with valuation and unbonding

```sql
ALTER TABLE stake_tiers
  ADD COLUMN stake_asset       text NOT NULL DEFAULT 'USDT',
  ADD COLUMN fee_discount_bps  int  NOT NULL DEFAULT 0,
  ADD COLUMN reward_apr_bps    int  NOT NULL DEFAULT 0,
  ADD COLUMN min_hold_hours    int  NOT NULL DEFAULT 0;

-- `amount` stays the number of units of `asset` locked in the ledger — exactly what unstake returns.
ALTER TABLE stake_positions
  ADD COLUMN asset               text   NOT NULL DEFAULT 'USDT',
  ADD COLUMN valued_usdt         bigint,          -- credited value after haircut
  ADD COLUMN valuation_price     numeric(38,18),  -- PINR->USDT used
  ADD COLUMN haircut_bps         int,
  ADD COLUMN valued_at           timestamptz,
  ADD COLUMN grace_until         timestamptz,
  ADD COLUMN countable_from      timestamptz,     -- min-hold maturity
  ADD COLUMN unbond_requested_at timestamptz,
  ADD COLUMN release_after       timestamptz;

ALTER TABLE stake_positions DROP CONSTRAINT stake_positions_status_check;
ALTER TABLE stake_positions ADD CONSTRAINT stake_positions_status_check
  CHECK (status IN ('PENDING','ACTIVE','WATCH','UNBONDING','RELEASED','SLASHED'));
ALTER TABLE stake_positions ADD CONSTRAINT stake_positions_unbonding_check
  CHECK (status <> 'UNBONDING' OR (unbond_requested_at IS NOT NULL AND release_after IS NOT NULL));

CREATE INDEX stake_positions_reval_idx
  ON stake_positions (mode, asset, status) WHERE status IN ('ACTIVE','WATCH');
CREATE INDEX stake_positions_unbond_idx
  ON stake_positions (mode, release_after) WHERE status = 'UNBONDING';
```

### 3. Price oracle — every valuation must be reproducible

```sql
CREATE TABLE token_price_points (
  id            bigserial PRIMARY KEY,
  mode          text NOT NULL CHECK (mode IN ('DEMO','LIVE')),
  asset         text NOT NULL,
  quote_asset   text NOT NULL DEFAULT 'USDT',
  source        text NOT NULL CHECK (source IN ('PANCAKESWAP_TWAP','CEX','ADMIN_FIXED','MANUAL_OVERRIDE')),
  price         numeric(38,18) NOT NULL CHECK (price > 0),
  twap_window_s int,
  raw_payload   jsonb NOT NULL DEFAULT '{}',
  accepted      boolean NOT NULL DEFAULT true,
  reject_reason text,              -- 'MOVE_BOUND_EXCEEDED', 'OUT_OF_BAND', 'STALE'
  observed_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX token_price_latest_idx
  ON token_price_points (mode, asset, quote_asset, observed_at DESC) WHERE accepted;

CREATE TABLE token_valuation_runs (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  mode              text NOT NULL,
  price_point_id    bigint REFERENCES token_price_points(id),
  positions_checked int NOT NULL DEFAULT 0,
  downgraded        int NOT NULL DEFAULT 0,
  margin_calls      int NOT NULL DEFAULT 0,
  started_at        timestamptz NOT NULL DEFAULT now(),
  finished_at       timestamptz
);
```

### 4. Earn plans and versions

```sql
CREATE TABLE earning_plans (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  mode         text NOT NULL CHECK (mode IN ('DEMO','LIVE')),
  name         text NOT NULL,
  asset        text NOT NULL,
  status       text NOT NULL DEFAULT 'DRAFT' CHECK (status IN ('DRAFT','ACTIVE','CLOSED','ARCHIVED')),
  sort         int  NOT NULL DEFAULT 0,
  created_by   uuid REFERENCES users(id),
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE earning_plan_versions (
  id                     uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_id                uuid NOT NULL REFERENCES earning_plans(id),
  version                int  NOT NULL,
  duration_days          int  NOT NULL CHECK (duration_days >= 0),
  rate_bps               int  NOT NULL CHECK (rate_bps >= 0),
  accrual_period         text NOT NULL CHECK (accrual_period IN ('DAILY','WEEKLY','MONTHLY','AT_MATURITY')),
  payout_mode            text NOT NULL CHECK (payout_mode IN ('TO_AVAILABLE','COMPOUND','AT_MATURITY')),
  min_amount             bigint NOT NULL CHECK (min_amount > 0),
  max_per_user           bigint,
  capacity_total         bigint,
  early_exit             text NOT NULL CHECK (early_exit IN ('NONE','PENALTY','FORFEIT_REWARDS')),
  early_exit_penalty_bps int  NOT NULL DEFAULT 0,
  auto_renew             boolean NOT NULL DEFAULT false,
  funding_source         text NOT NULL CHECK (funding_source IN ('REWARD_POOL','TREASURY_BUDGET','COMPANY_REVENUE')),
  disclaimer             text NOT NULL DEFAULT '',
  effective_from         timestamptz NOT NULL DEFAULT now(),
  effective_to           timestamptz,
  created_by             uuid REFERENCES users(id),
  approved_by            uuid REFERENCES users(id),
  created_at             timestamptz NOT NULL DEFAULT now(),
  UNIQUE (plan_id, version),
  CHECK (approved_by IS NULL OR approved_by <> created_by)   -- maker-checker
);
CREATE UNIQUE INDEX earning_plan_current_uq
  ON earning_plan_versions (plan_id) WHERE effective_to IS NULL;

ALTER TABLE earning_positions
  ADD COLUMN plan_version_id uuid REFERENCES earning_plan_versions(id),
  ADD COLUMN asset           text NOT NULL DEFAULT 'USDT',
  ADD COLUMN duration_days   int,
  ADD COLUMN rate_bps        int,
  ADD COLUMN reward_reserved bigint NOT NULL DEFAULT 0,
  ADD COLUMN reserve_tx_id   uuid REFERENCES ledger_transactions(id),
  ADD COLUMN renewed_from_id uuid REFERENCES earning_positions(id);

ALTER TABLE earning_rewards ADD COLUMN period_start timestamptz;
ALTER TABLE earning_rewards ADD COLUMN period_end   timestamptz;
```

`plan_snapshot` stays as it is — belt and braces. `plan_version_id` gives you a queryable join; the snapshot survives even if a version row is ever archived.

### 5. Merchant bond

```sql
-- required_stake_usdt (exists since 0001) stays the requirement, in USDT value. No second requirement column.
ALTER TABLE merchant_profiles
  ADD COLUMN bond_usdt_min_share_bps int NOT NULL DEFAULT 0
             CHECK (bond_usdt_min_share_bps BETWEEN 0 AND 10000),   -- 0 = PINR-only bond
  ADD COLUMN bond_value_usdt         bigint NOT NULL DEFAULT 0,
  ADD COLUMN bond_revalued_at        timestamptz,
  ADD COLUMN margin_call_at          timestamptz,
  ADD COLUMN margin_call_due_at      timestamptz,
  ADD COLUMN restricted_at           timestamptz,
  ADD COLUMN unbonding_started_at    timestamptz,
  ADD COLUMN unbonding_release_at    timestamptz;

-- keeps every status that exists today (incl. CANCELLED) and adds three
ALTER TABLE merchant_profiles DROP CONSTRAINT merchant_profiles_status_check;
ALTER TABLE merchant_profiles ADD CONSTRAINT merchant_profiles_status_check
  CHECK (status IN ('PENDING','PENDING_STAKE','ACTIVE','MARGIN_CALL','RESTRICTED',
                    'UNBONDING','SUSPENDED','REJECTED','CANCELLED'));

CREATE TABLE merchant_bond_events (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  mode           text NOT NULL,
  merchant_id    uuid NOT NULL REFERENCES users(id),
  event          text NOT NULL CHECK (event IN ('POSTED','TOPPED_UP','REVALUED','MARGIN_CALL',
                                                'RESTRICTED','CURED','SLASHED','UNBOND_REQUESTED','RELEASED')),
  required_usdt  bigint NOT NULL,
  value_usdt     bigint NOT NULL,
  coverage_bps   int    NOT NULL,
  price_point_id bigint REFERENCES token_price_points(id),
  actor_user_id  uuid REFERENCES users(id),
  reason         text,
  created_at     timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX merchant_bond_events_idx ON merchant_bond_events (merchant_id, created_at DESC);
```

### 6. Token treasury and forced sales

```sql
CREATE TABLE token_supply_events (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  kind         text NOT NULL CHECK (kind IN ('DEPLOY','ALLOCATION','TRANSFER','BURN','LP_ADD','LP_LOCK')),
  amount_raw   numeric(78,0) NOT NULL,
  from_address text,
  to_address   text,
  tx_hash      text,
  note         text,
  recorded_by  uuid REFERENCES users(id),
  occurred_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE token_liquidations (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  mode           text NOT NULL,
  reason         text NOT NULL CHECK (reason IN ('SLASH_COVER','TREASURY_REBALANCE')),
  merchant_id    uuid REFERENCES users(id),
  amount_pinr    bigint NOT NULL,
  proceeds_usdt  bigint NOT NULL,
  effective_price numeric(38,18) NOT NULL,
  slippage_bps   int,
  tx_hash        text,
  approved_by    uuid REFERENCES users(id),
  created_at     timestamptz NOT NULL DEFAULT now()
);
```

### 7. Internal swap and treasury ops

```sql
CREATE TABLE swap_quotes (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  mode           text   NOT NULL CHECK (mode IN ('DEMO','LIVE')),
  user_id        uuid   NOT NULL REFERENCES users(id),
  asset_in       text   NOT NULL CHECK (asset_in  IN ('USDT','PINR')),
  asset_out      text   NOT NULL CHECK (asset_out IN ('USDT','PINR')),
  amount_in      bigint NOT NULL CHECK (amount_in > 0),          -- micro units of asset_in, fee included
  fee            bigint NOT NULL DEFAULT 0 CHECK (fee >= 0),     -- micro units of asset_in
  amount_out     bigint NOT NULL CHECK (amount_out > 0),         -- micro units of asset_out
  ref_price      numeric(38,18) NOT NULL CHECK (ref_price > 0),  -- USDT per PINR, before spread
  quoted_price   numeric(38,18) NOT NULL CHECK (quoted_price > 0),
  spread_bps     int    NOT NULL CHECK (spread_bps >= 0),
  impact_bps     int    NOT NULL DEFAULT 0 CHECK (impact_bps >= 0),
  usdt_value     bigint NOT NULL CHECK (usdt_value > 0),         -- for limits and reporting
  price_point_id bigint NOT NULL REFERENCES token_price_points(id),
  status         text   NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN','USED','EXPIRED','REJECTED')),
  expires_at     timestamptz NOT NULL,
  created_at     timestamptz NOT NULL DEFAULT now(),
  CHECK (asset_in <> asset_out),
  CHECK (fee < amount_in)
);
CREATE INDEX swap_quotes_user_idx ON swap_quotes (user_id, created_at DESC);

CREATE TABLE swaps (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  mode            text   NOT NULL CHECK (mode IN ('DEMO','LIVE')),
  user_id         uuid   NOT NULL REFERENCES users(id),
  quote_id        uuid   NOT NULL UNIQUE REFERENCES swap_quotes(id),   -- one quote, one swap
  idempotency_key text   NOT NULL,
  asset_in        text   NOT NULL,
  asset_out       text   NOT NULL,
  amount_in       bigint NOT NULL CHECK (amount_in > 0),
  fee             bigint NOT NULL CHECK (fee >= 0),
  amount_out      bigint NOT NULL CHECK (amount_out > 0),
  price           numeric(38,18) NOT NULL CHECK (price > 0),
  usdt_value      bigint NOT NULL CHECK (usdt_value > 0),
  in_tx_id        uuid   NOT NULL REFERENCES ledger_transactions(id),
  out_tx_id       uuid   NOT NULL REFERENCES ledger_transactions(id),
  tds_asset       text,
  tds_amount      bigint NOT NULL DEFAULT 0 CHECK (tds_amount >= 0),
  created_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, idempotency_key),
  CHECK (asset_in <> asset_out),
  CHECK (in_tx_id <> out_tx_id)
);
CREATE INDEX swaps_user_time_idx ON swaps (user_id, mode, created_at);
CREATE INDEX swaps_mode_time_idx ON swaps (mode, created_at);
CREATE TRIGGER swaps_immutable BEFORE UPDATE OR DELETE ON swaps
  FOR EACH ROW EXECUTE FUNCTION rf_forbid_mutation();

-- Inventory funding, rebalancing and reserve top-ups: proposed by one admin, approved by another.
CREATE TABLE token_treasury_ops (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  mode           text   NOT NULL CHECK (mode IN ('DEMO','LIVE')),
  kind           text   NOT NULL CHECK (kind IN ('FUND_INVENTORY','DEFUND_INVENTORY',
                                                 'REBALANCE_BUY_PINR','REBALANCE_SELL_PINR',
                                                 'FUND_REWARD_POOL','FUND_RECOVERY_RESERVE',
                                                 'RECOVERY_CONVERSION')),
  asset          text   NOT NULL,
  amount         bigint NOT NULL CHECK (amount > 0),
  counter_asset  text,
  counter_amount bigint,
  tx_hash        text,                  -- on-chain leg, when there is one
  ledger_tx_id   uuid REFERENCES ledger_transactions(id),
  status         text   NOT NULL DEFAULT 'PROPOSED' CHECK (status IN ('PROPOSED','APPROVED','EXECUTED','REJECTED')),
  proposed_by    uuid   NOT NULL REFERENCES users(id),
  approved_by    uuid REFERENCES users(id),
  reason         text   NOT NULL,
  created_at     timestamptz NOT NULL DEFAULT now(),
  executed_at    timestamptz,
  CHECK (approved_by IS NULL OR approved_by <> proposed_by)
);
CREATE UNIQUE INDEX token_treasury_ops_tx_uq ON token_treasury_ops (mode, tx_hash) WHERE tx_hash IS NOT NULL;
```

**How this SQL was checked.** All seven sections ran as one transaction on Postgres 16 after migrations 0001–0015, on a database seeded with live-shaped rows (an active USDT buying stake, a slashed merchant, a `CANCELLED` merchant); every existing row came through unchanged. Then: a mixed-asset ledger transaction was refused at commit; a two-leg swap committed and both assets still net to zero; a swap whose out-leg exceeded inventory rolled back both legs; a second release under the same key was refused; an `UNBONDING` row without `release_after` was refused; `swaps` refused `UPDATE`; one quote could not execute twice; a self-approved treasury op was refused; and two opposite swaps deadlocked without the inventory pre-lock and both committed with it.

Three statements in the earlier draft were wrong against the real schema: the system-code list dropped `RECOVERY_FRAUD_SLASH` (added in 0015 — it fails on any database that already has a slash and re-breaks slashing on one that doesn't); `deposits.token_contract` already exists; and the merchant status list dropped `CANCELLED`. All three are fixed above.

### Two details worth getting right in the migration

- **Dust on 18→6 conversion.** The ledger works in bigint micro (6 dp); PINR on chain is 18 dp. The existing USDT path already truncates the trailing 12 digits. Truncate *down* on credit and *up* on debit, and record the residue — otherwise reconciliation drifts by dust and the `CUST-08` seven-clean-days gate never goes green.
- **`asset` must reach `post()`.** Add `asset` to `AccountRef` and have `post()` throw if a single transaction touches two assets. Without that guard, one bad call can credit PINR against a USDT debit and the DB trigger will happily accept it, because the trigger checks that debits equal credits, not that they are the same asset. 0016 now closes that gap in the database as well (section 1), so both the application and the trigger refuse it.

## Core logic and flows

### Ledger postings, the recipes

Every operation below is one balanced `post()` with an idempotency key, and all entries in a transaction share one `asset`.

| Operation | Movement | Idempotency key |
| --- | --- | --- |
| PINR deposit credited | `CUSTODY_HOT_WALLET` to user `AVAILABLE` | `deposit:{chain}:{txHash}:{logIndex}` |
| Stake for tier | user `AVAILABLE` to user `BUY_STAKE` | `stake:{positionId}:lock` |
| Release stake | user `BUY_STAKE` to user `AVAILABLE` | `stake:{positionId}:release` |
| Merchant bond posted | user `AVAILABLE` to user `MERCHANT_STAKE` | `bond:{positionId}:lock` |
| Merchant slash | user `MERCHANT_STAKE` to `RECOVERY_FRAUD_SLASH` | `slash:{merchantId}:{reasonSlug}:{n}` |
| Pay victim from recovery | `RECOVERY_FRAUD_SLASH` to victim `AVAILABLE` | `recovery:{claimId}` |
| Earn position opened | user `AVAILABLE` to user `EARNING`, **plus** `TOKEN_REWARD_POOL` to `REWARD_RESERVED` | `earn:{positionId}:lock` |
| Earn reward paid | `REWARD_RESERVED` to user `AVAILABLE` | `earn:{positionId}:reward:{period}` |
| Earn matured | user `EARNING` to user `AVAILABLE`; unused reserve back to `TOKEN_REWARD_POOL` | `earn:{positionId}:release` |
| Early exit | user `EARNING` to user `AVAILABLE` (net) and `REVENUE_EARLY_EXIT_PENALTIES` (penalty) | `earn:{positionId}:release` |
| Withdrawal reserved | user `AVAILABLE` to user `PENDING_WITHDRAWAL` | `wd:{withdrawalId}:reserve` |
| Withdrawal confirmed | user `PENDING_WITHDRAWAL` to `CUSTODY_HOT_WALLET` | `wd:{withdrawalId}:settle` |
| Unstake requested | No movement — the position becomes UNBONDING and stops counting toward a tier | — |
| Swap in-leg | user AVAILABLE to SWAP\_INVENTORY (net) and REVENUE\_SWAP\_FEES (fee), input asset only | swap:{quoteId}:in |
| Swap out-leg | SWAP\_INVENTORY to user AVAILABLE, output asset only | swap:{quoteId}:out |
| Swap inventory funded (PINR) | CUSTODY\_HOT\_WALLET to SWAP\_INVENTORY, after the Safe transfer confirms | treasury:{opId} |
| Swap inventory funded (USDT) | TREASURY\_EQUITY to SWAP\_INVENTORY, only if custody minus customer liabilities covers it | treasury:{opId} |
| Victim paid from reserve | RECOVERY\_RESERVE to victim AVAILABLE, always USDT | recovery-reserve:{claimId} |

The early-exit key deliberately reuses `:release`, which is the existing convention: it makes "matured" and "exited early" mutually exclusive at the data layer rather than in application logic.

### Deposit flow

```mermaid
sequenceDiagram
  participant U as User
  participant C as BSC
  participant W as Worker
  participant L as Ledger
  U->>C: sends PINR to<br/>their deposit address
  W->>C: transfersTo(PINR, addrs)
  C-->>W: Transfer logs
  W->>W: dedupe on<br/>tx+logIndex
  W->>W: wait 15 conf<br/>+ finalized
  W->>L: post DEPOSIT<br/>asset=PINR
  L-->>U: balance credited
```

The scanner today reads one contract from `settings.chain.tokenContract`. It becomes a loop over enabled tokens, and the asset is resolved from the log's own `address` field, which `transfersTo()` already returns as `tokenContract`. Two guards matter: reject a log whose `tokenContract` is not an enabled token (someone airdropping a look-alike token into your addresses), and keep the existing `deposits_chain_tx_uq (chain_id, tx_hash, log_index)` unique index, which already handles reorg replay.

### Withdrawal and signer changes

The signer service is currently single-token: `SIGNER_TOKEN_CONTRACT`, `SIGNER_MAX_PER_TX_RAW`, `SIGNER_DAILY_CAP_RAW`. It needs a token map with **separate caps per token**, because a cap expressed in raw 18-dp units means something completely different for a token worth $1 and a token worth $0.01. Reuse the whole existing withdrawal path otherwise: OTP, approval mode, `treasury.hotWalletMaxPerTxUsdt`, the gas guard (`holdWithdrawalsOnLowGas`, `minHotBnb`) and the dual-approval threshold all apply unchanged.

One addition: withdrawal limits for PINR should be evaluated on **USDT-equivalent value at oracle price**, not on token count, so the existing treasury caps keep meaning what they mean.

### Worker jobs

`src/server/jobs/jobs.ts` already runs leased jobs. Four to add or change:

| Job | Cadence | What it does | Failure behaviour |
| --- | --- | --- | --- |
| `token_price_poll` | 5 min | Reads the PancakeSwap TWAP, applies move-bound and band checks, writes a `token_price_points` row (accepted or rejected) | On repeated failure: price goes stale, staking suspends, existing tiers hold |
| `token_revaluation` | hourly | Revalues stake positions and merchant bonds against the latest accepted price; sets `WATCH`, `MARGIN_CALL`, `RESTRICTED`; writes `token_valuation_runs` | Skips entirely if the price is stale; never downgrades on stale data |
| `earning_accrual` | hourly | Replaces `runEarningPayouts()`; day-based periods, pays from `REWARD_RESERVED` | Idempotent per `(position, period)`, safe to re-run |
| `token_reconciliation` | daily | On-chain PINR balance of custody addresses vs ledger `CUSTODY_HOT_WALLET` + `CUSTODY_COLD_WALLET` for `asset='PINR'` | Discrepancy creates a `reconciliation_items` row, same as USDT |
| stake\_unbond\_release | 5 min | Releases UNBONDING positions whose release\_after has passed — same asset, same units; skips accounts on fraud hold or with an open dispute | Idempotent via stake:{id}:release; skipped positions go to an admin queue |
| swap\_inventory\_watch | 5 min | Compares each inventory with its target and floor; widens the spread, pauses a direction, alerts treasury | Fails closed: if balances cannot be read, swaps pause |
| swap\_quote\_cleanup | hourly | Marks expired OPEN quotes as EXPIRED | Housekeeping only — execution checks expires\_at itself |

### Ledger invariants to assert

Extend `checkLedgerIntegrity()` with these, per asset. Each one should be a go-live auto-check, the same way the existing custody invariant is.

1. Sum of all user balances + system balances = 0, **per asset**.
2. `CUSTODY_HOT_WALLET` + `CUSTODY_COLD_WALLET` for PINR = on-chain PINR balance of custody addresses, within a dust tolerance.
3. `REWARD_RESERVED` >= sum of unpaid projected rewards across `ACTIVE` earning positions.
4. For every merchant with `status = 'ACTIVE'`: `bond_value_usdt >= required_stake_usdt`, or an open margin call exists.
5. No `ledger_transaction` has entries in more than one asset. Since 0016 the database trigger refuses it too; the check stays as a second line.
6. `SWAP_INVENTORY` ≥ 0 per asset — already enforced by `allow_negative = false`, asserted anyway.
7. Every `swaps` row has exactly one in-leg and one out-leg ledger transaction, each in the asset the row names.
8. While PINR-only bonds are enabled, `RECOVERY_RESERVE` (USDT) ≥ `token.recoveryReserveMinUsdt`.

### New server modules

Following the existing layout under `src/server/`:

- `token/config.ts` — enabled tokens, contract validation at save time
- `token/oracle.ts` — price fetch, bounds, staleness, `priceAt(timestamp)` for reproducing a past valuation
- `token/valuation.ts` — haircut maths, coverage ratios, the revaluation pass
- `token/treasury.ts` — reward pool, reservations, supply events
- `earning/plans.ts` — plan and version CRUD, maker-checker
- `earning/accrual.ts` — the day-based accrual engine
- `merchants/bond.ts` — requirement sizing, margin calls, slash ordering
- `swap/quote.ts` — pricing, limits, quote creation
- `swap/execute.ts` — the one-transaction execution with the inventory pre-lock
- `swap/inventory.ts` — targets, floors, treasury ops
- `stakes/unbond.ts` — unstake requests, cooldowns, the release job, merchant exit checks

Existing modules that change: `ledger/ledger.ts` (asset threading), `wallet/deposits.ts` (multi-token scan), `wallet/withdrawals.ts` (asset + value limits), `stakes/stakes.ts` (asset-aware), `limits/limits.ts` (PINR tier source and fee discount), `merchants/eligibility.ts` (bond coverage instead of flat stake), `settings/registry.ts` (new groups), `readiness/items.ts` (new gate items).

### Admin surface

| Screen | Purpose |
| --- | --- |
| Admin to Token to Overview | Contract, supply, treasury balances, pool balance, current price, reserved vs free |
| Admin to Token to Oracle | Price history, rejected points and why, manual override with 2FA and a reason |
| Admin to Earn plans | List, create, re-rate (maker-checker), close; projected liability at each rate |
| Admin to Stakes | Extend the existing tiers screen with asset, haircut, fee discount, min hold |
| Admin to Merchants | Bond coverage column, margin-call queue, slash with dual approval and appeal state |
| Admin to Treasury | Extend for PINR: pool top-ups, liquidations, supply events |
| Admin to Swap | Inventory per asset against target, spread and fee, direction switches, today's volume and net flow, recent swaps |
| Admin to Treasury ops | Propose and approve inventory funding, rebalancing, reward-pool and recovery-reserve top-ups; the on-chain tx is verified before any ledger credit |
| Admin to Unstake queue | Unbonding positions held by a fraud hold or dispute, and merchant exits with their release checklist |

User-facing screens already exist at `/app/stake` and `/app/earn` and keep their shape; they gain an asset switch, a coverage bar, and plan cards.

## Risk, security and compliance

I am not a lawyer and this is not legal advice — the points below are what to put in front of counsel, not conclusions to act on. Your go-live tracker already has `LEGAL-02` (written legal opinion on the operating model) open; the token materially changes what that opinion has to cover, so it should be raised before you build, not after.

### The legal exposure, ranked

| Risk | What triggers it | How to reduce it |
| --- | --- | --- |
| **Unregulated deposit scheme (BUDS Act 2019)** | Taking money or assets from the public with a promised or represented return and a fixed lock-in. An admin-set APY on a token you issue, with a 30-day lock, is close to the centre of this | Get counsel's view before launch. Frame rewards as variable and discretionary, never "guaranteed"; prefer fee-share or cashback over a fixed rate; keep the existing "variable, not guaranteed" disclaimer prominent, not buried |
| **Collective investment scheme / securities characterisation** | Selling a token on the expectation of profit from your efforts | Lead with utility (fee discount, limits, merchant bond), not with yield. Do not publish price targets or returns in marketing |
| **FIU-IND obligations** | You are already registering as a Reporting Entity (`LEGAL-01`). A self-issued token expands the surface | Same KYC and AML rules for PINR as for USDT, from day one. No "token-only" path that skips KYC |
| **Tax** | Section 115BBH (30% on VDA gains) and Section 194S (1% TDS on transfer of a VDA) both apply. Staking rewards, PINR/USDT swaps and merchant slashes are all arguably VDA transfers | This is `LEGAL-06` in your tracker. Get the TDS mechanics decided **before** you pay a single reward, because retro-fixing TDS on thousands of small accruals is painful |
| **Self-dealing on price** | You issue the token, you run the pool, and you set the oracle that values collateral | Publish the oracle rule. Log every price point including rejected ones. Never let a manual override apply without a written reason and 2FA |

### Technical and security risks

| Risk | Mitigation |
| --- | --- |
| Oracle manipulation through a thin pool | TWAP not spot, bounded per-update movement, absolute price band, minimum hold before a stake counts, and a cap on how much limit PINR can unlock at all |
| Reward pool insolvency | Reserve the full projected reward at position open. A plan that cannot reserve shows as full |
| Mint authority / rug perception | Fixed supply with renounced ownership, or a capped mint behind a 3-of-5 Safe and a 48h timelock. Publish the addresses |
| Unlocked liquidity | Lock LP tokens and publish the lock transaction |
| Look-alike token deposits | The scanner rejects any Transfer log whose contract is not an enabled token |
| Reorg / double credit | Existing `deposits_chain_tx_uq` plus the finalized-block gate already handle this; keep both for PINR |
| Dust drift on 18 to 6 dp conversion | Truncate down on credit, up on debit, record residue; assert it in reconciliation |
| Cross-asset ledger corruption | `post()` rejects any transaction touching two assets |
| Hot wallet exposure | PINR gets its own per-tx and daily signer caps, denominated so they mean the same thing as the USDT ones |
| Emergency stop | Per-token kill switches (`depositsEnabled`, `withdrawalsEnabled`, `stakingEnabled`, `earnEnabled`) separate from the global pause, so one token can be frozen without stopping the exchange |
| Opposite swaps deadlocking on the two inventory rows | Lock both SWAP\_INVENTORY rows in a fixed order (USDT, then PINR) at the start of every swap — reproduced and fixed in the Postgres test |
| A sell-side run drains USDT inventory | Global hourly net-sell cap, inventory floors that pause the sell side, and no "guaranteed cash-out" wording anywhere |
| TWAP-lag arbitrage through the swap | Quote the conservative side of TWAP and spot, a spread, and a 24 h maturity before deposited PINR can be sold |
| Victims cannot be paid when bonds are PINR-only | Company-funded RECOVERY\_RESERVE in USDT; new merchant approvals pause while it is below its minimum |

### Additions to the go-live gate

These belong in `readiness_items` alongside the existing ones, with evidence and an approver, exactly as `CUST-04` and `CUST-07` work today.

- **TOK-01 (BLOCKER)** — Contract deployed and source-verified on mainnet BscScan; address recorded in `token_supply_events`.
- **TOK-02 (BLOCKER)** — Mint authority renounced, or held by a multisig plus timelock with signers documented.
- **TOK-03 (BLOCKER)** — LP locked, lock transaction published.
- **TOK-04 (BLOCKER)** — Independent smart-contract audit or, at minimum, a published review; your `INFRA-09` pen-test scope extended to the token paths.
- **TOK-05 (BLOCKER)** — Counsel's written opinion specifically covering the Earn model and the merchant bond.
- **TOK-06 (BLOCKER)** — Tax treatment (194S TDS, 115BBH) confirmed in writing and implemented in the reward path.
- **TOK-07 (HIGH)** — Oracle live for 7 consecutive days with no rejected-point backlog and no stale gaps.
- **TOK-08 (HIGH)** — Testnet run complete: deposit, stake, accrue, mature, unstake, withdraw, slash, reconcile — with tx hashes.
- **TOK-09 (HIGH)** — Reward pool funded to cover 100% of projected liability at the launch plan rates.
- **TOK-10 (HIGH)** — Seven consecutive clean PINR reconciliation days, mirroring `CUST-08`.
- **TOK-11 (BLOCKER)** — Swap drill on testnet with evidence: concurrent opposite swaps, a failed out-leg, the inventory-floor pause, and one quote submitted twice.
- **TOK-12 (BLOCKER when bonds are PINR-only)** — `RECOVERY_RESERVE` funded to its policy minimum from company USDT.
- **TOK-13 (BLOCKER for swaps on LIVE)** — Tax treatment of swaps (194S on VDA-to-VDA transfers) confirmed in writing and implemented.

## Rollout, and what I need from you before any code

The ordering below is deliberate: the ledger work comes first because everything else sits on it, and the token is deployed late because its parameters are permanent. Nothing here touches the live USDT exchange path — each phase ships behind a flag that is off.

| Phase | What ships | Go / no-go gate |
| --- | --- | --- |
| **0. Decisions** | Tokenomics, the three architecture choices, counsel briefed | Counsel has the Earn model in writing |
| **1. Ledger goes two-asset** | `asset` threaded through `AccountRef`, `post()`, balances, integrity check; deposit addresses decoupled from asset | Existing USDT test suite green, unchanged; cross-asset transaction rejected in a test |
| **2. Token deployed to testnet** | Contract, Safe, verification, `chain.pinr` settings with save-time validation | `erc20Symbol` / `erc20Decimals` validated against chain; wrong address refused |
| **3. Custody two-token** | Scanner loop, signer token map with per-token caps, PINR deposit and withdrawal | Full testnet deposit-to-credit and withdrawal-to-confirm run with tx hashes |
| **4. Oracle** | `token_price_poll`, bounds, staleness, price history screen | 7 days running, no stale gaps, rejected points explainable |
| **5. Internal swap** | swap\_quotes + swaps, inventory accounts, treasury ops with maker–checker, limits and circuit breakers, swap screen | Opposite-swap concurrency test passes; a failed out-leg rolls back the in-leg; inventory never goes negative; sell side pauses at its floor |
| **6. User staking** | PINR tiers, haircut, min hold, revaluation, grace period, fee discount | Revaluation never changes limits mid-order; downgrade path tested; unstake returns exactly the staked PINR units after the cooldown |
| **7. Earn plans** | `earning_plans` + versions, day-based accrual, reservation at open, admin screens | Plan cannot open without a full reserve; re-rating leaves open positions untouched |
| **8. Merchant bond** | Two-tranche bond, sizing, margin calls, slash ordering, unbonding cooldown | Slash drill: victim paid in USDT (reserve first in PINR-only mode), merchant exit releases the same PINR after the cooldown, audit trail complete |
| **9. Mainnet** | Mainnet deploy, LP seeded and locked, features enabled one at a time | All TOK-01 to TOK-13 approved with evidence |

The platform is **LIVE** now, so the rule for phases 1 to 8 is stricter than before: build and test against BSC testnet and a staging copy of the database; ship to production only behind flags that are off; and never let a migration step rewrite an existing USDT row. The internal swap (phase 5) comes before user staking on purpose — once new stakes are PINR-only, the swap is how users get PINR without a wallet.

### Open questions I need answered

These change the design, not just the copy. The first three are the ones that block Phase 0.

- [ ] **What does "3%" mean?** Per annum, per month, or 3% cashback on fees paid? (See the table in Part 2 — the cost difference is roughly 14x.)
- [ ] **Where do rewards come from?** A fixed pre-funded pool from treasury allocation, or newly minted tokens, or a share of real revenue? This is the difference between a sustainable programme and a dilution schedule.
- [ ] **Fixed supply, or keep a capped mint?** Fixed-and-renounced is the strongest position and the hardest to reverse.
- [x] **Merchant bond: full PINR (your direction), or USDT floor plus a PINR tranche?** I have recommended the second and sized it at a 50-60% USDT floor.

  If you go full PINR, the company-funded `RECOVERY_RESERVE` in Part 5 is mandatory — how much USDT will you commit to it?
- [ ] Do existing USDT merchant stakes migrate, get grandfathered, or stay as they are? Default in Part 5: grandfathered and never converted automatically, with a voluntary move-to-PINR screen.
- [ ] **A direct INR ⇄ PINR order side?** Partly answered: PINR swaps with USDT inside the platform (Part 6), and INR reaches PINR through USDT. A direct INR pair would pull in the whole pricing, merchant-matching and dispute machinery and roughly double the scope — do you ever want it?
- [ ] Name, symbol, total supply, and the allocation split. "PINR" is a placeholder: a symbol ending in INR can read like a rupee-pegged coin, which this is not.
- [ ] Target launch date, so counsel and the tax adviser can be engaged with a real deadline.
- [x] How much USDT and how much PINR go into swap inventory at launch? That is the ceiling on what users can swap on day one.
- [x] Sell side (PINR → USDT) on at launch, or buy-only for the first weeks while the pool matures?
- [ ] Are 100 bps spread and a 20 bps fee acceptable starting points for the swap?
- [ ] User unstake cooldown: 24 hours, or none?

Answer the first four and I can turn this into a concrete implementation plan with migration files, module signatures and a task breakdown.

