# Untitled

<!-- tab: Untitled -->

# How to Find Your Meta Business Portfolio (BM) ID

2026-10-11 · @someone

To share your Agency Ad Account we need one thing from you: your Business Portfolio ID (also called the Business Manager ID or BM ID) — a 15–17 digit number. This guide shows exactly where to click on desktop, in Ads Manager, and on mobile, and what to do if you do not have a Business Portfolio yet.

## 1. What the BM ID is (and what it is not)

Your Business Portfolio ID is the number Meta assigns to your Business Portfolio (the account that owns your Pages, ad accounts and pixels). Meta renamed "Business Manager" to "Business Portfolio" in 2024, so you will see both names — they are the same thing, and the ID has not changed. We use it to share the agency ad account into your portfolio as a partner, so you get full control inside your own Ads Manager.

| Looks like | What it is | Correct? |
| --- | --- | --- |
| `1234567890123456` (15–17 digits, found under Business info) | Business Portfolio / Business Manager ID | Yes — send this |
| `act_1234567890` or "Ad account ID: 1234567890" | Ad account ID | No |
| `100012345678901` next to your Page name | Page ID | No |
| The number in your profile URL | Personal profile ID | No |
| `123456789012345` under Events Manager | Pixel / dataset ID | No |

The fastest check: the number you send must come from a screen that says **Business portfolio ID** or **Business Manager ID**.

## 2. Method 1 — Business Settings → Business info (desktop, fastest)

Takes about 30 seconds. Use a laptop or desktop browser, logged in to the Facebook profile that is an Admin of your business.

1. Open [business.facebook.com/settings](https://business.facebook.com/settings). If you are asked to choose a business, pick the one where you want the ad account.
2. In the left menu, scroll to the bottom and click **Business info** (on some accounts it is under **Business portfolio info**).
3. At the top of the page you will see **Business portfolio ID** (older accounts: **Business Manager ID**) followed by a 15–17 digit number.
4. Click the number to select it, copy it, and send it to us on WhatsApp.

Shortcut: [business.facebook.com/settings/info](https://business.facebook.com/settings/info) opens the Business info page directly.

If the left menu has no **Business info** entry, you are in Meta Business Suite, not Business Settings. Click the gear icon (**Settings**) at the bottom of the left sidebar, then **Business portfolio info** — the ID is on that page too.

## 3. Method 2 — Copy it from the browser URL

Every Business Settings page carries the ID in its web address. Open any Business Settings page and look at the address bar:

```
https://business.facebook.com/settings/people?business_id=1234567890123456
```

The digits after `business_id=` are your Business Portfolio ID. Copy only the number, not the `business_id=` part and nothing after an `&`.

Do not confuse it with `act=` — that one is the ad account ID and will not work:

```
https://adsmanager.facebook.com/adsmanager/manage/campaigns?act=987654321&business_id=1234567890123456
```

In this example, `1234567890123456` is the ID we need; `987654321` is not.

## 4. Method 3 — From Ads Manager (adsmanager.facebook.com)

Ads Manager itself does not display the Business Portfolio ID on screen, but it is two clicks away.

1. Open [adsmanager.facebook.com](https://adsmanager.facebook.com) and make sure the account selector in the top-left shows an ad account that belongs to your business (the business name appears under the account name).
2. Click the **gear icon** (Settings) in the left navigation bar, or open the **All tools** menu (the grid icon) and click **Business settings** under *Manage business*.
3. Business Settings opens in a new tab. In the left menu, click **Business info** at the bottom.
4. Copy the number next to **Business portfolio ID** / **Business Manager ID**.

Quicker: while you are in Ads Manager, look at the address bar — if it contains `business_id=`, the digits after it are your ID (see Method 2). If the URL only has `act=`, the ad account is a personal one and is not inside a Business Portfolio; use Method 1, or create a portfolio (section 6).

## 5. Method 4 — On your phone

**Meta Business Suite app (Android / iPhone)**

1. Open the Meta Business Suite app and make sure the correct business is selected at the top.
2. Tap the menu (**≡** or **More**) → **Settings**.
3. Tap **Business portfolio info** (older versions: **Business info**).
4. Your **Business portfolio ID** is listed there. Long-press the number to copy it.

**Mobile browser (works on every phone)**

1. Open Chrome or Safari and go to [business.facebook.com/settings/info](https://business.facebook.com/settings/info).
2. If the page looks cramped or redirects to the app, turn on **Desktop site** (Chrome: ⋮ menu → *Desktop site*; Safari: **aA** → *Request Desktop Website*) and reload.
3. The ID is at the top of the Business info page. Long-press to copy.

If the Facebook app opens instead of the browser, copy the link and paste it directly into the browser's address bar.

## 6. No Business Portfolio yet? Create one in 2 minutes

If [business.facebook.com/settings](https://business.facebook.com/settings) shows "Create a business portfolio" instead of your business, you do not have one yet. It is free and you do not need a registered company.

1. Go to [business.facebook.com/overview](https://business.facebook.com/overview) and click **Create a business portfolio** (older wording: **Create account**).
2. Enter a **Business name** (your brand or your own name is fine), **Your name**, and a **business email** you can access.
3. Click **Submit**. Meta sends a confirmation email — open it and click **Confirm now**.
4. You are taken to Business Settings. Click **Business info** at the bottom of the left menu and copy the **Business portfolio ID**.

Two things that save time later:

- Turn on **two-factor authentication** on your Facebook profile (Settings → Security and login). New portfolios often cannot add partners or run ads until the admin has 2FA.
- Use a Facebook profile that is at least a few weeks old and has not been restricted. A brand-new profile creating a portfolio and receiving an ad account on the same day is the most common reason for a "Your business is restricted" message.

## 7. Send us the ID

Send one WhatsApp message in this format — it lets us share the account without any back-and-forth:

```
Business Portfolio ID: 1234567890123456
Business name: <name shown in Business Settings>
Service: Agency Ad Account
```

Please send the ID as text, not only as a screenshot — we copy it directly into Meta and a typo in a 16-digit number means the account goes to the wrong business. A screenshot of the Business info page as a second message is welcome.

You only need to be an **Admin** of that portfolio. You do not need Business verification, a payment method or a registered company to receive the account.

## 8. After you send it

We add your Business Portfolio as a partner on the agency ad account. Nothing needs to be accepted on your side — the account appears in your portfolio automatically, usually within a few minutes of confirmation.

**Where to find it**

1. Open [business.facebook.com/settings](https://business.facebook.com/settings) → **Accounts** → **Ad accounts**.
2. The new account is listed with **Owned by** showing our agency name. That is correct — agency accounts stay owned by the agency and are shared to you with full control.

**Give yourself access (one time)**

1. Click the new ad account in that list, then click **Add people**.
2. Select your own name, switch on **Full control** ("Manage ad account"), and click **Assign**.
3. Open [adsmanager.facebook.com](https://adsmanager.facebook.com), click the account selector in the top-left, and pick the new account. You are ready to create campaigns.

You do not add a payment method — the account runs on the prepaid balance you top up with us. If the account does not show up within 30 minutes of our confirmation, send us a screenshot of your **Ad accounts** page and we will re-check the ID.

## 9. Common mistakes and FAQ

| Situation | What to do |
| --- | --- |
| I sent an ID and you said it is wrong | It was probably the ad account ID (`act_…`) or a Page ID. Go to **Business Settings → Business info** and copy the number labelled *Business portfolio ID*. |
| I have more than one business portfolio | Send the ID of the one where you will run the ads and where your role is **Admin** (check under **Users → People**, your name). |
| I am an Employee, not an Admin | Ask the portfolio Admin to send the ID, or create your own portfolio (section 6) in 2 minutes. |
| Business Settings says "Your business is restricted" | The account will still arrive, but ads will not run until the restriction is lifted. Request a review under **Security Center**, or create a fresh portfolio from an older, clean profile. |
| Meta asks for Business verification | Not needed to receive a shared ad account. Ignore it unless Meta blocks ads later. |
| The page shows "Business Manager ID" instead of "Business portfolio ID" | Same number, older wording. Send it. |
| My ad account is not inside any portfolio | Create a portfolio (section 6). Personal ad accounts cannot receive an agency account. |
| I only use the Facebook mobile app | Use the mobile browser method in section 5 with *Desktop site* turned on. |
| The ID has 15, 16 or 17 digits — which is right? | All are valid lengths. Copy exactly what Meta shows. |

## 10. Checklist before you send

- [ ] The number was copied from a screen that says **Business portfolio ID** or **Business Manager ID** (not `act_`, not a Page)
- [ ] It is 15–17 digits with no spaces or letters
- [ ] You are an **Admin** of that portfolio (Business Settings → Users → People)
- [ ] Two-factor authentication is on for your Facebook profile
- [ ] Sent as text on WhatsApp in the format from section 7

Still stuck? Send us a screenshot of your Business Settings left menu and we will tell you exactly where to click. Guide hosted at [agency.mexacobm.online/guide/bm-id](https://agency.mexacobm.online/guide/bm-id).

